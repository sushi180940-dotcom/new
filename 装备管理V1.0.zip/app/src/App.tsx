import { useState, useMemo, useEffect } from 'react'
import Sidebar from './components/Sidebar'
import TopBar from './components/TopBar'
import DashboardPage from './pages/DashboardPage'
import WarehouseVisPage from './pages/WarehouseVisPage'
import ProcurementPage, { contractData, orderData } from './pages/ProcurementPage'
import SupplierPage from './pages/SupplierPage'
// CodingPage removed - merged into SystemPage
import EmergencyPage from './pages/EmergencyPage'
import EmergencyMgmtDashboard from './pages/EmergencyMgmtDashboard'
import CommandPage from './pages/CommandPage'
import SupervisionPage from './pages/SupervisionPage'
import AnalysisPage from './pages/AnalysisPage'
import TrainingPage from './pages/TrainingPage'
import EquipmentSupportPage from './pages/EquipmentSupportPage'
import SystemPage from './pages/SystemPage'
import InOutRecordPage from './pages/InOutRecordPage'
import EquipmentBorrowPage from './pages/EquipmentBorrowPage'
import RepairPage from './pages/RepairPage'
import ScrapPage from './pages/ScrapPage'
import InboundPage from './pages/InboundPage'
import OutboundPage from './pages/OutboundPage'
import InventoryDetailPage from './pages/InventoryDetailPage'
import SafetyStockPage from './pages/SafetyStockPage'
import StockStatsPage from './pages/StockStatsPage'
import EquipmentMgmtDashboard from './pages/EquipmentMgmtDashboard'
import WarehouseMgmtPage from './pages/WarehouseMgmtPage'
import MaintenancePage from './pages/MaintenancePage'
import SplitManagementPage from './pages/SplitManagementPage'
import EquipStandardPage from './pages/EquipStandardPage'

// Module -> parent topNav mapping
const moduleToTopNav: Record<string, string> = {
  dashboard: 'home',
  command: 'command-center',
  analysis: 'command-center',
  procurement: 'equipment-mgmt',
  supplier: 'equipment-mgmt',
  warehouse: 'home',
  supervision: 'home',
  'rule-cfg': 'home',
  'alert': 'home',
  'control': 'home',
  'subscribe': 'home',
  coding: 'system',
  rule: 'system',
  approval: 'system',
  implant: 'system',
  trace: 'system',
  codemgmt: 'system',
  'equipment-support': 'procurement',
  'tech-personnel': 'procurement',
  'warranty-query': 'procurement',
  'fault-repair': 'procurement',
  'service-review': 'procurement',
  'complaint-mgmt': 'procurement',
  system: 'system',
  emergency: 'emergency',
  training: 'home',
  'inout-record': 'home',
  'equip-borrow': 'home',
  'warehouse-mgmt': 'home',
  inbound: 'home',
  outbound: 'home',
  inventory: 'home',
  'safety-stock': 'home',
  repair: 'home',
  scrap: 'home',
  'equipment-workbench': 'dashboard',
}

const topNavNames: Record<string, string> = {
  home: '首页',
  dashboard: '所队装备管理',
  emergency: '应急物资管理',
  'command-center': '指挥决策',
  'equipment-mgmt': '装备管理',
  system: '系统管理',
}

const moduleNames: Record<string, string> = {
  dashboard: '所队装备管理',
  warehouse: '仓库可视化',
  procurement: '采购及售后管理',
  supplier: '供应商管理',
  coding: '装备编码管理',
  equipment: '装备管理',
  emergency: '应急装备管理',
  command: '指挥决策',
  supervision: '装备监督管理',
  training: '应用技能培训',
  'equipment-support': '装备技术保障',
  system: '系统管理',
  'inout-record': '出入库记录',
  'equip-borrow': '装备领用',
  'warehouse-mgmt': '仓库管理',
  inbound: '入库管理',
  outbound: '出库管理',
  inventory: '库存明细',
  'safety-stock': '安全库存',
  repair: '报修管理',
  scrap: '报废管理',
  analysis: '装备研判分析',
  'equipment-workbench': '装备工作台',
}

// All sub-tab labels
const subTabLabels: Record<string, string> = {
  // command
  map: '全省管理一张图',
  'command-map': '指挥决策一张图',
  // analysis
  model: '数据模型',
  'purchase-analysis': '采购研判',
  'stock-analysis': '库存研判',
  // procurement
  dashboard: '工作台',
  purchase: '采购管理',
  contract: '合同管理',
  order: '订单管理',
  acceptance: '验收管理',
  // supplier
  register: '注册审批',
  enterprise: '供应商信息',
  product: '装备管理',
  penalty: '处罚管理',
  // coding
  'rule-cfg': '装备监督',
  rule: '编码规则',
  approval: '编码管理',
  implant: '编码植入',
  trace: '编码溯源',
  codemgmt: '编码字典',
  // equipment (所队装备管理)
  'room-config': '装备室配置管',
  inventory: '库存管理',
  'personal-alloc': '个人装备分配',
  'repair-mgmt': '报修管理',
  'scrap-mgmt': '报废管理',
  inbound: '入库管理',
  outbound: '出库管理',
  stockcheck: '装备盘点',
  ledger: '台账管理',
  stats: '库存统计',
  // emergency (应急装备管理)
  transfer: '装备调拨',
  'team-distribute': '所队装备配发',
  'em-inventory': '应急库存',
  fixed: '转固定资产',
  // supervision
  alert: '预警查询',
  control: '装备管控',
  subscribe: '提醒订阅',
  // training
  material: '培训资料',
  process: '培训过程',
  expert: '专家库',
  forum: '交流互动',
  // equipment-support
  'tech-personnel': '技术人员管理',
  'warranty-query': '装备质保查询',
  'fault-repair': '装备故障报修',
  'service-review': '服务评价',
  'complaint-mgmt': '投诉管理',
  // system
  org: '机构管理',
  role: '角色管理',
  user: '用户管理',
  device: '终端设备',
  log: '日志管理',
}

export default function App() {
  const [activeTopNav, setActiveTopNav] = useState('home')
  const [activeModule, setActiveModule] = useState('dashboard')
  const [activeSubTab, setActiveSubTab] = useState('')
  // sidebar removed

  // Switch top nav
  const handleTopNavChange = (key: string) => {
    setActiveTopNav(key)
    if (key === 'home') {
      setActiveModule('dashboard')
      setActiveSubTab('')
    }
    // Otherwise keep current module/subTab if it belongs to this topNav
    const currentModuleParent = moduleToTopNav[activeModule]
    if (currentModuleParent !== key) {
      // Switch to first module of the new top nav
      const firstModule = getFirstModule(key)
      if (firstModule) {
        setActiveModule(firstModule)
        setActiveSubTab('')
      }
    }
  }

  function getFirstModule(topNav: string): string | null {
    const mapping: Record<string, string[]> = {
      'command-center': ['command', 'analysis'],
      'equipment-mgmt': ['procurement', 'supplier'],
      'system': ['system'],
    }
    return mapping[topNav]?.[0] || null
  }

  // Handle navigation from sidebar or breadcrumb
  const handleNavigate = (module: string, subTab?: string) => {
    setActiveModule(module)
    if (subTab) {
      setActiveSubTab(subTab)
    } else {
      // If clicking parent without subtab, keep existing or clear
      setActiveSubTab('')
    }
    // Sync top nav
    const parentTopNav = moduleToTopNav[module]
    if (parentTopNav && parentTopNav !== activeTopNav) {
      setActiveTopNav(parentTopNav)
    }
  }

  // Top navs that have empty sidebar (all modules moved to workbenches)
  const topNavsWithEmptySidebar = ['home', 'equipment-mgmt', 'dashboard', 'emergency']

  // Breadcrumb
  const breadcrumb = useMemo(() => {
    const items: { label: string; key: string }[] = []
    // Only show top nav label if it has sidebar submenus
    if (!topNavsWithEmptySidebar.includes(activeTopNav)) {
      items.push({ label: topNavNames[activeTopNav] || '首页', key: activeTopNav })
    }
    if (activeModule !== 'dashboard' && activeTopNav !== 'home') {
      items.push({ label: moduleNames[activeModule] || activeModule, key: activeModule })
    }
    if (activeSubTab && subTabLabels[activeSubTab]) {
      items.push({ label: subTabLabels[activeSubTab], key: activeSubTab })
    }
    return items
  }, [activeTopNav, activeModule, activeSubTab])

  // Sync top nav when module changes
  useEffect(() => {
    const expectedTopNav = moduleToTopNav[activeModule]
    if (expectedTopNav && expectedTopNav !== activeTopNav) {
      setActiveTopNav(expectedTopNav)
    }
  }, [activeModule])

  const renderPage = () => {
    switch (activeModule) {
      case 'dashboard': return <DashboardPage onNavigate={handleNavigate} />
      case 'equipment-workbench': return <EquipmentMgmtDashboard onNavigate={handleNavigate} />
      case 'warehouse': return <WarehouseVisPage />
      case 'procurement': return <ProcurementPage activeSubTab={activeSubTab} onNavigate={handleNavigate} />
      case 'supplier': return <SupplierPage activeSubTab={activeSubTab} onNavigate={handleNavigate} contractData={contractData} orderData={orderData} />
      // coding merged into system module
      case 'emergency': return activeSubTab ? <EmergencyPage activeSubTab={activeSubTab} /> : <EmergencyMgmtDashboard onNavigate={handleNavigate} />
      case 'command': return <CommandPage activeSubTab={activeSubTab} />
      case 'supervision': return <SupervisionPage activeSubTab={activeSubTab} onNavigate={handleNavigate} />
      case 'analysis': return <AnalysisPage activeSubTab={activeSubTab} />
      case 'training': return <TrainingPage activeSubTab={activeSubTab} />
      case 'equipment-support': return <EquipmentSupportPage activeSubTab={activeSubTab} onNavigate={handleNavigate} />
      case 'system': return <SystemPage activeSubTab={activeSubTab} />
      case 'maintenance': return <MaintenancePage onNavigate={handleNavigate} />
      case 'split-management': return <SplitManagementPage onNavigate={handleNavigate} />
      case 'equip-standard': return <EquipStandardPage onNavigate={handleNavigate} />
      case 'inout-record': return <InOutRecordPage onNavigate={handleNavigate} />
      case 'equip-borrow': return <EquipmentBorrowPage onNavigate={handleNavigate} />
      case 'warehouse-mgmt': return <WarehouseMgmtPage onNavigate={handleNavigate} activeSubTab={activeSubTab} />
      case 'inbound': return <InboundPage onNavigate={handleNavigate} />
      case 'outbound': return <OutboundPage onNavigate={handleNavigate} />
      case 'repair': return <RepairPage onNavigate={handleNavigate} />
      case 'scrap': return <ScrapPage onNavigate={handleNavigate} />
      case 'inventory':
      case 'safety-stock':
        return <WarehouseMgmtPage onNavigate={handleNavigate} />
      default: return <DashboardPage />
    }
  }

  return (
    <div className="flex h-screen w-screen overflow-hidden" style={{ background: 'var(--content-bg)' }}>
      {/* Main area */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <TopBar
          activeTopNav={activeTopNav}
          activeModule={activeModule}
          onTopNavChange={handleTopNavChange}
          onNavigate={handleNavigate}
        />
        {/* Breadcrumb bar */}
        <div className="flex items-center px-6 h-10 text-sm" style={{ background: '#fff', borderBottom: '1px solid var(--border-color)' }}>
          <div className="flex items-center gap-2">
            {breadcrumb.map((item, index) => (
              <span key={item.key} className="flex items-center gap-2">
                {index > 0 && <span className="text-gray-300">/</span>}
                <span className={index === breadcrumb.length - 1 ? 'text-gray-800 font-medium' : 'text-gray-500'}>
                  {item.label}
                </span>
              </span>
            ))}
          </div>
        </div>
        {/* Main content */}
        <main className="flex-1 overflow-y-auto scrollbar-thin animate-fade-in" style={{ background: 'var(--content-bg)' }}>
          {renderPage()}
        </main>
      </div>
    </div>
  )
}
