import { useState, useMemo, useRef, useCallback, useEffect } from 'react'

/* ================================================================
   Types
   ================================================================ */
interface TagNode {
  id: string
  name: string
  parentId: string | null
  color: string
  description: string
  isLeaf: boolean
  isEnabled: boolean
  equipCount: number
  scope: 'all' | 'specific'
  scopeTargets?: string[]
  autoRuleEnabled: boolean
  autoRules: AutoRule[]
  children?: TagNode[]
}

interface AutoRule {
  id: string
  field: string
  operator: string
  value: string
}

interface BoundEquip {
  id: string
  code: string
  name: string
  spec: string
  location: string
  source: 'manual' | 'auto'
}

/* ================================================================
   Constants
   ================================================================ */
const PRESET_COLORS = [
  { value: '#ff4d4f', label: '红色' },
  { value: '#faad14', label: '橙色' },
  { value: '#52c41a', label: '绿色' },
  { value: '#1890ff', label: '蓝色' },
  { value: '#722ed1', label: '紫色' },
  { value: '#eb2f96', label: '粉色' },
  { value: '#13c2c2', label: '青色' },
  { value: '#8c8c8c', label: '灰色' },
]

const RULE_FIELDS = [
  { value: 'category', label: '品类', type: 'select', options: ['防护装备', '通信设备', '应急装备', '记录设备', '照明设备', '警械装备'] },
  { value: 'warehouse', label: '存放仓库', type: 'select', options: ['省厅主仓库', '市局限装备仓库', '区县装备室'] },
  { value: 'status', label: '库存状态', type: 'select', options: ['在库', '领用', '维修'] },
  { value: 'validDays', label: '保质期剩余天数', type: 'number' },
  { value: 'inDate', label: '入库日期', type: 'date' },
]

const OPERATORS: Record<string, { value: string; label: string }[]> = {
  select: [{ value: 'eq', label: '等于' }, { value: 'ne', label: '不等于' }],
  number: [{ value: 'eq', label: '等于' }, { value: 'lt', label: '小于' }, { value: 'gt', label: '大于' }, { value: 'lte', label: '小于等于' }, { value: 'gte', label: '大于等于' }],
  date: [{ value: 'eq', label: '等于' }, { value: 'before', label: '早于' }, { value: 'after', label: '晚于' }],
}

/* ================================================================
   Sample Data
   ================================================================ */
function generateSampleData(): TagNode[] {
  return [
    {
      id: 't1', name: '状态类', parentId: null, color: '#faad14', description: '按装备状态分类', isLeaf: false, isEnabled: true, equipCount: 28, scope: 'all', autoRuleEnabled: false, autoRules: [],
      children: [
        { id: 't1-1', name: '临期30天', parentId: 't1', color: '#faad14', description: '保质期剩余30天内的装备', isLeaf: true, isEnabled: true, equipCount: 23, scope: 'all', autoRuleEnabled: true, autoRules: [{ id: 'r1', field: 'validDays', operator: 'lte', value: '30' }] },
        { id: 't1-2', name: '报废待定', parentId: 't1', color: '#ff4d4f', description: '待报废处理的装备', isLeaf: true, isEnabled: true, equipCount: 5, scope: 'all', autoRuleEnabled: false, autoRules: [] },
      ]
    },
    {
      id: 't2', name: '活动类', parentId: null, color: '#1890ff', description: '按活动/任务分类', isLeaf: false, isEnabled: true, equipCount: 12, scope: 'all', autoRuleEnabled: false, autoRules: [],
      children: [
        { id: 't2-1', name: '双11备货', parentId: 't2', color: '#1890ff', description: '双十一专项备货装备', isLeaf: true, isEnabled: true, equipCount: 12, scope: 'all', autoRuleEnabled: false, autoRules: [] },
      ]
    },
    {
      id: 't3', name: '品类特征', parentId: null, color: '#52c41a', description: '按品类特征分类', isLeaf: false, isEnabled: true, equipCount: 3, scope: 'all', autoRuleEnabled: false, autoRules: [],
      children: [
        { id: 't3-1', name: '易碎品', parentId: 't3', color: '#faad14', description: '易碎装备标记', isLeaf: true, isEnabled: false, equipCount: 0, scope: 'all', autoRuleEnabled: false, autoRules: [] },
        { id: 't3-2', name: '贵重仪器', parentId: 't3', color: '#722ed1', description: '高价值精密仪器', isLeaf: true, isEnabled: true, equipCount: 3, scope: 'all', autoRuleEnabled: true, autoRules: [{ id: 'r2', field: 'category', operator: 'eq', value: '通信设备' }] },
      ]
    },
  ]
}

const sampleBoundEquips: BoundEquip[] = [
  { id: 'e1', code: '0101P00100', name: '手持终端 XT-2000', spec: 'XT-2000/黑色/128G', location: '省厅主仓库 A区-01-03', source: 'auto' },
  { id: 'e2', code: '0101P00200', name: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G/防水', location: '省厅主仓库 A区-02-01', source: 'manual' },
  { id: 'e3', code: '0101P00300', name: '防弹背心 FDY-3R', spec: 'FDY-3R/三级/均码', location: '省厅主仓库 C区-01-02', source: 'auto' },
  { id: 'e4', code: '0101P00500', name: '对讲机 PD780G', spec: 'PD780G/U段/数字', location: '市局限装备仓库 B区-01-05', source: 'auto' },
  { id: 'e5', code: '0101P00600', name: '应急照明灯 YD-100', spec: 'YD-100/LED/充电', location: '省厅主仓库 A区-03-04', source: 'manual' },
]

/* ================================================================
   Helper Functions
   ================================================================ */
function flattenTags(nodes: TagNode[]): TagNode[] {
  const result: TagNode[] = []
  function walk(list: TagNode[]) {
    for (const n of list) {
      result.push(n)
      if (n.children) walk(n.children)
    }
  }
  walk(nodes)
  return result
}

function findTag(nodes: TagNode[], id: string): TagNode | null {
  for (const n of nodes) {
    if (n.id === id) return n
    if (n.children) {
      const found = findTag(n.children, id)
      if (found) return found
    }
  }
  return null
}

function findParent(nodes: TagNode[], childId: string): TagNode | null {
  for (const n of nodes) {
    if (n.children?.some(c => c.id === childId)) return n
    if (n.children) {
      const found = findParent(n.children, childId)
      if (found) return found
    }
  }
  return null
}

function removeTag(nodes: TagNode[], id: string): TagNode[] {
  return nodes.filter(n => n.id !== id).map(n => ({
    ...n,
    children: n.children ? removeTag(n.children, id) : undefined,
  }))
}

function updateTag(nodes: TagNode[], id: string, updater: (t: TagNode) => TagNode): TagNode[] {
  return nodes.map(n => {
    if (n.id === id) return updater({ ...n })
    if (n.children) return { ...n, children: updateTag(n.children, id, updater) }
    return n
  })
}

function searchTree(nodes: TagNode[], kw: string): { matchedIds: Set<string>; expandIds: Set<string> } {
  const matchedIds = new Set<string>()
  const expandIds = new Set<string>()
  function walk(list: TagNode[], path: string[] = []) {
    for (const n of list) {
      const isMatch = n.name.toLowerCase().includes(kw.toLowerCase())
      if (isMatch) {
        matchedIds.add(n.id)
        path.forEach(p => expandIds.add(p))
      }
      if (n.children) {
        walk(n.children, [...path, n.id])
        if (n.children.some(c => matchedIds.has(c.id))) {
          expandIds.add(n.id)
        }
      }
    }
  }
  walk(nodes)
  return { matchedIds, expandIds }
}

/* ================================================================
   Component
   ================================================================ */
export default function TagManagement() {
  const [tagTree, setTagTree] = useState<TagNode[]>(generateSampleData)
  const [selectedTagId, setSelectedTagId] = useState<string>('t1-1')
  const [searchKw, setSearchKw] = useState('')
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['t1', 't2', 't3']))
  const [draggingId, setDraggingId] = useState<string | null>(null)

  // Modals
  const [tagModalOpen, setTagModalOpen] = useState(false)
  const [tagModalMode, setTagModalMode] = useState<'add-root' | 'add-child' | 'edit'>('add-root')
  const [tagModalParentId, setTagModalParentId] = useState<string | null>(null)
  const [editTagId, setEditTagId] = useState<string | null>(null)
  const [formName, setFormName] = useState('')
  const [formDesc, setFormDesc] = useState('')
  const [formColor, setFormColor] = useState('#1890ff')

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [deleteTagId, setDeleteTagId] = useState<string | null>(null)

  const [boundEquips] = useState<BoundEquip[]>(sampleBoundEquips)
  const [selectedEquipIds, setSelectedEquipIds] = useState<Set<string>>(new Set())
  const [equipPage, setEquipPage] = useState(1)

  const searchRef = useRef<HTMLInputElement>(null)

  // Derived
  const selectedTag = useMemo(() => findTag(tagTree, selectedTagId), [tagTree, selectedTagId])

  const searchResult = useMemo(() => {
    if (!searchKw.trim()) return null
    return searchTree(tagTree, searchKw)
  }, [tagTree, searchKw])

  const effectiveExpanded = useMemo(() => {
    if (searchResult) {
      return new Set([...expandedIds, ...searchResult.expandIds])
    }
    return expandedIds
  }, [expandedIds, searchResult])

  // Handlers
  const toggleExpand = useCallback((id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }, [])

  const openAddRoot = () => {
    setTagModalMode('add-root')
    setTagModalParentId(null)
    setEditTagId(null)
    setFormName('')
    setFormDesc('')
    setFormColor('#1890ff')
    setTagModalOpen(true)
  }

  const openAddChild = (parentId: string) => {
    setTagModalMode('add-child')
    setTagModalParentId(parentId)
    setEditTagId(null)
    setFormName('')
    setFormDesc('')
    setFormColor('#1890ff')
    setTagModalOpen(true)
  }

  const openEdit = (tag: TagNode) => {
    setTagModalMode('edit')
    setEditTagId(tag.id)
    setFormName(tag.name)
    setFormDesc(tag.description)
    setFormColor(tag.color)
    setTagModalOpen(true)
  }

  const confirmDelete = (tag: TagNode) => {
    setDeleteTagId(tag.id)
    setDeleteConfirmOpen(true)
  }

  const executeDelete = () => {
    if (!deleteTagId) return
    const tag = findTag(tagTree, deleteTagId)
    if (!tag) return

    if (tag.children && tag.children.length > 0) {
      // Parent: promote children to root
      const newTree = removeTag(tagTree, deleteTagId)
      const promoted = tag.children.map(c => ({ ...c, parentId: null }))
      setTagTree([...newTree, ...promoted])
    } else {
      // Leaf: just remove
      setTagTree(prev => removeTag(prev, deleteTagId))
    }

    if (selectedTagId === deleteTagId) {
      const remaining = flattenTags(removeTag(tagTree, deleteTagId))
      setSelectedTagId(remaining[0]?.id || '')
    }
    setDeleteConfirmOpen(false)
    setDeleteTagId(null)
  }

  const saveTag = () => {
    if (!formName.trim() || formName.length < 2 || formName.length > 20) {
      alert('标签名称需2-20字')
      return
    }

    if (tagModalMode === 'edit' && editTagId) {
      setTagTree(prev => updateTag(prev, editTagId, t => ({ ...t, name: formName.trim(), description: formDesc.trim(), color: formColor })))
    } else {
      const newTag: TagNode = {
        id: `t-${Date.now()}`,
        name: formName.trim(),
        parentId: tagModalMode === 'add-child' ? tagModalParentId : null,
        color: formColor,
        description: formDesc.trim(),
        isLeaf: tagModalMode === 'add-child' || tagModalMode === 'add-root',
        isEnabled: true,
        equipCount: 0,
        scope: 'all',
        autoRuleEnabled: false,
        autoRules: [],
      }

      if (tagModalMode === 'add-child' && tagModalParentId) {
        setTagTree(prev => updateTag(prev, tagModalParentId, t => ({
          ...t,
          isLeaf: false,
          children: [...(t.children || []), newTag],
        })))
        setExpandedIds(prev => new Set(prev).add(tagModalParentId))
      } else {
        setTagTree(prev => [...prev, newTag])
      }
      setSelectedTagId(newTag.id)
    }
    setTagModalOpen(false)
  }

  const handleDragStart = (id: string) => setDraggingId(id)
  const handleDragEnd = () => setDraggingId(null)

  const handleDropOnNode = (targetId: string) => {
    if (!draggingId || draggingId === targetId) return
    // Prevent cyclic drop
    const dragged = findTag(tagTree, draggingId)
    if (!dragged) return
    if (dragged.children && findTag(dragged.children, targetId)) return

    const newTree = removeTag(tagTree, draggingId)
    const draggedNode = findTag(tagTree, draggingId)
    if (!draggedNode) return

    const updatedNode = { ...draggedNode, parentId: targetId }
    setTagTree(updateTag(newTree, targetId, t => ({
      ...t,
      isLeaf: false,
      children: [...(t.children || []), updatedNode],
    })))
    setExpandedIds(prev => new Set(prev).add(targetId))
    setDraggingId(null)
  }

  const updateAutoRule = (tagId: string, ruleId: string, field: string, value: string) => {
    setTagTree(prev => updateTag(prev, tagId, t => {
      const fieldDef = RULE_FIELDS.find(f => f.value === field)
      const type = fieldDef?.type || 'select'
      return {
        ...t,
        autoRules: t.autoRules.map(r => r.id === ruleId ? { ...r, [field]: value, operator: field === 'field' ? (type === 'number' ? 'lt' : 'eq') : r.operator } : r),
      }
    }))
  }

  const addAutoRule = (tagId: string) => {
    setTagTree(prev => updateTag(prev, tagId, t => ({
      ...t,
      autoRules: [...t.autoRules, { id: `r-${Date.now()}`, field: 'category', operator: 'eq', value: '' }],
    })))
  }

  const removeAutoRule = (tagId: string, ruleId: string) => {
    setTagTree(prev => updateTag(prev, tagId, t => ({
      ...t,
      autoRules: t.autoRules.filter(r => r.id !== ruleId),
    })))
  }

  const toggleAutoRule = (tagId: string) => {
    setTagTree(prev => updateTag(prev, tagId, t => ({
      ...t,
      autoRuleEnabled: !t.autoRuleEnabled,
    })))
  }

  // Tree renderer
  const renderTree = (nodes: TagNode[], depth = 0) => {
    return nodes.map(node => {
      const isExpanded = effectiveExpanded.has(node.id)
      const isSelected = selectedTagId === node.id
      const isDragging = draggingId === node.id
      const hasChildren = node.children && node.children.length > 0
      const isSearchMatch = searchResult?.matchedIds.has(node.id)

      return (
        <div key={node.id}>
          <div
            className={`group flex items-center gap-1 px-2 py-1.5 text-xs cursor-pointer rounded transition-all select-none
              ${isSelected ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50'}
              ${isDragging ? 'opacity-50' : ''}
              ${isSearchMatch ? 'ring-1 ring-yellow-300 bg-yellow-50' : ''}
            `}
            style={{ paddingLeft: `${depth * 16 + 8}px` }}
            draggable
            onDragStart={() => handleDragStart(node.id)}
            onDragEnd={handleDragEnd}
            onDragOver={e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move' }}
            onDrop={e => { e.preventDefault(); handleDropOnNode(node.id) }}
            onClick={() => setSelectedTagId(node.id)}
          >
            {hasChildren ? (
              <button
                className="w-4 h-4 flex items-center justify-center flex-shrink-0"
                onClick={e => { e.stopPropagation(); toggleExpand(node.id) }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
                  <polyline points="9 18 15 12 9 6"/>
                </svg>
              </button>
            ) : (
              <span className="w-4 flex-shrink-0 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full" style={{ background: node.color }} />
              </span>
            )}

            {hasChildren && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={node.color} strokeWidth="2" className="flex-shrink-0"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>}

            <span className="truncate flex-1">{node.name}</span>
            <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>({node.equipCount})</span>

            {/* Hover actions */}
            <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
              {hasChildren && (
                <button
                  className="w-5 h-5 rounded flex items-center justify-center hover:bg-blue-100"
                  title="新建子标签"
                  onClick={e => { e.stopPropagation(); openAddChild(node.id) }}
                >
                  <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                </button>
              )}
              <button
                className="w-5 h-5 rounded flex items-center justify-center hover:bg-gray-200"
                title="编辑"
                onClick={e => { e.stopPropagation(); openEdit(node) }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              </button>
              <button
                className="w-5 h-5 rounded flex items-center justify-center hover:bg-red-100"
                title="删除"
                onClick={e => { e.stopPropagation(); confirmDelete(node) }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              </button>
            </div>
          </div>
          {hasChildren && isExpanded && (
            <div>{renderTree(node.children!, depth + 1)}</div>
          )}
        </div>
      )
    })
  }

  const pageSize = 5
  const totalPages = Math.ceil(boundEquips.length / pageSize)
  const pagedEquips = boundEquips.slice((equipPage - 1) * pageSize, equipPage * pageSize)

  return (
    <div className="h-full flex">
      {/* ===== Left: Tag Tree ===== */}
      <aside className="w-60 border-r flex-shrink-0 flex flex-col" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
        {/* Header */}
        <div className="p-3 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
          <span className="text-sm font-medium">标签树</span>
          <button className="btn-primary text-xs px-2 py-1 flex items-center gap-1" onClick={openAddRoot}>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            新建根标签
          </button>
        </div>

        {/* Search */}
        <div className="p-2">
          <div className="relative">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#bfbfbf" strokeWidth="2" className="absolute left-2 top-1/2 -translate-y-1/2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input
              ref={searchRef}
              className="form-input w-full text-xs pl-7"
              placeholder="搜索标签..."
              value={searchKw}
              onChange={e => setSearchKw(e.target.value)}
            />
          </div>
        </div>

        {/* Tree */}
        <div className="flex-1 overflow-y-auto p-2">
          {tagTree.length === 0 && (
            <div className="text-center py-8">
              <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>暂无标签</p>
              <button className="text-xs mt-2" style={{ color: 'var(--primary-blue)' }} onClick={openAddRoot}>新建根标签</button>
            </div>
          )}
          {renderTree(tagTree)}
          {searchKw.trim() && tagTree.length > 0 && flattenTags(tagTree).every(t => !searchResult?.matchedIds.has(t.id)) && (
            <div className="text-center py-4 text-xs" style={{ color: 'var(--text-disabled)' }}>未找到标签</div>
          )}
        </div>
      </aside>

      {/* ===== Right: Tag Detail ===== */}
      <main className="flex-1 overflow-y-auto p-5">
        {selectedTag ? (
          <div className="max-w-3xl">
            {/* Breadcrumb */}
            <div className="flex items-center gap-2 text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>
              <span>装备管理</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
              <span>标签管理</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg>
              <span className="font-medium" style={{ color: 'var(--text-primary)' }}>{selectedTag.name}</span>
            </div>

            {/* Basic Info */}
            <div className="content-card p-4 mb-4">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <span className="w-1 h-4 rounded-full" style={{ background: selectedTag.color }} />
                基础信息
              </h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>标签名称</label>
                  <div className="form-input bg-gray-50 text-sm">{selectedTag.name}</div>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>父标签</label>
                  <div className="form-input bg-gray-50 text-sm">
                    {selectedTag.parentId ? findTag(tagTree, selectedTag.parentId)?.name || '-' : '(根标签)'}
                  </div>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>颜色标记</label>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full border" style={{ background: selectedTag.color, borderColor: '#d9d9d9' }} />
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                      {PRESET_COLORS.find(c => c.value === selectedTag.color)?.label || '自定义'}
                    </span>
                  </div>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                  <span className={`tag text-xs ${selectedTag.isEnabled ? 'tag-green' : 'tag-gray'}`}>
                    {selectedTag.isEnabled ? '启用' : '禁用'}
                  </span>
                </div>
                <div className="col-span-2">
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>描述</label>
                  <div className="form-input bg-gray-50 text-sm min-h-[60px]" style={{ whiteSpace: 'pre-wrap' }}>
                    {selectedTag.description || '-'}
                  </div>
                </div>
              </div>
            </div>

            {/* Scope */}
            <div className="content-card p-4 mb-4">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <span className="w-1 h-4 rounded-full bg-green-500" />
                适用范围
              </h4>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="radio" checked={selectedTag.scope === 'all'} readOnly className="accent-blue-500" />
                  <span>全仓库通用</span>
                </label>
                <label className="flex items-center gap-2 text-sm cursor-pointer">
                  <input type="radio" checked={selectedTag.scope === 'specific'} readOnly className="accent-blue-500" />
                  <span>指定仓库/货区</span>
                </label>
              </div>
            </div>

            {/* Auto Rule - only for leaf tags */}
            {selectedTag.isLeaf && (
              <div className="content-card p-4 mb-4">
                <h4 className="font-semibold mb-3 flex items-center gap-2">
                  <span className="w-1 h-4 rounded-full bg-purple-500" />
                  自动打标规则
                </h4>
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-sm">{selectedTag.autoRuleEnabled ? '已开启' : '已关闭'}</span>
                  <button
                    className={`relative w-10 h-5 rounded-full transition-colors ${selectedTag.autoRuleEnabled ? 'bg-blue-500' : 'bg-gray-300'}`}
                    onClick={() => toggleAutoRule(selectedTag.id)}
                  >
                    <span className={`absolute top-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${selectedTag.autoRuleEnabled ? 'translate-x-5' : 'translate-x-0.5'}`} />
                  </button>
                </div>

                {selectedTag.autoRuleEnabled && (
                  <div className="space-y-2">
                    {selectedTag.autoRules.map((rule, idx) => {
                      const fieldDef = RULE_FIELDS.find(f => f.value === rule.field)
                      const ops = OPERATORS[fieldDef?.type || 'select']
                      return (
                        <div key={rule.id} className="flex items-center gap-2 p-2 rounded border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>条件{idx + 1}</span>
                          <select
                            className="form-input text-xs w-28"
                            value={rule.field}
                            onChange={e => updateAutoRule(selectedTag.id, rule.id, 'field', e.target.value)}
                          >
                            {RULE_FIELDS.map(f => <option key={f.value} value={f.value}>{f.label}</option>)}
                          </select>
                          <select
                            className="form-input text-xs w-24"
                            value={rule.operator}
                            onChange={e => updateAutoRule(selectedTag.id, rule.id, 'operator', e.target.value)}
                          >
                            {ops.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                          </select>
                          {fieldDef?.type === 'select' ? (
                            <select
                              className="form-input text-xs flex-1"
                              value={rule.value}
                              onChange={e => updateAutoRule(selectedTag.id, rule.id, 'value', e.target.value)}
                            >
                              <option value="">请选择</option>
                              {fieldDef.options?.map(o => <option key={o} value={o}>{o}</option>)}
                            </select>
                          ) : fieldDef?.type === 'number' ? (
                            <input
                              type="number"
                              className="form-input text-xs flex-1"
                              placeholder="输入数值"
                              value={rule.value}
                              onChange={e => updateAutoRule(selectedTag.id, rule.id, 'value', e.target.value)}
                            />
                          ) : (
                            <input
                              type="date"
                              className="form-input text-xs flex-1"
                              value={rule.value}
                              onChange={e => updateAutoRule(selectedTag.id, rule.id, 'value', e.target.value)}
                            />
                          )}
                          <button
                            className="p-1 rounded hover:bg-red-50"
                            onClick={() => removeAutoRule(selectedTag.id, rule.id)}
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          </button>
                        </div>
                      )
                    })}
                    <button
                      className="btn-default text-xs px-2 py-1 mt-1"
                      onClick={() => addAutoRule(selectedTag.id)}
                    >
                      + 添加条件
                    </button>
                    <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>多个条件之间为"且"关系（AND）</p>
                  </div>
                )}
              </div>
            )}

            {/* Bound Equipment - only for leaf tags */}
            {selectedTag.isLeaf && (
              <div className="content-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold flex items-center gap-2">
                    <span className="w-1 h-4 rounded-full bg-orange-500" />
                    已绑定装备
                    <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>({boundEquips.length}件)</span>
                  </h4>
                  {selectedEquipIds.size > 0 && (
                    <button
                      className="btn-danger text-xs px-2 py-1"
                      onClick={() => { setSelectedEquipIds(new Set()); alert(`已移除 ${selectedEquipIds.size} 件装备的标签关联`) }}
                    >
                      批量移除 ({selectedEquipIds.size})
                    </button>
                  )}
                </div>

                <table className="data-table">
                  <thead>
                    <tr>
                      <th className="w-8"><input type="checkbox" checked={selectedEquipIds.size === boundEquips.length && boundEquips.length > 0} onChange={e => setSelectedEquipIds(e.target.checked ? new Set(boundEquips.map(eq => eq.id)) : new Set())} /></th>
                      <th>装备编号</th>
                      <th>装备名称</th>
                      <th>规格型号</th>
                      <th>存放位置</th>
                      <th>标签来源</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagedEquips.map(eq => (
                      <tr key={eq.id}>
                        <td><input type="checkbox" checked={selectedEquipIds.has(eq.id)} onChange={e => {
                          const next = new Set(selectedEquipIds)
                          if (e.target.checked) next.add(eq.id)
                          else next.delete(eq.id)
                          setSelectedEquipIds(next)
                        }} /></td>
                        <td className="font-mono text-xs">{eq.code}</td>
                        <td className="text-xs">{eq.name}</td>
                        <td className="text-xs" style={{ color: 'var(--text-secondary)' }}>{eq.spec}</td>
                        <td className="text-xs">{eq.location}</td>
                        <td>
                          <span className={`tag text-xs ${eq.source === 'auto' ? 'tag-blue' : 'tag-green'}`}>
                            {eq.source === 'auto' ? '自动' : '手动'}
                          </span>
                        </td>
                        <td>
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => alert('已移除装备标签关联')}>
                            移除
                          </button>
                        </td>
                      </tr>
                    ))}
                    {boundEquips.length === 0 && (
                      <tr><td colSpan={7} className="text-center py-6 text-xs" style={{ color: 'var(--text-disabled)' }}>暂无绑定装备</td></tr>
                    )}
                  </tbody>
                </table>

                {totalPages > 1 && (
                  <div className="flex items-center justify-end gap-1 mt-3">
                    <button className="px-2 py-1 text-xs rounded border hover:bg-gray-50" disabled={equipPage === 1} onClick={() => setEquipPage(p => p - 1)}>上一页</button>
                    <span className="text-xs px-2">{equipPage} / {totalPages}</span>
                    <button className="px-2 py-1 text-xs rounded border hover:bg-gray-50" disabled={equipPage === totalPages} onClick={() => setEquipPage(p => p + 1)}>下一页</button>
                  </div>
                )}
              </div>
            )}

            {!selectedTag.isLeaf && (
              <div className="content-card p-8 text-center">
                <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>当前选中的是父标签（分组）</p>
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>请选择一个叶子标签查看打标规则和已绑定装备</p>
              </div>
            )}
          </div>
        ) : (
          <div className="flex items-center justify-center h-full">
            <div className="text-center">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3">
                <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82zM7 7h.01"/>
              </svg>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>请从左侧选择一个标签</p>
            </div>
          </div>
        )}
      </main>

      {/* ===== Tag Modal ===== */}
      {tagModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTagModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white rounded-t-xl" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-base font-semibold">
                {tagModalMode === 'add-root' ? '新建根标签' : tagModalMode === 'add-child' ? '新建子标签' : '编辑标签'}
              </h3>
              <button onClick={() => setTagModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5 space-y-4 overflow-y-auto flex-1">
              <div>
                <label className="block text-xs mb-1.5 font-medium">标签名称 <span className="text-red-400">*</span></label>
                <input
                  className="form-input w-full"
                  placeholder="2-20字"
                  value={formName}
                  onChange={e => setFormName(e.target.value)}
                  maxLength={20}
                  autoFocus
                />
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>{formName.length}/20 字</p>
              </div>
              <div>
                <label className="block text-xs mb-1.5 font-medium">颜色标记</label>
                <div className="flex flex-wrap gap-2">
                  {PRESET_COLORS.map(c => (
                    <button
                      key={c.value}
                      className={`w-7 h-7 rounded-full border-2 transition-all ${formColor === c.value ? 'border-gray-800 scale-110' : 'border-transparent hover:scale-105'}`}
                      style={{ background: c.value }}
                      title={c.label}
                      onClick={() => setFormColor(c.value)}
                    />
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-xs mb-1.5 font-medium">描述</label>
                <textarea
                  className="form-input w-full text-sm"
                  rows={3}
                  placeholder="请输入标签描述（可选）"
                  value={formDesc}
                  onChange={e => setFormDesc(e.target.value)}
                />
              </div>
            </div>
            <div className="sticky bottom-0 flex justify-end gap-2 px-5 py-4 border-t bg-white rounded-b-xl" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setTagModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={saveTag}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Delete Confirm Modal ===== */}
      {deleteConfirmOpen && deleteTagId && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[400px] p-5 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full bg-red-50 flex items-center justify-center flex-shrink-0">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              </div>
              <div>
                <h3 className="font-semibold">确认删除</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>
                  {(() => {
                    const tag = findTag(tagTree, deleteTagId)
                    if (!tag) return ''
                    if (tag.children && tag.children.length > 0) {
                      return `该分组下有 ${tag.children.length} 个子标签，删除后子标签将提升为根标签`
                    }
                    return '该标签将从所有关联装备上移除，此操作不可恢复'
                  })()}
                </p>
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <button className="btn-default" onClick={() => setDeleteConfirmOpen(false)}>取消</button>
              <button className="btn-danger" onClick={executeDelete}>确认删除</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
