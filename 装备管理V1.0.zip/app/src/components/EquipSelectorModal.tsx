import { useState, useMemo } from 'react'

interface StockEquip {
  id: string
  name: string
  category: string
  spec: string
  equipCode: string
  rfidCode: string
  qty: number
}

interface Props {
  open: boolean
  onClose: () => void
  onConfirm: (selected: StockEquip[]) => void
}

const stockEquips: StockEquip[] = [
  { id: 's1', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/128G/黑色', equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', qty: 50 },
  { id: 's2', name: '执法记录仪 DSJ-A7', category: '通信装备', spec: 'DSJ-A7/64G/防水', equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', qty: 30 },
  { id: 's3', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级/均码', equipCode: '0101P00300', rfidCode: '10101P0030012024021010004XXXXXX0004', qty: 25 },
  { id: 's4', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号/轻量化', equipCode: '0101P00400', rfidCode: '10101P0040012024031505005XXXXXX0005', qty: 20 },
  { id: 's5', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段/数字', equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', qty: 40 },
  { id: 's6', name: '应急照明灯 YD-100', category: '应急装备', spec: 'YD-100/LED/充电', equipCode: '0101P00600', rfidCode: '10101P0060012024031005006XXXXXX0006', qty: 60 },
  { id: 's7', name: '防弹盾牌 FDP-3S', category: '防护装备', spec: 'FDP-3S/铝合金/手持', equipCode: '0101P00700', rfidCode: '10101P0070012024031005007XXXXXX0007', qty: 15 },
  { id: 's8', name: '催泪喷射器 CL-200', category: '执法装备', spec: 'CL-200/200ml/喷射', equipCode: '0101P00800', rfidCode: '10101P0080012024031005008XXXXXX0008', qty: 100 },
  { id: 's9', name: '强光手电 QG-500', category: '个人装备', spec: 'QG-500/充电款/防水', equipCode: '0101P00900', rfidCode: '10101P0090012024031005009XXXXXX0009', qty: 45 },
  { id: 's10', name: '急救包 JJB-A', category: '急救装备', spec: 'JJB-A/综合型/标准', equipCode: '0101P01000', rfidCode: '10101P0100012024031005010XXXXXX0010', qty: 30 },
  { id: 's11', name: '防刺手套 FC-02', category: '个人装备', spec: 'FC-02/凯夫拉/防割', equipCode: '0101P01100', rfidCode: '10101P0110012024031005011XXXXXX0011', qty: 55 },
  { id: 's12', name: '手铐 SK-01', category: '执法装备', spec: 'SK-01/不锈钢/双保险', equipCode: '0101P01200', rfidCode: '10101P0120012024031005012XXXXXX0012', qty: 80 },
]

const categoryOptions = ['全部', '通信装备', '防护装备', '应急装备', '执法装备', '个人装备', '急救装备']

export default function EquipSelectorModal({ open, onClose, onConfirm }: Props) {
  const [searchKw, setSearchKw] = useState('')
  const [filterCat, setFilterCat] = useState('全部')
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  const filtered = useMemo(() => {
    return stockEquips.filter(e => {
      const matchKw = !searchKw || e.name.includes(searchKw) || e.equipCode.includes(searchKw)
      const matchCat = filterCat === '全部' || e.category === filterCat
      return matchKw && matchCat
    })
  }, [searchKw, filterCat])

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleConfirm = () => {
    const selected = stockEquips.filter(e => selectedIds.has(e.id))
    onConfirm(selected)
    setSelectedIds(new Set())
    setSearchKw('')
    setFilterCat('全部')
  }

  const handleClose = () => {
    setSelectedIds(new Set())
    setSearchKw('')
    setFilterCat('全部')
    onClose()
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative bg-white rounded-xl shadow-2xl w-[800px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200" style={{ maxWidth: '95vw' }}>
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white rounded-t-xl" style={{ borderColor: 'var(--border-color)' }}>
          <h3 className="text-base font-semibold">选择库存装备</h3>
          <button onClick={handleClose} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>

        {/* Search & Filter */}
        <div className="px-5 py-3 border-b flex items-center gap-3" style={{ borderColor: 'var(--border-color)' }}>
          <div className="relative flex-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#bfbfbf" strokeWidth="2" className="absolute left-2 top-1/2 -translate-y-1/2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <input className="form-input w-full text-sm pl-7" placeholder="搜索装备名称或编码..." value={searchKw} onChange={e => setSearchKw(e.target.value)} />
          </div>
          <select className="form-input text-sm w-32" value={filterCat} onChange={e => setFilterCat(e.target.value)}>
            {categoryOptions.map(c => <option key={c}>{c}</option>)}
          </select>
          <span className="text-xs px-2 py-1 rounded-full" style={{ background: '#e6f7ff', color: '#1890ff' }}>
            已选 {selectedIds.size} 件
          </span>
        </div>

        {/* Equipment List */}
        <div className="flex-1 overflow-y-auto p-4">
          <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
            <thead>
              <tr style={{ background: 'var(--table-header-bg)' }}>
                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>
                  <input type="checkbox" checked={selectedIds.size === filtered.length && filtered.length > 0} onChange={e => setSelectedIds(e.target.checked ? new Set(filtered.map(f => f.id)) : new Set())} />
                </th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>编码</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>类别</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>库存</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => (
                <tr key={e.id} className={`cursor-pointer transition-colors hover:bg-blue-50 ${selectedIds.has(e.id) ? 'bg-blue-50' : ''}`} onClick={() => toggleSelect(e.id)}>
                  <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>
                    <input type="checkbox" checked={selectedIds.has(e.id)} onChange={() => toggleSelect(e.id)} onClick={e => e.stopPropagation()} />
                  </td>
                  <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{e.name}</td>
                  <td className="border p-2 font-mono" style={{ borderColor: 'var(--border-color)' }}>{e.equipCode}</td>
                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category}</td>
                  <td className="border p-2" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>{e.spec}</td>
                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{e.qty}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={6} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>未找到匹配装备</td></tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 flex justify-end gap-2 px-5 py-4 border-t bg-white rounded-b-xl" style={{ borderColor: 'var(--border-color)' }}>
          <button className="btn-default" onClick={handleClose}>取消</button>
          <button className="btn-primary" disabled={selectedIds.size === 0} onClick={handleConfirm}>
            确定添加 ({selectedIds.size})
          </button>
        </div>
      </div>
    </div>
  )
}
