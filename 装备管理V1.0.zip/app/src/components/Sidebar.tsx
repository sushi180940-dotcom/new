export interface SubMenuItem {
  key: string
  label: string
  icon: string
  children?: { key: string; label: string }[]
}

interface SidebarProps {
  activeTopNav: string
  activeModule: string
  activeSubTab: string
  onNavigate: (module: string, subTab?: string) => void
  collapsed: boolean
  onToggleCollapse: () => void
}

export default function Sidebar(_props: SidebarProps) {
  return null
}
