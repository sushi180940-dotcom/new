import { useState } from 'react'

interface Props {
  tags: string[]
  maxShow?: number
  size?: 'sm' | 'md'
}

const tagColorMap: Record<string, { bg: string; text: string }> = {
  '状态类/临期30天': { bg: '#fff7e6', text: '#fa8f14' },
  '状态类/报废待定': { bg: '#fff2f0', text: '#ff4d4f' },
  '活动类/双11备货': { bg: '#e6f7ff', text: '#1890ff' },
  '品类特征/易碎品': { bg: '#f6ffed', text: '#52c41a' },
  '品类特征/贵重仪器': { bg: '#f9f0ff', text: '#722ed1' },
}

function getTagColor(tag: string) {
  if (tagColorMap[tag]) return tagColorMap[tag]
  // Hash to consistent color
  let hash = 0
  for (let i = 0; i < tag.length; i++) hash = tag.charCodeAt(i) + ((hash << 5) - hash)
  const colors = [
    { bg: '#e6f7ff', text: '#1890ff' },
    { bg: '#f6ffed', text: '#52c41a' },
    { bg: '#fff7e6', text: '#fa8f14' },
    { bg: '#fff2f0', text: '#ff4d4f' },
    { bg: '#f9f0ff', text: '#722ed1' },
    { bg: '#f0f5ff', text: '#2f54eb' },
  ]
  return colors[Math.abs(hash) % colors.length]
}

export default function TagBadges({ tags, maxShow = 3, size = 'sm' }: Props) {
  const [hoverIdx, setHoverIdx] = useState<number | null>(null)
  if (!tags || tags.length === 0) return <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>

  const show = tags.slice(0, maxShow)
  const extra = tags.length - maxShow

  return (
    <div className="flex flex-wrap gap-1">
      {show.map((tag, i) => {
        const c = getTagColor(tag)
        return (
          <span
            key={i}
            className={`inline-flex items-center rounded-full cursor-default transition-all ${size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-0.5'}`}
            style={{ background: c.bg, color: c.text }}
            title={tag}
            onMouseEnter={() => setHoverIdx(i)}
            onMouseLeave={() => setHoverIdx(null)}
          >
            {size === 'sm' && tag.length > 8 ? tag.slice(0, 8) + '...' : tag}
          </span>
        )
      })}
      {extra > 0 && (
        <span
          className={`inline-flex items-center rounded-full text-xs px-1.5 py-0.5 cursor-pointer hover:bg-gray-200`}
          style={{ background: '#f5f5f5', color: 'var(--text-secondary)' }}
          title={tags.slice(maxShow).join('\n')}
        >
          +{extra}
        </span>
      )}
    </div>
  )
}

// RFID display with tooltip
export function RfidDisplay({ rfid, showFull = false }: { rfid: string; showFull?: boolean }) {
  const [copied, setCopied] = useState(false)
  if (!rfid) return <span style={{ color: 'var(--text-disabled)' }}>-</span>

  if (showFull) {
    return (
      <div className="flex items-center gap-2">
        <span className="font-mono text-xs break-all" style={{ color: 'var(--text-secondary)' }}>{rfid}</span>
        <button
          className="text-xs px-2 py-0.5 rounded border hover:bg-gray-50 flex-shrink-0"
          style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}
          onClick={() => { navigator.clipboard?.writeText(rfid); setCopied(true); setTimeout(() => setCopied(false), 1500) }}
        >
          {copied ? '已复制' : '复制'}
        </button>
      </div>
    )
  }

  return (
    <span className="font-mono text-xs cursor-help" title={rfid} style={{ color: 'var(--text-secondary)' }}>
      {rfid.slice(0, 8)}...{rfid.slice(-4)}
    </span>
  )
}
