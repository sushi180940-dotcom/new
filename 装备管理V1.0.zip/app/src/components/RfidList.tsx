import { useState } from 'react'
import { RfidDisplay } from './TagBadges'

interface Props {
  rfids: string[]
  selectedRfid?: string
  onSelect?: (rfid: string) => void
  showSelect?: boolean
}

export default function RfidList({ rfids, selectedRfid, onSelect, showSelect = true }: Props) {
  const [expanded, setExpanded] = useState(true)
  if (!rfids || rfids.length === 0) return null

  return (
    <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
      <button
        className="w-full flex items-center justify-between px-3 py-2 text-xs font-medium"
        style={{ background: '#fafafa' }}
        onClick={() => setExpanded(!expanded)}
      >
        <span className="flex items-center gap-2">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2">
            <rect x="4" y="4" width="16" height="16" rx="2"/><path d="M4 9h16M9 4v16"/>
          </svg>
          RFID编码列表
          <span className="text-[10px] px-1.5 py-0.5 rounded-full" style={{ background: '#e6f7ff', color: '#1890ff' }}>
            {rfids.length} 件
          </span>
        </span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: expanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.15s' }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
      {expanded && (
        <div className="max-h-[200px] overflow-y-auto">
          <table className="w-full">
            <thead>
              <tr style={{ background: '#fafafa' }}>
                {showSelect && <th className="text-left text-[10px] px-3 py-1.5 w-8">选择</th>}
                <th className="text-left text-[10px] px-3 py-1.5">序号</th>
                <th className="text-left text-[10px] px-3 py-1.5">RFID编码</th>
              </tr>
            </thead>
            <tbody>
              {rfids.map((rfid, idx) => (
                <tr
                  key={rfid}
                  className={`border-t cursor-pointer transition-colors hover:bg-blue-50 ${selectedRfid === rfid ? 'bg-blue-50' : ''}`}
                  style={{ borderColor: 'var(--border-color)' }}
                  onClick={() => onSelect?.(rfid)}
                >
                  {showSelect && (
                    <td className="px-3 py-1.5">
                      <input
                        type="radio"
                        checked={selectedRfid === rfid}
                        onChange={() => onSelect?.(rfid)}
                        className="accent-blue-500"
                      />
                    </td>
                  )}
                  <td className="px-3 py-1.5 text-xs font-mono">{idx + 1}</td>
                  <td className="px-3 py-1.5"><RfidDisplay rfid={rfid} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
