import { useState, useRef, useEffect } from 'react'

export interface TopNavItem {
  key: string
  label: string
  topNav?: boolean
}

interface TopBarProps {
  activeTopNav: string
  activeModule?: string
  onTopNavChange: (key: string) => void
  onNavigate?: (module: string, subTab?: string) => void
}

// All top nav items in order
const topNavItems: TopNavItem[] = [
  { key: 'home', label: '首页' },
  { key: 'procurement', label: '采购及售后管理' },
  // 供应商管理通过采购及售后页面内路由跳转，不在顶部导航显示
  // { key: 'supplier', label: '供应商管理' },
  { key: 'dashboard', label: '所队装备管理' },
  { key: 'emergency', label: '应急物资管理' },
  { key: 'equip-standard', label: '配备核定管理' },
  { key: 'command', label: '指挥决策管理' },
  { key: 'supervision', label: '装备监督管理' },
  { key: 'analysis', label: '装备研判分析' },
  { key: 'training', label: '应用技能培训' },
  { key: 'system', label: '系统管理' },
]

export default function TopBar({ activeTopNav, activeModule, onTopNavChange, onNavigate }: TopBarProps) {
  const [notifOpen, setNotifOpen] = useState(false)
  const [userOpen, setUserOpen] = useState(false)
  const notifRef = useRef<HTMLDivElement>(null)
  const userRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false)
      if (userRef.current && !userRef.current.contains(e.target as Node)) setUserOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const notifications = [
    { id: 1, title: 'A-103仓库温度异常', desc: '温度32°C超过阈值30°C', time: '10:23', read: false, type: 'warning' },
    { id: 2, title: '采购申请 CG2024001 待审批', desc: '张三提交的采购申请需审批', time: '09:45', read: false, type: 'info' },
    { id: 3, title: '装备编码审批 BM2024001', desc: '100件手持终端编码待生成', time: '09:30', read: true, type: 'info' },
    { id: 4, title: '库存预警：手持终端', desc: '当前库存15件，低于安全库存25件', time: '08:15', read: true, type: 'warning' },
    { id: 5, title: '系统升级通知', desc: '系统将于今晚23:00进行升级维护', time: '昨天', read: true, type: 'info' },
  ]

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <header className="flex items-center justify-between h-14 px-4 flex-shrink-0 relative z-50" style={{ background: 'var(--topbar-bg)' }}>
      {/* Left: Logo + Top Nav */}
      <div className="flex items-center gap-1 h-full">
        {/* Logo */}
        <button
          onClick={() => onTopNavChange('home')}
          className="flex items-center gap-2 mr-4 pr-4 border-r border-white/10 h-full cursor-pointer hover:opacity-80 transition-opacity"
        >
          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: 'var(--primary-blue)' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/>
            </svg>
          </div>
          <span className="text-white font-semibold text-sm whitespace-nowrap hidden lg:inline">装备物资系统</span>
        </button>
        {/* Top Nav Items */}
        {topNavItems.map(item => (
          <button
            key={item.key}
            onClick={() => {
              // Special handling: dashboard topNav navigates to equipment-workbench module
              if (item.key === 'dashboard') {
                onNavigate?.('equipment-workbench')
              } else if (item.key === 'emergency') {
                onNavigate?.('emergency')
              } else {
                onNavigate?.(item.key)
              }
            }}
            className={`relative h-full px-3 text-sm font-medium transition-all duration-200 border-b-2 whitespace-nowrap ${
              (activeModule === item.key || (item.key === 'dashboard' && activeModule === 'equipment-workbench') || (item.key === 'emergency' && activeModule === 'emergency'))
                ? 'text-white border-blue-400'
                : 'text-white/60 border-transparent hover:text-white hover:bg-white/5'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1">
        {/* Notification */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative p-2 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/>
            </svg>
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 rounded-full text-xs flex items-center justify-center font-bold" style={{ background: 'var(--error)', color: '#fff', fontSize: '10px' }}>
                {unreadCount}
              </span>
            )}
          </button>
          {notifOpen && (
            <div className="absolute right-0 top-full mt-2 w-80 rounded-lg shadow-xl border overflow-hidden" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="font-semibold text-sm">消息通知</span>
                <span className="text-xs cursor-pointer" style={{ color: 'var(--primary-blue)' }}>全部已读</span>
              </div>
              <div className="max-h-80 overflow-y-auto">
                {notifications.map(n => (
                  <div key={n.id} className={`px-4 py-3 border-b cursor-pointer hover:bg-blue-50 transition-colors ${!n.read ? 'bg-blue-50/50' : ''}`} style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-start gap-2">
                      {!n.read && <span className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: 'var(--primary-blue)' }} />}
                      {n.read && <span className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0" style={{ background: '#d9d9d9' }} />}
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate" style={{ color: 'var(--text-primary)' }}>{n.title}</p>
                        <p className="text-xs mt-0.5 truncate" style={{ color: 'var(--text-secondary)' }}>{n.desc}</p>
                        <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>{n.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2 text-center border-t cursor-pointer hover:bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-xs" style={{ color: 'var(--primary-blue)' }}>查看全部消息</span>
              </div>
            </div>
          )}
        </div>

        {/* User */}
        <div className="relative" ref={userRef}>
          <button
            onClick={() => setUserOpen(!userOpen)}
            className="flex items-center gap-2 px-2 py-1.5 text-white/70 hover:text-white hover:bg-white/10 rounded-lg transition-all"
          >
            <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold" style={{ background: 'var(--primary-blue)' }}>
              管
            </div>
            <span className="text-sm">管理员</span>
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${userOpen ? 'rotate-180' : ''}`}>
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </button>
          {userOpen && (
            <div className="absolute right-0 top-full mt-2 w-48 rounded-lg shadow-xl border overflow-hidden" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
              <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <p className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>系统管理员</p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>admin@system.com</p>
              </div>
              <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-50 transition-colors flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                个人中心
              </button>
              <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-gray-50 transition-colors flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
                系统设置
              </button>
              <div className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-red-50 transition-colors flex items-center gap-2" style={{ color: 'var(--error)' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
                  退出登录
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
