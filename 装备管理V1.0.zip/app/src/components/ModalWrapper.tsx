import type { ReactNode } from 'react'

type ModalSize = 'large' | 'medium' | 'small'

interface Props {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  size?: ModalSize
  footer?: ReactNode
}

const sizeMap: Record<ModalSize, string> = {
  large: 'w-[95vw] max-w-[1100px] max-h-[92vh]',
  medium: 'w-[680px] max-h-[85vh]',
  small: 'w-[480px]',
}

export default function ModalWrapper({ open, onClose, title, children, size = 'medium', footer }: Props) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className={`relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200 ${sizeMap[size]}`}>
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white rounded-t-xl" style={{ borderColor: 'var(--border-color)' }}>
          <h3 className="text-base font-semibold">{title}</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5">
          {children}
        </div>
        {/* Footer */}
        {footer && (
          <div className="sticky bottom-0 flex justify-end gap-2 px-5 py-4 border-t bg-white rounded-b-xl" style={{ borderColor: 'var(--border-color)' }}>
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}
