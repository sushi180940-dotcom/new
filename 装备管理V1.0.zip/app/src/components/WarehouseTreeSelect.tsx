import { useState, useRef, useEffect } from 'react'

interface Warehouse {
  id: string
  name: string
  parent?: string
  entityType: string
  level: string
  children?: Warehouse[]
}

interface Props {
  warehouseData: Warehouse[]
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
  mode?: 'id' | 'name'
  showAll?: boolean
  allLabel?: string
  allValue?: string
}

function findWarehousePathById(nodes: Warehouse[], targetId: string, path: string[] = []): string[] | null {
  for (const n of nodes) {
    if (n.id === targetId) return [...path, n.name]
    if (n.children) {
      const result = findWarehousePathById(n.children, targetId, [...path, n.name])
      if (result) return result
    }
  }
  return null
}

function findWarehousePathByName(nodes: Warehouse[], targetName: string, path: string[] = []): string[] | null {
  for (const n of nodes) {
    if (n.name === targetName) return [...path, n.name]
    if (n.children) {
      const result = findWarehousePathByName(n.children, targetName, [...path, n.name])
      if (result) return result
    }
  }
  return null
}

function getNameById(nodes: Warehouse[], id: string): string {
  for (const w of nodes) {
    if (w.id === id) return w.name
    if (w.children) {
      const child = getNameById(w.children, id)
      if (child) return child
    }
  }
  return id
}

export default function WarehouseTreeSelect({ warehouseData, value, onChange, placeholder = '请选择', className = '', mode = 'id', showAll = false, allLabel = '全部', allValue = '' }: Props) {
  const [open, setOpen] = useState(false)
  const [expanded, setExpanded] = useState<Set<string>>(new Set(warehouseData.map(w => w.id)))
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  const toggleExpand = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const getDisplayValue = () => {
    if (!value) return ''
    if (mode === 'name') return value
    return getNameById(warehouseData, value)
  }

  const getPath = () => {
    if (!value) return null
    return mode === 'name' ? findWarehousePathByName(warehouseData, value) : findWarehousePathById(warehouseData, value)
  }

  const isSelected = (node: Warehouse) => {
    if (mode === 'name') return value === node.name
    return value === node.id
  }

  const handleSelect = (node: Warehouse) => {
    onChange(mode === 'name' ? node.name : node.id)
    setOpen(false)
  }

  const displayValue = getDisplayValue()
  const path = getPath()

  const renderNode = (node: Warehouse, depth = 0) => {
    const isExpanded = expanded.has(node.id)
    const hasChildren = node.children && node.children.length > 0
    const selected = isSelected(node)

    return (
      <div key={node.id}>
        <div
          className={`flex items-center gap-1 px-2 py-1.5 text-xs cursor-pointer transition-colors hover:bg-blue-50 ${selected ? 'bg-blue-50 text-blue-600 font-medium' : ''}`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={() => handleSelect(node)}
        >
          {hasChildren && (
            <button
              className="w-4 h-4 flex items-center justify-center flex-shrink-0"
              onClick={e => { e.stopPropagation(); toggleExpand(node.id) }}
            >
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isExpanded ? 'rotate(90deg)' : 'none', transition: 'transform 0.15s' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          )}
          {!hasChildren && <span className="w-4" />}
          <span className="truncate">{node.name}</span>
          <span className="text-[10px] flex-shrink-0 ml-1" style={{ color: 'var(--text-disabled)' }}>{node.entityType}</span>
        </div>
        {hasChildren && isExpanded && node.children!.map(child => renderNode(child, depth + 1))}
      </div>
    )
  }

  return (
    <div className={`relative ${className}`} ref={ref}>
      <button
        type="button"
        className="form-input w-full text-left text-sm flex items-center justify-between"
        onClick={() => setOpen(!open)}
      >
        <span className={displayValue ? '' : 'text-gray-400'}>
          {displayValue || placeholder}
        </span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>
      {path && path.length > 0 && (
        <span className="text-[10px] mt-0.5 block truncate" style={{ color: 'var(--text-disabled)' }}>
          {path.join(' / ')}
        </span>
      )}
      {open && (
        <div className="absolute z-50 left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-[280px] overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
          {showAll && (
            <div
              className={`flex items-center gap-1 px-2 py-1.5 text-xs cursor-pointer transition-colors hover:bg-blue-50 ${!value || value === allValue ? 'bg-blue-50 text-blue-600 font-medium' : ''}`}
              style={{ paddingLeft: '8px' }}
              onClick={() => { onChange(allValue); setOpen(false) }}
            >
              <span className="w-4" />
              <span>{allLabel}</span>
            </div>
          )}
          {warehouseData.map(node => renderNode(node))}
        </div>
      )}
    </div>
  )
}
