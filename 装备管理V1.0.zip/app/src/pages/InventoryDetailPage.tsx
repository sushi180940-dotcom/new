import { useState } from 'react'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'
import { warehouseData } from '../pages/InboundPage'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type EquipStatus = 'in_stock' | 'in_use' | 'repairing' | 'scrapped'

interface InventoryItem {
  id: string
  equipCode: string
  equipName: string
  spec: string
  room: string
  location: string
  status: EquipStatus
  qty: number
  lastOpTime: string
}

interface LifecycleRecord {
  stage: string
  time: string
  operator: string
  title: string
  detail: string
}

const statusLabels: Record<EquipStatus, { label: string; tag: string }> = {
  in_stock: { label: '在库', tag: 'tag-green' },
  in_use: { label: '领用', tag: 'tag-blue' },
  repairing: { label: '维修', tag: 'tag-yellow' },
  scrapped: { label: '报废', tag: 'tag-red' },
}

const inventoryData: InventoryItem[] = [
  { id: '1', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', spec: 'XT-2000/黑色/128G', room: '省厅主仓库', location: 'A区-01-03', status: 'in_stock', qty: 45, lastOpTime: '2024-03-15 09:30:00' },
  { id: '2', equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G/防水', room: '省厅主仓库', location: 'A区-02-01', status: 'in_use', qty: 8, lastOpTime: '2024-03-14 16:45:00' },
  { id: '3', equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', equipName: '对讲机 PD780G', spec: 'PD780G/U段/数字', room: '市局限装备仓库', location: 'B区-01-05', status: 'in_stock', qty: 38, lastOpTime: '2024-03-14 10:20:00' },
  { id: '4', equipCode: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', spec: 'FDY-3R/三级/均码', room: '省厅主仓库', location: 'C区-01-02', status: 'repairing', qty: 3, lastOpTime: '2024-03-13 08:00:00' },
  { id: '5', equipCode: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', equipName: '战术头盔 MICH-2000', spec: 'MICH-2000/L号/凯夫拉', room: '区县装备室', location: 'D区-01-01', status: 'in_stock', qty: 25, lastOpTime: '2024-03-12 14:10:00' },
  { id: '6', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', spec: 'XT-2000/黑色/128G', room: '市局限装备仓库', location: 'B区-03-02', status: 'scrapped', qty: 2, lastOpTime: '2024-03-10 11:30:00' },
  { id: '7', equipCode: '1-0-1-01-P006-001-20240310-05-006XXXXXX-0001', equipName: '应急照明灯 YD-100', spec: 'YD-100/LED/充电', room: '省厅主仓库', location: 'A区-03-04', status: 'in_stock', qty: 60, lastOpTime: '2024-03-09 15:00:00' },
  { id: '8', equipCode: '1-0-1-01-P007-001-20240220-05-007XXXXXX-0001', equipName: '防弹盾牌 FDP-3S', spec: 'FDP-3S/三级/透明', room: '区县装备室', location: 'D区-02-03', status: 'in_use', qty: 5, lastOpTime: '2024-03-08 09:45:00' },
  { id: '9', equipCode: '1-0-1-01-P008-001-20240125-05-008XXXXXX-0001', equipName: '催泪喷射器 CL-200', spec: 'CL-200/200ml/手持', room: '省厅主仓库', location: 'A区-04-01', status: 'in_stock', qty: 100, lastOpTime: '2024-03-07 16:20:00' },
  { id: '10', equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G/防水', room: '市局限装备仓库', location: 'B区-02-04', status: 'in_stock', qty: 12, lastOpTime: '2024-03-06 11:00:00' },
]

const lifecycleData: Record<string, LifecycleRecord[]> = {
  '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001': [
    { stage: '入库', time: '2024-03-15 09:30', operator: '李四 · 装备仓库', title: '新购入库', detail: '合同编号HT2024001，订单DD2024001，数量50台' },
    { stage: '出库', time: '2024-03-20 10:00', operator: '王五 · 装备仓库', title: '分配至第一支队', detail: '出库单号CK2024001，分配数量10台' },
    { stage: '使用', time: '2024-03-22 08:30', operator: '张三 · 第一支队', title: '日常通信保障', detail: '使用地点：指挥中心' },
    { stage: '维修', time: '2024-05-10 11:20', operator: '赵六 · 维修中心', title: '更换电池', detail: '原电池老化，更换新电池，维修单WX2024001' },
    { stage: '盘点', time: '2024-06-01 09:00', operator: '李四 · 第一支队', title: '季度盘点', detail: '状态正常，数量核对无误' },
    { stage: '使用', time: '2024-06-10 14:20', operator: '张三 · 第一支队', title: '日常通信保障', detail: '使用地点：巡逻区域A' },
  ],
  'default': [
    { stage: '入库', time: '2024-03-10 09:00', operator: '李四 · 装备仓库', title: '采购入库', detail: '新购装备验收合格，正式入库' },
    { stage: '盘点', time: '2024-06-01 09:00', operator: '王五 · 装备仓库', title: '季度盘点', detail: '状态正常，数量核对无误' },
  ],
}

const statusTabs = [
  { key: 'all', label: '全部' },
  { key: 'in_stock', label: '在库' },
  { key: 'in_use', label: '领用' },
  { key: 'repairing', label: '维修' },
  { key: 'scrapped', label: '报废' },
]

export default function InventoryDetailPage({ onNavigate }: Props) {
  const [items, setItems] = useState<InventoryItem[]>(inventoryData)
  const [activeStatusTab, setActiveStatusTab] = useState('all')

  // Modal states
  const [editModalOpen, setEditModalOpen] = useState(false)
  const [scrapModalOpen, setScrapModalOpen] = useState(false)
  const [transferModalOpen, setTransferModalOpen] = useState(false)
  const [damageModalOpen, setDamageModalOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)

  const [activeItem, setActiveItem] = useState<InventoryItem | null>(null)

  // Edit form
  const [formName, setFormName] = useState('')
  const [formSpec, setFormSpec] = useState('')
  const [formRoom, setFormRoom] = useState('')
  const [formLocation, setFormLocation] = useState('')
  const [formStatus, setFormStatus] = useState<EquipStatus>('in_stock')
  const [formQty, setFormQty] = useState(0)

  // Scrap form
  const [scrapReason, setScrapReason] = useState('')
  const [scrapQty, setScrapQty] = useState(1)

  // Transfer form
  const [targetRoom, setTargetRoom] = useState('')
  const [targetLocation, setTargetLocation] = useState('')
  const [transferQty, setTransferQty] = useState(1)
  const [transferReason, setTransferReason] = useState('')

  // Damage form
  const [damageReason, setDamageReason] = useState('')
  const [damageQty, setDamageQty] = useState(1)
  const [damageDesc, setDamageDesc] = useState('')

  const filteredItems = activeStatusTab === 'all' ? items : items.filter(i => i.status === activeStatusTab)

  const resetForms = () => {
    setScrapReason(''); setScrapQty(1)
    setTargetRoom(''); setTargetLocation(''); setTransferQty(1); setTransferReason('')
    setDamageReason(''); setDamageQty(1); setDamageDesc('')
  }

  const openEdit = (item: InventoryItem) => {
    setActiveItem(item)
    setFormName(item.equipName)
    setFormSpec(item.spec)
    setFormRoom(item.room)
    setFormLocation(item.location)
    setFormStatus(item.status)
    setFormQty(item.qty)
    setEditModalOpen(true)
  }

  const handleSaveEdit = () => {
    if (!activeItem) return
    setItems(prev => prev.map(i => i.id === activeItem.id ? {
      ...i, equipName: formName, spec: formSpec, room: formRoom,
      location: formLocation, status: formStatus, qty: formQty,
      lastOpTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    } : i))
    setEditModalOpen(false)
    setActiveItem(null)
    alert('修改成功')
  }

  const openScrap = (item: InventoryItem) => {
    setActiveItem(item)
    setScrapQty(item.qty)
    setScrapModalOpen(true)
  }

  const handleScrap = () => {
    if (!activeItem || !scrapReason) { alert('请填写报废原因'); return }
    setItems(prev => prev.map(i => i.id === activeItem.id ? {
      ...i, status: 'scrapped' as EquipStatus,
      lastOpTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    } : i))
    setScrapModalOpen(false)
    resetForms()
    setActiveItem(null)
    alert('报废操作成功')
  }

  const openTransfer = (item: InventoryItem) => {
    setActiveItem(item)
    setTransferQty(item.qty)
    setTransferModalOpen(true)
  }

  const handleTransfer = () => {
    if (!activeItem || !targetRoom) { alert('请选择目标仓库'); return }
    setItems(prev => prev.map(i => i.id === activeItem.id ? {
      ...i, room: targetRoom, location: targetLocation || i.location,
      lastOpTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    } : i))
    setTransferModalOpen(false)
    resetForms()
    setActiveItem(null)
    alert('调库成功')
  }

  const openDamage = (item: InventoryItem) => {
    setActiveItem(item)
    setDamageQty(item.qty)
    setDamageModalOpen(true)
  }

  const handleDamage = () => {
    if (!activeItem || !damageReason) { alert('请填写报损原因'); return }
    setItems(prev => prev.map(i => i.id === activeItem.id ? {
      ...i, qty: Math.max(0, i.qty - damageQty),
      lastOpTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    } : i))
    setDamageModalOpen(false)
    resetForms()
    setActiveItem(null)
    alert('报损操作成功')
  }

  const handleDelete = (item: InventoryItem) => {
    if (confirm(`确定删除装备 ${item.equipName} 吗？`)) {
      setItems(prev => prev.filter(i => i.id !== item.id))
      alert('删除成功')
    }
  }

  const handleEnable = (item: InventoryItem) => {
    setItems(prev => prev.map(i => i.id === item.id ? {
      ...i, status: 'in_stock' as EquipStatus,
      lastOpTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    } : i))
    alert(`装备 ${item.equipName} 已启用`)
  }

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>台账管理</span>
      </div>

      {/* Search area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-32" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</label><input className="form-input w-48 font-mono text-xs" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>在库</option><option>领用</option><option>维修</option><option>报废</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属库室</label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value="" onChange={() => {}} mode="name" showAll allLabel="全部" className="w-32" /></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-5 gap-4">
        {[
          { label: '在库', value: items.filter(i => i.status === 'in_stock').length, color: '#52c41a' },
          { label: '领用', value: items.filter(i => i.status === 'in_use').length, color: '#1890ff' },
          { label: '维修', value: items.filter(i => i.status === 'repairing').length, color: '#faad14' },
          { label: '报废', value: items.filter(i => i.status === 'scrapped').length, color: '#ff4d4f' },
          { label: '总件数', value: items.length, color: '#722ed1' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 text-center">
            <div className="text-2xl font-bold" style={{ color: card.color }}>{card.value}</div>
            <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
          </div>
        ))}
      </div>

      {/* Status Tabs */}
      <div className="flex items-center gap-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
        {statusTabs.map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveStatusTab(tab.key)}
            className={`px-4 py-2.5 text-sm font-medium transition-all border-b-2 -mb-px ${
              activeStatusTab === tab.key
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent hover:text-gray-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Data table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>装备编码</th><th>装备名称</th><th>规格型号</th><th>所属库室</th><th>库位</th><th>状态</th><th>数量</th><th>最后操作时间</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredItems.map(item => (
              <tr key={item.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs max-w-[160px] truncate" title={item.equipCode}>{item.equipCode}</td>
                <td className="font-medium">{item.equipName}</td>
                <td className="text-xs">{item.spec}</td>
                <td>{item.room}</td>
                <td>{item.location}</td>
                <td><span className={`tag text-xs ${statusLabels[item.status].tag}`}>{statusLabels[item.status].label}</span></td>
                <td className="font-mono text-xs">{item.qty}</td>
                <td className="text-xs">{item.lastOpTime}</td>
                <td>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <button className="text-xs hover:underline" style={{ color: '#1890ff' }} onClick={() => { setActiveItem(item); setDetailOpen(true) }}>查看</button>
                    <button className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => openEdit(item)}>修改</button>
                    {item.status !== 'scrapped' && (
                      <>
                        <button className="text-xs hover:underline" style={{ color: '#722ed1' }} onClick={() => openTransfer(item)}>调库</button>
                        <button className="text-xs hover:underline" style={{ color: '#eb2f96' }} onClick={() => openDamage(item)}>报损</button>
                        <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => openScrap(item)}>报废</button>
                      </>
                    )}
                    {item.status === 'scrapped' && (
                      <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => handleEnable(item)}>启用</button>
                    )}
                    <button className="text-xs hover:underline" style={{ color: '#8c8c8c' }} onClick={() => handleDelete(item)}>删除</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ==================== Detail Modal ==================== */}
      {detailOpen && activeItem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-1/2 h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#722ed1" strokeWidth="2"><path d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                编码溯源详情 - {activeItem.equipCode}
              </h3>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* Basic Info */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm"><span className="w-1 h-4 rounded-full bg-blue-500" />基本档案</h4>
                <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono text-xs font-medium">{activeItem.equipCode}</span></div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>装备名称：</span>{activeItem.equipName}</div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>规格型号：</span>{activeItem.spec}</div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>所属库室：</span>{activeItem.room}</div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>库位：</span>{activeItem.location}</div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>当前状态：</span><span className={`tag text-xs ${activeItem.status === 'in_stock' ? 'tag-green' : activeItem.status === 'in_use' ? 'tag-blue' : activeItem.status === 'repairing' ? 'tag-yellow' : 'tag-red'}`}>{statusLabels[activeItem.status].label}</span></div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>数量：</span>{activeItem.qty}</div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>最后操作：</span>{activeItem.lastOpTime}</div>
                  </div>
                </div>
              </div>

              {/* Lifecycle */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500" />全生命周期记录</span>
                  <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>共 {(lifecycleData[activeItem.equipCode] || lifecycleData['default']).length} 条生命周期记录</span>
                </h4>
                <div className="space-y-3">
                  {(lifecycleData[activeItem.equipCode] || lifecycleData['default']).map((rec, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: '#f0f5ff' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{rec.stage}</span>
                          <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{rec.time}</span>
                        </div>
                        <div className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{rec.operator}</div>
                        <div className="text-sm font-medium mt-1">{rec.title}</div>
                        <div className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{rec.detail}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ==================== Edit Modal ==================== */}
      {editModalOpen && activeItem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEditModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">修改装备信息</h3>
              <button onClick={() => setEditModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Read-only info */}
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{activeItem.equipCode}</span></div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前状态：</span><span className={`tag text-xs ${statusLabels[activeItem.status].tag}`}>{statusLabels[activeItem.status].label}</span></div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" value={formName} onChange={e => setFormName(e.target.value)} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规格型号</label>
                <input className="form-input w-full" value={formSpec} onChange={e => setFormSpec(e.target.value)} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属库室</label>
                  <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={formRoom} onChange={setFormRoom} mode="name" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库位</label>
                  <input className="form-input w-full" value={formLocation} onChange={e => setFormLocation(e.target.value)} placeholder="如A区-01-03" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                  <select className="form-input w-full" value={formStatus} onChange={e => setFormStatus(e.target.value as EquipStatus)}>
                    <option value="in_stock">在库</option>
                    <option value="in_use">领用</option>
                    <option value="repairing">维修</option>
                    <option value="scrapped">报废</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>数量</label>
                  <input className="form-input w-full" type="number" min={0} value={formQty} onChange={e => setFormQty(Number(e.target.value))} />
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-5">
              <button className="btn-default" onClick={() => setEditModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSaveEdit}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== Scrap Modal ==================== */}
      {scrapModalOpen && activeItem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setScrapModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-red-500 flex items-center gap-2">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                报废申请
              </h3>
              <button onClick={() => setScrapModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Equipment info display */}
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#ffccc7', background: '#fff2f0' }}>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{activeItem.equipCode}</span></div>
                <div><span style={{ color: 'var(--text-secondary)' }}>装备名称：</span>{activeItem.equipName}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span>{activeItem.spec}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>所属库室：</span>{activeItem.room} / {activeItem.location}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前库存：</span><span className="font-medium">{activeItem.qty}</span></div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前状态：</span><span className={`tag text-xs ${statusLabels[activeItem.status].tag}`}>{statusLabels[activeItem.status].label}</span></div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废数量 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" type="number" min={1} max={activeItem.qty} value={scrapQty} onChange={e => setScrapQty(Number(e.target.value))} />
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>最大可报废数量：{activeItem.qty}</p>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废原因 <span className="text-red-400">*</span></label>
                <textarea className="form-input w-full text-sm" rows={3} placeholder="请详细说明报废原因..." value={scrapReason} onChange={e => setScrapReason(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-5">
              <button className="btn-default" onClick={() => { setScrapModalOpen(false); resetForms() }}>取消</button>
              <button className="btn-danger" onClick={handleScrap}>确认报废</button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== Transfer Modal (调库) ==================== */}
      {transferModalOpen && activeItem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTransferModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2" style={{ color: '#722ed1' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#722ed1" strokeWidth="2"><path d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4"/></svg>
                调库申请
              </h3>
              <button onClick={() => setTransferModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Current info */}
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#d3adf7', background: '#f9f0ff' }}>
              <div className="text-xs mb-2 font-medium" style={{ color: '#722ed1' }}>当前位置</div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{activeItem.equipCode}</span></div>
                <div><span style={{ color: 'var(--text-secondary)' }}>装备名称：</span>{activeItem.equipName}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span>{activeItem.spec}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前库室：</span>{activeItem.room}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前库位：</span>{activeItem.location}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前库存：</span><span className="font-medium">{activeItem.qty}</span></div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨数量 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" type="number" min={1} max={activeItem.qty} value={transferQty} onChange={e => setTransferQty(Number(e.target.value))} />
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>最大可调拨数量：{activeItem.qty}</p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>目标仓库 <span className="text-red-400">*</span></label>
                  <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={targetRoom} onChange={setTargetRoom} mode="name" placeholder="请选择目标仓库" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>目标库位</label>
                  <input className="form-input w-full" placeholder="如A区-01-03" value={targetLocation} onChange={e => setTargetLocation(e.target.value)} />
                </div>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨原因</label>
                <textarea className="form-input w-full text-sm" rows={2} placeholder="请填写调拨原因..." value={transferReason} onChange={e => setTransferReason(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-5">
              <button className="btn-default" onClick={() => { setTransferModalOpen(false); resetForms() }}>取消</button>
              <button className="btn-primary" onClick={handleTransfer} style={{ background: '#722ed1' }}>确认调库</button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== Damage Modal (报损) ==================== */}
      {damageModalOpen && activeItem && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDamageModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold flex items-center gap-2" style={{ color: '#eb2f96' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#eb2f96" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                报损登记
              </h3>
              <button onClick={() => setDamageModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Equipment info */}
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#ffadd2', background: '#fff0f6' }}>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{activeItem.equipCode}</span></div>
                <div><span style={{ color: 'var(--text-secondary)' }}>装备名称：</span>{activeItem.equipName}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span>{activeItem.spec}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>所属库室：</span>{activeItem.room} / {activeItem.location}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>当前库存：</span><span className="font-medium">{activeItem.qty}</span></div>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报损数量 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" type="number" min={1} max={activeItem.qty} value={damageQty} onChange={e => setDamageQty(Number(e.target.value))} />
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>最大可报损数量：{activeItem.qty}</p>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报损原因 <span className="text-red-400">*</span></label>
                <select className="form-input w-full mb-2" value={damageReason} onChange={e => setDamageReason(e.target.value)}>
                  <option value="">请选择报损原因</option>
                  <option value="natural">自然损耗</option>
                  <option value="accident">意外损坏</option>
                  <option value="expire">过期失效</option>
                  <option value="quality">质量问题</option>
                  <option value="other">其他</option>
                </select>
                {damageReason === 'other' && (
                  <textarea className="form-input w-full text-sm" rows={2} placeholder="请详细说明报损原因..." value={damageDesc} onChange={e => setDamageDesc(e.target.value)} />
                )}
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-5">
              <button className="btn-default" onClick={() => { setDamageModalOpen(false); resetForms() }}>取消</button>
              <button className="btn-danger" onClick={handleDamage} style={{ background: '#eb2f96' }}>确认报损</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
