import { useState } from 'react'
import TagBadges, { RfidDisplay } from '../components/TagBadges'
import RfidList from '../components/RfidList'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

/* ================================================================
   仓库数据（与领用管理一致）
   ================================================================ */
interface Warehouse {
  id: string
  name: string
  parent?: string
  entityType: string
  level: string
  children?: Warehouse[]
}

const warehouseData: Warehouse[] = [
  { id: 'ES001', name: '省厅主仓库', parent: undefined, entityType: '仓库', level: '省级', children: [
    { id: 'ES001-A', name: 'A区-01货架', parent: 'ES001', entityType: '货架', level: '省级' },
    { id: 'ES001-B', name: 'A区-02货架', parent: 'ES001', entityType: '货架', level: '省级' },
    { id: 'ES001-C', name: 'A区-03货架', parent: 'ES001', entityType: '货架', level: '省级' },
  ]},
  { id: 'ES002', name: '市局限装备仓库', parent: undefined, entityType: '仓库', level: '市级', children: [
    { id: 'ES002-A', name: 'B区-01货架', parent: 'ES002', entityType: '货架', level: '市级' },
    { id: 'ES002-B', name: 'B区-02货架', parent: 'ES002', entityType: '货架', level: '市级' },
    { id: 'ES002-C', name: 'B区-03货架', parent: 'ES002', entityType: '货架', level: '市级' },
  ]},
  { id: 'ES003', name: 'A区县级装备库', parent: undefined, entityType: '分区', level: '区县级', children: [
    { id: 'ES003-A', name: 'C区-01货架', parent: 'ES003', entityType: '货架', level: '区县级' },
    { id: 'ES003-B', name: 'C区-02货架', parent: 'ES003', entityType: '货架', level: '区县级' },
  ]},
  { id: 'ES004', name: 'B区县级装备库', parent: undefined, entityType: '分区', level: '区县级', children: [] },
]

function flattenWarehouses(nodes: Warehouse[], depth = 0): { id: string; label: string }[] {
  const result: { id: string; label: string }[] = []
  for (const n of nodes) {
    const indent = '\u00A0\u00A0'.repeat(depth)
    result.push({ id: n.id, label: `${indent}${n.name}` })
    if (n.children) result.push(...flattenWarehouses(n.children, depth + 1))
  }
  return result
}

function getWarehouseName(id: string) {
  for (const w of warehouseData) {
    if (w.id === id) return w.name
    if (w.children) for (const c of w.children) if (c.id === id) return c.name
  }
  return id
}

/* ================================================================
   库存装备数据源（与报修管理、报废管理、领用管理一致）
   ================================================================ */
const stockMaterials = [
  { name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', unit: '台', equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司', qty: 50, produceDate: '2024-01-15', validDate: '2027-01-15', price: 2800, total: 140000, remark: '期初盘点', location: 'ES001-A' },
  { name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', unit: '台', equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', tags: ['状态类/临期30天'], supplier: '烽火通信科技股份有限公司', qty: 30, produceDate: '2024-02-01', validDate: '2027-02-01', price: 1500, total: 45000, remark: '', location: 'ES001-B' },
  { name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', unit: '台', equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', tags: ['活动类/双11备货'], supplier: '海康威视数字技术股份有限公司', qty: 100, produceDate: '2024-02-20', validDate: '2027-02-20', price: 1800, total: 180000, remark: '批量采购', location: 'ES002-A' },
  { name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', unit: '件', equipCode: '0101P00300', rfidCode: '10101P0030012024021010004XXXXXX0004', tags: ['品类特征/易碎品'], supplier: '华为技术有限公司', qty: 20, produceDate: '2024-01-10', validDate: '2029-01-10', price: 3200, total: 64000, remark: '从市局调拨', location: 'ES001-B' },
  { name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', unit: '顶', equipCode: '0101P00400', rfidCode: '10101P0040012024031505005XXXXXX0005', tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司', qty: 15, produceDate: '2024-01-15', validDate: '2028-01-15', price: 2600, total: 39000, remark: '任务结束归还', location: 'ES003-A' },
  { name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', unit: '根', equipCode: '0101P00600', rfidCode: '10101P0060012024031505006XXXXXX0006', tags: ['品类特征/贵重仪器'], supplier: '大华技术股份有限公司', qty: 40, produceDate: '2024-03-01', validDate: '2027-03-01', price: 350, total: 14000, remark: '派出所配发', location: 'ES002-B' },
  { name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', unit: '件', equipCode: '0101P03400', rfidCode: '10101P0340012024090105007XXXXXX0007', tags: ['状态类/临期30天'], supplier: '大华技术股份有限公司', qty: 60, produceDate: '2024-09-01', validDate: '2027-09-01', price: 45, total: 2700, remark: '', location: 'ES003-A' },
  { name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', unit: '辆', equipCode: '0101P04600', rfidCode: '10101P0460012024110105008XXXXXX0008', tags: ['活动类/双11备货'], supplier: '中兴通讯股份有限公司', qty: 5, produceDate: '2024-11-01', validDate: '2027-11-01', price: 28000, total: 140000, remark: '交警中队', location: 'ES003-A' },
  { name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', unit: '面', equipCode: '0101P04700', rfidCode: '10101P0470012024111505009XXXXXX0009', tags: ['品类特征/易碎品'], supplier: '华为技术有限公司', qty: 20, produceDate: '2024-11-15', validDate: '2029-11-15', price: 680, total: 13600, remark: '', location: 'ES001-A' },
  { name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', unit: '台', equipCode: '0101P01600', rfidCode: '10101P0160012024041505010XXXXXX0010', tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '海康威视数字技术股份有限公司', qty: 60, produceDate: '2024-04-15', validDate: '2027-04-15', price: 3500, total: 210000, remark: '指挥中心', location: 'ES001-A' },
  { name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', unit: '根', equipCode: '0101P01000', rfidCode: '10101P0100012024010805011XXXXXX0011', tags: ['品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司', qty: 45, produceDate: '2024-01-08', validDate: '2029-01-08', price: 380, total: 17100, remark: '', location: 'ES003-B' },
  { name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', unit: '个', equipCode: '0101P02200', rfidCode: '10101P0220012024061005012XXXXXX0012', tags: ['状态类/临期30天'], supplier: '烽火通信科技股份有限公司', qty: 30, produceDate: '2024-06-10', validDate: '2027-06-10', price: 320, total: 9600, remark: '', location: 'ES003-B' },
]

const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))
const unitOptions = ['刑警支队', '治安支队', '交警支队', '特警支队', '网安支队', '刑侦支队', '反恐支队', '指挥中心', '交警大队', '巡警支队', '装备调配中心', '仓库管理组', '设备维护组', '资产管理组']

function pickMaterial(index: number) {
  const m = stockMaterials[index % stockMaterials.length]
  return { ...m }
}

/* ================================================================
   类型与接口定义
   ================================================================ */
type OutboundType = '领用出库' | '配发出库' | '调拨出库' | '报修出库' | '报废出库' | '紧急出库'
type OutStatus = 'pending_out' | 'completed'

interface MaterialDetail {
  id: string
  name: string
  category: string
  spec: string
  outQty: number
  unit: string
  remainQty: number
  location: string
  produceDate: string
  validDate: string
  maintainPeriod: string
  price: number
  total: number
  equipCode: string
  rfidCode: string
  tags?: string[]
  individualRFIDs?: string[]
  remark: string
  supplier: string
  isFixedAsset?: boolean
}

// 公共基础字段
interface BaseRecord {
  materials: MaterialDetail[]
  outDate: string
  remark: string
  status: OutStatus
  operator: string
  outWarehouse: string
  applicant: string
  applyUnit: string
}

interface LYRecord extends BaseRecord { type: '领用出库'; orderNo: string; isBorrow: boolean; returnDate?: string }
interface PFRecord extends BaseRecord { type: '配发出库'; orderNo: string; issueUnit: string; remainQty: number }
interface DBRecord extends BaseRecord { type: '调拨出库'; transferNo: string; sendUnit: string; recvUnit: string; orderNo: string }
interface BXRecord extends BaseRecord { type: '报修出库'; orderNo: string }
interface BFRecord extends BaseRecord { type: '报废出库'; scrapNo: string; orderNo: string }
interface JJRecord extends BaseRecord { type: '紧急出库'; orderNo: string; isBorrow: boolean; returnDate?: string }

type AnyOutboundRecord = LYRecord | PFRecord | DBRecord | BXRecord | BFRecord | JJRecord

const statusMap: Record<OutStatus, { label: string; tag: string }> = {
  pending_out: { label: '待出库', tag: 'tag-yellow' },
  completed:   { label: '已出库', tag: 'tag-green' },
}

const typeTagMap: Record<OutboundType, { color: string; bg: string }> = {
  '领用出库': { color: '#1890ff', bg: '#e6f7ff' },
  '配发出库': { color: '#52c41a', bg: '#f6ffed' },
  '调拨出库': { color: '#722ed1', bg: '#f9f0ff' },
  '报修出库': { color: '#faad14', bg: '#fffbe6' },
  '报废出库': { color: '#ff4d4f', bg: '#fff1f0' },
  '紧急出库': { color: '#eb2f96', bg: '#fff0f6' },
}

const tabs: { key: OutboundType; label: string; type: OutboundType }[] = [
  { key: '领用出库', label: '领用出库', type: '领用出库' },
  { key: '配发出库', label: '配发出库', type: '配发出库' },
  { key: '调拨出库', label: '调拨出库', type: '调拨出库' },
  { key: '报修出库', label: '报修出库', type: '报修出库' },
  { key: '报废出库', label: '报废出库', type: '报废出库' },
  { key: '紧急出库', label: '紧急出库', type: '紧急出库' },
]

/* ================================================================
   辅助函数
   ================================================================ */
function makeMats(...indices: number[]): MaterialDetail[] {
  return indices.map(i => {
    const m = pickMaterial(i)
    const outQty = [2, 3, 5, 8, 10, 1][i % 6]
    const remainQty = [45, 27, 95, 15, 10, 38][i % 6]
    const price = m.price
    return {
      id: `MAT-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 4)}`,
      name: m.name, category: m.category, spec: m.spec, outQty, unit: m.unit,
      remainQty, location: getWarehouseName(m.location),
      produceDate: m.produceDate, validDate: m.validDate,
      maintainPeriod: ['3个月', '3个月', '6个月', '12个月', '6个月', '6个月'][i % 6],
      price, total: price * outQty,
      equipCode: m.equipCode, rfidCode: m.rfidCode,
      remark: m.remark, supplier: m.supplier,
    }
  })
}

function baseRecord(i: number): BaseRecord {
  return {
    materials: [],
    outDate: '',
    remark: '',
    status: (i < 3 ? 'pending_out' : 'completed') as OutStatus,
    operator: '',
    outWarehouse: ['省厅主仓库', '市局限装备仓库', '省厅主仓库', '区县装备室', '市局限装备仓库', '省厅主仓库'][i],
    applicant: ['张建国', '李卫国', '王志强', '赵明华', '陈晓东', '刘建华'][i],
    applyUnit: ['刑警支队', '治安支队', '特警支队', '交警大队', '网安支队', '巡警支队'][i],
  }
}

const lyRecords: LYRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '领用出库' as const,
  orderNo: `LY2024${String(i + 1).padStart(3, '0')}`,
  isBorrow: i < 2,
  returnDate: i < 2 ? ['2024-04-15', '2024-04-30'][i] : undefined,
  materials: makeMats(i, (i + 3) % 12),
  outDate: ['2024-03-15', '2024-03-16', '2024-03-18', '2024-03-20', '2024-03-22', '2024-03-25'][i],
  remark: ['春季装备更新', '日常领用', '应急演练', '路面执勤', '专项行动', '巡逻保障'][i],
  operator: ['张建国', '李卫国', '王志强', '赵明华', '陈晓东', '刘建华'][i],
}))

const pfRecords: PFRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '配发出库' as const,
  orderNo: `PF2024${String(i + 1).padStart(3, '0')}`,
  issueUnit: ['刑警支队', '治安支队', '特警支队', '交警大队', '巡警支队', '网安支队'][i],
  remainQty: [45, 27, 95, 15, 10, 38][i],
  materials: makeMats((i + 2) % 12, (i + 5) % 12),
  outDate: ['2024-03-14', '2024-03-17', '2024-03-19', '2024-03-21', '2024-03-23', '2024-03-26'][i],
  remark: ['新警配发', '年度配发', '补发申请', '转正配发', '晋升换发', '调岗更换'][i],
  operator: ['陈晓东', '刘建华', '周文博', '吴海涛', '郑国强', '孙德胜'][i],
}))

const dbRecords: DBRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '调拨出库' as const,
  transferNo: `DB2024${String(i + 1).padStart(3, '0')}`,
  sendUnit: ['省厅装备处', '市局装备科', '省厅装备处', 'A区县公安局', '市局装备科', '省厅装备处'][i],
  recvUnit: ['市局装备科', 'A区县公安局', 'B区县公安局', 'C区县公安局', 'D区县公安局', '特警支队'][i],
  orderNo: `CK2024${String(i + 21).padStart(3, '0')}`,
  materials: makeMats((i + 4) % 12, (i + 7) % 12, (i + 1) % 12),
  outDate: ['2024-03-12', '2024-03-15', '2024-03-18', '2024-03-20', '2024-03-24', '2024-03-27'][i],
  remark: ['跨区域调拨', '支援兄弟单位', '库存平衡', '装备更新', '专项任务', '合并整合'][i],
  operator: ['周文博', '吴海涛', '郑国强', '马为民', '黄志勇', '赵明华'][i],
  applicant: ['周文博', '吴海涛', '郑国强', '马为民', '黄志勇', '赵明华'][i],
  applyUnit: ['仓库管理组', '后勤处', '财务处', '资产管理组', '指挥中心', '交警大队'][i],
}))

const bxRecords: BXRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '报修出库' as const,
  orderNo: `BXCK2024${String(i + 1).padStart(3, '0')}`,
  materials: makeMats((i + 6) % 12),
  outDate: ['2024-03-13', '2024-03-16', '2024-03-19', '2024-03-21', '2024-03-23', '2024-03-28'][i],
  remark: ['返厂维修', '故障送修', '定期保养', '屏幕更换', '电池更换', '主板维修'][i],
  operator: ['郑国强', '孙德胜', '马为民', '黄志勇', '周丽华', '吴天明'][i],
  applicant: ['郑国强', '孙德胜', '马为民', '黄志勇', '周丽华', '吴天明'][i],
  applyUnit: ['设备维护组', '技术保障组', '资产管理组', '指挥中心', '审计处', '督查室'][i],
}))

const bfRecords: BFRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '报废出库' as const,
  scrapNo: `BF2024${String(i + 1).padStart(3, '0')}`,
  orderNo: `BFCK2024${String(i + 1).padStart(3, '0')}`,
  materials: makeMats((i + 8) % 12),
  outDate: ['2024-03-10', '2024-03-14', '2024-03-17', '2024-03-19', '2024-03-22', '2024-03-29'][i],
  remark: ['到期报废', '损坏报废', '过期销毁', '淘汰更新', '事故损毁', '技术淘汰'][i],
  operator: ['马为民', '黄志勇', '赵明华', '周丽华', '吴天明', '王建国'][i],
  applicant: ['马为民', '黄志勇', '赵明华', '周丽华', '吴天明', '王建国'][i],
  applyUnit: ['资产管理组', '指挥中心', '交警大队', '审计处', '督查室', '刑警支队'][i],
}))

const jjRecords: JJRecord[] = Array.from({ length: 6 }, (_, i) => ({
  ...baseRecord(i),
  type: '紧急出库' as const,
  orderNo: `JJ2024${String(i + 1).padStart(3, '0')}`,
  isBorrow: i < 3,
  returnDate: i < 3 ? ['2024-04-10', '2024-04-20', '2024-05-01'][i] : undefined,
  materials: makeMats((i + 10) % 12, (i + 3) % 12),
  outDate: ['2024-03-15', '2024-03-18', '2024-03-20', '2024-03-22', '2024-03-24', '2024-03-26'][i],
  remark: ['突发事件处置', '重大安保', '反恐演练', '抢险救灾', '追捕行动', '应急布控'][i],
  operator: ['黄志勇', '赵明华', '王志强', '张建国', '李卫国', '陈晓东'][i],
}))

const allRecords: AnyOutboundRecord[] = [...lyRecords, ...pfRecords, ...dbRecords, ...bxRecords, ...bfRecords, ...jjRecords]

const typeCount: Record<OutboundType, number> = {
  '领用出库': lyRecords.length, '配发出库': pfRecords.length, '调拨出库': dbRecords.length,
  '报修出库': bxRecords.length, '报废出库': bfRecords.length, '紧急出库': jjRecords.length,
}

function getRowKey(row: AnyOutboundRecord): string {
  switch (row.type) {
    case '领用出库': case '配发出库': case '报修出库': case '紧急出库': return row.orderNo
    case '调拨出库': return row.transferNo
    case '报废出库': return row.scrapNo
  }
}
function getOrderNo(row: AnyOutboundRecord): string {
  switch (row.type) {
    case '领用出库': case '配发出库': case '报修出库': case '紧急出库': return row.orderNo
    case '调拨出库': return row.transferNo
    case '报废出库': return row.scrapNo
  }
}
function getApplicantLabel(row: AnyOutboundRecord): string {
  const parts: string[] = []
  if (row.applicant) parts.push(row.applicant)
  if (row.applyUnit) parts.push(row.applyUnit)
  return parts.join(' / ') || '-'
}

/* ================================================================
   主组件
   ================================================================ */
export default function OutboundPage({ onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState<OutboundType>('领用出库')
  const [records, setRecords] = useState<AnyOutboundRecord[]>(allRecords)
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [detailModal, setDetailModal] = useState<{ open: boolean; record: AnyOutboundRecord | null }>({ open: false, record: null })
  const [confirmModal, setConfirmModal] = useState<{ open: boolean; record: AnyOutboundRecord | null }>({ open: false, record: null })
  const [confirmRfidData, setConfirmRfidData] = useState<Record<string, string[]>>({})
  const [confirmExpandedMat, setConfirmExpandedMat] = useState<string | null>(null)
  const [editModal, setEditModal] = useState<{ open: boolean; record: JJRecord | null }>({ open: false, record: null })
  const [addModalOpen, setAddModalOpen] = useState(false)

  // 查询
  const [qEquipName, setQEquipName] = useState('')
  const [qOrderNo, setQOrderNo] = useState('')
  const [qLocation, setQLocation] = useState('')

  // 新增表单
  const [formApplicant, setFormApplicant] = useState('')
  const [formApplyUnit, setFormApplyUnit] = useState('')
  const [formIsBorrow, setFormIsBorrow] = useState(false)
  const [formReturnDate, setFormReturnDate] = useState('')
  const [formWarehouse, setFormWarehouse] = useState('')
  const [formDate, setFormDate] = useState('')
  const [formRemark, setFormRemark] = useState('')
  const [formMaterials, setFormMaterials] = useState<MaterialDetail[]>([])

  // 库存弹窗
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockSearchLocation, setStockSearchLocation] = useState('')
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: typeof stockMaterials[0]; qty: number }[]>([])

  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchLocation && !s.location.startsWith(stockSearchLocation)) return false
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    return true
  })

  const filtered = records
    .filter(r => r.type === activeTab)
    .filter(r => !qOrderNo || getOrderNo(r).toLowerCase().includes(qOrderNo.toLowerCase()))
    .filter(r => !qEquipName || r.materials.some(m => m.name.includes(qEquipName)))
    .filter(r => !qLocation || r.materials.some(m => m.location.includes(qLocation)))

  const toggleExpand = (id: string) => setExpandedId(prev => prev === id ? null : id)

  const doConfirmOut = () => {
    if (!confirmModal.record) return
    // 校验所有RFID编码已填写
    for (const m of confirmModal.record.materials) {
      const rfids = confirmRfidData[m.id] || []
      for (let i = 0; i < m.outQty; i++) {
        if (!rfids[i] || rfids[i].trim() === '') {
          alert(`【${m.name}】的第 ${i + 1} 个RFID编码未填写，请补充后确认`)
          setConfirmExpandedMat(m.id)
          return
        }
      }
    }
    const key = getRowKey(confirmModal.record)
    setRecords(prev => prev.map(r => getRowKey(r) === key ? { ...r, status: 'completed' as OutStatus } : r))
    setConfirmModal({ open: false, record: null })
    setConfirmRfidData({})
  }

  const resetForm = () => {
    setFormApplicant(''); setFormApplyUnit(''); setFormIsBorrow(false)
    setFormReturnDate(''); setFormWarehouse(''); setFormDate('')
    setFormRemark(''); setFormMaterials([])
  }
  const openAddModal = () => { resetForm(); setAddModalOpen(true) }

  const toggleStockSelect = (stock: typeof stockMaterials[0]) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.name === stock.name)
      if (exists) return prev.filter(p => p.stock.name !== stock.name)
      return [...prev, { stock, qty: 1 }]
    })
  }
  const updateSelectedQty = (name: string, newQty: number) => {
    const item = stockMaterials.find(s => s.name === name)
    if (item && newQty > item.qty) { alert('申请数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.name === name ? { ...p, qty: Math.max(1, newQty) } : p))
  }
  const confirmStockItems = () => {
    const newItems: MaterialDetail[] = selectedStockItems.map((s, i) => ({
      id: `MAT-${Date.now()}-${i}`,
      name: s.stock.name, category: s.stock.category, spec: s.stock.spec,
      outQty: s.qty, unit: s.stock.unit, remainQty: s.stock.qty - s.qty,
      location: getWarehouseName(s.stock.location),
      produceDate: s.stock.produceDate, validDate: s.stock.validDate,
      maintainPeriod: '3个月', price: s.stock.price, total: s.stock.price * s.qty,
      equipCode: s.stock.equipCode, rfidCode: s.stock.rfidCode,
      remark: s.stock.remark, supplier: s.stock.supplier,
    }))
    setFormMaterials(prev => [...prev, ...newItems])
    setStockModalOpen(false)
    setSelectedStockItems([])
    setStockSearchName(''); setStockSearchCategory(''); setStockSearchLocation('')
  }

  const validateForm = () => {
    if (!formApplicant && !formApplyUnit) { alert('申请人和申请单位至少填写一个'); return false }
    if (!formWarehouse) { alert('请选择调出仓库'); return false }
    if (formIsBorrow && !formReturnDate) { alert('借用类型需填写归还时间'); return false }
    if (formMaterials.length === 0) { alert('请至少添加一件物资'); return false }
    return true
  }

  const handleSaveAdd = () => {
    if (!validateForm()) return
    const newNo = `JJ2024${String(records.filter(r => r.type === '紧急出库').length + 1).padStart(3, '0')}`
    const newRecord: JJRecord = {
      type: '紧急出库', orderNo: newNo, isBorrow: formIsBorrow,
      returnDate: formIsBorrow ? formReturnDate : undefined,
      applicant: formApplicant || '', applyUnit: formApplyUnit || '',
      outWarehouse: getWarehouseName(formWarehouse) || formWarehouse,
      materials: formMaterials,
      outDate: formDate || new Date().toISOString().slice(0, 10),
      remark: formRemark, status: 'pending_out', operator: '当前用户',
    }
    setRecords(prev => [newRecord, ...prev])
    setAddModalOpen(false)
    resetForm()
  }

  const resetQuery = () => { setQEquipName(''); setQOrderNo(''); setQLocation('') }

  /* ==================== 确认出库弹窗内容（只读） ==================== */
  const renderConfirmContent = (record: AnyOutboundRecord) => {
    const isBorrow = record.type === '领用出库' || record.type === '紧急出库' ? (record as LYRecord | JJRecord).isBorrow : false
    const returnDate = record.type === '领用出库' || record.type === '紧急出库' ? (record as LYRecord | JJRecord).returnDate : undefined

    return (
      <div className="p-6 space-y-5 overflow-y-auto flex-1">
        <div className="content-card p-4 border-l-4" style={{ borderColor: '#eb2f96' }}>
          <h4 className="text-sm font-semibold mb-3" style={{ color: '#eb2f96' }}>基本信息</h4>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库单号</label>
              <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={getOrderNo(record)} />
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
              <input className="form-input w-full bg-gray-50" readOnly value={record.applicant || '-'} />
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位</label>
              <input className="form-input w-full bg-gray-50" readOnly value={record.applyUnit || '-'} />
            </div>
            {(record.type === '领用出库' || record.type === '紧急出库') && (
              <>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否借用</label>
                  <input className="form-input w-full bg-gray-50" readOnly value={isBorrow ? '是' : '否'} />
                </div>
                {isBorrow && (
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>归还时间</label>
                    <input className="form-input w-full bg-gray-50" readOnly value={returnDate || '-'} />
                  </div>
                )}
              </>
            )}
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库</label>
              <input className="form-input w-full bg-gray-50" readOnly value={record.outWarehouse} />
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库日期</label>
              <input className="form-input w-full bg-gray-50" readOnly value={record.outDate} />
            </div>
            <div>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
              <input className="form-input w-full bg-gray-50" readOnly value={record.remark || '-'} />
            </div>
            {record.type === '调拨出库' && (
              <>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发物单位</label>
                  <input className="form-input w-full bg-gray-50" readOnly value={(record as DBRecord).sendUnit} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>收物单位</label>
                  <input className="form-input w-full bg-gray-50" readOnly value={(record as DBRecord).recvUnit} />
                </div>
              </>
            )}
            {record.type === '配发出库' && (
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>配发单位</label>
                <input className="form-input w-full bg-gray-50" readOnly value={(record as PFRecord).issueUnit} />
              </div>
            )}
            {record.type === '报废出库' && (
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库单号</label>
                <input className="form-input w-full bg-gray-50 font-mono text-xs" readOnly value={(record as BFRecord).orderNo} />
              </div>
            )}
          </div>
        </div>
        <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
          <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>物资明细 <span style={{ color: 'var(--text-secondary)' }}>({record.materials.length} 种)</span></h4>
          <div className="overflow-x-auto">
            <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
              <thead>
                <tr style={{ background: 'var(--table-header-bg)' }}>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>#</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>标签</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>出库数量</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>存储位置</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                  <th className="border p-2" style={{ borderColor: 'var(--border-color)', minWidth: 140 }}>
                    RFID编码 <span className="text-red-400">*</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {record.materials.map((item, idx) => {
                  const isExpanded = confirmExpandedMat === item.id
                  const rfids = confirmRfidData[item.id] || []
                  return (
                    <>
                      <tr key={item.id}>
                        <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                        <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{item.name}</td>
                        <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.category}</td>
                        <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.spec}</td>
                        <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}><TagBadges tags={item.tags || []} maxShow={2} /></td>
                        <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{item.outQty}</td>
                        <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.unit}</td>
                        <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.location}</td>
                        <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.price.toLocaleString()}</td>
                        <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                        <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>
                          {item.outQty === 1 ? (
                            <div className="flex items-center gap-1">
                              <input
                                className="form-input w-36 font-mono text-[10px]"
                                value={rfids[0] || ''}
                                onChange={e => setConfirmRfidData(prev => ({...prev, [item.id]: [e.target.value]}))}
                                placeholder="请输入RFID"
                              />
                              <button
                                className="p-1 rounded hover:bg-gray-100 flex-shrink-0"
                                title="扫描"
                                onClick={() => {
                                  const prefix = item.rfidCode.substring(0, 20) || '10101P00100120240315'
                                  const suffix = String(Math.floor(Math.random() * 999999)).padStart(6, '0')
                                  setConfirmRfidData(prev => ({...prev, [item.id]: [`${prefix}${suffix}`]}))
                                }}
                              >
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><rect x="7" y="7" width="10" height="10" rx="1"/></svg>
                              </button>
                            </div>
                          ) : (
                            <button
                              className="text-xs px-2 py-1 rounded border hover:bg-gray-50 flex items-center gap-1 w-full justify-center"
                              style={{ color: 'var(--primary-blue)', borderColor: '#bfdbfe' }}
                              onClick={() => setConfirmExpandedMat(isExpanded ? null : item.id)}
                            >
                              {isExpanded ? '收起' : `展开填写 (${item.outQty}个)`}
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9"/></svg>
                            </button>
                          )}
                        </td>
                      </tr>
                      {item.outQty > 1 && isExpanded && (
                        <tr key={item.id + '-rfid'}>
                          <td colSpan={10} className="p-0">
                            <div className="bg-gray-50 p-3 space-y-2">
                              {Array.from({ length: item.outQty }, (_, i) => (
                                <div key={i} className="flex items-center gap-2">
                                  <span className="text-xs font-mono w-6 text-right flex-shrink-0" style={{ color: 'var(--text-secondary)' }}>{i + 1}.</span>
                                  <input
                                    className="form-input flex-1 font-mono text-[10px]"
                                    value={rfids[i] || ''}
                                    onChange={e => {
                                      const newRfids = [...rfids]
                                      newRfids[i] = e.target.value
                                      setConfirmRfidData(prev => ({...prev, [item.id]: newRfids}))
                                    }}
                                    placeholder={`请输入第 ${i + 1} 个RFID编码`}
                                  />
                                  <button
                                    className="p-1 rounded hover:bg-gray-100 flex-shrink-0"
                                    title="扫描"
                                    onClick={() => {
                                      const prefix = item.rfidCode.substring(0, 20) || '10101P00100120240315'
                                      const suffix = String(Math.floor(Math.random() * 999999)).padStart(6, '0')
                                      const newRfids = [...rfids]
                                      newRfids[i] = `${prefix}${suffix}`
                                      setConfirmRfidData(prev => ({...prev, [item.id]: newRfids}))
                                    }}
                                  >
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><rect x="7" y="7" width="10" height="10" rx="1"/></svg>
                                  </button>
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
          返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>出库管理</span>
      </div>

      {/* 操作栏 */}
      <div className="flex items-center justify-between">
        {activeTab === '紧急出库' && (
          <button className="btn-primary text-sm" onClick={openAddModal}>+ 新增出库单</button>
        )}
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filtered.length} 条记录</span>
      </div>

      {/* 查询区域 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label>
            <input className="form-input w-36 text-sm" placeholder="模糊查询" value={qEquipName} onChange={e => setQEquipName(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库单号</label>
            <input className="form-input w-36 text-sm" placeholder="请输入" value={qOrderNo} onChange={e => setQOrderNo(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置</label>
            <input className="form-input w-36 text-sm" placeholder="请输入" value={qLocation} onChange={e => setQLocation(e.target.value)} />
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default text-sm" onClick={resetQuery}>重置</button>
            <button className="btn-primary text-sm">查询</button>
          </div>
        </div>
      </div>

      {/* 页签 */}
      <div className="flex gap-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
        {tabs.map(tab => (
          <button
            key={tab.key}
            className={activeTab === tab.key
              ? 'relative px-4 py-2.5 text-sm font-medium transition-colors text-[var(--primary-blue)]'
              : 'relative px-4 py-2.5 text-sm font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
            }
            onClick={() => { setActiveTab(tab.key); setExpandedId(null) }}
          >
            {tab.label}
            <span className={activeTab === tab.key
              ? 'ml-1.5 text-xs px-1.5 py-0.5 rounded-full bg-blue-50 text-[var(--primary-blue)]'
              : 'ml-1.5 text-xs px-1.5 py-0.5 rounded-full bg-gray-100 text-[var(--text-secondary)]'
            }>{typeCount[tab.type]}</span>
            {activeTab === tab.key && (
              <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: 'var(--primary-blue)' }} />
            )}
          </button>
        ))}
      </div>

      {/* 数据表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>{renderTableHead(activeTab)}</thead>
          <tbody>
            {filtered.map(row => (
              <TableRow key={getRowKey(row)} row={row} expandedId={expandedId}
                onToggleExpand={toggleExpand}
                onDetail={(r) => setDetailModal({ open: true, record: r })}
                onConfirmOut={(r) => {
                  const initRfid: Record<string, string[]> = {}
                  r.materials.forEach(m => {
                    initRfid[m.id] = Array.from({ length: m.outQty }, (_, i) => i === 0 ? m.rfidCode : '')
                  })
                  setConfirmRfidData(initRfid)
                  setConfirmExpandedMat(null)
                  setConfirmModal({ open: true, record: r })
                }}
                onEdit={(r) => setEditModal({ open: true, record: r })}
              />
            ))}
            {filtered.length === 0 && (
              <tr><td colSpan={20} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* ===== 确认出库弹窗（只读完整表单） ===== */}
      {confirmModal.open && confirmModal.record && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setConfirmModal({ open: false, record: null })} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[900px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">确认出库</h3>
              <button onClick={() => setConfirmModal({ open: false, record: null })} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {renderConfirmContent(confirmModal.record)}
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setConfirmModal({ open: false, record: null })}>取消</button>
              <button className="btn-primary" onClick={() => alert('固资推送功能开发中')}>固资推送</button>
              <button className="btn-primary" onClick={doConfirmOut}>确认出库</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情弹窗 ===== */}
      {detailModal.open && detailModal.record && (
        <div className="fixed inset-0 z-[70] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailModal({ open: false, record: null })} />
          <div className="relative bg-white shadow-2xl w-[600px] flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">出库详情</h3>
              <button onClick={() => setDetailModal({ open: false, record: null })} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="overflow-y-auto flex-1 p-6 text-sm">
              <DetailContent record={detailModal.record} />
            </div>
            <div className="sticky bottom-0 px-5 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailModal({ open: false, record: null })}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 新增紧急出库弹窗 ===== */}
      {addModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAddModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[900px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增紧急出库单</h3>
              <button onClick={() => setAddModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* 基本信息 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#eb2f96' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#eb2f96' }}>基本信息</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库单号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={`JJ2024${String(records.filter(r => r.type === '紧急出库').length + 1).padStart(3, '0')}`} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入申请人姓名" value={formApplicant} onChange={e => setFormApplicant(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full" value={formApplyUnit} onChange={e => setFormApplyUnit(e.target.value)}>
                      <option value="">请选择</option>
                      {unitOptions.map(u => <option key={u}>{u}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否借用</label>
                    <select className="form-input w-full" value={formIsBorrow ? '是' : '否'} onChange={e => setFormIsBorrow(e.target.value === '是')}>
                      <option value="否">否</option>
                      <option value="是">是</option>
                    </select>
                  </div>
                  {formIsBorrow && (
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>归还时间 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full" type="date" value={formReturnDate} onChange={e => setFormReturnDate(e.target.value)} />
                    </div>
                  )}
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库 <span className="text-red-400">*</span></label>
                    <WarehouseTreeSelect warehouseData={warehouseData} value={formWarehouse} onChange={setFormWarehouse} placeholder="请选择" />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>出库日期 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" type="date" value={formDate} onChange={e => setFormDate(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                    <input className="form-input w-full" placeholder="请输入备注" value={formRemark} onChange={e => setFormRemark(e.target.value)} />
                  </div>
                </div>
              </div>

              {/* 物资明细 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细 <span style={{ color: 'var(--text-secondary)' }}>({formMaterials.length} 种)</span></h4>
                  <button onClick={() => { setSelectedStockItems([]); setStockModalOpen(true) }} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 添加物资</button>
                </div>
                {formMaterials.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border border-separate border-spacing-0" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 min-w-[32px]" style={{ borderColor: 'var(--border-color)' }}>#</th>
                          <th className="border p-2 min-w-[120px]" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                          <th className="border p-2 min-w-[100px]" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                          <th className="border p-2 min-w-[100px]" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                          <th className="border p-2 min-w-[72px]" style={{ borderColor: 'var(--border-color)' }}>出库数量</th>
                          <th className="border p-2 min-w-[60px]" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                          <th className="border p-2 min-w-[140px]" style={{ borderColor: 'var(--border-color)' }}>存储位置</th>
                          <th className="border p-2 min-w-[90px]" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                          <th className="border p-2 min-w-[90px]" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                          <th className="border p-2 min-w-[56px]" style={{ borderColor: 'var(--border-color)' }}>固资</th>
                          <th className="border p-2 min-w-[40px] sticky right-0 bg-white z-10" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formMaterials.map((item, idx) => (
                          <tr key={item.id}>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.name}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.category}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.spec}</td>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{item.outQty}</td>
                            <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.unit}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.location}</td>
                            <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.price.toLocaleString()}</td>
                            <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                            <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>
                              <input type="checkbox" checked={item.isFixedAsset || false} onChange={e => setFormMaterials(prev => prev.map((m, i) => i === idx ? { ...m, isFixedAsset: e.target.checked } : m))} />
                            </td>
                            <td className="border p-2 text-center sticky right-0 bg-white z-10" style={{ borderColor: 'var(--border-color)' }}>
                              <button onClick={() => setFormMaterials(prev => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setAddModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSaveAdd} disabled={formMaterials.length === 0}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备选择弹窗（左右分栏，参照领用管理） ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[100dvh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* 搜索区域 */}
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置</label>
                  <select className="form-input w-32 text-sm" value={stockSearchLocation} onChange={e => setStockSearchLocation(e.target.value)}>
                    <option value="">全部</option>
                    {flattenWarehouses(warehouseData).map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label>
                  <input className="form-input w-28 text-sm" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label>
                  <select className="form-input w-28 text-sm" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}>
                    <option value="">全部</option>
                    {categoryOptions.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchLocation(''); setStockSearchName(''); setStockSearchCategory('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            {/* 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：库存装备列表 */}
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" disabled /></th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>剩余数量</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.name === s.name)
                      return (
                        <tr key={s.name} className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`} onClick={() => toggleStockSelect(s)}>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" checked={isSelected} readOnly /></td>
                          <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{s.name}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.category}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.spec || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.produceDate || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.validDate || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{s.qty}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{s.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{s.equipCode}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.supplier}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.remark || '-'}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && (
                      <tr><td colSpan={13} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedStockItems.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备添加</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.name} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 mb-2 text-[11px]">
                            <div><span style={{ color: 'var(--text-disabled)' }}>类别: </span><span style={{ color: 'var(--text-secondary)' }}>{s.stock.category}</span></div>
                            <div><span style={{ color: 'var(--text-disabled)' }}>规格: </span><span style={{ color: 'var(--text-secondary)' }}>{s.stock.spec}</span></div>
                            <div><span style={{ color: 'var(--text-disabled)' }}>编码: </span><span className="font-mono" style={{ color: 'var(--text-secondary)' }}>{s.stock.equipCode}</span></div>
                            <div><span style={{ color: 'var(--text-disabled)' }}>余量: </span><span className="font-mono font-medium" style={{ color: '#1890ff' }}>{s.stock.qty}</span></div>
                          </div>
                          <div className="flex items-center justify-between gap-2 pt-1 border-t" style={{ borderColor: 'var(--border-color)' }}>
                            <span className="text-[11px]" style={{ color: 'var(--text-disabled)' }}>出库数量</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.name, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.name, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.name, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.name !== s.stock.name))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ================================================================
   表格头渲染
   ================================================================ */
function renderTableHead(activeTab: OutboundType) {
  const commonCols = [<th key="no">出库单号</th>, <th key="type">出库类型</th>]
  switch (activeTab) {
    case '领用出库':
      return (<tr>{commonCols}<th>申请人/申请单位</th><th>是否借用</th><th>归还时间</th><th>调出仓库</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
    case '配发出库':
      return (<tr>{commonCols}<th>申请人/申请单位</th><th>调出仓库</th><th>配发单位</th><th>剩余数量</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
    case '调拨出库':
      return (<tr>{commonCols}<th>发物单位</th><th>收物单位</th><th>申请人/申请单位</th><th>调出仓库</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
    case '报修出库':
      return (<tr>{commonCols}<th>申请人/申请单位</th><th>调出仓库</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
    case '报废出库':
      return (<tr>{commonCols}<th>申请人/申请单位</th><th>调出仓库</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
    case '紧急出库':
      return (<tr>{commonCols}<th>是否借用</th><th>归还时间</th><th>申请人/申请单位</th><th>调出仓库</th><th>装备数量</th><th>出库日期</th><th>状态</th><th>备注</th><th>操作</th></tr>)
  }
}

/* ================================================================
   表格行组件
   ================================================================ */
function TableRow({ row, expandedId, onToggleExpand, onDetail, onConfirmOut, onEdit }: {
  row: AnyOutboundRecord
  expandedId: string | null
  onToggleExpand: (id: string) => void
  onDetail: (r: AnyOutboundRecord) => void
  onConfirmOut: (r: AnyOutboundRecord) => void
  onEdit: (r: JJRecord) => void
}) {
  const key = getRowKey(row)
  const status = statusMap[row.status]
  const t = typeTagMap[row.type]
  const typeTag = <span className="text-xs px-2 py-0.5 rounded font-medium" style={{ color: t.color, background: t.bg }}>{row.type}</span>
  const appLabel = getApplicantLabel(row)

  const actions = () => {
    const btns: any[] = []
    btns.push(<button key="d" className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onDetail(row)}>详情</button>)
    if (row.status === 'pending_out') {
      btns.push(<button key="c" className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => onConfirmOut(row)}>确认出库</button>)
      if (row.type === '紧急出库') btns.push(<button key="e" className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => onEdit(row as JJRecord)}>编辑</button>)
    }
    return <div className="flex items-center gap-2 flex-wrap">{btns}</div>
  }

  switch (row.type) {
    case '领用出库':
      return (<><tr><td className="font-mono text-xs">{row.orderNo}</td><td>{typeTag}</td><td>{appLabel}</td><td>{row.isBorrow ? '是' : '否'}</td><td>{row.returnDate || '-'}</td><td>{row.outWarehouse}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
    case '配发出库':
      return (<><tr><td className="font-mono text-xs">{row.orderNo}</td><td>{typeTag}</td><td>{appLabel}</td><td>{row.outWarehouse}</td><td>{row.issueUnit}</td><td>{row.remainQty}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
    case '调拨出库':
      return (<><tr><td className="font-mono text-xs">{row.transferNo}</td><td>{typeTag}</td><td>{row.sendUnit}</td><td>{row.recvUnit}</td><td>{appLabel}</td><td>{row.outWarehouse}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
    case '报修出库':
      return (<><tr><td className="font-mono text-xs">{row.orderNo}</td><td>{typeTag}</td><td>{appLabel}</td><td>{row.outWarehouse}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
    case '报废出库':
      return (<><tr><td className="font-mono text-xs">{row.scrapNo}</td><td>{typeTag}</td><td>{appLabel}</td><td>{row.outWarehouse}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
    case '紧急出库':
      return (<><tr><td className="font-mono text-xs">{row.orderNo}</td><td>{typeTag}</td><td>{row.isBorrow ? '是' : '否'}</td><td>{row.returnDate || '-'}</td><td>{appLabel}</td><td>{row.outWarehouse}</td><td>{row.materials.length} 种</td><td>{row.outDate}</td><td><span className={'tag text-xs ' + status.tag}>{status.label}</span></td><td className="text-xs">{row.remark || '-'}</td><td>{actions()}</td></tr></>)
  }
}

/* ================================================================
   详情弹窗内容
   ================================================================ */
function DetailContent({ record }: { record: AnyOutboundRecord }) {
  const status = statusMap[record.status]
  const fields: { label: string; value: string }[] = []
  fields.push({ label: '出库类型', value: record.type })
  fields.push({ label: '状态', value: status.label })
  fields.push({ label: '经办人', value: record.operator })
  fields.push({ label: '出库日期', value: record.outDate })
  fields.push({ label: '申请人', value: record.applicant || '-' })
  fields.push({ label: '申请单位', value: record.applyUnit || '-' })

  switch (record.type) {
    case '领用出库':
      fields.push({ label: '出库单号', value: record.orderNo })
      fields.push({ label: '是否借用', value: record.isBorrow ? '是' : '否' })
      if (record.returnDate) fields.push({ label: '归还时间', value: record.returnDate })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
    case '配发出库':
      fields.push({ label: '出库单号', value: record.orderNo })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '配发单位', value: (record as PFRecord).issueUnit })
      fields.push({ label: '剩余数量', value: String((record as PFRecord).remainQty) })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
    case '调拨出库':
      fields.push({ label: '调拨单号', value: (record as DBRecord).transferNo })
      fields.push({ label: '发物单位', value: (record as DBRecord).sendUnit })
      fields.push({ label: '收物单位', value: (record as DBRecord).recvUnit })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
    case '报修出库':
      fields.push({ label: '出库单号', value: record.orderNo })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
    case '报废出库':
      fields.push({ label: '报废单号', value: (record as BFRecord).scrapNo })
      fields.push({ label: '出库单号', value: (record as BFRecord).orderNo })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
    case '紧急出库':
      fields.push({ label: '出库单号', value: record.orderNo })
      fields.push({ label: '是否借用', value: (record as JJRecord).isBorrow ? '是' : '否' })
      if ((record as JJRecord).returnDate) fields.push({ label: '归还时间', value: (record as JJRecord).returnDate! })
      fields.push({ label: '调出仓库', value: record.outWarehouse })
      fields.push({ label: '备注', value: record.remark || '-' })
      break
  }

  return (
    <div>
      <div className="mb-5">
        <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: 'var(--primary-blue)' }} />基本信息</h4>
        <div className="grid grid-cols-3 gap-x-4 gap-y-2">
          {fields.map(f => (
            <div key={f.label} className="flex flex-col py-1">
              <span className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
              <span className="font-medium">{f.value}</span>
            </div>
          ))}
        </div>
      </div>
      <div>
        <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#faad14' }} />物资明细（{record.materials.length} 种）</h4>
        <div className="overflow-x-auto">
          <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
            <thead>
              <tr style={{ background: 'var(--table-header-bg)' }}>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>#</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>出库数量</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>剩余数量</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>存储位置</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
              </tr>
            </thead>
            <tbody>
              {record.materials.map((m, i) => (
                <tr key={m.id}>
                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{i + 1}</td>
                  <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{m.name}</td>
                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{m.category}</td>
                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{m.spec}</td>
                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{m.outQty}</td>
                  <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{m.unit}</td>
                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{m.remainQty}</td>
                  <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{m.location}</td>
                  <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{m.price.toLocaleString()}</td>
                  <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{m.total.toLocaleString()}</td>
                  <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{m.equipCode}</td>
                  <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{m.supplier}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* RFID编码列表 - 按物资分组展示 */}
        {record.materials.some(m => m.outQty > 1 || (m.individualRFIDs && m.individualRFIDs.length > 1)) && (
          <div className="mt-4 space-y-2">
            <h4 className="text-sm font-semibold flex items-center gap-2">
              <span className="w-1 h-4 rounded-full bg-purple-500" />RFID编码明细
            </h4>
            {record.materials.filter(m => m.outQty > 1 || (m.individualRFIDs && m.individualRFIDs.length > 1)).map((m, i) => (
              <RfidList
                key={m.id}
                rfids={m.individualRFIDs || Array.from({ length: m.outQty }, (_, idx) => m.rfidCode.slice(0, -4) + String(idx + 1).padStart(4, '0'))}
                selectedRfid={m.rfidCode}
                onSelect={(rfid) => { }}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
