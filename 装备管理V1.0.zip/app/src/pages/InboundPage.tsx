import { useState, useMemo } from 'react'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'
import TagBadges, { RfidDisplay } from '../components/TagBadges'
import RfidList from '../components/RfidList'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type InboundSource = 'initial' | 'purchase' | 'transfer' | 'return' | 'team'
type InboundStatus = 'pending' | 'done'

// ===== 仓库配置数据（树形结构） =====
interface Warehouse {
  id: string
  name: string
  parent?: string
  entityType: string
  level: string
  children?: Warehouse[]
}

export const warehouseData: Warehouse[] = [
  {
    id: 'ES001', name: '省厅主仓库', parent: undefined, entityType: '仓库', level: '省级',
    children: [
      { id: 'ES001-A', name: 'A区-01货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-B', name: 'A区-02货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-C', name: 'A区-03货架', parent: 'ES001', entityType: '货架', level: '省级' },
    ]
  },
  {
    id: 'ES002', name: '市局限装备仓库', parent: undefined, entityType: '仓库', level: '市级',
    children: [
      { id: 'ES002-A', name: 'B区-01货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-B', name: 'B区-02货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-C', name: 'B区-03货架', parent: 'ES002', entityType: '货架', level: '市级' },
    ]
  },
  {
    id: 'ES003', name: 'A区县级装备库', parent: undefined, entityType: '分区', level: '区县级',
    children: [
      { id: 'ES003-A', name: 'C区-01货架', parent: 'ES003', entityType: '货架', level: '区县级' },
      { id: 'ES003-B', name: 'C区-02货架', parent: 'ES003', entityType: '货架', level: '区县级' },
    ]
  },
  { id: 'ES004', name: 'B区县级装备库', parent: undefined, entityType: '分区', level: '区县级', children: [] },
]

function flattenWarehouses(nodes: Warehouse[], depth = 0): { id: string; label: string }[] {
  const result: { id: string; label: string }[] = []
  for (const n of nodes) {
    const indent = '\u00A0\u00A0'.repeat(depth)
    result.push({ id: n.id, label: `${indent}${n.name}` })
    if (n.children) result.push(...flattenWarehouses(n.children, depth + 1))
  }
  return result
}

function getSelfAndChildren(nodeId: string): { id: string; name: string }[] {
  const result: { id: string; name: string }[] = []
  for (const w of warehouseData) {
    if (w.id === nodeId) {
      result.push({ id: w.id, name: w.name })
      if (w.children) for (const c of w.children) result.push({ id: c.id, name: c.name })
    }
  }
  return result
}

// ===== 物资明细接口 =====
interface MaterialItem {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  transferQty: number
  borrowQty: number
  produceDate: string
  validDate: string
  maintainPeriod: string
  unit: string
  subUnit: string
  price: number
  total: number
  equipCode: string
  rfidCode: string
  remark: string
  supplier: string
  location: string
  isFixedAsset: boolean
  tags: string[]
  individualRFIDs?: string[]
}

interface RfidMaterial {
  rfidCode: string
  name: string
  category: string
  spec: string
  equipCode: string
  supplier: string
}

const rfidMaterialDB: RfidMaterial[] = [
  { rfidCode: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色', equipCode: '0101P00100', supplier: '华为技术有限公司' },
  { rfidCode: '10101P0020012024040105003XXXXXX0003', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', equipCode: '0101P00200', supplier: '海康威视数字技术股份有限公司' },
  { rfidCode: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', equipCode: '0101P00300', supplier: '华为技术有限公司' },
  { rfidCode: '10101P0040012024031505005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', equipCode: '0101P00400', supplier: '中兴通讯股份有限公司' },
  { rfidCode: '10101P0050012024031505002XXXXXX0002', name: '对讲机 PD780G', category: '通信设备', spec: 'PD780G/U段', equipCode: '0101P00500', supplier: '烽火通信科技股份有限公司' },
  { rfidCode: '10101P0060012024031505006XXXXXX0006', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', equipCode: '0101P00600', supplier: '大华技术股份有限公司' },
]

// ===== 入库记录接口 =====
interface InboundRecord {
  id: string
  source: InboundSource
  inboundNo: string
  materialSource: string
  location: string
  inboundTime: string
  operator: string
  status: InboundStatus
  materials: MaterialItem[]
  purchaseProject: string
  purchaseDate: string
  mainSupplier: string
  transferNo: string
  senderUnit: string
  borrower: string
  borrowTime: string
  expectReturnDate: string
}

const sourceLabels: Record<InboundSource, string> = {
  initial: '期初库存', purchase: '采购入库', transfer: '仓库调拨入库', return: '归还入库', team: '捐赠入库',
}

const sourceTabs: { key: InboundSource; label: string }[] = [
  { key: 'initial', label: '期初库存' },
  { key: 'purchase', label: '采购入库' },
  { key: 'transfer', label: '仓库调拨入库' },
  { key: 'return', label: '归还入库' },
  { key: 'team', label: '捐赠入库' },
]

const materialSourceOptions = ['期初库存', '采购入库', '仓库调拨', '归还入库', '捐赠入库']
const unitOptions = ['个', '台', '根', '箱']
const subUnitOptions: Record<string, string[]> = { '箱': ['个/1箱', '台/1箱', '根/1箱'] }
const supplierOptions = [
  '华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司',
  '中兴通讯股份有限公司', '大华技术股份有限公司',
]

const statusLabels: Record<InboundStatus, { label: string; tag: string }> = {
  pending: { label: '待入库', tag: 'tag-yellow' },
  done: { label: '已入库', tag: 'tag-green' },
}

const emptyMaterial = (defaultSupplier: string = ''): MaterialItem => ({
  id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
  name: '', category: '', spec: '', qty: 0, transferQty: 0, borrowQty: 0,
  produceDate: '', validDate: '', maintainPeriod: '',
  unit: '个', subUnit: '', price: 0, total: 0,
  equipCode: '', rfidCode: '', remark: '', supplier: defaultSupplier, location: '',
  isFixedAsset: false,
  tags: [],
})

const inboundRecords: InboundRecord[] = [
  // ===== 期初库存 x4 =====
  {
    id: 'RK2024101', source: 'initial', inboundNo: 'RK2024101',
    materialSource: '期初库存', location: 'ES001',
    inboundTime: '2024-01-10 09:00:00',
    operator: '王建国', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色', qty: 50, transferQty: 0, borrowQty: 0, produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 2800, total: 140000, equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', remark: '期初盘点', supplier: '华为技术有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '2', name: '对讲机 PD780G', category: '通信设备', spec: 'PD780G/U段', qty: 30, transferQty: 0, borrowQty: 0, produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 1500, total: 45000, equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '3', name: '警务通手机 S1', category: '通信设备', spec: 'S1/6.5寸', qty: 25, transferQty: 0, borrowQty: 0, produceDate: '2024-01-20', validDate: '2027-01-20', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 3200, total: 80000, equipCode: '0101P00700', rfidCode: '10101P0070012024012005007XXXXXX0007', remark: '配发刑侦', supplier: '华为技术有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '4', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 80, transferQty: 0, borrowQty: 0, produceDate: '2024-02-10', validDate: '2027-02-10', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 1800, total: 144000, equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', remark: '全局配发', supplier: '海康威视数字技术股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
  {
    id: 'RK2024102', source: 'initial', inboundNo: 'RK2024102',
    materialSource: '期初库存', location: 'ES002',
    inboundTime: '2024-01-15 10:30:00',
    operator: '李秀英', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '防弹盾牌 FDP-4', category: '防护装备', spec: 'FDP-4/四级', qty: 12, transferQty: 0, borrowQty: 0, produceDate: '2023-12-01', validDate: '2028-12-01', maintainPeriod: '12个月', unit: '面', subUnit: '', price: 4500, total: 54000, equipCode: '0101P00800', rfidCode: '10101P0080012023120105008XXXXXX0008', remark: '特警队', supplier: '华为技术有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
    ]
  },
  {
    id: 'RK2024103', source: 'initial', inboundNo: 'RK2024103',
    materialSource: '期初库存', location: 'ES003',
    inboundTime: '2024-01-20 08:00:00',
    operator: '赵志刚', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '催泪喷射器 CR-S', category: '警械', spec: 'CR-S/500ml', qty: 60, transferQty: 0, borrowQty: 0, produceDate: '2024-01-05', validDate: '2027-01-05', maintainPeriod: '12个月', unit: '瓶', subUnit: '', price: 120, total: 7200, equipCode: '0101P00900', rfidCode: '10101P0090012024010505009XXXXXX0009', remark: '', supplier: '大华技术股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '2', name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', qty: 45, transferQty: 0, borrowQty: 0, produceDate: '2024-01-08', validDate: '2029-01-08', maintainPeriod: '6个月', unit: '根', subUnit: '', price: 380, total: 17100, equipCode: '0101P01000', rfidCode: '10101P0100012024010805010XXXXXX0010', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '3', name: '手铐 SK-A', category: '警械', spec: 'SK-A/不锈钢', qty: 30, transferQty: 0, borrowQty: 0, produceDate: '2024-01-10', validDate: '2030-01-10', maintainPeriod: '12个月', unit: '副', subUnit: '', price: 95, total: 2850, equipCode: '0101P01100', rfidCode: '10101P0110012024011005011XXXXXX0011', remark: '', supplier: '大华技术股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['活动类/双11备货'] },
    ]
  },
  {
    id: 'RK2024104', source: 'initial', inboundNo: 'RK2024104',
    materialSource: '期初库存', location: 'ES001',
    inboundTime: '2024-02-01 09:00:00',
    operator: '周丽华', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '防刺背心 FC-F', category: '防护装备', spec: 'FC-F/芳纶', qty: 35, transferQty: 0, borrowQty: 0, produceDate: '2024-01-20', validDate: '2029-01-20', maintainPeriod: '12个月', unit: '件', subUnit: '', price: 2800, total: 98000, equipCode: '0101P01200', rfidCode: '10101P0120012024012005012XXXXXX0012', remark: '', supplier: '华为技术有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
      { id: '2', name: '防弹头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 20, transferQty: 0, borrowQty: 0, produceDate: '2024-01-25', validDate: '2029-01-25', maintainPeriod: '6个月', unit: '顶', subUnit: '', price: 2600, total: 52000, equipCode: '0101P00400', rfidCode: '10101P0010012024031505001XXXXXX0001', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '3', name: '战术手套 TS-B', category: '防护装备', spec: 'TS-B/凯夫拉', qty: 50, transferQty: 0, borrowQty: 0, produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '6个月', unit: '副', subUnit: '', price: 220, total: 11000, equipCode: '0101P01300', rfidCode: '10101P0130012024020105013XXXXXX0013', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '4', name: '护目镜 HM-P', category: '防护装备', spec: 'HM-P/防雾', qty: 40, transferQty: 0, borrowQty: 0, produceDate: '2024-02-05', validDate: '2027-02-05', maintainPeriod: '3个月', unit: '副', subUnit: '', price: 180, total: 7200, equipCode: '0101P01400', rfidCode: '10101P0140012024020505014XXXXXX0014', remark: '', supplier: '海康威视数字技术股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
    ]
  },

  // ===== 采购入库 x4 =====
  {
    id: 'RK2024201', source: 'purchase', inboundNo: 'RK2024201',
    materialSource: '采购入库', location: 'ES002',
    inboundTime: '2024-04-10 14:00:00',
    operator: '吴天明', status: 'done', purchaseProject: '2024年警用通信装备采购项目', purchaseDate: '2024-04-01',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '执法记录仪 DSJ-A8', category: '执法设备', spec: 'DSJ-A8/128G', qty: 200, transferQty: 0, borrowQty: 0, produceDate: '2024-03-20', validDate: '2027-03-20', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 2200, total: 440000, equipCode: '0101P01500', rfidCode: '10101P0150012024032005015XXXXXX0015', remark: '全局更新', supplier: '海康威视数字技术股份有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['活动类/双11备货'] },
    ]
  },
  {
    id: 'RK2024202', source: 'purchase', inboundNo: 'RK2024202',
    materialSource: '采购入库', location: 'ES001',
    inboundTime: '2024-05-08 10:00:00',
    operator: '孙秀兰', status: 'done', purchaseProject: '2024年安防监控采购项目', purchaseDate: '2024-04-25',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '4G执法记录仪 DSJ-4G', category: '执法设备', spec: 'DSJ-4G/实时传输', qty: 60, transferQty: 0, borrowQty: 0, produceDate: '2024-04-15', validDate: '2027-04-15', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 3500, total: 210000, equipCode: '0101P01600', rfidCode: '10101P0160012024041505016XXXXXX0016', remark: '指挥中心', supplier: '海康威视数字技术股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
      { id: '2', name: '高清摄像头 IPC-4K', category: '监控设备', spec: 'IPC-4K/夜视', qty: 40, transferQty: 0, borrowQty: 0, produceDate: '2024-04-20', validDate: '2029-04-20', maintainPeriod: '12个月', unit: '台', subUnit: '', price: 1800, total: 72000, equipCode: '0101P01700', rfidCode: '10101P0170012024042005017XXXXXX0017', remark: '', supplier: '大华技术股份有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '3', name: '网络硬盘录像机 NVR-64', category: '监控设备', spec: 'NVR-64/64路', qty: 15, transferQty: 0, borrowQty: 0, produceDate: '2024-04-22', validDate: '2029-04-22', maintainPeriod: '12个月', unit: '台', subUnit: '', price: 8500, total: 127500, equipCode: '0101P01800', rfidCode: '10101P0180012024042205018XXXXXX0018', remark: '', supplier: '大华技术股份有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['状态类/临期30天'] },
    ]
  },
  {
    id: 'RK2024203', source: 'purchase', inboundNo: 'RK2024203',
    materialSource: '采购入库', location: 'ES003',
    inboundTime: '2024-06-15 09:30:00',
    operator: '马建国', status: 'pending', purchaseProject: '2024年应急装备采购项目', purchaseDate: '2024-06-01',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '强光搜索灯 SS-D', category: '照明设备', spec: 'SS-D/5000流明', qty: 25, transferQty: 0, borrowQty: 0, produceDate: '2024-06-01', validDate: '2027-06-01', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 1200, total: 30000, equipCode: '0101P01900', rfidCode: '10101P0190012024060105019XXXXXX0019', remark: '应急救援', supplier: '大华技术股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '2', name: '便携式发电机 FD-2K', category: '应急设备', spec: 'FD-2K/2KW', qty: 8, transferQty: 0, borrowQty: 0, produceDate: '2024-06-05', validDate: '2029-06-05', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 6500, total: 52000, equipCode: '0101P02000', rfidCode: '10101P0200012024060505020XXXXXX0020', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '3', name: '救生绳索 JS-30', category: '救援装备', spec: 'JS-30/30米', qty: 30, transferQty: 0, borrowQty: 0, produceDate: '2024-06-08', validDate: '2029-06-08', maintainPeriod: '12个月', unit: '根', subUnit: '', price: 850, total: 25500, equipCode: '0101P02100', rfidCode: '10101P0210012024060805021XXXXXX0021', remark: '', supplier: '华为技术有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
      { id: '4', name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', qty: 50, transferQty: 0, borrowQty: 0, produceDate: '2024-06-10', validDate: '2026-06-10', maintainPeriod: '6个月', unit: '个', subUnit: '', price: 320, total: 16000, equipCode: '0101P02200', rfidCode: '10101P0220012024061005022XXXXXX0022', remark: '过期提醒', supplier: '烽火通信科技股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
    ]
  },
  {
    id: 'RK2024204', source: 'purchase', inboundNo: 'RK2024204',
    materialSource: '采购入库', location: 'ES002',
    inboundTime: '2024-07-20 15:00:00',
    operator: '陈秀英', status: 'pending', purchaseProject: '2024年交通执法装备采购', purchaseDate: '2024-07-10',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '酒精测试仪 JJ-C8', category: '检测设备', spec: 'JJ-C8/高精度', qty: 20, transferQty: 0, borrowQty: 0, produceDate: '2024-07-15', validDate: '2026-07-15', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 3200, total: 64000, equipCode: '0101P02300', rfidCode: '10101P0230012024071505023XXXXXX0023', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '2', name: '测速仪 CS-R2', category: '检测设备', spec: 'CS-R2/雷达', qty: 12, transferQty: 0, borrowQty: 0, produceDate: '2024-07-18', validDate: '2027-07-18', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 12000, total: 144000, equipCode: '0101P02400', rfidCode: '10101P0240012024071805024XXXXXX0024', remark: '', supplier: '华为技术有限公司', location: 'ES002-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '3', name: '交通指挥棒 ZHB-L', category: '交通装备', spec: 'ZHB-L/LED', qty: 100, transferQty: 0, borrowQty: 0, produceDate: '2024-07-12', validDate: '2027-07-12', maintainPeriod: '3个月', unit: '根', subUnit: '', price: 65, total: 6500, equipCode: '0101P02500', rfidCode: '10101P0250012024071205025XXXXXX0025', remark: '', supplier: '大华技术股份有限公司', location: 'ES002-C', isFixedAsset: false, tags: ['活动类/双11备货'] },
    ]
  },

  // ===== 仓库调拨入库 x4 =====
  {
    id: 'RK2024301', source: 'transfer', inboundNo: 'RK2024301',
    materialSource: '仓库调拨', location: 'ES003',
    inboundTime: '2024-08-05 10:00:00',
    operator: '李志刚', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024301', senderUnit: '市局装备处', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '防弹盾牌 FDP-3', category: '防护装备', spec: 'FDP-3/三级', qty: 10, transferQty: 10, borrowQty: 0, produceDate: '2024-03-15', validDate: '2029-03-15', maintainPeriod: '12个月', unit: '面', subUnit: '', price: 3800, total: 38000, equipCode: '0101P02600', rfidCode: '10101P0260012024031505026XXXXXX0026', remark: '调拨至县局', supplier: '华为技术有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
  {
    id: 'RK2024302', source: 'transfer', inboundNo: 'RK2024302',
    materialSource: '仓库调拨', location: 'ES001',
    inboundTime: '2024-08-12 14:30:00',
    operator: '张秀英', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024302', senderUnit: '分局装备科', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '手持金属探测器 JT-8', category: '检测设备', spec: 'JT-8/高灵敏', qty: 18, transferQty: 18, borrowQty: 0, produceDate: '2024-05-10', validDate: '2027-05-10', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 980, total: 17640, equipCode: '0101P02700', rfidCode: '10101P0270012024051005027XXXXXX0027', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '2', name: 'X光安检机 XJ-S', category: '检测设备', spec: 'XJ-S/便携', qty: 3, transferQty: 3, borrowQty: 0, produceDate: '2024-05-15', validDate: '2029-05-15', maintainPeriod: '12个月', unit: '台', subUnit: '', price: 28000, total: 84000, equipCode: '0101P02800', rfidCode: '10101P0280012024062005028XXXXXX0028', remark: '贵重设备', supplier: '中兴通讯股份有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '3', name: '毒品检测仪 DP-5', category: '检测设备', spec: 'DP-5/拉曼', qty: 6, transferQty: 6, borrowQty: 0, produceDate: '2024-05-20', validDate: '2027-05-20', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 15000, total: 90000, equipCode: '0101P02900', rfidCode: '10101P0290012024070105029XXXXXX0029', remark: '禁毒支队', supplier: '华为技术有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
    ]
  },
  {
    id: 'RK2024303', source: 'transfer', inboundNo: 'RK2024303',
    materialSource: '仓库调拨', location: 'ES002',
    inboundTime: '2024-09-01 09:00:00',
    operator: '王建军', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024303', senderUnit: '省厅装备中心', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '无人机 X8-PS', category: '飞行装备', spec: 'X8-PS/警用版', qty: 4, transferQty: 4, borrowQty: 0, produceDate: '2024-08-10', validDate: '2027-08-10', maintainPeriod: '6个月', unit: '架', subUnit: '', price: 45000, total: 180000, equipCode: '0101P03000', rfidCode: '10101P0300012024081505030XXXXXX0030', remark: '', supplier: '华为技术有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '2', name: '无人机电池 DC-6S', category: '飞行装备', spec: 'DC-6S/6000mAh', qty: 16, transferQty: 16, borrowQty: 0, produceDate: '2024-08-15', validDate: '2027-08-15', maintainPeriod: '3个月', unit: '块', subUnit: '', price: 850, total: 13600, equipCode: '0101P03100', rfidCode: '10101P0310012024052005031XXXXXX0031', remark: '', supplier: '华为技术有限公司', location: 'ES002-B', isFixedAsset: false, tags: ['品类特征/易碎品'] },
      { id: '3', name: '遥控器 YK-PRO', category: '飞行装备', spec: 'YK-PRO/5km', qty: 4, transferQty: 4, borrowQty: 0, produceDate: '2024-08-12', validDate: '2027-08-12', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 3200, total: 12800, equipCode: '0101P03200', rfidCode: '10101P0320012024080105032XXXXXX0032', remark: '', supplier: '华为技术有限公司', location: 'ES002-C', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '4', name: '图传模块 TC-5G', category: '通信设备', spec: 'TC-5G/高清', qty: 4, transferQty: 4, borrowQty: 0, produceDate: '2024-08-18', validDate: '2027-08-18', maintainPeriod: '6个月', unit: '套', subUnit: '', price: 6800, total: 27200, equipCode: '0101P03300', rfidCode: '10101P0330012024081005033XXXXXX0033', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['状态类/临期30天'] },
    ]
  },
  {
    id: 'RK2024304', source: 'transfer', inboundNo: 'RK2024304',
    materialSource: '仓库调拨', location: 'ES003',
    inboundTime: '2024-09-18 11:00:00',
    operator: '刘桂芳', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024304', senderUnit: '市局交通支队', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 60, transferQty: 60, borrowQty: 0, produceDate: '2024-09-01', validDate: '2027-09-01', maintainPeriod: '3个月', unit: '件', subUnit: '', price: 45, total: 2700, equipCode: '0101P03400', rfidCode: '10101P0340012024090105034XXXXXX0034', remark: '', supplier: '大华技术股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '2', name: '交通锥 JT-L', category: '交通装备', spec: 'JT-L/70cm', qty: 80, transferQty: 80, borrowQty: 0, produceDate: '2024-09-05', validDate: '2027-09-05', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 35, total: 2800, equipCode: '0101P03500', rfidCode: '10101P0350012024080505035XXXXXX0035', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['活动类/双11备货'] },
    ]
  },

  // ===== 归还入库 x4 =====
  {
    id: 'RK2024401', source: 'return', inboundNo: 'RK2024401',
    materialSource: '归还入库', location: 'ES001',
    inboundTime: '2024-10-10 16:30:00',
    operator: '赵明辉', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024401', senderUnit: '刑侦支队', borrower: '李警官/刑侦支队', borrowTime: '2024-09-20', expectReturnDate: '2024-10-15',
    materials: [
      { id: '1', name: '数字取证工作站 FZ-WS', category: '取证设备', spec: 'FZ-WS/高性能', qty: 2, transferQty: 0, borrowQty: 2, produceDate: '2024-06-01', validDate: '2027-06-01', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 28000, total: 56000, equipCode: '0101P03600', rfidCode: '10101P0360012024090105036XXXXXX0036', remark: '取证完成', supplier: '中兴通讯股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
  {
    id: 'RK2024402', source: 'return', inboundNo: 'RK2024402',
    materialSource: '归还入库', location: 'ES002',
    inboundTime: '2024-10-20 09:00:00',
    operator: '孙建平', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024402', senderUnit: '反恐支队', borrower: '王警官/反恐支队', borrowTime: '2024-10-01', expectReturnDate: '2024-10-25',
    materials: [
      { id: '1', name: '防爆毯 FB-T3', category: '防爆装备', spec: 'FB-T3/双人', qty: 3, transferQty: 0, borrowQty: 3, produceDate: '2024-05-10', validDate: '2029-05-10', maintainPeriod: '12个月', unit: '条', subUnit: '', price: 15000, total: 45000, equipCode: '0101P03700', rfidCode: '10101P0370012024070105037XXXXXX0037', remark: '演练归还', supplier: '华为技术有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '2', name: '防爆服 FB-F2', category: '防爆装备', spec: 'FB-F2/搜爆', qty: 3, transferQty: 0, borrowQty: 3, produceDate: '2024-05-15', validDate: '2029-05-15', maintainPeriod: '12个月', unit: '套', subUnit: '', price: 22000, total: 66000, equipCode: '0101P03800', rfidCode: '10101P0380012024030105038XXXXXX0038', remark: '演练归还', supplier: '华为技术有限公司', location: 'ES002-B', isFixedAsset: false, tags: ['状态类/临期30天'] },
    ]
  },
  {
    id: 'RK2024403', source: 'return', inboundNo: 'RK2024403',
    materialSource: '归还入库', location: 'ES003',
    inboundTime: '2024-11-05 14:00:00',
    operator: '周雪梅', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024403', senderUnit: '网安支队', borrower: '陈警官/网安支队', borrowTime: '2024-10-25', expectReturnDate: '2024-11-10',
    materials: [
      { id: '1', name: '网络取证设备 WZ-8', category: '取证设备', spec: 'WZ-8/便携', qty: 2, transferQty: 0, borrowQty: 2, produceDate: '2024-08-01', validDate: '2027-08-01', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 18000, total: 36000, equipCode: '0101P03900', rfidCode: '10101P0390012024112005039XXXXXX0039', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '2', name: '数据恢复设备 HF-D', category: '取证设备', spec: 'HF-D/专业版', qty: 2, transferQty: 0, borrowQty: 2, produceDate: '2024-08-05', validDate: '2027-08-05', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 22000, total: 44000, equipCode: '0101P04000', rfidCode: '10101P0400012024112005040XXXXXX0040', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '3', name: '硬盘只读锁 ZD-L1', category: '取证设备', spec: 'ZD-L1/USB3', qty: 4, transferQty: 0, borrowQty: 4, produceDate: '2024-08-10', validDate: '2027-08-10', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 2800, total: 11200, equipCode: '0101P04100', rfidCode: '10101P0410012024120105041XXXXXX0041', remark: '', supplier: '华为技术有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
  {
    id: 'RK2024404', source: 'return', inboundNo: 'RK2024404',
    materialSource: '归还入库', location: 'ES001',
    inboundTime: '2024-11-20 10:30:00',
    operator: '郑国强', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: 'DB2024404', senderUnit: '交警总队', borrower: '林警官/交警总队', borrowTime: '2024-11-10', expectReturnDate: '2024-11-30',
    materials: [
      { id: '1', name: '便携式打印机 DY-B', category: '办公设备', spec: 'DY-B/蓝牙', qty: 5, transferQty: 0, borrowQty: 5, produceDate: '2024-09-15', validDate: '2027-09-15', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 650, total: 3250, equipCode: '0101P04200', rfidCode: '10101P0420012024100105042XXXXXX0042', remark: '', supplier: '大华技术股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '2', name: '移动硬盘 YD-2T', category: '存储设备', spec: 'YD-2T/加密', qty: 8, transferQty: 0, borrowQty: 8, produceDate: '2024-09-20', validDate: '2027-09-20', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 480, total: 3840, equipCode: '0101P04300', rfidCode: '10101P0430012024061005043XXXXXX0043', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '3', name: '执法记录仪充电器 CD-8', category: '充电设备', spec: 'CD-8/8口', qty: 3, transferQty: 0, borrowQty: 3, produceDate: '2024-09-25', validDate: '2027-09-25', maintainPeriod: '6个月', unit: '台', subUnit: '', price: 1200, total: 3600, equipCode: '0101P04400', rfidCode: '10101P0440012024112005044XXXXXX0044', remark: '', supplier: '海康威视数字技术股份有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '4', name: '车载支架 CZ-J', category: '车载装备', spec: 'CZ-J/通用', qty: 10, transferQty: 0, borrowQty: 10, produceDate: '2024-09-28', validDate: '2027-09-28', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 85, total: 850, equipCode: '0101P04500', rfidCode: '10101P0450012024112005045XXXXXX0045', remark: '', supplier: '大华技术股份有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['活动类/双11备货'] },
    ]
  },

  // ===== 捐赠入库 x4 =====
  {
    id: 'RK2024501', source: 'team', inboundNo: 'RK2024501',
    materialSource: '捐赠入库', location: 'ES003',
    inboundTime: '2024-12-05 09:00:00',
    operator: '何建国', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', qty: 5, transferQty: 0, borrowQty: 0, produceDate: '2024-11-01', validDate: '2027-11-01', maintainPeriod: '3个月', unit: '辆', subUnit: '', price: 28000, total: 140000, equipCode: '0101P04600', rfidCode: '10101P0460012024110105046XXXXXX0046', remark: '交警中队', supplier: '中兴通讯股份有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
  {
    id: 'RK2024502', source: 'team', inboundNo: 'RK2024502',
    materialSource: '捐赠入库', location: 'ES001',
    inboundTime: '2024-12-15 10:00:00',
    operator: '韩秀兰', status: 'done', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 20, transferQty: 0, borrowQty: 0, produceDate: '2024-11-15', validDate: '2029-11-15', maintainPeriod: '12个月', unit: '面', subUnit: '', price: 680, total: 13600, equipCode: '0101P04700', rfidCode: '10101P0470012024111505047XXXXXX0047', remark: '', supplier: '华为技术有限公司', location: 'ES001-A', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '2', name: '防暴头盔 FBK-H', category: '防暴装备', spec: 'FBK-H/透明面罩', qty: 20, transferQty: 0, borrowQty: 0, produceDate: '2024-11-20', validDate: '2029-11-20', maintainPeriod: '12个月', unit: '顶', subUnit: '', price: 450, total: 9000, equipCode: '0101P04800', rfidCode: '10101P0480012024031505048XXXXXX0048', remark: '', supplier: '华为技术有限公司', location: 'ES001-B', isFixedAsset: false, tags: ['状态类/临期30天'] },
      { id: '3', name: '防暴叉 FB-C', category: '防暴装备', spec: 'FB-C/不锈钢', qty: 15, transferQty: 0, borrowQty: 0, produceDate: '2024-11-25', validDate: '2029-11-25', maintainPeriod: '6个月', unit: '根', subUnit: '', price: 320, total: 4800, equipCode: '0101P04900', rfidCode: '10101P0490012024120105049XXXXXX0049', remark: '', supplier: '烽火通信科技股份有限公司', location: 'ES001-C', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
    ]
  },
  {
    id: 'RK2024503', source: 'team', inboundNo: 'RK2024503',
    materialSource: '捐赠入库', location: 'ES002',
    inboundTime: '2025-01-08 11:30:00',
    operator: '曹志强', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '巡逻车 PC-WL', category: '交通工具', spec: 'PC-WL/电动', qty: 3, transferQty: 0, borrowQty: 0, produceDate: '2024-12-10', validDate: '2027-12-10', maintainPeriod: '3个月', unit: '辆', subUnit: '', price: 35000, total: 105000, equipCode: '0101P05000', rfidCode: '10101P0500012024060105050XXXXXX0050', remark: '巡逻队', supplier: '中兴通讯股份有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '2', name: '喊话器 HS-S', category: '通信装备', spec: 'HS-S/50W', qty: 8, transferQty: 0, borrowQty: 0, produceDate: '2024-12-15', validDate: '2027-12-15', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 680, total: 5440, equipCode: '0101P05100', rfidCode: '10101P0510012024090105051XXXXXX0051', remark: '', supplier: '华为技术有限公司', location: 'ES002-B', isFixedAsset: false, tags: ['品类特征/易碎品'] },
      { id: '3', name: '警灯警报器 JL-A', category: '车载装备', spec: 'JL-A/红蓝', qty: 6, transferQty: 0, borrowQty: 0, produceDate: '2024-12-18', validDate: '2027-12-18', maintainPeriod: '6个月', unit: '套', subUnit: '', price: 2200, total: 13200, equipCode: '0101P05200', rfidCode: '10101P0520012024102005052XXXXXX0052', remark: '', supplier: '大华技术股份有限公司', location: 'ES002-C', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
      { id: '4', name: '行车记录仪 XD-4K', category: '车载装备', spec: 'XD-4K/前后双录', qty: 10, transferQty: 0, borrowQty: 0, produceDate: '2024-12-20', validDate: '2027-12-20', maintainPeriod: '3个月', unit: '台', subUnit: '', price: 850, total: 8500, equipCode: '0101P05300', rfidCode: '10101P0530012024112005053XXXXXX0053', remark: '', supplier: '海康威视数字技术股份有限公司', location: 'ES002-A', isFixedAsset: false, tags: ['状态类/临期30天'] },
    ]
  },
  {
    id: 'RK2024504', source: 'team', inboundNo: 'RK2024504',
    materialSource: '捐赠入库', location: 'ES003',
    inboundTime: '2025-01-20 08:00:00',
    operator: '田丽华', status: 'pending', purchaseProject: '', purchaseDate: '',
    mainSupplier: '',
    transferNo: '', senderUnit: '', borrower: '', borrowTime: '', expectReturnDate: '',
    materials: [
      { id: '1', name: '智能手环 SH-P', category: '智能装备', spec: 'SH-P/定位版', qty: 30, transferQty: 0, borrowQty: 0, produceDate: '2025-01-05', validDate: '2028-01-05', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 420, total: 12600, equipCode: '0101P05400', rfidCode: '10101P0540012024031505054XXXXXX0054', remark: '', supplier: '华为技术有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
      { id: '2', name: '智能眼镜 GJ-V', category: '智能装备', spec: 'GJ-V/AR版', qty: 10, transferQty: 0, borrowQty: 0, produceDate: '2025-01-08', validDate: '2028-01-08', maintainPeriod: '6个月', unit: '副', subUnit: '', price: 5800, total: 58000, equipCode: '0101P05500', rfidCode: '10101P0550012024010505055XXXXXX0055', remark: '', supplier: '中兴通讯股份有限公司', location: 'ES003-B', isFixedAsset: false, tags: ['活动类/双11备货'] },
      { id: '3', name: '智能胸牌 XP-S', category: '智能装备', spec: 'XP-S/NFC', qty: 50, transferQty: 0, borrowQty: 0, produceDate: '2025-01-10', validDate: '2028-01-10', maintainPeriod: '3个月', unit: '个', subUnit: '', price: 180, total: 9000, equipCode: '0101P05600', rfidCode: '10101P0560012024080105056XXXXXX0056', remark: '', supplier: '华为技术有限公司', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/易碎品'] },
    ]
  },
]

const fieldMeta: Record<InboundSource, { transferQty: boolean; borrowQty: boolean; produceDate: string; validDate: string; maintainPeriod: string }> = {
  initial: { transferQty: false, borrowQty: false, produceDate: '#', validDate: '', maintainPeriod: '' },
  purchase: { transferQty: false, borrowQty: false, produceDate: '', validDate: '', maintainPeriod: '' },
  transfer: { transferQty: true, borrowQty: false, produceDate: '#', validDate: '', maintainPeriod: '' },
  return:   { transferQty: false, borrowQty: true,  produceDate: '#', validDate: '#', maintainPeriod: '#' },
  team:     { transferQty: false, borrowQty: false, produceDate: '#', validDate: '#', maintainPeriod: '#' },
}

// 判断是否可以编辑
const canEdit = (r: InboundRecord) =>
  r.status === 'pending' && (r.source === 'initial' || r.source === 'purchase' || r.source === 'team')

export default function InboundPage({ onNavigate }: Props) {
  const [records, setRecords] = useState<InboundRecord[]>(inboundRecords)
  const [activeTab, setActiveTab] = useState<InboundSource>('initial')
  const [modalOpen, setModalOpen] = useState(false)
  const [historyModalOpen, setHistoryModalOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<InboundRecord | null>(null)

  // 编辑模式
  const [editMode, setEditMode] = useState(false)
  const [editingId, setEditingId] = useState('')

  // 预览弹窗
  const [previewOpen, setPreviewOpen] = useState(false)
  const [previewRecord, setPreviewRecord] = useState<InboundRecord | null>(null)

  // 二次确认弹窗
  const [submitConfirmOpen, setSubmitConfirmOpen] = useState(false)

  // 弹窗子状态
  const [importOpen, setImportOpen] = useState(false)
  const [rfidOpen, setRfidOpen] = useState(false)
  const [addMaterialOpen, setAddMaterialOpen] = useState(false)
  const [rfidRecognizeOpen, setRfidRecognizeOpen] = useState(false)
  const [onRfidRecognized, setOnRfidRecognized] = useState<((rfidCode: string) => void) | null>(null)
  const [rfidConnected, setRfidConnected] = useState(false)
  const [rfidDeviceName, setRfidDeviceName] = useState('')

  // ===== 表单状态 =====
  const [formInboundNo, setFormInboundNo] = useState('')
  const [formMaterialSource, setFormMaterialSource] = useState('')
  const [formLocation, setFormLocation] = useState('')
  const [formInboundTime, setFormInboundTime] = useState('')
  const [formOperator, setFormOperator] = useState('')
  const [formPurchaseProject, setFormPurchaseProject] = useState('')
  const [formPurchaseDate, setFormPurchaseDate] = useState('')
  const [formMainSupplier, setFormMainSupplier] = useState('')
  const [formTransferNo, setFormTransferNo] = useState('')
  const [formSenderUnit, setFormSenderUnit] = useState('')
  const [formBorrower, setFormBorrower] = useState('')
  const [formBorrowTime, setFormBorrowTime] = useState('')
  const [formExpectReturnDate, setFormExpectReturnDate] = useState('')
  const [formMaterials, setFormMaterials] = useState<MaterialItem[]>([])
  const [matRfidData, setMatRfidData] = useState<Record<string, string[]>>({})
  const [matExpandedRfid, setMatExpandedRfid] = useState<string | null>(null)

  const meta = fieldMeta[activeTab]

  const getWarehouseName = (id: string) => {
    for (const w of warehouseData) {
      if (w.id === id) return w.name
      if (w.children) for (const c of w.children) if (c.id === id) return c.name
    }
    return id
  }

  const resetForm = () => {
    const nextId = records.length + 1
    setFormInboundNo(`RK${new Date().getFullYear()}${String(nextId).padStart(4, '0')}`)
    setFormMaterialSource('')
    setFormLocation('')
    setFormInboundTime(new Date().toISOString().slice(0, 16))
    setFormOperator('')
    setFormPurchaseProject('')
    setFormPurchaseDate('')
    setFormTransferNo('')
    setFormSenderUnit('')
    setFormBorrower('')
    setFormBorrowTime('')
    setFormExpectReturnDate('')
    setFormMaterials([])
    setFormMainSupplier('')
    setMatRfidData({})
    setMatExpandedRfid(null)
    setEditMode(false)
    setEditingId('')
  }

  // 从记录加载表单（编辑）
  const loadFormFromRecord = (r: InboundRecord) => {
    setFormInboundNo(r.inboundNo)
    setFormMaterialSource(r.materialSource)
    setFormLocation(r.location)
    setFormInboundTime(r.inboundTime)
    setFormOperator(r.operator)
    setFormPurchaseProject(r.purchaseProject)
    setFormPurchaseDate(r.purchaseDate)
    setFormMainSupplier(r.mainSupplier)
    setFormTransferNo(r.transferNo)
    setFormSenderUnit(r.senderUnit)
    setFormBorrower(r.borrower)
    setFormBorrowTime(r.borrowTime)
    setFormExpectReturnDate(r.expectReturnDate)
    setFormMaterials(r.materials.map(m => ({ ...m })))
  }

  const addMaterialRow = (item?: MaterialItem) => setFormMaterials(prev => [...prev, item || emptyMaterial(formMainSupplier)])
  const removeMaterialRow = (index: number) => {
    const removedId = formMaterials[index]?.id
    setFormMaterials(prev => prev.filter((_, i) => i !== index))
    if (removedId) {
      setMatRfidData(prev => { const n = { ...prev }; delete n[removedId]; return n })
      if (matExpandedRfid === removedId) setMatExpandedRfid(null)
    }
  }

  const updateMaterial = (index: number, field: keyof MaterialItem, value: string | number | boolean) => {
    setFormMaterials(prev => prev.map((item, i) => {
      if (i !== index) return item
      const updated = { ...item, [field]: value }
      if (field === 'qty' || field === 'price') updated.total = (Number(updated.qty) || 0) * (Number(updated.price) || 0)
      return updated
    }))
    // qty变化时同步调整RFID列表长度
    if (field === 'qty') {
      const newQty = Number(value) || 0
      setFormMaterials(prev => {
        const item = prev[index]
        if (!item) return prev
        setMatRfidData(rfidPrev => {
          const current = rfidPrev[item.id] || []
          if (newQty > current.length) {
            // 增加：补空，第一个填入默认rfidCode
            const added = Array.from({ length: newQty - current.length }, (_, i) =>
              i === 0 && current.length === 0 ? item.rfidCode : ''
            )
            return { ...rfidPrev, [item.id]: [...current, ...added] }
          } else if (newQty < current.length) {
            // 减少：截断
            return { ...rfidPrev, [item.id]: current.slice(0, newQty) }
          }
          return rfidPrev
        })
        return prev
      })
    }
  }

  const getTotalAmount = () => formMaterials.reduce((s, m) => s + m.total, 0)

  // 提交入库（带二次确认）
  const handleSubmitRequest = () => {
    if (!formMaterialSource || !formLocation) { alert('请填写必填信息（物资来源、存储位置）'); return }
    if (formMaterials.length === 0) { alert('请至少添加一条物资明细'); return }
    if (formMaterials.some(m => !m.name || !m.qty)) { alert('请完善物资明细（物资名称、数量为必填）'); return }
    if (activeTab === 'purchase' && !formPurchaseProject.trim()) { alert('请输入采购项目名称'); return }
    if (activeTab === 'purchase' && !formPurchaseDate) { alert('请选择采购日期'); return }
    if (activeTab === 'purchase' && !formMainSupplier) { alert('请选择供应商'); return }
    if (formMaterials.some(m => !m.supplier)) { alert('请完善物资明细（供应商为必填）'); return }
    setSubmitConfirmOpen(true)
  }

  // 真正提交
  const handleSubmitConfirm = () => {
    setSubmitConfirmOpen(false)
    if (editMode && editingId) {
      setRecords(prev => prev.map(r => r.id === editingId ? {
        ...r,
        materialSource: formMaterialSource, location: formLocation,
        inboundTime: formInboundTime || new Date().toLocaleString('zh-CN', { hour12: false }),
        operator: formOperator || '当前用户',
        materials: formMaterials.map(m => ({ ...m, total: (m.qty || 0) * (m.price || 0) })),
        purchaseProject: formPurchaseProject, purchaseDate: formPurchaseDate,
        mainSupplier: formMainSupplier,
        transferNo: formTransferNo, senderUnit: formSenderUnit,
        borrower: formBorrower, borrowTime: formBorrowTime, expectReturnDate: formExpectReturnDate,
      } : r))
      alert('修改成功')
    } else {
      const newRecord: InboundRecord = {
        id: formInboundNo, source: activeTab, inboundNo: formInboundNo,
        materialSource: formMaterialSource, location: formLocation,
        inboundTime: formInboundTime || new Date().toLocaleString('zh-CN', { hour12: false }),
        operator: formOperator || '当前用户', status: 'pending',
        materials: formMaterials.map(m => ({ ...m, total: (m.qty || 0) * (m.price || 0) })),
        purchaseProject: formPurchaseProject, purchaseDate: formPurchaseDate,
        mainSupplier: formMainSupplier,
        transferNo: formTransferNo, senderUnit: formSenderUnit,
        borrower: formBorrower, borrowTime: formBorrowTime, expectReturnDate: formExpectReturnDate,
      }
      setRecords(prev => [newRecord, ...prev])
      alert('入库单已创建')
    }
    setModalOpen(false)
    setEditMode(false)
    setEditingId('')
    resetForm()
  }

  // 点击确认 → 打开预览弹窗
  const handlePreviewConfirm = (r: InboundRecord) => {
    setPreviewRecord(r)
    setPreviewOpen(true)
  }

  // 预览弹窗中确认入库
  const handleRealConfirm = () => {
    if (previewRecord) {
      setRecords(prev => prev.map(r => r.id === previewRecord.id ? { ...r, status: 'done' as const } : r))
      alert(`入库单 ${previewRecord.id} 已确认入库`)
    }
    setPreviewOpen(false)
    setPreviewRecord(null)
  }

  const handleDelete = (r: InboundRecord) => {
    if (confirm(`确定删除入库单 ${r.id} 吗？`)) {
      setRecords(prev => prev.filter(item => item.id !== r.id))
      alert('删除成功')
    }
  }

  const handleEdit = (r: InboundRecord) => {
    setEditMode(true)
    setEditingId(r.id)
    loadFormFromRecord(r)
    setModalOpen(true)
  }

  const showAddButton = activeTab === 'initial' || activeTab === 'purchase' || activeTab === 'team'
  const filteredRecords = records.filter(r => r.source === activeTab)

  // ===== 渲染基本信息字段 =====
  const renderBasicFields = () => {
    const col3 = 'grid grid-cols-3 gap-4'
    const commonFields = (
      <>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资来源 <span className="text-red-400">*</span></label>
          <select className="form-input w-full" value={formMaterialSource} onChange={e => setFormMaterialSource(e.target.value)}>
            <option value="">请选择</option>
            {materialSourceOptions.map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置 <span className="text-red-400">*</span></label>
          <select className="form-input w-full" value={formLocation} onChange={e => setFormLocation(e.target.value)}>
            <option value="">请选择</option>
            {flattenWarehouses(warehouseData).map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>入库时间 <span className="text-red-400">*</span></label>
          <input type="datetime-local" className="form-input w-full" value={formInboundTime} onChange={e => setFormInboundTime(e.target.value)} />
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
          <input className="form-input w-full" placeholder="请输入经办人" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
        </div>
      </>
    )
    const inboundNoField = (
      <div>
        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>入库单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
        <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={formInboundNo} />
      </div>
    )
    switch (activeTab) {
      case 'purchase':
        return (<><div className={col3}>{inboundNoField}<div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购项目名称 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入采购项目名称" value={formPurchaseProject} onChange={e => setFormPurchaseProject(e.target.value)} /></div><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购日期 <span className="text-red-400">*</span></label><input type="date" className="form-input w-full" value={formPurchaseDate} onChange={e => setFormPurchaseDate(e.target.value)} /></div></div><div className={col3}><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商 <span className="text-red-400">*</span></label><select className="form-input w-full" value={formMainSupplier} onChange={e => { setFormMainSupplier(e.target.value); setFormMaterials(prev => prev.map(m => m.supplier ? m : { ...m, supplier: e.target.value })) }}><option value="">请选择供应商</option>{supplierOptions.map(s => <option key={s}>{s}</option>)}</select></div><div className="mt-4">{commonFields}</div></div></>)
      case 'transfer':
        return (<><div className={col3}><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="请输入调拨单号" value={formTransferNo} onChange={e => setFormTransferNo(e.target.value)} /></div><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发物单位 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="请输入发物单位" value={formSenderUnit} onChange={e => setFormSenderUnit(e.target.value)} /></div>{inboundNoField}</div><div className={`${col3} mt-4`}>{commonFields}</div></>)
      case 'return':
        return (<><div className={col3}><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>借用人/单位 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="请输入借用人/单位" value={formBorrower} onChange={e => setFormBorrower(e.target.value)} /></div><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>借用时间 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input type="date" className="form-input w-full" value={formBorrowTime} onChange={e => setFormBorrowTime(e.target.value)} /></div><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>预计归还日期 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input type="date" className="form-input w-full" value={formExpectReturnDate} onChange={e => setFormExpectReturnDate(e.target.value)} /></div></div><div className={`${col3} mt-4`}><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="请输入调拨单号" value={formTransferNo} onChange={e => setFormTransferNo(e.target.value)} /></div><div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发物单位 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="请输入发物单位" value={formSenderUnit} onChange={e => setFormSenderUnit(e.target.value)} /></div>{inboundNoField}</div><div className={`${col3} mt-4`}>{commonFields}</div></>)
      default:
        return (<div className={col3}>{inboundNoField}{commonFields}</div>)
    }
  }

  // ===== 渲染表格 =====
  const renderTableHeaders = () => {
    const h: any[] = []
    h.push(<th key="cb" className="w-10"><input type="checkbox"/></th>)
    h.push(<th key="no">入库单号</th>)
    h.push(<th key="src">物资来源</th>)
    if (activeTab === 'purchase') { h.push(<th key="proj">采购项目</th>, <th key="pdate">采购日期</th>) }
    if (activeTab === 'transfer') { h.push(<th key="tno">调拨单号</th>, <th key="sunit">发物单位</th>) }
    if (activeTab === 'return') { h.push(<th key="borrower">借用人/单位</th>, <th key="btime">借用时间</th>, <th key="ertn">预计归还</th>, <th key="tno">调拨单号</th>, <th key="sunit">发物单位</th>) }
    h.push(<th key="loc">存储位置</th>, <th key="ename">装备名称</th>, <th key="spec">规格型号</th>, <th key="tags">标签</th>)
    if (activeTab === 'transfer') h.push(<th key="tqty">调拨数量</th>)
    else if (activeTab === 'return') h.push(<th key="bqty">借用数量</th>)
    else h.push(<th key="qty">入库数量</th>)
    h.push(<th key="time">入库时间</th>, <th key="op">入库人</th>, <th key="status">状态</th>, <th key="act">操作</th>)
    return <tr>{h}</tr>
  }

  const renderTableRow = (r: InboundRecord) => {
    const c: any[] = []
    c.push(<td key="cb"><input type="checkbox"/></td>)
    c.push(<td key="no" className="font-mono text-xs font-medium">{r.inboundNo}</td>)
    c.push(<td key="src"><span className="tag tag-blue text-xs">{r.materialSource}</span></td>)
    if (activeTab === 'purchase') { c.push(<td key="proj" className="text-xs max-w-[150px] truncate">{r.purchaseProject || '-'}</td>, <td key="pdate" className="text-xs">{r.purchaseDate || '-'}</td>) }
    if (activeTab === 'transfer') { c.push(<td key="tno" className="font-mono text-xs">{r.transferNo || '-'}</td>, <td key="sunit" className="text-xs">{r.senderUnit || '-'}</td>) }
    if (activeTab === 'return') { c.push(<td key="borrower" className="text-xs">{r.borrower || '-'}</td>, <td key="btime" className="text-xs">{r.borrowTime || '-'}</td>, <td key="ertn" className="text-xs">{r.expectReturnDate || '-'}</td>, <td key="tno2" className="font-mono text-xs">{r.transferNo || '-'}</td>, <td key="sunit2" className="text-xs">{r.senderUnit || '-'}</td>) }
    c.push(<td key="loc" className="text-xs">{r.location ? getWarehouseName(r.location) : '-'}</td>, <td key="ename">{r.materials[0]?.name || '-'}</td>, <td key="spec" className="text-xs">{r.materials[0]?.spec || '-'}</td>, <td key="tags" className="text-xs"><TagBadges tags={r.materials[0]?.tags || []} maxShow={2} /></td>)
    if (activeTab === 'transfer') c.push(<td key="tqty" className="font-mono text-xs">{r.materials[0]?.transferQty || 0}</td>)
    else if (activeTab === 'return') c.push(<td key="bqty" className="font-mono text-xs">{r.materials[0]?.borrowQty || 0}</td>)
    else c.push(<td key="qty" className="font-mono text-xs">{r.materials[0]?.qty || 0}</td>)
    c.push(<td key="time" className="text-xs">{r.inboundTime || '-'}</td>, <td key="op">{r.operator}</td>)
    c.push(<td key="status"><span className={`tag text-xs ${statusLabels[r.status].tag}`}>{statusLabels[r.status].label}</span></td>)
    c.push(
      <td key="act">
        <div className="flex items-center gap-2 flex-wrap">
          {r.status === 'pending' && <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => handlePreviewConfirm(r)}>确认</button>}
          {canEdit(r) && <button className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => handleEdit(r)}>修改</button>}
          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedRecord(r); setDetailOpen(true) }}>详情</button>
          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDelete(r)}>删除</button>
        </div>
      </td>
    )
    return <tr key={r.id}>{c}</tr>
  }

  // ===== RFID识别功能 =====
  const handleRfidRecognize = (callback: (rfidCode: string) => void) => {
    setOnRfidRecognized(() => callback)
    setRfidRecognizeOpen(true)
  }

  const handleRfidScanComplete = (rfidCode: string) => {
    if (onRfidRecognized) {
      onRfidRecognized(rfidCode)
      setOnRfidRecognized(null)
    }
    const match = rfidMaterialDB.find(r => r.rfidCode === rfidCode)
    if (match && rfidOpen) {
      const item = emptyMaterial()
      item.rfidCode = match.rfidCode
      item.name = match.name
      item.category = match.category
      item.spec = match.spec
      item.equipCode = match.equipCode
      item.supplier = match.supplier
      item.price = 0
      item.qty = 1
      item.total = 0
      addMaterialRow(item)
      setRfidOpen(false)
      setRfidConnected(false)
      setRfidDeviceName('')
      alert(`扫描成功：${match.name}`)
    } else if (match && rfidRecognizeOpen) {
      setRfidRecognizeOpen(false)
      setRfidConnected(false)
      setRfidDeviceName('')
    }
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>仓库管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>入库管理</span>
      </div>

      {/* 页签 */}
      <div className="flex items-center gap-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
        {sourceTabs.map(tab => (
          <button key={tab.key} onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2.5 text-sm font-medium transition-all border-b-2 -mb-px ${activeTab === tab.key ? 'border-blue-500 text-blue-600' : 'border-transparent hover:text-gray-700'}`}>
            {tab.label}
          </button>
        ))}
      </div>

      {/* 搜索 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>入库单号</label><input className="form-input w-36" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资来源</label><select className="form-input w-32"><option>全部</option>{materialSourceOptions.map(o => <option key={o}>{o}</option>)}</select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置</label><WarehouseTreeSelect warehouseData={warehouseData} value="" onChange={() => {}} showAll allLabel="全部" className="w-32" /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-32" placeholder="请输入..." /></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex items-center justify-between">
        {showAddButton ? (
          <div className="flex items-center gap-2">
            <button className="btn-primary flex items-center gap-1" onClick={() => { resetForm(); setModalOpen(true) }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              物资入库
            </button>
            <button className="btn-default flex items-center gap-1 text-xs" onClick={() => setHistoryModalOpen(true)}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              历史库存整理
            </button>
          </div>
        ) : <div />}
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filteredRecords.length} 条记录</span>
      </div>

      {/* 数据表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>{renderTableHeaders()}</thead>
          <tbody>{filteredRecords.map(r => renderTableRow(r))}</tbody>
        </table>
      </div>

      {/* ===== 主弹窗：入库单 ===== */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1200px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{editMode ? `修改入库单 - ${formInboundNo}` : `${sourceLabels[activeTab]} - 物资入库单`}</h3>
              <button onClick={() => { setModalOpen(false); setEditMode(false); setEditingId(''); }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* 基本信息 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#52c41a' }}>基本信息</h4>
                {renderBasicFields()}
              </div>

              {/* 物资明细 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细 <span style={{ color: 'var(--text-secondary)' }}>({formMaterials.length} 种)</span></h4>
                  <div className="flex gap-2">
                    <button onClick={() => setImportOpen(true)} className="text-xs px-3 py-1.5 rounded-lg border border-green-200 text-green-600 hover:bg-green-50 transition-colors flex items-center gap-1">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                      导入Excel
                    </button>
                    <button onClick={() => setRfidOpen(true)} className="text-xs px-3 py-1.5 rounded-lg border border-purple-200 text-purple-600 hover:bg-purple-50 transition-colors flex items-center gap-1">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                      RFID扫描
                    </button>
                    <button onClick={() => setAddMaterialOpen(true)} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors flex items-center gap-1">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      添加物资
                    </button>
                  </div>
                </div>

                {formMaterials.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <p className="text-sm">暂无物资，请通过上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border border-separate border-spacing-0" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 min-w-[32px]" style={{ borderColor: 'var(--border-color)' }}>#</th>
                          <th className="border p-2 min-w-[120px]" style={{ borderColor: 'var(--border-color)' }}>物资名称 <span className="text-red-400">*</span></th>
                          <th className="border p-2 min-w-[100px]" style={{ borderColor: 'var(--border-color)' }}>物资类别(二级) <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 min-w-[100px]" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                          <th className="border p-2 min-w-[72px]" style={{ borderColor: 'var(--border-color)' }}>入库数量 <span className="text-red-400">*</span></th>
                          {meta.transferQty && <th className="border p-2 min-w-[72px]" style={{ borderColor: 'var(--border-color)' }}>调拨数量 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>}
                          {meta.borrowQty && <th className="border p-2 min-w-[72px]" style={{ borderColor: 'var(--border-color)' }}>借用数量 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>}
                          <th className="border p-2 min-w-[110px]" style={{ borderColor: 'var(--border-color)' }}>生产日期 {meta.produceDate === '#' && <span style={{ color: 'var(--text-disabled)' }}>#</span>}</th>
                          <th className="border p-2 min-w-[110px]" style={{ borderColor: 'var(--border-color)' }}>有效期 {meta.validDate === '#' && <span style={{ color: 'var(--text-disabled)' }}>#</span>}</th>
                          <th className="border p-2 min-w-[80px]" style={{ borderColor: 'var(--border-color)' }}>保养期 {meta.maintainPeriod === '#' && <span style={{ color: 'var(--text-disabled)' }}>#</span>}</th>
                          <th className="border p-2 min-w-[80px]" style={{ borderColor: 'var(--border-color)' }}>单位 <span className="text-red-400">*</span></th>
                          <th className="border p-2 min-w-[90px]" style={{ borderColor: 'var(--border-color)' }}>单价(¥) <span className="text-red-400">*</span></th>
                          <th className="border p-2 min-w-[90px]" style={{ borderColor: 'var(--border-color)' }}>总价(¥) <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 min-w-[120px]" style={{ borderColor: 'var(--border-color)' }}>装备编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 min-w-[120px]" style={{ borderColor: 'var(--border-color)' }}>RFID编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 min-w-[140px]" style={{ borderColor: 'var(--border-color)' }}>存储位置 <span className="text-red-400">*</span></th>
                          <th className="border p-2 min-w-[80px]" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                          <th className="border p-2 min-w-[110px]" style={{ borderColor: 'var(--border-color)' }}>供应商 <span className="text-red-400">*</span></th>
                          <th className="border p-2 min-w-[40px] sticky right-0 bg-white z-10" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formMaterials.map((mat, idx) => {
                          const isRfidExpanded = matExpandedRfid === mat.id
                          const rfids = matRfidData[mat.id] || []
                          return (<>
                          <tr key={mat.id}>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="物资名称" value={mat.name} onChange={e => updateMaterial(idx, 'name', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="类别" value={mat.category} onChange={e => updateMaterial(idx, 'category', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="规格" value={mat.spec} onChange={e => updateMaterial(idx, 'spec', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={0} value={mat.qty || ''} onChange={e => updateMaterial(idx, 'qty', Number(e.target.value))} /></td>
                            {meta.transferQty && <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono bg-gray-50" type="number" min={0} value={mat.transferQty || ''} onChange={e => updateMaterial(idx, 'transferQty', Number(e.target.value))} /></td>}
                            {meta.borrowQty && <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono bg-gray-50" type="number" min={0} value={mat.borrowQty || ''} onChange={e => updateMaterial(idx, 'borrowQty', Number(e.target.value))} /></td>}
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" type="date" value={mat.produceDate} onChange={e => updateMaterial(idx, 'produceDate', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" type="date" value={mat.validDate} onChange={e => updateMaterial(idx, 'validDate', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center" placeholder="如3个月" value={mat.maintainPeriod} onChange={e => updateMaterial(idx, 'maintainPeriod', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                              <div className="flex flex-col gap-1">
                                <select className="w-full text-xs p-1 outline-none bg-transparent" value={mat.unit} onChange={e => { updateMaterial(idx, 'unit', e.target.value); if (e.target.value !== '箱') updateMaterial(idx, 'subUnit', '') }}>
                                  {unitOptions.map(u => <option key={u}>{u}</option>)}
                                </select>
                                {mat.unit === '箱' && (
                                  <select className="w-full text-xs p-1 outline-none bg-transparent text-blue-600" value={mat.subUnit} onChange={e => updateMaterial(idx, 'subUnit', e.target.value)}>
                                    <option value="">请选择</option>
                                    {subUnitOptions['箱'].map(s => <option key={s}>{s}</option>)}
                                  </select>
                                )}
                              </div>
                            </td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-right font-mono" type="number" min={0} value={mat.price || ''} onChange={e => updateMaterial(idx, 'price', Number(e.target.value))} /></td>
                            <td className="border p-2 text-right font-mono font-medium" style={{ borderColor: 'var(--border-color)' }}>¥{mat.total.toLocaleString()}</td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent font-mono" placeholder="装备编码" value={mat.equipCode} onChange={e => updateMaterial(idx, 'equipCode', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)', minWidth: mat.qty > 1 ? 120 : 80 }}>
                              {mat.qty <= 1 ? (
                                <div className="flex gap-1">
                                  <input className="w-full text-xs p-1 outline-none bg-transparent font-mono" placeholder="RFID" value={rfids[0] || mat.rfidCode} onChange={e => {
                                    setMatRfidData(prev => ({...prev, [mat.id]: [e.target.value]}))
                                    updateMaterial(idx, 'rfidCode', e.target.value)
                                  }} />
                                  <button className="text-blue-500 hover:text-blue-700 flex-shrink-0" title="RFID识别" onClick={() => handleRfidRecognize((code) => { setMatRfidData(prev => ({...prev, [mat.id]: [code]})); updateMaterial(idx, 'rfidCode', code) })}>
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                                  </button>
                                </div>
                              ) : (
                                <button className="text-xs px-2 py-1 rounded border hover:bg-gray-50 flex items-center gap-1 w-full justify-center" style={{ color: 'var(--primary-blue)', borderColor: '#bfdbfe' }} onClick={() => setMatExpandedRfid(isRfidExpanded ? null : mat.id)}>
                                  {isRfidExpanded ? '收起' : `展开填写 (${mat.qty}个)`}
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isRfidExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9"/></svg>
                                </button>
                              )}
                            </td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                              <WarehouseTreeSelect
                                warehouseData={formLocation ? warehouseData.filter(w => w.id === formLocation || w.parent === formLocation) : warehouseData}
                                value={mat.location}
                                onChange={val => updateMaterial(idx, 'location', val)}
                                className="w-full text-xs"
                              />
                            </td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="备注" value={mat.remark} onChange={e => updateMaterial(idx, 'remark', e.target.value)} /></td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                              <select className="w-full text-xs p-1 outline-none bg-transparent" value={mat.supplier} onChange={e => updateMaterial(idx, 'supplier', e.target.value)}>
                                <option value="">请选择</option>
                                {supplierOptions.map(s => <option key={s}>{s}</option>)}
                              </select>
                            </td>
                            <td className="border p-1 text-center sticky right-0 bg-white z-10" style={{ borderColor: 'var(--border-color)' }}>
                              <button onClick={() => removeMaterialRow(idx)} className="text-red-400 hover:text-red-600">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                              </button>
                            </td>
                          </tr>
                          {mat.qty > 1 && isRfidExpanded && (
                            <tr key={mat.id + '-rfid'}>
                              <td colSpan={19} className="p-0">
                                <div className="bg-gray-50 p-3 space-y-2">
                                  <div className="flex items-center justify-between mb-2">
                                    <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>{mat.name} — RFID编码列表</span>
                                    <button className="text-xs px-2 py-1 rounded border hover:bg-gray-100" style={{ color: 'var(--primary-blue)', borderColor: '#bfdbfe' }} onClick={() => {
                                      // 一键扫描填充所有空位
                                      const newRfids = rfids.map((r, i) => r || `${mat.rfidCode.substring(0, 20)}${String(Math.floor(Math.random() * 999999)).padStart(6, '0')}_${i + 1}`)
                                      setMatRfidData(prev => ({...prev, [mat.id]: newRfids}))
                                    }}>一键扫描填充</button>
                                  </div>
                                  {Array.from({ length: mat.qty }, (_, i) => (
                                    <div key={i} className="flex items-center gap-2">
                                      <span className="text-xs font-mono w-6 text-right flex-shrink-0" style={{ color: 'var(--text-secondary)' }}>{i + 1}.</span>
                                      <input className="form-input flex-1 font-mono text-[10px]" value={rfids[i] || ''} onChange={e => {
                                        const newRfids = [...rfids]
                                        newRfids[i] = e.target.value
                                        setMatRfidData(prev => ({...prev, [mat.id]: newRfids}))
                                      }} placeholder={`请输入第 ${i + 1} 个RFID编码`} />
                                      <button className="p-1 rounded hover:bg-gray-100 flex-shrink-0" title="扫描" onClick={() => {
                                        const prefix = mat.rfidCode.substring(0, 20) || '10101P00100120240315'
                                        const suffix = String(Math.floor(Math.random() * 999999)).padStart(6, '0')
                                        const newRfids = [...rfids]
                                        newRfids[i] = `${prefix}${suffix}`
                                        setMatRfidData(prev => ({...prev, [mat.id]: newRfids}))
                                      }}>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><rect x="7" y="7" width="10" height="10" rx="1"/></svg>
                                      </button>
                                    </div>
                                  ))}
                                </div>
                              </td>
                            </tr>
                          )}
                        </>)})}
                      </tbody>
                    </table>
                  </div>
                )}

                {formMaterials.length > 0 && (
                  <div className="mt-3 flex items-center justify-end gap-4">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合计品种：{formMaterials.length} 种</span>
                    <span className="text-sm font-mono font-bold">合计金额：¥{getTotalAmount().toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            {/* 底部按钮（去掉保存草稿） */}
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setModalOpen(false); setEditMode(false); setEditingId(''); }}>取消</button>
              <button className="btn-primary" onClick={handleSubmitRequest}>{editMode ? '保存修改' : '提交入库'}</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 入库单预览弹窗（点击确认时） ===== */}
      {previewOpen && previewRecord && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setPreviewOpen(false); setPreviewRecord(null); }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[560px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">物资入库单预览</h3>
              <button onClick={() => { setPreviewOpen(false); setPreviewRecord(null); }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              {/* 入库单信息 */}
              <div className="border rounded-lg p-4" style={{ borderColor: 'var(--border-color)' }}>
                <div className="text-center mb-4">
                  <h2 className="text-xl font-bold tracking-widest">物资入库单</h2>
                  <p className="text-xs mt-1 font-mono" style={{ color: 'var(--text-secondary)' }}>NO. {previewRecord.inboundNo}</p>
                </div>
                <div className="grid grid-cols-2 gap-y-2 gap-x-6 text-xs">
                  {[
                    { label: '入库类型', value: sourceLabels[previewRecord.source] },
                    { label: '物资来源', value: previewRecord.materialSource },
                    { label: '存储位置', value: previewRecord.location ? getWarehouseName(previewRecord.location) : '-' },
                    { label: '入库时间', value: previewRecord.inboundTime || '-' },
                                        { label: '经办人', value: previewRecord.operator },
                    ...(previewRecord.source === 'purchase' ? [{ label: '采购项目名称', value: previewRecord.purchaseProject || '-' }, { label: '采购日期', value: previewRecord.purchaseDate || '-' }, { label: '供应商', value: previewRecord.mainSupplier || '-' }] : []),
                    ...(previewRecord.source === 'transfer' ? [{ label: '调拨单号', value: previewRecord.transferNo || '-' }, { label: '发物单位', value: previewRecord.senderUnit || '-' }] : []),
                    ...(previewRecord.source === 'return' ? [{ label: '借用人/单位', value: previewRecord.borrower || '-' }, { label: '借用时间', value: previewRecord.borrowTime || '-' }, { label: '预计归还日期', value: previewRecord.expectReturnDate || '-' }] : []),
                  ].map(f => (
                    <div key={f.label} className="flex justify-between py-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 物资明细预览 */}
              <div>
                <h4 className="text-sm font-semibold mb-2">物资明细（{previewRecord.materials.length} 种）</h4>
                <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <table className="w-full text-xs">
                    <thead>
                      <tr style={{ background: 'var(--table-header-bg)' }}>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>#</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>数量</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>存储位置</th>
                      </tr>
                    </thead>
                    <tbody>
                      {previewRecord.materials.map((m, i) => (
                        <tr key={m.id}>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{i + 1}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{m.name}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{m.spec || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{m.qty} {m.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{m.price?.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono font-medium" style={{ borderColor: 'var(--border-color)' }}>¥{m.total?.toLocaleString()}</td>
                          <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{m.location ? getWarehouseName(m.location) : '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-2 text-right text-sm font-mono font-bold">
                  合计金额：¥{previewRecord.materials.reduce((s, m) => s + m.total, 0).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setPreviewOpen(false); setPreviewRecord(null); }}>取消</button>
              <button className="btn-primary" onClick={handleRealConfirm}>确认入库</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 二次确认弹窗（提交入库时） ===== */}
      {submitConfirmOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSubmitConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[420px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="text-center mb-5">
              <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center bg-yellow-50">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#faad14" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01"/></svg>
              </div>
              <h3 className="text-lg font-semibold">确认提交</h3>
              <p className="text-sm mt-2" style={{ color: 'var(--text-secondary)' }}>
                确认提交入库吗？
              </p>
              <div className="mt-3 bg-gray-50 rounded-lg p-3 text-left text-xs space-y-1.5">
                <p><span style={{ color: 'var(--text-secondary)' }}>入库单号：</span><span className="font-mono font-medium">{formInboundNo}</span></p>
                <p><span style={{ color: 'var(--text-secondary)' }}>物资种类：</span><span className="font-medium">{formMaterials.length} 种</span></p>
                <p><span style={{ color: 'var(--text-secondary)' }}>合计金额：</span><span className="font-mono font-bold" style={{ color: '#faad14' }}>¥{getTotalAmount().toLocaleString()}</span></p>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setSubmitConfirmOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSubmitConfirm}>确认</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 导入Excel弹窗 ===== */}
      {importOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setImportOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">导入Excel/CSV</h3>
              <button onClick={() => setImportOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors cursor-pointer"
                onClick={() => {
                  const imported: MaterialItem[] = [
                    { ...emptyMaterial(), name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色', qty: 50, unit: '台', price: 2800, total: 140000, supplier: '华为技术有限公司', location: formLocation ? getSelfAndChildren(formLocation)[0]?.id || '' : '', isFixedAsset: false, tags: ['状态类/临期30天', '品类特征/贵重仪器'] },
                    { ...emptyMaterial(), name: '对讲机 PD780G', category: '通信设备', spec: 'PD780G/U段', qty: 30, unit: '台', price: 1500, total: 45000, supplier: '烽火通信科技股份有限公司', location: formLocation ? getSelfAndChildren(formLocation)[0]?.id || '' : '', isFixedAsset: false, tags: ['状态类/临期30天'] },
                    { ...emptyMaterial(), name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 20, unit: '台', price: 1800, total: 36000, supplier: '海康威视数字技术股份有限公司', location: formLocation ? getSelfAndChildren(formLocation)[0]?.id || '' : '', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
                  ]
                  imported.forEach(m => { m.total = m.qty * m.price })
                  setFormMaterials(prev => [...prev, ...imported])
                  setImportOpen(false)
                  alert(`导入成功：${imported.length} 条物资明细`)
                }}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2" style={{ color: 'var(--text-secondary)' }}><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>
                <p className="text-sm font-medium mb-1">点击或拖拽文件上传</p>
                <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 .xlsx .xls .csv</p>
              </div>
              <div className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs font-medium mb-2" style={{ color: 'var(--text-secondary)' }}>Excel模板格式（必须包含以下列）：</p>
                <div className="flex flex-wrap gap-1">
                  {['物资名称*', '物资类别', '规格型号', '数量*', '单位*', '单价*', '供应商*', '生产日期', '有效期', '装备编码', 'RFID编码', '备注'].map(col => (
                    <span key={col} className="text-xs px-2 py-0.5 rounded border" style={{ borderColor: 'var(--border-color)', color: col.includes('*') ? '#ff4d4f' : 'var(--text-secondary)' }}>{col}</span>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-5">
              <button className="btn-default text-xs flex items-center gap-1" onClick={() => alert('模板下载功能待对接')}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
                下载模板
              </button>
              <button className="btn-default" onClick={() => setImportOpen(false)}>取消</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== RFID扫描弹窗 ===== */}
      {rfidOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setRfidOpen(false); setRfidConnected(false); setRfidDeviceName(''); }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[440px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">RFID设备连接</h3>
              <button onClick={() => { setRfidOpen(false); setRfidConnected(false); setRfidDeviceName(''); }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium mb-2" style={{ color: 'var(--text-secondary)' }}>可用设备列表</label>
                <div className="space-y-2">
                  {[
                    { id: 'RFID-A1', name: 'RFID-Reader-A1', port: 'COM3' },
                    { id: 'RFID-B2', name: 'RFID-Reader-B2', port: 'COM4' },
                    { id: 'RFID-SIM', name: '模拟扫描设备', port: 'SIM' },
                  ].map(dev => (
                    <label key={dev.id} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${rfidDeviceName === dev.name ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'}`}>
                      <input type="radio" name="rfidDevice" className="hidden" checked={rfidDeviceName === dev.name} onChange={() => { setRfidDeviceName(dev.name); setRfidConnected(false); }} />
                      <div className="w-8 h-8 rounded flex items-center justify-center" style={{ background: rfidDeviceName === dev.name ? '#e6e6ff' : '#f0f0f0' }}>
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={rfidDeviceName === dev.name ? '#722ed1' : 'var(--text-secondary)'} strokeWidth="2"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                      </div>
                      <div className="flex-1"><p className="text-sm font-medium">{dev.name}</p><p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{dev.port}</p></div>
                      {rfidConnected && rfidDeviceName === dev.name && <span className="text-xs text-green-600 font-medium">已连接</span>}
                    </label>
                  ))}
                </div>
              </div>
              {rfidConnected && (
                <div className="bg-purple-50 rounded-lg p-4 text-center">
                  <div className="w-12 h-12 rounded-full mx-auto mb-2 flex items-center justify-center" style={{ background: '#e6e6ff' }}>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#722ed1" strokeWidth="2" className="animate-pulse"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                  </div>
                  <p className="text-sm font-medium" style={{ color: '#722ed1' }}>已连接 {rfidDeviceName}</p>
                  <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>请将RFID标签靠近扫描器...</p>
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 mt-5">
              {rfidConnected && <button className="btn-default text-xs" onClick={() => { setRfidConnected(false); setRfidDeviceName(''); }}>断开</button>}
              <button className="btn-default" onClick={() => { setRfidOpen(false); setRfidConnected(false); setRfidDeviceName(''); }}>取消</button>
              {!rfidConnected ? (
                <button className="btn-primary" disabled={!rfidDeviceName} onClick={() => setRfidConnected(true)}>连接</button>
              ) : (
                <button className="btn-primary" onClick={() => { handleRfidScanComplete(rfidMaterialDB[Math.floor(Math.random() * rfidMaterialDB.length)].rfidCode) }}>开始扫描</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===== 添加物资弹窗 ===== */}
      {addMaterialOpen && (
        <AddMaterialModal
          warehouseData={warehouseData}
          flattenWarehouses={flattenWarehouses}
          getSelfAndChildren={getSelfAndChildren}
          parentLocation={formLocation}
          rfidMaterialDB={rfidMaterialDB}
          onRfidRecognize={handleRfidRecognize}
          onRfidRecognizeOpen={() => setRfidRecognizeOpen(true)}
          onRfidRecognizeClose={() => setRfidRecognizeOpen(false)}
          rfidRecognizeOpen={rfidRecognizeOpen}
          onConfirm={(item) => { addMaterialRow(item); setAddMaterialOpen(false); }}
          onCancel={() => setAddMaterialOpen(false)}
        />
      )}

      {/* ===== RFID识别弹窗（从物资明细行触发） ===== */}
      {rfidRecognizeOpen && !rfidOpen && (
        <RfidRecognizeModal
          rfidMaterialDB={rfidMaterialDB}
          onClose={() => { setRfidRecognizeOpen(false); setOnRfidRecognized(null); }}
          onConfirm={(rfidCode) => {
            handleRfidScanComplete(rfidCode)
            setRfidRecognizeOpen(false)
            setOnRfidRecognized(null)
          }}
        />
      )}

      {/* ===== 详情抽屉 ===== */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative w-[520px] bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="font-semibold text-base">{sourceLabels[selectedRecord.source]} - 入库详情</h3>
              <button className="p-1 rounded hover:bg-gray-100" onClick={() => setDetailOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息</h4>
                <div className="space-y-2">
                  {[
                    { label: '入库单号', value: selectedRecord.inboundNo },
                    { label: '入库类型', value: sourceLabels[selectedRecord.source] },
                    { label: '物资来源', value: selectedRecord.materialSource },
                    { label: '存储位置', value: selectedRecord.location ? getWarehouseName(selectedRecord.location) : '-' },
                    { label: '入库时间', value: selectedRecord.inboundTime || '-' },
                                        { label: '经办人', value: selectedRecord.operator },
                    { label: '状态', value: statusLabels[selectedRecord.status].label },
                    ...(selectedRecord.source === 'purchase' ? [{ label: '采购项目名称', value: selectedRecord.purchaseProject || '-' }, { label: '采购日期', value: selectedRecord.purchaseDate || '-' }] : []),
                    ...(selectedRecord.source === 'transfer' ? [{ label: '调拨单号', value: selectedRecord.transferNo || '-' }, { label: '发物单位', value: selectedRecord.senderUnit || '-' }] : []),
                    ...(selectedRecord.source === 'return' ? [{ label: '借用人/单位', value: selectedRecord.borrower || '-' }, { label: '借用时间', value: selectedRecord.borrowTime || '-' }, { label: '预计归还日期', value: selectedRecord.expectReturnDate || '-' }, { label: '调拨单号', value: selectedRecord.transferNo || '-' }, { label: '发物单位', value: selectedRecord.senderUnit || '-' }] : []),
                  ].map(f => (
                    <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium text-sm">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>物资明细（{selectedRecord.materials.length} 种）</h4>
                {selectedRecord.materials.map((m, i) => (
                  <div key={m.id} className="border rounded-lg p-3 mb-2" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="text-xs font-medium mb-2">#{i + 1} {m.name}</div>
                    <div className="grid grid-cols-2 gap-y-1 gap-x-4 text-xs">
                      <span style={{ color: 'var(--text-secondary)' }}>规格型号：<span className="text-gray-900">{m.spec || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>物资类别：<span className="text-gray-900">{m.category || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>入库数量：<span className="text-gray-900">{m.qty} {m.unit}{m.subUnit ? `(${m.subUnit})` : ''}</span></span>
                      {selectedRecord.source === 'transfer' && <span style={{ color: 'var(--text-secondary)' }}>调拨数量：<span className="text-gray-900">{m.transferQty || 0}</span></span>}
                      {selectedRecord.source === 'return' && <span style={{ color: 'var(--text-secondary)' }}>借用数量：<span className="text-gray-900">{m.borrowQty || 0}</span></span>}
                      <span style={{ color: 'var(--text-secondary)' }}>单价：<span className="text-gray-900 font-mono">¥{m.price?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>总价：<span className="text-gray-900 font-mono font-medium">¥{m.total?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>存储位置：<span className="text-gray-900">{m.location ? getWarehouseName(m.location) : '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>供应商：<span className="text-gray-900">{m.supplier || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>生产日期：<span className="text-gray-900">{m.produceDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>有效期：<span className="text-gray-900">{m.validDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>保养期：<span className="text-gray-900">{m.maintainPeriod || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>装备编码：<span className="text-gray-900 font-mono">{m.equipCode || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>RFID编码：<RfidDisplay rfid={m.rfidCode} showFull /></span>
                      <span className="col-span-2" style={{ color: 'var(--text-secondary)' }}>标签：<TagBadges tags={m.tags || []} size="md" maxShow={5} /></span>
                      {m.remark && <span className="col-span-2" style={{ color: 'var(--text-secondary)' }}>备注：<span className="text-gray-900">{m.remark}</span></span>}
                    </div>
                    {/* RFID编码列表 - 数量>1时展示 */}
                    {(m.qty > 1 || (m.individualRFIDs && m.individualRFIDs.length > 1)) && (
                      <div className="mt-2 pt-2 border-t" style={{ borderColor: 'var(--border-color)' }}>
                        <RfidList
                          rfids={m.individualRFIDs || Array.from({ length: m.qty }, (_, i) => m.rfidCode.slice(0, -4) + String(i + 1).padStart(4, '0'))}
                          selectedRfid={m.rfidCode}
                          onSelect={(rfid) => { /* 可选中RFID */ }}
                        />
                      </div>
                    )}
                  </div>
                ))}
                <div className="text-right text-sm font-mono font-bold mt-2">
                  合计金额：¥{selectedRecord.materials.reduce((s, m) => s + m.total, 0).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="p-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 历史库存整理弹窗 ===== */}
      {historyModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setHistoryModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="text-center mb-5">
              <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center bg-blue-50">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
              </div>
              <h3 className="text-lg font-semibold">历史库存整理</h3>
              <p className="text-sm mt-3 px-4" style={{ color: 'var(--text-secondary)' }}>
                可通过整理工具按现有装备规范要求，生成文件实现历史库存的快速导入
              </p>
            </div>
            <div className="flex items-center justify-center gap-3">
              <button className="btn-default" onClick={() => setHistoryModalOpen(false)}>取消</button>
              <button className="btn-primary flex items-center gap-1" onClick={() => { alert('整理工具下载功能待对接'); setHistoryModalOpen(false) }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                下载整理工具
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ===== 添加物资弹窗组件 =====
interface AddMaterialModalProps {
  warehouseData: Warehouse[]
  flattenWarehouses: (nodes: Warehouse[], depth?: number) => { id: string; label: string }[]
  getSelfAndChildren: (nodeId: string) => { id: string; name: string }[]
  parentLocation: string
  rfidMaterialDB: RfidMaterial[]
  onRfidRecognize: (callback: (rfidCode: string) => void) => void
  onRfidRecognizeOpen: () => void
  onRfidRecognizeClose: () => void
  rfidRecognizeOpen: boolean
  onConfirm: (item: MaterialItem) => void
  onCancel: () => void
}

function AddMaterialModal({ warehouseData, flattenWarehouses, getSelfAndChildren, parentLocation, rfidMaterialDB, onConfirm, onCancel, onRfidRecognizeOpen }: AddMaterialModalProps) {
  const [item, setItem] = useState<MaterialItem>(emptyMaterial())
  const [localRfidOpen, setLocalRfidOpen] = useState(false)

  const update = (field: keyof MaterialItem, value: string | number | boolean) => {
    setItem(prev => {
      const updated = { ...prev, [field]: value }
      if (field === 'qty' || field === 'price') updated.total = (Number(updated.qty) || 0) * (Number(updated.price) || 0)
      return updated
    })
  }

  const handleConfirm = () => {
    if (!item.name || !item.qty) { alert('请填写必填项（物资名称、入库数量）'); return }
    onConfirm(item)
  }

  const getWarehouseName = (id: string) => {
    for (const w of warehouseData) { if (w.id === id) return w.name; if (w.children) for (const c of w.children) if (c.id === id) return c.name; }
    return id
  }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onCancel} />
      <div className="relative bg-white rounded-xl shadow-2xl w-[560px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
          <h3 className="text-lg font-semibold">新建入库物资</h3>
          <button onClick={onCancel} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
        </div>
        <div className="p-6 space-y-3 overflow-y-auto flex-1">
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入物资名称" value={item.name} onChange={e => update('name', e.target.value)} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别(二级) <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full" placeholder="物资类别" value={item.category} onChange={e => update('category', e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规格型号</label><input className="form-input w-full" placeholder="规格型号" value={item.spec} onChange={e => update('spec', e.target.value)} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>入库数量 <span className="text-red-400">*</span></label><input className="form-input w-full text-center font-mono" type="number" min={0} placeholder="0" value={item.qty || ''} onChange={e => update('qty', Number(e.target.value))} /></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>生产日期</label><input type="date" className="form-input w-full" value={item.produceDate} onChange={e => update('produceDate', e.target.value)} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>有效期</label><input type="date" className="form-input w-full" value={item.validDate} onChange={e => update('validDate', e.target.value)} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养期</label><input className="form-input w-full text-center" placeholder="如3个月" value={item.maintainPeriod} onChange={e => update('maintainPeriod', e.target.value)} /></div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单位 <span className="text-red-400">*</span></label>
              <select className="form-input w-full" value={item.unit} onChange={e => { update('unit', e.target.value); if (e.target.value !== '箱') update('subUnit', '') }}>
                {['个', '台', '根', '箱'].map(u => <option key={u}>{u}</option>)}
              </select>
              {item.unit === '箱' && (
                <select className="form-input w-full mt-1 text-xs text-blue-600" value={item.subUnit} onChange={e => update('subUnit', e.target.value)}>
                  <option value="">请选择</option>
                  {['个/1箱', '台/1箱', '根/1箱'].map(s => <option key={s}>{s}</option>)}
                </select>
              )}
            </div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单价(¥) <span className="text-red-400">*</span></label><input className="form-input w-full text-right font-mono" type="number" min={0} placeholder="0" value={item.price || ''} onChange={e => update('price', Number(e.target.value))} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>总价(¥) <span style={{ color: 'var(--text-disabled)' }}>#</span></label><div className="form-input w-full text-right font-mono bg-gray-50 flex items-center justify-end">¥{item.total.toLocaleString()}</div></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></label><input className="form-input w-full font-mono text-xs" placeholder="装备编码" value={item.equipCode} onChange={e => update('equipCode', e.target.value)} /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>RFID编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
              <div className="flex gap-1">
                <input className="form-input flex-1 font-mono text-xs" placeholder="RFID编码" value={item.rfidCode} onChange={e => update('rfidCode', e.target.value)} />
                <button className="px-2 rounded border border-blue-200 text-blue-600 hover:bg-blue-50 flex items-center" title="识别" onClick={() => { onRfidRecognizeOpen(); setLocalRfidOpen(true); }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                </button>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置 <span className="text-red-400">*</span></label>
              <WarehouseTreeSelect warehouseData={parentLocation ? warehouseData.filter(w => w.id === parentLocation || w.parent === parentLocation) : warehouseData} value={item.location} onChange={val => update('location', val)} />
            </div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商 <span className="text-red-400">*</span></label>
              <select className="form-input w-full" value={item.supplier} onChange={e => update('supplier', e.target.value)}>
                <option value="">请选择</option>
                {['华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司', '中兴通讯股份有限公司', '大华技术股份有限公司'].map(s => <option key={s}>{s}</option>)}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>固定资产</label>
              <select className="form-input w-full" value={item.isFixedAsset ? '是' : '否'} onChange={e => update('isFixedAsset', e.target.value === '是')}>
                <option value="否">否</option>
                <option value="是">是</option>
              </select>
            </div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label><textarea className="form-input w-full text-sm" rows={2} placeholder="备注信息..." value={item.remark} onChange={e => update('remark', e.target.value)} /></div>
          </div>
        </div>
        <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
          <button className="btn-default" onClick={onCancel}>取消</button>
          <button className="btn-primary" onClick={handleConfirm}>确认添加</button>
        </div>
      </div>

      {/* 内嵌RFID识别弹窗 */}
      {localRfidOpen && (
        <RfidRecognizeModal
          rfidMaterialDB={rfidMaterialDB}
          onClose={() => setLocalRfidOpen(false)}
          onConfirm={(rfidCode) => {
            const match = rfidMaterialDB.find(r => r.rfidCode === rfidCode)
            if (match) {
              setItem(prev => ({ ...prev, rfidCode: match.rfidCode, name: match.name, category: match.category, spec: match.spec, equipCode: match.equipCode, supplier: match.supplier }))
            } else {
              setItem(prev => ({ ...prev, rfidCode: rfidCode }))
            }
            setLocalRfidOpen(false)
          }}
        />
      )}
    </div>
  )
}

// ===== RFID识别弹窗组件 =====
interface RfidRecognizeModalProps {
  rfidMaterialDB: RfidMaterial[]
  onClose: () => void
  onConfirm: (rfidCode: string) => void
}

function RfidRecognizeModal({ rfidMaterialDB, onClose, onConfirm }: RfidRecognizeModalProps) {
  const [connected, setConnected] = useState(false)
  const [deviceName, setDeviceName] = useState('')
  const [scanned, setScanned] = useState(false)
  const [scanResult, setScanResult] = useState<RfidMaterial | null>(null)

  const handleConnect = () => { setConnected(true) }
  const handleScan = () => {
    const random = rfidMaterialDB[Math.floor(Math.random() * rfidMaterialDB.length)]
    setScanResult(random)
    setScanned(true)
  }

  return (
    <div className="fixed inset-0 z-[80] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative bg-white rounded-xl shadow-2xl w-[420px] p-6 animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">RFID识别</h3>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
        </div>
        {!connected ? (
          <div className="space-y-3">
            <label className="block text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>选择RFID设备</label>
            <div className="space-y-2">
              {[{ id: 'SIM', name: '模拟扫描设备', port: 'SIM' }].map(dev => (
                <label key={dev.id} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-all ${deviceName === dev.name ? 'border-purple-500 bg-purple-50' : 'border-gray-200 hover:border-gray-300'}`}>
                  <input type="radio" name="rfidDev" className="hidden" checked={deviceName === dev.name} onChange={() => setDeviceName(dev.name)} />
                  <div className="w-8 h-8 rounded flex items-center justify-center" style={{ background: deviceName === dev.name ? '#e6e6ff' : '#f0f0f0' }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={deviceName === dev.name ? '#722ed1' : 'var(--text-secondary)'} strokeWidth="2"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
                  </div>
                  <div className="flex-1"><p className="text-sm font-medium">{dev.name}</p><p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{dev.port}</p></div>
                </label>
              ))}
            </div>
          </div>
        ) : !scanned ? (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full mx-auto mb-3 flex items-center justify-center" style={{ background: '#e6e6ff' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#722ed1" strokeWidth="2" className="animate-pulse"><path d="M3 7v5a2 2 0 002 2h2M21 7v5a2 2 0 01-2 2h-2M3 17h18M8 14v3m4-3v3m4-3v3M12 3v8"/></svg>
            </div>
            <p className="text-sm font-medium" style={{ color: '#722ed1' }}>已连接 {deviceName}</p>
            <p className="text-xs mt-2" style={{ color: 'var(--text-secondary)' }}>请将RFID标签靠近扫描器...</p>
          </div>
        ) : (
          <div className="text-center py-4">
            <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center bg-green-100">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="3"><path d="M20 6L9 17l-5-5"/></svg>
            </div>
            <p className="text-sm font-medium text-green-600">扫描成功</p>
            {scanResult && (
              <div className="mt-3 bg-gray-50 rounded-lg p-3 text-left text-xs space-y-1">
                <p><span style={{ color: 'var(--text-secondary)' }}>RFID编码：</span><span className="font-mono">{scanResult.rfidCode}</span></p>
                <p><span style={{ color: 'var(--text-secondary)' }}>物资名称：</span>{scanResult.name}</p>
                <p><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span>{scanResult.spec}</p>
                <p><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{scanResult.equipCode}</span></p>
              </div>
            )}
          </div>
        )}
        <div className="flex items-center justify-end gap-3 mt-5">
          <button className="btn-default" onClick={onClose}>取消</button>
          {!connected ? <button className="btn-primary" disabled={!deviceName} onClick={handleConnect}>连接</button> : !scanned ? <button className="btn-primary" onClick={handleScan}>开始扫描</button> : <button className="btn-primary" onClick={() => { if (scanResult) onConfirm(scanResult.rfidCode); }}>确认</button>}
        </div>
      </div>
    </div>
  )
}
