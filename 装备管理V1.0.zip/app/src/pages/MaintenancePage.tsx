import { useState } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type MaintainCycle = '日保养' | '周保养' | '月保养' | '季度保养' | '年度保养'
type MaintainType = '预防性保养' | '故障保养' | '定期保养' | '季节性保养'
type RunStatus = '正常' | '异常' | '待观察'
type Severity = '一般' | '严重' | '紧急'

/* ================================================================
   库存装备数据源（与报修管理完全一致）
   ================================================================ */
const stockMaterials = [
  { name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', unit: '台', equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', supplier: '华为技术有限公司', qty: 50, produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', price: 2800, total: 140000, remark: '期初盘点' },
  { name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', unit: '台', equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', supplier: '烽火通信科技股份有限公司', qty: 30, produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', price: 1500, total: 45000, remark: '' },
  { name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', unit: '台', equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', supplier: '海康威视数字技术股份有限公司', qty: 100, produceDate: '2024-02-20', validDate: '2027-02-20', maintainPeriod: '6个月', price: 1800, total: 180000, remark: '批量采购' },
  { name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', unit: '件', equipCode: '0101P00300', rfidCode: '10101P0030012024021010004XXXXXX0004', supplier: '华为技术有限公司', qty: 20, produceDate: '2024-01-10', validDate: '2029-01-10', maintainPeriod: '12个月', price: 3200, total: 64000, remark: '从市局调拨' },
  { name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', unit: '顶', equipCode: '0101P00400', rfidCode: '10101P0040012024031505005XXXXXX0005', supplier: '中兴通讯股份有限公司', qty: 15, produceDate: '2024-01-15', validDate: '2028-01-15', maintainPeriod: '6个月', price: 2600, total: 39000, remark: '任务结束归还' },
  { name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', unit: '根', equipCode: '0101P00600', rfidCode: '10101P0060012024031505006XXXXXX0006', supplier: '大华技术股份有限公司', qty: 40, produceDate: '2024-03-01', validDate: '2027-03-01', maintainPeriod: '6个月', price: 350, total: 14000, remark: '派出所配发' },
  { name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', unit: '面', equipCode: '0101P04700', rfidCode: '10101P0470012024111505009XXXXXX0009', supplier: '华为技术有限公司', qty: 20, produceDate: '2024-11-15', validDate: '2029-11-15', maintainPeriod: '3个月', price: 680, total: 13600, remark: '' },
  { name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', unit: '台', equipCode: '0101P01600', rfidCode: '10101P0160012024041505010XXXXXX0010', supplier: '海康威视数字技术股份有限公司', qty: 60, produceDate: '2024-04-15', validDate: '2027-04-15', maintainPeriod: '3个月', price: 3500, total: 210000, remark: '指挥中心' },
  { name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', unit: '根', equipCode: '0101P01000', rfidCode: '10101P0100012024010805011XXXXXX0011', supplier: '中兴通讯股份有限公司', qty: 45, produceDate: '2024-01-08', validDate: '2029-01-08', maintainPeriod: '3个月', price: 380, total: 17100, remark: '' },
  { name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', unit: '个', equipCode: '0101P02200', rfidCode: '10101P0220012024061005012XXXXXX0012', supplier: '烽火通信科技股份有限公司', qty: 30, produceDate: '2024-06-10', validDate: '2027-06-10', maintainPeriod: '6个月', price: 320, total: 9600, remark: '' },
  { name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', unit: '件', equipCode: '0101P03400', rfidCode: '10101P0340012024090105007XXXXXX0007', supplier: '大华技术股份有限公司', qty: 60, produceDate: '2024-09-01', validDate: '2027-09-01', maintainPeriod: '3个月', price: 45, total: 2700, remark: '' },
  { name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', unit: '辆', equipCode: '0101P04600', rfidCode: '10101P0460012024110105008XXXXXX0008', supplier: '中兴通讯股份有限公司', qty: 5, produceDate: '2024-11-01', validDate: '2027-11-01', maintainPeriod: '6个月', price: 28000, total: 140000, remark: '交警中队' },
]

const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))

/* ================================================================
   接口定义
   ================================================================ */
interface MaintainItem {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  unit: string
  produceDate: string
  validDate: string
  maintainPeriod: string
  price: number
  total: number
  equipCode: string
  rfidCode: string
  supplier: string
  remark: string
  rfidList?: string[] // 多个RFID编码
}

interface Consumable {
  id: string
  name: string
  qty: number
  unit: string
  remark: string
}

interface AbnormalIssue {
  description: string
  severity: Severity
  tempMeasure: string
}

interface MaintainRecord {
  id: string
  maintainType: MaintainType
  maintainCycle: MaintainCycle
  maintainTime: string
  nextMaintainTime: string
  operator: string // 经办人
  materials: MaintainItem[]
  maintainItems: string[]
  workDescription: string
  consumables: Consumable[]
  abnormalIssue?: AbnormalIssue
  runStatus: RunStatus
  existingProblems: string
  handleResult: string
  remark: string
}

const maintainItemsOptions = ['清洁', '检测', '调试', '耗材更换', '故障排查', '参数校准', '润滑', '紧固']

const cycleDays: Record<MaintainCycle, number> = {
  '日保养': 1, '周保养': 7, '月保养': 30, '季度保养': 90, '年度保养': 365,
}

function nextMaintainDate(baseDate: string, cycle: MaintainCycle): string {
  if (!baseDate) return ''
  const d = new Date(baseDate)
  d.setDate(d.getDate() + cycleDays[cycle])
  return d.toISOString().slice(0, 10)
}

/* ================================================================
   样例数据（含物资明细和多RFID）
   ================================================================ */
function makeMat(index: number, qty: number, override?: Partial<MaintainItem>): MaintainItem {
  const s = stockMaterials[index % stockMaterials.length]
  const rfidList = Array.from({ length: qty }, (_, i) => i === 0 ? s.rfidCode : `${s.rfidCode.substring(0, 20)}${String(Math.floor(Math.random() * 999999)).padStart(6, '0')}_${i + 1}`)
  return {
    id: `MAT-${Date.now()}-${index}`,
    name: s.name, category: s.category, spec: s.spec,
    qty, unit: s.unit,
    produceDate: s.produceDate, validDate: s.validDate,
    maintainPeriod: s.maintainPeriod,
    price: s.price, total: s.price * qty,
    equipCode: s.equipCode,
    rfidCode: s.rfidCode,
    supplier: s.supplier,
    remark: s.remark,
    rfidList,
    ...override,
  }
}

const demoRecords: MaintainRecord[] = [
  {
    id: 'MB20240315001', maintainType: '定期保养', maintainCycle: '月保养',
    maintainTime: '2024-03-15', nextMaintainTime: '2024-04-14', operator: '张建国',
    materials: [makeMat(0, 2)],
    maintainItems: ['清洁', '检测', '调试'],
    workDescription: '对设备外壳进行清洁，检测电池电量及信号强度，调试音量及屏幕亮度参数。',
    consumables: [{ id: 'c1', name: '清洁布', qty: 2, unit: '块', remark: '防静电布' }],
    runStatus: '正常', existingProblems: '无', handleResult: '保养完成，设备运行正常',
    remark: '下次注意检查充电口磨损情况',
  },
  {
    id: 'MB20240315002', maintainType: '预防性保养', maintainCycle: '季度保养',
    maintainTime: '2024-03-14', nextMaintainTime: '2024-06-12', operator: '李卫国',
    materials: [makeMat(3, 3)],
    maintainItems: ['检测', '清洁'],
    workDescription: '检查防弹层完整性，清洁外层织物，检查魔术贴粘贴效果。',
    consumables: [],
    abnormalIssue: { description: '左肩带魔术贴粘性下降', severity: '一般', tempMeasure: '已用备用魔术贴临时加固' },
    runStatus: '待观察', existingProblems: '左肩带魔术贴老化', handleResult: '临时加固处理，待配件到货后更换',
    remark: '需跟进肩带配件采购进度',
  },
  {
    id: 'MB20240314003', maintainType: '故障保养', maintainCycle: '周保养',
    maintainTime: '2024-03-14', nextMaintainTime: '2024-03-21', operator: '王志强',
    materials: [makeMat(1, 1)],
    maintainItems: ['故障排查', '调试', '参数校准'],
    workDescription: '排查通话杂音问题，检查发现天线接口松动，重新紧固后校准频率参数。',
    consumables: [{ id: 'c2', name: '天线密封圈', qty: 1, unit: '个', remark: '老化更换' }],
    abnormalIssue: { description: '通话时出现间歇性杂音', severity: '严重', tempMeasure: '紧固天线接口，暂时消除杂音' },
    runStatus: '正常', existingProblems: '天线接口存在松动隐患', handleResult: '紧固处理，建议下次保养重点关注',
    remark: '',
  },
  {
    id: 'MB20240313004', maintainType: '定期保养', maintainCycle: '年度保养',
    maintainTime: '2024-03-13', nextMaintainTime: '2025-03-13', operator: '赵明华',
    materials: [makeMat(11, 1)],
    maintainItems: ['检测', '润滑', '紧固', '耗材更换'],
    workDescription: '全面检测发动机及制动系统，更换机油、机滤，润滑链条，紧固各连接螺栓。',
    consumables: [
      { id: 'c3', name: '机油', qty: 2, unit: '升', remark: '全合成' },
      { id: 'c4', name: '机滤', qty: 1, unit: '个', remark: '' },
    ],
    runStatus: '正常', existingProblems: '无', handleResult: '年度保养完成，各项性能指标正常',
    remark: '下次年度保养前建议做一次中期检查',
  },
  {
    id: 'MB20240312005', maintainType: '季节性保养', maintainCycle: '季度保养',
    maintainTime: '2024-03-12', nextMaintainTime: '2024-06-10', operator: '陈晓东',
    materials: [makeMat(4, 5)],
    maintainItems: ['清洁', '检测'],
    workDescription: '清洁头盔内衬及外壳，检查悬挂系统完整性，检查夜视仪支架稳固性。',
    consumables: [],
    runStatus: '正常', existingProblems: '无', handleResult: '保养完成',
    remark: '夏季高温注意内衬清洁频率',
  },
  {
    id: 'MB20240310006', maintainType: '定期保养', maintainCycle: '月保养',
    maintainTime: '2024-03-10', nextMaintainTime: '2024-04-09', operator: '刘建华',
    materials: [makeMat(6, 2)],
    maintainItems: ['清洁', '检测'],
    workDescription: '清洁盾牌表面污渍及标识，检查把手牢固性，检查观察窗透明度。',
    consumables: [],
    abnormalIssue: { description: '观察窗有轻微划痕，影响视线', severity: '一般', tempMeasure: '已记录，不影响当前使用' },
    runStatus: '待观察', existingProblems: '观察窗轻微划痕', handleResult: '继续使用，计划下次更换观察窗',
    remark: '',
  },
]

/* ================================================================
   主组件
   ================================================================ */
export default function MaintenancePage({ onNavigate }: Props) {
  const [records, setRecords] = useState<MaintainRecord[]>(demoRecords)
  const [qEquipName, setQEquipName] = useState('')
  const [qEquipCode, setQEquipCode] = useState('')
  const [qType, setQType] = useState('')
  const [qOperator, setQOperator] = useState('')
  const [qDateStart, setQDateStart] = useState('')
  const [qDateEnd, setQDateEnd] = useState('')

  const [addOpen, setAddOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [detailRecord, setDetailRecord] = useState<MaintainRecord | null>(null)

  // 新增表单 state
  const [formMaintainType, setFormMaintainType] = useState<MaintainType>('定期保养')
  const [formMaintainCycle, setFormMaintainCycle] = useState<MaintainCycle>('月保养')
  const [formMaintainTime, setFormMaintainTime] = useState('')
  const [formOperator, setFormOperator] = useState('')
  const [formMaterials, setFormMaterials] = useState<MaintainItem[]>([])
  const [matExpandedRfid, setMatExpandedRfid] = useState<string | null>(null)
  const [matRfidData, setMatRfidData] = useState<Record<string, string[]>>({})
  const [formItems, setFormItems] = useState<string[]>([])
  const [formWorkDesc, setFormWorkDesc] = useState('')
  const [formConsumables, setFormConsumables] = useState<Consumable[]>([])
  const [formHasIssue, setFormHasIssue] = useState(false)
  const [formIssueDesc, setFormIssueDesc] = useState('')
  const [formIssueSeverity, setFormIssueSeverity] = useState<Severity>('一般')
  const [formIssueTemp, setFormIssueTemp] = useState('')
  const [formRunStatus, setFormRunStatus] = useState<RunStatus>('正常')
  const [formExistingProblems, setFormExistingProblems] = useState('')
  const [formHandleResult, setFormHandleResult] = useState('')
  const [formRemark, setFormRemark] = useState('')

  // 库存选择弹窗 state
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: typeof stockMaterials[0]; qty: number }[]>([])

  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    return true
  })

  const resetForm = () => {
    setFormMaintainType('定期保养'); setFormMaintainCycle('月保养')
    setFormMaintainTime(''); setFormOperator('')
    setFormMaterials([]); setFormItems([]); setFormWorkDesc('')
    setFormConsumables([])
    setFormHasIssue(false); setFormIssueDesc(''); setFormIssueSeverity('一般'); setFormIssueTemp('')
    setFormRunStatus('正常'); setFormExistingProblems(''); setFormHandleResult(''); setFormRemark('')
    setMatExpandedRfid(null)
    setMatRfidData({})
  }

  const handleSave = () => {
    if (!formMaintainTime || !formOperator) {
      alert('请填写必填项（保养时间、经办人）')
      return
    }
    if (formMaterials.length === 0) {
      alert('请至少添加一件物资')
      return
    }
    // RFID完整性校验：数量>2的物资，所有RFID最后4位必须已填写
    for (const m of formMaterials) {
      if (m.qty > 2 && m.rfidList) {
        for (let i = 0; i < m.rfidList.length; i++) {
          const rfid = m.rfidList[i]
          const suffix = rfid.substring(rfid.length - 4)
          if (!suffix || suffix.length < 4 || !/^\d{4}$/.test(suffix)) {
            alert(`【${m.name}】的第 ${i + 1} 个RFID编码最后4位未填写完整，请补充后保存`)
            setMatExpandedRfid(m.id)
            return
          }
        }
      }
    }
    const newRecord: MaintainRecord = {
      id: `MB${formMaintainTime.replace(/-/g, '')}${String(records.length + 1).padStart(3, '0')}`,
      maintainType: formMaintainType, maintainCycle: formMaintainCycle,
      maintainTime: formMaintainTime,
      nextMaintainTime: nextMaintainDate(formMaintainTime, formMaintainCycle),
      operator: formOperator,
      materials: formMaterials,
      maintainItems: formItems, workDescription: formWorkDesc,
      consumables: formConsumables,
      abnormalIssue: formHasIssue ? { description: formIssueDesc, severity: formIssueSeverity, tempMeasure: formIssueTemp } : undefined,
      runStatus: formRunStatus, existingProblems: formExistingProblems,
      handleResult: formHandleResult, remark: formRemark,
    }
    setRecords(prev => [newRecord, ...prev])
    setAddOpen(false)
    resetForm()
  }

  const handleDelete = (id: string) => {
    if (confirm('确定删除该保养记录吗？')) {
      setRecords(prev => prev.filter(r => r.id !== id))
      if (detailRecord?.id === id) setDetailOpen(false)
    }
  }

  const toggleItem = (item: string) => {
    setFormItems(prev => prev.includes(item) ? prev.filter(i => i !== item) : [...prev, item])
  }

  const addConsumable = () => {
    setFormConsumables(prev => [...prev, { id: `c-${Date.now()}`, name: '', qty: 1, unit: '', remark: '' }])
  }

  const updateConsumable = (index: number, field: keyof Consumable, value: string | number) => {
    setFormConsumables(prev => prev.map((c, i) => i === index ? { ...c, [field]: value } : c))
  }

  const removeConsumable = (index: number) => {
    setFormConsumables(prev => prev.filter((_, i) => i !== index))
  }

  // 库存选择
  const toggleStockSelect = (stock: typeof stockMaterials[0]) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.name === stock.name)
      if (exists) return prev.filter(p => p.stock.name !== stock.name)
      return [...prev, { stock, qty: 1 }]
    })
  }

  const updateSelectedQty = (name: string, newQty: number) => {
    const item = stockMaterials.find(s => s.name === name)
    if (item && newQty > item.qty) { alert('申请数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.name === name ? { ...p, qty: Math.max(1, newQty) } : p))
  }

  const confirmStockItems = () => {
    const newItems: MaintainItem[] = selectedStockItems.map((s, i) => {
      const prefix = s.stock.rfidCode.substring(0, s.stock.rfidCode.length - 4)
      const rfidList = Array.from({ length: s.qty }, (_, j) => {
        if (s.qty <= 2) {
          // 数量<=2时自动生成完整RFID
          return j === 0 ? s.stock.rfidCode : `${prefix}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`
        } else {
          // 数量>2时，第一个填完整的，其余最后4位留空让用户手动填写
          return j === 0 ? s.stock.rfidCode : `${prefix}`
        }
      })
      return {
        id: `MAT-${Date.now()}-${i}`,
        name: s.stock.name, category: s.stock.category, spec: s.stock.spec,
        qty: s.qty, unit: s.stock.unit,
        produceDate: s.stock.produceDate, validDate: s.stock.validDate,
        maintainPeriod: s.stock.maintainPeriod,
        price: s.stock.price, total: s.stock.price * s.qty,
        equipCode: s.stock.equipCode,
        rfidCode: s.stock.rfidCode,
        supplier: s.stock.supplier,
        remark: s.stock.remark,
        rfidList,
      }
    })
    setFormMaterials(prev => [...prev, ...newItems])
    setStockModalOpen(false)
    setSelectedStockItems([])
    setStockSearchName(''); setStockSearchCategory('')
  }

  const totalPrice = formMaterials.reduce((sum, m) => sum + m.total, 0)

  const filtered = records.filter(r => {
    if (qEquipName && !r.materials.some(m => m.name.includes(qEquipName))) return false
    if (qEquipCode && !r.materials.some(m => m.equipCode.toLowerCase().includes(qEquipCode.toLowerCase()))) return false
    if (qType && r.maintainType !== qType) return false
    if (qOperator && !r.operator.includes(qOperator)) return false
    if (qDateStart && r.maintainTime < qDateStart) return false
    if (qDateEnd && r.maintainTime > qDateEnd) return false
    return true
  })

  // 获取RFID显示文本
  const getRfidDisplay = (mat: MaintainItem): string => {
    const rfids = mat.rfidList || [mat.rfidCode]
    if (rfids.length === 1) return rfids[0]
    return `${rfids[0]}... (+${rfids.length - 1})`
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
          返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>保养管理</span>
      </div>

      {/* 操作栏 */}
      <div className="flex items-center justify-between">
        <button className="btn-primary text-sm" onClick={() => { resetForm(); setAddOpen(true) }}>+ 新增保养记录</button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filtered.length} 条记录</span>
      </div>

      {/* 查询区域 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-36 text-sm" placeholder="模糊查询" value={qEquipName} onChange={e => setQEquipName(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编号</label><input className="form-input w-36 text-sm font-mono" placeholder="请输入" value={qEquipCode} onChange={e => setQEquipCode(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养类型</label><select className="form-input w-32 text-sm" value={qType} onChange={e => setQType(e.target.value)}><option value="">全部</option><option>预防性保养</option><option>故障保养</option><option>定期保养</option><option>季节性保养</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人</label><input className="form-input w-28 text-sm" placeholder="请输入" value={qOperator} onChange={e => setQOperator(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养时间</label><div className="flex items-center gap-1"><input className="form-input w-28 text-sm" type="date" value={qDateStart} onChange={e => setQDateStart(e.target.value)} /><span style={{ color: 'var(--text-disabled)' }}>~</span><input className="form-input w-28 text-sm" type="date" value={qDateEnd} onChange={e => setQDateEnd(e.target.value)} /></div></div>
          <div className="flex gap-2 ml-auto"><button className="btn-default text-sm" onClick={() => { setQEquipName(''); setQEquipCode(''); setQType(''); setQOperator(''); setQDateStart(''); setQDateEnd('') }}>重置</button><button className="btn-primary text-sm">查询</button></div>
        </div>
      </div>

      {/* 表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>序号</th><th>保养编号</th><th>保养类型</th><th>保养周期</th><th>保养时间</th><th>经办人</th><th>物资明细</th><th>RFID编号</th><th>装备状态</th><th>异常问题</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr key={r.id}>
                <td className="font-mono text-xs">{i + 1}</td>
                <td className="font-mono text-xs">{r.id}</td>
                <td><span className="text-xs px-2 py-0.5 rounded" style={{ background: '#e6f7ff', color: '#1890ff' }}>{r.maintainType}</span></td>
                <td>{r.maintainCycle}</td>
                <td>{r.maintainTime}</td>
                <td>{r.operator}</td>
                <td className="text-xs">{r.materials.map(m => `${m.name}(${m.qty}${m.unit})`).join(', ')}</td>
                <td>
                  {r.materials.map((m, mi) => (
                    <div key={m.id} className="text-xs font-mono" title={m.rfidList?.join('\n') || m.rfidCode}>
                      {getRfidDisplay(m)}
                    </div>
                  ))}
                </td>
                <td><span className={`tag text-xs ${r.runStatus === '正常' ? 'tag-green' : r.runStatus === '异常' ? 'tag-red' : 'tag-yellow'}`}>{r.runStatus}</span></td>
                <td>{r.abnormalIssue ? <span className="text-xs px-2 py-0.5 rounded" style={{ background: '#fff2f0', color: '#ff4d4f' }}>有</span> : <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDetailRecord(r); setDetailOpen(true) }}>详情</button>
                    <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDelete(r.id)}>删除</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={11} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
          </tbody>
        </table>
      </div>

      {/* ===== 新增保养记录弹窗 ===== */}
      {addOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAddOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1000px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增保养记录</h3>
              <button onClick={() => setAddOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* 基本信息 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#1890ff' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息 <span className="text-xs font-normal" style={{ color: 'var(--text-disabled)' }}>- 必填项标 *</span></h4>
                <div className="grid grid-cols-5 gap-4">
                  <div>
                    <label className="block text-xs mb-1">保养编号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={`MB${formMaintainTime ? formMaintainTime.replace(/-/g, '') : 'YYYYMMDD'}${String(records.length + 1).padStart(3, '0')}`} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1">保养类型 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full text-sm" value={formMaintainType} onChange={e => setFormMaintainType(e.target.value as MaintainType)}><option>预防性保养</option><option>故障保养</option><option>定期保养</option><option>季节性保养</option></select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1">保养时间 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" type="date" value={formMaintainTime} onChange={e => setFormMaintainTime(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1">经办人 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1">下次保养时间</label>
                    <input className="form-input w-full bg-gray-50" readOnly value={nextMaintainDate(formMaintainTime, formMaintainCycle)} />
                  </div>
                </div>
              </div>

              {/* 物资明细 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细</h4>
                  <div className="flex items-center gap-3">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合计品种：<strong style={{ color: 'var(--primary-blue)' }}>{formMaterials.length}</strong> 种 | 合计金额：<strong style={{ color: 'var(--primary-blue)' }}>¥{totalPrice.toLocaleString()}</strong></span>
                    <button onClick={() => { setSelectedStockItems([]); setStockModalOpen(true) }} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 添加物资</button>
                  </div>
                </div>
                {formMaterials.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 w-6">#</th>
                          <th className="border p-2">物资名称</th>
                          <th className="border p-2">物资类别</th>
                          <th className="border p-2">规格型号</th>
                          <th className="border p-2 w-16">数量</th>
                          <th className="border p-2">生产日期</th>
                          <th className="border p-2">有效期</th>
                          <th className="border p-2">保养期</th>
                          <th className="border p-2 w-8">单位</th>
                          <th className="border p-2 w-16">单价</th>
                          <th className="border p-2 w-16">总价</th>
                          <th className="border p-2">装备编码</th>
                          <th className="border p-2">RFID编码</th>
                          <th className="border p-2">供应商</th>
                          <th className="border p-2">备注</th>
                          <th className="border p-2 w-8">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formMaterials.map((item, idx) => {
                          const isExpanded = matExpandedRfid === item.id
                          const rfidList = item.rfidList || [item.rfidCode]
                          // 获取RFID前缀（去掉最后4位）
                          const getPrefix = (rfid: string) => rfid.substring(0, Math.max(0, rfid.length - 4))
                          const prefix = getPrefix(rfidList[0] || item.rfidCode)
                          return (
                            <>
                              <tr key={item.id}>
                                <td className="border p-2 text-center font-mono">{idx + 1}</td>
                                <td className="border p-2 font-medium">{item.name}</td>
                                <td className="border p-2">{item.category}</td>
                                <td className="border p-2">{item.spec}</td>
                                <td className="border p-2 text-center font-mono">{item.qty}</td>
                                <td className="border p-2">{item.produceDate}</td>
                                <td className="border p-2">{item.validDate}</td>
                                <td className="border p-2">{item.maintainPeriod}</td>
                                <td className="border p-2 text-center">{item.unit}</td>
                                <td className="border p-2 text-right font-mono">¥{item.price.toLocaleString()}</td>
                                <td className="border p-2 text-right font-mono">¥{item.total.toLocaleString()}</td>
                                <td className="border p-2 font-mono">{item.equipCode}</td>
                                <td className="border p-2" style={{ minWidth: item.qty > 2 ? 120 : 60 }}>
                                  {item.qty <= 2 ? (
                                    <span className="font-mono text-[10px]" title={rfidList.join('\n')}>{getRfidDisplay(item)}</span>
                                  ) : (
                                    <button className="text-xs px-2 py-1 rounded border hover:bg-gray-50 flex items-center gap-1 w-full justify-center" style={{ color: 'var(--primary-blue)', borderColor: '#bfdbfe' }} onClick={() => setMatExpandedRfid(isExpanded ? null : item.id)}>
                                      {isExpanded ? '收起' : `展开填写 (${item.qty}个)`}
                                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}><polyline points="6 9 12 15 18 9"/></svg>
                                    </button>
                                  )}
                                </td>
                                <td className="border p-2">{item.supplier}</td>
                                <td className="border p-2">{item.remark || '-'}</td>
                                <td className="border p-2 text-center">
                                  <button onClick={() => setFormMaterials(prev => prev.filter((_, i) => i !== idx))} className="text-red-400 hover:text-red-600">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                  </button>
                                </td>
                              </tr>
                              {item.qty > 2 && isExpanded && (
                                <tr key={item.id + '-rfid'}>
                                  <td colSpan={16} className="p-0">
                                    <div className="bg-gray-50 p-3 space-y-2">
                                      <div className="flex items-center justify-between mb-1">
                                        <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>{item.name} — RFID编码填写 <span className="text-red-400">*</span></span>
                                        <button className="text-xs px-2 py-1 rounded border hover:bg-gray-100 flex items-center gap-1" style={{ color: '#52c41a', borderColor: '#b7eb8f' }} onClick={() => {
                                          // RFID扫描：自动填充所有空位的最后4位
                                          const newList = rfidList.map((r, i) => {
                                            const p = getPrefix(r)
                                            const suffix = r.substring(r.length - 4)
                                            if (!suffix || suffix.length < 4 || !/^\d{4}$/.test(suffix)) {
                                              return `${p}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`
                                            }
                                            return r
                                          })
                                          setFormMaterials(prev => prev.map(m => m.id === item.id ? { ...m, rfidList: newList } : m))
                                        }}>
                                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 7V5a2 2 0 012-2h2M17 3h2a2 2 0 012 2v2M21 17v2a2 2 0 01-2 2h-2M7 21H5a2 2 0 01-2-2v-2"/><rect x="7" y="7" width="10" height="10" rx="1"/></svg>
                                          RFID扫描
                                        </button>
                                      </div>
                                      {Array.from({ length: item.qty }, (_, i) => {
                                        const fullRfid = rfidList[i] || prefix
                                        const currentSuffix = fullRfid.substring(fullRfid.length - 4)
                                        const hasValidSuffix = /^\d{4}$/.test(currentSuffix)
                                        return (
                                          <div key={i} className="flex items-center gap-2">
                                            <span className="text-xs font-mono w-6 text-right flex-shrink-0" style={{ color: 'var(--text-secondary)' }}>{i + 1}.</span>
                                            <code className="text-[10px] px-2 py-1 rounded bg-gray-200 font-mono flex-shrink-0" style={{ color: 'var(--text-secondary)' }}>{prefix}</code>
                                            <input
                                              className={`form-input w-20 font-mono text-center text-xs ${hasValidSuffix ? '' : 'border-red-300 bg-red-50'}`}
                                              maxLength={4}
                                              placeholder="____"
                                              value={hasValidSuffix ? currentSuffix : ''}
                                              onChange={e => {
                                                const val = e.target.value.replace(/\D/g, '').slice(0, 4)
                                                const newList = [...rfidList]
                                                newList[i] = `${prefix}${val.padEnd(4, '_')}`
                                                setFormMaterials(prev => prev.map(m => m.id === item.id ? { ...m, rfidList: newList } : m))
                                              }}
                                            />
                                            {!hasValidSuffix && <span className="text-xs text-red-400">需填写4位数字</span>}
                                          </div>
                                        )
                                      })}
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* 保养作业 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#52c41a' }}>保养作业</h4>
                <div className="mb-3">
                  <label className="block text-xs mb-2">保养项目</label>
                  <div className="flex flex-wrap gap-2">
                    {maintainItemsOptions.map(item => (
                      <button key={item} onClick={() => toggleItem(item)} className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${formItems.includes(item) ? 'border-green-400 bg-green-50 text-green-600' : 'border-gray-200 text-gray-500 hover:border-gray-300'}`}>{formItems.includes(item) ? '✓ ' : ''}{item}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="block text-xs mb-1">作业说明</label>
                  <textarea className="form-input w-full text-sm" rows={3} placeholder="描述本次保养的具体作业内容..." value={formWorkDesc} onChange={e => setFormWorkDesc(e.target.value)} />
                </div>
              </div>

              {/* 耗材使用 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#722ed1' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#722ed1' }}>耗材使用</h4>
                  <button onClick={addConsumable} className="text-xs px-2 py-1 rounded border hover:bg-gray-50" style={{ color: '#722ed1', borderColor: '#d3adf7' }}>+ 添加耗材</button>
                </div>
                {formConsumables.length === 0 ? (
                  <div className="text-center py-4 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}><p className="text-xs">未使用耗材，点击上方按钮添加</p></div>
                ) : (
                  <div className="space-y-2">
                    {formConsumables.map((c, i) => (
                      <div key={c.id} className="flex items-center gap-2">
                        <input className="form-input flex-1 text-sm" placeholder="耗材名称" value={c.name} onChange={e => updateConsumable(i, 'name', e.target.value)} />
                        <input className="form-input w-16 text-sm text-center" type="number" min={1} placeholder="数量" value={c.qty} onChange={e => updateConsumable(i, 'qty', Number(e.target.value))} />
                        <input className="form-input w-16 text-sm" placeholder="单位" value={c.unit} onChange={e => updateConsumable(i, 'unit', e.target.value)} />
                        <input className="form-input flex-1 text-sm" placeholder="备注" value={c.remark} onChange={e => updateConsumable(i, 'remark', e.target.value)} />
                        <button onClick={() => removeConsumable(i)} className="text-red-400 hover:text-red-600"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* 异常问题 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#ff4d4f' }}>
                <div className="flex items-center gap-3 mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#ff4d4f' }}>异常问题</h4>
                  <label className="flex items-center gap-1 text-xs cursor-pointer"><input type="checkbox" checked={formHasIssue} onChange={e => setFormHasIssue(e.target.checked)} /><span>发现异常</span></label>
                </div>
                {formHasIssue && (
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <label className="block text-xs mb-1">问题描述</label>
                      <input className="form-input w-full" placeholder="描述发现的异常问题..." value={formIssueDesc} onChange={e => setFormIssueDesc(e.target.value)} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1">严重程度</label>
                        <select className="form-input w-full" value={formIssueSeverity} onChange={e => setFormIssueSeverity(e.target.value as Severity)}><option>一般</option><option>严重</option><option>紧急</option></select>
                      </div>
                      <div>
                        <label className="block text-xs mb-1">临时处置措施</label>
                        <input className="form-input w-full" placeholder="临时处理措施..." value={formIssueTemp} onChange={e => setFormIssueTemp(e.target.value)} />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* 保养结果 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>保养结果</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1">装备运行状态</label>
                    <select className="form-input w-full" value={formRunStatus} onChange={e => setFormRunStatus(e.target.value as RunStatus)}><option>正常</option><option>异常</option><option>待观察</option></select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1">现存问题</label>
                    <input className="form-input w-full" placeholder="保养后仍存在的问题" value={formExistingProblems} onChange={e => setFormExistingProblems(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1">处理结果</label>
                    <input className="form-input w-full" placeholder="本次保养的处理结果" value={formHandleResult} onChange={e => setFormHandleResult(e.target.value)} />
                  </div>
                  <div className="col-span-3">
                    <label className="block text-xs mb-1">备注</label>
                    <input className="form-input w-full" placeholder="其他需要说明的事项..." value={formRemark} onChange={e => setFormRemark(e.target.value)} />
                  </div>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setAddOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSave}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备选择弹窗（左右分栏，参照报修管理） ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[100dvh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* 搜索区域 */}
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label>
                  <input className="form-input w-28 text-sm" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label>
                  <select className="form-input w-28 text-sm" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}>
                    <option value="">全部</option>
                    {categoryOptions.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchName(''); setStockSearchCategory('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            {/* 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：库存装备列表 */}
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8"><input type="checkbox" disabled /></th>
                      <th className="border p-2">物资名称</th>
                      <th className="border p-2">物资类别</th>
                      <th className="border p-2">规格型号</th>
                      <th className="border p-2">生产日期</th>
                      <th className="border p-2">有效期</th>
                      <th className="border p-2">剩余数量</th>
                      <th className="border p-2">单位</th>
                      <th className="border p-2">单价</th>
                      <th className="border p-2">总价</th>
                      <th className="border p-2">装备编码</th>
                      <th className="border p-2">供应商</th>
                      <th className="border p-2">备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.name === s.name)
                      return (
                        <tr key={s.name} className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`} onClick={() => toggleStockSelect(s)}>
                          <td className="border p-2 text-center"><input type="checkbox" checked={isSelected} readOnly /></td>
                          <td className="border p-2 font-medium">{s.name}</td>
                          <td className="border p-2">{s.category}</td>
                          <td className="border p-2">{s.spec || '-'}</td>
                          <td className="border p-2">{s.produceDate || '-'}</td>
                          <td className="border p-2">{s.validDate || '-'}</td>
                          <td className="border p-2 text-center font-mono">{s.qty}</td>
                          <td className="border p-2 text-center">{s.unit}</td>
                          <td className="border p-2 text-right font-mono">¥{s.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono">¥{s.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono text-xs">{s.equipCode}</td>
                          <td className="border p-2">{s.supplier}</td>
                          <td className="border p-2">{s.remark || '-'}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && (
                      <tr><td colSpan={13} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedStockItems.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备添加</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.name} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>余量: {s.stock.qty}</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.name, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.name, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.name, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.name !== s.stock.name))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情弹窗 ===== */}
      {detailOpen && detailRecord && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[900px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">保养详情</h3>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1 text-sm">
              {/* 基本信息 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#1890ff' }} />基本信息</h4>
                <div className="grid grid-cols-5 gap-x-4 gap-y-2">
                  {[
                    { label: '保养编号', value: detailRecord.id },
                    { label: '保养类型', value: detailRecord.maintainType },
                    { label: '保养周期', value: detailRecord.maintainCycle },
                    { label: '保养时间', value: detailRecord.maintainTime },
                    { label: '下次保养', value: detailRecord.nextMaintainTime },
                    { label: '经办人', value: detailRecord.operator },
                    { label: '装备状态', value: detailRecord.runStatus },
                    { label: '处理结果', value: detailRecord.handleResult || '-' },
                  ].map(f => (
                    <div key={f.label} className="flex flex-col py-1">
                      <span className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 物资明细 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#faad14' }} />物资明细（{detailRecord.materials.length} 种）</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                    <thead>
                      <tr style={{ background: 'var(--table-header-bg)' }}>
                        <th className="border p-2">#</th>
                        <th className="border p-2">物资名称</th>
                        <th className="border p-2">规格型号</th>
                        <th className="border p-2">数量</th>
                        <th className="border p-2">单位</th>
                        <th className="border p-2">保养期</th>
                        <th className="border p-2">单价</th>
                        <th className="border p-2">总价</th>
                        <th className="border p-2">装备编码</th>
                        <th className="border p-2">RFID编码</th>
                        <th className="border p-2">供应商</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detailRecord.materials.map((m, i) => (
                        <tr key={m.id}>
                          <td className="border p-2 text-center font-mono">{i + 1}</td>
                          <td className="border p-2 font-medium">{m.name}</td>
                          <td className="border p-2">{m.spec}</td>
                          <td className="border p-2 text-center font-mono">{m.qty}</td>
                          <td className="border p-2 text-center">{m.unit}</td>
                          <td className="border p-2">{m.maintainPeriod}</td>
                          <td className="border p-2 text-right font-mono">¥{m.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono">¥{m.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono">{m.equipCode}</td>
                          <td className="border p-2 font-mono text-[10px]">
                            {(m.rfidList || [m.rfidCode]).map((r, ri) => (
                              <div key={ri}>{r}</div>
                            ))}
                          </td>
                          <td className="border p-2">{m.supplier}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* 保养作业 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#52c41a' }} />保养作业</h4>
                <div className="flex flex-wrap gap-2 mb-2">
                  {detailRecord.maintainItems.map(item => (
                    <span key={item} className="text-xs px-2 py-0.5 rounded-full bg-green-50 text-green-600 border border-green-200">{item}</span>
                  ))}
                  {detailRecord.maintainItems.length === 0 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>}
                </div>
                <div className="bg-gray-50 rounded-lg p-3 text-xs" style={{ color: 'var(--text-secondary)' }}>{detailRecord.workDescription || '无作业说明'}</div>
              </div>

              {/* 耗材使用 */}
              {detailRecord.consumables.length > 0 && (
                <div>
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#722ed1' }} />耗材使用</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="border p-2">耗材名称</th><th className="border p-2">数量</th><th className="border p-2">单位</th><th className="border p-2">备注</th></tr></thead>
                      <tbody>{detailRecord.consumables.map(c => (<tr key={c.id}><td className="border p-2">{c.name}</td><td className="border p-2 text-center">{c.qty}</td><td className="border p-2 text-center">{c.unit}</td><td className="border p-2">{c.remark || '-'}</td></tr>))}</tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 异常问题 */}
              {detailRecord.abnormalIssue && (
                <div>
                  <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#ff4d4f' }} />异常问题</h4>
                  <div className="bg-red-50 rounded-lg p-3 space-y-2">
                    <div className="flex items-center gap-2"><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>严重程度：</span><span className="text-xs px-2 py-0.5 rounded" style={{ background: '#fff', color: detailRecord.abnormalIssue.severity === '紧急' ? '#ff4d4f' : detailRecord.abnormalIssue.severity === '严重' ? '#faad14' : '#1890ff' }}>{detailRecord.abnormalIssue.severity}</span></div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>问题描述：</span><span className="text-xs">{detailRecord.abnormalIssue.description}</span></div>
                    <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>临时处置：</span><span className="text-xs">{detailRecord.abnormalIssue.tempMeasure}</span></div>
                  </div>
                </div>
              )}

              {/* 保养结果 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#faad14' }} />保养结果</h4>
                <div className="grid grid-cols-3 gap-x-4 gap-y-2">
                  <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>现存问题</span><div className="font-medium">{detailRecord.existingProblems || '-'}</div></div>
                  <div><span className="text-xs" style={{ color: 'var(--text-secondary)' }}>备注</span><div className="font-medium">{detailRecord.remark || '-'}</div></div>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
