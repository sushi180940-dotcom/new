import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

/* ─────────────── Types ─────────────── */

interface TechPerson {
  id: string
  name: string
  unitType: 'supplier' | 'agreement'
  org: string
  phone: string
  role: string
  specialty: string
  status: 'on' | 'off'
}

interface WarrantyItem {
  id: string
  equipName: string
  code: string
  supplier: string
  purchaseDate: string
  warrantyMonths: number
  expiryDate: string
  status: 'valid' | 'expired' | 'near'
}

interface FaultOrder {
  id: string
  reporter: string
  org: string
  equipName: string
  code: string
  faultDesc: string
  reportTime: string
  status: 'reported' | 'approved' | 'dispatched' | 'repairing' | 'done'
  repairman?: string
  result?: string
}

interface ServiceReview {
  id: string
  serviceType: string
  targetName: string
  reviewer: string
  org: string
  rating: number
  content: string
  time: string
}

interface Complaint {
  id: string
  complainant: string
  org: string
  targetType: string
  targetName: string
  content: string
  time: string
  status: 'pending' | 'processing' | 'resolved'
  reply?: string
}

/* ─────────────── Mock Data ─────────────── */

// 系统单位库（用于模糊匹配）
const systemOrgs = [
  { name: '华为科技', unitType: 'supplier' as const },
  { name: '海康威视', unitType: 'supplier' as const },
  { name: '中兴通信', unitType: 'supplier' as const },
  { name: '大华股份', unitType: 'supplier' as const },
  { name: '宇视科技', unitType: 'supplier' as const },
  { name: '中安保全服务有限公司', unitType: 'agreement' as const },
  { name: '北京智盾科技服务有限公司', unitType: 'agreement' as const },
  { name: '上海安防设备协议供货商', unitType: 'agreement' as const },
  { name: '广州智能装备协议供货商', unitType: 'agreement' as const },
]

const techPersonMock: TechPerson[] = [
  { id: '1', name: '陈建国', unitType: 'supplier', org: '华为科技', phone: '13800138001', role: '高级工程师', specialty: '通信设备维修', status: 'on' },
  { id: '2', name: '刘晓燕', unitType: 'supplier', org: '海康威视', phone: '13900139002', role: '技术经理', specialty: '监控系统调试', status: 'on' },
  { id: '3', name: '赵志强', unitType: 'agreement', org: '中安保全服务有限公司', phone: '13700137003', role: '工程师', specialty: '安防设备维护', status: 'on' },
  { id: '4', name: '孙丽华', unitType: 'agreement', org: '北京智盾科技服务有限公司', phone: '13600136004', role: '技术员', specialty: '智能装备检测', status: 'on' },
  { id: '5', name: '周伟', unitType: 'supplier', org: '中兴通信', phone: '13500135005', role: '工程师', specialty: '无线电设备', status: 'off' },
]

const warrantyMock: WarrantyItem[] = [
  { id: '1', equipName: '手持对讲机', code: 'EQ20250101001', supplier: '华为科技', purchaseDate: '2025-01-15', warrantyMonths: 24, expiryDate: '2027-01-14', status: 'valid' },
  { id: '2', equipName: '执法记录仪', code: 'EQ20240601002', supplier: '海康威视', purchaseDate: '2024-06-01', warrantyMonths: 12, expiryDate: '2025-05-31', status: 'near' },
  { id: '3', equipName: '车载电台', code: 'EQ20230301003', supplier: '中兴通信', purchaseDate: '2023-03-01', warrantyMonths: 24, expiryDate: '2025-02-28', status: 'expired' },
]

const faultMock: FaultOrder[] = [
  { id: 'F20250501001', reporter: '赵明', org: '朝阳分局', equipName: '手持对讲机', code: 'EQ20250101001', faultDesc: '无法开机，疑似电池故障', reportTime: '2025-05-01 09:30', status: 'reported' },
  { id: 'F20250428002', reporter: '钱红', org: '海淀分局', equipName: '执法记录仪', code: 'EQ20240601002', faultDesc: '录像模糊，镜头可能有污渍或损坏', reportTime: '2025-04-28 14:20', status: 'approved' },
  { id: 'F20250425003', reporter: '孙刚', org: '丰台分局', equipName: '车载电台', code: 'EQ20230301003', faultDesc: '信号不稳定，经常断连', reportTime: '2025-04-25 11:00', status: 'dispatched', repairman: '张伟' },
  { id: 'F20250420004', reporter: '周丽', org: '通州分局', equipName: '无人机', code: 'EQ20241001004', faultDesc: '遥控器失灵', reportTime: '2025-04-20 16:45', status: 'repairing', repairman: '李强' },
  { id: 'F20250415005', reporter: '吴军', org: '昌平分局', equipName: '监控摄像头', code: 'EQ20240201005', faultDesc: '画面黑屏', reportTime: '2025-04-15 08:10', status: 'done', repairman: '王芳', result: '更换电源适配器，已恢复正常' },
]

const reviewMock: ServiceReview[] = [
  { id: '1', serviceType: '维修服务', targetName: '张伟', reviewer: '赵明', org: '朝阳分局', rating: 5, content: '响应迅速，技术过硬，当天就解决了问题。', time: '2025-05-02 10:00' },
  { id: '2', serviceType: '培训服务', targetName: '李强', reviewer: '钱红', org: '海淀分局', rating: 4, content: '讲解清晰，但希望增加实操环节。', time: '2025-04-29 15:30' },
  { id: '3', serviceType: '维修服务', targetName: '王芳', reviewer: '吴军', org: '昌平分局', rating: 5, content: '服务态度好，维修专业。', time: '2025-04-16 09:20' },
]

// 当前登录用户（系统自动获取）
const currentUser = { name: '赵明', org: '朝阳分局' }

// 用户持有的装备库（用于模糊搜索）
const myEquipments = [
  { name: '手持对讲机', code: 'EQ20250101001' },
  { name: '执法记录仪', code: 'EQ20240601002' },
  { name: '车载电台', code: 'EQ20230301003' },
  { name: '无人机', code: 'EQ20241001004' },
  { name: '监控摄像头', code: 'EQ20240201005' },
  { name: '防弹背心', code: 'EQ20240101006' },
  { name: '强光手电', code: 'EQ20240901007' },
]

// 投诉对象库（用于模糊匹配）
const complaintTargets = [
  '华为科技', '海康威视', '中兴通信', '大华股份', '宇视科技',
  '张伟', '李强', '王芳', '某维修点', '某培训中心',
  '执法记录仪X5', '手持对讲机Pro', '无人机M300',
]

const complaintMock: Complaint[] = [
  { id: 'C20250501001', complainant: '郑华', org: '大兴分局', targetType: '供应商', targetName: '华为科技', content: '供货周期过长，约定30天到货，实际用了45天。', time: '2025-05-01 11:00', status: 'pending' },
  { id: 'C20250428002', complainant: '陈静', org: '房山分局', targetType: '维修人员', targetName: '某维修点', content: '维修后设备频繁死机，维修质量不达标。', time: '2025-04-28 13:40', status: 'processing' },
  { id: 'C20250420003', complainant: '黄磊', org: '顺义分局', targetType: '产品质量', targetName: '执法记录仪X5', content: '电池续航与标称不符，实际使用不到4小时。', time: '2025-04-20 10:15', status: 'resolved', reply: '已联系厂家更换电池模组，请留意后续使用。' },
]

const statusColors: Record<string, { text: string; color: string }> = {
  reported: { text: '待审批', color: '#faad14' },
  approved: { text: '已审批', color: '#1890ff' },
  dispatched: { text: '已派单', color: '#722ed1' },
  repairing: { text: '维修中', color: '#eb2f96' },
  done: { text: '已完成', color: '#52c41a' },
  valid: { text: '在保', color: '#52c41a' },
  expired: { text: '已过保', color: '#ff4d4f' },
  near: { text: '即将过期', color: '#faad14' },
  pending: { text: '待处理', color: '#ff4d4f' },
  processing: { text: '处理中', color: '#1890ff' },
  resolved: { text: '已解决', color: '#52c41a' },
  on: { text: '在职', color: '#52c41a' },
  off: { text: '离职', color: '#ff4d4f' },
}

const faultFlow = ['reported', 'approved', 'dispatched', 'repairing', 'done'] as const

/* ─────────────── Component ─────────────── */

export default function EquipmentSupportPage({ activeSubTab = 'dashboard', onNavigate }: Props) {
  const [subTab, setSubTab] = useState(activeSubTab || 'dashboard')

  useEffect(() => {
    setSubTab(activeSubTab || 'dashboard')
  }, [activeSubTab])

  /* ─── 7.1 技术人员管理 ─── */
  const [techList, setTechList] = useState<TechPerson[]>(techPersonMock)
  const [techSearch, setTechSearch] = useState('')
  const [techUnitTypeFilter, setTechUnitTypeFilter] = useState('')
  const [techModalOpen, setTechModalOpen] = useState(false)
  const [techForm, setTechForm] = useState<Partial<TechPerson>>({})
  const [editingTechId, setEditingTechId] = useState<string | null>(null)

  /* ─── 7.2 装备质保查询 ─── */
  const [warrantySearch, setWarrantySearch] = useState('')
  const [warrantyStatusFilter, setWarrantyStatusFilter] = useState('')

  /* ─── 7.3 装备故障报修 ─── */
  const [faultList, setFaultList] = useState<FaultOrder[]>(faultMock)
  const [faultSearch, setFaultSearch] = useState('')
  const [faultStatusFilter, setFaultStatusFilter] = useState('')
  const [faultModalOpen, setFaultModalOpen] = useState(false)
  const [faultForm, setFaultForm] = useState({ reporter: '', org: '', equipName: '', code: '', faultDesc: '' })
  const [detailFault, setDetailFault] = useState<FaultOrder | null>(null)
  const [repairModalOpen, setRepairModalOpen] = useState(false)
  const [repairResult, setRepairResult] = useState('')

  // 装备模糊搜索
  const [equipSearchText, setEquipSearchText] = useState('')
  const [equipSearchOpen, setEquipSearchOpen] = useState(false)
  // 技术人员-所属单位模糊搜索
  const [techOrgDropdownOpen, setTechOrgDropdownOpen] = useState(false)

  /* ─── 7.4 服务评价 ─── */
  const [reviewSearch, setReviewSearch] = useState('')
  const [reviewModalOpen, setReviewModalOpen] = useState(false)
  const [reviewForm, setReviewForm] = useState({ serviceType: '维修服务', targetName: '', rating: 5, content: '' })

  /* ─── 7.5 投诉管理 ─── */
  const [complaintList, setComplaintList] = useState<Complaint[]>(complaintMock)
  const [complaintSearch, setComplaintSearch] = useState('')
  const [complaintStatusFilter, setComplaintStatusFilter] = useState('')
  const [complaintModalOpen, setComplaintModalOpen] = useState(false)
  const [complaintForm, setComplaintForm] = useState({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
  const [replyComplaint, setReplyComplaint] = useState<Complaint | null>(null)
  const [replyContent, setReplyContent] = useState('')
  const [replyOpen, setReplyOpen] = useState(false)

  // 投诉对象模糊搜索
  const [targetSearchText, setTargetSearchText] = useState('')
  const [targetSearchOpen, setTargetSearchOpen] = useState(false)

  /* ─── File upload ref ─── */
  /* ─────────────── Handlers ─────────────── */

  const openTechModal = (item?: TechPerson) => {
    if (item) {
      setTechForm({ ...item })
      setEditingTechId(item.id)
    } else {
      setTechForm({ name: '', unitType: 'supplier', org: '', phone: '', role: '工程师', specialty: '', status: 'on' })
      setEditingTechId(null)
    }
    setTechModalOpen(true)
  }

  const saveTech = () => {
    if (!techForm.name || !techForm.org) return
    if (editingTechId) {
      setTechList(prev => prev.map(t => t.id === editingTechId ? { ...t, ...techForm } as TechPerson : t))
    } else {
      const { id: _unused, ...restForm } = techForm as TechPerson
      void _unused
      const newItem: TechPerson = { id: Date.now().toString(), ...restForm }
      setTechList(prev => [...prev, newItem])
    }
    setTechModalOpen(false)
  }

  const deleteTech = (id: string) => {
    if (confirm('确定删除该技术人员？')) setTechList(prev => prev.filter(t => t.id !== id))
  }

  const addFault = () => {
    const finalForm = {
      ...faultForm,
      reporter: currentUser.name,
      org: currentUser.org,
    }
    if (!finalForm.equipName || !finalForm.faultDesc) return
    const newFault: FaultOrder = {
      id: `F${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(faultList.length + 1).padStart(3, '0')}`,
      ...finalForm,
      reportTime: new Date().toLocaleString('zh-CN'),
      status: 'reported',
    }
    setFaultList(prev => [newFault, ...prev])
    setFaultModalOpen(false)
    setFaultForm({ reporter: '', org: '', equipName: '', code: '', faultDesc: '' })
    setEquipSearchText('')
  }

  const advanceFaultStatus = (id: string) => {
    setFaultList(prev => prev.map(f => {
      if (f.id !== id) return f
      const idx = faultFlow.indexOf(f.status as typeof faultFlow[number])
      if (idx >= 0 && idx < faultFlow.length - 1) {
        return { ...f, status: faultFlow[idx + 1] }
      }
      return f
    }))
  }

  const submitRepairResult = () => {
    if (!detailFault || !repairResult) return
    setFaultList(prev => prev.map(f => f.id === detailFault.id ? { ...f, status: 'done' as const, result: repairResult } : f))
    setRepairModalOpen(false)
    setRepairResult('')
    setDetailFault(null)
  }

  const addReview = () => {
    if (!reviewForm.targetName || !reviewForm.content) return
    const newReview: ServiceReview = {
      id: Date.now().toString(),
      ...reviewForm,
      reviewer: '当前用户',
      org: '本单位',
      time: new Date().toLocaleString('zh-CN'),
    }
    reviewMock.unshift(newReview)
    setReviewModalOpen(false)
    setReviewForm({ serviceType: '维修服务', targetName: '', rating: 5, content: '' })
  }

  const addComplaint = () => {
    const finalForm = {
      ...complaintForm,
      complainant: currentUser.name,
      org: currentUser.org,
    }
    if (!finalForm.targetName || !finalForm.content) return
    const newItem: Complaint = {
      id: `C${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(complaintList.length + 1).padStart(3, '0')}`,
      ...finalForm,
      time: new Date().toLocaleString('zh-CN'),
      status: 'pending',
    }
    setComplaintList(prev => [newItem, ...prev])
    setComplaintModalOpen(false)
    setComplaintForm({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
    setTargetSearchText('')
  }

  const submitReply = () => {
    if (!replyComplaint || !replyContent) return
    setComplaintList(prev => prev.map(c => c.id === replyComplaint.id ? { ...c, status: 'resolved', reply: replyContent } : c))
    setReplyOpen(false)
    setReplyContent('')
    setReplyComplaint(null)
  }

  const processComplaint = (id: string) => {
    setComplaintList(prev => prev.map(c => c.id === id ? { ...c, status: 'processing' } : c))
  }

  // 从质保查询发起报修
  const startRepairFromWarranty = (equipName: string, code: string) => {
    setFaultForm({
      reporter: currentUser.name,
      org: currentUser.org,
      equipName,
      code,
      faultDesc: '',
    })
    setEquipSearchText(equipName)
    setSubTab('fault-repair')
    setTimeout(() => setFaultModalOpen(true), 100)
  }

  /* ─────────────── Filter helpers ─────────────── */

  const filteredTech = techList.filter(t => {
    const matchSearch = !techSearch || t.name.includes(techSearch) || t.specialty.includes(techSearch) || t.org.includes(techSearch)
    const matchUnitType = !techUnitTypeFilter || t.unitType === techUnitTypeFilter
    return matchSearch && matchUnitType
  })
  const filteredWarranty = warrantyMock.filter(w => {
    const matchSearch = !warrantySearch || w.equipName.includes(warrantySearch) || w.code.includes(warrantySearch)
    const matchStatus = !warrantyStatusFilter || w.status === warrantyStatusFilter
    return matchSearch && matchStatus
  })
  const filteredFault = faultList.filter(f => {
    const matchSearch = !faultSearch || f.equipName.includes(faultSearch) || f.id.includes(faultSearch)
    const matchStatus = !faultStatusFilter || f.status === faultStatusFilter
    return matchSearch && matchStatus
  })
  const filteredReview = reviewMock.filter(r =>
    !reviewSearch || r.targetName.includes(reviewSearch) || r.serviceType.includes(reviewSearch)
  )
  const filteredComplaint = complaintList.filter(c => {
    const matchSearch = !complaintSearch || c.complainant.includes(complaintSearch) || c.targetName.includes(complaintSearch)
    const matchStatus = !complaintStatusFilter || c.status === complaintStatusFilter
    return matchSearch && matchStatus
  })

  /* ─────────────── Tabs config ─────────────── */

  const tabs = [
    { key: 'dashboard', label: '工作台' },
    { key: 'tech-personnel', label: '技术人员管理' },
    { key: 'warranty-query', label: '装备质保查询' },
    { key: 'fault-repair', label: '装备故障报修' },
    { key: 'service-review', label: '服务评价' },
    { key: 'complaint-mgmt', label: '投诉管理' },
  ]

  /* ═══════════════════════════════════════════ */

  return (
    <div className="p-6 max-w-[1600px] mx-auto" onClick={() => { setEquipSearchOpen(false); setTargetSearchOpen(false); setTechOrgDropdownOpen(false) }}>

      {/* ═══════ 工作台 ═══════ */}
      {subTab === 'dashboard' && (
        <div className="space-y-4 animate-fade-in">
          {/* 统计卡片 */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[
              { label: '技术人员', value: `${techList.length} 人`, color: '#1890ff', icon: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2' },
              { label: '在保装备', value: `${warrantyMock.filter(w => w.status === 'valid').length} 件`, color: '#52c41a', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586' },
              { label: '待处理故障', value: `${faultList.filter(f => f.status !== 'done').length} 个`, color: '#ff4d4f', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77' },
              { label: '服务评价', value: `${reviewMock.length} 条`, color: '#faad14', icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
              { label: '投诉记录', value: `${complaintMock.length} 条`, color: '#722ed1', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
            ].map(card => (
              <div key={card.label} className="content-card p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d={card.icon}/>
                  </svg>
                </div>
                <div>
                  <div className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                  <div className="text-lg font-bold" style={{ color: card.color }}>{card.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* 快捷入口 */}
          <div className="content-card p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
              快捷入口
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {[
                { key: 'tech-personnel', label: '技术人员管理', desc: '技术人员档案管理', color: '#13c2c2', icon: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2' },
                { key: 'warranty-query', label: '装备质保查询', desc: '装备质保状态查询', color: '#eb2f96', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586' },
                { key: 'fault-repair', label: '装备故障报修', desc: '故障报修闭环管理', color: '#ff4d4f', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77' },
                { key: 'service-review', label: '服务评价', desc: '服务质量评价管理', color: '#faad14', icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
                { key: 'complaint-mgmt', label: '投诉管理', desc: '供应商投诉处理', color: '#722ed1', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
              ].map(item => (
                <button
                  key={item.key}
                  onClick={() => setSubTab(item.key)}
                  className="flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left"
                  style={{ borderColor: 'var(--border-color)', background: '#fff' }}
                >
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                      <path d={item.icon}/>
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium">{item.label}</div>
                    <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
                  </div>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                    <polyline points="9 18 15 12 9 6"/>
                  </svg>
                </button>
              ))}
            </div>
          </div>

          {/* 最近故障报修 */}
          <div className="content-card p-4">
            <h3 className="font-semibold mb-3">最近故障报修</h3>
            <table className="data-table">
              <thead>
                <tr>
                  <th>报修单号</th><th>装备名称</th><th>报修人</th><th>状态</th><th>报修时间</th>
                </tr>
              </thead>
              <tbody>
                {faultList.slice(0, 5).map(f => (
                  <tr key={f.id}>
                    <td className="font-mono text-xs">{f.id}</td>
                    <td>{f.equipName}</td>
                    <td>{f.reporter}</td>
                    <td><span className={`tag text-xs ${f.status === 'done' ? 'tag-green' : f.status === 'repairing' ? 'tag-blue' : 'tag-yellow'}`}>{f.status === 'reported' ? '已报修' : f.status === 'approved' ? '已审批' : f.status === 'dispatched' ? '已派单' : f.status === 'repairing' ? '维修中' : '已完成'}</span></td>
                    <td className="text-xs">{f.reportTime}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ═══════ 7.1 技术人员管理 ═══════ */}
      {subTab === 'tech-personnel' && (
        <div className="animate-fade-in">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1 mb-2">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setSubTab('dashboard')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>技术人员管理</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-3 items-center">
              <input
                placeholder="姓名/专业/所属单位"
                value={techSearch}
                onChange={e => setTechSearch(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none focus:ring-2 focus:ring-blue-200"
                style={{ borderColor: 'var(--border-color)', background: '#fff', width: 220 }}
              />
              <select
                value={techUnitTypeFilter}
                onChange={e => setTechUnitTypeFilter(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none"
                style={{ borderColor: 'var(--border-color)', background: '#fff' }}
              >
                <option value="">全部类型</option>
                <option value="supplier">供应商</option>
                <option value="agreement">协议供货商</option>
              </select>
              <button
                onClick={() => {}}
                className="px-4 py-1.5 text-sm rounded-md text-white"
                style={{ background: '#1890ff' }}
              >查询</button>
              {(techSearch || techUnitTypeFilter) && (
                <button onClick={() => { setTechSearch(''); setTechUnitTypeFilter('') }} className="text-sm text-gray-500">重置</button>
              )}
            </div>
            <button
              onClick={() => openTechModal()}
              className="px-4 py-1.5 text-sm rounded-md text-white"
              style={{ background: '#52c41a' }}
            >新增技术人员</button>
          </div>

          <div className="rounded-lg overflow-hidden border" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: 'var(--card-header-bg)' }}>
                  <th className="px-4 py-3 text-left font-medium">姓名</th>
                  <th className="px-4 py-3 text-left font-medium">单位类型</th>
                  <th className="px-4 py-3 text-left font-medium">所属单位</th>
                  <th className="px-4 py-3 text-left font-medium">联系电话</th>
                  <th className="px-4 py-3 text-left font-medium">职称</th>
                  <th className="px-4 py-3 text-left font-medium">专业领域</th>
                  <th className="px-4 py-3 text-left font-medium">状态</th>
                  <th className="px-4 py-3 text-left font-medium">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredTech.map(item => (
                  <tr key={item.id} className="border-t hover:bg-blue-50/30 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                    <td className="px-4 py-3 font-medium">{item.name}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs" style={{ background: item.unitType === 'supplier' ? '#e6f7ff' : '#f6ffed', color: item.unitType === 'supplier' ? '#1890ff' : '#52c41a' }}>
                        {item.unitType === 'supplier' ? '供应商' : '协议供货商'}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{item.org}</td>
                    <td className="px-4 py-3 text-gray-600">{item.phone}</td>
                    <td className="px-4 py-3 text-gray-600">{item.role}</td>
                    <td className="px-4 py-3 text-gray-600">{item.specialty}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                        {statusColors[item.status].text}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2">
                        <button onClick={() => openTechModal(item)} className="text-blue-600 hover:text-blue-800 text-xs">编辑</button>
                        <button onClick={() => deleteTech(item.id)} className="text-red-500 hover:text-red-700 text-xs">删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredTech.length === 0 && (
                  <tr><td colSpan={8} className="text-center py-12 text-gray-400">暂无数据</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ═══════ 7.2 装备质保查询 ═══════ */}
      {subTab === 'warranty-query' && (
        <div className="animate-fade-in">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1 mb-2">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setSubTab('dashboard')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>装备质保查询</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-3 items-center">
              <input
                placeholder="装备名称/编码"
                value={warrantySearch}
                onChange={e => setWarrantySearch(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none focus:ring-2 focus:ring-blue-200"
                style={{ borderColor: 'var(--border-color)', background: '#fff', width: 220 }}
              />
              <select
                value={warrantyStatusFilter}
                onChange={e => setWarrantyStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none"
                style={{ borderColor: 'var(--border-color)', background: '#fff' }}
              >
                <option value="">全部状态</option>
                <option value="valid">在保</option>
                <option value="near">即将过期</option>
                <option value="expired">已过保</option>
              </select>
              <button className="px-4 py-1.5 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>查询</button>
              {(warrantySearch || warrantyStatusFilter) && (
                <button onClick={() => { setWarrantySearch(''); setWarrantyStatusFilter('') }} className="text-sm text-gray-500">重置</button>
              )}
            </div>
          </div>

          <div className="rounded-lg overflow-hidden border" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: 'var(--card-header-bg)' }}>
                  <th className="px-4 py-3 text-left font-medium">装备名称</th>
                  <th className="px-4 py-3 text-left font-medium">装备编码</th>
                  <th className="px-4 py-3 text-left font-medium">供应商</th>
                  <th className="px-4 py-3 text-left font-medium">采购日期</th>
                  <th className="px-4 py-3 text-left font-medium">质保时长</th>
                  <th className="px-4 py-3 text-left font-medium">到期日期</th>
                  <th className="px-4 py-3 text-left font-medium">状态</th>
                  <th className="px-4 py-3 text-left font-medium">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredWarranty.map(item => (
                  <tr key={item.id} className="border-t hover:bg-blue-50/30 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                    <td className="px-4 py-3 font-medium">{item.equipName}</td>
                    <td className="px-4 py-3 font-mono text-gray-700">{item.code}</td>
                    <td className="px-4 py-3 text-gray-600">{item.supplier}</td>
                    <td className="px-4 py-3 text-gray-600">{item.purchaseDate}</td>
                    <td className="px-4 py-3 text-gray-600">{item.warrantyMonths}个月</td>
                    <td className="px-4 py-3" style={{ color: item.status === 'expired' ? '#ff4d4f' : item.status === 'near' ? '#faad14' : '#52c41a', fontWeight: 500 }}>
                      {item.expiryDate}
                    </td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                        {statusColors[item.status].text}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => startRepairFromWarranty(item.equipName, item.code)}
                        className="px-3 py-1 text-xs rounded border hover:bg-blue-50 transition-colors"
                        style={{ borderColor: '#1890ff', color: '#1890ff' }}
                      >发起报修</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filteredWarranty.length === 0 && (
            <div className="text-center py-16 text-gray-400 text-sm">暂无质保数据</div>
          )}
        </div>
      )}

      {/* ═══════ 7.3 装备故障报修 ═══════ */}
      {subTab === 'fault-repair' && (
        <div className="animate-fade-in">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1 mb-2">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setSubTab('dashboard')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>装备故障报修</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-3 items-center">
              <input
                placeholder="装备名称/工单号"
                value={faultSearch}
                onChange={e => setFaultSearch(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none focus:ring-2 focus:ring-blue-200"
                style={{ borderColor: 'var(--border-color)', background: '#fff', width: 220 }}
              />
              <select
                value={faultStatusFilter}
                onChange={e => setFaultStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none"
                style={{ borderColor: 'var(--border-color)', background: '#fff' }}
              >
                <option value="">全部状态</option>
                <option value="reported">待审批</option>
                <option value="approved">已审批</option>
                <option value="dispatched">已派单</option>
                <option value="repairing">维修中</option>
                <option value="done">已完成</option>
              </select>
              <button className="px-4 py-1.5 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>查询</button>
              {(faultSearch || faultStatusFilter) && (
                <button onClick={() => { setFaultSearch(''); setFaultStatusFilter('') }} className="text-sm text-gray-500">重置</button>
              )}
            </div>
            <button
              onClick={() => setFaultModalOpen(true)}
              className="px-4 py-1.5 text-sm rounded-md text-white"
              style={{ background: '#52c41a' }}
            >报修登记</button>
          </div>

          <div className="rounded-lg overflow-hidden border" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
            <table className="w-full text-sm">
              <thead>
                <tr style={{ background: 'var(--card-header-bg)' }}>
                  <th className="px-4 py-3 text-left font-medium">工单号</th>
                  <th className="px-4 py-3 text-left font-medium">报修人</th>
                  <th className="px-4 py-3 text-left font-medium">装备名称</th>
                  <th className="px-4 py-3 text-left font-medium">故障描述</th>
                  <th className="px-4 py-3 text-left font-medium">报修时间</th>
                  <th className="px-4 py-3 text-left font-medium">当前状态</th>
                  <th className="px-4 py-3 text-left font-medium">维修人</th>
                  <th className="px-4 py-3 text-left font-medium">操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredFault.map(item => (
                  <tr key={item.id} className="border-t hover:bg-blue-50/30 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                    <td className="px-4 py-3 font-mono text-gray-700">{item.id}</td>
                    <td className="px-4 py-3">{item.reporter}<br/><span className="text-xs text-gray-400">{item.org}</span></td>
                    <td className="px-4 py-3">{item.equipName}<br/><span className="text-xs text-gray-400 font-mono">{item.code}</span></td>
                    <td className="px-4 py-3 text-gray-600 max-w-[200px] truncate" title={item.faultDesc}>{item.faultDesc}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{item.reportTime}</td>
                    <td className="px-4 py-3">
                      <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                        {statusColors[item.status].text}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{item.repairman || '-'}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2 flex-wrap">
                        <button onClick={() => setDetailFault(item)} className="text-blue-600 hover:text-blue-800 text-xs">查看</button>
                        {item.status !== 'done' && (
                          <button onClick={() => advanceFaultStatus(item.id)} className="text-green-600 hover:text-green-800 text-xs">
                            {item.status === 'repairing' ? '完成' : '推进'}
                          </button>
                        )}
                        {item.status === 'repairing' && (
                          <>
                            <button onClick={() => { setDetailFault(item); setRepairModalOpen(true) }} className="text-purple-600 hover:text-purple-800 text-xs">反馈</button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredFault.length === 0 && (
                  <tr><td colSpan={8} className="text-center py-12 text-gray-400">暂无报修工单</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ═══════ 7.4 服务评价 ═══════ */}
      {subTab === 'service-review' && (
        <div className="animate-fade-in">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1 mb-2">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setSubTab('dashboard')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>服务评价</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-3">
              <input
                placeholder="评价对象/服务类型"
                value={reviewSearch}
                onChange={e => setReviewSearch(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none focus:ring-2 focus:ring-blue-200"
                style={{ borderColor: 'var(--border-color)', background: '#fff', width: 220 }}
              />
              <button className="px-4 py-1.5 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>查询</button>
              {reviewSearch && <button onClick={() => setReviewSearch('')} className="text-sm text-gray-500">重置</button>}
            </div>
            <button
              onClick={() => setReviewModalOpen(true)}
              className="px-4 py-1.5 text-sm rounded-md text-white"
              style={{ background: '#52c41a' }}
            >评价登记</button>
          </div>

          <div className="space-y-3">
            {filteredReview.map(item => (
              <div key={item.id} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-medium text-gray-800">{item.reviewer}</span>
                    <span className="text-xs text-gray-400">{item.org}</span>
                    <span className="px-2 py-0.5 rounded text-xs" style={{ background: '#f0f0f0', color: '#666' }}>{item.serviceType}</span>
                  </div>
                  <span className="text-xs text-gray-400">{item.time}</span>
                </div>
                <div className="flex items-center gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map(s => (
                    <svg key={s} width="16" height="16" viewBox="0 0 24 24" fill={s <= item.rating ? '#faad14' : '#e8e8e8'}>
                      <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                    </svg>
                  ))}
                  <span className="text-sm ml-1" style={{ color: '#faad14' }}>{item.rating}分</span>
                </div>
                <p className="text-sm text-gray-600">{item.content}</p>
                <div className="mt-2 text-xs text-gray-400">评价对象：{item.targetName}</div>
              </div>
            ))}
            {filteredReview.length === 0 && (
              <div className="text-center py-16 text-gray-400 text-sm">暂无评价记录</div>
            )}
          </div>
        </div>
      )}

      {/* ═══════ 7.5 投诉管理 ═══════ */}
      {subTab === 'complaint-mgmt' && (
        <div className="animate-fade-in">
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1 mb-2">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setSubTab('dashboard')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>投诉管理</span>
          </div>
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-3 items-center">
              <input
                placeholder="投诉人/投诉对象"
                value={complaintSearch}
                onChange={e => setComplaintSearch(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none focus:ring-2 focus:ring-blue-200"
                style={{ borderColor: 'var(--border-color)', background: '#fff', width: 220 }}
              />
              <select
                value={complaintStatusFilter}
                onChange={e => setComplaintStatusFilter(e.target.value)}
                className="px-3 py-1.5 text-sm rounded-md border focus:outline-none"
                style={{ borderColor: 'var(--border-color)', background: '#fff' }}
              >
                <option value="">全部状态</option>
                <option value="pending">待处理</option>
                <option value="processing">处理中</option>
                <option value="resolved">已解决</option>
              </select>
              <button className="px-4 py-1.5 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>查询</button>
              {(complaintSearch || complaintStatusFilter) && (
                <button onClick={() => { setComplaintSearch(''); setComplaintStatusFilter('') }} className="text-sm text-gray-500">重置</button>
              )}
            </div>
            <button
              onClick={() => setComplaintModalOpen(true)}
              className="px-4 py-1.5 text-sm rounded-md text-white"
              style={{ background: '#ff4d4f' }}
            >投诉登记</button>
          </div>

          <div className="space-y-3">
            {filteredComplaint.map(item => (
              <div key={item.id} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-3">
                    <span className="font-mono text-xs text-gray-500">{item.id}</span>
                    <span className="text-sm font-medium text-gray-800">{item.complainant}</span>
                    <span className="text-xs text-gray-400">{item.org}</span>
                    <span className="px-2 py-0.5 rounded text-xs" style={{ background: '#f0f0f0', color: '#666' }}>{item.targetType}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                    {statusColors[item.status].text}
                  </span>
                </div>
                <div className="text-sm text-gray-600 mb-2">
                  <span className="text-gray-400">投诉对象：</span>{item.targetName}
                </div>
                <p className="text-sm text-gray-700 mb-3">{item.content}</p>
                <div className="flex justify-between items-center text-xs text-gray-400">
                  <span>{item.time}</span>
                  <div className="flex gap-2">
                    {item.status === 'pending' && (
                      <button onClick={() => processComplaint(item.id)} className="px-3 py-1 rounded border text-xs hover:bg-blue-50" style={{ borderColor: '#1890ff', color: '#1890ff' }}>受理</button>
                    )}
                    {(item.status === 'processing' || item.status === 'pending') && (
                      <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="px-3 py-1 rounded border text-xs hover:bg-green-50" style={{ borderColor: '#52c41a', color: '#52c41a' }}>回复</button>
                    )}
                    {item.reply && (
                      <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="text-blue-600 hover:text-blue-800">查看回复</button>
                    )}
                  </div>
                </div>
                {item.reply && (
                  <div className="mt-3 p-3 rounded text-sm" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                    <span className="text-green-700 font-medium">回复：</span>
                    <span className="text-gray-700">{item.reply}</span>
                  </div>
                )}
              </div>
            ))}
            {filteredComplaint.length === 0 && (
              <div className="text-center py-16 text-gray-400 text-sm">暂无投诉记录</div>
            )}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════ */}
      {/* ═══════════ 技术人员管理 Modal ═══════════ */}
      {/* ═══════════════════════════════════════════ */}

      {techModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }} onClick={() => setTechOrgDropdownOpen(false)}>
          <div className="rounded-xl p-6 w-[500px] max-h-[90vh] overflow-y-auto" style={{ background: '#fff' }} onClick={e => e.stopPropagation()}>
            <h3 className="text-base font-semibold mb-4">{editingTechId ? '编辑技术人员' : '新增技术人员'}</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">姓名 <span className="text-red-500">*</span></label>
                <input value={techForm.name || ''} onChange={e => setTechForm({ ...techForm, name: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">单位类型 <span className="text-red-500">*</span> {techForm.org && systemOrgs.some(o => o.name === techForm.org) && (
                  <span className="text-xs font-normal" style={{ color: '#52c41a' }}>(已自动获取)</span>
                )}</label>
                <select
                  value={techForm.unitType || 'supplier'}
                  onChange={e => setTechForm({ ...techForm, unitType: e.target.value as 'supplier' | 'agreement' })}
                  disabled={!!techForm.org && systemOrgs.some(o => o.name === techForm.org)}
                  className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none disabled:bg-gray-50 disabled:text-gray-500"
                  style={{ borderColor: 'var(--border-color)' }}
                >
                  <option value="supplier">供应商</option>
                  <option value="agreement">协议供货商</option>
                </select>
              </div>
              <div className="relative">
                <label className="block text-sm mb-1">所属单位 <span className="text-red-500">*</span></label>
                <input
                  value={techForm.org || ''}
                  onChange={e => {
                    const val = e.target.value
                    setTechForm(prev => ({ ...prev, org: val, unitType: undefined }))
                  }}
                  onFocus={() => setTechOrgDropdownOpen(true)}
                  className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200"
                  style={{ borderColor: 'var(--border-color)' }}
                  placeholder="输入单位名称搜索..."
                />
                {/* 模糊匹配下拉 */}
                {techOrgDropdownOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 rounded-md border shadow-lg z-50 max-h-[200px] overflow-y-auto" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
                    {systemOrgs
                      .filter(o => o.name.toLowerCase().includes((techForm.org || '').toLowerCase()))
                      .map(o => (
                        <button
                          key={o.name}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors flex justify-between items-center"
                          onClick={() => {
                            setTechForm(prev => ({ ...prev, org: o.name, unitType: o.unitType }))
                            setTechOrgDropdownOpen(false)
                          }}
                        >
                          <span>{o.name}</span>
                          <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: o.unitType === 'supplier' ? '#e6f7ff' : '#f6ffed', color: o.unitType === 'supplier' ? '#1890ff' : '#52c41a' }}>
                            {o.unitType === 'supplier' ? '供应商' : '协议供货商'}
                          </span>
                        </button>
                      ))}
                    {systemOrgs.filter(o => o.name.toLowerCase().includes((techForm.org || '').toLowerCase())).length === 0 && (
                      <div className="px-3 py-2 text-sm text-gray-400">无匹配单位</div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm mb-1">联系电话</label>
                <input value={techForm.phone || ''} onChange={e => setTechForm({ ...techForm, phone: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">职称</label>
                <select value={techForm.role || '工程师'} onChange={e => setTechForm({ ...techForm, role: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }}>
                  <option>高级工程师</option>
                  <option>工程师</option>
                  <option>技术员</option>
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">专业领域</label>
                <input value={techForm.specialty || ''} onChange={e => setTechForm({ ...techForm, specialty: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">状态</label>
                <select value={techForm.status || 'on'} onChange={e => setTechForm({ ...techForm, status: e.target.value as 'on' | 'off' })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }}>
                  <option value="on">在职</option>
                  <option value="off">离职</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setTechModalOpen(false)} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>取消</button>
              <button onClick={saveTech} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 报修登记 Modal ═══════════ */}

      {faultModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="rounded-xl p-6 w-[500px] max-h-[90vh] overflow-y-auto" style={{ background: '#fff' }}>
            <h3 className="text-base font-semibold mb-4">报修登记</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">报修人</label>
                <input value={currentUser.name} readOnly className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none bg-gray-50 text-gray-500" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">所属机构</label>
                <input value={currentUser.org} readOnly className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none bg-gray-50 text-gray-500" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div className="relative">
                <label className="block text-sm mb-1">装备名称 <span className="text-red-500">*</span></label>
                <input
                  value={equipSearchText || faultForm.equipName}
                  onChange={e => {
                    const val = e.target.value
                    setEquipSearchText(val)
                    setFaultForm(prev => ({ ...prev, equipName: val, code: '' }))
                    setEquipSearchOpen(!!val)
                  }}
                  onFocus={() => { if ((equipSearchText || faultForm.equipName).length >= 1) setEquipSearchOpen(true) }}
                  className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200"
                  style={{ borderColor: 'var(--border-color)' }}
                  placeholder="输入装备名称搜索..."
                />
                {equipSearchOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 rounded-md border shadow-lg z-50 max-h-[200px] overflow-y-auto" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
                    {myEquipments
                      .filter(e => e.name.toLowerCase().includes((equipSearchText || faultForm.equipName).toLowerCase()) || e.code.toLowerCase().includes((equipSearchText || faultForm.equipName).toLowerCase()))
                      .map(e => (
                        <button
                          key={e.code}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors flex justify-between"
                          onClick={() => {
                            setFaultForm(prev => ({ ...prev, equipName: e.name, code: e.code, reporter: currentUser.name, org: currentUser.org }))
                            setEquipSearchText(e.name)
                            setEquipSearchOpen(false)
                          }}
                        >
                          <span>{e.name}</span>
                          <span className="text-gray-400 font-mono text-xs">{e.code}</span>
                        </button>
                      ))}
                    {myEquipments.filter(e => e.name.toLowerCase().includes((equipSearchText || faultForm.equipName).toLowerCase()) || e.code.toLowerCase().includes((equipSearchText || faultForm.equipName).toLowerCase())).length === 0 && (
                      <div className="px-3 py-2 text-sm text-gray-400">无匹配装备</div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm mb-1">装备编码</label>
                <input value={faultForm.code} readOnly className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none bg-gray-50 text-gray-500 font-mono" style={{ borderColor: 'var(--border-color)' }} placeholder="选择装备后自动填充" />
              </div>
              <div>
                <label className="block text-sm mb-1">故障描述 <span className="text-red-500">*</span></label>
                <textarea value={faultForm.faultDesc} onChange={e => setFaultForm({ ...faultForm, faultDesc: e.target.value })} rows={3} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setFaultModalOpen(false)} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>取消</button>
              <button onClick={addFault} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>提交</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 查看工单详情 Modal ═══════════ */}

      {detailFault && !repairModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }} onClick={() => setDetailFault(null)}>
          <div className="rounded-xl p-6 w-[520px] max-h-[90vh] overflow-y-auto" style={{ background: '#fff' }} onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-semibold">工单详情</h3>
              <button onClick={() => setDetailFault(null)} className="text-gray-400 hover:text-gray-600 text-lg">&times;</button>
            </div>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500">工单号</span><span className="font-mono">{detailFault.id}</span>
              </div>
              <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500">报修人</span><span>{detailFault.reporter} / {detailFault.org}</span>
              </div>
              <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500">装备信息</span><span>{detailFault.equipName} / {detailFault.code}</span>
              </div>
              <div className="py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500 block mb-1">故障描述</span><span className="text-gray-700">{detailFault.faultDesc}</span>
              </div>
              <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500">报修时间</span><span>{detailFault.reportTime}</span>
              </div>
              <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-gray-500">当前状态</span>
                <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[detailFault.status].color}15`, color: statusColors[detailFault.status].color }}>
                  {statusColors[detailFault.status].text}
                </span>
              </div>
              {detailFault.repairman && (
                <div className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="text-gray-500">维修人</span><span>{detailFault.repairman}</span>
                </div>
              )}
              {detailFault.result && (
                <div className="py-2">
                  <span className="text-gray-500 block mb-1">维修结果</span>
                  <div className="p-3 rounded" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                    {detailFault.result}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 维修反馈 Modal ═══════════ */}

      {repairModalOpen && detailFault && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="rounded-xl p-6 w-[480px]" style={{ background: '#fff' }}>
            <h3 className="text-base font-semibold mb-4">维修反馈 - {detailFault.id}</h3>
            <div className="mb-4 p-3 rounded" style={{ background: '#f5f5f5' }}>
              <div className="text-sm"><span className="text-gray-500">装备：</span>{detailFault.equipName}</div>
              <div className="text-sm"><span className="text-gray-500">故障：</span>{detailFault.faultDesc}</div>
            </div>
            <div>
              <label className="block text-sm mb-1">维修结果 <span className="text-red-500">*</span></label>
              <textarea value={repairResult} onChange={e => setRepairResult(e.target.value)} rows={4} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }} placeholder="请填写维修过程及结果..." />
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => { setRepairModalOpen(false); setRepairResult('') }} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>取消</button>
              <button onClick={submitRepairResult} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#52c41a' }}>提交反馈</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 评价登记 Modal ═══════════ */}

      {reviewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="rounded-xl p-6 w-[480px]" style={{ background: '#fff' }}>
            <h3 className="text-base font-semibold mb-4">服务评价</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">服务类型</label>
                <select value={reviewForm.serviceType} onChange={e => setReviewForm({ ...reviewForm, serviceType: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }}>
                  <option>维修服务</option>
                  <option>培训服务</option>
                  <option>咨询服务</option>
                </select>
              </div>
              <div>
                <label className="block text-sm mb-1">评价对象 <span className="text-red-500">*</span></label>
                <select
                  value={reviewForm.targetName}
                  onChange={e => {
                    const targetName = e.target.value
                    const selectedFault = faultList.find(f => f.id === targetName)
                    setReviewForm(prev => ({
                      ...prev,
                      targetName: selectedFault ? `${selectedFault.equipName}（${selectedFault.id}）` : targetName,
                      serviceType: '维修服务',
                    }))
                  }}
                  className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none"
                  style={{ borderColor: 'var(--border-color)' }}
                >
                  <option value="">请选择已完结的报修工单</option>
                  {faultList.filter(f => f.status === 'done').map(f => (
                    <option key={f.id} value={f.id}>{f.equipName} — {f.id}（{f.repairman || '系统'}）</option>
                  ))}
                </select>
                {faultList.filter(f => f.status === 'done').length === 0 && (
                  <p className="text-xs text-gray-400 mt-1">暂无已完结的报修工单可供评价</p>
                )}
              </div>
              <div>
                <label className="block text-sm mb-1">评分</label>
                <div className="flex items-center gap-2">
                  {[1, 2, 3, 4, 5].map(s => (
                    <button key={s} onClick={() => setReviewForm({ ...reviewForm, rating: s })} className="transition-transform hover:scale-110">
                      <svg width="28" height="28" viewBox="0 0 24 24" fill={s <= reviewForm.rating ? '#faad14' : '#e8e8e8'}>
                        <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/>
                      </svg>
                    </button>
                  ))}
                  <span className="text-sm ml-2" style={{ color: '#faad14' }}>{reviewForm.rating}分</span>
                </div>
              </div>
              <div>
                <label className="block text-sm mb-1">评价内容 <span className="text-red-500">*</span></label>
                <textarea value={reviewForm.content} onChange={e => setReviewForm({ ...reviewForm, content: e.target.value })} rows={3} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setReviewModalOpen(false)} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>取消</button>
              <button onClick={addReview} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#1890ff' }}>提交评价</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉登记 Modal ═══════════ */}

      {complaintModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="rounded-xl p-6 w-[500px]" style={{ background: '#fff' }}>
            <h3 className="text-base font-semibold mb-4">投诉登记</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm mb-1">投诉人</label>
                <input value={currentUser.name} readOnly className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none bg-gray-50 text-gray-500" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">所属机构</label>
                <input value={currentUser.org} readOnly className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none bg-gray-50 text-gray-500" style={{ borderColor: 'var(--border-color)' }} />
              </div>
              <div>
                <label className="block text-sm mb-1">投诉类型</label>
                <select value={complaintForm.targetType} onChange={e => setComplaintForm({ ...complaintForm, targetType: e.target.value })} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }}>
                  <option>供应商</option>
                  <option>维修人员</option>
                  <option>产品质量</option>
                  <option>服务态度</option>
                </select>
              </div>
              <div className="relative">
                <label className="block text-sm mb-1">投诉对象 <span className="text-red-500">*</span></label>
                <input
                  value={targetSearchText || complaintForm.targetName}
                  onChange={e => {
                    const val = e.target.value
                    setTargetSearchText(val)
                    setComplaintForm(prev => ({ ...prev, targetName: val, complainant: currentUser.name, org: currentUser.org }))
                    setTargetSearchOpen(!!val)
                  }}
                  onFocus={() => { if ((targetSearchText || complaintForm.targetName).length >= 1) setTargetSearchOpen(true) }}
                  className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-200"
                  style={{ borderColor: 'var(--border-color)' }}
                  placeholder="输入投诉对象名称搜索..."
                />
                {targetSearchOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 rounded-md border shadow-lg z-50 max-h-[200px] overflow-y-auto" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
                    {complaintTargets
                      .filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase()))
                      .map(t => (
                        <button
                          key={t}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors"
                          onClick={() => {
                            setComplaintForm(prev => ({ ...prev, targetName: t, complainant: currentUser.name, org: currentUser.org }))
                            setTargetSearchText(t)
                            setTargetSearchOpen(false)
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    {complaintTargets.filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase())).length === 0 && (
                      <div className="px-3 py-2 text-sm text-gray-400">无匹配数据</div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm mb-1">投诉内容 <span className="text-red-500">*</span></label>
                <textarea value={complaintForm.content} onChange={e => setComplaintForm({ ...complaintForm, content: e.target.value })} rows={3} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setComplaintModalOpen(false)} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>取消</button>
              <button onClick={addComplaint} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#ff4d4f' }}>提交投诉</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉回复 Modal ═══════════ */}

      {replyOpen && replyComplaint && (
        <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.4)' }}>
          <div className="rounded-xl p-6 w-[500px]" style={{ background: '#fff' }}>
            <h3 className="text-base font-semibold mb-4">投诉处理 - {replyComplaint.id}</h3>
            <div className="mb-4 p-3 rounded text-sm" style={{ background: '#f5f5f5' }}>
              <div><span className="text-gray-500">投诉人：</span>{replyComplaint.complainant} / {replyComplaint.org}</div>
              <div><span className="text-gray-500">投诉对象：</span>{replyComplaint.targetName}</div>
              <div className="mt-1"><span className="text-gray-500">内容：</span>{replyComplaint.content}</div>
            </div>
            {replyComplaint.reply ? (
              <div className="p-3 rounded" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                <span className="text-green-700 font-medium text-sm">已回复：</span>
                <p className="text-sm text-gray-700 mt-1">{replyComplaint.reply}</p>
              </div>
            ) : (
              <div>
                <label className="block text-sm mb-1">处理回复 <span className="text-red-500">*</span></label>
                <textarea value={replyContent} onChange={e => setReplyContent(e.target.value)} rows={4} className="w-full px-3 py-2 text-sm border rounded-md focus:outline-none" style={{ borderColor: 'var(--border-color)' }} placeholder="请填写处理意见..." />
              </div>
            )}
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} className="px-4 py-2 text-sm rounded-md border" style={{ borderColor: 'var(--border-color)' }}>
                {replyComplaint.reply ? '关闭' : '取消'}
              </button>
              {!replyComplaint.reply && (
                <button onClick={submitReply} className="px-4 py-2 text-sm rounded-md text-white" style={{ background: '#52c41a' }}>提交回复</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
