import { useState } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type SplitType = '拆分' | '组装'

// 库存物资类型（完整字段）
interface StockMaterial {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  unit: string
  produceDate: string
  validDate: string
  isFixedAsset: boolean
  price: number
  total: number
  equipCode: string
  supplier: string
  remark: string
  location: string
}

// 拆分/组装结果（含完整物资明细）
interface SplitResult {
  stockId: string
  name: string
  code: string
  qty: number
  isMain: boolean
  category: string
  spec: string
  produceDate: string
  validDate: string
  isFixedAsset: boolean
  unit: string
  price: number
  total: number
  supplier: string
  remark: string
  rfid: string
}

interface SplitRecord {
  id: string
  type: SplitType
  sourceName: string
  sourceCode: string
  sourceQty: number
  sourceSpec: string
  sourceCategory: string
  results: SplitResult[]
  operator: string
  operateTime: string
  status: string
  remark: string
}

const stockMaterials: StockMaterial[] = [
  { id: 's1', name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色', qty: 20, unit: '台', produceDate: '2023-06', validDate: '2028-06', isFixedAsset: true, price: 3200, total: 64000, equipCode: 'ZB-2023-001', supplier: '华为技术', remark: '在用', location: 'A仓库' },
  { id: 's2', name: '对讲机 PD780G', category: '通信设备', spec: 'PD780G/U段', qty: 15, unit: '台', produceDate: '2023-03', validDate: '2028-03', isFixedAsset: true, price: 1800, total: 27000, equipCode: 'ZB-2023-002', supplier: '海能达', remark: '在用', location: 'A仓库' },
  { id: 's3', name: '执法记录仪 DSJ-A7', category: '记录设备', spec: 'DSJ-A7/64G', qty: 30, unit: '台', produceDate: '2023-08', validDate: '2028-08', isFixedAsset: true, price: 1200, total: 36000, equipCode: 'ZB-2023-003', supplier: '科视达', remark: '在库', location: 'B仓库' },
  { id: 's4', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 10, unit: '件', produceDate: '2023-01', validDate: '2030-01', isFixedAsset: true, price: 2500, total: 25000, equipCode: 'ZB-2023-004', supplier: '中航防弹', remark: '在库', location: 'A仓库' },
  { id: 's5', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 8, unit: '顶', produceDate: '2023-04', validDate: '2030-04', isFixedAsset: true, price: 1500, total: 12000, equipCode: 'ZB-2023-005', supplier: '保利安防', remark: '在库', location: 'B仓库' },
  { id: 's6', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 40, unit: '根', produceDate: '2023-05', validDate: '2028-05', isFixedAsset: false, price: 280, total: 11200, equipCode: 'ZB-2023-006', supplier: '海洋王照明', remark: '在库', location: 'A仓库' },
  { id: 's7', name: '相机套装(含存储卡)', category: '组合装备', spec: 'DSLR+32G卡', qty: 5, unit: '套', produceDate: '2023-02', validDate: '2028-02', isFixedAsset: true, price: 8600, total: 43000, equipCode: 'SET-2023-001', supplier: '佳能中国', remark: '在库', location: 'A仓库' },
  { id: 's8', name: '防暴盾牌 FB-P', category: '防护装备', spec: 'FB-P/铝合金', qty: 12, unit: '面', produceDate: '2023-07', validDate: '2030-07', isFixedAsset: true, price: 800, total: 9600, equipCode: 'ZB-2023-007', supplier: '中航防弹', remark: '在库', location: 'B仓库' },
  { id: 's9', name: '伸缩警棍 ZG-T', category: '应急装备', spec: 'ZG-T/钛合金', qty: 25, unit: '根', produceDate: '2023-09', validDate: '2028-09', isFixedAsset: false, price: 350, total: 8750, equipCode: 'ZB-2023-008', supplier: '保利安防', remark: '在库', location: 'A仓库' },
  { id: 's10', name: '急救包 JJB-A', category: '应急装备', spec: 'JJB-A/综合型', qty: 18, unit: '个', produceDate: '2023-10', validDate: '2026-10', isFixedAsset: false, price: 220, total: 3960, equipCode: 'ZB-2023-009', supplier: '红立方', remark: '在库', location: 'B仓库' },
  { id: 's11', name: '存储卡 32G', category: '配件', spec: 'SDHC Class10', qty: 50, unit: '张', produceDate: '2023-03', validDate: '2030-03', isFixedAsset: false, price: 80, total: 4000, equipCode: 'PJ-2023-001', supplier: '闪迪', remark: '在库', location: 'A仓库' },
  { id: 's12', name: '相机镜头 50mm', category: '配件', spec: 'F1.8 STM', qty: 8, unit: '个', produceDate: '2023-02', validDate: '2030-02', isFixedAsset: false, price: 1200, total: 9600, equipCode: 'PJ-2023-002', supplier: '佳能中国', remark: '在库', location: 'A仓库' },
  { id: 's13', name: '相机机身', category: '记录设备', spec: 'DSLR/2400万像素', qty: 6, unit: '台', produceDate: '2023-02', validDate: '2028-02', isFixedAsset: true, price: 5800, total: 34800, equipCode: 'ZB-2023-010', supplier: '佳能中国', remark: '在库', location: 'A仓库' },
  { id: 's14', name: '绷带卷', category: '应急装备', spec: '10cm×5m', qty: 100, unit: '卷', produceDate: '2023-11', validDate: '2028-11', isFixedAsset: false, price: 15, total: 1500, equipCode: 'ZB-2023-011', supplier: '红立方', remark: '在库', location: 'B仓库' },
  { id: 's15', name: '消毒液 500ml', category: '应急装备', spec: '碘伏/500ml瓶装', qty: 60, unit: '瓶', produceDate: '2023-12', validDate: '2026-12', isFixedAsset: false, price: 25, total: 1500, equipCode: 'ZB-2023-012', supplier: '红立方', remark: '在库', location: 'B仓库' },
]

const tabs: { key: SplitType; label: string }[] = [
  { key: '拆分', label: '资产拆分' },
  { key: '组装', label: '资产组装' },
]

const demoRecords: SplitRecord[] = [
  {
    id: 'CF20240313001', type: '拆分', sourceName: '相机套装(含存储卡)', sourceCode: 'SET-2023-001', sourceQty: 5, sourceSpec: 'DSLR+32G卡', sourceCategory: '组合装备',
    results: [
      { stockId: 's13', name: '相机机身', code: 'ZB-2023-010', qty: 5, isMain: true, category: '记录设备', spec: 'DSLR/2400万像素', produceDate: '2023-02', validDate: '2028-02', isFixedAsset: true, unit: '台', price: 5800, total: 29000, supplier: '佳能中国', remark: '原套装主件', rfid: '' },
      { stockId: 's11', name: '存储卡 32G', code: 'PJ-2023-001', qty: 5, isMain: false, category: '配件', spec: 'SDHC Class10', produceDate: '2023-03', validDate: '2030-03', isFixedAsset: false, unit: '张', price: 80, total: 400, supplier: '闪迪', remark: '拆出附件', rfid: 'E200XXXXXXXX4126XXXX20001219' },
    ],
    operator: '王志强', operateTime: '2024-03-13 11:00', status: '已完成', remark: '拆出存储卡',
  },
  {
    id: 'ZB20240312002', type: '组装', sourceName: '相机机身+存储卡+镜头', sourceCode: 'ASM-001', sourceQty: 3, sourceSpec: '套装', sourceCategory: '组合装备',
    results: [
      { stockId: 's13', name: '相机机身', code: 'ZB-2023-010', qty: 3, isMain: true, category: '记录设备', spec: 'DSLR/2400万像素', produceDate: '2023-02', validDate: '2028-02', isFixedAsset: true, unit: '台', price: 5800, total: 17400, supplier: '佳能中国', remark: '主件', rfid: '' },
      { stockId: 's11', name: '存储卡 32G', code: 'PJ-2023-001', qty: 3, isMain: false, category: '配件', spec: 'SDHC Class10', produceDate: '2023-03', validDate: '2030-03', isFixedAsset: false, unit: '张', price: 80, total: 240, supplier: '闪迪', remark: '附件', rfid: 'E200XXXXXXXX4126XXXX20001219' },
      { stockId: 's12', name: '相机镜头 50mm', code: 'PJ-2023-002', qty: 3, isMain: false, category: '配件', spec: 'F1.8 STM', produceDate: '2023-02', validDate: '2030-02', isFixedAsset: false, unit: '个', price: 1200, total: 3600, supplier: '佳能中国', remark: '附件', rfid: 'E200XXXXXXXX5127XXXX20011220' },
    ],
    operator: '赵明华', operateTime: '2024-03-12 16:00', status: '已完成', remark: '组装完整相机套装',
  },
  {
    id: 'CF20240309003', type: '拆分', sourceName: '急救包 JJB-A', sourceCode: 'ZB-2023-009', sourceQty: 18, sourceSpec: 'JJB-A/综合型', sourceCategory: '应急装备',
    results: [
      { stockId: 's10', name: '急救包 JJB-A（空包）', code: 'ZB-2023-009-E', qty: 18, isMain: true, category: '应急装备', spec: 'JJB-A/空包', produceDate: '2023-10', validDate: '2026-10', isFixedAsset: false, unit: '个', price: 80, total: 1440, supplier: '红立方', remark: '空包主件', rfid: '' },
      { stockId: 's14', name: '绷带卷', code: 'ZB-2023-011', qty: 18, isMain: false, category: '应急装备', spec: '10cm×5m', produceDate: '2023-11', validDate: '2028-11', isFixedAsset: false, unit: '卷', price: 15, total: 270, supplier: '红立方', remark: '拆出附件', rfid: 'E200XXXXXXXX6128XXXX20021221' },
      { stockId: 's15', name: '消毒液 500ml', code: 'ZB-2023-012', qty: 18, isMain: false, category: '应急装备', spec: '碘伏/500ml瓶装', produceDate: '2023-12', validDate: '2026-12', isFixedAsset: false, unit: '瓶', price: 25, total: 450, supplier: '红立方', remark: '拆出附件', rfid: 'E200XXXXXXXX7129XXXX20031222' },
    ],
    operator: '刘建华', operateTime: '2024-03-09 10:30', status: '已完成', remark: '拆出急救用品',
  },
]

export default function SplitManagementPage({ onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState<SplitType>('拆分')
  const [records, setRecords] = useState<SplitRecord[]>(demoRecords)
  const [qName, setQName] = useState('')
  const [qCode, setQCode] = useState('')
  const [qOperator, setQOperator] = useState('')

  const [modalOpen, setModalOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [detailRecord, setDetailRecord] = useState<SplitRecord | null>(null)

  // ===== 库存选择弹窗状态 =====
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockModalMode, setStockModalMode] = useState<'main' | 'accessory'>('main')
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [stockSearchLocation, setStockSearchLocation] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: StockMaterial; qty: number }[]>([])

  // 拆分弹窗 state
  const [splitSource, setSplitSource] = useState<StockMaterial | null>(null)
  const [splitAccessories, setSplitAccessories] = useState<SplitResult[]>([])

  // 组装弹窗 state
  const [asmMain, setAsmMain] = useState<StockMaterial | null>(null)
  const [asmAccessories, setAsmAccessories] = useState<SplitResult[]>([])
  const [asmName, setAsmName] = useState('')

  const [formOperator, setFormOperator] = useState('')
  const [formRemark, setFormRemark] = useState('')

  const filtered = records
    .filter(r => r.type === activeTab)
    .filter(r => !qName || r.sourceName.includes(qName))
    .filter(r => !qCode || r.sourceCode.toLowerCase().includes(qCode.toLowerCase()))
    .filter(r => !qOperator || r.operator.includes(qOperator))

  const resetForm = () => {
    setSplitSource(null); setSplitAccessories([])
    setAsmMain(null); setAsmAccessories([]); setAsmName('')
    setFormOperator(''); setFormRemark('')
    setSelectedStockItems([])
  }

  // 打开库存装备弹窗
  const openStockModal = (mode: 'main' | 'accessory') => {
    setStockModalMode(mode)
    setStockSearchName('')
    setStockSearchCategory('')
    setStockSearchLocation('')
    setSelectedStockItems([])
    setStockModalOpen(true)
  }

  // 过滤库存
  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    if (stockSearchLocation && !s.location.includes(stockSearchLocation)) return false
    // 已选为主装备的不再出现在附件选择列表
    if (stockModalMode === 'accessory' && activeTab === '拆分' && splitSource && s.id === splitSource.id) return false
    if (stockModalMode === 'accessory' && activeTab === '组装' && asmMain && s.id === asmMain.id) return false
    // 已选的附件不再出现
    const currentAccessories = activeTab === '拆分' ? splitAccessories : asmAccessories
    if (currentAccessories.some(a => a.stockId === s.id)) return false
    return true
  })

  const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))
  const locationOptions = Array.from(new Set(stockMaterials.map(s => s.location)))

  // 切换库存选择
  const toggleStockSelect = (stock: StockMaterial) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.id === stock.id)
      if (exists) return prev.filter(p => p.stock.id !== stock.id)
      return [...prev, { stock, qty: 1 }]
    })
  }

  const updateSelectedQty = (stockId: string, newQty: number) => {
    const stock = stockMaterials.find(s => s.id === stockId)
    if (stock && newQty > stock.qty) { alert('选择数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.id === stockId ? { ...p, qty: Math.max(1, newQty) } : p))
  }

  // 确认选择库存装备
  const confirmStockItems = () => {
    if (selectedStockItems.length === 0) { setStockModalOpen(false); return }

    if (stockModalMode === 'main') {
      // 选择主装备
      const selected = selectedStockItems[0].stock
      if (activeTab === '拆分') {
        setSplitSource(selected)
      } else {
        setAsmMain(selected)
        if (!asmName) setAsmName(`${selected.name}套装`)
      }
    } else {
      // 选择附件装备 -> 转为 SplitResult
      const newResults: SplitResult[] = selectedStockItems.map(s => ({
        stockId: s.stock.id,
        name: s.stock.name,
        code: s.stock.equipCode,
        qty: s.qty,
        isMain: false,
        category: s.stock.category,
        spec: s.stock.spec,
        produceDate: s.stock.produceDate,
        validDate: s.stock.validDate,
        isFixedAsset: s.stock.isFixedAsset,
        unit: s.stock.unit,
        price: s.stock.price,
        total: s.stock.price * s.qty,
        supplier: s.stock.supplier,
        remark: s.stock.remark,
        rfid: '',
      }))
      if (activeTab === '拆分') {
        setSplitAccessories(prev => [...prev, ...newResults])
      } else {
        setAsmAccessories(prev => [...prev, ...newResults])
      }
    }
    setStockModalOpen(false)
    setSelectedStockItems([])
  }

  // 更新附件数量
  const updateAccessoryQty = (idx: number, newQty: number) => {
    const list = activeTab === '拆分' ? [...splitAccessories] : [...asmAccessories]
    if (list[idx]) {
      list[idx] = { ...list[idx], qty: Math.max(1, newQty), total: list[idx].price * Math.max(1, newQty) }
      if (activeTab === '拆分') {
        setSplitAccessories(list)
      } else {
        setAsmAccessories(list)
      }
    }
  }

  // 删除附件
  const removeAccessory = (idx: number) => {
    if (activeTab === '拆分') setSplitAccessories(prev => prev.filter((_, i) => i !== idx))
    else setAsmAccessories(prev => prev.filter((_, i) => i !== idx))
  }

  // 生成RFID编码（基于装备名称和装备编码）
  const generateRFID = (name: string, code: string) => {
    if (!name || !code) return ''
    const hash = code.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
    const nameHash = name.split('').reduce((s, c) => s + c.charCodeAt(0), 0)
    const seg1 = String(hash % 10000).padStart(4, '0')
    const seg2 = String(nameHash % 10000).padStart(4, '0')
    const seg3 = String((hash * nameHash) % 10000).padStart(4, '0')
    const seg4 = String((hash + nameHash) % 10000).padStart(4, '0')
    return `E200${seg1}${seg2}${seg3}${seg4}`
  }

  // 添加空附属装备行
  const addEmptyAccessory = () => {
    const emptyRow: SplitResult = {
      stockId: `new-${Date.now()}`,
      name: '', code: '', qty: 1, isMain: false,
      category: '', spec: '', produceDate: '', validDate: '',
      isFixedAsset: false, unit: '件', price: 0, total: 0,
      supplier: '', remark: '', rfid: '',
    }
    if (activeTab === '拆分') {
      setSplitAccessories(prev => [...prev, emptyRow])
    } else {
      setAsmAccessories(prev => [...prev, emptyRow])
    }
  }

  // 更新附件字段
  const updateAccessoryField = (idx: number, field: keyof SplitResult, value: string | number) => {
    const list = activeTab === '拆分' ? [...splitAccessories] : [...asmAccessories]
    if (list[idx]) {
      list[idx] = { ...list[idx], [field]: value }
      if (field === 'qty' || field === 'price') {
        list[idx].total = (list[idx].qty || 0) * (list[idx].price || 0)
      }
      if (activeTab === '拆分') {
        setSplitAccessories(list)
      } else {
        setAsmAccessories(list)
      }
    }
  }

  const handleSave = () => {
    if (!formOperator) { alert('请输入操作人'); return }

    let results: SplitResult[] = []
    let sourceName = '', sourceCode = '', sourceQty = 0, sourceSpec = '', sourceCategory = ''

    if (activeTab === '拆分') {
      if (!splitSource) { alert('请选择组合装备'); return }
      sourceName = splitSource.name; sourceCode = splitSource.equipCode; sourceQty = splitSource.qty
      sourceSpec = splitSource.spec; sourceCategory = splitSource.category
      results = [
        {
          stockId: splitSource.id, name: splitSource.name, code: splitSource.equipCode,
          qty: splitSource.qty, isMain: true, category: splitSource.category,
          spec: splitSource.spec, produceDate: splitSource.produceDate,
          validDate: splitSource.validDate, isFixedAsset: splitSource.isFixedAsset,
          unit: splitSource.unit, price: splitSource.price, total: splitSource.total,
          supplier: splitSource.supplier, remark: '原装备主件', rfid: '',
        },
        ...splitAccessories,
      ]
    } else {
      if (!asmMain) { alert('请选择主件装备'); return }
      sourceName = asmName || `${asmMain.name}套装`; sourceCode = `ASM-${Date.now()}`; sourceQty = asmMain.qty
      sourceSpec = '套装'; sourceCategory = '组合装备'
      results = [
        {
          stockId: asmMain.id, name: sourceName, code: sourceCode,
          qty: asmMain.qty, isMain: true, category: asmMain.category,
          spec: asmMain.spec, produceDate: asmMain.produceDate,
          validDate: asmMain.validDate, isFixedAsset: asmMain.isFixedAsset,
          unit: asmMain.unit, price: asmMain.price, total: asmMain.total,
          supplier: asmMain.supplier, remark: '组装主件', rfid: '',
        },
        ...asmAccessories,
      ]
    }

    const newRecord: SplitRecord = {
      id: `${activeTab === '拆分' ? 'CF' : 'ZB'}${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(records.length + 1).padStart(3, '0')}`,
      type: activeTab, sourceName, sourceCode, sourceQty, sourceSpec, sourceCategory,
      results, operator: formOperator,
      operateTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status: '已完成', remark: formRemark,
    }
    setRecords(prev => [newRecord, ...prev])
    setModalOpen(false)
    resetForm()
  }

  const typeTagMap: Record<SplitType, { color: string; bg: string }> = {
    '拆分': { color: '#52c41a', bg: '#f6ffed' },
    '组装': { color: '#faad14', bg: '#fffbe6' },
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
          返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>拆分管理</span>
      </div>

      {/* 操作栏 */}
      <div className="flex items-center justify-between">
        <button className="btn-primary text-sm" onClick={() => { resetForm(); setModalOpen(true) }}>+ 新增{activeTab === '拆分' ? '拆分' : '组装'}</button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filtered.length} 条记录</span>
      </div>

      {/* 查询区域 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-36 text-sm" placeholder="模糊查询" value={qName} onChange={e => setQName(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编号</label><input className="form-input w-36 text-sm font-mono" placeholder="请输入" value={qCode} onChange={e => setQCode(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作人</label><input className="form-input w-28 text-sm" placeholder="请输入" value={qOperator} onChange={e => setQOperator(e.target.value)} /></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default text-sm" onClick={() => { setQName(''); setQCode(''); setQOperator('') }}>重置</button>
            <button className="btn-primary text-sm">查询</button>
          </div>
        </div>
      </div>

      {/* 页签 */}
      <div className="flex gap-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
        {tabs.map(tab => (
          <button key={tab.key} className={activeTab === tab.key
            ? 'relative px-4 py-2.5 text-sm font-medium transition-colors text-[var(--primary-blue)]'
            : 'relative px-4 py-2.5 text-sm font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
          } onClick={() => { setActiveTab(tab.key); setModalOpen(false) }}>
            {tab.label}
            {activeTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: 'var(--primary-blue)' }} />}
          </button>
        ))}
      </div>

      {/* 表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>序号</th><th>操作编号</th><th>原装备名称</th><th>原装备编号</th><th>原数量</th><th>拆分/组装后明细</th><th>操作类型</th><th>操作人</th><th>操作时间</th><th>状态</th><th>备注</th><th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r, i) => (
              <tr key={r.id}>
                <td className="font-mono text-xs">{i + 1}</td>
                <td className="font-mono text-xs">{r.id}</td>
                <td className="font-medium">{r.sourceName}</td>
                <td className="font-mono text-xs">{r.sourceCode}</td>
                <td>{r.sourceQty} 件</td>
                <td className="text-xs">
                  {r.results.map((res, ri) => (
                    <span key={ri} className={`inline-block mr-2 mb-1 px-2 py-0.5 rounded text-xs ${res.isMain ? 'bg-blue-50 text-blue-600' : 'bg-gray-100 text-gray-500'}`}>
                      {res.name}({res.qty}{res.unit || '件'})
                    </span>
                  ))}
                </td>
                <td><span className="text-xs px-2 py-0.5 rounded font-medium" style={{ color: typeTagMap[r.type].color, background: typeTagMap[r.type].bg }}>{r.type}</span></td>
                <td>{r.operator}</td>
                <td className="text-xs">{r.operateTime}</td>
                <td><span className="tag text-xs tag-green">{r.status}</span></td>
                <td className="text-xs">{r.remark || '-'}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDetailRecord(r); setDetailOpen(true) }}>详情</button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={12} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
          </tbody>
        </table>
      </div>

      {/* ===== 新增弹窗 ===== */}
      {modalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[900px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                新增{activeTab === '拆分' ? '资产拆分' : '资产组装'}
              </h3>
              <button onClick={() => setModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* ── 资产拆分 ── */}
              {activeTab === '拆分' && (
                <>
                  <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold" style={{ color: '#52c41a' }}>选择组合装备</h4>
                      <button onClick={() => openStockModal('main')} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 选择装备</button>
                    </div>
                    {splitSource ? (
                      <div className="grid grid-cols-4 gap-3 text-xs p-3 rounded bg-gray-50">
                        <div><span style={{ color: 'var(--text-secondary)' }}>装备名称：</span><span className="font-medium">{splitSource.name}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{splitSource.equipCode}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span><span>{splitSource.spec}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>数量：</span><span className="font-mono">{splitSource.qty} {splitSource.unit}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>物资类别：</span><span>{splitSource.category}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>单价：</span><span className="font-mono">¥{splitSource.price.toLocaleString()}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>供应商：</span><span>{splitSource.supplier}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>生产日期：</span><span>{splitSource.produceDate}</span></div>
                      </div>
                    ) : (
                      <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                        <p className="text-xs">请点击上方按钮从库存选择组合装备</p>
                      </div>
                    )}
                  </div>

                  {splitSource && (
                    <div className="content-card p-4 border-l-4" style={{ borderColor: '#722ed1' }}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-semibold" style={{ color: '#722ed1' }}>拆分出的附属装备 <span style={{ color: 'var(--text-secondary)' }}>({splitAccessories.length} 种)</span></h4>
                        <button onClick={addEmptyAccessory} className="text-xs px-3 py-1.5 rounded-lg border border-purple-200 text-purple-600 hover:bg-purple-50 transition-colors">+ 添加附属装备</button>
                      </div>
                      {splitAccessories.length === 0 ? (
                        <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                          <p className="text-xs">请点击上方按钮添加附属装备</p>
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                            <thead>
                              <tr style={{ background: 'var(--table-header-bg)' }}>
                                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>#</th>
                                <th className="border p-2 w-28" style={{ borderColor: 'var(--border-color)' }}>装备名称 <span className="text-red-400">*</span></th>
                                <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                                <th className="border p-2 w-10" style={{ borderColor: 'var(--border-color)' }}>数量</th>
                                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                                <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                                <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                                <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                                <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                                <th className="border p-2 w-12" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                                <th className="border p-2 w-24" style={{ borderColor: 'var(--border-color)' }}>RFID</th>
                                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                              </tr>
                            </thead>
                            <tbody>
                              {splitAccessories.map((item, idx) => (
                                <tr key={item.stockId}>
                                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="装备名称（模糊查询）" value={item.name} onChange={e => updateAccessoryField(idx, 'name', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent font-mono" placeholder="编码（模糊查询）" value={item.code} onChange={e => updateAccessoryField(idx, 'code', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="类别" value={item.category} onChange={e => updateAccessoryField(idx, 'category', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="规格" value={item.spec} onChange={e => updateAccessoryField(idx, 'spec', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.qty} onChange={e => updateAccessoryQty(idx, Number(e.target.value))} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-center" placeholder="单位" value={item.unit} onChange={e => updateAccessoryField(idx, 'unit', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-right font-mono" type="number" min={0} value={item.price} onChange={e => updateAccessoryField(idx, 'price', Number(e.target.value))} />
                                  </td>
                                  <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-center" placeholder="生产日期" value={item.produceDate} onChange={e => updateAccessoryField(idx, 'produceDate', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-center" placeholder="有效期" value={item.validDate} onChange={e => updateAccessoryField(idx, 'validDate', e.target.value)} />
                                  </td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent" placeholder="供应商" value={item.supplier} onChange={e => updateAccessoryField(idx, 'supplier', e.target.value)} />
                                  </td>
                                  <td className="border p-2 text-center font-mono text-[10px]" style={{ borderColor: 'var(--border-color)', color: item.rfid ? '#52c41a' : 'var(--text-disabled)' }}>{item.rfid || generateRFID(item.name, item.code) || '-'}</td>
                                  <td className="border p-1 text-center" style={{ borderColor: 'var(--border-color)' }}>
                                    <button onClick={() => removeAccessory(idx)} className="text-red-400 hover:text-red-600">
                                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}

              {/* ── 资产组装 ── */}
              {activeTab === '组装' && (
                <>
                  <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>选择主件装备</h4>
                      <button onClick={() => openStockModal('main')} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 选择装备</button>
                    </div>
                    {asmMain ? (
                      <div className="grid grid-cols-4 gap-3 text-xs p-3 rounded bg-gray-50">
                        <div><span style={{ color: 'var(--text-secondary)' }}>装备名称：</span><span className="font-medium">{asmMain.name}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>装备编码：</span><span className="font-mono">{asmMain.equipCode}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>规格型号：</span><span>{asmMain.spec}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>数量：</span><span className="font-mono">{asmMain.qty} {asmMain.unit}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>物资类别：</span><span>{asmMain.category}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>单价：</span><span className="font-mono">¥{asmMain.price.toLocaleString()}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>供应商：</span><span>{asmMain.supplier}</span></div>
                        <div><span style={{ color: 'var(--text-secondary)' }}>生产日期：</span><span>{asmMain.produceDate}</span></div>
                      </div>
                    ) : (
                      <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                        <p className="text-xs">请点击上方按钮从库存选择主件装备</p>
                      </div>
                    )}
                    <div className="mt-3">
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>组装后名称</label>
                      <input className="form-input w-full" placeholder="如：相机套装" value={asmName} onChange={e => setAsmName(e.target.value)} />
                    </div>
                  </div>

                  {asmMain && (
                    <div className="content-card p-4 border-l-4" style={{ borderColor: '#722ed1' }}>
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="text-sm font-semibold" style={{ color: '#722ed1' }}>组装附件装备 <span style={{ color: 'var(--text-secondary)' }}>({asmAccessories.length} 种)</span></h4>
                        <button onClick={() => openStockModal('accessory')} className="text-xs px-3 py-1.5 rounded-lg border border-purple-200 text-purple-600 hover:bg-purple-50 transition-colors">+ 添加附件装备</button>
                      </div>
                      {asmAccessories.length === 0 ? (
                        <div className="text-center py-6 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                          <p className="text-xs">请点击上方按钮从库存选择附件装备</p>
                        </div>
                      ) : (
                        <div className="overflow-x-auto">
                          <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                            <thead>
                              <tr style={{ background: 'var(--table-header-bg)' }}>
                                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>#</th>
                                <th className="border p-2 w-28" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                                <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                                <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                                <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                                <th className="border p-2 w-12" style={{ borderColor: 'var(--border-color)' }}>数量</th>
                                <th className="border p-2 w-10" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                                <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                                <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                                <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                              </tr>
                            </thead>
                            <tbody>
                              {asmAccessories.map((item, idx) => (
                                <tr key={item.stockId}>
                                  <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                                  <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{item.name}</td>
                                  <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{item.code}</td>
                                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.category}</td>
                                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.spec}</td>
                                  <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                                    <input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.qty} onChange={e => updateAccessoryQty(idx, Number(e.target.value))} />
                                  </td>
                                  <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.unit}</td>
                                  <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.price.toLocaleString()}</td>
                                  <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                                  <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.produceDate}</td>
                                  <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.validDate}</td>
                                  <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.supplier}</td>
                                  <td className="border p-1 text-center" style={{ borderColor: 'var(--border-color)' }}>
                                    <button onClick={() => removeAccessory(idx)} className="text-red-400 hover:text-red-600">
                                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                    </button>
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}

              {/* 公共字段 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#13c2c2' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#13c2c2' }}>操作信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1">操作人 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入操作人姓名" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1">备注</label>
                    <input className="form-input w-full" placeholder="备注说明..." value={formRemark} onChange={e => setFormRemark(e.target.value)} />
                  </div>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSave}>确认</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备选择弹窗（左右分栏） ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[85vw] max-w-[1100px] h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {stockModalMode === 'main' ? '选择装备' : '选择附件装备'}
              </h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* 搜索区域 */}
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label>
                  <input className="form-input w-32" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label>
                  <select className="form-input w-28" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}>
                    <option value="">全部</option>
                    {categoryOptions.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置</label>
                  <select className="form-input w-28" value={stockSearchLocation} onChange={e => setStockSearchLocation(e.target.value)}>
                    <option value="">全部</option>
                    {locationOptions.map(l => <option key={l}>{l}</option>)}
                  </select>
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchName(''); setStockSearchCategory(''); setStockSearchLocation('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            {/* 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：库存装备列表 */}
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>
                        <input type="checkbox" disabled />
                      </th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>库存数量</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>存储位置</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.id === s.id)
                      return (
                        <tr
                          key={s.id}
                          className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`}
                          onClick={() => {
                            if (stockModalMode === 'main') {
                              // 主装备只能单选
                              setSelectedStockItems([{ stock: s, qty: 1 }])
                            } else {
                              toggleStockSelect(s)
                            }
                          }}
                        >
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>
                            <input type="checkbox" checked={isSelected} readOnly />
                          </td>
                          <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{s.name}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.category}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.spec || '-'}</td>
                          <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{s.equipCode}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.produceDate || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.validDate || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{s.qty}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{s.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.price.toLocaleString()}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.supplier}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.location}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && (
                      <tr><td colSpan={12} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedStockItems.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备选择</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.id} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>余量: {s.stock.qty}</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.id, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.id !== s.stock.id))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情弹窗（含完整物资明细） ===== */}
      {detailOpen && detailRecord && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[800px] max-w-[95vw] max-h-[88vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{detailRecord.type}详情</h3>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1 text-sm">
              {/* 基本信息 */}
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息</h4>
                <div className="grid grid-cols-4 gap-x-4 gap-y-2 text-xs">
                  {[
                    { label: '操作编号', value: detailRecord.id },
                    { label: '操作类型', value: detailRecord.type },
                    { label: '原装备名称', value: detailRecord.sourceName },
                    { label: '原装备编号', value: detailRecord.sourceCode },
                    { label: '原装备类别', value: detailRecord.sourceCategory },
                    { label: '原规格型号', value: detailRecord.sourceSpec },
                    { label: '原数量', value: `${detailRecord.sourceQty}` },
                    { label: '操作人', value: detailRecord.operator },
                    { label: '操作时间', value: detailRecord.operateTime },
                    { label: '状态', value: detailRecord.status },
                    { label: '备注', value: detailRecord.remark || '-' },
                  ].map(f => (
                    <div key={f.label} className="flex flex-col py-1">
                      <span className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 结果明细 - 完整物资明细表格 */}
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#722ed1' }}>{detailRecord.type}结果明细（{detailRecord.results.length} 条）</h4>
                <div className="overflow-x-auto">
                  <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                    <thead>
                      <tr style={{ background: 'var(--table-header-bg)' }}>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>序号</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>主/附</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>数量</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>RFID</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>固定资产</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                        <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                      </tr>
                    </thead>
                    <tbody>
                      {detailRecord.results.map((r, i) => (
                        <tr key={i} className={r.isMain ? 'bg-blue-50/50' : ''}>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{i + 1}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>
                            <span className="px-1.5 py-0.5 rounded text-[10px] font-medium" style={{ background: r.isMain ? '#1890ff' : '#52c41a', color: '#fff' }}>{r.isMain ? '主件' : '附件'}</span>
                          </td>
                          <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{r.name}</td>
                          <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{r.code}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{r.category}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{r.spec || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{r.qty}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{r.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{r.price?.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono font-medium" style={{ borderColor: 'var(--border-color)' }}>¥{r.total?.toLocaleString()}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{r.produceDate || '-'}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{r.validDate || '-'}</td>
                          <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{r.rfid || '-'}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{r.isFixedAsset ? '是' : '否'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{r.supplier || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{r.remark || '-'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
