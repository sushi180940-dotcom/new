import React, { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

// ========== 左侧导航配置 ==========
interface NavItem {
  key: string
  label: string
  group?: string
}

const navItems: NavItem[] = [
  { key: 'org', label: '机构管理', group: '系统管理' },
  { key: 'role', label: '角色管理', group: '系统管理' },
  { key: 'user', label: '用户管理', group: '系统管理' },
  { key: 'device', label: '终端设备', group: '系统管理' },
  { key: 'log', label: '日志管理', group: '系统管理' },
  { key: 'approval', label: '审批管理', group: '系统管理' },
  { key: 'rule', label: '编码规则', group: '装备编码' },
  { key: 'mgmt', label: '编码管理', group: '装备编码' },
  { key: 'trace', label: '编码溯源', group: '装备编码' },
]

const navIcons: Record<string, React.ReactNode> = {
  org: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 21h18M5 21V7l8-4 8 4v14M9 21v-6h6v6"/></svg>,
  role: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  user: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  device: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
  log: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  approval: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>,
  rule: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>,
  mgmt: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  trace: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>,
  dict: <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/><line x1="8" y1="7" x2="16" y2="7"/><line x1="8" y1="11" x2="12" y2="11"/></svg>,
}

// ========== 机构管理类型 ==========
interface OrgNode {
  name: string
  expanded?: boolean
  leaf?: boolean
  children?: OrgNode[]
}

// ========== 审批管理类型 ==========
interface ApprovalItem {
  id: string
  type: string
  applicant: string
  applyTime: string
  currentNode: string
  status: 'pending' | 'approved' | 'rejected'
  remark?: string
}

const approvalData: ApprovalItem[] = [
  { id: 'SP2024001', type: '入库审批', applicant: '张三', applyTime: '2024-03-15 09:30', currentNode: '部门主管审批', status: 'pending' },
  { id: 'SP2024002', type: '领用审批', applicant: '李四', applyTime: '2024-03-14 14:20', currentNode: '仓库管理员审批', status: 'pending' },
  { id: 'SP2024003', type: '报修审批', applicant: '王五', applyTime: '2024-03-13 11:00', currentNode: '已完成', status: 'approved', remark: '同意维修' },
  { id: 'SP2024004', type: '报废审批', applicant: '赵六', applyTime: '2024-03-12 16:45', currentNode: '财务审批', status: 'pending' },
  { id: 'SP2024005', type: '入库审批', applicant: '钱七', applyTime: '2024-03-11 08:30', currentNode: '已驳回', status: 'rejected', remark: '信息不完整' },
  { id: 'SP2024006', type: '领用审批', applicant: '孙八', applyTime: '2024-03-10 10:15', currentNode: '已完成', status: 'approved', remark: '同意领用' },
]

const approvalStatusConfig: Record<string, { label: string; color: string; bg: string }> = {
  pending: { label: '审批中', color: '#d4880f', bg: '#f5efe6' },
  approved: { label: '已通过', color: '#1a4b8c', bg: '#e8eef5' },
  rejected: { label: '已驳回', color: '#c0392b', bg: '#f5e6e6' },
}

// ========== 编码规则类型 ==========
interface CodeSegment {
  id: number
  name: string
  length: number
  type: '字母' | '数字' | '字母数字'
  valueSource: '固定值' | '关联字典' | '自动流水'
  fixedValue?: string
  dictName?: string
  resetMode?: '按年度归零' | '按月度归零' | '永不归零'
  required: boolean
}

interface CodeRuleData {
  id: string
  name: string
  segments: CodeSegment[]
  status: 'active' | 'inactive'
  createTime: string
  updateTime: string
}

interface CodeRuleChangeLog {
  id: string
  ruleId: string
  operator: string
  time: string
  field: string
  oldValue: string
  newValue: string
  reason: string
}

// ========== 编码管理类型 ==========
type ApplyStatus = 'pending' | 'approved' | 'rejected'

interface CodeEquipItem {
  id: string
  applyId: string
  orderId: string
  orderNo: string
  supplier: string
  equipName: string
  code: string
  isPlaceholderCode: boolean
  status: ApplyStatus
  applicant: string
  applyTime: string
  approver?: string
  approveTime?: string
  remark?: string
}

interface CodeApplyData {
  id: string
  orderId: string
  orderNo: string
  supplier: string
  applicant: string
  applyTime: string
  status: ApplyStatus
  approver?: string
  approveTime?: string
  items: CodeEquipItem[]
  remark?: string
}

// ========== 编码导入类型 ==========
type CheckResult = 'match' | 'conflict' | 'new'
type ConflictResolution = 'system' | 'excel' | 'skip'
type ImportStep = 'upload' | 'preview' | 'confirm' | 'done'

interface ImportRow {
  id: string
  rowNum: number
  orderNo: string
  equipName: string
  supplier: string
  excelCode: string
  systemCode: string
  checkResult: CheckResult
  conflictReason?: string
  resolution: ConflictResolution
  selected: boolean
}

interface ImportLog {
  id: string
  operator: string
  time: string
  filename: string
  totalCount: number
  matchCount: number
  conflictCount: number
  newCount: number
  skipCount: number
  details: string
}

// ========== 编码溯源类型 ==========
interface TraceRecord {
  id: string
  code: string
  equipName: string
  spec: string
  manufacturer: string
  supplier: string
  usingUnit: string
  currentOwner: string
  status: 'in_stock' | 'in_use' | 'under_repair' | 'transferred' | 'retired'
  warehouseTime: string
  lastOperationTime: string
  lastOperationType: string
  lastOperator: string
  lifecycle: TraceEvent[]
}

interface TraceEvent {
  id: string
  time: string
  type: '入库' | '出库' | '使用' | '维修' | '调拨' | '盘点' | '报废'
  operator: string
  unit: string
  description: string
  detail?: string
}

// ========== 编码字典类型 ==========
type DictType = '标签类别' | '一级分类' | '二级分类' | '三级分类' | '装备品种名称' | '型号编码' | '生产日期' | '有效期' | '供应商信用代码'

interface CodeDictData {
  id: string
  code: string
  name: string
  dictType: DictType
  parentCode?: string
  parentName?: string
  maintainCycle?: string
  validityPeriod?: string
  status: 'active' | 'inactive'
  sortOrder: number
  createTime: string
  remark?: string
}

// ========== 样例数据 ==========
const rulesData: CodeRuleData[] = [
  {
    id: 'RUL001', name: '通用装备编码规则',
    segments: [
      { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
      { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
      { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
      { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
      { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
      { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
      { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
      { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
      { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
      { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
    ],
    status: 'active',
    createTime: '2024-01-10', updateTime: '2024-06-15'
  },
]

const traceData: TraceRecord[] = [
  {
    id: 'TR001', code: '1-0-1-01-P001-001-20240315-05-001XXXXXX-0001', equipName: '数字对讲机 PD780G', spec: 'PD780G/400-470MHz',
    manufacturer: '海能达通信', supplier: '华为技术', usingUnit: '第一支队', currentOwner: '第一支队·通信科',
    status: 'in_use', warehouseTime: '2024-03-15 09:30', lastOperationTime: '2024-06-10 14:20',
    lastOperationType: '日常领用', lastOperator: '张三',
    lifecycle: [
      { id: 'EV001', time: '2024-03-15 09:30', type: '入库', operator: '李四', unit: '装备仓库', description: '新购入库', detail: '合同编号HT2024001，订单DD2024001，数量50台' },
      { id: 'EV002', time: '2024-03-20 10:00', type: '出库', operator: '王五', unit: '装备仓库', description: '分配至第一支队', detail: '出库单号CK2024001，分配数量10台' },
      { id: 'EV003', time: '2024-03-22 08:30', type: '使用', operator: '张三', unit: '第一支队', description: '日常通信保障', detail: '使用地点：指挥中心' },
      { id: 'EV004', time: '2024-05-10 11:20', type: '维修', operator: '赵六', unit: '维修中心', description: '更换电池', detail: '原电池老化，更换新电池，维修单WX2024001' },
      { id: 'EV005', time: '2024-06-01 09:00', type: '盘点', operator: '李四', unit: '第一支队', description: '季度盘点', detail: '状态正常，数量核对无误' },
      { id: 'EV006', time: '2024-06-10 14:20', type: '使用', operator: '张三', unit: '第一支队', description: '日常通信保障', detail: '使用地点：巡逻区域A' },
    ]
  },
  {
    id: 'TR002', code: '1-0-1-01-P002-002-20240401-05-002XXXXXX-0002', equipName: '应急照明灯 YJ-200', spec: 'YJ-200/LED 200W',
    manufacturer: '海洋王照明', supplier: '中兴通讯', usingUnit: '第二支队', currentOwner: '第二支队·应急科',
    status: 'in_stock', warehouseTime: '2024-04-01 10:00', lastOperationTime: '2024-05-28 16:00',
    lastOperationType: '入库验收', lastOperator: '钱七',
    lifecycle: [
      { id: 'EV007', time: '2024-04-01 10:00', type: '入库', operator: '钱七', unit: '装备仓库', description: '新购入库', detail: '合同编号HT2024002，订单DD2024002' },
      { id: 'EV008', time: '2024-05-28 16:00', type: '盘点', operator: '钱七', unit: '装备仓库', description: '月度盘点', detail: '库存20台，状态正常' },
    ]
  },
  {
    id: 'TR003', code: '1-0-1-01-P003-003-20240210-10-003XXXXXX-0003', equipName: '监控摄像头 HK-4K100', spec: 'HK-4K100/800万像素',
    manufacturer: '海康威视', supplier: '海康威视', usingUnit: '第三支队', currentOwner: '第三支队·技防科',
    status: 'under_repair', warehouseTime: '2024-02-10 14:00', lastOperationTime: '2024-06-08 09:30',
    lastOperationType: '故障报修', lastOperator: '孙八',
    lifecycle: [
      { id: 'EV009', time: '2024-02-10 14:00', type: '入库', operator: '周九', unit: '装备仓库', description: '新购入库' },
      { id: 'EV010', time: '2024-02-15 08:00', type: '出库', operator: '周九', unit: '装备仓库', description: '分配至第三支队' },
      { id: 'EV011', time: '2024-03-01 10:00', type: '调拨', operator: '吴十', unit: '指挥中心', description: '临时调拨至指挥中心', detail: '调拨单DB2024001' },
      { id: 'EV012', time: '2024-04-20 15:30', type: '调拨', operator: '吴十', unit: '第三支队', description: '调拨归还' },
      { id: 'EV013', time: '2024-06-08 09:30', type: '维修', operator: '孙八', unit: '维修中心', description: '镜头模糊，送修', detail: '维修单WX2024002，预计3个工作日' },
    ]
  },
]

const importLogData: ImportLog[] = [
  { id: 'IM001', operator: '管理员', time: '2024-06-15 14:30', filename: '装备编码导入_20240615.xlsx', totalCount: 50, matchCount: 42, conflictCount: 5, newCount: 3, skipCount: 0, details: '42条一致直接导入，5条冲突已按系统编码覆盖，3条新建编码' },
  { id: 'IM002', operator: '管理员', time: '2024-06-10 09:15', filename: '装备编码导入_20240610.xlsx', totalCount: 30, matchCount: 25, conflictCount: 3, newCount: 2, skipCount: 2, details: '25条一致，3条冲突采用Excel编码，2条新建，2条跳过' },
]

const changeLogData: CodeRuleChangeLog[] = [
  { id: 'LOG001', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:30', field: '规则名称', oldValue: '通用装备编码规则V1', newValue: '通用装备编码规则', reason: '简化命名' },
  { id: 'LOG002', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:32', field: '适用装备中类', oldValue: 'TX01', newValue: '全部', reason: '扩大适用范围' },
  { id: 'LOG003', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:35', field: '属性后缀-长度', oldValue: '1位', newValue: '2位', reason: '满足扩展需求' },
]

const codeApplyData: CodeApplyData[] = [
  {
    id: 'BM2024001', orderId: 'DD2024001', orderNo: 'DD2024001', supplier: '华为技术',
    status: 'approved', applicant: '张三', applyTime: '2024-03-01 09:30',
    approver: '李主任', approveTime: '2024-03-01 14:00', remark: '手持终端编码申请',
    items: [
      { id: 'E001', applyId: 'BM2024001', orderId: 'DD2024001', orderNo: 'DD2024001', supplier: '华为技术', equipName: '数字对讲机 PD780G', code: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', isPlaceholderCode: true, status: 'approved', applicant: '张三', applyTime: '2024-03-01 09:30', approver: '李主任', approveTime: '2024-03-01 14:00' },
    ]
  },
  {
    id: 'BM2024002', orderId: 'DD2024002', orderNo: 'DD2024002', supplier: '中兴通讯',
    status: 'pending', applicant: '李四', applyTime: '2024-03-05 10:15', remark: '应急照明设备编码申请',
    items: [
      { id: 'E002', applyId: 'BM2024002', orderId: 'DD2024002', orderNo: 'DD2024002', supplier: '中兴通讯', equipName: '应急照明灯 YJ-200', code: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', isPlaceholderCode: true, status: 'pending', applicant: '李四', applyTime: '2024-03-05 10:15' },
    ]
  },
  {
    id: 'BM2024003', orderId: 'DD2024003', orderNo: 'DD2024003', supplier: '海康威视',
    status: 'pending', applicant: '王五', applyTime: '2024-03-10 11:00', remark: '监控摄像头编码申请',
    items: [
      { id: 'E003', applyId: 'BM2024003', orderId: 'DD2024003', orderNo: 'DD2024003', supplier: '海康威视', equipName: '监控摄像头 HK-4K100', code: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0003', isPlaceholderCode: true, status: 'pending', applicant: '王五', applyTime: '2024-03-10 11:00' },
    ]
  },
  {
    id: 'BM2024004', orderId: 'DD2024004', orderNo: 'DD2024004', supplier: '大疆创新',
    status: 'rejected', applicant: '赵六', applyTime: '2024-03-12 14:20',
    approver: '李主任', approveTime: '2024-03-12 15:00', remark: '信息不完整，驳回补充',
    items: [
      { id: 'E004', applyId: 'BM2024004', orderId: 'DD2024004', orderNo: 'DD2024004', supplier: '大疆创新', equipName: '卫星便携站 S9000', code: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', isPlaceholderCode: true, status: 'rejected', applicant: '赵六', applyTime: '2024-03-12 14:20', approver: '李主任', approveTime: '2024-03-12 15:00' },
    ]
  },
  {
    id: 'BM2024005', orderId: 'DD2024005', orderNo: 'DD2024005', supplier: '海能达',
    status: 'pending', applicant: '钱七', applyTime: '2024-03-15 09:00', remark: '对讲机编码申请',
    items: [
      { id: 'E005', applyId: 'BM2024005', orderId: 'DD2024005', orderNo: 'DD2024005', supplier: '海能达', equipName: '对讲机 HP780', code: '1-0-1-01-P005-001-[日期]-05-005XXXXXX-0005', isPlaceholderCode: true, status: 'pending', applicant: '钱七', applyTime: '2024-03-15 09:00' },
    ]
  },
]

const codeDictData: CodeDictData[] = [
  { id: 'D001', code: '0', name: '装备标签', dictType: '标签类别', status: 'active', sortOrder: 1, createTime: '2024-01-10', remark: '单个装备的标签' },
  { id: 'D002', code: '1', name: '箱标签', dictType: '标签类别', status: 'active', sortOrder: 2, createTime: '2024-01-10', remark: '整箱装备的标签' },
  { id: 'D003', code: 'YJ', name: '应急救援', dictType: '一级分类', status: 'active', sortOrder: 1, createTime: '2024-01-10', remark: '应急救援类装备' },
  { id: 'D004', code: 'TX', name: '通信装备', dictType: '一级分类', status: 'active', sortOrder: 2, createTime: '2024-01-10', remark: '通信类装备' },
  { id: 'D005', code: 'AQ', name: '安全防护', dictType: '一级分类', status: 'active', sortOrder: 3, createTime: '2024-01-10', remark: '安全防护类装备' },
  { id: 'D006', code: 'JT', name: '交通工具', dictType: '一级分类', status: 'active', sortOrder: 4, createTime: '2024-01-10', remark: '交通工具类装备' },
  { id: 'D007', code: 'YJ01', name: '救生器材', dictType: '二级分类', parentCode: 'YJ', parentName: '应急救援', status: 'active', sortOrder: 1, createTime: '2024-01-10' },
  { id: 'D008', code: 'YJ02', name: '消防器材', dictType: '二级分类', parentCode: 'YJ', parentName: '应急救援', status: 'active', sortOrder: 2, createTime: '2024-01-10' },
  { id: 'D009', code: 'TX01', name: '对讲机', dictType: '二级分类', parentCode: 'TX', parentName: '通信装备', status: 'active', sortOrder: 3, createTime: '2024-01-10' },
  { id: 'D010', code: 'TX02', name: '卫星便携站', dictType: '二级分类', parentCode: 'TX', parentName: '通信装备', status: 'active', sortOrder: 4, createTime: '2024-01-10' },
  { id: 'D011', code: 'TX0101', name: '数字对讲机', dictType: '三级分类', parentCode: 'TX01', parentName: '对讲机', status: 'active', sortOrder: 1, createTime: '2024-01-15' },
  { id: 'D012', code: 'TX0102', name: '模拟对讲机', dictType: '三级分类', parentCode: 'TX01', parentName: '对讲机', status: 'inactive', sortOrder: 2, createTime: '2024-01-15', remark: '逐步淘汰中' },
  { id: 'D013', code: 'P001', name: '海能达PD780G', dictType: '装备品种名称', parentCode: 'TX0101', parentName: '数字对讲机', status: 'active', sortOrder: 1, createTime: '2024-02-01', remark: '主流型号' },
  { id: 'D014', code: 'P002', name: '摩托罗拉P8668i', dictType: '装备品种名称', parentCode: 'TX0101', parentName: '数字对讲机', status: 'active', sortOrder: 2, createTime: '2024-02-01', remark: '高端型号' },
  { id: 'D015', code: 'PRODDATE', name: '生产日期', dictType: '生产日期', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '6位，YYMMDD格式' },
  { id: 'D016', code: '240315', name: '2024年3月15日', dictType: '生产日期', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '示例：240315' },
  { id: 'D017', code: '240601', name: '2024年6月1日', dictType: '生产日期', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '示例：240601' },
  { id: 'D018', code: 'VALIDITY', name: '有效期', dictType: '有效期', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '2位，年数' },
  { id: 'D019', code: '05', name: '5年', dictType: '有效期', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '有效期5年' },
  { id: 'D020', code: '10', name: '10年', dictType: '有效期', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '有效期10年' },
  { id: 'DXH001', code: 'XH001', name: '型号编码', dictType: '型号编码', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '3位，装备型号编码' },
  { id: 'DXH002', code: '001', name: 'PD780G标准版', dictType: '型号编码', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '海能达PD780G' },
  { id: 'DXH003', code: '002', name: 'P8668i高端版', dictType: '型号编码', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '摩托罗拉P8668i' },
  { id: 'DXH004', code: '003', name: 'S9000卫星版', dictType: '型号编码', status: 'active', sortOrder: 4, createTime: '2024-03-01', remark: '卫星便携站S9000' },
  { id: 'D021', code: 'SUPPCODE', name: '供应商信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '9位，组织机构代码第9-17位' },
  { id: 'D022', code: '001XXXXXX', name: '华为技术信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '示例' },
  { id: 'D023', code: '002XXXXXX', name: '海康威视信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '示例' },
]

const segmentColorMap: Record<number, string> = {
  1: '#1a4b8c', 2: '#2e5fa0', 3: '#4373b4', 4: '#5787c8',
  5: '#6c9bdc', 6: '#8bb3d4', 7: '#c0392b', 8: '#d4880f', 9: '#1a4b8c', 10: '#4373b4',
}

const checkResultConfig: Record<CheckResult, { label: string; color: string; bg: string }> = {
  match: { label: '一致', color: '#1a4b8c', bg: '#e8eef5' },
  conflict: { label: '冲突', color: '#c0392b', bg: '#f5e6e6' },
  new: { label: '新建', color: '#1a4b8c', bg: '#e8eef5' },
}

const applyStatusConfig: Record<ApplyStatus, { label: string; color: string; bg: string }> = {
  pending: { label: '待审批', color: '#d4880f', bg: '#f5efe6' },
  approved: { label: '已通过', color: '#1a4b8c', bg: '#e8eef5' },
  rejected: { label: '已驳回', color: '#c0392b', bg: '#f5e6e6' },
}

const traceStatusMap: Record<string, { label: string; color: string; bg: string; border: string }> = {
  in_stock: { label: '在库', color: '#1a4b8c', bg: '#e8eef5', border: '#b7eb8f' },
  in_use: { label: '在用', color: '#1a4b8c', bg: '#e8eef5', border: '#91d5ff' },
  under_repair: { label: '维修中', color: '#c0392b', bg: '#f5e6e6', border: '#ffccc7' },
  transferred: { label: '调拨中', color: '#d4880f', bg: '#f5efe6', border: '#ffe58f' },
  retired: { label: '已报废', color: '#8c8c8c', bg: '#f5f5f5', border: '#d9d9d9' },
}

const orderOptions = [
  { id: 'DD2024001', no: 'DD2024001', supplier: '海康威视', equipName: '监控摄像头 HK-4K100', qty: 50, status: '待编码' },
  { id: 'DD2024002', no: 'DD2024002', supplier: '华为技术', equipName: '数字对讲机 PD780G', qty: 30, status: '待编码' },
  { id: 'DD2024003', no: 'DD2024003', supplier: '中兴通讯', equipName: '应急照明灯 YJ-200', qty: 20, status: '待编码' },
  { id: 'DD2024004', no: 'DD2024004', supplier: '大疆创新', equipName: '卫星便携站 S9000', qty: 15, status: '待编码' },
]

// ========== 系统管理数据 ==========
const orgTreeData: OrgNode[] = [
  {
    name: '浙江省',
    expanded: true,
    children: [
      {
        name: '杭州市',
        expanded: true,
        children: [
          {
            name: '西湖区',
            expanded: true,
            children: [
              { name: '省厅', leaf: true },
              { name: '西湖分局', leaf: true },
            ],
          },
          { name: '拱墅区', leaf: true },
        ],
      },
      { name: '宁波市', leaf: true },
      { name: '温州市', leaf: true },
    ],
  },
]

const rolesData = [
  { name: '超级管理员', desc: '系统最高权限' },
  { name: '装备管理员', desc: '装备全生命周期管理' },
  { name: '采购员', desc: '采购申请与合同管理' },
  { name: '库管员', desc: '出入库与盘点' },
  { name: '审计员', desc: '数据查询与审计' },
]

const devicesData = [
  { id: 'DEV001', name: '主通道感知', type: 'RFID通道', location: 'A栋仓库入口', ip: '192.168.1.100', status: 'online' },
  { id: 'DEV002', name: '人脸门禁', type: '人脸门禁', location: 'A栋仓库门', ip: '192.168.1.101', status: 'online' },
  { id: 'DEV003', name: '抓拍机', type: '抓拍机', location: 'A-102区域', ip: '192.168.1.102', status: 'offline' },
]

const logsData = [
  { id: 'LOG0001', user: '张三', time: '10:23:15', type: '登录', module: '系统', content: '登录成功', ip: '192.168.1.100' },
  { id: 'LOG0002', user: '张三', time: '10:24:30', type: '数据查询', module: '库存管理', content: '查询库存明细', ip: '192.168.1.100' },
  { id: 'LOG0003', user: '张三', time: '10:25:45', type: '数据修改', module: '库存管理', content: '修改装备状态', ip: '192.168.1.100' },
]


export default function SystemPage({ activeSubTab }: Props) {
  // ===== 激活的导航项 =====
  const allNavKeys = navItems.map(n => n.key)
  const [activeTab, setActiveTab] = useState(activeSubTab && allNavKeys.includes(activeSubTab) ? activeSubTab : 'org')

  useEffect(() => {
    if (activeSubTab && allNavKeys.includes(activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])

  // ===== 审批管理状态 =====
  const [approvalList] = useState<ApprovalItem[]>(approvalData)
  const [approvalSearchType, setApprovalSearchType] = useState('')
  const [approvalSearchStatus, setApprovalSearchStatus] = useState('')
  const [approvalSearchKeyword, setApprovalSearchKeyword] = useState('')

  // ===== 编码规则状态 =====
  const [ruleList, setRuleList] = useState<CodeRuleData[]>(rulesData)
  const [selectedRule, setSelectedRule] = useState<CodeRuleData | null>(null)
  const [ruleEditMode, setRuleEditMode] = useState<'add' | 'edit' | 'view'>('view')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTitle, setDrawerTitle] = useState('')
  const [editingSegments, setEditingSegments] = useState<CodeSegment[]>([
    { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
    { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
    { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
    { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
    { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
    { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
    { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
    { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
    { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
    { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
  ])
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [selectedDeleteRule, setSelectedDeleteRule] = useState<CodeRuleData | null>(null)
  const [changelogOpen, setChangelogOpen] = useState(false)
  const [selectedChangelogRuleId, setSelectedChangelogRuleId] = useState('')

  // ===== 编码管理状态 =====
  const [applyList, setApplyList] = useState<CodeApplyData[]>(codeApplyData)
  const [applySearchKeyword, setApplySearchKeyword] = useState('')
  const [applySearchCode, setApplySearchCode] = useState('')
  const [applySearchCodeStatus, setApplySearchCodeStatus] = useState<'placeholder' | 'generated' | ''>('')
  const [applySearchStatus, setApplySearchStatus] = useState<ApplyStatus | ''>('')
  const [applyDetailOpen, setApplyDetailOpen] = useState(false)
  const [selectedApply, setSelectedApply] = useState<CodeApplyData | null>(null)
  const [applyViewMode, setApplyViewMode] = useState<'view' | 'approve' | 'add' | 'edit'>('view')
  const [approveConfirmOpen, setApproveConfirmOpen] = useState(false)
  const [approveAction, setApproveAction] = useState<'approve' | 'reject'>('approve')
  const [approveRemark, setApproveRemark] = useState('')
  const [selectedOrderId, setSelectedOrderId] = useState('')
  const [orderEquipList, setOrderEquipList] = useState<CodeEquipItem[]>([])

  // ===== 编码溯源状态 =====
  const [traceSearchCode, setTraceSearchCode] = useState('')
  const [selectedTraceRecord, setSelectedTraceRecord] = useState<TraceRecord | null>(null)
  const [traceDetailOpen, setTraceDetailOpen] = useState(false)
  const [importModalOpen, setImportModalOpen] = useState(false)
  const [importStep, setImportStep] = useState<ImportStep>('upload')
  const [importRows, setImportRows] = useState<ImportRow[]>([])
  const [importFileName, setImportFileName] = useState('')
  const [importError, setImportError] = useState('')
  const [importLogs] = useState<ImportLog[]>(importLogData)
  const [importLogOpen, setImportLogOpen] = useState(false)

  // ===== 编码字典状态 =====
  const [dictList] = useState<CodeDictData[]>(codeDictData)
  const [dictSearchType, setDictSearchType] = useState<DictType | ''>('')
  const [dictSearchKeyword, setDictSearchKeyword] = useState('')
  const [dictSearchStatus, setDictSearchStatus] = useState<'active' | 'inactive' | ''>('')
  const [dictDrawerOpen, setDictDrawerOpen] = useState(false)
  const [dictDrawerTitle, setDictDrawerTitle] = useState('')
  const [selectedDict, setSelectedDict] = useState<CodeDictData | null>(null)
  const [dictEditMode, setDictEditMode] = useState<'add' | 'edit' | 'view'>('view')

  // ===== 编码规则 helpers =====
  const openRuleDetailWithSegments = (item: CodeRuleData, mode: 'view' | 'edit') => {
    setSelectedRule(item)
    setRuleEditMode(mode)
    setDrawerTitle(mode === 'edit' ? `编辑编码规则 - ${item.id}` : `编码规则详情 - ${item.id}`)
    setEditingSegments([...item.segments])
    setDrawerOpen(true)
  }

  const openAddRule = () => {
    setSelectedRule(null)
    setRuleEditMode('add')
    setDrawerTitle('新增编码规则')
    setEditingSegments([
      { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
      { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
      { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
      { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
      { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
      { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
      { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
      { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
      { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
      { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
    ])
    setDrawerOpen(true)
  }

  const toggleRuleStatus = (item: CodeRuleData) => {
    setRuleList(prev => prev.map(r =>
      r.id === item.id
        ? { ...r, status: r.status === 'active' ? 'inactive' as const : 'active' as const, updateTime: new Date().toISOString().slice(0, 10) }
        : r
    ))
  }

  const handleDeleteRule = (item: CodeRuleData) => {
    setSelectedDeleteRule(item)
    setDeleteConfirmOpen(true)
  }

  const confirmDeleteRule = () => {
    if (selectedDeleteRule) {
      setRuleList(prev => prev.filter(r => r.id !== selectedDeleteRule.id))
    }
    setDeleteConfirmOpen(false)
    setSelectedDeleteRule(null)
  }

  const handleAddSegment = () => {
    const newId = editingSegments.length > 0 ? Math.max(...editingSegments.map(s => s.id)) + 1 : 1
    setEditingSegments(prev => [...prev, { id: newId, name: '', length: 1, type: '字母数字', valueSource: '关联字典', dictName: '', required: false }])
  }

  const handleDeleteSegment = (segId: number) => {
    setEditingSegments(prev => prev.filter(s => s.id !== segId))
  }

  const handleSegmentChange = (segId: number, field: keyof CodeSegment, value: string | boolean | number) => {
    setEditingSegments(prev => prev.map(s => s.id === segId ? { ...s, [field]: value } : s))
  }

  const openChangelog = (ruleId: string) => {
    setSelectedChangelogRuleId(ruleId)
    setChangelogOpen(true)
  }

  const generatePreviewCode = (rule?: CodeRuleData | null) => {
    if (!rule) {
      return [
        { value: codeDictData.find(d => d.dictType === '标签类别')?.code || '1', display: '标签类别', segmentName: '标签类别', isPlaceholder: true },
        { value: codeDictData.find(d => d.dictType === '一级分类')?.code || '0', display: codeDictData.find(d => d.dictType === '一级分类')?.code || '0', segmentName: '一级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '二级分类')?.code || '1', display: codeDictData.find(d => d.dictType === '二级分类')?.code || '1', segmentName: '二级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '三级分类')?.code || '01', display: codeDictData.find(d => d.dictType === '三级分类')?.code || '01', segmentName: '三级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '装备品种名称')?.code || 'P001', display: codeDictData.find(d => d.dictType === '装备品种名称')?.code || 'P001', segmentName: '装备名称编码', isPlaceholder: false },
        { value: (codeDictData.find(d => d.dictType === '型号编码')?.code || '001').slice(0, 3), display: (codeDictData.find(d => d.dictType === '型号编码')?.code || '001').slice(0, 3), segmentName: '装备型号编码', isPlaceholder: false },
        { value: '[DATE]', display: '[日期]', segmentName: '生产日期', isPlaceholder: true },
        { value: codeDictData.find(d => d.dictType === '有效期')?.code || '05', display: codeDictData.find(d => d.dictType === '有效期')?.code || '05', segmentName: '有效期', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '供应商信用代码')?.code || '001XXXXXX', display: codeDictData.find(d => d.dictType === '供应商信用代码')?.code || '001XXXXXX', segmentName: '供应商代码', isPlaceholder: false },
        { value: '[SEQ]', display: '流水号', segmentName: '流水号', isPlaceholder: true },
      ]
    }
    return rule.segments.map((seg, idx) => {
      if (idx === 0 && seg.name === '标签类别') {
        return { value: '1', display: '标签类别', segmentName: seg.name, isPlaceholder: true }
      }
      if (seg.name === '流水号') {
        return { value: '[SEQ]', display: '流水号', segmentName: seg.name, isPlaceholder: true }
      }
      const isPlaceholder = seg.name === '生产日期'
      if (isPlaceholder) {
        return { value: '[DATE]', display: '[日期]', segmentName: seg.name, isPlaceholder: true }
      }
      if (seg.valueSource === '固定值') {
        const val = (seg.fixedValue || 'X').padStart(seg.length, 'X').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      if (seg.valueSource === '关联字典') {
        const dictItem = codeDictData.find(d => d.dictType === seg.dictName)
        const code = dictItem?.code || ''
        const val = code.padStart(seg.length, '0').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      if (seg.valueSource === '自动流水') {
        const val = '0001'.padStart(seg.length, '0').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      return { value: 'X'.repeat(seg.length), display: 'X'.repeat(seg.length), segmentName: seg.name, isPlaceholder: false }
    })
  }

  // ===== 编码管理 helpers =====
  const renderSplitCode = (code: string) => {
    const segments = code.split('-')
    return (
      <>
        {segments.map((seg, i) => {
          const isLast = i === segments.length - 1
          const isFirst = i === 0
          const isDate = /^\d{8}$/.test(seg)
          const isGray = isFirst || isLast || isDate
          let displayText = seg
          if (isFirst) displayText = '标签类别'
          else if (isLast) displayText = '流水号'
          const separator = i < segments.length - 1 ? '-' : ''
          return (
            <span key={i}>
              {isGray ? (
                <span style={{ color: '#8c8c8c', background: '#f5f5f5', border: '1px dashed #d9d9d9', padding: '1px 4px', borderRadius: '4px', fontFamily: 'monospace', fontSize: '11px' }}>{displayText}</span>
              ) : (
                <span style={{ color: '#1890ff', fontFamily: 'monospace', fontSize: '11px' }}>{seg}</span>
              )}
              {separator && <span style={{ color: '#d9d9d9', fontFamily: 'monospace', fontSize: '11px' }}>{separator}</span>}
            </span>
          )
        })}
      </>
    )
  }

  const generateCodePreview = (_equipName: string, _orderNo: string) => {
    const nameDict = codeDictData.find(d => d.dictType === '装备品种名称')
    const modelDict = codeDictData.find(d => d.dictType === '型号编码')
    const validityDict = codeDictData.find(d => d.dictType === '有效期')
    const supplierDict = codeDictData.find(d => d.dictType === '供应商信用代码')
    return [
      codeDictData.find(d => d.dictType === '标签类别')?.code || '1',
      codeDictData.find(d => d.dictType === '一级分类')?.code || '0',
      codeDictData.find(d => d.dictType === '二级分类')?.code || '1',
      codeDictData.find(d => d.dictType === '三级分类')?.code || '01',
      (nameDict?.code || 'P001'),
      (modelDict?.code || '001').slice(0, 3),
      '[日期]',
      validityDict?.code || '05',
      supplierDict?.code || '001XXXXXX',
      '[流水]',
    ].join('-')
  }

  const handleSelectOrder = (orderId: string) => {
    setSelectedOrderId(orderId)
    const order = orderOptions.find(o => o.id === orderId)
    if (!order) { setOrderEquipList([]); return }
    const items: CodeEquipItem[] = [{
      id: `EQ${Date.now()}`,
      applyId: '',
      orderId: order.id,
      orderNo: order.no,
      supplier: order.supplier,
      equipName: order.equipName,
      code: generateCodePreview(order.equipName, order.no),
      isPlaceholderCode: true,
      status: 'pending' as ApplyStatus,
      applicant: '当前用户',
      applyTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
    }]
    setOrderEquipList(items)
  }

  const openApplyDetail = (item: CodeApplyData, mode: 'view' | 'approve' | 'edit') => {
    setSelectedApply(item)
    setApplyViewMode(mode)
    setApproveRemark('')
    setSelectedOrderId(item.orderId)
    setOrderEquipList(item.items || [])
    setApplyDetailOpen(true)
  }

  const openAddApply = () => {
    setSelectedApply(null)
    setApplyViewMode('add')
    setApproveRemark('')
    setSelectedOrderId('')
    setOrderEquipList([])
    setApplyDetailOpen(true)
  }

  const handleApproveAction = (action: 'approve' | 'reject') => {
    setApproveAction(action)
    setApproveConfirmOpen(true)
  }

  const confirmApproveAction = () => {
    if (selectedApply) {
      const newStatus = approveAction === 'approve' ? 'approved' as ApplyStatus : 'rejected' as ApplyStatus
      const now = new Date().toISOString().slice(0, 16).replace('T', ' ')
      setApplyList(prev => prev.map(a => a.id === selectedApply.id ? {
        ...a,
        status: newStatus,
        approver: '李主任',
        approveTime: now,
        items: a.items.map(it => ({ ...it, status: newStatus, approver: '李主任', approveTime: now }))
      } : a))
    }
    setApproveConfirmOpen(false)
    setApplyDetailOpen(false)
    setApproveRemark('')
  }

  // ===== 导入功能 helpers =====
  const openImportModal = () => {
    setImportModalOpen(true)
    setImportStep('upload')
    setImportRows([])
    setImportFileName('')
    setImportError('')
  }

  const closeImportModal = () => {
    setImportModalOpen(false)
    setImportStep('upload')
    setImportRows([])
    setImportFileName('')
    setImportError('')
  }

  const parseExcelFile = (fileName: string) => {
    setImportError('')
    const mockRows: ImportRow[] = [
      { id: 'R001', rowNum: 2, orderNo: 'DD2024001', equipName: '数字对讲机 PD780G', supplier: '华为技术', excelCode: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', systemCode: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R002', rowNum: 3, orderNo: 'DD2024002', equipName: '应急照明灯 YJ-200', supplier: '中兴通讯', excelCode: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', systemCode: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R003', rowNum: 4, orderNo: 'DD2024003', equipName: '监控摄像头 HK-4K100', supplier: '海康威视', excelCode: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0099', systemCode: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0003', checkResult: 'conflict', conflictReason: 'Excel流水号0099与系统流水号0003不一致', resolution: 'system', selected: false },
      { id: 'R004', rowNum: 5, orderNo: 'DD2024006', equipName: '手持终端 SC-500', supplier: '紫光电子', excelCode: '1-0-1-01-P006-004-[日期]-05-006XXXXXX-0006', systemCode: '1-0-1-01-P006-004-[日期]-05-006XXXXXX-0006', checkResult: 'new', resolution: 'system', selected: true },
      { id: 'R005', rowNum: 6, orderNo: 'DD2024004', equipName: '卫星便携站 S9000', supplier: '大疆创新', excelCode: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', systemCode: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R006', rowNum: 7, orderNo: 'DD2024007', equipName: '无人机 M300', supplier: '大疆创新', excelCode: '1-0-1-01-P007-005-[日期]-05-007XXXXXX-0150', systemCode: '1-0-1-01-P007-005-[日期]-05-007XXXXXX-0007', checkResult: 'conflict', conflictReason: 'Excel流水号0150与系统流水号0007不一致', resolution: 'system', selected: false },
    ]
    setImportRows(mockRows)
    setImportFileName(fileName)
    setImportStep('preview')
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls') && !file.name.endsWith('.csv')) {
      setImportError('请上传 .xlsx、.xls 或 .csv 格式的文件')
      return
    }
    parseExcelFile(file.name)
  }

  const toggleRowSelected = (rowId: string) => {
    setImportRows(prev => prev.map(r => r.id === rowId ? { ...r, selected: !r.selected } : r))
  }

  const setRowResolution = (rowId: string, resolution: ConflictResolution) => {
    setImportRows(prev => prev.map(r => r.id === rowId ? { ...r, resolution, selected: resolution !== 'skip' } : r))
  }

  const batchResolution = (result: CheckResult, resolution: ConflictResolution) => {
    setImportRows(prev => prev.map(r => r.checkResult === result ? { ...r, resolution, selected: resolution !== 'skip' } : r))
  }

  const confirmImport = () => {
    setImportStep('done')
  }

  // ===== 编码字典 helpers =====
  const openDictDetail = (item: CodeDictData, mode: 'view' | 'edit') => {
    setSelectedDict(item)
    setDictEditMode(mode)
    setDictDrawerTitle(mode === 'edit' ? `编辑字典项 - ${item.id}` : `字典项详情 - ${item.id}`)
    setDictDrawerOpen(true)
  }

  const openAddDict = () => {
    setSelectedDict(null)
    setDictEditMode('add')
    setDictDrawerTitle('新增字典项')
    setDictDrawerOpen(true)
  }

  // ===== 机构管理渲染 =====
  const renderOrgTree = (nodes: OrgNode[], depth = 0) => (
    <div className={depth > 0 ? 'ml-4 border-l pl-2' : ''} style={{ borderColor: 'var(--border-color)' }}>
      {nodes.map((node, i) => (
        <div key={i}>
          <button className={`flex items-center gap-2 py-1.5 text-sm w-full text-left hover:text-blue-600 transition-colors ${node.leaf ? 'pl-6' : ''}`}>
            {!node.leaf && (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${node.expanded ? 'rotate-90' : ''}`}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            )}
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: node.leaf ? 'var(--primary-blue)' : 'var(--text-secondary)' }}>
              {node.leaf ? <><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></> : <><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></>}
            </svg>
            <span style={{ color: node.leaf ? 'var(--text-primary)' : 'var(--text-secondary)', fontWeight: node.leaf ? 500 : 400 }}>{node.name}</span>
          </button>
          {node.children && node.expanded && renderOrgTree(node.children, depth + 1)}
        </div>
      ))}
    </div>
  )

  // ===== 分组后的导航项 =====
  const groupedNav = navItems.reduce((acc, item) => {
    const group = item.group || '其他'
    if (!acc[group]) acc[group] = []
    acc[group].push(item)
    return acc
  }, {} as Record<string, NavItem[]>)


  return (
    <div className="flex h-full" style={{ background: 'var(--content-bg)' }}>
      {/* 左侧导航 */}
      <div className="w-[200px] flex-shrink-0 border-r bg-white flex flex-col overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
        <div className="p-3 pt-4">
          {Object.entries(groupedNav).map(([group, items]) => (
            <div key={group} className="mb-4">
              <div className="px-3 mb-1 text-xs font-medium" style={{ color: 'var(--text-disabled)' }}>{group}</div>
              {items.map(item => (
                <button
                  key={item.key}
                  className={`w-full flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-all duration-200 mb-0.5 ${
                    activeTab === item.key
                      ? 'font-medium'
                      : 'hover:bg-gray-50'
                  }`}
                  style={
                    activeTab === item.key
                      ? { background: '#e6f7ff', color: '#1890ff', borderLeft: '3px solid #1890ff' }
                      : { color: 'var(--text-secondary)', borderLeft: '3px solid transparent' }
                  }
                  onClick={() => setActiveTab(item.key)}
                >
                  <span style={{ color: activeTab === item.key ? '#1890ff' : 'var(--text-disabled)' }}>{navIcons[item.key]}</span>
                  {item.label}
                </button>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* 右侧内容区 */}
      <div className="flex-1 overflow-y-auto p-6">

        {/* ========== 机构管理 ========== */}
        {activeTab === 'org' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="content-card p-4">
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
                组织树
              </h4>
              {renderOrgTree(orgTreeData)}
            </div>
            <div className="lg:col-span-2 space-y-4">
              <div className="content-card p-5">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">XX省公安厅</h4>
                  <div className="flex gap-2">
                    <button className="btn-primary text-xs px-2 py-1">新增子机构</button>
                    <button className="btn-default text-xs px-2 py-1">编辑</button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <p><span style={{ color: 'var(--text-secondary)' }}>机构编码：</span><span className="font-mono">UNIT001</span></p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>机构名称：</span>XX省公安厅</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>上级机构：</span>-</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>层级：</span>省级</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>负责人：</span>王厅长</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>同步状态：</span><span className="tag tag-green">已同步</span></p>
                </div>
              </div>
              <div className="content-card p-5">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold">下属用户（128人）</h4>
                  <div className="flex gap-2">
                    <button className="btn-primary text-xs px-2 py-1">新增用户</button>
                    <button className="btn-default text-xs px-2 py-1">导出</button>
                  </div>
                </div>
                <table className="data-table">
                  <thead><tr><th>姓名</th><th>工号</th><th>手机号</th><th>角色</th><th>状态</th></tr></thead>
                  <tbody>
                    {[
                      { name: '张三', no: '2024001', phone: '138****8888', role: '装备管理员', status: 'active' },
                      { name: '李四', no: '2024002', phone: '139****6666', role: '库管员', status: 'active' },
                      { name: '王五', no: '2024003', phone: '137****5555', role: '采购员', status: 'active' },
                    ].map(u => (
                      <tr key={u.no}>
                        <td className="font-medium">{u.name}</td><td className="font-mono text-xs">{u.no}</td><td className="font-mono text-xs">{u.phone}</td>
                        <td><span className="tag tag-blue">{u.role}</span></td><td><span className="tag tag-green">在职</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========== 角色管理 ========== */}
        {activeTab === 'role' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="content-card p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold">角色列表</h4>
                <button className="btn-primary text-xs px-2 py-1">新增</button>
              </div>
              <div className="space-y-1">
                {rolesData.map((r, i) => (
                  <button key={r.name} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left text-sm transition-all ${i === 1 ? 'bg-blue-50 text-blue-600' : 'hover:bg-gray-50'}`}>
                    <div className={`w-2 h-2 rounded-full ${i === 1 ? 'bg-blue-500' : i === 0 ? 'bg-red-500' : 'bg-gray-300'}`} />
                    <div>
                      <p className="font-medium">{r.name}</p>
                      <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{r.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
            <div className="lg:col-span-2 content-card p-5">
              <h4 className="font-semibold mb-4">当前角色：装备管理员</h4>
              <div className="mb-6">
                <h5 className="text-sm font-medium mb-3">菜单权限</h5>
                <div className="space-y-2">
                  {[
                    { label: '仓库可视化', checked: true, children: ['建筑可视化', '存放位置可视化', '实时数据可视化', '业务动态可视化'] },
                    { label: '采购及售后管理', checked: true, children: ['采购管理', '合同管理', '订单管理'] },
                    { label: '小区装备管理', checked: true, children: [] },
                    { label: '系统管理', checked: false, children: [] },
                  ].map(m => (
                    <div key={m.label} className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input type="checkbox" defaultChecked={m.checked} className="accent-blue-500" />
                        <span className="text-sm font-medium">{m.label}</span>
                      </label>
                      {m.children.length > 0 && (
                        <div className="ml-6 mt-2 space-y-1">
                          {m.children.map(c => (
                            <label key={c} className="flex items-center gap-2 cursor-pointer">
                              <input type="checkbox" defaultChecked className="accent-blue-500" />
                              <span className="text-xs">{c}</span>
                            </label>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h5 className="text-sm font-medium mb-3">数据权限</h5>
                <div className="space-y-2 text-sm">
                  <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-blue-500" /> 本级</label>
                  <label className="flex items-center gap-2"><input type="checkbox" defaultChecked className="accent-blue-500" /> 下级所有</label>
                </div>
              </div>
              <button className="btn-primary mt-6">保存权限配置</button>
            </div>
          </div>
        )}

        {/* ========== 用户管理 ========== */}
        {activeTab === 'user' && (
          <div className="content-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">用户列表</h4>
              <div className="flex gap-2">
                <button className="btn-primary text-xs px-2 py-1">新增用户</button>
                <button className="btn-default text-xs px-2 py-1">导出</button>
              </div>
            </div>
            <table className="data-table">
              <thead><tr><th className="w-10"><input type="checkbox"/></th><th>姓名</th><th>工号</th><th>手机号</th><th>所属机构</th><th>角色</th><th>状态</th><th>操作</th></tr></thead>
              <tbody>
                {[
                  { name: '张三', no: '2024001', phone: '138****8888', org: 'XX省公安厅', role: '装备管理员', status: 'active' },
                  { name: '李四', no: '2024002', phone: '139****6666', org: '西湖分局', role: '库管员', status: 'active' },
                  { name: '王五', no: '2024003', phone: '137****5555', org: '拱墅分局', role: '采购员', status: 'active' },
                ].map(u => (
                  <tr key={u.no}>
                    <td><input type="checkbox"/></td>
                    <td className="font-medium">{u.name}</td>
                    <td className="font-mono text-xs">{u.no}</td>
                    <td className="font-mono text-xs">{u.phone}</td>
                    <td>{u.org}</td>
                    <td><span className="tag tag-blue">{u.role}</span></td>
                    <td><span className="tag tag-green">在职</span></td>
                    <td><div className="flex gap-2"><button className="text-xs" style={{ color: 'var(--primary-blue)' }}>编辑</button><button className="text-xs" style={{ color: 'var(--error)' }}>禁用</button></div></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* ========== 终端设备 ========== */}
        {activeTab === 'device' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <button className="btn-primary flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>注册设备</button>
              <button className="btn-default flex items-center gap-1">批量同步状态</button>
            </div>
            <div className="content-card overflow-hidden">
              <table className="data-table">
                <thead><tr><th className="w-10"><input type="checkbox"/></th><th>设备ID</th><th>设备名称</th><th>类型</th><th>安装位置</th><th>IP地址</th><th>状态</th><th>操作</th></tr></thead>
                <tbody>
                  {devicesData.map(d => (
                    <tr key={d.id}>
                      <td><input type="checkbox"/></td>
                      <td className="font-mono text-xs">{d.id}</td>
                      <td className="font-medium">{d.name}</td>
                      <td>{d.type}</td>
                      <td>{d.location}</td>
                      <td className="font-mono text-xs">{d.ip}</td>
                      <td><span className={`status-dot ${d.status}`} style={{ background: d.status === 'online' ? '#52c41a' : '#ff4d4f' }}>{d.status === 'online' ? '在线' : '离线'}</span></td>
                      <td><div className="flex gap-2"><button className="text-xs" style={{ color: 'var(--primary-blue)' }}>查看</button><button className="text-xs" style={{ color: 'var(--primary-blue)' }}>{d.status === 'offline' ? '重启' : '配置'}</button></div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========== 日志管理 ========== */}
        {activeTab === 'log' && (
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3 mb-4">
              <div><label className="block text-xs mb-1">时间</label><div className="flex items-center gap-1"><input className="form-input w-32" type="date"/><span className="text-gray-400">~</span><input className="form-input w-32" type="date"/></div></div>
              <div><label className="block text-xs mb-1">用户</label><input className="form-input w-28" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1">模块</label><select className="form-input w-28"><option>全部</option><option>系统</option><option>库存管理</option></select></div>
              <div className="flex gap-2 ml-auto"><button className="btn-default">重置</button><button className="btn-primary">查询</button></div>
            </div>
            <table className="data-table">
              <thead><tr><th className="w-10"><input type="checkbox"/></th><th>日志ID</th><th>操作人</th><th>时间</th><th>操作类型</th><th>模块</th><th>内容摘要</th><th>IP地址</th></tr></thead>
              <tbody>
                {logsData.map(l => (
                  <tr key={l.id}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{l.id}</td>
                    <td>{l.user}</td>
                    <td className="font-mono text-xs">{l.time}</td>
                    <td><span className="tag tag-blue">{l.type}</span></td>
                    <td>{l.module}</td>
                    <td className="text-sm">{l.content}</td>
                    <td className="font-mono text-xs">{l.ip}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="flex items-center justify-between px-4 py-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs">导出日志</button>
              <button className="btn-danger text-xs">按条件清理</button>
            </div>
          </div>
        )}

        {/* ========== 审批管理 ========== */}
        {activeTab === 'approval' && (
          <div className="space-y-4">
            <div className="content-card p-4">
              <div className="flex flex-wrap items-end gap-3 mb-4">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批类型</label>
                  <select className="form-input w-32" value={approvalSearchType} onChange={e => setApprovalSearchType(e.target.value)}>
                    <option value="">全部</option>
                    <option>入库审批</option>
                    <option>领用审批</option>
                    <option>报修审批</option>
                    <option>报废审批</option>
                  </select>
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                  <select className="form-input w-28" value={approvalSearchStatus} onChange={e => setApprovalSearchStatus(e.target.value)}>
                    <option value="">全部</option>
                    <option value="pending">审批中</option>
                    <option value="approved">已通过</option>
                    <option value="rejected">已驳回</option>
                  </select>
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
                  <input className="form-input w-28" placeholder="请输入..." value={approvalSearchKeyword} onChange={e => setApprovalSearchKeyword(e.target.value)} />
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default" onClick={() => { setApprovalSearchType(''); setApprovalSearchStatus(''); setApprovalSearchKeyword('') }}>重置</button>
                  <button className="btn-primary">查询</button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="data-table" style={{ minWidth: '800px' }}>
                  <thead>
                    <tr>
                      <th className="w-10"><input type="checkbox"/></th>
                      <th>审批单号</th>
                      <th>审批类型</th>
                      <th>申请人</th>
                      <th>申请时间</th>
                      <th>当前节点</th>
                      <th>审批状态</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {approvalList
                      .filter(a => !approvalSearchType || a.type === approvalSearchType)
                      .filter(a => !approvalSearchStatus || a.status === approvalSearchStatus)
                      .filter(a => !approvalSearchKeyword || a.applicant.includes(approvalSearchKeyword))
                      .map(a => (
                        <tr key={a.id}>
                          <td><input type="checkbox"/></td>
                          <td className="font-mono text-xs">{a.id}</td>
                          <td><span className="tag tag-blue text-xs">{a.type}</span></td>
                          <td>{a.applicant}</td>
                          <td className="text-xs">{a.applyTime}</td>
                          <td className="text-xs">{a.currentNode}</td>
                          <td>
                            <span className="tag text-xs px-2 py-0.5" style={{
                              background: approvalStatusConfig[a.status].bg,
                              color: approvalStatusConfig[a.status].color,
                              border: `1px solid ${approvalStatusConfig[a.status].color}30`
                            }}>
                              {approvalStatusConfig[a.status].label}
                            </span>
                          </td>
                          <td>
                            <div className="flex items-center gap-2">
                              <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>查看</button>
                              {a.status === 'pending' && (
                                <>
                                  <button className="text-xs hover:underline" style={{ color: '#1a4b8c' }}>通过</button>
                                  <button className="text-xs hover:underline" style={{ color: '#c0392b' }}>驳回</button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========== 编码规则 ========== */}
        {activeTab === 'rule' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="btn-primary flex items-center gap-1" onClick={openAddRule}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                  新增规则
                </button>
              </div>
              <div className="flex gap-2 text-xs">
                <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#b7eb8f', background: '#f6ffed', color: '#52c41a' }}>已启用 {ruleList.filter(r => r.status === 'active').length}</span>
                <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#d9d9d9', background: '#f5f5f5', color: '#8c8c8c' }}>已禁用 {ruleList.filter(r => r.status === 'inactive').length}</span>
              </div>
            </div>
            <div className="content-card p-4">
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则ID/名称</label><input className="form-input w-40" placeholder="请输入..." /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>已启用</option><option>已禁用</option></select></div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default">重置</button>
                  <button className="btn-primary">查询</button>
                </div>
              </div>
            </div>
            <div className="content-card overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr><th className="w-10"><input type="checkbox"/></th><th>规则ID</th><th>规则名称</th><th>段位数</th><th>状态</th><th>操作</th></tr>
                </thead>
                <tbody>
                  {ruleList.map(r => (
                    <tr key={r.id}>
                      <td><input type="checkbox"/></td>
                      <td className="font-mono text-xs">{r.id}</td>
                      <td className="font-medium">{r.name}</td>
                      <td>{r.segments.length}段（共{r.segments.reduce((sum, s) => sum + s.length, 0)}位）</td>
                      <td><span className={`tag ${r.status === 'active' ? 'tag-green' : 'tag-gray'}`}>{r.status === 'active' ? '启用' : '禁用'}</span></td>
                      <td>
                        <div className="flex items-center gap-2">
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openRuleDetailWithSegments(r, 'view')}>查看</button>
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openRuleDetailWithSegments(r, 'edit')}>编辑</button>
                          {r.status === 'active' ? (
                            <button className="text-xs hover:underline" style={{ color: '#c0392b' }} onClick={() => toggleRuleStatus(r)}>禁用</button>
                          ) : (
                            <button className="text-xs hover:underline" style={{ color: '#1a4b8c' }} onClick={() => toggleRuleStatus(r)}>启用</button>
                          )}
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openChangelog(r.id)}>变更记录</button>
                          <button className="text-xs hover:underline" style={{ color: '#c0392b' }} onClick={() => handleDeleteRule(r)}>删除</button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========== 编码管理 ========== */}
        {activeTab === 'mgmt' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="btn-primary flex items-center gap-1" onClick={openAddApply}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                  新增编码申请
                </button>
                <button className="btn-default flex items-center gap-1 text-xs" onClick={() => {
                  const csv = ['\uFEFF关联订单,装备名称,供应商,编码,审批状态,申请人,申请时间,审批人,审批时间']
                  applyList.forEach(a => {
                    a.items.forEach(it => {
                      const statusText = applyStatusConfig[it.status].label
                      csv.push(`${it.orderNo},${it.equipName},${it.supplier},${it.code},${statusText},${it.applicant},${it.applyTime},${it.approver || '-'},${it.approveTime || '-'}`)
                    })
                  })
                  const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' })
                  const link = document.createElement('a')
                  link.href = URL.createObjectURL(blob)
                  link.download = `编码管理_${new Date().toISOString().slice(0, 10)}.csv`
                  link.click()
                }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  导出
                </button>
              </div>
              <div className="flex gap-2 text-xs items-center">
                {(Object.keys(applyStatusConfig) as ApplyStatus[]).map(s => (
                  <span key={s} className="px-3 py-1 rounded-full border" style={{ borderColor: applyStatusConfig[s].color + '40', background: applyStatusConfig[s].bg, color: applyStatusConfig[s].color }}>
                    {applyStatusConfig[s].label} {applyList.reduce((sum, a) => sum + a.items.filter(it => it.status === s).length, 0)}
                  </span>
                ))}
              </div>
            </div>
            <div className="content-card p-4">
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label>
                  <input className="form-input w-36" placeholder="装备名称..." value={applySearchKeyword} onChange={e => setApplySearchKeyword(e.target.value)} />
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码</label>
                  <input className="form-input w-40 font-mono" placeholder="编码..." value={applySearchCode} onChange={e => setApplySearchCode(e.target.value)} />
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码状态</label>
                  <select className="form-input w-28" value={applySearchCodeStatus} onChange={e => setApplySearchCodeStatus(e.target.value as 'placeholder' | 'generated' | '')}>
                    <option value="">全部</option>
                    <option value="placeholder">预生成</option>
                    <option value="generated">已生成</option>
                  </select>
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单</label>
                  <input className="form-input w-36" placeholder="订单号..." />
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                  <select className="form-input w-24" value={applySearchStatus} onChange={e => setApplySearchStatus(e.target.value as ApplyStatus | '')}>
                    <option value="">全部</option>
                    <option value="pending">待审批</option>
                    <option value="approved">已通过</option>
                    <option value="rejected">已驳回</option>
                  </select>
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                  <input className="form-input w-32" placeholder="供应商..." />
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default" onClick={() => { setApplySearchKeyword(''); setApplySearchCode(''); setApplySearchCodeStatus(''); setApplySearchStatus('') }}>重置</button>
                  <button className="btn-primary">查询</button>
                </div>
              </div>
            </div>
            <div className="content-card overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr>
                    <th className="w-10"><input type="checkbox"/></th>
                    <th>装备名称</th>
                    <th>编码</th>
                    <th>编码状态</th>
                    <th>关联订单</th>
                    <th>审批状态</th>
                    <th>供应商</th>
                    <th>申请人</th>
                    <th>申请时间</th>
                    <th>审批人</th>
                    <th>审批时间</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {applyList
                    .filter(a => !applySearchStatus || a.items.some(it => it.status === applySearchStatus))
                    .filter(a => !applySearchKeyword || a.orderNo.includes(applySearchKeyword) || a.items.some(it => it.equipName.includes(applySearchKeyword) || it.supplier.includes(applySearchKeyword)))
                    .flatMap(a => a.items.map((it, idx) => ({ ...it, _apply: a, _isFirst: idx === 0 })))
                    .filter(it => !applySearchStatus || it.status === applySearchStatus)
                    .filter(it => !applySearchCode || it.code.includes(applySearchCode))
                    .filter(it => !applySearchCodeStatus || (applySearchCodeStatus === 'placeholder' ? it.isPlaceholderCode : !it.isPlaceholderCode))
                    .map(it => (
                      <tr key={it.id}>
                        <td><input type="checkbox"/></td>
                        <td className="text-sm font-medium">{it.equipName}</td>
                        <td>
                          <span className="font-mono text-xs">
                            {renderSplitCode(it.code)}
                          </span>
                        </td>
                        <td>
                          <span className="tag text-xs px-2 py-0.5" style={{
                            background: it.isPlaceholderCode ? '#fffbe6' : '#f6ffed',
                            color: it.isPlaceholderCode ? '#faad14' : '#52c41a',
                            border: `1px solid ${it.isPlaceholderCode ? '#ffe58f' : '#b7eb8f'}`
                          }}>
                            {it.isPlaceholderCode ? '预生成' : '已生成'}
                          </span>
                        </td>
                        <td className="font-mono text-xs">{it.orderNo}</td>
                        <td>
                          <span className="tag text-xs px-2 py-0.5" style={{ background: applyStatusConfig[it.status].bg, color: applyStatusConfig[it.status].color, border: `1px solid ${applyStatusConfig[it.status].color}30` }}>
                            {applyStatusConfig[it.status].label}
                          </span>
                        </td>
                        <td className="text-xs">{it.supplier}</td>
                        <td>{it.applicant}</td>
                        <td className="text-xs">{it.applyTime}</td>
                        <td>{it.approver || '-'}</td>
                        <td className="text-xs">{it.approveTime || '-'}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openApplyDetail(it._apply, 'view')}>查看</button>
                            {it.status === 'pending' && (
                              <button className="text-xs hover:underline" style={{ color: '#1a4b8c' }} onClick={() => openApplyDetail(it._apply, 'approve')}>审批</button>
                            )}
                            {it.status === 'pending' && (
                              <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openApplyDetail(it._apply, 'edit')}>编辑</button>
                            )}
                            <button className="text-xs hover:underline" style={{ color: '#c0392b' }}>删除</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========== 编码溯源 ========== */}
        {activeTab === 'trace' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="btn-default flex items-center gap-1 text-xs" onClick={openImportModal}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  导入Excel
                </button>
                <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setImportLogOpen(true)}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="inline mr-0.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  导入日志
                </button>
              </div>
            </div>
            <div className="content-card p-4">
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入装备名称" /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</label><input className="form-input font-mono w-40" placeholder="请输入装备编码" /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>生产商</label><select className="form-input w-36"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>大疆创新科技有限公司</option><option>中兴通讯股份有限公司</option></select></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>在库</option><option>在用</option><option>维修中</option><option>已报废</option></select></div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default">重置</button>
                  <button className="btn-primary">查询</button>
                </div>
              </div>
            </div>
            <div className="content-card overflow-x-auto">
              <table className="data-table" style={{ minWidth: '900px' }}>
                <thead>
                  <tr>
                    <th>装备编码</th>
                    <th>装备名称</th>
                    <th>规格型号</th>
                    <th>生产商</th>
                    <th>使用单位</th>
                    <th>当前所属</th>
                    <th>状态</th>
                    <th>入库时间</th>
                    <th>最近操作</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {traceData
                    .filter(t => !traceSearchCode || t.code.includes(traceSearchCode) || t.equipName.includes(traceSearchCode))
                    .map(t => (
                      <tr key={t.id}>
                        <td className="font-mono text-xs whitespace-nowrap" style={{ minWidth: '280px' }}>{t.code}</td>
                        <td className="text-sm font-medium">{t.equipName}</td>
                        <td className="text-xs">{t.spec}</td>
                        <td className="text-xs">{t.manufacturer}</td>
                        <td className="text-xs">{t.usingUnit}</td>
                        <td className="text-xs">{t.currentOwner}</td>
                        <td>
                          <span className="tag text-xs px-2 py-0.5" style={{
                            background: traceStatusMap[t.status].bg,
                            color: traceStatusMap[t.status].color,
                            border: `1px solid ${traceStatusMap[t.status].border}`
                          }}>
                            {traceStatusMap[t.status].label}
                          </span>
                        </td>
                        <td className="text-xs">{t.warehouseTime}</td>
                        <td>
                          <span className="text-xs">{t.lastOperationType}</span>
                          <br/>
                          <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{t.lastOperationTime}</span>
                        </td>
                        <td>
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedTraceRecord(t); setTraceDetailOpen(true) }}>查看详情</button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* ========== 编码字典 ========== */}
        {activeTab === 'dict' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <button className="btn-primary flex items-center gap-1" onClick={openAddDict}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                  新增字典项
                </button>
              </div>
              <div className="flex gap-2 text-xs">
                {(['标签类别', '一级分类', '二级分类', '三级分类', '装备品种名称', '型号编码', '生产日期', '有效期', '供应商信用代码'] as DictType[]).map(t => (
                  <span key={t} className="px-3 py-1 rounded-full border" style={{ borderColor: '#e6f7ff', background: '#f0f8ff', color: '#1890ff' }}>
                    {t} {dictList.filter(d => d.dictType === t).length}
                  </span>
                ))}
              </div>
            </div>
            <div className="content-card p-4">
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典类型</label>
                  <select className="form-input w-32" value={dictSearchType} onChange={e => setDictSearchType(e.target.value as DictType | '')}>
                    <option value="">全部</option>
                    <option>标签类别</option>
                    <option>一级分类</option>
                    <option>二级分类</option>
                    <option>三级分类</option>
                    <option>装备品种名称</option>
                    <option>型号编码</option>
                    <option>生产日期</option>
                    <option>有效期</option>
                    <option>供应商信用代码</option>
                  </select>
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码/名称</label>
                  <input className="form-input w-40" placeholder="请输入关键词..." value={dictSearchKeyword} onChange={e => setDictSearchKeyword(e.target.value)} />
                </div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                  <select className="form-input w-28" value={dictSearchStatus} onChange={e => setDictSearchStatus(e.target.value as 'active' | 'inactive' | '')}>
                    <option value="">全部</option>
                    <option value="active">启用</option>
                    <option value="inactive">禁用</option>
                  </select>
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default" onClick={() => { setDictSearchType(''); setDictSearchKeyword(''); setDictSearchStatus('') }}>重置</button>
                  <button className="btn-primary">查询</button>
                </div>
              </div>
            </div>
            <div className="content-card overflow-hidden">
              <table className="data-table">
                <thead>
                  <tr>
                    <th className="w-10"><input type="checkbox"/></th>
                    <th>序号</th>
                    <th>字典类型</th>
                    <th>编码</th>
                    <th>名称</th>
                    <th>上级分类</th>
                    <th>状态</th>
                    <th>排序号</th>
                    <th>扩展信息</th>
                    <th>创建时间</th>
                    <th>备注</th>
                    <th>操作</th>
                  </tr>
                </thead>
                <tbody>
                  {dictList
                    .filter(d => !dictSearchType || d.dictType === dictSearchType)
                    .filter(d => !dictSearchStatus || d.status === dictSearchStatus)
                    .filter(d => !dictSearchKeyword || d.code.includes(dictSearchKeyword) || d.name.includes(dictSearchKeyword) || (d.parentName || '').includes(dictSearchKeyword))
                    .sort((a, b) => a.dictType.localeCompare(b.dictType) || a.sortOrder - b.sortOrder)
                    .map((d, idx) => (
                      <tr key={d.id}>
                        <td><input type="checkbox"/></td>
                        <td>{idx + 1}</td>
                        <td>
                          <span className="tag text-xs" style={{
                            background: d.dictType === '标签类别' ? '#e6f7ff' : d.dictType === '装备品种名称' ? '#f6ffed' : d.dictType === '型号编码' ? '#fff0f6' : '#fffbe6',
                            color: d.dictType === '标签类别' ? '#1890ff' : d.dictType === '装备品种名称' ? '#52c41a' : d.dictType === '型号编码' ? '#eb2f96' : '#faad14',
                            border: `1px solid ${d.dictType === '标签类别' ? '#91d5ff' : d.dictType === '装备品种名称' ? '#b7eb8f' : d.dictType === '型号编码' ? '#ffadd2' : '#ffe58f'}`
                          }}>
                            {d.dictType}
                          </span>
                        </td>
                        <td className="font-mono text-xs font-medium">{d.code}</td>
                        <td className="font-medium">{d.name}</td>
                        <td>{d.parentName ? <span><span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{d.parentCode}</span> · {d.parentName}</span> : '-'}</td>
                        <td><span className={`tag ${d.status === 'active' ? 'tag-green' : 'tag-gray'}`}>{d.status === 'active' ? '启用' : '禁用'}</span></td>
                        <td>{d.sortOrder}</td>
                        <td className="text-xs">{d.createTime}</td>
                        <td>
                          {(d.maintainCycle || d.validityPeriod) ? (
                            <div className="flex flex-col gap-0.5">
                              {d.maintainCycle && <span className="text-xs" style={{ color: '#13c2c2' }}>保养：{d.maintainCycle}月</span>}
                              {d.validityPeriod && <span className="text-xs" style={{ color: '#faad14' }}>有效：{d.validityPeriod}年</span>}
                            </div>
                          ) : (
                            <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>
                          )}
                        </td>
                        <td className="text-xs" style={{ color: 'var(--text-secondary)' }}>{d.remark || '-'}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDictDetail(d, 'view')}>查看</button>
                            <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDictDetail(d, 'edit')}>编辑</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>


      {/* ===== 编码规则 Drawer ===== */}
      {drawerOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setDrawerOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{drawerTitle}</h3>
              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>规则基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则ID <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedRule?.id || ''} placeholder="系统自动生成" readOnly={ruleEditMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedRule?.name || ''} placeholder="请输入规则名称" readOnly={ruleEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码总长度</label>
                    <input className="form-input font-mono" value="32位" readOnly />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                    <select className="form-input" defaultValue={selectedRule?.status || 'active'} disabled={ruleEditMode === 'view'}>
                      <option value="active">启用</option>
                      <option value="inactive">禁用</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>段位配置 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（共{editingSegments.reduce((sum, s) => sum + s.length, 0)}位）</span></h4>
                <div className="space-y-3">
                  {editingSegments.map((seg, idx) => (
                    <div key={seg.id} className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: `${segmentColorMap[(idx % 10) + 1]}05` }}>
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: segmentColorMap[(idx % 10) + 1] }}>{idx + 1}</div>
                        <span className="font-medium text-sm">{seg.name || `段位${idx + 1}`}</span>
                        <span className="text-xs font-mono ml-2" style={{ color: segmentColorMap[(idx % 10) + 1] }}>{seg.length}位 &middot; {seg.type}</span>
                        {seg.required && <span className="text-xs text-red-400">*</span>}
                        <div className="ml-auto flex items-center gap-1">
                          {ruleEditMode !== 'view' && editingSegments.length > 1 && (
                            <button className="p-1 rounded hover:bg-red-50" onClick={() => handleDeleteSegment(seg.id)} title="删除段位">
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>段位名称</label>
                          <input className="form-input text-sm" value={seg.name} onChange={e => handleSegmentChange(seg.id, 'name', e.target.value)} readOnly={ruleEditMode === 'view'} />
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>长度</label>
                          <input className="form-input text-sm font-mono" type="number" min={1} max={20} value={seg.length} onChange={e => handleSegmentChange(seg.id, 'length', parseInt(e.target.value) || 1)} readOnly={ruleEditMode === 'view'} />
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>类型</label>
                          <select className="form-input text-sm" value={seg.type} onChange={e => handleSegmentChange(seg.id, 'type', e.target.value)} disabled={ruleEditMode === 'view'}>
                            <option>字母</option>
                            <option>数字</option>
                            <option>字母数字</option>
                          </select>
                        </div>
                        <div className="col-span-2">
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>取值方式</label>
                          <select className="form-input text-sm" value={seg.valueSource} onChange={e => handleSegmentChange(seg.id, 'valueSource', e.target.value)} disabled={ruleEditMode === 'view'}>
                            <option>固定值</option>
                            <option>关联字典</option>
                            <option>自动流水</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否必填</label>
                          <div className="flex items-center gap-2 h-[34px]">
                            <input type="checkbox" checked={seg.required} onChange={e => handleSegmentChange(seg.id, 'required', e.target.checked)} disabled={ruleEditMode === 'view'} className="w-4 h-4" />
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{seg.required ? '必填' : '选填'}</span>
                          </div>
                        </div>
                        {seg.valueSource === '固定值' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>固定值</label>
                            <input className="form-input text-sm font-mono" value={seg.fixedValue || ''} onChange={e => handleSegmentChange(seg.id, 'fixedValue', e.target.value)} placeholder="请输入固定值" readOnly={ruleEditMode === 'view'} />
                          </div>
                        )}
                        {seg.valueSource === '关联字典' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联字典 <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>（从编码字典中选择）</span></label>
                            <select className="form-input text-sm" value={seg.dictName || ''} onChange={e => handleSegmentChange(seg.id, 'dictName', e.target.value)} disabled={ruleEditMode === 'view'}>
                              <option value="">请选择字典</option>
                              <option>标签类别</option>
                              <option>一级分类</option>
                              <option>二级分类</option>
                              <option>三级分类</option>
                              <option>装备品种名称</option>
                              <option>型号编码</option>
                              <option>生产日期</option>
                              <option>有效期</option>
                              <option>供应商信用代码</option>
                            </select>
                          </div>
                        )}
                        {seg.valueSource === '自动流水' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>流水号归零方式</label>
                            <select className="form-input text-sm" value={seg.resetMode || '按年度归零'} onChange={e => handleSegmentChange(seg.id, 'resetMode', e.target.value)} disabled={ruleEditMode === 'view'}>
                              <option>按年度归零</option>
                              <option>按月度归零</option>
                              <option>永不归零</option>
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                {ruleEditMode !== 'view' && (
                  <button className="btn-default text-xs mt-3" onClick={handleAddSegment}>
                    <span className="flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      添加段位
                    </span>
                  </button>
                )}
              </div>

              {selectedRule && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>编码预览</h4>
                  <div className="p-4 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="flex items-center gap-1 flex-wrap mb-2">
                      {generatePreviewCode(selectedRule).map((part, i) => (
                        <span key={i} className="flex items-center gap-1">
                          <span className="group relative text-sm font-mono px-1.5 py-0.5 rounded cursor-help" style={part.isPlaceholder ? { color: '#8c8c8c', background: '#f5f5f5', border: '1px dashed #d9d9d9' } : { color: segmentColorMap[i + 1], background: `${segmentColorMap[i + 1]}10` }}>
                            {part.display}
                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block text-xs whitespace-nowrap px-2 py-1 rounded text-white z-20" style={{ background: part.isPlaceholder ? '#8c8c8c' : segmentColorMap[i + 1] }}>
                              {part.segmentName}{part.isPlaceholder ? '（暂未生产）' : ''}
                            </span>
                          </span>
                          {i < generatePreviewCode(selectedRule).length - 1 && <span className="text-sm font-mono" style={{ color: 'var(--text-disabled)' }}>-</span>}
                        </span>
                      ))}
                    </div>
                    <p className="text-sm font-mono font-bold" style={{ color: 'var(--primary-blue)' }}>= {generatePreviewCode(selectedRule).map(p => p.display).join('-')}</p>
                    <p className="text-xs mt-2" style={{ color: 'var(--text-secondary)' }}>
                      共32位 | 通过编码可解析装备分类、名称、型号、生产日期、有效期、供应商、流水号等关键属性
                    </p>
                  </div>
                </div>
              )}

              {selectedRule && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>系统信息</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span><span>{selectedRule.createTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>更新时间：</span><span>{selectedRule.updateTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建人员：</span><span>管理员</span></div>
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setDrawerOpen(false)}>{ruleEditMode === 'view' ? '关闭' : '取消'}</button>
              {ruleEditMode !== 'view' && <button className="btn-primary">保存</button>}
            </div>
          </div>
        </>
      )}

      {/* ===== 编码字典 Drawer ===== */}
      {dictDrawerOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setDictDrawerOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{dictDrawerTitle}</h3>
              <button onClick={() => setDictDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典项ID <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.id || ''} placeholder="系统自动生成" readOnly={dictEditMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典类型 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedDict?.dictType || ''} disabled={dictEditMode === 'view'}>
                      <option value="">请选择</option>
                      <option>标签类别</option>
                      <option>一级分类</option>
                      <option>二级分类</option>
                      <option>三级分类</option>
                      <option>装备品种名称</option>
                      <option>型号编码</option>
                      <option>生产日期</option>
                      <option>有效期</option>
                      <option>供应商信用代码</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码 <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.code || ''} placeholder="请输入编码" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedDict?.name || ''} placeholder="请输入名称" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                    <select className="form-input" defaultValue={selectedDict?.status || 'active'} disabled={dictEditMode === 'view'}>
                      <option value="active">启用</option>
                      <option value="inactive">禁用</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号</label>
                    <input className="form-input font-mono" type="number" min={0} defaultValue={selectedDict?.sortOrder || 0} readOnly={dictEditMode === 'view'} />
                  </div>
                </div>
              </div>

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-purple-500"/>扩展信息（可选）</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养周期（月）</label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.maintainCycle || ''} placeholder="如：3 表示每3个月" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>有效期（装备有效年限）</label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.validityPeriod || ''} placeholder="如：5 表示5年" readOnly={dictEditMode === 'view'} />
                  </div>
                </div>
              </div>

              {(selectedDict?.parentCode || dictEditMode !== 'view') && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>上级分类</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>上级编码</label>
                      <input className="form-input font-mono" defaultValue={selectedDict?.parentCode || ''} placeholder="请输入上级编码" readOnly={dictEditMode === 'view'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>上级名称</label>
                      <input className="form-input" defaultValue={selectedDict?.parentName || ''} placeholder="请输入上级名称" readOnly={dictEditMode === 'view'} />
                    </div>
                  </div>
                </div>
              )}

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>备注</h4>
                <div>
                  <textarea className="form-input w-full text-sm" rows={3} defaultValue={selectedDict?.remark || ''} placeholder="请输入备注信息..." readOnly={dictEditMode === 'view'} />
                </div>
              </div>

              {selectedDict && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>系统信息</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span><span>{selectedDict.createTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建人员：</span><span>管理员</span></div>
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setDictDrawerOpen(false)}>{dictEditMode === 'view' ? '关闭' : '取消'}</button>
              {dictEditMode !== 'view' && <button className="btn-primary">保存</button>}
            </div>
          </div>
        </>
      )}

      {/* ===== 编码申请详情 Drawer ===== */}
      {applyDetailOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setApplyDetailOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {applyViewMode === 'add' ? '新增编码申请' : applyViewMode === 'approve' ? `审批编码申请 - ${selectedApply?.id}` : applyViewMode === 'edit' ? `编辑编码申请 - ${selectedApply?.id}` : `编码申请详情 - ${selectedApply?.id}`}
              </h3>
              <button onClick={() => setApplyDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>申请信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单号 {applyViewMode === 'add' && <span className="text-red-400">*</span>}</label>
                    <input className="form-input font-mono" defaultValue={selectedApply?.id || ''} placeholder="系统自动生成" readOnly={applyViewMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                    <input className="form-input" defaultValue={selectedApply?.supplier || ''} placeholder="-" readOnly={applyViewMode === 'view'} />
                  </div>
                </div>
                {applyViewMode === 'add' ? (
                  <div className="space-y-3 mt-3">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单 <span className="text-red-400">*</span></label>
                      <select className="form-input text-sm" value={selectedOrderId} onChange={e => handleSelectOrder(e.target.value)}>
                        <option value="">请选择关联订单</option>
                        {orderOptions.map(o => (
                          <option key={o.id} value={o.id}>{o.no} · {o.equipName} · {o.supplier} · {o.qty}件</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                      <input className="form-input" value={orderOptions.find(o => o.id === selectedOrderId)?.supplier || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
                      <input className="form-input" defaultValue="当前用户" readOnly />
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 mt-3">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单 <span className="text-red-400">*</span></label>
                      <input className="form-input font-mono" defaultValue={selectedApply?.orderNo || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                      <input className="form-input" defaultValue={selectedApply?.supplier || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
                      <input className="form-input" defaultValue={selectedApply?.applicant || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请时间</label>
                      <input className="form-input" defaultValue={selectedApply?.applyTime || ''} readOnly />
                    </div>
                  </div>
                )}
                <div className="mt-3">
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                  <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedApply?.remark || ''} placeholder="请输入备注..." readOnly={applyViewMode === 'view'} />
                </div>
              </div>

              {orderEquipList.length > 0 && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-purple-500"/>装备编码明细 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（共{orderEquipList.length}件装备）</span></h4>
                  </div>
                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {orderEquipList.map((eq, i) => (
                      <div key={eq.id} className="flex items-center gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                        <span className="text-xs font-medium" style={{ color: 'var(--text-disabled)' }}>{i + 1}</span>
                        <div className="flex-1 min-w-0">
                          <input className="form-input text-xs py-1.5 w-full" defaultValue={eq.equipName} placeholder="装备名称" readOnly={applyViewMode === 'view'} />
                        </div>
                        <div className="flex-[2] min-w-0">
                          <span className="font-mono text-xs block">{renderSplitCode(eq.code)}</span>
                          {eq.isPlaceholderCode && (
                            <span className="text-xs mt-0.5 inline-block px-2 py-0.5 rounded" style={{ color: '#8c8c8c', background: '#f5f5f5', border: '1px dashed #d9d9d9', fontFamily: 'monospace' }}>待生产分配</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  {orderEquipList.some(e => e.isPlaceholderCode) && (
                    <div className="mt-3 p-3 rounded-lg border" style={{ borderColor: '#faad1430', background: '#fffbe6' }}>
                      <p className="text-xs flex items-center gap-1" style={{ color: '#d48806' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d48806" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        灰色部分（[日期]、[流水]）为占位符，表示生产日期和流水号将在实际生产时自动分配
                      </p>
                    </div>
                  )}
                </div>
              )}

              {selectedApply && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>审批流程</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>1</div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">采购人发起编码申请</p>
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedApply.applicant} 于 {selectedApply.applyTime} 提交申请</p>
                      </div>
                      <span className="tag tag-green text-xs">已完成</span>
                    </div>
                    {selectedApply.status !== 'pending' ? (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: selectedApply.status === 'rejected' ? '#ff4d4f' : '#52c41a' }}>2</div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">上级单位审批</p>
                          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedApply.approver} 于 {selectedApply.approveTime} {selectedApply.status === 'rejected' ? '驳回申请' : '审批通过'}</p>
                        </div>
                        <span className={`tag text-xs ${selectedApply.status === 'rejected' ? 'tag-red' : 'tag-green'}`}>{selectedApply.status === 'rejected' ? '已驳回' : '已通过'}</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#faad14' }}>2</div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">上级单位审批</p>
                          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>等待审批中...</p>
                        </div>
                        <span className="tag tag-yellow text-xs">进行中</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              {applyViewMode === 'approve' && selectedApply?.status === 'pending' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-danger" onClick={() => handleApproveAction('reject')}>驳回</button>
                  <button className="btn-primary" onClick={() => handleApproveAction('approve')}>审批通过</button>
                </>
              ) : applyViewMode === 'add' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-primary" disabled={!selectedOrderId || orderEquipList.length === 0}>提交申请</button>
                </>
              ) : applyViewMode === 'edit' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-primary">保存修改</button>
                </>
              ) : (
                <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>关闭</button>
              )}
            </div>
          </div>
        </>
      )}

      {/* ===== 审批确认弹窗 ===== */}
      {approveConfirmOpen && selectedApply && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setApproveConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: approveAction === 'approve' ? '#f6ffed' : '#fff2f0' }}>
                {approveAction === 'approve' ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                )}
              </div>
              <h3 className="text-base font-semibold">{approveAction === 'approve' ? '确认审批通过' : '确认驳回'}</h3>
            </div>
            <div className="mb-5">
              <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                申请单号：<span className="font-mono font-medium">{selectedApply.id}</span><br/>
                供应商：<span>{selectedApply.supplier}</span><br/>
                装备名称：<span>{selectedApply.items[0]?.equipName || '-'}</span><br/>
                编码：<span className="font-mono">{selectedApply.items[0]?.code || '-'}</span><br/>
                申请数量：<span className="font-medium">{selectedApply.items.length} 件</span>
              </p>
              {approveAction === 'approve' && (
                <div className="p-3 rounded-lg border mb-3" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                  <p className="text-xs" style={{ color: '#1a4b8c' }}>审批通过后，预生成编码中的占位符部分（生产日期、流水号）将在实际生产时自动分配。</p>
                </div>
              )}
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{approveAction === 'approve' ? '审批意见（可选）' : '驳回原因'}</label>
              <textarea className="form-input w-full text-sm" rows={2} placeholder={approveAction === 'approve' ? '请输入审批意见...' : '请输入驳回原因...'} value={approveRemark} onChange={e => setApproveRemark(e.target.value)} />
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setApproveConfirmOpen(false)}>取消</button>
              <button className={approveAction === 'approve' ? 'btn-primary' : 'btn-danger'} onClick={confirmApproveAction}>
                {approveAction === 'approve' ? '确认通过并生成编码' : '确认驳回'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 删除确认弹窗 ===== */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认删除</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除编码规则"<span className="font-medium">{selectedDeleteRule?.id}</span>"？<br/>规则名称：<span className="font-medium">{selectedDeleteRule?.name}</span><br/>删除后数据将无法恢复，请谨慎操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setDeleteConfirmOpen(false)}>取消</button>
              <button className="btn-danger" onClick={confirmDeleteRule}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 变更记录弹窗 ===== */}
      {changelogOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setChangelogOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                </div>
                <h3 className="text-base font-semibold">变更记录 - {selectedChangelogRuleId}</h3>
              </div>
              <button onClick={() => setChangelogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).length === 0 ? (
                <div className="text-center py-12">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>暂无变更记录</p>
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更字段</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更前值</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更后值</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更原因</th>
                    </tr>
                  </thead>
                  <tbody>
                    {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).map(l => (
                      <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="px-3 py-2 font-mono text-xs">{l.id}</td>
                        <td className="px-3 py-2">{l.operator}</td>
                        <td className="px-3 py-2 text-xs">{l.time}</td>
                        <td className="px-3 py-2 font-medium">{l.field}</td>
                        <td className="px-3 py-2"><span className="text-xs" style={{ color: '#c0392b' }}>{l.oldValue}</span></td>
                        <td className="px-3 py-2"><span className="text-xs" style={{ color: '#1a4b8c' }}>{l.newValue}</span></td>
                        <td className="px-3 py-2 text-xs max-w-xs truncate" title={l.reason}>{l.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).length} 条记录</span>
              <button className="btn-default text-xs" onClick={() => setChangelogOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 导入弹窗 (4步向导) ===== */}
      {importModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={closeImportModal} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[960px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                </div>
                <div>
                  <h3 className="text-base font-semibold">批量导入装备编码</h3>
                  {importFileName && <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{importFileName}</p>}
                </div>
              </div>
              <button onClick={closeImportModal} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="px-6 py-3 border-b flex items-center gap-0" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
              {[
                { key: 'upload', label: '上传文件' },
                { key: 'preview', label: '核对预览' },
                { key: 'confirm', label: '确认导入' },
                { key: 'done', label: '完成' },
              ].map((s, i) => {
                const stepOrder = ['upload', 'preview', 'confirm', 'done']
                const currentIdx = stepOrder.indexOf(importStep)
                const stepIdx = stepOrder.indexOf(s.key)
                const isActive = stepIdx === currentIdx
                const isDone = stepIdx < currentIdx
                return (
                  <div key={s.key} className="flex items-center">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{ background: isActive ? '#e6f7ff' : 'transparent' }}>
                      <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs text-white" style={{ background: isActive ? '#1890ff' : isDone ? '#52c41a' : '#d9d9d9' }}>
                        {isDone ? (<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>) : i + 1}</div>
                      <span className="text-xs font-medium" style={{ color: isActive ? '#1890ff' : isDone ? '#52c41a' : '#8c8c8c' }}>{s.label}</span>
                    </div>
                    {i < 3 && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-1"><polyline points="9 18 15 12 9 6"/></svg>}
                  </div>
                )
              })}
            </div>

            <div className="flex-1 overflow-auto p-6">
              {importStep === 'upload' && (
                <div className="space-y-4">
                  <div className="p-8 rounded-xl border-2 border-dashed text-center" style={{ borderColor: '#d9d9d9', background: '#fafafa' }}>
                    <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#e6f7ff' }}>
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    </div>
                    <p className="text-sm font-medium mb-1">点击上传或拖拽Excel文件到此处</p>
                    <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>支持 .xlsx、.xls、.csv 格式，文件大小不超过10MB</p>
                    <label className="btn-primary cursor-pointer inline-flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      选择文件
                      <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileUpload} />
                    </label>
                  </div>
                  {importError && (
                    <div className="p-3 rounded-lg border flex items-center gap-2" style={{ borderColor: '#ff4d4f', background: '#fff2f0' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                      <span className="text-xs" style={{ color: '#c0392b' }}>{importError}</span>
                    </div>
                  )}
                  <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <h5 className="text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>模板字段说明</h5>
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      <span><span className="text-red-400">*</span> 关联订单</span>
                      <span><span className="text-red-400">*</span> 装备名称</span>
                      <span><span className="text-red-400">*</span> 供应商</span>
                      <span><span className="text-red-400">*</span> 编码</span>
                    </div>
                  </div>
                </div>
              )}

              {(importStep === 'preview' || importStep === 'confirm') && (
                <div className="space-y-4">
                  <div className="flex gap-3">
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#52c41a40', background: '#f6ffed', color: '#52c41a' }}>
                      一致 {importRows.filter(r => r.checkResult === 'match').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#ff4d4f40', background: '#fff2f0', color: '#ff4d4f' }}>
                      冲突 {importRows.filter(r => r.checkResult === 'conflict').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#1890ff40', background: '#e6f7ff', color: '#1890ff' }}>
                      新建 {importRows.filter(r => r.checkResult === 'new').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#8c8c8c40', background: '#f5f5f5', color: '#8c8c8c' }}>
                      跳过 {importRows.filter(r => r.resolution === 'skip').length}
                    </span>
                  </div>

                  {importRows.some(r => r.checkResult === 'conflict') && importStep === 'preview' && (
                    <div className="flex items-center gap-2 p-3 rounded-lg border" style={{ borderColor: '#faad1430', background: '#fffbe6' }}>
                      <span className="text-xs font-medium" style={{ color: '#d48806' }}>冲突处理：</span>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#b7eb8f', background: '#f6ffed', color: '#52c41a' }} onClick={() => batchResolution('conflict', 'system')}>全部以系统为准</button>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#ff4d4f30', background: '#fff2f0', color: '#ff4d4f' }} onClick={() => batchResolution('conflict', 'excel')}>全部以Excel为准</button>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#d9d9d9', background: '#f5f5f5', color: '#8c8c8c' }} onClick={() => batchResolution('conflict', 'skip')}>全部跳过</button>
                    </div>
                  )}

                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)', width: 32 }}><input type="checkbox" checked={importRows.every(r => r.selected)} onChange={() => {}} /></th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)', width: 40 }}>行号</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>关联订单</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>装备名称</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>核对状态</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>Excel编码</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>系统编码</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>冲突原因</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>处理方式</th>
                        </tr>
                      </thead>
                      <tbody>
                        {importRows.map(row => (
                          <tr key={row.id} className="border-b" style={{ borderColor: 'var(--border-color)', opacity: row.resolution === 'skip' ? 0.5 : 1 }}>
                            <td className="px-2 py-2"><input type="checkbox" checked={row.selected} onChange={() => toggleRowSelected(row.id)} /></td>
                            <td className="px-2 py-2 text-xs" style={{ color: 'var(--text-disabled)' }}>{row.rowNum}</td>
                            <td className="px-2 py-2 font-mono text-xs">{row.orderNo}</td>
                            <td className="px-2 py-2 text-xs font-medium">{row.equipName}</td>
                            <td className="px-2 py-2">
                              <span className="tag text-xs px-1.5 py-0.5" style={{ background: checkResultConfig[row.checkResult].bg, color: checkResultConfig[row.checkResult].color, border: `1px solid ${checkResultConfig[row.checkResult].color}30` }}>
                                {checkResultConfig[row.checkResult].label}
                              </span>
                            </td>
                            <td className="px-2 py-2 font-mono text-xs">{row.excelCode}</td>
                            <td className="px-2 py-2 font-mono text-xs">{row.systemCode}</td>
                            <td className="px-2 py-2 text-xs" style={{ color: row.checkResult === 'conflict' ? '#ff4d4f' : 'var(--text-secondary)' }}>{row.conflictReason || '-'}</td>
                            <td className="px-2 py-2">
                              <select className="form-input text-xs py-1" value={row.resolution} onChange={e => setRowResolution(row.id, e.target.value as ConflictResolution)}>
                                <option value="system">系统编码</option>
                                <option value="excel">Excel编码</option>
                                <option value="skip">跳过</option>
                              </select>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {importStep === 'done' && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#f6ffed' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <h4 className="text-lg font-semibold mb-2" style={{ color: '#1a4b8c' }}>导入成功</h4>
                  <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>
                    共处理 {importRows.length} 条记录：
                    {importRows.filter(r => r.checkResult === 'match').length} 条一致、
                    {importRows.filter(r => r.checkResult === 'conflict').length} 条冲突已处理、
                    {importRows.filter(r => r.checkResult === 'new').length} 条新建
                  </p>
                  <div className="p-4 rounded-lg border max-w-md mx-auto text-left" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作人：管理员</p>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作时间：{new Date().toISOString().slice(0, 16).replace('T', ' ')}</p>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>文件名：{importFileName}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>导入数量：{importRows.filter(r => r.resolution !== 'skip').length} 条</p>
                  </div>
                </div>
              )}
            </div>

            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                {importStep === 'preview' && `共 ${importRows.length} 条 · 已选 ${importRows.filter(r => r.selected).length} 条`}
                {importStep === 'confirm' && `即将导入 ${importRows.filter(r => r.selected && r.resolution !== 'skip').length} 条编码`}
              </span>
              <div className="flex items-center gap-3">
                {importStep === 'upload' && (
                  <button className="btn-default text-xs" onClick={closeImportModal}>取消</button>
                )}
                {(importStep === 'preview' || importStep === 'confirm') && (
                  <>
                    <button className="btn-default text-xs" onClick={closeImportModal}>取消</button>
                    <button className="btn-default text-xs" onClick={() => setImportStep('preview')}>返回核对</button>
                    {importStep === 'preview' ? (
                      <button className="btn-primary text-xs" onClick={() => setImportStep('confirm')}>下一步：确认导入</button>
                    ) : (
                      <button className="btn-primary text-xs" onClick={confirmImport}>确认导入并绑定装备</button>
                    )}
                  </>
                )}
                {importStep === 'done' && (
                  <button className="btn-primary text-xs" onClick={closeImportModal}>完成</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== 导入日志弹窗 ===== */}
      {importLogOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setImportLogOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                </div>
                <h3 className="text-base font-semibold">编码导入日志</h3>
              </div>
              <button onClick={() => setImportLogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {importLogs.length === 0 ? (
                <div className="text-center py-12">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>暂无导入记录</p>
                </div>
              ) : (
                <>
                  <table className="w-full text-sm">
                    <thead>
                      <tr style={{ background: 'var(--table-header-bg)' }}>
                        <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>
                        <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>
                        <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>时间</th>
                        <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>文件名</th>
                        <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>总数</th>
                        <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>一致</th>
                        <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>冲突</th>
                        <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>新建</th>
                        <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>跳过</th>
                      </tr>
                    </thead>
                    <tbody>
                      {importLogs.map(l => (
                        <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="px-3 py-2 font-mono text-xs">{l.id}</td>
                          <td className="px-3 py-2">{l.operator}</td>
                          <td className="px-3 py-2 text-xs">{l.time}</td>
                          <td className="px-3 py-2 text-xs font-medium">{l.filename}</td>
                          <td className="px-3 py-2 text-right font-mono text-xs">{l.totalCount}</td>
                          <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#1a4b8c' }}>{l.matchCount}</td>
                          <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#c0392b' }}>{l.conflictCount}</td>
                          <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#1a4b8c' }}>{l.newCount}</td>
                          <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#8c8c8c' }}>{l.skipCount}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className="mt-4 space-y-2">
                    {importLogs.map(l => (
                      <div key={l.id + '_detail'} className="p-3 rounded-lg border text-xs" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                        <span style={{ color: 'var(--text-secondary)' }}>{l.details}</span>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {importLogs.length} 条记录</span>
              <button className="btn-default text-xs" onClick={() => setImportLogOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 溯源详情弹窗 ===== */}
      {traceDetailOpen && selectedTraceRecord && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTraceDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </div>
                <div>
                  <h3 className="text-base font-semibold">编码溯源详情</h3>
                  <p className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedTraceRecord.code}</p>
                </div>
              </div>
              <button onClick={() => setTraceDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="flex-1 overflow-auto p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本档案</h4>
                <div className="grid grid-cols-3 gap-4">
                  {[
                    { label: '装备编码', value: selectedTraceRecord.code, mono: true },
                    { label: '装备名称', value: selectedTraceRecord.equipName, bold: true },
                    { label: '规格型号', value: selectedTraceRecord.spec },
                    { label: '生产商', value: selectedTraceRecord.manufacturer },
                    { label: '供应商', value: selectedTraceRecord.supplier },
                    { label: '当前状态', value: traceStatusMap[selectedTraceRecord.status]?.label, status: true },
                    { label: '使用单位', value: selectedTraceRecord.usingUnit, bold: true },
                    { label: '当前所属', value: selectedTraceRecord.currentOwner, bold: true },
                    { label: '入库时间', value: selectedTraceRecord.warehouseTime },
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>{item.label}</span>
                      {item.status ? (
                        <span className="tag text-xs px-2 py-0.5" style={{
                          background: traceStatusMap[selectedTraceRecord.status].bg,
                          color: traceStatusMap[selectedTraceRecord.status].color,
                          border: `1px solid ${traceStatusMap[selectedTraceRecord.status].border}`
                        }}>
                          {item.value}
                        </span>
                      ) : (
                        <span className={`text-xs ${item.mono ? 'font-mono' : ''} ${item.bold ? 'font-medium' : ''}`}>{item.value}</span>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>全生命周期记录</h4>
                <div className="relative pl-6">
                  <div className="absolute left-2 top-0 bottom-0 w-px" style={{ background: 'var(--border-color)' }} />
                  <div className="space-y-4">
                    {selectedTraceRecord.lifecycle.map((ev) => {
                      const typeColors: Record<string, string> = { 入库: '#52c41a', 出库: '#1890ff', 使用: '#722ed1', 维修: '#ff4d4f', 调拨: '#faad14', 盘点: '#13c2c2', 报废: '#8c8c8c' }
                      const typeBgs: Record<string, string> = { 入库: '#f6ffed', 出库: '#e6f7ff', 使用: '#f9f0ff', 维修: '#fff2f0', 调拨: '#fffbe6', 盘点: '#e6fffb', 报废: '#f5f5f5' }
                      return (
                        <div key={ev.id} className="relative flex items-start gap-3">
                          <div className="absolute -left-4 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center" style={{ background: typeColors[ev.type] || '#d9d9d9', top: 2 }} />
                          <div className="flex-1 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="tag text-xs px-2 py-0.5" style={{ background: typeBgs[ev.type], color: typeColors[ev.type], border: `1px solid ${typeColors[ev.type]}30` }}>{ev.type}</span>
                              <span className="text-xs font-medium">{ev.time}</span>
                              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{ev.operator} &middot; {ev.unit}</span>
                            </div>
                            <p className="text-sm">{ev.description}</p>
                            {ev.detail && <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{ev.detail}</p>}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {selectedTraceRecord.lifecycle.length} 条生命周期记录</span>
              <button className="btn-default text-xs" onClick={() => setTraceDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
