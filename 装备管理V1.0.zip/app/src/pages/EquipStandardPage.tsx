import { useState, useMemo } from 'react'
import ReactECharts from 'echarts-for-react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

const tabList = [
  { key: 'analysis', label: '核定统计分析' },
  { key: 'standard', label: '配备标准管理' },
  { key: 'factor', label: '核定因素管理' },
]

/* ================================================================
   配备标准管理子页签类型
   ================================================================ */
type StandardSubTab = 'directory' | 'project' | 'unit' | 'detail'

interface StandardDirectory {
  id: string
  code: string
  name: string
  dept: string
  scene: string
  effectDate: string
  status: '启用' | '停用'
  remark: string
}

interface EquipProject {
  id: string
  code: string
  name: string
  assetCategory: string
  assetSysName: string
  status: '启用' | '停用'
}

interface EquipUnit {
  id: string
  name: string
  calcDimension: '机构' | '人员' | '编制' | '点位'
  calcRule: string
  applicableStandards: string[]
  status: '启用' | '停用'
}

interface StandardDetail {
  id: string
  standardCode: string
  seqNo: number
  projectName: string
  unitName: string
  ratio: string
  qty: number
  configUnitType?: string
  unit: string
  peopleCount?: string
  target?: string
  useYears: string
  unitPrice: number
  maintainFee: number
  equipType: '刚性标配' | '弹性选配'
  isSysEquip: boolean
  funcDesc: string
  remark: string
}

/* ================================================================
   核定因素管理接口
   ================================================================ */
interface OrgNode {
  id: string
  label: string
  expanded?: boolean
  children?: OrgNode[]
}

interface FactorItem {
  id: string
  orgId: string
  orgName: string
  collectType: '采集' | '按需' | '应配'
  standardName: string
  equipName: string
  unit: string
  shouldQty: number
  shouldAmount: number
  targetObj: string
  remark: string
}

/* ================================================================
   样例数据
   ================================================================ */
const deptOptions = ['刑警支队', '治安支队', '交警支队', '特警支队', '网安支队', '刑侦支队', '反恐支队', '指挥中心', '交警大队', '巡警支队', '派出所']
const sceneOptions = ['日常执勤', '应急处突', '专项任务', '交通管控', '反恐防暴', '侦查办案', '巡逻防控', '安保警卫']
const categoryOptions = ['通信装备', '执法装备', '防护装备', '照明设备', '交通工具', '医疗装备', '警械', '防暴装备']
const configUnitOptions = [
  { group: '按单位', options: ['套', '台', '个', '面'] },
  { group: '按支队', options: ['套/支队'] },
  { group: '按大队', options: ['套/大队'] },
  { group: '按中队', options: ['套/中队'] },
  { group: '按人数', options: ['件/人', '颗/人', '根/人', '套/人'] },
]

/* ================================================================
   组织架构树数据
   ================================================================ */
const orgTreeData: OrgNode[] = [
  {
    id: 'org-root',
    label: '市公安局',
    expanded: true,
    children: [
      {
        id: 'org-branch1',
        label: '局机关',
        expanded: true,
        children: [
          { id: 'org-dept1', label: '指挥中心' },
          { id: 'org-dept2', label: '刑警支队' },
          { id: 'org-dept3', label: '治安支队' },
          { id: 'org-dept4', label: '交警支队' },
          { id: 'org-dept5', label: '特警支队' },
          { id: 'org-dept6', label: '网安支队' },
        ],
      },
      {
        id: 'org-branch2',
        label: '下属分局',
        expanded: true,
        children: [
          { id: 'org-sub1', label: '城关分局' },
          { id: 'org-sub2', label: '开发区分局' },
          { id: 'org-sub3', label: '高新分局' },
        ],
      },
      {
        id: 'org-branch3',
        label: '基层派出所',
        expanded: false,
        children: [
          { id: 'org-p1', label: '解放路派出所' },
          { id: 'org-p2', label: '建设路派出所' },
          { id: 'org-p3', label: '人民路派出所' },
          { id: 'org-p4', label: '和平路派出所' },
        ],
      },
    ],
  },
]

/* ================================================================
   核定因素样例数据
   ================================================================ */
const factorData: FactorItem[] = [
  { id: '1', orgId: 'org-dept1', orgName: '指挥中心', collectType: '应配', standardName: '市级机关装备配备标准', equipName: '接处警信息系统平台', unit: '套', shouldQty: 1, shouldAmount: 45.00, targetObj: '指挥中心', remark: '含系统软件授权' },
  { id: '2', orgId: 'org-dept1', orgName: '指挥中心', collectType: '应配', standardName: '市级机关装备配备标准', equipName: '接处警工作台', unit: '套', shouldQty: 1, shouldAmount: 12.00, targetObj: '指挥中心', remark: '' },
  { id: '3', orgId: 'org-dept1', orgName: '指挥中心', collectType: '应配', standardName: '市级机关装备配备标准', equipName: '报警受理系统', unit: '套', shouldQty: 1, shouldAmount: 38.00, targetObj: '指挥中心', remark: '110/119/122三网合一' },
  { id: '4', orgId: 'org-dept1', orgName: '指挥中心', collectType: '按需', standardName: '市级机关装备配备标准', equipName: '数字录音系统', unit: '套', shouldQty: 1, shouldAmount: 8.50, targetObj: '指挥中心', remark: '全程录音存储' },
  { id: '5', orgId: 'org-dept2', orgName: '刑警支队', collectType: '应配', standardName: '刑侦支队装备配备标准', equipName: '执法记录仪', unit: '件/人', shouldQty: 60, shouldAmount: 10.80, targetObj: '一线执法民警', remark: '每人1台' },
  { id: '6', orgId: 'org-dept2', orgName: '刑警支队', collectType: '应配', standardName: '刑侦支队装备配备标准', equipName: '手持终端', unit: '件/人', shouldQty: 30, shouldAmount: 8.40, targetObj: '侦查办案人员', remark: '按在岗人数' },
  { id: '7', orgId: 'org-dept2', orgName: '刑警支队', collectType: '采集', standardName: '刑侦支队装备配备标准', equipName: '对讲机', unit: '件/人', shouldQty: 50, shouldAmount: 7.50, targetObj: '全体民警', remark: 'PD780G' },
  { id: '8', orgId: 'org-dept3', orgName: '治安支队', collectType: '应配', standardName: '治安支队装备配备标准', equipName: '防弹背心', unit: '件/人', shouldQty: 20, shouldAmount: 6.40, targetObj: '高危岗位民警', remark: 'FDY-3R型' },
  { id: '9', orgId: 'org-dept3', orgName: '治安支队', collectType: '应配', standardName: '治安支队装备配备标准', equipName: '战术头盔', unit: '件/人', shouldQty: 20, shouldAmount: 5.20, targetObj: '处突队员', remark: 'MICH-2000型' },
  { id: '10', orgId: 'org-sub1', orgName: '城关分局', collectType: '应配', standardName: '派出所装备配备标准', equipName: '警用强光手电', unit: '根/人', shouldQty: 80, shouldAmount: 2.80, targetObj: '全体民警', remark: '基层标配' },
]

/* ================================================================
   核定统计分析接口
   ================================================================ */
interface AnalysisItem {
  id: string
  orgId: string
  orgName: string
  equipName: string
  shouldQty: number
  actualQty: number
  unitPrice: number
  updateTime: string
}

/* ================================================================
   核定统计分析 - 4级组织架构树（省→市→县→基层）
   ================================================================ */
interface AnaOrgNode {
  id: string
  label: string
  level: '省级' | '市级' | '县级' | '基层'
  children?: AnaOrgNode[]
}

const anaOrgTreeData: AnaOrgNode[] = [
  {
    id: 'ana-prov-1', label: 'XX省公安厅', level: '省级',
    children: [
      {
        id: 'ana-city-1', label: 'XX市公安局', level: '市级',
        children: [
          {
            id: 'ana-county-1', label: '城关分局', level: '县级',
            children: [
              { id: 'ana-station-1', label: '指挥中心', level: '基层' },
              { id: 'ana-station-2', label: '刑警支队', level: '基层' },
              { id: 'ana-station-3', label: '治安支队', level: '基层' },
              { id: 'ana-station-4', label: '交警支队', level: '基层' },
              { id: 'ana-station-5', label: '特警支队', level: '基层' },
            ],
          },
          {
            id: 'ana-county-2', label: '开发区分局', level: '县级',
            children: [
              { id: 'ana-station-6', label: '开发区综合队', level: '基层' },
            ],
          },
          {
            id: 'ana-county-3', label: '高新分局', level: '县级',
            children: [
              { id: 'ana-station-7', label: '高新综合队', level: '基层' },
            ],
          },
        ],
      },
    ],
  },
]

// 基层单位id → orgName 映射（用于数据关联）
const anaOrgIdToName: Record<string, string> = {
  'ana-station-1': '指挥中心',
  'ana-station-2': '刑警支队',
  'ana-station-3': '治安支队',
  'ana-station-4': '交警支队',
  'ana-station-5': '特警支队',
  'ana-station-6': '开发区分局',
  'ana-station-7': '高新分局',
}

/* ================================================================
   核定统计样例数据
   ================================================================ */
const analysisData: AnalysisItem[] = [
  { id: '1', orgId: 'ana-station-1', orgName: '指挥中心', equipName: '接处警信息系统平台', shouldQty: 1, actualQty: 1, unitPrice: 45.00, updateTime: '2025-06' },
  { id: '2', orgId: 'ana-station-1', orgName: '指挥中心', equipName: '接处警工作台', shouldQty: 1, actualQty: 1, unitPrice: 12.00, updateTime: '2025-06' },
  { id: '3', orgId: 'ana-station-1', orgName: '指挥中心', equipName: '报警受理系统', shouldQty: 1, actualQty: 0, unitPrice: 38.00, updateTime: '2025-06' },
  { id: '4', orgId: 'ana-station-1', orgName: '指挥中心', equipName: '数字录音系统', shouldQty: 1, actualQty: 1, unitPrice: 8.50, updateTime: '2025-06' },
  { id: '5', orgId: 'ana-station-1', orgName: '指挥中心', equipName: '通信调度系统', shouldQty: 1, actualQty: 1, unitPrice: 22.00, updateTime: '2025-06' },
  { id: '6', orgId: 'ana-station-2', orgName: '刑警支队', equipName: '执法记录仪', shouldQty: 60, actualQty: 52, unitPrice: 0.18, updateTime: '2025-06' },
  { id: '7', orgId: 'ana-station-2', orgName: '刑警支队', equipName: '手持终端', shouldQty: 30, actualQty: 30, unitPrice: 0.28, updateTime: '2025-06' },
  { id: '8', orgId: 'ana-station-2', orgName: '刑警支队', equipName: '对讲机', shouldQty: 50, actualQty: 45, unitPrice: 0.15, updateTime: '2025-06' },
  { id: '9', orgId: 'ana-station-2', orgName: '刑警支队', equipName: '急救包', shouldQty: 30, actualQty: 25, unitPrice: 0.03, updateTime: '2025-06' },
  { id: '10', orgId: 'ana-station-3', orgName: '治安支队', equipName: '防弹背心', shouldQty: 20, actualQty: 18, unitPrice: 0.32, updateTime: '2025-06' },
  { id: '11', orgId: 'ana-station-3', orgName: '治安支队', equipName: '战术头盔', shouldQty: 20, actualQty: 20, unitPrice: 0.26, updateTime: '2025-06' },
  { id: '12', orgId: 'ana-station-3', orgName: '治安支队', equipName: '执法记录仪', shouldQty: 40, actualQty: 35, unitPrice: 0.18, updateTime: '2025-06' },
  { id: '13', orgId: 'ana-station-4', orgName: '交警支队', equipName: '执法记录仪', shouldQty: 80, actualQty: 72, unitPrice: 0.18, updateTime: '2025-06' },
  { id: '14', orgId: 'ana-station-4', orgName: '交警支队', equipName: '对讲机', shouldQty: 60, actualQty: 60, unitPrice: 0.15, updateTime: '2025-06' },
  { id: '15', orgId: 'ana-station-4', orgName: '交警支队', equipName: '警用强光手电', shouldQty: 80, actualQty: 65, unitPrice: 0.035, updateTime: '2025-06' },
  { id: '16', orgId: 'ana-station-5', orgName: '特警支队', equipName: '防弹背心', shouldQty: 30, actualQty: 30, unitPrice: 0.32, updateTime: '2025-06' },
  { id: '17', orgId: 'ana-station-5', orgName: '特警支队', equipName: '战术头盔', shouldQty: 30, actualQty: 28, unitPrice: 0.26, updateTime: '2025-06' },
  { id: '18', orgId: 'ana-station-5', orgName: '特警支队', equipName: '防暴盾牌', shouldQty: 40, actualQty: 40, unitPrice: 0.068, updateTime: '2025-06' },
  { id: '19', orgId: 'ana-station-5', orgName: '特警支队', equipName: '通信调度系统', shouldQty: 1, actualQty: 1, unitPrice: 22.00, updateTime: '2025-06' },
  { id: '20', orgId: 'ana-station-6', orgName: '开发区分局', equipName: '执法记录仪', shouldQty: 30, actualQty: 22, unitPrice: 0.18, updateTime: '2025-06' },
  { id: '21', orgId: 'ana-station-6', orgName: '开发区分局', equipName: '对讲机', shouldQty: 30, actualQty: 28, unitPrice: 0.15, updateTime: '2025-06' },
  { id: '22', orgId: 'ana-station-6', orgName: '开发区分局', equipName: '警用强光手电', shouldQty: 30, actualQty: 25, unitPrice: 0.035, updateTime: '2025-06' },
  { id: '23', orgId: 'ana-station-7', orgName: '高新分局', equipName: '执法记录仪', shouldQty: 25, actualQty: 20, unitPrice: 0.18, updateTime: '2025-06' },
  { id: '24', orgId: 'ana-station-7', orgName: '高新分局', equipName: '对讲机', shouldQty: 25, actualQty: 20, unitPrice: 0.15, updateTime: '2025-06' },
  { id: '25', orgId: 'ana-station-7', orgName: '高新分局', equipName: '警用强光手电', shouldQty: 25, actualQty: 22, unitPrice: 0.035, updateTime: '2025-06' },
]

const directoryData: StandardDirectory[] = [
  { id: '1', code: 'PB-2024-001', name: '刑侦支队装备配备标准', dept: '刑警支队', scene: '侦查办案', effectDate: '2024-01-01', status: '启用', remark: '2024年度刑侦支队标配' },
  { id: '2', code: 'PB-2024-002', name: '治安支队装备配备标准', dept: '治安支队', scene: '日常执勤', effectDate: '2024-01-01', status: '启用', remark: '' },
  { id: '3', code: 'PB-2024-003', name: '特警支队装备配备标准', dept: '特警支队', scene: '反恐防暴', effectDate: '2024-03-01', status: '启用', remark: '含应急处突专项' },
  { id: '4', code: 'PB-2024-004', name: '交警大队装备配备标准', dept: '交警大队', scene: '交通管控', effectDate: '2024-01-01', status: '停用', remark: '待修订' },
  { id: '5', code: 'PB-2024-005', name: '指挥中心装备配备标准', dept: '指挥中心', scene: '日常执勤', effectDate: '2024-06-01', status: '启用', remark: '新增通信装备' },
  { id: '6', code: 'PB-2024-006', name: '派出所装备配备标准', dept: '派出所', scene: '巡逻防控', effectDate: '2024-01-01', status: '启用', remark: '覆盖基层所队' },
]

const projectData: EquipProject[] = [
  { id: '1', code: 'XM-001', name: '执法记录仪', assetCategory: '执法装备', assetSysName: '执法记录仪DSJ-A7', status: '启用' },
  { id: '2', code: 'XM-002', name: '手持终端', assetCategory: '通信装备', assetSysName: '手持终端XT-2000', status: '启用' },
  { id: '3', code: 'XM-003', name: '对讲机', assetCategory: '通信装备', assetSysName: '对讲机PD780G', status: '启用' },
  { id: '4', code: 'XM-004', name: '防弹背心', assetCategory: '防护装备', assetSysName: '防弹背心FDY-3R', status: '启用' },
  { id: '5', code: 'XM-005', name: '战术头盔', assetCategory: '防护装备', assetSysName: '战术头盔MICH-2000', status: '启用' },
  { id: '6', code: 'XM-006', name: '急救包', assetCategory: '医疗装备', assetSysName: '急救包JJB-A', status: '启用' },
  { id: '7', code: 'XM-007', name: '防暴盾牌', assetCategory: '防暴装备', assetSysName: '防暴盾牌FB-P', status: '停用' },
  { id: '8', code: 'XM-008', name: '警用强光手电', assetCategory: '照明设备', assetSysName: '警用强光手电', status: '启用' },
]

const unitData: EquipUnit[] = [
  { id: '1', name: '办案大队数', calcDimension: '机构', calcRule: '按机构数量核算', applicableStandards: ['刑侦支队标准', '治安支队标准'], status: '启用' },
  { id: '2', name: '在岗人数', calcDimension: '人员', calcRule: '按实际在岗人数核算', applicableStandards: ['刑侦支队标准', '派出所标准'], status: '启用' },
  { id: '3', name: '编制总数', calcDimension: '编制', calcRule: '按核定编制数核算', applicableStandards: ['治安支队标准', '交警大队标准'], status: '启用' },
  { id: '4', name: '业务点位数', calcDimension: '点位', calcRule: '按业务点位数量核算', applicableStandards: ['指挥中心标准'], status: '启用' },
  { id: '5', name: '巡逻中队数', calcDimension: '机构', calcRule: '按巡逻中队数量核算', applicableStandards: ['巡警支队标准'], status: '停用' },
  { id: '6', name: '执勤班组数', calcDimension: '人员', calcRule: '按执勤班组人数核算', applicableStandards: ['特警支队标准'], status: '启用' },
]

const detailData: StandardDetail[] = [
  { id: '1', standardCode: 'PB-2024-001', seqNo: 1, projectName: '执法记录仪', unitName: '办案大队数', ratio: '1:2', qty: 2, configUnitType: '按人数', unit: '件/人', peopleCount: '', target: '', useYears: '3年', unitPrice: 1800, maintainFee: 200, equipType: '刚性标配', isSysEquip: true, funcDesc: '执法过程全程记录', remark: '每人配备1台' },
  { id: '2', standardCode: 'PB-2024-001', seqNo: 2, projectName: '手持终端', unitName: '在岗人数', ratio: '1:1', qty: 1, configUnitType: '按人数', unit: '件/人', peopleCount: '', target: '', useYears: '5年', unitPrice: 2800, maintainFee: 350, equipType: '刚性标配', isSysEquip: true, funcDesc: '移动执法信息查询', remark: '刑侦标配' },
  { id: '3', standardCode: 'PB-2024-001', seqNo: 3, projectName: '对讲机', unitName: '在岗人数', ratio: '1:1', qty: 1, configUnitType: '按人数', unit: '件/人', peopleCount: '', target: '', useYears: '3年', unitPrice: 1500, maintainFee: 150, equipType: '刚性标配', isSysEquip: false, funcDesc: '无线通信联络', remark: '' },
  { id: '4', standardCode: 'PB-2024-002', seqNo: 1, projectName: '防弹背心', unitName: '在岗人数', ratio: '1:1', qty: 1, configUnitType: '按人数', unit: '件/人', peopleCount: '', target: '', useYears: '5年', unitPrice: 3200, maintainFee: 100, equipType: '弹性选配', isSysEquip: true, funcDesc: '人身安全防护', remark: '高危岗位配备' },
  { id: '5', standardCode: 'PB-2024-002', seqNo: 2, projectName: '战术头盔', unitName: '在岗人数', ratio: '1:1', qty: 1, configUnitType: '按人数', unit: '件/人', peopleCount: '', target: '', useYears: '5年', unitPrice: 2600, maintainFee: 80, equipType: '弹性选配', isSysEquip: true, funcDesc: '头部安全防护', remark: '' },
  { id: '6', standardCode: 'PB-2024-003', seqNo: 1, projectName: '防暴盾牌', unitName: '编制总数', ratio: '1:2', qty: 2, configUnitType: '按单位', unit: '面', peopleCount: '', target: '', useYears: '3年', unitPrice: 680, maintainFee: 50, equipType: '刚性标配', isSysEquip: false, funcDesc: '防暴处突防护', remark: '特警标配' },
  { id: '7', standardCode: 'PB-2024-003', seqNo: 2, projectName: '急救包', unitName: '执勤班组数', ratio: '1:1', qty: 1, configUnitType: '按单位', unit: '个', peopleCount: '', target: '', useYears: '3年', unitPrice: 320, maintainFee: 30, equipType: '刚性标配', isSysEquip: false, funcDesc: '急救医疗用品', remark: '' },
  { id: '8', standardCode: 'PB-2024-006', seqNo: 1, projectName: '警用强光手电', unitName: '在岗人数', ratio: '1:1', qty: 1, configUnitType: '按人数', unit: '根/人', peopleCount: '', target: '', useYears: '2年', unitPrice: 350, maintainFee: 20, equipType: '刚性标配', isSysEquip: false, funcDesc: '夜间执勤照明', remark: '基层标配' },
]

/* ================================================================
   主组件
   ================================================================ */
export default function EquipStandardPage({ activeSubTab, onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'analysis')

  /* ---- 配备标准管理子状态 ---- */
  const [standardSubTab, setStandardSubTab] = useState<StandardSubTab>('directory')
  const [modalOpen, setModalOpen] = useState(false)
  const [modalTitle, setModalTitle] = useState('')
  const [editData, setEditData] = useState<any>(null)

  // 目录维护弹窗state
  const [dCode, setDCode] = useState('')
  const [dName, setDName] = useState('')
  const [dDept, setDDept] = useState('')
  const [dScene, setDScene] = useState('')
  const [dEffectDate, setDEffectDate] = useState('')
  const [dStatus, setDStatus] = useState<'启用' | '停用'>('启用')
  const [dRemark, setDRemark] = useState('')

  // 项目维护弹窗state
  const [pCode, setPCode] = useState('')
  const [pName, setPName] = useState('')
  const [pCategory, setPCategory] = useState('')
  const [pAssetName, setPAssetName] = useState('')
  const [pStatus, setPStatus] = useState<'启用' | '停用'>('启用')

  // 单元维护弹窗state
  const [uName, setUName] = useState('')
  const [uDimension, setUDimension] = useState<'机构' | '人员' | '编制' | '点位'>('机构')
  const [uRule, setURule] = useState('')
  const [uStandards, setUStandards] = useState<string[]>([])
  const [uStatus, setUStatus] = useState<'启用' | '停用'>('启用')

  // 标准明细弹窗state
  const [sCode, setSCode] = useState('')
  const [sSeqNo, setSSeqNo] = useState(1)
  const [sProject, setSProject] = useState('')
  const [sUnit, setSUnit] = useState('')
  const [sRatio, setSRatio] = useState('')
  const [sQty, setSQty] = useState(1)
  const [sUnit2, setSUnit2] = useState('')
  const [sUseYears, setSUseYears] = useState('')
  const [sPrice, setSPrice] = useState(0)
  const [sFee, setSFee] = useState(0)
  const [sType, setSType] = useState<'刚性标配' | '弹性选配'>('刚性标配')
  const [sIsSys, setSIsSys] = useState(false)
  const [sFunc, setSFunc] = useState('')
  const [sRemark, setSRemark] = useState('')

  const [directories, setDirectories] = useState(directoryData)
  const [projects, setProjects] = useState(projectData)
  const [units, setUnits] = useState(unitData)
  const [details, setDetails] = useState(detailData)

  // 树形导航状态
  const [selectedTreeNode, setSelectedTreeNode] = useState<string>('municipal-org')

  // 树形数据改为响应式状态
  const [treeData, setTreeData] = useState([
    {
      id: 'provincial', label: '省级标准', expanded: true,
      children: [{ id: 'provincial-dept', label: '省厅标准', expanded: false }],
    },
    {
      id: 'municipal', label: '市级标准', expanded: true,
      children: [{ id: 'municipal-org', label: '市级机关标准', expanded: false }],
    },
    {
      id: 'public', label: '公用标准', expanded: true,
      children: [
        { id: 'public-station', label: '派出机构标准', expanded: false },
        { id: 'public-venue', label: '其他监管场所标准', expanded: false },
      ],
    },
  ])

  // 中间栏：系统自带的组织机构树状态
  const [selectedStdOrgNode, setSelectedStdOrgNode] = useState<string>('')

  // 标准分类 → 组织机构的联动映射（根据左侧选中的标准，确定中间哪些组织适用）
  const getStandardToOrgs = (stdNodeId: string): string[] => {
    if (stdNodeId.startsWith('provincial')) {
      return ['org-root', 'org-branch1', 'org-dept1', 'org-dept2', 'org-dept3', 'org-dept4', 'org-dept5', 'org-dept6']
    }
    if (stdNodeId.startsWith('municipal')) {
      return ['org-root', 'org-branch2', 'org-sub1', 'org-sub2', 'org-sub3']
    }
    if (stdNodeId.startsWith('public')) {
      return ['org-root', 'org-branch3', 'org-p1', 'org-p2', 'org-p3', 'org-p4']
    }
    return []
  }

  // 过滤中间栏的组织机构树（根据左侧选中的标准分类）
  const filterOrgTreeByStandard = (nodes: OrgNode[], allowedIds: string[]): OrgNode[] => {
    return nodes.reduce<OrgNode[]>((acc, node) => {
      const isAllowed = allowedIds.includes(node.id)
      const filteredChildren = node.children ? filterOrgTreeByStandard(node.children, allowedIds) : undefined
      const hasAllowedChildren = filteredChildren && filteredChildren.length > 0
      if (isAllowed || hasAllowedChildren) {
        acc.push({ ...node, children: filteredChildren })
      }
      return acc
    }, [])
  }

  // 右侧表格数据根据（左侧标准 + 中间组织）联动过滤
  const getFilteredDetailRows = () => {
    // 未选中标准分类时显示全部
    if (!selectedTreeNode) return detailRows
    // 未选中组织机构时，显示该标准分类下的全部数据
    if (!selectedStdOrgNode) return detailRows
    // 两个都选中了，根据组织类型过滤展示不同的配备项目
    // 这里用简单的逻辑：根据选中的组织节点，返回对应的配备项目子集
    const orgNode = findOrgNode(orgTreeData, selectedStdOrgNode)
    if (!orgNode) return detailRows
    // 根据组织层级和类型，展示不同的数据行
    // 简单实现：指挥中心显示接处警相关，刑警支队显示执法装备相关，派出所显示基层装备相关
    const dept = orgNode.label
    if (dept === '指挥中心') {
      return detailRows.filter(r => r.id === 'd1' || r.id === 'd2' || r.id === 'd3' || r.id === 'd4' || r.id.startsWith('d5') || r.id.startsWith('d6') || r.id.startsWith('d7') || r.id.startsWith('d8') || r.id.startsWith('d9') || r.id.startsWith('d10') || r.id.startsWith('d11'))
    }
    if (dept === '刑警支队') {
      return detailRows.filter(r => r.id === 'd1' || r.id === 'd2' || r.id.startsWith('d5') || r.id.startsWith('d6') || r.id.startsWith('d7'))
    }
    if (dept === '治安支队') {
      return detailRows.filter(r => r.id === 'd1' || r.id === 'd2' || r.id.startsWith('d5') || r.id.startsWith('d6'))
    }
    if (dept === '特警支队') {
      return detailRows.filter(r => r.id === 'd1' || r.id.startsWith('d13') || r.id.startsWith('d14'))
    }
    return detailRows
  }

  // 递归渲染中间栏的组织架构树（带联动高亮）
  const renderStdOrgTree = (nodes: OrgNode[], depth: number = 0): any => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const pad = depth * 14 + 6
      return (
        <div key={node.id}>
          <button
            className={`w-full text-left px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${selectedStdOrgNode === node.id ? 'bg-green-50 text-green-600 font-medium' : 'hover:bg-gray-50'}`}
            style={{ paddingLeft: `${pad}px` }}
            onClick={() => setSelectedStdOrgNode(node.id)}
          >
            {hasChildren ? (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
            ) : <span className="w-2.5" />}
            <span>{node.label}</span>
          </button>
          {hasChildren && node.children && renderStdOrgTree(node.children, depth + 1)}
        </div>
      )
    })
  }

  // 树节点操作弹窗
  const [treeModalOpen, setTreeModalOpen] = useState(false)
  const [treeModalType, setTreeModalType] = useState<'addSibling' | 'addChild' | 'edit'>('addChild')
  const [treeModalLabel, setTreeModalLabel] = useState('')

  // 配置弹窗 - 两步向导
  const [configModalOpen, setConfigModalOpen] = useState(false)
  const [configStep, setConfigStep] = useState<1 | 2>(1)
  const [configUnitIds, setConfigUnitIds] = useState<string[]>([])
  const [configEquipList, setConfigEquipList] = useState<any[]>([])

  const createEmptyEquipRow = (): Record<string, any> => ({
    id: `eq-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    equipName: '', configUnitType: '按单位', unit: '套', peopleCount: '', target: '', qty: '1', years: '5-8年',
    price: '0', fee: '0', equipType: '必配', isSysEquip: '是', funcDesc: '',
  })

  // 查找节点路径
  const findNodePath = (nodes: any[], id: string, path: number[] = []): number[] | null => {
    for (let i = 0; i < nodes.length; i++) {
      if (nodes[i].id === id) return [...path, i]
      if (nodes[i].children) {
        const childPath = findNodePath(nodes[i].children, id, [...path, i])
        if (childPath) return childPath
      }
    }
    return null
  }

  // 树节点CRUD
  const addTreeNode = (parentPath: number[] | null, label: string) => {
    const newNode = { id: `node-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, label, expanded: false, children: [] as any[] }
    setTreeData(prev => {
      const next = JSON.parse(JSON.stringify(prev))
      if (parentPath === null) {
        next.push(newNode)
      } else {
        let target = next
        for (let i = 0; i < parentPath.length; i++) {
          target = target[parentPath[i]].children
        }
        target.push(newNode)
      }
      return next
    })
  }

  const editTreeNode = (nodePath: number[], label: string) => {
    setTreeData(prev => {
      const next = JSON.parse(JSON.stringify(prev))
      let target = next
      for (let i = 0; i < nodePath.length - 1; i++) {
        target = target[nodePath[i]].children
      }
      target[nodePath[nodePath.length - 1]].label = label
      return next
    })
  }

  const deleteTreeNode = (nodePath: number[]) => {
    setTreeData(prev => {
      const next = JSON.parse(JSON.stringify(prev))
      let target = next
      for (let i = 0; i < nodePath.length - 1; i++) {
        target = target[nodePath[i]].children
      }
      target.splice(nodePath[nodePath.length - 1], 1)
      return next
    })
    setSelectedTreeNode('')
  }

  // 树节点操作按钮
  const handleTreeAddSibling = () => {
    if (!selectedTreeNode) { alert('请先选择一个节点'); return }
    setTreeModalType('addSibling')
    setTreeModalLabel('')
    setTreeModalOpen(true)
  }

  const handleTreeAddChild = () => {
    if (!selectedTreeNode) { alert('请先选择一个节点'); return }
    setTreeModalType('addChild')
    setTreeModalLabel('')
    setTreeModalOpen(true)
  }

  const handleTreeEdit = () => {
    if (!selectedTreeNode) { alert('请先选择一个节点'); return }
    const path = findNodePath(treeData, selectedTreeNode)
    if (!path) return
    const node = path.reduce((acc: any, idx: number) => acc[idx].children || acc[idx], treeData as any)
    const target = path.length === 1 ? treeData[path[0]] : path.slice(0, -1).reduce((acc: any, idx: number) => acc[idx].children, treeData as any)[path[path.length - 1]]
    setTreeModalType('edit')
    setTreeModalLabel(target.label)
    setTreeModalOpen(true)
  }

  const handleTreeDelete = () => {
    if (!selectedTreeNode) { alert('请先选择一个节点'); return }
    if (!confirm('确定删除该节点及其子节点吗？')) return
    const path = findNodePath(treeData, selectedTreeNode)
    if (path) deleteTreeNode(path)
  }

  const handleTreeModalSave = () => {
    if (!treeModalLabel.trim()) { alert('请输入节点名称'); return }
    const path = findNodePath(treeData, selectedTreeNode)
    if (treeModalType === 'addSibling') {
      if (!path || path.length === 1) {
        addTreeNode(null, treeModalLabel.trim())
      } else {
        addTreeNode(path.slice(0, -1), treeModalLabel.trim())
      }
    } else if (treeModalType === 'addChild') {
      addTreeNode(path || null, treeModalLabel.trim())
    } else if (treeModalType === 'edit' && path) {
      editTreeNode(path, treeModalLabel.trim())
    }
    setTreeModalOpen(false)
    setTreeModalLabel('')
  }

  // 配置弹窗操作
  const handleConfigOpen = () => {
    if (!selectedTreeNode) { alert('请先选择一个标准节点'); return }
    setConfigStep(1)
    setConfigUnitIds([])
    setConfigEquipList([createEmptyEquipRow()])
    setConfigModalOpen(true)
  }

  // 递归收集所有组织架构节点ID和label
  const collectOrgNodes = (nodes: OrgNode[]): { id: string; label: string }[] => {
    return nodes.reduce<{ id: string; label: string }[]>((acc, n) => {
      acc.push({ id: n.id, label: n.label })
      if (n.children) acc.push(...collectOrgNodes(n.children))
      return acc
    }, [])
  }

  // 步骤1：递归渲染可多选的单位树
  const renderStep1UnitTree = (nodes: OrgNode[], depth: number = 0): any => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const isSelected = configUnitIds.includes(node.id)
      const pad = depth * 16 + 8
      return (
        <div key={node.id}>
          <label className="w-full text-left px-2 py-1.5 rounded text-sm flex items-center gap-2 cursor-pointer hover:bg-gray-50 transition-colors" style={{ paddingLeft: `${pad}px` }}>
            <input type="checkbox" checked={isSelected} onChange={() => {
              setConfigUnitIds(prev => isSelected ? prev.filter(id => id !== node.id) : [...prev, node.id])
            }} />
            <span>{node.label}</span>
          </label>
          {hasChildren && node.children && renderStep1UnitTree(node.children, depth + 1)}
        </div>
      )
    })
  }

  const handleConfigSave = () => {
    // 验证至少有一条装备数据且装备名称不为空
    const validEquips = configEquipList.filter(e => e.equipName.trim())
    if (validEquips.length === 0) { alert('请至少填写一条装备明细'); return }
    setConfigModalOpen(false)
  }

  /* ================================================================
     核定因素管理状态
     ================================================================ */
  const [factors, setFactors] = useState<FactorItem[]>(factorData)
  const [selectedOrgNode, setSelectedOrgNode] = useState<string>('')
  const [factorSearchKey, setFactorSearchKey] = useState('')
  const [factorSearchType, setFactorSearchType] = useState<'全部' | '采集' | '按需' | '应配'>('全部')

  // 核定因素弹窗 - 支持一次性添加多条
  const [factorModalOpen, setFactorModalOpen] = useState(false)
  const [factorEditId, setFactorEditId] = useState<string | null>(null)
  const [factorFormList, setFactorFormList] = useState<{
    id: string; collectType: '采集' | '按需' | '应配'; standardName: string;
    equipName: string; unit: string; shouldQty: string; shouldAmount: string;
    targetObj: string; remark: string;
  }[]>([])

  const createEmptyFactorRow = () => ({
    id: `ft-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
    collectType: '应配' as '采集' | '按需' | '应配',
    standardName: '', equipName: '', unit: '', shouldQty: '', shouldAmount: '', targetObj: '', remark: '',
  })

  const openFactorAdd = () => {
    setFactorEditId(null)
    setFactorFormList([createEmptyFactorRow()])
    setFactorModalOpen(true)
  }

  const openFactorEdit = (item: FactorItem) => {
    setFactorEditId(item.id)
    setFactorFormList([{
      id: `ft-${Date.now()}`,
      collectType: item.collectType,
      standardName: item.standardName,
      equipName: item.equipName,
      unit: item.unit,
      shouldQty: String(item.shouldQty),
      shouldAmount: String(item.shouldAmount),
      targetObj: item.targetObj,
      remark: item.remark,
    }])
    setFactorModalOpen(true)
  }

  const handleFactorDelete = (id: string) => {
    if (!confirm('确定删除该核定因素吗？')) return
    setFactors(prev => prev.filter(f => f.id !== id))
  }

  const handleFactorSave = () => {
    const validItems = factorFormList.filter(f => f.standardName.trim() && f.equipName.trim() && f.shouldQty.trim())
    if (validItems.length === 0) { alert('请至少填写一条有效的核定因素（标准名称、配备项目、应配数为必填）'); return }

    if (factorEditId) {
      const first = validItems[0]
      setFactors(prev => prev.map(f => f.id === factorEditId ? {
        ...f,
        collectType: first.collectType,
        standardName: first.standardName,
        equipName: first.equipName,
        unit: first.unit,
        shouldQty: Number(first.shouldQty),
        shouldAmount: Number(first.shouldAmount),
        targetObj: first.targetObj,
        remark: first.remark,
      } : f))
    } else {
      const orgLabel = selectedOrgNode ? (findOrgNode(orgTreeData, selectedOrgNode)?.label || '') : ''
      validItems.forEach(item => {
        setFactors(prev => [...prev, {
          id: String(Date.now()) + '-' + Math.random().toString(36).slice(2, 5),
          orgId: selectedOrgNode,
          orgName: orgLabel || '全局',
          collectType: item.collectType,
          standardName: item.standardName,
          equipName: item.equipName,
          unit: item.unit,
          shouldQty: Number(item.shouldQty),
          shouldAmount: Number(item.shouldAmount),
          targetObj: item.targetObj,
          remark: item.remark,
        }])
      })
    }
    setFactorModalOpen(false)
  }

  // 递归查找组织架构节点
  const findOrgNode = (nodes: OrgNode[], id: string): OrgNode | null => {
    for (const n of nodes) {
      if (n.id === id) return n
      if (n.children) { const r = findOrgNode(n.children, id); if (r) return r }
    }
    return null
  }

  // 递归渲染组织架构树
  const renderOrgTree = (nodes: OrgNode[], depth: number = 0): any => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const pad = depth * 16 + 8
      return (
        <div key={node.id}>
          <button
            className={`w-full text-left px-2 py-1.5 rounded text-sm flex items-center gap-1 transition-colors ${selectedOrgNode === node.id ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50'}`}
            style={{ paddingLeft: `${pad}px` }}
            onClick={() => setSelectedOrgNode(node.id)}
          >
            {hasChildren ? (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
            ) : <span className="w-3" />}
            <span>{node.label}</span>
          </button>
          {hasChildren && node.children && renderOrgTree(node.children, depth + 1)}
        </div>
      )
    })
  }

  // 过滤后的核定因素列表
  const filteredFactors = factors.filter(f => {
    if (selectedOrgNode && !f.orgId.startsWith(selectedOrgNode) && f.orgId !== selectedOrgNode) {
      // 简单过滤：如果选中了节点，只显示该节点的数据（或全部）
    }
    if (factorSearchType !== '全部' && f.collectType !== factorSearchType) return false
    if (factorSearchKey) {
      const key = factorSearchKey.toLowerCase()
      return f.standardName.toLowerCase().includes(key) ||
        f.equipName.toLowerCase().includes(key) ||
        f.targetObj.toLowerCase().includes(key) ||
        f.orgName.toLowerCase().includes(key)
    }
    return true
  })

  /* ---- 统计计算 ---- */
  const enabledDirs = directories.filter(d => d.status === '启用').length
  const enabledProjs = projects.filter(p => p.status === '启用').length
  const enabledUnits = units.filter(u => u.status === '启用').length
  const rigidCount = details.filter(d => d.equipType === '刚性标配').length
  const flexCount = details.filter(d => d.equipType === '弹性选配').length
  const totalRefVal = details.reduce((s, d) => s + d.unitPrice * d.qty, 0)

  // 顶层统计：配备标准数、配置单位数、配备达标率、刚性标配项
  const stdCount = directories.length
  const configUnitCount = new Set(analysisData.map(a => a.orgId)).size
  const overallPassRate = (() => {
    let pass = 0
    analysisData.forEach(item => { if (item.actualQty >= item.shouldQty) pass++ })
    return analysisData.length > 0 ? ((pass / analysisData.length) * 100).toFixed(1) : '0.0'
  })()

  const resetModal = () => {
    setDCode(''); setDName(''); setDDept(''); setDScene(''); setDEffectDate(''); setDStatus('启用'); setDRemark('')
    setPCode(''); setPName(''); setPCategory(''); setPAssetName(''); setPStatus('启用')
    setUName(''); setUDimension('机构'); setURule(''); setUStandards([]); setUStatus('启用')
    setSCode(''); setSSeqNo(1); setSProject(''); setSUnit(''); setSRatio(''); setSQty(1); setSUnit2(''); setSUseYears(''); setSPrice(0); setSFee(0); setSType('刚性标配'); setSIsSys(false); setSFunc(''); setSRemark('')
    setEditData(null)
  }

  const openAdd = (tab: StandardSubTab) => {
    setStandardSubTab(tab)
    resetModal()
    const titles: Record<StandardSubTab, string> = {
      directory: '新增标准目录',
      project: '新增配备项目',
      unit: '新增配备单元',
      detail: '新增标准明细',
    }
    setModalTitle(titles[tab])
    setModalOpen(true)
  }

  const openEdit = (tab: StandardSubTab, row: any) => {
    setStandardSubTab(tab)
    resetModal()
    setEditData(row)
    const titles: Record<StandardSubTab, string> = {
      directory: '编辑标准目录',
      project: '编辑配备项目',
      unit: '编辑配备单元',
      detail: '编辑标准明细',
    }
    setModalTitle(titles[tab])

    if (tab === 'directory') {
      setDCode(row.code); setDName(row.name); setDDept(row.dept); setDScene(row.scene)
      setDEffectDate(row.effectDate); setDStatus(row.status); setDRemark(row.remark)
    } else if (tab === 'project') {
      setPCode(row.code); setPName(row.name); setPCategory(row.assetCategory); setPAssetName(row.assetSysName); setPStatus(row.status)
    } else if (tab === 'unit') {
      setUName(row.name); setUDimension(row.calcDimension); setURule(row.calcRule); setUStandards(row.applicableStandards); setUStatus(row.status)
    } else {
      setSCode(row.standardCode); setSSeqNo(row.seqNo); setSProject(row.projectName); setSUnit(row.unitName)
      setSRatio(row.ratio); setSQty(row.qty); setSUnit2(row.unit); setSUseYears(row.useYears); setSPrice(row.unitPrice)
      setSFee(row.maintainFee); setSType(row.equipType); setSIsSys(row.isSysEquip); setSFunc(row.funcDesc); setSRemark(row.remark)
    }
    setModalOpen(true)
  }

  const handleSave = () => {
    if (standardSubTab === 'directory') {
      if (!dCode || !dName) { alert('请填写标准编号和名称'); return }
      if (editData) {
        setDirectories(prev => prev.map(d => d.id === editData.id ? { ...d, code: dCode, name: dName, dept: dDept, scene: dScene, effectDate: dEffectDate, status: dStatus, remark: dRemark } : d))
      } else {
        setDirectories(prev => [...prev, { id: String(Date.now()), code: dCode, name: dName, dept: dDept, scene: dScene, effectDate: dEffectDate, status: dStatus, remark: dRemark }])
      }
    } else if (standardSubTab === 'project') {
      if (!pCode || !pName) { alert('请填写项目编码和名称'); return }
      if (editData) {
        setProjects(prev => prev.map(p => p.id === editData.id ? { ...p, code: pCode, name: pName, assetCategory: pCategory, assetSysName: pAssetName, status: pStatus } : p))
      } else {
        setProjects(prev => [...prev, { id: String(Date.now()), code: pCode, name: pName, assetCategory: pCategory, assetSysName: pAssetName, status: pStatus }])
      }
    } else if (standardSubTab === 'unit') {
      if (!uName) { alert('请填写单元名称'); return }
      if (editData) {
        setUnits(prev => prev.map(u => u.id === editData.id ? { ...u, name: uName, calcDimension: uDimension, calcRule: uRule, applicableStandards: uStandards, status: uStatus } : u))
      } else {
        setUnits(prev => [...prev, { id: String(Date.now()), name: uName, calcDimension: uDimension, calcRule: uRule, applicableStandards: uStandards, status: uStatus }])
      }
    } else {
      if (!sCode || !sProject) { alert('请填写标准代码和配备项目'); return }
      if (editData) {
        setDetails(prev => prev.map(d => d.id === editData.id ? { ...d, standardCode: sCode, seqNo: sSeqNo, projectName: sProject, unitName: sUnit, ratio: sRatio, qty: sQty, unit: sUnit2, useYears: sUseYears, unitPrice: sPrice, maintainFee: sFee, equipType: sType, isSysEquip: sIsSys, funcDesc: sFunc, remark: sRemark } : d))
      } else {
        setDetails(prev => [...prev, { id: String(Date.now()), standardCode: sCode, seqNo: sSeqNo, projectName: sProject, unitName: sUnit, ratio: sRatio, qty: sQty, unit: sUnit2, useYears: sUseYears, unitPrice: sPrice, maintainFee: sFee, equipType: sType, isSysEquip: sIsSys, funcDesc: sFunc, remark: sRemark }])
      }
    }
    setModalOpen(false)
    resetModal()
  }

  const handleDelete = (tab: StandardSubTab, id: string) => {
    if (!confirm('确定删除该记录吗？')) return
    if (tab === 'directory') setDirectories(prev => prev.filter(d => d.id !== id))
    else if (tab === 'project') setProjects(prev => prev.filter(p => p.id !== id))
    else if (tab === 'unit') setUnits(prev => prev.filter(u => u.id !== id))
    else setDetails(prev => prev.filter(d => d.id !== id))
  }

  const toggleStatus = (tab: StandardSubTab, id: string) => {
    if (tab === 'directory') {
      setDirectories(prev => prev.map(d => d.id === id ? { ...d, status: d.status === '启用' ? '停用' as const : '启用' as const } : d))
    } else if (tab === 'project') {
      setProjects(prev => prev.map(p => p.id === id ? { ...p, status: p.status === '启用' ? '停用' as const : '启用' as const } : p))
    } else if (tab === 'unit') {
      setUnits(prev => prev.map(u => u.id === id ? { ...u, status: u.status === '启用' ? '停用' as const : '启用' as const } : u))
    }
  }

  /* ================================================================
     Render - 配备标准管理模块
     ================================================================ */
  const detailRows = [
  // ── 县局标准 ──
  { id: 'std1', isHeader: true, name: '县局标准', level: 0, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 指挥信通装备
  { id: 'cmd1', isHeader: true, name: '指挥信通装备', level: 1, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 指挥调度装备
  { id: 'cmd11', isHeader: true, name: '指挥调度装备', level: 2, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 接处警设备
  { id: 'cmd111', isHeader: true, name: '接处警设备', level: 3, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd01', isHeader: false, name: '智能接处警系统', level: 4, unit: '套', configUnitType: '按单位', qty: '1', years: '5-8年', price: '350000', fee: '17500', type: '必配', sys: '是', desc: '集报警定位、语音转写、智能派单于一体的接处警平台', peopleCount: '', target: '指挥中心' },
  { id: 'd02', isHeader: false, name: '语音调度终端', level: 4, unit: '套', configUnitType: '按单位', qty: '1', years: '5年', price: '28000', fee: '1400', type: '必配', sys: '是', desc: '支持语音呼叫、群组调度、录音回放功能', peopleCount: '', target: '指挥中心' },
  // 调度设备
  { id: 'cmd112', isHeader: true, name: '调度设备', level: 3, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd03', isHeader: false, name: '调度服务器', level: 4, unit: '套', configUnitType: '按单位', qty: '1', years: '5年', price: '85000', fee: '4250', type: '必配', sys: '是', desc: '承载调度业务的核心服务器设备', peopleCount: '', target: '指挥中心' },
  { id: 'd04', isHeader: false, name: '调度控制台', level: 4, unit: '台', configUnitType: '按单位', qty: '2', years: '6年', price: '45000', fee: '2250', type: '必配', sys: '是', desc: '三联屏可升降操作台，用于调度指挥', peopleCount: '', target: '指挥中心' },
  // 通信保障装备
  { id: 'cmd12', isHeader: true, name: '通信保障装备', level: 2, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 无线通信设备
  { id: 'cmd121', isHeader: true, name: '无线通信设备', level: 3, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd05', isHeader: false, name: '对讲机 PD780G', level: 4, unit: '套/支队', configUnitType: '按支队', qty: '10', years: '5年', price: '1800', fee: '90', type: '必配', sys: '是', desc: 'U段数字对讲机，支持组呼和紧急呼叫', peopleCount: '', target: '各支队' },
  { id: 'd06', isHeader: false, name: '手持终端 XT-2000', level: 4, unit: '套/支队', configUnitType: '按支队', qty: '8', years: '5年', price: '3200', fee: '160', type: '必配', sys: '是', desc: '集成GPS定位、4G通信的手持执法终端', peopleCount: '', target: '各支队' },
  // 卫星通信设备
  { id: 'cmd122', isHeader: true, name: '卫星通信设备', level: 3, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd07', isHeader: false, name: '卫星便携站', level: 4, unit: '套', configUnitType: '按单位', qty: '2', years: '8年', price: '120000', fee: '6000', type: '选配', sys: '否', desc: '便携式卫星通信站，应急场景快速部署', peopleCount: '', target: '指挥中心' },
  // 执勤执法装备
  { id: 'duty1', isHeader: true, name: '执勤执法装备', level: 1, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 个人防护装备
  { id: 'duty11', isHeader: true, name: '个人防护装备', level: 2, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd08', isHeader: false, name: '防弹背心 FDY-3R', level: 4, unit: '件/人', configUnitType: '按人数', qty: '1', years: '5年', price: '2500', fee: '125', type: '必配', sys: '是', desc: '三级防弹标准，前后插板式防护设计', peopleCount: '5', target: '特警支队' },
  { id: 'd09', isHeader: false, name: '战术头盔 MICH-2000', level: 4, unit: '颗/人', configUnitType: '按人数', qty: '1', years: '5年', price: '1500', fee: '75', type: '必配', sys: '是', desc: '轻量化战术防护头盔，L号可调节内衬', peopleCount: '5', target: '特警支队' },
  { id: 'd10', isHeader: false, name: '防暴盾牌 FB-P', level: 4, unit: '件/人', configUnitType: '按人数', qty: '1', years: '6年', price: '800', fee: '40', type: '必配', sys: '是', desc: '铝合金防暴盾牌，手持式防护装备', peopleCount: '5', target: '特警支队' },
  // 应急急救装备
  { id: 'duty12', isHeader: true, name: '应急急救装备', level: 2, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd11', isHeader: false, name: '急救包 JJB-A', level: 4, unit: '件/人', configUnitType: '按人数', qty: '1', years: '3年', price: '220', fee: '11', type: '必配', sys: '否', desc: '综合型急救包，含绷带、消毒液等基础用品', peopleCount: '5', target: '全体民警' },
  { id: 'd12', isHeader: false, name: '伸缩警棍 ZG-T', level: 4, unit: '根/人', configUnitType: '按人数', qty: '1', years: '4年', price: '350', fee: '18', type: '必配', sys: '否', desc: '钛合金材质伸缩式制伏警棍', peopleCount: '5', target: '全体民警' },
  // 消防装备
  { id: 'fire1', isHeader: true, name: '消防装备', level: 1, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  // 灭火器材
  { id: 'fire11', isHeader: true, name: '灭火器材', level: 2, unit: '', configUnitType: '', qty: '', years: '', price: '', fee: '', type: '', sys: '', desc: '', peopleCount: '', target: '' },
  { id: 'd13', isHeader: false, name: '消防水带 65mm', level: 4, unit: '套/支队', configUnitType: '按支队', qty: '20', years: '3年', price: '180', fee: '9', type: '必配', sys: '否', desc: '65mm口径20米有衬里消防水带', peopleCount: '', target: '消防支队' },
  { id: 'd14', isHeader: false, name: '灭火器套装', level: 4, unit: '套/支队', configUnitType: '按支队', qty: '5', years: '3年', price: '450', fee: '23', type: '必配', sys: '否', desc: '含干粉灭火器2具+消防斧+消防钩', peopleCount: '', target: '消防支队' },
  { id: 'd15', isHeader: false, name: '执法记录仪 DSJ-A7', level: 4, unit: '件/人', configUnitType: '按人数', qty: '1', years: '4年', price: '1200', fee: '60', type: '必配', sys: '是', desc: '64G高清执法记录，红外夜视功能', peopleCount: '5', target: '全体民警' },
]

  // 递归渲染树节点
  const renderTreeNodes = (nodes: any[], depth: number = 0): any => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const pad = depth * 16 + 8
      return (
        <div key={node.id}>
          <button
            className={`w-full text-left px-2 py-1.5 rounded text-sm flex items-center gap-1 transition-colors ${selectedTreeNode === node.id ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50'}`}
            style={{ paddingLeft: `${pad}px` }}
            onClick={() => setSelectedTreeNode(node.id)}
          >
            {hasChildren ? (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
            ) : <span className="w-3" />}
            <span>{node.label}</span>
          </button>
          {hasChildren && node.children && renderTreeNodes(node.children, depth + 1)}
        </div>
      )
    })
  }

  const renderStandardModule = () => {
    // 根据左侧标准过滤中间的组织机构
    const allowedOrgIds = getStandardToOrgs(selectedTreeNode)
    const filteredOrgTree = selectedTreeNode ? filterOrgTreeByStandard(orgTreeData, allowedOrgIds) : orgTreeData
    // 获取联动过滤后的右侧表格数据
    const filteredDetailRows = getFilteredDetailRows()

    return (
    <div className="space-y-4">
      {/* 左中右三栏布局：标准分类 | 组织机构 | 配备项目表格 */}
      <div className="flex gap-3" style={{ minHeight: '600px' }}>
        {/* 左侧：标准分类树 */}
        <div className="content-card p-3 flex-shrink-0 flex flex-col" style={{ width: '200px' }}>
          {/* 操作按钮栏 */}
          <div className="flex flex-wrap gap-1 mb-2">
            <button onClick={handleTreeAddSibling} title="增加同级" className="flex-1 flex items-center justify-center gap-0.5 text-xs py-1 rounded border hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              同级
            </button>
            <button onClick={handleTreeAddChild} title="增加子级" className="flex-1 flex items-center justify-center gap-0.5 text-xs py-1 rounded border hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              子级
            </button>
            <button onClick={handleTreeEdit} title="编辑" className="flex-1 flex items-center justify-center gap-0.5 text-xs py-1 rounded border hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              编辑
            </button>
            <button onClick={handleTreeDelete} title="删除" className="flex-1 flex items-center justify-center gap-0.5 text-xs py-1 rounded border hover:bg-red-50 transition-colors" style={{ borderColor: 'var(--border-color)', color: '#ff4d4f' }}>
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
              删除
            </button>
          </div>
          <h3 className="text-sm font-semibold mb-2 px-1" style={{ color: 'var(--text-primary)' }}>标准分类</h3>
          <div className="flex-1 overflow-y-auto">
            {renderTreeNodes(treeData, 0)}
          </div>
          {/* 配置按钮 */}
          <div className="mt-2 pt-2 border-t" style={{ borderColor: 'var(--border-color)' }}>
            <button onClick={handleConfigOpen} className="w-full btn-primary flex items-center justify-center gap-1 py-1.5 text-xs">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83 0 2 2 0 010-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 010-2.83 2 2 0 012.83 0l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 0 2 2 0 010 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z"/></svg>
              配置
            </button>
          </div>
        </div>

        {/* 中间：系统自带的组织机构树 */}
        <div className="content-card p-3 flex-shrink-0 flex flex-col" style={{ width: '190px' }}>
          <h3 className="text-sm font-semibold mb-3 px-1 flex items-center gap-1" style={{ color: 'var(--text-primary)' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
            配置单位
          </h3>
          <div className="flex-1 overflow-y-auto">
            {filteredOrgTree.length > 0 ? renderStdOrgTree(filteredOrgTree, 0) : (
              <p className="text-xs text-center py-4" style={{ color: 'var(--text-secondary)' }}>请先选择标准分类</p>
            )}
          </div>
          <div className="mt-2 pt-2 border-t text-center" style={{ borderColor: 'var(--border-color)' }}>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
              {selectedStdOrgNode ? `已选: ${findOrgNode(filteredOrgTree, selectedStdOrgNode)?.label || ''}` : '未选择组织'}
            </span>
          </div>
        </div>

        {/* 右侧：配备项目表格 */}
        <div className="content-card overflow-hidden flex-1">
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ minWidth: 180 }}>配备项目名称</th>
                <th style={{ minWidth: 60 }}>配置单元</th>
                <th style={{ minWidth: 60 }}>计量单位</th>
                <th style={{ minWidth: 50 }}>数量</th>
                <th style={{ minWidth: 70 }}>使用年限</th>
                <th style={{ minWidth: 80 }}>参考单价</th>
                <th style={{ minWidth: 70 }}>维护费用</th>
                <th style={{ minWidth: 60 }}>配备类型</th>
                <th style={{ minWidth: 70 }}>配备对象</th>
                <th style={{ minWidth: 70 }}>系统装备</th>
                <th style={{ minWidth: 250 }}>功能描述</th>
              </tr>
            </thead>
            <tbody>
              {filteredDetailRows.map(row => (
                row.isHeader ? (
                  <tr key={row.id} style={{ background: '#fafafa' }}>
                    <td className="font-medium" style={{ paddingLeft: `${row.level * 20 + 12}px`, color: 'var(--text-primary)' }}>
                      {row.name}
                    </td>
                    <td colSpan={10} />
                  </tr>
                ) : (
                  <tr key={row.id}>
                    <td style={{ paddingLeft: `${row.level * 20 + 12}px` }}>{row.name}</td>
                    <td>{row.configUnitType || '按单位'}</td>
                    <td>{row.unit}</td>
                    <td>{row.configUnitType === '按人数' && row.peopleCount ? `${row.qty}/${row.peopleCount}` : row.qty}</td>
                    <td>{row.years}</td>
                    <td className="font-mono text-right">{row.price}</td>
                    <td className="font-mono text-right">{row.fee}</td>
                    <td>{row.type}</td>
                    <td>{row.target || '-'}</td>
                    <td>{row.sys}</td>
                    <td className="text-xs" style={{ maxWidth: 400 }}>{row.desc}</td>
                  </tr>
                )
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ===== 树节点操作弹窗 ===== */}
      {treeModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTreeModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[400px] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-5 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-base font-semibold">
                {treeModalType === 'addSibling' ? '增加同级节点' : treeModalType === 'addChild' ? '增加子级节点' : '编辑节点'}
              </h3>
              <button onClick={() => setTreeModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-5">
              <label className="block text-sm mb-2" style={{ color: 'var(--text-secondary)' }}>
                节点名称 <span className="text-red-400">*</span>
              </label>
              <input className="form-input w-full" placeholder="请输入节点名称..." value={treeModalLabel} onChange={e => setTreeModalLabel(e.target.value)} autoFocus />
            </div>
            <div className="flex items-center justify-end gap-3 px-5 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setTreeModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleTreeModalSave}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 配置弹窗 - 两步向导 ===== */}
      {configModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setConfigModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[960px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* 弹窗头部 */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-lg font-semibold">
                  配置标准 - {(() => { const path = findNodePath(treeData, selectedTreeNode); if (!path) return ''; let target = treeData as any; for (let i = 0; i < path.length - 1; i++) target = target[path[i]].children; return target[path[path.length - 1]]?.label || '' })()}
                </h3>
                {/* 步骤指示器 */}
                <div className="flex items-center gap-2 mt-2">
                  <span className={`text-xs px-2.5 py-0.5 rounded-full ${configStep === 1 ? 'text-white' : 'text-gray-500'}`} style={{ background: configStep === 1 ? 'var(--primary-blue)' : '#f0f0f0' }}>步骤 1：选择配备单位</span>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>
                  <span className={`text-xs px-2.5 py-0.5 rounded-full ${configStep === 2 ? 'text-white' : 'text-gray-500'}`} style={{ background: configStep === 2 ? 'var(--primary-blue)' : '#f0f0f0' }}>步骤 2：装备明细清单</span>
                </div>
              </div>
              <button onClick={() => setConfigModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* ===== 步骤 1：选择配备单位 ===== */}
            {configStep === 1 && (
              <>
                <div className="flex flex-1 overflow-hidden" style={{ minHeight: '400px' }}>
                  {/* 左侧：组织架构树可多选 */}
                  <div className="w-1/2 p-5 border-r overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="text-sm font-medium mb-3" style={{ color: 'var(--text-primary)' }}>系统组织架构</h4>
                    {renderStep1UnitTree(orgTreeData, 0)}
                  </div>
                  {/* 右侧：已选单位清单 */}
                  <div className="w-1/2 p-5 overflow-y-auto">
                    <h4 className="text-sm font-medium mb-3" style={{ color: 'var(--text-primary)' }}>
                      已选单位（{configUnitIds.length}）
                    </h4>
                    {configUnitIds.length === 0 && (
                      <p className="text-sm py-4 text-center" style={{ color: 'var(--text-secondary)' }}>请在左侧选择配备单位</p>
                    )}
                    <div className="space-y-1.5">
                      {collectOrgNodes(orgTreeData).filter(n => configUnitIds.includes(n.id)).map(node => (
                        <div key={node.id} className="flex items-center justify-between px-3 py-2 rounded-lg bg-blue-50 text-sm">
                          <span className="text-blue-700">{node.label}</span>
                          <button onClick={() => setConfigUnitIds(prev => prev.filter(id => id !== node.id))} className="text-blue-400 hover:text-red-500 transition-colors">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setConfigModalOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => {
                    if (configUnitIds.length === 0) { alert('请至少选择一个配备单位'); return }
                    setConfigStep(2)
                  }}>下一步</button>
                </div>
              </>
            )}

            {/* ===== 步骤 2：装备明细清单 ===== */}
            {configStep === 2 && (
              <>
                <div className="flex-1 overflow-y-auto p-6 space-y-4">
                  {/* 已选单位展示 */}
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>配备单位：</span>
                    {collectOrgNodes(orgTreeData).filter(n => configUnitIds.includes(n.id)).map(n => (
                      <span key={n.id} className="tag text-xs tag-blue">{n.label}</span>
                    ))}
                  </div>
                  {/* 装备列表 - 2行紧凑布局 */}
                  {configEquipList.map((equip, idx) => (
                    <div key={equip.id} className="border rounded-lg p-3 space-y-2" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>装备 #{idx + 1}</span>
                        {configEquipList.length > 1 && (
                          <button onClick={() => setConfigEquipList(prev => prev.filter(e => e.id !== equip.id))} className="text-xs flex items-center gap-1 hover:text-red-500 transition-colors" style={{ color: '#ff4d4f' }}>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                            删除
                          </button>
                        )}
                      </div>
                      {/* 第1行：名称+配置单元+计量单位+数量 */}
                      <div className="grid grid-cols-6 gap-2">
                        <div className="col-span-2">
                          <label className="block text-[11px] mb-0.5">装备名称 <span className="text-red-400">*</span></label>
                          <input className="form-input w-full text-sm py-1" placeholder="装备名称" value={equip.equipName} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, equipName: e.target.value } : item))} />
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">配置单元</label>
                          <select className="form-input w-full text-sm py-1" value={equip.configUnitType || '按单位'} onChange={e => { const newType = e.target.value; setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, configUnitType: newType, unit: configUnitOptions.find(g => g.group === newType)?.options[0] || '' } : item)) }}>
                            <option>按单位</option>
                            <option>按支队</option>
                            <option>按大队</option>
                            <option>按中队</option>
                            <option>按人数</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">计量单位</label>
                          <select className="form-input w-full text-sm py-1" value={equip.unit} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, unit: e.target.value } : item))}>
                            {configUnitOptions.filter(g => g.group === (equip.configUnitType || '按单位')).map(g => g.options.map(o => <option key={o}>{o}</option>))}
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">数量</label>
                          {equip.configUnitType === '按人数' ? (
                            <div className="flex items-center gap-1">
                              <input className="form-input w-1/2 text-sm py-1" placeholder="人数" value={equip.peopleCount || ''} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, peopleCount: e.target.value } : item))} />
                              <span className="text-xs whitespace-nowrap">人</span>
                              <input className="form-input w-1/2 text-sm py-1" placeholder="数量" value={equip.qty} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, qty: e.target.value } : item))} />
                              {equip.peopleCount ? <span className="text-xs font-mono whitespace-nowrap" style={{ color: '#1890ff' }}>({equip.qty || 1}/{equip.peopleCount})</span> : null}
                            </div>
                          ) : (
                            <input className="form-input w-full text-sm py-1" value={equip.qty} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, qty: e.target.value } : item))} />
                          )}
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">使用年限</label>
                          <input className="form-input w-full text-sm py-1" placeholder="5-8年" value={equip.years} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, years: e.target.value } : item))} />
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">类型</label>
                          <select className="form-input w-full text-sm py-1" value={equip.equipType} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, equipType: e.target.value } : item))}>
                            <option>必配</option><option>选配</option><option>弹性选配</option>
                          </select>
                        </div>
                      </div>
                      {/* 第2行：单价+费用+系统+配备对象+描述 */}
                      <div className="grid grid-cols-6 gap-2">
                        <div>
                          <label className="block text-[11px] mb-0.5">参考单价</label>
                          <input className="form-input w-full text-sm py-1" value={equip.price} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, price: e.target.value } : item))} />
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">维护费用</label>
                          <input className="form-input w-full text-sm py-1" value={equip.fee} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, fee: e.target.value } : item))} />
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">系统装备</label>
                          <select className="form-input w-full text-sm py-1" value={equip.isSysEquip} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, isSysEquip: e.target.value } : item))}>
                            <option>是</option><option>否</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] mb-0.5">配备对象</label>
                          <input className="form-input w-full text-sm py-1" placeholder="配备对象" value={equip.target || ''} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, target: e.target.value } : item))} />
                        </div>
                        <div className="col-span-2">
                          <label className="block text-[11px] mb-0.5">功能描述</label>
                          <input className="form-input w-full text-sm py-1" placeholder="描述该装备的功能用途..." value={equip.funcDesc} onChange={e => setConfigEquipList(prev => prev.map((item, i) => i === idx ? { ...item, funcDesc: e.target.value } : item))} />
                        </div>
                      </div>
                    </div>
                  ))}
                  {/* 添加装备按钮 */}
                  <button onClick={() => setConfigEquipList(prev => [...prev, createEmptyEquipRow()])} className="w-full py-3 rounded-lg border-2 border-dashed flex items-center justify-center gap-2 text-sm transition-colors hover:border-blue-400 hover:text-blue-600" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    添加一条装备
                  </button>
                </div>
                <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setConfigModalOpen(false)}>取消</button>
                  <button className="btn-default" onClick={() => setConfigStep(1)}>上一步</button>
                  <button className="btn-primary" onClick={handleConfigSave}>保存</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )}

  /* ================================================================
     Render - 核定因素管理
     ================================================================ */
  const renderFactorModule = () => (
    <div className="space-y-4">
      {/* 搜索区域 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关键词</label>
            <input className="form-input w-48" placeholder="标准名称/配备项目..." value={factorSearchKey} onChange={e => setFactorSearchKey(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采集类型</label>
            <select className="form-input w-28" value={factorSearchType} onChange={e => setFactorSearchType(e.target.value as any)}>
              <option>全部</option><option>采集</option><option>按需</option><option>应配</option>
            </select>
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default" onClick={() => { setFactorSearchKey(''); setFactorSearchType('全部') }}>重置</button>
            <button className="btn-primary" onClick={() => {}}>查询</button>
          </div>
        </div>
      </div>

      {/* 左侧组织树 + 右侧列表 */}
      <div className="flex gap-4" style={{ minHeight: '600px' }}>
        {/* 左侧组织架构树 */}
        <div className="content-card p-3 flex-shrink-0 flex flex-col" style={{ width: '220px' }}>
          <h3 className="text-sm font-semibold mb-3 px-2" style={{ color: 'var(--text-primary)' }}>组织架构</h3>
          <div className="flex-1 overflow-y-auto">
            {renderOrgTree(orgTreeData, 0)}
          </div>
          <div className="mt-2 pt-2 border-t text-center" style={{ borderColor: 'var(--border-color)' }}>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
              {selectedOrgNode ? `已选: ${findOrgNode(orgTreeData, selectedOrgNode)?.label || ''}` : '未选择组织'}
            </span>
          </div>
        </div>

        {/* 右侧核定因素列表 */}
        <div className="flex-1 space-y-3">
          {/* 操作栏 */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={openFactorAdd}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增
              </button>
              <button className="btn-default flex items-center gap-1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                导出
              </button>
            </div>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filteredFactors.length} 条记录</span>
          </div>

          {/* 表格 */}
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>配备类型</th>
                  <th>标准名称</th>
                  <th>配备项目</th>
                  <th>配置单元</th>
                  <th>应配数</th>
                  <th>应配额（万元）</th>
                  <th>配备对象</th>
                  <th>备注</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {filteredFactors.map(item => (
                  <tr key={item.id}>
                    <td>
                      <span className={`tag text-xs ${item.collectType === '应配' ? 'tag-green' : item.collectType === '按需' ? 'tag-blue' : 'tag-orange'}`}>{item.collectType}</span>
                    </td>
                    <td className="font-medium">{item.standardName}</td>
                    <td>{item.equipName}</td>
                    <td>{item.unit}</td>
                    <td className="text-center font-mono">{item.shouldQty}</td>
                    <td className="text-right font-mono">{item.shouldAmount.toFixed(2)}</td>
                    <td>{item.targetObj}</td>
                    <td className="text-xs">{item.remark || '-'}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openFactorEdit(item)}>编辑</button>
                        <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleFactorDelete(item.id)}>删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
                {filteredFactors.length === 0 && (
                  <tr><td colSpan={9} className="text-center py-8 text-sm" style={{ color: 'var(--text-secondary)' }}>暂无数据</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* ===== 新增/编辑弹窗 - 支持一次性多条，2行布局 ===== */}
      {factorModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setFactorModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[960px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{factorEditId ? '编辑核定因素' : '新增核定因素'}</h3>
              <button onClick={() => setFactorModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-3">
              {factorFormList.map((factor, idx) => (
                <div key={factor.id} className="border rounded-lg p-3 space-y-2" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>明细 #{idx + 1}</span>
                    {factorFormList.length > 1 && (
                      <button onClick={() => setFactorFormList(prev => prev.filter(f => f.id !== factor.id))} className="text-xs flex items-center gap-1 hover:text-red-500 transition-colors" style={{ color: '#ff4d4f' }}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>
                        删除
                      </button>
                    )}
                  </div>
                  {/* 第1行：配备类型+标准名称+配备项目+单位 */}
                  <div className="grid grid-cols-6 gap-2">
                    <div>
                      <label className="block text-[11px] mb-0.5">配备类型</label>
                      <select className="form-input w-full text-sm py-1" value={factor.collectType} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, collectType: e.target.value as any } : item))}>
                        <option>应配</option><option>按需</option><option>采集</option>
                      </select>
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] mb-0.5">标准名称 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full text-sm py-1" placeholder="标准名称" value={factor.standardName} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, standardName: e.target.value } : item))} />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] mb-0.5">配备项目 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full text-sm py-1" placeholder="配备项目" value={factor.equipName} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, equipName: e.target.value } : item))} />
                    </div>
                    <div>
                      <label className="block text-[11px] mb-0.5">配置单元</label>
                      <select className="form-input w-full text-sm py-1" value={factor.unit} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, unit: e.target.value } : item))}>
                        <option value="">请选择</option>
                        {configUnitOptions.map(g => (
                          <optgroup key={g.group} label={g.group}>
                            {g.options.map(o => <option key={o}>{o}</option>)}
                          </optgroup>
                        ))}
                      </select>
                    </div>
                  </div>
                  {/* 第2行：应配数+应配额+配备对象+备注 */}
                  <div className="grid grid-cols-6 gap-2">
                    <div>
                      <label className="block text-[11px] mb-0.5">应配数 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full text-sm py-1" type="number" min={0} placeholder="0" value={factor.shouldQty} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, shouldQty: e.target.value } : item))} />
                    </div>
                    <div>
                      <label className="block text-[11px] mb-0.5">应配额（万元）</label>
                      <input className="form-input w-full text-sm py-1" type="number" min={0} step="0.01" placeholder="0.00" value={factor.shouldAmount} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, shouldAmount: e.target.value } : item))} />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] mb-0.5">配备对象</label>
                      <input className="form-input w-full text-sm py-1" placeholder="配备对象" value={factor.targetObj} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, targetObj: e.target.value } : item))} />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-[11px] mb-0.5">备注</label>
                      <input className="form-input w-full text-sm py-1" placeholder="备注说明..." value={factor.remark} onChange={e => setFactorFormList(prev => prev.map((item, i) => i === idx ? { ...item, remark: e.target.value } : item))} />
                    </div>
                  </div>
                </div>
              ))}
              {/* 添加按钮 */}
              <button onClick={() => setFactorFormList(prev => [...prev, createEmptyFactorRow()])} className="w-full py-3 rounded-lg border-2 border-dashed flex items-center justify-center gap-2 text-sm transition-colors hover:border-blue-400 hover:text-blue-600" style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                添加一条核定因素
              </button>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setFactorModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleFactorSave}>保存</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )

  /* ================================================================
     核定统计分析状态 - 树形层级统计
     ================================================================ */
  const [analysisList] = useState<AnalysisItem[]>(analysisData)
  const [anaTimeStart, setAnaTimeStart] = useState('2025-01')
  const [anaTimeEnd, setAnaTimeEnd] = useState('2025-12')
  const [anaViewMode, setAnaViewMode] = useState<'chart' | 'table'>('chart')
  const [anaChartType, setAnaChartType] = useState<'qty' | 'amount'>('qty')
  const [selectedAnaOrg, setSelectedAnaOrg] = useState<string>('ana-prov-1')

  // 在4级树中查找节点
  const findAnaOrgNode = (nodes: AnaOrgNode[], id: string): AnaOrgNode | null => {
    for (const n of nodes) {
      if (n.id === id) return n
      if (n.children) { const r = findAnaOrgNode(n.children, id); if (r) return r }
    }
    return null
  }

  // 收集某节点下所有叶子节点（基层单位）的id
  const collectLeafIds = (node: AnaOrgNode): string[] => {
    if (!node.children || node.children.length === 0) return [node.id]
    return node.children.flatMap(collectLeafIds)
  }

  // 获取某节点下所有叶子节点的分析数据
  const getLeafAnalysisData = (nodeId: string): AnalysisItem[] => {
    const node = findAnaOrgNode(anaOrgTreeData, nodeId)
    if (!node) return []
    const leafIds = collectLeafIds(node)
    return analysisList.filter(item => leafIds.includes(item.orgId))
  }

  // 计算一组分析数据的统计指标
  const calcStats = (items: AnalysisItem[]) => {
    let totalShould = 0, totalActual = 0, passCount = 0
    let shouldAmount = 0, actualAmount = 0, amountPassCount = 0
    items.forEach(item => {
      totalShould += item.shouldQty
      totalActual += item.actualQty
      if (item.actualQty >= item.shouldQty) passCount++
      const sa = item.shouldQty * item.unitPrice
      const aa = item.actualQty * item.unitPrice
      shouldAmount += sa
      actualAmount += aa
      if (aa >= sa) amountPassCount++
    })
    const totalItems = items.length || 1
    return {
      itemCount: items.length,
      totalShould,
      totalActual,
      totalGap: Math.max(0, totalShould - totalActual),
      totalSurplus: Math.max(0, totalActual - totalShould),
      passRate: ((passCount / totalItems) * 100).toFixed(1),
      amountPassRate: shouldAmount > 0 ? ((actualAmount / shouldAmount) * 100).toFixed(1) : '0.0',
      shouldAmount,
      actualAmount,
      passCount,
      underCount: totalItems - passCount,
    }
  }

  // 获取选中节点的直接子节点统计（用于非叶子节点展示下一层级达标率）
  const getChildrenStats = (nodeId: string) => {
    const node = findAnaOrgNode(anaOrgTreeData, nodeId)
    if (!node || !node.children) return []
    return node.children.map(child => {
      const childItems = getLeafAnalysisData(child.id)
      const stats = calcStats(childItems)
      return { ...child, ...stats, items: childItems }
    })
  }

  // 获取叶子节点（基层单位）的装备明细
  const getLeafEquipDetail = (nodeId: string) => {
    return getLeafAnalysisData(nodeId)
  }

  // 叶子节点饼图数据（主函数体中计算，供 renderAnalysisModule 使用）
  const leafPieData = useMemo(() => {
    const node = findAnaOrgNode(anaOrgTreeData, selectedAnaOrg)
    const isLeafNode = node ? !node.children || node.children.length === 0 : false
    if (!isLeafNode) return [{ name: '达标', value: 0 }, { name: '不达标', value: 0 }]
    const items = getLeafAnalysisData(selectedAnaOrg)
    let pass = 0, fail = 0
    items.forEach(item => {
      if (item.actualQty >= item.shouldQty) pass++
      else fail++
    })
    return [{ name: '达标', value: pass }, { name: '不达标', value: fail }]
  }, [selectedAnaOrg])

  /* ================================================================
     Render - 核定计算（预留占位）
     ================================================================ */
  const renderCalcModule = () => (
    <div className="content-card p-12 text-center">
      <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#f0f0f0' }}>
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#bfbfbf" strokeWidth="1.5">
          <path d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
        </svg>
      </div>
      <h3 className="text-base font-medium mb-2" style={{ color: 'var(--text-secondary)' }}>核定计算</h3>
      <p className="text-sm" style={{ color: 'var(--text-disabled)' }}>该模块正在开发中，敬请期待...</p>
    </div>
  )

  /* ================================================================
     Render - 核定统计分析（树形层级统计）
     ================================================================ */
  const renderAnalysisModule = () => {
    const selNode = findAnaOrgNode(anaOrgTreeData, selectedAnaOrg)
    const isLeaf = selNode ? !selNode.children || selNode.children.length === 0 : false
    const curStats = calcStats(getLeafAnalysisData(selectedAnaOrg))

    // 非叶子节点：展示下一层级的达标率
    const childrenStats = isLeaf ? [] : getChildrenStats(selectedAnaOrg)

    // 叶子节点：展示装备明细
    const equipDetail = isLeaf ? getLeafEquipDetail(selectedAnaOrg) : []

    // 当前层级标签
    const levelLabel = selNode?.level || ''

    // 下一层级达标率柱状图 - 支持数量/金额切换
    const levelBarOption = anaChartType === 'qty'
      ? {
          tooltip: { trigger: 'axis' as const, formatter: (p: any) => `${p[0].name}<br/>数量达标率: ${p[0].value}%` },
          grid: { left: '3%', right: '4%', bottom: '3%', top: 10, containLabel: true },
          xAxis: { type: 'category' as const, data: childrenStats.map(d => d.label), axisLabel: { rotate: 20, fontSize: 10 } },
          yAxis: { type: 'value' as const, name: '数量达标率%', max: 100 },
          series: [{
            type: 'bar' as const,
            data: childrenStats.map(d => Number(d.passRate)),
            itemStyle: { color: (p: any) => p.value >= 90 ? '#52c41a' : p.value >= 70 ? '#faad14' : '#ff4d4f', borderRadius: [4, 4, 0, 0] },
            barWidth: '40%',
            label: { show: true, position: 'top' as const, formatter: '{c}%', fontSize: 10 },
          }],
        }
      : {
          tooltip: { trigger: 'axis' as const, formatter: (p: any) => `${p[0].name}<br/>金额达标率: ${p[0].value}%` },
          grid: { left: '3%', right: '4%', bottom: '3%', top: 10, containLabel: true },
          xAxis: { type: 'category' as const, data: childrenStats.map(d => d.label), axisLabel: { rotate: 20, fontSize: 10 } },
          yAxis: { type: 'value' as const, name: '金额达标率%', max: 100 },
          series: [{
            type: 'bar' as const,
            data: childrenStats.map(d => {
              const shouldAmt = d.items.reduce((s, it) => s + it.shouldQty * it.unitPrice, 0)
              const actualAmt = d.items.reduce((s, it) => s + it.actualQty * it.unitPrice, 0)
              return shouldAmt > 0 ? Number(((actualAmt / shouldAmt) * 100).toFixed(1)) : 0
            }),
            itemStyle: { color: (p: any) => p.value >= 90 ? '#52c41a' : p.value >= 70 ? '#faad14' : '#ff4d4f', borderRadius: [4, 4, 0, 0] },
            barWidth: '40%',
            label: { show: true, position: 'top' as const, formatter: '{c}%', fontSize: 10 },
          }],
        }

    // 叶子节点装备柱状图 - 支持数量/金额切换
    const equipBarOption = {
      tooltip: { trigger: 'axis' as const, formatter: anaChartType === 'amount' ? '{b}<br/>{a0}: ¥{c0}万<br/>{a1}: ¥{c1}万' : '{b}<br/>{a0}: {c0}件<br/>{a1}: {c1}件' },
      legend: { data: ['应配', '实配'], top: 0 },
      grid: { left: '3%', right: '4%', bottom: '3%', top: 30, containLabel: true },
      xAxis: { type: 'category' as const, data: equipDetail.map(d => d.equipName), axisLabel: { rotate: 25, fontSize: 9 } },
      yAxis: { type: 'value' as const, name: anaChartType === 'amount' ? '金额(万元)' : '数量(件)' },
      series: [
        { name: '应配', type: 'bar' as const, data: equipDetail.map(d => anaChartType === 'amount' ? Number((d.shouldQty * d.unitPrice).toFixed(2)) : d.shouldQty), itemStyle: { color: '#1890ff' }, barWidth: '25%' },
        { name: '实配', type: 'bar' as const, data: equipDetail.map(d => anaChartType === 'amount' ? Number((d.actualQty * d.unitPrice).toFixed(2)) : d.actualQty), itemStyle: { color: '#52c41a' }, barWidth: '25%' },
      ],
    }

    const pieOption = {
      tooltip: { trigger: 'item' as const, formatter: '{b}: {c} ({d}%)' },
      legend: { bottom: 0 },
      series: [{
        type: 'pie' as const, radius: ['40%', '65%'], center: ['50%', '45%'],
        data: leafPieData,
        itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
        label: { show: true, formatter: '{b}\n{d}%' },
        color: ['#52c41a', '#ff4d4f'],
      }],
    }

    return (
    <div className="space-y-4">
      {/* 筛选区域 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>开始时间</label>
            <input className="form-input w-32" type="month" value={anaTimeStart} onChange={e => setAnaTimeStart(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>结束时间</label>
            <input className="form-input w-32" type="month" value={anaTimeEnd} onChange={e => setAnaTimeEnd(e.target.value)} />
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default" onClick={() => { setAnaTimeStart('2025-01'); setAnaTimeEnd('2025-12') }}>重置</button>
            <button className="btn-default flex items-center gap-1">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
              导出
            </button>
          </div>
        </div>
      </div>

      {/* 树形导航 + 右侧内容 */}
      <div className="flex gap-4" style={{ minHeight: '600px' }}>
        {/* 左侧组织架构树 */}
        <div className="content-card p-3 flex-shrink-0 flex flex-col" style={{ width: '200px' }}>
          <h3 className="text-sm font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>组织架构</h3>
          <div className="flex-1 overflow-y-auto">
            {(function renderTree(nodes: AnaOrgNode[], depth: number = 0): any {
              return nodes.map(node => {
                const hasChildren = node.children && node.children.length > 0
                const pad = depth * 14 + 6
                return (
                  <div key={node.id}>
                    <button
                      className={`w-full text-left px-2 py-1 rounded text-xs flex items-center gap-1 transition-colors ${selectedAnaOrg === node.id ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50'}`}
                      style={{ paddingLeft: `${pad}px` }}
                      onClick={() => setSelectedAnaOrg(node.id)}
                    >
                      {hasChildren ? (
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="6 9 12 15 18 9"/></svg>
                      ) : <span className="w-2.5" />}
                      <span>{node.label}</span>
                      {hasChildren && <span className="text-[10px] ml-auto opacity-50">{node.level}</span>}
                    </button>
                    {hasChildren && node.children && renderTree(node.children, depth + 1)}
                  </div>
                )
              })
            })(anaOrgTreeData, 0)}
          </div>
        </div>

        {/* 右侧内容 */}
        <div className="flex-1 space-y-4">
          {/* 面包屑路径 + 页签切换 */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs">
              <span style={{ color: 'var(--text-secondary)' }}>当前层级：</span>
              <span className="tag text-xs tag-blue">{levelLabel}</span>
              <span className="font-medium">{selNode?.label || ''}</span>
              {isLeaf ? (
                <span style={{ color: 'var(--text-secondary)' }}>- 共 {equipDetail.length} 项装备明细</span>
              ) : (
                <span style={{ color: 'var(--text-secondary)' }}>- 含 {childrenStats.length} 个{levelLabel === '省级' ? '市' : levelLabel === '市级' ? '区县' : '基层单位'}</span>
              )}
            </div>
            {/* 页签切换 */}
            <div className="flex rounded-lg border overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
              <button className={`px-4 py-1.5 text-xs transition-colors ${anaViewMode === 'chart' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaViewMode === 'chart' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaViewMode('chart')}>
                <span className="flex items-center gap-1">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 20V10M12 20V4M6 20v-6"/></svg>
                  图表
                </span>
              </button>
              <button className={`px-4 py-1.5 text-xs transition-colors ${anaViewMode === 'table' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaViewMode === 'table' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaViewMode('table')}>
                <span className="flex items-center gap-1">
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
                  表格
                </span>
              </button>
            </div>
          </div>

          {/* 统计卡片 */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-3">
            {[
              { label: '应配总数', value: curStats.totalShould, unit: '件', color: '#1890ff', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
              { label: '实配总数', value: curStats.totalActual, unit: '件', color: '#52c41a', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
              { label: '缺口总数', value: curStats.totalGap, unit: '件', color: '#ff4d4f', icon: 'M13 17h8m0 0V9m0 8l-8-8-4 4-6-6' },
              { label: '富余总数', value: curStats.totalSurplus, unit: '件', color: '#faad14', icon: 'M12 6v6m0 0v6m0-6h6m-6 0H6' },
              { label: '应配金额', value: `¥${curStats.shouldAmount.toFixed(2)}`, unit: '万元', color: '#1890ff', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
              { label: '实配金额', value: `¥${curStats.actualAmount.toFixed(2)}`, unit: '万元', color: '#52c41a', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
              { label: '数量达标率', value: `${curStats.passRate}%`, unit: `${curStats.passCount}/${curStats.itemCount}`, color: '#722ed1', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
              { label: '金额达标率', value: `${curStats.amountPassRate}%`, unit: `¥${curStats.actualAmount.toFixed(0)}/¥${curStats.shouldAmount.toFixed(0)}`, color: '#eb2f96', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
            ].map(card => (
              <div key={card.label} className="content-card p-3 flex items-center gap-3">
                <div className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={card.icon}/></svg>
                </div>
                <div>
                  <div className="text-[10px] mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                  <div className="text-base font-bold" style={{ color: card.color }}>{card.value}</div>
                  <div className="text-[9px]" style={{ color: 'var(--text-disabled)' }}>{card.unit}</div>
                </div>
              </div>
            ))}
          </div>

          {/* ===== 图表视图 ===== */}
          {anaViewMode === 'chart' && !isLeaf && (
            <div className="space-y-3">
              <div className="flex justify-end">
                <div className="flex rounded-lg border overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <button className={`px-4 py-1.5 text-xs transition-colors ${anaChartType === 'qty' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaChartType === 'qty' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaChartType('qty')}>数量达标</button>
                  <button className={`px-4 py-1.5 text-xs transition-colors ${anaChartType === 'amount' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaChartType === 'amount' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaChartType('amount')}>金额达标</button>
                </div>
              </div>
              <div className="content-card p-4">
                <h3 className="text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>
                  下一层级{anaChartType === 'amount' ? '金额' : '数量'}达标率（{levelLabel === '省级' ? '市级' : levelLabel === '市级' ? '县级' : '基层单位'}）
                </h3>
                <ReactECharts option={levelBarOption} style={{ height: '300px' }} />
              </div>
            </div>
          )}

          {anaViewMode === 'chart' && isLeaf && (
            <div className="space-y-4">
              {/* 数量/金额切换 */}
              <div className="flex justify-end">
                <div className="flex rounded-lg border overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <button className={`px-4 py-1.5 text-xs transition-colors ${anaChartType === 'qty' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaChartType === 'qty' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaChartType('qty')}>数量达标</button>
                  <button className={`px-4 py-1.5 text-xs transition-colors ${anaChartType === 'amount' ? 'text-white' : 'hover:bg-gray-50'}`} style={{ background: anaChartType === 'amount' ? 'var(--primary-blue)' : 'transparent' }} onClick={() => setAnaChartType('amount')}>金额达标</button>
                </div>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="content-card p-4">
                  <h3 className="text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>{anaChartType === 'amount' ? '各装备应配/实配金额对比' : '各装备应配/实配数量对比'}</h3>
                  <ReactECharts option={equipBarOption} style={{ height: '300px' }} />
                </div>
                <div className="content-card p-4">
                  <h3 className="text-sm font-semibold mb-2" style={{ color: 'var(--text-primary)' }}>达标状态分布</h3>
                  <ReactECharts option={pieOption} style={{ height: '300px' }} />
                </div>
              </div>
            </div>
          )}

          {/* ===== 表格视图 ===== */}
          {anaViewMode === 'table' && !isLeaf && (
            <div className="content-card overflow-hidden">
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
                <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>
                  {levelLabel === '省级' ? '市级' : levelLabel === '市级' ? '县级' : '基层单位'}达标情况汇总
                </h3>
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {childrenStats.length} 个（系统自动核算）</span>
              </div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>名称</th>
                    <th>层级</th>
                    <th>装备项数</th>
                    <th>应配总数</th>
                    <th>实配总数</th>
                    <th>缺口</th>
                    <th>富余</th>
                    <th>数量达标率</th>
                    <th>应配金额(万元)</th>
                    <th>实配金额(万元)</th>
                    <th>差额金额(万元)</th>
                    <th>金额达标率</th>
                    <th>达标状态</th>
                  </tr>
                </thead>
                <tbody>
                  {childrenStats.map(child => {
                    const childShouldAmount = child.items.reduce((s, it) => s + it.shouldQty * it.unitPrice, 0)
                    const childActualAmount = child.items.reduce((s, it) => s + it.actualQty * it.unitPrice, 0)
                    const amountPassRate = childShouldAmount > 0 ? ((childActualAmount / childShouldAmount) * 100).toFixed(1) : '0.0'
                    const isQtyPass = Number(child.passRate) >= 90
                    const isAmtPass = Number(amountPassRate) >= 90
                    return (
                      <tr key={child.id} className="cursor-pointer hover:bg-blue-50/50" onClick={() => setSelectedAnaOrg(child.id)}>
                        <td className="font-medium flex items-center gap-1">
                          {child.children ? (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--primary-blue)' }}><polyline points="9 18 15 12 9 6"/></svg>
                          ) : (
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2"><circle cx="12" cy="12" r="3"/></svg>
                          )}
                          {child.label}
                        </td>
                        <td><span className="text-xs px-2 py-0.5 rounded" style={{ background: child.level === '市级' ? '#e6f7ff' : child.level === '县级' ? '#f6ffed' : '#fff7e6', color: child.level === '市级' ? '#1890ff' : child.level === '县级' ? '#52c41a' : '#fa8c16' }}>{child.level}</span></td>
                        <td className="text-center font-mono">{child.itemCount}</td>
                        <td className="text-center font-mono">{child.totalShould}</td>
                        <td className="text-center font-mono">{child.totalActual}</td>
                        <td className="text-center font-mono" style={{ color: child.totalGap > 0 ? '#ff4d4f' : 'var(--text-secondary)' }}>{child.totalGap || '-'}</td>
                        <td className="text-center font-mono" style={{ color: child.totalSurplus > 0 ? '#faad14' : 'var(--text-secondary)' }}>{child.totalSurplus || '-'}</td>
                        <td className="text-center">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(Number(child.passRate), 100)}%`, background: Number(child.passRate) >= 90 ? '#52c41a' : Number(child.passRate) >= 70 ? '#faad14' : '#ff4d4f' }} />
                            </div>
                            <span className="text-xs font-mono">{child.passRate}%</span>
                          </div>
                        </td>
                        <td className="text-right font-mono">¥{childShouldAmount.toFixed(2)}</td>
                        <td className="text-right font-mono">¥{childActualAmount.toFixed(2)}</td>
                        <td className="text-right font-mono" style={{ color: child.totalGap > 0 ? '#ff4d4f' : 'var(--text-secondary)' }}>{child.totalGap > 0 ? `¥${(child.totalGap * 0.1).toFixed(2)}` : '-'}</td>
                        <td className="text-center">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(Number(amountPassRate), 100)}%`, background: Number(amountPassRate) >= 90 ? '#52c41a' : Number(amountPassRate) >= 70 ? '#faad14' : '#ff4d4f' }} />
                            </div>
                            <span className="text-xs font-mono">{amountPassRate}%</span>
                          </div>
                        </td>
                        <td>
                          <span className={`tag text-xs ${isQtyPass && isAmtPass ? 'tag-green' : isQtyPass || isAmtPass ? 'tag-orange' : 'tag-red'}`}>{isQtyPass && isAmtPass ? '已达标' : isQtyPass || isAmtPass ? '部分达标' : '未达标'}</span>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {anaViewMode === 'table' && isLeaf && (
            <div className="content-card overflow-hidden">
              <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
                <h3 className="text-sm font-semibold" style={{ color: 'var(--text-primary)' }}>各装备达标明细</h3>
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {equipDetail.length} 条记录（系统自动核算）</span>
              </div>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>装备项目</th>
                    <th>应配数</th>
                    <th>实配数</th>
                    <th>缺口</th>
                    <th>富余</th>
                    <th>数量达标率</th>
                    <th>应配金额(万元)</th>
                    <th>实配金额(万元)</th>
                    <th>金额达标率</th>
                    <th>差额金额(万元)</th>
                    <th>达标状态</th>
                  </tr>
                </thead>
                <tbody>
                  {equipDetail.map(item => {
                    const gap = Math.max(0, item.shouldQty - item.actualQty)
                    const surplus = Math.max(0, item.actualQty - item.shouldQty)
                    const shouldAmount = (item.shouldQty * item.unitPrice).toFixed(2)
                    const actualAmount = (item.actualQty * item.unitPrice).toFixed(2)
                    const qtyPassRate = item.shouldQty > 0 ? ((item.actualQty / item.shouldQty) * 100).toFixed(1) : '0.0'
                    const amtPassRate = (item.shouldQty * item.unitPrice) > 0 ? (((item.actualQty * item.unitPrice) / (item.shouldQty * item.unitPrice)) * 100).toFixed(1) : '0.0'
                    const isQtyPass = item.actualQty >= item.shouldQty
                    const isAmtPass = (item.actualQty * item.unitPrice) >= (item.shouldQty * item.unitPrice)
                    const diffAmount = (gap * item.unitPrice).toFixed(2)
                    return (
                      <tr key={item.id}>
                        <td className="font-medium">{item.equipName}</td>
                        <td className="text-center font-mono">{item.shouldQty}</td>
                        <td className="text-center font-mono">{item.actualQty}</td>
                        <td className="text-center font-mono" style={{ color: gap > 0 ? '#ff4d4f' : 'var(--text-secondary)' }}>{gap || '-'}</td>
                        <td className="text-center font-mono" style={{ color: surplus > 0 ? '#faad14' : 'var(--text-secondary)' }}>{surplus || '-'}</td>
                        <td className="text-center">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(Number(qtyPassRate), 100)}%`, background: isQtyPass ? '#52c41a' : '#ff4d4f' }} />
                            </div>
                            <span className="text-xs font-mono">{qtyPassRate}%</span>
                          </div>
                        </td>
                        <td className="text-right font-mono">¥{shouldAmount}</td>
                        <td className="text-right font-mono">¥{actualAmount}</td>
                        <td className="text-center">
                          <div className="flex items-center gap-1.5">
                            <div className="w-12 h-1.5 rounded-full bg-gray-100 overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(Number(amtPassRate), 100)}%`, background: isAmtPass ? '#52c41a' : '#ff4d4f' }} />
                            </div>
                            <span className="text-xs font-mono">{amtPassRate}%</span>
                          </div>
                        </td>
                        <td className="text-right font-mono" style={{ color: gap > 0 ? '#ff4d4f' : 'var(--text-secondary)' }}>{gap > 0 ? `¥${diffAmount}` : '-'}</td>
                        <td><span className={`tag text-xs ${isQtyPass && isAmtPass ? 'tag-green' : isQtyPass || isAmtPass ? 'tag-orange' : 'tag-red'}`}>{isQtyPass && isAmtPass ? '已达标' : isQtyPass || isAmtPass ? '部分达标' : '未达标'}</span></td>
                      </tr>
                    )
                  })}
                  {equipDetail.length === 0 && (
                    <tr><td colSpan={11} className="text-center py-8 text-sm" style={{ color: 'var(--text-secondary)' }}>暂无数据</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
    )
  }

  /* ================================================================
     主渲染
     ================================================================ */
  return (
    <div className="p-6 space-y-4">
      {/* 页面标题 */}
      <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>配备核定管理</h1>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: '配备标准数', value: `${stdCount} 个`, color: '#1890ff', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
          { label: '配置单位数', value: `${configUnitCount} 个`, color: '#52c41a', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5M9 21h6' },
          { label: '配备达标率', value: `${overallPassRate}%`, color: '#722ed1', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' },
          { label: '刚性标配项', value: `${rigidCount} 项`, color: '#eb2f96', icon: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-xl font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 快捷入口 */}
      <div className="content-card p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {tabList.map(item => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': activeTab === item.key ? '#1890ff' : 'transparent' } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: activeTab === item.key ? '#1890ff15' : '#f5f5f5' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={activeTab === item.key ? '#1890ff' : '#8c8c8c'} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  {item.key === 'analysis' && <path d="M18 20V10M12 20V4M6 20v-6"/>}
                  {item.key === 'standard' && <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>}
                  {item.key === 'factor' && <path d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"/>}
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium" style={{ color: activeTab === item.key ? '#1890ff' : 'var(--text-primary)' }}>{item.label}</div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>
                  {item.key === 'analysis' && '核定统计与分析'}
                  {item.key === 'standard' && '标准目录/项目/单元/明细'}
                  {item.key === 'factor' && '核定因素配置管理'}
                </div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* 内容区 */}
      {activeTab === 'analysis' && renderAnalysisModule()}
      {activeTab === 'standard' && renderStandardModule()}
      {activeTab === 'factor' && renderFactorModule()}
    </div>
  )
}
