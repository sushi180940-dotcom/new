import { useState, useMemo } from 'react'
import ReactEChartsCore from 'echarts-for-react'
import AnalysisAllocationPage from './AnalysisAllocationPage'

// 福建地区三级联动数据
const regionData = [
  { city: '福州市', districts: ['鼓楼区','台江区','仓山区','晋安区','马尾区','长乐区','福清市','闽侯县','连江县','罗源县','闽清县','永泰县'] },
  { city: '厦门市', districts: ['思明区','湖里区','集美区','海沧区','同安区','翔安区'] },
  { city: '莆田市', districts: ['城厢区','涵江区','荔城区','秀屿区','仙游县'] },
  { city: '三明市', districts: ['三元区','沙县区','永安市','明溪县','清流县','宁化县','大田县','尤溪县','将乐县','泰宁县','建宁县'] },
  { city: '泉州市', districts: ['鲤城区','丰泽区','洛江区','泉港区','石狮市','晋江市','南安市','惠安县','安溪县','永春县','德化县'] },
  { city: '漳州市', districts: ['芗城区','龙文区','龙海区','长泰区','漳浦县','云霄县','诏安县','东山县','平和县','南靖县','华安县'] },
  { city: '南平市', districts: ['延平区','建阳区','邵武市','武夷山市','建瓯市','顺昌县','浦城县','光泽县','松溪县','政和县'] },
  { city: '龙岩市', districts: ['新罗区','永定区','漳平市','长汀县','上杭县','武平县','连城县'] },
  { city: '宁德市', districts: ['蕉城区','福安市','福鼎市','霞浦县','古田县','屏南县','寿宁县','周宁县','柘荣县'] },
]

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

type SubModule = 'model' | 'purchase' | 'allocation' | 'aftersales' | 'supplier' | 'quality' | 'distribution'

const navItems: { key: SubModule; label: string; icon: string }[] = [
  { key: 'model', label: '数据模型管理', icon: 'M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-4a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10' },
  { key: 'purchase', label: '采购研判分析', icon: 'M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z' },
  { key: 'allocation', label: '配备研判分析', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z' },
  { key: 'aftersales', label: '售后研判分析', icon: 'M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 9.192l-3.536 3.536M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-5 0a4 4 0 11-8 0 4 4 0 018 0z' },
  { key: 'supplier', label: '供应商能力分析', icon: 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z' },
  { key: 'quality', label: '装备质量分析', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
  { key: 'distribution', label: '装备分布分析', icon: 'M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064' },
]

/* ================================================================ */
export default function AnalysisPage({ activeSubTab, onNavigate }: Props) {
  const [activeSub, setActiveSub] = useState<SubModule>((activeSubTab as SubModule) || 'purchase')

  const renderContent = () => {
    switch (activeSub) {
      case 'model': return <DataModelManager onNavigate={onNavigate} />
      case 'purchase': return <PurchaseAnalysis onNavigate={onNavigate} />
      case 'allocation': return <AnalysisAllocationPage onNavigate={onNavigate} />
      case 'aftersales': return <AftersalesAnalysis onNavigate={onNavigate} />
      case 'supplier': return <SupplierAnalysis onNavigate={onNavigate} />
      case 'quality': return <QualityAnalysis onNavigate={onNavigate} />
      case 'distribution': return <DistributionAnalysis onNavigate={onNavigate} />
      default: return <PurchaseAnalysis onNavigate={onNavigate} />
    }
  }

  return (
    <div className="h-full overflow-auto" style={{ minHeight: 'calc(100vh - 48px)', background: 'var(--bg-primary)' }}>
      {/* Top tab nav */}
      <div className="sticky top-0 z-30 bg-white border-b px-4" style={{ borderColor: 'var(--border-color)' }}>
        <div className="flex gap-1 overflow-x-auto">
          {navItems.map(item => (
            <button
              key={item.key}
              onClick={() => setActiveSub(item.key)}
              className={`relative flex items-center gap-1.5 px-4 py-3 text-sm transition-all whitespace-nowrap ${activeSub === item.key ? 'font-medium' : 'hover:text-blue-600'}`}
              style={{
                color: activeSub === item.key ? 'var(--primary-blue)' : 'var(--text-secondary)',
                borderBottom: activeSub === item.key ? '2px solid var(--primary-blue)' : '2px solid transparent',
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={item.icon}/>
              </svg>
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      {renderContent()}
    </div>
  )
}

/* ================================================================
   系统可用数据字段（用于公式编辑）
   ================================================================ */
const months = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']

const sysDataFields = [
  { category: '库存数据', fields: ['库存总量', '在库数量', '在用数量', '待修数量', '待报废数量', '调拨中数量'] },
  { category: '采购数据', fields: ['采购金额', '采购数量', '采购单价', '交付周期', '供应商数量'] },
  { category: '配备数据', fields: ['应配数量', '实配数量', '配备率', '缺口数量', '缺口率', '使用率'] },
  { category: '质量数据', fields: ['故障率', '报废率', '平均无故障时间', '维修次数', '投诉次数'] },
  { category: '售后数据', fields: ['报修数量', '维修周期', '售后响应时间', '满意度评分'] },
  { category: '组织数据', fields: ['人员编制', '在岗人数', '部门数量', '基层单位数'] },
]

// 图表类型选项
type ChartType = 'pie' | 'bar' | 'line' | 'area' | 'radar' | 'table' | 'stat' | 'dualAxis' | 'scatter' | 'horizontalBar'

const chartTypeOptions: { value: ChartType; label: string; desc: string }[] = [
  { value: 'pie', label: '饼图', desc: '占比分布' },
  { value: 'bar', label: '柱状图', desc: '数量对比' },
  { value: 'horizontalBar', label: '横向柱状图', desc: '排名对比' },
  { value: 'line', label: '折线图', desc: '趋势变化' },
  { value: 'area', label: '面积图', desc: '累积趋势' },
  { value: 'dualAxis', label: '双轴图', desc: '多指标对比' },
  { value: 'radar', label: '雷达图', desc: '能力评估' },
  { value: 'scatter', label: '散点图', desc: '分布关系' },
  { value: 'table', label: '数据表格', desc: '明细展示' },
  { value: 'stat', label: '统计卡片', desc: '关键数字' },
]

interface LayoutGroup {
  id: string
  title: string
  chartType: ChartType
  indicators: string[]
  order: number
  colSpan: 1 | 2 | 3
}

interface CustomIndicator {
  id: string
  name: string
  formula: string
  formulaDisplay: string
}

/* ================================================================
   10.1 数据模型管理 - 支持自定义指标公式 + 页面布局配置
   ================================================================ */
interface DataModel {
  id: string
  name: string
  creator: string
  createTime: string
  dimensions: string[]
  indicators: string[]
  customIndicators: CustomIndicator[]
  layoutGroups: LayoutGroup[]
  shareScope: string
}

// 根据指标名称智能推荐图表类型
function recommendChartType(indicator: string): ChartType {
  if (indicator.includes('率') || indicator.includes('占比') || indicator.includes('百分比')) {
    return 'pie'
  }
  if (indicator.includes('评分') || indicator.includes('指数')) {
    return 'radar'
  }
  if (indicator.includes('趋势') || indicator.includes('金额') || indicator.includes('总量')) {
    return 'line'
  }
  if (indicator.includes('数') || indicator.includes('量') || indicator.includes('件') || indicator.includes('次')) {
    return 'bar'
  }
  if (indicator.includes('时间') || indicator.includes('周期') || indicator.includes('天数')) {
    return 'horizontalBar'
  }
  return 'bar'
}

// 根据已选指标自动生成推荐的布局分组
function autoLayoutGroups(indicators: string[], customIndicators: CustomIndicator[]): LayoutGroup[] {
  // 按语义将指标分类到不同分组
  const groupDefs: { title: string; keywords: string[]; chartType: ChartType; colSpan: 1 | 2 | 3 }[] = [
    { title: '库存概览', keywords: ['库存', '在库', '金额', '周转', '预警'], chartType: 'stat', colSpan: 3 },
    { title: '使用效能', keywords: ['使用率', '利用', '闲置', '人均', '配备'], chartType: 'stat', colSpan: 3 },
    { title: '运维保障', keywords: ['报修', '完好', '维修', '售后', '满意度'], chartType: 'stat', colSpan: 3 },
    { title: '流转效率', keywords: ['入库', '出库', '调拨', '交付', '响应'], chartType: 'dualAxis', colSpan: 2 },
    { title: '质量分析', keywords: ['故障', '报废', 'MTBF', '质量'], chartType: 'dualAxis', colSpan: 2 },
    { title: '分布构成', keywords: ['分布', '状态', '品类', '区域', '岗位'], chartType: 'pie', colSpan: 1 },
    { title: '供应商评估', keywords: ['供应商', '评分', '及时率'], chartType: 'radar', colSpan: 2 },
    { title: '采购分析', keywords: ['采购', '预算', '周期'], chartType: 'area', colSpan: 2 },
    { title: '配备缺口', keywords: ['缺口', '达标', '应配', '实配'], chartType: 'bar', colSpan: 2 },
  ]

  const used = new Set<string>()
  const groups: LayoutGroup[] = []
  let order = 0

  for (const gd of groupDefs) {
    const matched = indicators.filter(ind => {
      if (used.has(ind)) return false
      return gd.keywords.some(kw => ind.includes(kw))
    })
    if (matched.length > 0) {
      matched.forEach(m => used.add(m))
      const allInds = [...matched]
      // 自定义指标也匹配
      const matchedCustom = customIndicators.filter(ci =>
        gd.keywords.some(kw => ci.name.includes(kw))
      )
      matchedCustom.forEach(mc => {
        if (!allInds.includes(mc.name)) allInds.push(mc.name)
      })
      groups.push({
        id: `lg-${order}`,
        title: gd.title,
        chartType: allInds.length >= 2 && gd.chartType === 'stat' ? 'dualAxis' : gd.chartType,
        indicators: allInds,
        order,
        colSpan: gd.colSpan,
      })
      order++
    }
  }

  // 剩余未分类的指标放入"其他指标"组
  const remaining = indicators.filter(ind => !used.has(ind))
  if (remaining.length > 0) {
    groups.push({
      id: `lg-${order}`,
      title: '其他指标',
      chartType: remaining.length >= 3 ? 'bar' : 'stat',
      indicators: remaining,
      order,
      colSpan: 2,
    })
  }

  return groups
}

const initialModels: DataModel[] = [
  { id: 'M001', name: '采购研判分析模型', creator: 'admin', createTime: '2024-03-15 09:30:00', dimensions: ['时间', '装备类别', '供应商', '装备状态', '警种'], indicators: ['平均采购周期', '入库及时率', '出库响应时间', '库存呆滞率', '装备总库存', '库存金额', '库存周转率', '库存预警项', '装备平均使用率', '人均配备数', '装备利用率', '闲置装备占比', '平均报修率', '装备完好率', '平均维修时间', '售后满意度', '采购金额', '预算金额'], customIndicators: [{ id: 'c1', name: '采购及时率', formula: '及时入库数/总采购数*100', formulaDisplay: '及时入库数 ÷ 总采购数 × 100' }], layoutGroups: [{ id: 'lg-0', title: '库存概览', chartType: 'stat', indicators: ['装备总库存', '库存金额', '库存周转率', '库存预警项'], order: 0, colSpan: 3 }, { id: 'lg-1', title: '使用效能', chartType: 'stat', indicators: ['装备平均使用率', '人均配备数', '装备利用率', '闲置装备占比'], order: 1, colSpan: 3 }, { id: 'lg-2', title: '运维保障', chartType: 'stat', indicators: ['平均报修率', '装备完好率', '平均维修时间', '售后满意度'], order: 2, colSpan: 3 }, { id: 'lg-3', title: '流转效率', chartType: 'dualAxis', indicators: ['平均采购周期', '入库及时率', '出库响应时间', '库存呆滞率'], order: 3, colSpan: 2 }, { id: 'lg-4', title: '采购分析', chartType: 'area', indicators: ['采购金额', '预算金额', '采购及时率'], order: 4, colSpan: 2 }], shareScope: '全局共享' },
  { id: 'M002', name: '配备研判分析模型', creator: 'admin', createTime: '2024-04-20 14:00:00', dimensions: ['单位', '岗位', '装备类型', '装备品类', '故障类型'], indicators: ['装备平均使用率', '人均配备数', '装备利用率', '闲置装备占比', '应配数量', '实配数量', '配备率', '缺口数量', '缺口率', '装备总库存', '库存金额', '年入库总量', '年出库总量', '年调拨总量', '库存周转率', '年报修总数', '年报废总数', '平均故障率', '平均报废率', '装备完好率', '维修及时率', '平均维修时间', '售后满意度', '配备缺口总数', '调拨完成率', '平均调拨响应时间', '配备达标率'], customIndicators: [{ id: 'c2', name: '配备率', formula: '实配数量/应配数量*100', formulaDisplay: '实配数量 ÷ 应配数量 × 100' }, { id: 'c3', name: '缺口率', formula: '(应配数量-实配数量)/应配数量*100', formulaDisplay: '(应配数量 - 实配数量) ÷ 应配数量 × 100' }], layoutGroups: [{ id: 'lg-0', title: '装备储备', chartType: 'stat', indicators: ['装备总库存', '库存金额', '在用装备', '覆盖单位', '品类数量'], order: 0, colSpan: 3 }, { id: 'lg-1', title: '流转频次', chartType: 'stat', indicators: ['年入库总量', '年出库总量', '年调拨总量', '库存周转率'], order: 1, colSpan: 3 }, { id: 'lg-2', title: '损耗情况', chartType: 'stat', indicators: ['年报修总数', '年报废总数', '平均故障率', '平均报废率'], order: 2, colSpan: 3 }, { id: 'lg-3', title: '维保质量', chartType: 'stat', indicators: ['装备完好率', '维修及时率', '平均维修时间', '售后满意度'], order: 3, colSpan: 3 }, { id: 'lg-4', title: '资源调配', chartType: 'stat', indicators: ['配备缺口总数', '调拨完成率', '平均调拨响应时间', '配备达标率'], order: 4, colSpan: 3 }, { id: 'lg-5', title: '配备缺口分析', chartType: 'bar', indicators: ['应配数量', '实配数量', '配备率', '缺口数量', '缺口率', '配备达标率'], order: 5, colSpan: 2 }], shareScope: '全局共享' },
  { id: 'M003', name: '售后研判分析模型', creator: 'admin', createTime: '2024-05-10 10:15:00', dimensions: ['供应商', '装备类别', '时间', '故障类型'], indicators: ['年度报修总数', '平均维修时间', '投诉率', '售后满意度', '报废次数'], customIndicators: [{ id: 'c5', name: '售后效率指数', formula: '满意度评分/报修数量', formulaDisplay: '满意度评分 ÷ 报修数量' }], layoutGroups: [{ id: 'lg-0', title: '售后概览', chartType: 'stat', indicators: ['年度报修总数', '平均维修时间', '投诉率', '售后满意度'], order: 0, colSpan: 3 }, { id: 'lg-1', title: '售后趋势', chartType: 'dualAxis', indicators: ['年度报修总数', '投诉率', '报废次数', '售后效率指数'], order: 1, colSpan: 2 }, { id: 'lg-2', title: '故障类型分布', chartType: 'pie', indicators: ['故障类型'], order: 2, colSpan: 1 }], shareScope: '全局共享' },
  { id: 'M004', name: '供应商能力分析模型', creator: 'admin', createTime: '2024-06-01 11:00:00', dimensions: ['供应商', '时间'], indicators: ['供货质量评分', '交付及时率', '售后响应评分', '价格竞争力评分', '技术能力评分', '合作配合度评分'], customIndicators: [{ id: 'c4', name: '综合评分', formula: '(供货质量+交付及时率+售后响应+价格竞争力+技术能力+合作配合度)/6', formulaDisplay: '(供货质量 + 交付及时率 + 售后响应 + 价格竞争力 + 技术能力 + 合作配合度) ÷ 6' }], layoutGroups: [{ id: 'lg-0', title: '供应商能力雷达', chartType: 'radar', indicators: ['供货质量评分', '交付及时率', '售后响应评分', '价格竞争力评分', '技术能力评分', '合作配合度评分', '综合评分'], order: 0, colSpan: 2 }, { id: 'lg-1', title: '综合评分排名', chartType: 'table', indicators: ['综合评分'], order: 1, colSpan: 1 }], shareScope: '省厅共享' },
  { id: 'M005', name: '装备质量分析模型', creator: 'admin', createTime: '2024-06-15 08:30:00', dimensions: ['装备品类', '供应商', '时间'], indicators: ['平均故障率', '平均MTBF', '平均报废率', '质量预警'], customIndicators: [{ id: 'c6', name: '质量指数', formula: 'MTBF/(故障率+1)', formulaDisplay: 'MTBF ÷ (故障率 + 1)' }], layoutGroups: [{ id: 'lg-0', title: '质量概览', chartType: 'stat', indicators: ['平均故障率', '平均MTBF', '平均报废率', '质量预警'], order: 0, colSpan: 3 }, { id: 'lg-1', title: '质量分析', chartType: 'dualAxis', indicators: ['平均故障率', '平均MTBF', '平均报废率', '质量指数'], order: 1, colSpan: 2 }], shareScope: '全局共享' },
  { id: 'M006', name: '装备分布分析模型', creator: 'admin', createTime: '2024-07-01 16:00:00', dimensions: ['区域', '岗位', '装备品种'], indicators: ['装备总数', '覆盖区域', '平均密度'], customIndicators: [{ id: 'c7', name: '分布均衡指数', formula: '标准差/平均值', formulaDisplay: '标准差 ÷ 平均值' }], layoutGroups: [{ id: 'lg-0', title: '分布概览', chartType: 'stat', indicators: ['装备总数', '覆盖区域', '平均密度'], order: 0, colSpan: 3 }, { id: 'lg-1', title: '区域分布', chartType: 'bar', indicators: ['装备总数', '分布均衡指数'], order: 1, colSpan: 2 }], shareScope: '省厅共享' },
]

const dimensionOptions = ['时间', '供应商', '装备类别', '装备类型', '单位', '岗位', '区域', '装备品种', '装备状态', '警种', '故障类型']
const indicatorOptions = ['平均采购周期', '入库及时率', '出库响应时间', '库存呆滞率', '及时入库数', '总采购数', '装备总库存', '库存金额', '库存周转率', '库存预警项', '装备平均使用率', '人均配备数', '装备利用率', '闲置装备占比', '平均报修率', '装备完好率', '平均维修时间', '售后满意度', '采购金额', '预算金额', '应配数量', '实配数量', '配备率', '缺口数量', '缺口率', '年入库总量', '年出库总量', '年调拨总量', '年报修总数', '年报废总数', '平均故障率', '平均报废率', '维修及时率', '配备缺口总数', '调拨完成率', '平均调拨响应时间', '配备达标率', '年度报修总数', '投诉率', '报废次数', '供货质量评分', '交付及时率', '售后响应评分', '价格竞争力评分', '技术能力评分', '合作配合度评分', '平均MTBF', '质量预警', '装备总数', '覆盖区域', '平均密度', '标准差', '平均值', '故障率', 'MTBF']

/* ================================================================
   系统指标公式映射（hover 显示）
   ================================================================ */
const indicatorFormulaMap: Record<string, string> = {
  '平均采购周期': '∑(交付日期 - 下单日期) ÷ 采购批次',
  '入库及时率': '及时入库数 ÷ 总采购数 × 100%',
  '出库响应时间': '出库确认时间 - 申请提交时间',
  '库存呆滞率': '呆滞品数量 ÷ 库存总量 × 100%',
  '及时入库数': '实际到货日期 ≤ 约定交货日期的入库数',
  '总采购数': '统计周期内所有采购订单数量合计',
  '装备总库存': '在库数量 + 在用数量 + 待修数量 + 调拨中数量',
  '库存金额': '∑(各装备单价 × 库存数量)',
  '库存周转率': '年出库总量 ÷ 年平均库存',
  '库存预警项': '库存量 < 安全库存的装备品类数',
  '装备平均使用率': '实际使用时长 ÷ 可用时长 × 100%',
  '人均配备数': '装备总数量 ÷ 在编人数',
  '装备利用率': '在用数量 ÷ (在库数量 + 在用数量) × 100%',
  '闲置装备占比': '闲置数量 ÷ 装备总数量 × 100%',
  '平均报修率': '报修次数 ÷ 装备总数 × 100%',
  '装备完好率': '完好装备数 ÷ 装备总数 × 100%',
  '平均维修时间': '∑(维修完成时间 - 报修时间) ÷ 维修次数',
  '售后满意度': '∑满意度评分 ÷ 评价次数',
  '采购金额': '∑(采购单价 × 采购数量)',
  '预算金额': '年度装备采购预算总额',
  '应配数量': '根据编制标准计算的应配备装备数',
  '实配数量': '实际已配备的装备数量',
  '配备率': '实配数量 ÷ 应配数量 × 100%',
  '缺口数量': '应配数量 - 实配数量',
  '缺口率': '(应配数量 - 实配数量) ÷ 应配数量 × 100%',
  '年入库总量': '本年度累计入库装备数量',
  '年出库总量': '本年度累计出库装备数量',
  '年调拨总量': '本年度累计调拨装备数量',
  '年报修总数': '本年度累计报修次数',
  '年报废总数': '本年度累计报废装备数量',
  '平均故障率': '故障次数 ÷ 装备总数 × 100%',
  '平均报废率': '报废数量 ÷ 装备总数 × 100%',
  '维修及时率': '及时维修数 ÷ 总报修数 × 100%',
  '配备缺口总数': '∑(各单位缺口数量)',
  '调拨完成率': '已完成调拨数 ÷ 总调拨数 × 100%',
  '平均调拨响应时间': '∑(调拨完成时间 - 申请时间) ÷ 调拨次数',
  '配备达标率': '配备率 ≥ 标准的单位数 ÷ 总单位数 × 100%',
  '年度报修总数': '本年度累计报修次数',
  '投诉率': '投诉次数 ÷ 采购总数 × 100%',
  '报废次数': '本年度累计报废次数',
  '供货质量评分': '质量验收合格率 × 40% + 抽检合格率 × 30% + 退货率倒数 × 30%',
  '交付及时率': '按时交付订单数 ÷ 总订单数 × 100%',
  '售后响应评分': '∑(响应时间评分) ÷ 评价次数',
  '价格竞争力评分': '市场均价 ÷ 供应商报价 × 100',
  '技术能力评分': '专家评审打分平均分',
  '合作配合度评分': '∑(配合度评价) ÷ 评价次数',
  '平均MTBF': '∑(故障间隔时间) ÷ 故障次数',
  '质量预警': '故障率 > 阈值 或 MTBF < 阈值 的装备数',
  '装备总数': '∑(在库 + 在用 + 待修 + 调拨中)',
  '覆盖区域': '有装备配备的基层单位数',
  '平均密度': '装备总数 ÷ 覆盖区域数',
  '标准差': '√[∑(Xi - X̄)² ÷ N]',
  '平均值': '∑Xi ÷ N',
  '故障率': '故障次数 ÷ 运行总时长 × 100%',
  'MTBF': '运行总时长 ÷ 故障次数',
}

type SortField = 'id' | 'name' | 'createTime' | 'creator' | null
type SortOrder = 'asc' | 'desc'

type StepKey = 'basic' | 'layout' | 'preview'
const stepList: { key: StepKey; label: string }[] = [
  { key: 'basic', label: '基本信息' },
  { key: 'layout', label: '页面布局' },
  { key: 'preview', label: '预览确认' },
]

function DataModelManager({ onNavigate }: Props) {
  const [models, setModels] = useState<DataModel[]>(initialModels)
  const [searchKw, setSearchKw] = useState('')
  const [sortField, setSortField] = useState<SortField>(null)
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc')
  const [modalOpen, setModalOpen] = useState(false)
  const [editingModel, setEditingModel] = useState<DataModel | null>(null)
  const [formName, setFormName] = useState('')
  const [formDims, setFormDims] = useState<string[]>([])
  const [formInds, setFormInds] = useState<string[]>([])
  const [formShare, setFormShare] = useState('全局共享')
  const [customIndicators, setCustomIndicators] = useState<CustomIndicator[]>([])
  const [formulaEditing, setFormulaEditing] = useState(false)
  const [currentFormula, setCurrentFormula] = useState('')
  const [currentFormulaDisplay, setCurrentFormulaDisplay] = useState('')
  const [currentIndName, setCurrentIndName] = useState('')
  const [editingCustomId, setEditingCustomId] = useState<string | null>(null)
  const [currentStep, setCurrentStep] = useState<StepKey>('basic')
  const [layoutGroups, setLayoutGroups] = useState<LayoutGroup[]>([])
  const [draggingGroupId, setDraggingGroupId] = useState<string | null>(null)

  const filtered = useMemo(() => {
    let list = models.filter(m => !searchKw || m.name.includes(searchKw) || m.id.includes(searchKw))
    if (sortField) {
      list = [...list].sort((a, b) => {
        let cmp = 0
        if (sortField === 'id') cmp = a.id.localeCompare(b.id)
        else if (sortField === 'name') cmp = a.name.localeCompare(b.name)
        else if (sortField === 'createTime') cmp = a.createTime.localeCompare(b.createTime)
        else if (sortField === 'creator') cmp = a.creator.localeCompare(b.creator)
        return sortOrder === 'asc' ? cmp : -cmp
      })
    }
    return list
  }, [models, searchKw, sortField, sortOrder])

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortOrder('desc')
    }
  }

  const resetForm = () => {
    setEditingModel(null); setFormName(''); setFormDims([]); setFormInds([]); setFormShare('全局共享')
    setCustomIndicators([]); setCurrentFormula(''); setCurrentFormulaDisplay(''); setCurrentIndName(''); setEditingCustomId(null); setFormulaEditing(false)
    setCurrentStep('basic'); setLayoutGroups([])
  }

  const openCreate = () => {
    resetForm()
    setModalOpen(true)
  }

  const openEdit = (m: DataModel) => {
    setEditingModel(m); setFormName(m.name); setFormDims([...m.dimensions]); setFormInds([...m.indicators])
    setFormShare(m.shareScope); setCustomIndicators([...m.customIndicators]); setCurrentFormula(''); setCurrentFormulaDisplay('')
    setCurrentIndName(''); setEditingCustomId(null); setFormulaEditing(false)
    setCurrentStep('basic'); setLayoutGroups(m.layoutGroups ? [...m.layoutGroups] : [])
    setModalOpen(true)
  }

  const addFieldToFormula = (field: string) => { setCurrentFormula(prev => prev + field); setCurrentFormulaDisplay(prev => prev + field) }
  const addOperatorToFormula = (op: string, display: string) => { setCurrentFormula(prev => prev + op); setCurrentFormulaDisplay(prev => prev + display) }

  const saveCustomIndicator = () => {
    if (!currentIndName.trim()) { alert('请输入指标名称'); return }
    if (!currentFormula.trim()) { alert('请输入计算公式'); return }
    if (editingCustomId) {
      setCustomIndicators(prev => prev.map(ci => ci.id === editingCustomId ? { ...ci, name: currentIndName, formula: currentFormula, formulaDisplay: currentFormulaDisplay } : ci))
      setEditingCustomId(null)
    } else {
      setCustomIndicators(prev => [...prev, { id: `ci-${Date.now()}`, name: currentIndName, formula: currentFormula, formulaDisplay: currentFormulaDisplay }])
    }
    setCurrentIndName(''); setCurrentFormula(''); setCurrentFormulaDisplay(''); setFormulaEditing(false)
  }

  const editCustomIndicator = (ci: CustomIndicator) => {
    setCurrentIndName(ci.name); setCurrentFormula(ci.formula); setCurrentFormulaDisplay(ci.formulaDisplay || ci.formula)
    setEditingCustomId(ci.id); setFormulaEditing(true)
  }

  const deleteCustomIndicator = (id: string) => { setCustomIndicators(prev => prev.filter(ci => ci.id !== id)) }

  const handleSave = () => {
    if (!formName.trim()) { alert('请输入模型名称'); return }
    if (formDims.length === 0) { alert('请至少选择一个维度'); return }
    if (formInds.length === 0 && customIndicators.length === 0) { alert('请至少选择一个指标或定义一个自定义指标'); return }
    const finalLayout = layoutGroups.length > 0 ? layoutGroups : autoLayoutGroups(formInds, customIndicators)
    if (editingModel) {
      setModels(prev => prev.map(m => m.id === editingModel.id ? { ...m, name: formName, dimensions: formDims, indicators: formInds, customIndicators, layoutGroups: finalLayout, shareScope: formShare } : m))
    } else {
      const newId = `M${String(models.length + 1).padStart(3, '0')}`
      setModels(prev => [{ id: newId, name: formName, creator: '当前用户', createTime: new Date().toLocaleString('zh-CN', { hour12: false }), dimensions: formDims, indicators: formInds, customIndicators, layoutGroups: finalLayout, shareScope: formShare }, ...prev])
    }
    setModalOpen(false)
  }

  // 步骤切换时自动重新生成布局
  const goToStep = (step: StepKey) => {
    if (step === 'layout' || step === 'preview') {
      if (layoutGroups.length === 0 && (formInds.length > 0 || customIndicators.length > 0)) {
        setLayoutGroups(autoLayoutGroups(formInds, customIndicators))
      }
    }
    setCurrentStep(step)
  }

  // 拖拽排序
  const moveGroup = (fromOrder: number, toOrder: number) => {
    setLayoutGroups(prev => {
      const sorted = [...prev].sort((a, b) => a.order - b.order)
      const [removed] = sorted.splice(fromOrder, 1)
      sorted.splice(toOrder, 0, removed)
      return sorted.map((g, i) => ({ ...g, order: i }))
    })
  }

  // 更新分组图表类型
  const updateGroupChart = (groupId: string, chartType: ChartType) => {
    setLayoutGroups(prev => prev.map(g => g.id === groupId ? { ...g, chartType } : g))
  }

  // 更新分组标题
  const updateGroupTitle = (groupId: string, title: string) => {
    setLayoutGroups(prev => prev.map(g => g.id === groupId ? { ...g, title } : g))
  }

  // 更新分组列宽
  const updateGroupColSpan = (groupId: string, colSpan: 1 | 2 | 3) => {
    setLayoutGroups(prev => prev.map(g => g.id === groupId ? { ...g, colSpan } : g))
  }

  // 删除分组
  const deleteGroup = (groupId: string) => {
    setLayoutGroups(prev => {
      const filtered = prev.filter(g => g.id !== groupId)
      return filtered.map((g, i) => ({ ...g, order: i }))
    })
  }

  // 添加新分组
  const addGroup = () => {
    setLayoutGroups(prev => {
      const newGroup: LayoutGroup = {
        id: `lg-${Date.now()}`,
        title: '新建分组',
        chartType: 'stat',
        indicators: [],
        order: prev.length,
        colSpan: 2,
      }
      return [...prev, newGroup]
    })
  }

  // 将指标分配给分组
  const assignIndicatorToGroup = (indicator: string, groupId: string) => {
    setLayoutGroups(prev => prev.map(g => {
      // 先从其他分组移除
      if (g.id !== groupId && g.indicators.includes(indicator)) {
        return { ...g, indicators: g.indicators.filter(ind => ind !== indicator) }
      }
      // 添加到目标分组
      if (g.id === groupId && !g.indicators.includes(indicator)) {
        return { ...g, indicators: [...g.indicators, indicator] }
      }
      return g
    }))
  }

  const handleDelete = (id: string) => { if (confirm('确定删除该模型吗？')) setModels(prev => prev.filter(m => m.id !== id)) }

  return (
    <div className="p-6 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold" style={{ color: 'var(--text-primary)' }}>数据模型管理</h1>
        <input className="form-input w-48 text-sm" placeholder="搜索模型名称" value={searchKw} onChange={e => setSearchKw(e.target.value)} />
      </div>
      <div className="flex items-center justify-between">
        <button className="btn-primary text-sm flex items-center gap-1" onClick={openCreate}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新建模型
        </button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {filtered.length} 个模型</span>
      </div>
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => toggleSort('id')}>
                <span className="inline-flex items-center gap-1">模型ID {sortField === 'id' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={sortOrder === 'asc' ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'}/></svg>}</span>
              </th>
              <th className="cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => toggleSort('name')}>
                <span className="inline-flex items-center gap-1">模型名称 {sortField === 'name' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={sortOrder === 'asc' ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'}/></svg>}</span>
              </th>
              <th>维度字段</th>
              <th>系统指标</th>
              <th>自定义指标(公式)</th>
              <th>共享范围</th>
              <th className="cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => toggleSort('creator')}>
                <span className="inline-flex items-center gap-1">创建人 {sortField === 'creator' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={sortOrder === 'asc' ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'}/></svg>}</span>
              </th>
              <th className="cursor-pointer select-none hover:bg-gray-100 transition-colors" onClick={() => toggleSort('createTime')}>
                <span className="inline-flex items-center gap-1">创建时间 {sortField === 'createTime' && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d={sortOrder === 'asc' ? 'M18 15l-6-6-6 6' : 'M6 9l6 6 6-6'}/></svg>}</span>
              </th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(m => (
              <tr key={m.id}>
                <td className="font-mono text-xs font-medium">{m.id}</td>
                <td className="font-medium text-sm">{m.name}</td>
                <td>{m.dimensions.map(d => <span key={d} className="inline-block px-1.5 py-0.5 rounded text-xs mr-1" style={{ background: '#e6f4ff', color: '#1890ff' }}>{d}</span>)}</td>
                <td>{m.indicators.map(i => <span key={i} className="inline-block px-1.5 py-0.5 rounded text-xs mr-1" style={{ background: '#f6ffed', color: '#52c41a' }}>{i}</span>)}</td>
                <td>
                  {m.customIndicators.length > 0 ? m.customIndicators.map(ci => (
                    <div key={ci.id} className="text-xs mb-0.5">
                      <span className="font-medium" style={{ color: '#722ed1' }}>{ci.name}</span>
                      <span style={{ color: 'var(--text-secondary)' }}> = {ci.formulaDisplay || ci.formula}</span>
                    </div>
                  )) : <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>}
                </td>
                <td><span className="tag text-xs" style={{ background: m.shareScope === '全局共享' ? '#e6f4ff' : '#f6ffed', color: m.shareScope === '全局共享' ? '#1890ff' : '#52c41a' }}>{m.shareScope}</span></td>
                <td className="text-xs">{m.creator}</td>
                <td className="text-xs">{m.createTime}</td>
                <td>
                  <div className="flex gap-2">
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openEdit(m)}>编辑</button>
                    <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDelete(m.id)}>删除</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setModalOpen(false); resetForm(); }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{editingModel ? '编辑模型' : '新建模型'}</h3>
              <button onClick={() => { setModalOpen(false); resetForm(); }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* 步骤条 */}
            <div className="px-6 pt-4 pb-2">
              <div className="flex items-center gap-0">
                {stepList.map((s, i) => (
                  <div key={s.key} className="flex items-center flex-1">
                    <button
                      onClick={() => {
                        if (s.key === 'layout' && formInds.length === 0 && customIndicators.length === 0) return
                        if (s.key === 'preview' && (formInds.length === 0 || layoutGroups.length === 0)) return
                        goToStep(s.key)
                      }}
                      className={`flex items-center gap-2 text-sm transition-all ${currentStep === s.key ? 'font-medium' : ''}`}
                      style={{ color: currentStep === s.key ? 'var(--primary-blue)' : currentStep === 'preview' || (currentStep === 'layout' && s.key === 'preview') ? 'var(--text-secondary)' : 'var(--text-secondary)' }}
                    >
                      <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-medium ${currentStep === s.key ? 'text-white' : (currentStep === 'layout' && s.key === 'basic') || (currentStep === 'preview' && (s.key === 'basic' || s.key === 'layout')) ? 'text-white' : ''}`}
                        style={{ background: currentStep === s.key ? 'var(--primary-blue)' : (currentStep === 'layout' && s.key === 'basic') || (currentStep === 'preview') ? '#52c41a' : '#d9d9d9' }}>
                        {(currentStep === 'layout' && s.key === 'basic') || (currentStep === 'preview' && (s.key === 'basic' || s.key === 'layout')) ? (
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                        ) : (
                          i + 1
                        )}
                      </span>
                      <span>{s.label}</span>
                    </button>
                    {i < stepList.length - 1 && (
                      <div className="flex-1 h-px mx-3" style={{ background: currentStep === 'preview' ? '#52c41a' : '#d9d9d9' }} />
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* ========== 步骤1：基本信息 ========== */}
              {currentStep === 'basic' && (
                <div className="space-y-5">
                  <div>
                    <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-primary)' }}>模型名称 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入模型名称" value={formName} onChange={e => setFormName(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-primary)' }}>维度字段 <span className="text-red-400">*</span></label>
                    <div className="flex flex-wrap gap-2">
                      {dimensionOptions.map(d => (
                        <button key={d} onClick={() => setFormDims(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d])}
                          className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${formDims.includes(d) ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-gray-200 hover:border-gray-300'}`}>{d}</button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-primary)' }}>系统指标 <span style={{ color: 'var(--text-disabled)' }}>(鼠标悬停查看计算公式)</span></label>
                    <div className="flex flex-wrap gap-2">
                      {indicatorOptions.map(i => {
                        const formula = indicatorFormulaMap[i]
                        return (
                          <div key={i} className="relative group">
                            <button onClick={() => setFormInds(prev => prev.includes(i) ? prev.filter(x => x !== i) : [...prev, i])}
                              className={`px-3 py-1.5 text-xs rounded-lg border transition-all ${formInds.includes(i) ? 'border-green-500 bg-green-50 text-green-700' : 'border-gray-200 hover:border-gray-300'}`}>{i}</button>
                            {formula && (
                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 rounded-lg text-xs whitespace-nowrap z-[70] opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                                style={{ background: '#1a1a2e', color: '#fff' }}>
                                <div className="font-medium mb-0.5" style={{ color: '#7ee787' }}>{i}</div>
                                <div style={{ color: '#d4d4d8' }}>{formula}</div>
                                <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px"
                                  style={{ width: 0, height: 0, borderLeft: '5px solid transparent', borderRight: '5px solid transparent', borderTop: '5px solid #1a1a2e' }} />
                              </div>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>自定义指标（公式）</label>
                      <button className="text-xs flex items-center gap-1" style={{ color: 'var(--primary-blue)' }} onClick={() => { setFormulaEditing(true); setCurrentIndName(''); setCurrentFormula(''); setCurrentFormulaDisplay(''); setEditingCustomId(null); }}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>添加自定义指标
                      </button>
                    </div>
                    {customIndicators.length > 0 && (
                      <div className="space-y-2 mb-4">
                        {customIndicators.map(ci => (
                          <div key={ci.id} className="flex items-center justify-between px-3 py-2 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                            <div className="flex items-center gap-3">
                              <span className="text-xs font-medium" style={{ color: '#722ed1' }}>{ci.name}</span>
                              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>= {ci.formulaDisplay || ci.formula}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => editCustomIndicator(ci)}>编辑</button>
                              <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => deleteCustomIndicator(ci.id)}>删除</button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    {formulaEditing && (
                      <div className="border rounded-lg p-4 space-y-3" style={{ borderColor: 'var(--border-color)' }}>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs mb-1">指标名称 <span className="text-red-400">*</span></label>
                            <input className="form-input w-full text-sm" placeholder="如：配备率、综合评分" value={currentIndName} onChange={e => setCurrentIndName(e.target.value)} />
                          </div>
                          <div>
                            <label className="block text-xs mb-1">公式预览</label>
                            <div className="form-input w-full text-sm flex items-center min-h-[32px]" style={{ background: '#f5f5f5' }}>
                              <span className="font-mono text-xs" style={{ color: currentFormulaDisplay ? 'var(--text-primary)' : '#999' }}>{currentFormulaDisplay || '点击左侧字段和运算符构建公式...'}</span>
                            </div>
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs mb-2 font-medium">系统数据字段（点击添加）</label>
                          <div className="grid grid-cols-3 gap-2">
                            {sysDataFields.map(cat => (
                              <div key={cat.category} className="border rounded p-2" style={{ borderColor: '#e8e8e8' }}>
                                <div className="text-[11px] font-medium mb-1.5" style={{ color: 'var(--text-secondary)' }}>{cat.category}</div>
                                <div className="flex flex-wrap gap-1">
                                  {cat.fields.map(f => (
                                    <button key={f} onClick={() => addFieldToFormula(f)} className="text-[11px] px-2 py-0.5 rounded bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors">{f}</button>
                                  ))}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                        <div>
                          <label className="block text-xs mb-2 font-medium">运算符（点击添加）</label>
                          <div className="flex flex-wrap gap-2">
                            {[{ op: '+', display: ' + ' }, { op: '-', display: ' - ' }, { op: '*', display: ' × ' }, { op: '/', display: ' ÷ ' }, { op: '(', display: '(' }, { op: ')', display: ')' }, { op: '100', display: '100' }].map(item => (
                              <button key={item.op} onClick={() => addOperatorToFormula(item.op, item.display)} className="w-8 h-8 rounded-lg border flex items-center justify-center text-sm font-mono hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>{item.display.trim()}</button>
                            ))}
                            <button onClick={() => { setCurrentFormula(''); setCurrentFormulaDisplay(''); }} className="px-3 h-8 rounded-lg border flex items-center text-xs hover:bg-red-50 transition-colors" style={{ borderColor: 'var(--border-color)', color: '#ff4d4f' }}>清空</button>
                            <button onClick={() => { setCurrentFormula(prev => prev.slice(0, -1)); setCurrentFormulaDisplay(prev => prev.slice(0, -1)); }} className="px-3 h-8 rounded-lg border flex items-center text-xs hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>←退格</button>
                          </div>
                        </div>
                        <div className="flex items-center justify-end gap-2 pt-2">
                          <button className="btn-default text-xs px-3 py-1.5" onClick={() => { setFormulaEditing(false); setCurrentIndName(''); setCurrentFormula(''); setCurrentFormulaDisplay(''); setEditingCustomId(null); }}>取消</button>
                          <button className="btn-primary text-xs px-3 py-1.5" onClick={saveCustomIndicator}>保存指标</button>
                        </div>
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-primary)' }}>共享范围</label>
                    <select className="form-input w-full text-sm" value={formShare} onChange={e => setFormShare(e.target.value)}>
                      <option>全局共享</option><option>省厅共享</option><option>仅本人</option>
                    </select>
                  </div>
                </div>
              )}

              {/* ========== 步骤2：页面布局配置 ========== */}
              {currentStep === 'layout' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium">输出页面布局配置</h4>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>系统已根据指标自动推荐布局，您可以调整分组、图表类型和排序</p>
                    </div>
                    <button className="btn-primary text-xs px-3 py-1.5" onClick={addGroup}>
                      <span className="inline-flex items-center gap-1"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>添加分组</span>
                    </button>
                  </div>

                  {/* 布局分组列表 */}
                  <div className="space-y-3">
                    {[...layoutGroups].sort((a, b) => a.order - b.order).map((group, idx) => (
                      <div
                        key={group.id}
                        className="border rounded-lg overflow-hidden"
                        style={{ borderColor: draggingGroupId === group.id ? 'var(--primary-blue)' : 'var(--border-color)' }}
                        draggable
                        onDragStart={() => setDraggingGroupId(group.id)}
                        onDragEnd={() => setDraggingGroupId(null)}
                        onDragOver={e => e.preventDefault()}
                        onDrop={() => { if (draggingGroupId && draggingGroupId !== group.id) { moveGroup(layoutGroups.findIndex(g => g.id === draggingGroupId), idx); setDraggingGroupId(null); } }}
                      >
                        <div className="flex items-center gap-3 px-4 py-3" style={{ background: '#fafafa' }}>
                          {/* 拖拽手柄 */}
                          <div className="cursor-move p-1 rounded hover:bg-gray-200" title="拖拽调整顺序">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#999" strokeWidth="2"><circle cx="9" cy="6" r="1.5"/><circle cx="9" cy="12" r="1.5"/><circle cx="9" cy="18" r="1.5"/><circle cx="15" cy="6" r="1.5"/><circle cx="15" cy="12" r="1.5"/><circle cx="15" cy="18" r="1.5"/></svg>
                          </div>
                          {/* 分组标题 */}
                          <input
                            className="form-input text-sm font-medium flex-1"
                            style={{ background: 'white', minWidth: 120 }}
                            value={group.title}
                            onChange={e => updateGroupTitle(group.id, e.target.value)}
                          />
                          {/* 图表类型选择 */}
                          <select
                            className="form-input text-xs w-36"
                            value={group.chartType}
                            onChange={e => updateGroupChart(group.id, e.target.value as ChartType)}
                          >
                            {chartTypeOptions.map(ct => (
                              <option key={ct.value} value={ct.value}>{ct.label} — {ct.desc}</option>
                            ))}
                          </select>
                          {/* 列宽选择 */}
                          <select
                            className="form-input text-xs w-24"
                            value={group.colSpan}
                            onChange={e => updateGroupColSpan(group.id, Number(e.target.value) as 1 | 2 | 3)}
                          >
                            <option value={1}>半宽</option>
                            <option value={2}>全宽</option>
                            <option value={3}>1/3宽</option>
                          </select>
                          {/* 删除按钮 */}
                          <button className="p-1 rounded hover:bg-red-50" onClick={() => deleteGroup(group.id)} title="删除分组">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
                          </button>
                        </div>
                        {/* 指标分配 */}
                        <div className="px-4 py-3">
                          <div className="flex flex-wrap gap-1.5">
                            {[...formInds, ...customIndicators.map(ci => ci.name)].map(ind => {
                              const isInGroup = group.indicators.includes(ind)
                              return (
                                <button
                                  key={ind}
                                  onClick={() => assignIndicatorToGroup(ind, group.id)}
                                  className={`text-[11px] px-2 py-0.5 rounded border transition-all ${isInGroup ? 'border-blue-400 bg-blue-50 text-blue-700' : 'border-gray-200 text-gray-400 hover:border-gray-300 hover:text-gray-600'}`}
                                  title={isInGroup ? '点击移除' : '点击添加'}
                                >
                                  {ind}
                                </button>
                              )
                            })}
                          </div>
                          {group.indicators.length === 0 && (
                            <p className="text-[11px] mt-2" style={{ color: '#ff4d4f' }}>⚠ 请至少选择一个指标</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {layoutGroups.length === 0 && (
                    <div className="text-center py-8 border rounded-lg" style={{ borderColor: 'var(--border-color)', borderStyle: 'dashed' }}>
                      <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>暂无布局分组</p>
                      <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>请点击「添加分组」或返回上一步选择指标</p>
                    </div>
                  )}
                </div>
              )}

              {/* ========== 步骤3：预览确认 ========== */}
              {currentStep === 'preview' && (
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-medium">页面效果预览</h4>
                    <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>模型输出页面的最终效果如下，确认无误后保存</p>
                  </div>

                  {/* 预览画布 */}
                  <div className="border rounded-lg p-4 space-y-4" style={{ borderColor: 'var(--border-color)', background: '#f8f9fa' }}>
                    {/* 模型信息 */}
                    <div className="flex items-center gap-3 pb-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'var(--primary-blue)' }}>
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
                      </div>
                      <div>
                        <p className="text-sm font-medium">{formName || '未命名模型'}</p>
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{formDims.length}个维度 · {formInds.length + customIndicators.length}个指标 · {layoutGroups.length}个分组</p>
                      </div>
                    </div>

                    {/* 按布局分组渲染预览 */}
                    {[...layoutGroups].sort((a, b) => a.order - b.order).reduce<{ groups: LayoutGroup[][] }>((acc, group) => {
                      if (group.colSpan === 2 || acc.groups.length === 0 || acc.groups[acc.groups.length - 1].reduce((s, g) => s + g.colSpan, 0) + group.colSpan > 2) {
                        acc.groups.push([group])
                      } else {
                        acc.groups[acc.groups.length - 1].push(group)
                      }
                      return acc
                    }, { groups: [] }).groups.map((row, rowIdx) => (
                      <div key={rowIdx} className={`grid gap-3 ${row.reduce((s, g) => s + g.colSpan, 0) <= 2 ? 'grid-cols-' + (row.length === 1 && row[0].colSpan === 2 ? '1' : row.map(() => '1').join('-').replace(/-/g, ' ')) : 'grid-cols-' + row.map(g => g.colSpan).join('-')}`}
                        style={{ gridTemplateColumns: row.map(g => g.colSpan === 2 ? '1fr' : g.colSpan === 1 ? '1fr' : '1fr').join(' ') }}>
                        {row.map(group => (
                          <div key={group.id} className="bg-white rounded-lg p-3 shadow-sm">
                            {/* 分组标题 */}
                            <div className="flex items-center gap-2 mb-3">
                              <div className="w-1 h-4 rounded-full" style={{ background: 'var(--primary-blue)' }} />
                              <span className="text-xs font-medium">{group.title}</span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: '#f0f0f0', color: '#666' }}>
                                {chartTypeOptions.find(ct => ct.value === group.chartType)?.label || group.chartType}
                              </span>
                            </div>
                            {/* 统计卡片预览 */}
                            {group.chartType === 'stat' && (
                              <div className={`grid gap-2 ${group.indicators.length <= 3 ? 'grid-cols-3' : group.indicators.length <= 4 ? 'grid-cols-4' : 'grid-cols-5'}`}>
                                {group.indicators.map((ind, i) => (
                                  <div key={ind} className="text-center p-2 rounded" style={{ background: '#fafafa' }}>
                                    <p className="text-[10px] truncate" style={{ color: 'var(--text-secondary)' }}>{ind}</p>
                                    <p className="text-sm font-bold" style={{ color: ['#1890ff', '#52c41a', '#722ed1', '#faad14', '#ff4d4f', '#13c2c2'][i % 6] }}>
                                      {['78.5%', '4.8件', '82.3%', '8.2%', '2,856万', '5.2次'][i % 6]}
                                    </p>
                                  </div>
                                ))}
                              </div>
                            )}
                            {/* 图表占位预览 */}
                            {group.chartType !== 'stat' && (
                              <div className="flex items-center justify-center rounded" style={{ height: 180, background: '#fafafa' }}>
                                <div className="text-center">
                                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-2">
                                    {group.chartType === 'pie' && <><path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/></>}
                                    {group.chartType === 'bar' && <><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></>}
                                    {group.chartType === 'horizontalBar' && <><line x1="4" y1="6" x2="14" y2="6"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="18" x2="10" y2="18"/></>}
                                    {group.chartType === 'line' && <><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></>}
                                    {group.chartType === 'area' && <><path d="M22 12l-4-4-4 4-6-6-4 4V4H2v16h20z"/></>}
                                    {group.chartType === 'dualAxis' && <><path d="M3 3v18h18"/><path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/></>}
                                    {group.chartType === 'radar' && <><path d="M12 2l8.7 5.6-2.2 9.4H5.5L3.3 7.6z"/></>}
                                    {group.chartType === 'scatter' && <><circle cx="12" cy="12" r="1"/><circle cx="16" cy="8" r="1"/><circle cx="8" cy="16" r="1"/><circle cx="18" cy="16" r="1"/><circle cx="6" cy="8" r="1"/></>}
                                    {group.chartType === 'table' && <><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M3 15h18M9 3v18"/></>}
                                  </svg>
                                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                                    {chartTypeOptions.find(ct => ct.value === group.chartType)?.label || group.chartType}
                                  </p>
                                  <p className="text-[10px] mt-1" style={{ color: 'var(--text-disabled)' }}>{group.indicators.length} 个指标</p>
                                </div>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    ))}

                    {/* 维度信息 */}
                    <div className="pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                      <p className="text-xs font-medium mb-2">分析维度</p>
                      <div className="flex flex-wrap gap-2">
                        {formDims.map(d => (
                          <span key={d} className="text-xs px-2 py-1 rounded" style={{ background: '#e6f4ff', color: '#1890ff' }}>{d}</span>
                        ))}
                        {formDims.length === 0 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>未选择维度</span>}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div className="flex justify-between gap-3 px-6 py-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setModalOpen(false); resetForm(); }}>取消</button>
              <div className="flex gap-3">
                {currentStep !== 'basic' && (
                  <button className="btn-default" onClick={() => {
                    const prevIdx = stepList.findIndex(s => s.key === currentStep) - 1
                    if (prevIdx >= 0) setCurrentStep(stepList[prevIdx].key)
                  }}>上一步</button>
                )}
                {currentStep === 'basic' && (formInds.length > 0 || customIndicators.length > 0) && (
                  <button className="btn-primary" onClick={() => {
                    if (!formName.trim()) { alert('请输入模型名称'); return }
                    if (formDims.length === 0) { alert('请至少选择一个维度'); return }
                    if (formInds.length === 0 && customIndicators.length === 0) { alert('请至少选择一个指标'); return }
                    goToStep('layout')
                  }}>下一步：配置布局</button>
                )}
                {currentStep === 'layout' && layoutGroups.length > 0 && layoutGroups.every(g => g.indicators.length > 0) && (
                  <button className="btn-primary" onClick={() => goToStep('preview')}>下一步：预览确认</button>
                )}
                {currentStep === 'layout' && (layoutGroups.length === 0 || !layoutGroups.every(g => g.indicators.length > 0)) && (
                  <button className="btn-primary opacity-50 cursor-not-allowed" disabled>下一步：预览确认</button>
                )}
                {currentStep === 'preview' && (
                  <button className="btn-primary" onClick={handleSave}>保存模型</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// 筛选组件（时间范围 + 地区三级联动）
function FilterBar({ timeRange, setTimeRange, city, setCity, district, setDistrict }: {
  timeRange: string, setTimeRange: (v: string) => void,
  city: string, setCity: (v: string) => void,
  district: string, setDistrict: (v: string) => void
}) {
  const districts = city ? (regionData.find(r => r.city === city)?.districts || []) : []
  return (
    <div className="content-card p-4 mb-4">
      <div className="flex flex-wrap items-end gap-3">
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>时间范围</label>
          <select className="form-input w-32 text-sm" value={timeRange} onChange={e => setTimeRange(e.target.value)}>
            <option value="year">本年度</option>
            <option value="half">近半年</option>
            <option value="quarter">近季度</option>
            <option value="custom">自定义</option>
          </select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>省</label>
          <select className="form-input w-28 text-sm" disabled><option>福建省</option></select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>地市</label>
          <select className="form-input w-32 text-sm" value={city} onChange={e => { setCity(e.target.value); setDistrict('') }}>
            <option value="">全省</option>
            {regionData.map(r => <option key={r.city}>{r.city}</option>)}
          </select>
        </div>
        <div>
          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>区县</label>
          <select className="form-input w-32 text-sm" value={district} onChange={e => setDistrict(e.target.value)} disabled={!city}>
            <option value="">全部</option>
            {districts.map(d => <option key={d}>{d}</option>)}
          </select>
        </div>
        {timeRange === 'custom' && (
          <>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>开始日期</label><input type="date" className="form-input w-32 text-sm" /></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>结束日期</label><input type="date" className="form-input w-32 text-sm" /></div>
          </>
        )}
      </div>
    </div>
  )
}

/* ================================================================
   10.2 装备采购研判分析
   ================================================================ */
function PurchaseAnalysis({ onNavigate }: Props) {
  const [paTime, setPaTime] = useState('year')
  const [paCity, setPaCity] = useState('')
  const [paDistrict, setPaDistrict] = useState('')

  const stockStatusOption = useMemo(() => ({
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', right: 10, top: 'center', textStyle: { fontSize: 11 } },
    series: [{
      type: 'pie', radius: ['35%', '65%'], center: ['35%', '50%'],
      avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{d}%' },
      data: [
        { value: 3860, name: '在库', itemStyle: { color: '#1890ff' } },
        { value: 3240, name: '在用', itemStyle: { color: '#52c41a' } },
        { value: 425, name: '待修', itemStyle: { color: '#faad14' } },
        { value: 180, name: '待报废', itemStyle: { color: '#ff4d4f' } },
        { value: 95, name: '调拨中', itemStyle: { color: '#722ed1' } },
      ],
    }],
  }), [])

  const categoryStockOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['在库', '在用', '待修', '待报废'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['通信设备', '防护装备', '记录设备', '照明设备', '应急装备', '警械装备'] },
    yAxis: { type: 'value', name: '数量(件)' },
    series: [
      { name: '在库', type: 'bar', stack: 'total', data: [680, 520, 750, 380, 620, 910], itemStyle: { color: '#1890ff' } },
      { name: '在用', type: 'bar', stack: 'total', data: [520, 480, 620, 350, 580, 690], itemStyle: { color: '#52c41a' } },
      { name: '待修', type: 'bar', stack: 'total', data: [85, 62, 95, 48, 72, 63], itemStyle: { color: '#faad14' } },
      { name: '待报废', type: 'bar', stack: 'total', data: [35, 28, 42, 18, 25, 32], itemStyle: { color: '#ff4d4f' } },
    ],
  }), [])

  const turnoverRateOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['库存周转率(次/年)', '平均采购周期(天)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [{ type: 'value', name: '周转率', position: 'left' }, { type: 'value', name: '天数', position: 'right' }],
    series: [
      { name: '库存周转率(次/年)', type: 'line', data: [4.2, 4.5, 3.8, 5.1, 5.6, 4.8, 4.3, 5.2, 5.8, 4.6, 5.0, 5.5], smooth: true, itemStyle: { color: '#1890ff' } },
      { name: '平均采购周期(天)', type: 'line', yAxisIndex: 1, data: [22, 20, 25, 18, 16, 19, 21, 17, 15, 20, 18, 16], smooth: true, itemStyle: { color: '#ff4d4f' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const inboundTimelyOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '8%', containLabel: true },
    xAxis: { type: 'value', max: 100, name: '百分比(%)' },
    yAxis: { type: 'category', data: ['华为', '海康', '大华', '中兴', '浪潮', '烽火'], axisLabel: { fontSize: 11 } },
    series: [
      { name: '入库及时率', type: 'bar', data: [96, 92, 88, 85, 90, 82], barWidth: 16, itemStyle: { color: '#52c41a', borderRadius: [0, 4, 4, 0] }, label: { show: true, position: 'right', formatter: '{c}%', fontSize: 11 } },
    ],
  }), [])

  const usageRateOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '8%', containLabel: true },
    xAxis: { type: 'value', max: 100, name: '使用率(%)' },
    yAxis: { type: 'category', data: ['手持终端', '执法记录仪', '对讲机', '防弹背心', '战术头盔', '强光手电', '应急照明', '防弹盾牌'], axisLabel: { fontSize: 11 } },
    series: [
      { name: '使用率', type: 'bar', data: [92, 88, 85, 72, 68, 90, 65, 58], barWidth: 14, itemStyle: { color: (p: any) => p.value >= 80 ? '#52c41a' : p.value >= 60 ? '#faad14' : '#ff4d4f', borderRadius: [0, 4, 4, 0] }, label: { show: true, position: 'right', formatter: '{c}%', fontSize: 11 } },
    ],
  }), [])

  const perCapitaOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['人均配备(件)', '使用频次(次/月)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['刑警', '治安', '交警', '特警', '网安', '指挥'] },
    yAxis: [{ type: 'value', name: '件/人', position: 'left' }, { type: 'value', name: '次/月', position: 'right' }],
    series: [
      { name: '人均配备(件)', type: 'bar', data: [5.2, 4.8, 4.5, 6.8, 3.2, 4.0], itemStyle: { color: '#1890ff' }, barMaxWidth: 24 },
      { name: '使用频次(次/月)', type: 'line', yAxisIndex: 1, data: [45, 38, 52, 28, 35, 42], itemStyle: { color: '#faad14' } },
    ],
  }), [])

  const maintenanceOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['报修率(%)', '完好率(%)', '平均维修时间(天)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [{ type: 'value', name: '百分比(%)', position: 'left' }, { type: 'value', name: '天数', position: 'right' }],
    series: [
      { name: '报修率(%)', type: 'line', data: [3.2, 3.8, 2.5, 4.1, 4.8, 3.5, 2.8, 3.6, 4.2, 3.0, 3.5, 4.0], smooth: true, itemStyle: { color: '#ff4d4f' } },
      { name: '完好率(%)', type: 'line', data: [96.8, 96.2, 97.5, 95.9, 95.2, 96.5, 97.2, 96.4, 95.8, 97.0, 96.5, 96.0], smooth: true, itemStyle: { color: '#52c41a' } },
      { name: '平均维修时间(天)', type: 'line', yAxisIndex: 1, data: [5.2, 5.8, 4.5, 6.2, 7.0, 5.5, 4.8, 5.5, 6.5, 5.0, 5.2, 6.0], smooth: true, itemStyle: { color: '#faad14' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const purchaseTrendOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['采购金额', '预算金额'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: { type: 'value', name: '金额(万元)' },
    series: [
      { name: '采购金额', type: 'line', data: [85, 92, 78, 105, 120, 95, 88, 110, 130, 98, 115, 140], smooth: true, itemStyle: { color: '#1890ff' }, areaStyle: { color: 'rgba(24,144,255,0.1)' } },
      { name: '预算金额', type: 'line', data: [100, 100, 100, 110, 110, 110, 120, 120, 120, 130, 130, 130], smooth: true, itemStyle: { color: '#52c41a' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  return (
    <div className="p-6 space-y-4">
      <FilterBar timeRange={paTime} setTimeRange={setPaTime} city={paCity} setCity={setPaCity} district={paDistrict} setDistrict={setPaDistrict} />

      <div className="flex items-center gap-2 mb-1">
        <div className="w-1 h-5 rounded-full" style={{ background: '#1890ff' }} />
        <h3 className="font-semibold">采购存量</h3>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: '装备总库存', value: '7,800件', color: '#1890ff' },
          { label: '库存金额', value: '2,856万', color: '#52c41a' },
          { label: '库存周转率', value: '5.2次/年', color: '#722ed1' },
          { label: '库存预警项', value: '12项', color: '#ff4d4f' },
        ].map(c => (
          <div key={c.label} className="content-card p-3 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">装备状态分布</h4>
          <ReactEChartsCore option={stockStatusOption} style={{ height: 280 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">品类库存构成</h4>
          <ReactEChartsCore option={categoryStockOption} style={{ height: 280 }} notMerge={true} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-1 mt-6">
        <div className="w-1 h-5 rounded-full" style={{ background: '#52c41a' }} />
        <h3 className="font-semibold">流转效率</h3>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: '平均采购周期', value: '17.5天', color: '#1890ff' },
          { label: '入库及时率', value: '91.2%', color: '#52c41a' },
          { label: '出库响应时间', value: '4.2小时', color: '#faad14' },
          { label: '库存呆滞率', value: '3.8%', color: '#ff4d4f' },
        ].map(c => (
          <div key={c.label} className="content-card p-3 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">库存周转率与采购周期</h4>
          <ReactEChartsCore option={turnoverRateOption} style={{ height: 280 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">供应商入库及时率</h4>
          <ReactEChartsCore option={inboundTimelyOption} style={{ height: 280 }} notMerge={true} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-1 mt-6">
        <div className="w-1 h-5 rounded-full" style={{ background: '#faad14' }} />
        <h3 className="font-semibold">使用效能</h3>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: '装备平均使用率', value: '78.5%', color: '#1890ff' },
          { label: '人均配备数', value: '4.8件', color: '#52c41a' },
          { label: '装备利用率', value: '82.3%', color: '#faad14' },
          { label: '闲置装备占比', value: '8.2%', color: '#ff4d4f' },
        ].map(c => (
          <div key={c.label} className="content-card p-3 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">装备品类使用率</h4>
          <ReactEChartsCore option={usageRateOption} style={{ height: 280 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">人均配备与使用频次（按警种）</h4>
          <ReactEChartsCore option={perCapitaOption} style={{ height: 280 }} notMerge={true} />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-1 mt-6">
        <div className="w-1 h-5 rounded-full" style={{ background: '#ff4d4f' }} />
        <h3 className="font-semibold">运维保障</h3>
      </div>
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: '平均报修率', value: '3.6%', color: '#ff4d4f' },
          { label: '装备完好率', value: '96.4%', color: '#52c41a' },
          { label: '平均维修时间', value: '5.5天', color: '#faad14' },
          { label: '售后满意度', value: '88.5%', color: '#1890ff' },
        ].map(c => (
          <div key={c.label} className="content-card p-3 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">报修率 / 完好率 / 维修时间趋势</h4>
          <ReactEChartsCore option={maintenanceOption} style={{ height: 280 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">采购金额与预算对比</h4>
          <ReactEChartsCore option={purchaseTrendOption} style={{ height: 280 }} notMerge={true} />
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   10.4 装备售后研判分析
   ================================================================ */
function AftersalesAnalysis({ onNavigate }: Props) {
  const [asTime, setAsTime] = useState('year')
  const [asCity, setAsCity] = useState('')
  const [asDistrict, setAsDistrict] = useState('')
  const repairTrendOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['报修次数', '投诉次数', '报废次数'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: { type: 'value', name: '次数' },
    series: [
      { name: '报修次数', type: 'line', data: [12, 15, 8, 18, 22, 14, 10, 16, 20, 13, 17, 25], smooth: true, itemStyle: { color: '#ff4d4f' } },
      { name: '投诉次数', type: 'line', data: [2, 3, 1, 4, 5, 3, 2, 3, 4, 2, 3, 5], smooth: true, itemStyle: { color: '#faad14' } },
      { name: '报废次数', type: 'line', data: [1, 2, 0, 3, 4, 2, 1, 2, 3, 1, 2, 4], smooth: true, itemStyle: { color: '#722ed1' } },
    ],
  }), [])

  const faultTypeOption = useMemo(() => ({
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', right: 10, top: 'center' },
    series: [{
      type: 'pie', radius: ['40%', '70%'], center: ['35%', '50%'],
      avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{d}%' },
      data: [
        { value: 35, name: '硬件故障', itemStyle: { color: '#ff4d4f' } },
        { value: 25, name: '电池老化', itemStyle: { color: '#faad14' } },
        { value: 18, name: '接口损坏', itemStyle: { color: '#1890ff' } },
        { value: 12, name: '软件问题', itemStyle: { color: '#52c41a' } },
        { value: 10, name: '其他', itemStyle: { color: '#722ed1' } },
      ],
    }],
  }), [])

  return (
    <div className="p-6 space-y-4">
      <FilterBar timeRange={asTime} setTimeRange={setAsTime} city={asCity} setCity={setAsCity} district={asDistrict} setDistrict={setAsDistrict} />
      <div className="grid grid-cols-4 gap-4">
        {[{ label: '年度报修总数', value: '190次', color: '#ff4d4f' }, { label: '平均维修时间', value: '5.2天', color: '#faad14' }, { label: '投诉率', value: '2.1%', color: '#1890ff' }, { label: '售后满意度', value: '87.5%', color: '#52c41a' }].map(c => (
          <div key={c.label} className="content-card p-4 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">售后数据月度趋势</h4>
          <ReactEChartsCore option={repairTrendOption} style={{ height: 300 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">故障类型分布</h4>
          <ReactEChartsCore option={faultTypeOption} style={{ height: 300 }} notMerge={true} />
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   10.5 供应商能力分析
   ================================================================ */
function SupplierAnalysis({ onNavigate }: Props) {
  const [spTime, setSpTime] = useState('year')
  const [spCity, setSpCity] = useState('')
  const [spDistrict, setSpDistrict] = useState('')
  const radarOption = useMemo(() => ({
    tooltip: {},
    radar: {
      indicator: [
        { name: '供货质量', max: 100 },
        { name: '交付及时率', max: 100 },
        { name: '售后响应', max: 100 },
        { name: '价格竞争力', max: 100 },
        { name: '技术能力', max: 100 },
        { name: '合作配合度', max: 100 },
      ],
      radius: '60%',
    },
    legend: { bottom: 0 },
    series: [{
      type: 'radar',
      data: [
        { value: [92, 88, 85, 75, 90, 88], name: '华为技术', itemStyle: { color: '#1890ff' } },
        { value: [85, 90, 82, 88, 78, 85], name: '海康威视', itemStyle: { color: '#52c41a' } },
        { value: [78, 75, 80, 92, 72, 78], name: '大华股份', itemStyle: { color: '#faad14' } },
        { value: [88, 82, 90, 70, 85, 82], name: '中兴通讯', itemStyle: { color: '#722ed1' } },
      ],
    }],
  }), [])

  const scoreData = [
    { name: '华为技术', total: 86.3, quality: 92, delivery: 88, service: 85, price: 75, tech: 90, coop: 88 },
    { name: '海康威视', total: 84.7, quality: 85, delivery: 90, service: 82, price: 88, tech: 78, coop: 85 },
    { name: '大华股份', total: 82.5, quality: 78, delivery: 75, service: 80, price: 92, tech: 72, coop: 78 },
    { name: '中兴通讯', total: 86.2, quality: 88, delivery: 82, service: 90, price: 70, tech: 85, coop: 82 },
    { name: '浪潮集团', total: 79.8, quality: 75, delivery: 78, service: 72, price: 85, tech: 80, coop: 75 },
  ]

  return (
    <div className="p-6 space-y-4">
      <FilterBar timeRange={spTime} setTimeRange={setSpTime} city={spCity} setCity={setSpCity} district={spDistrict} setDistrict={setSpDistrict} />
      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">供应商能力雷达对比</h4>
          <ReactEChartsCore option={radarOption} style={{ height: 380 }} notMerge={true} />
        </div>
        <div className="content-card overflow-hidden">
          <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
            <h4 className="font-semibold text-sm">供应商综合评分</h4>
          </div>
          <table className="data-table text-sm">
            <thead>
              <tr>
                <th>供应商</th>
                <th>综合评分</th>
                <th>供货质量</th>
                <th>交付及时</th>
                <th>售后响应</th>
                <th>价格</th>
                <th>技术</th>
                <th>配合度</th>
              </tr>
            </thead>
            <tbody>
              {scoreData.map(s => (
                <tr key={s.name}>
                  <td className="font-medium">{s.name}</td>
                  <td className="font-bold" style={{ color: s.total >= 85 ? '#52c41a' : s.total >= 80 ? '#1890ff' : '#faad14' }}>{s.total}</td>
                  <td>{s.quality}</td>
                  <td>{s.delivery}</td>
                  <td>{s.service}</td>
                  <td>{s.price}</td>
                  <td>{s.tech}</td>
                  <td>{s.coop}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   10.6 装备质量分析
   ================================================================ */
function QualityAnalysis({ onNavigate }: Props) {
  const [qaTime, setQaTime] = useState('year')
  const [qaCity, setQaCity] = useState('')
  const [qaDistrict, setQaDistrict] = useState('')
  const qualityOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['库存数', '报修数', '报废数'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['手持终端', '执法记录仪', '对讲机', '防弹背心', '战术头盔', '防弹盾牌', '强光手电', '应急照明'] },
    yAxis: { type: 'value', name: '数量' },
    series: [
      { name: '库存数', type: 'bar', data: [520, 480, 650, 320, 380, 180, 720, 290], itemStyle: { color: '#1890ff' } },
      { name: '报修数', type: 'bar', data: [45, 38, 22, 12, 15, 8, 35, 28], itemStyle: { color: '#faad14' } },
      { name: '报废数', type: 'bar', data: [18, 22, 10, 5, 8, 3, 15, 18], itemStyle: { color: '#ff4d4f' } },
    ],
  }), [])

  const failureRateOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    grid: { left: '3%', right: '8%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['手持终端', '执法记录仪', '对讲机', '防弹背心', '战术头盔', '防弹盾牌', '强光手电', '应急照明'] },
    yAxis: [{ type: 'value', name: '故障率(%)', position: 'left' }, { type: 'value', name: 'MTBF(天)', position: 'right' }],
    series: [
      { name: '故障率(%)', type: 'bar', data: [8.7, 7.9, 3.4, 3.8, 3.9, 4.4, 4.9, 9.7], itemStyle: { color: '#ff4d4f' } },
      { name: 'MTBF(天)', type: 'line', yAxisIndex: 1, data: [365, 380, 520, 580, 560, 600, 480, 320], itemStyle: { color: '#52c41a' } },
    ],
  }), [])

  return (
    <div className="p-6 space-y-4">
      <FilterBar timeRange={qaTime} setTimeRange={setQaTime} city={qaCity} setCity={setQaCity} district={qaDistrict} setDistrict={setQaDistrict} />
      <div className="grid grid-cols-4 gap-4">
        {[{ label: '平均故障率', value: '5.8%', color: '#ff4d4f' }, { label: '平均MTBF', value: '475天', color: '#52c41a' }, { label: '平均报废率', value: '2.4%', color: '#faad14' }, { label: '质量预警', value: '3项', color: '#1890ff' }].map(c => (
          <div key={c.label} className="content-card p-4 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">各品类装备质量统计</h4>
          <ReactEChartsCore option={qualityOption} style={{ height: 320 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">故障率与平均无故障时间</h4>
          <ReactEChartsCore option={failureRateOption} style={{ height: 320 }} notMerge={true} />
        </div>
      </div>
    </div>
  )
}

/* ================================================================
   10.7 装备分布分析
   ================================================================ */
function DistributionAnalysis({ onNavigate }: Props) {
  const [daTime, setDaTime] = useState('year')
  const [daCity, setDaCity] = useState('')
  const [daDistrict, setDaDistrict] = useState('')
  const regionOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['通信设备', '防护装备', '照明设备', '应急装备', '记录设备'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['A区', 'B区', 'C区', 'D区', 'E区', 'F区'] },
    yAxis: { type: 'value', name: '数量(件)' },
    series: [
      { name: '通信设备', type: 'bar', stack: 'total', data: [120, 95, 80, 110, 65, 55], itemStyle: { color: '#1890ff' } },
      { name: '防护装备', type: 'bar', stack: 'total', data: [85, 70, 60, 75, 45, 40], itemStyle: { color: '#52c41a' } },
      { name: '照明设备', type: 'bar', stack: 'total', data: [65, 50, 45, 60, 35, 30], itemStyle: { color: '#faad14' } },
      { name: '应急装备', type: 'bar', stack: 'total', data: [45, 35, 30, 40, 25, 20], itemStyle: { color: '#722ed1' } },
      { name: '记录设备', type: 'bar', stack: 'total', data: [55, 40, 35, 50, 30, 25], itemStyle: { color: '#13c2c2' } },
    ],
  }), [])

  const postOption = useMemo(() => ({
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', right: 10, top: 'center' },
    series: [{
      type: 'pie', radius: ['35%', '60%'], center: ['40%', '50%'],
      avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{d}%' },
      data: [
        { value: 320, name: '一线执法岗', itemStyle: { color: '#1890ff' } },
        { value: 180, name: '指挥调度岗', itemStyle: { color: '#52c41a' } },
        { value: 120, name: '技术支撑岗', itemStyle: { color: '#faad14' } },
        { value: 95, name: '后勤保障岗', itemStyle: { color: '#722ed1' } },
        { value: 65, name: '应急处突岗', itemStyle: { color: '#13c2c2' } },
      ],
    }],
  }), [])

  return (
    <div className="p-6 space-y-4">
      <FilterBar timeRange={daTime} setTimeRange={setDaTime} city={daCity} setCity={setDaCity} district={daDistrict} setDistrict={setDaDistrict} />

      <div className="grid grid-cols-3 gap-4">
        {[{ label: '装备总数', value: '1,580件', color: '#1890ff' }, { label: '覆盖区域', value: '6个', color: '#52c41a' }, { label: '平均密度', value: '263件/区', color: '#722ed1' }].map(c => (
          <div key={c.label} className="content-card p-4 text-center">
            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
            <p className="text-2xl font-bold" style={{ color: c.color }}>{c.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">各区域装备分布（堆叠）</h4>
          <ReactEChartsCore option={regionOption} style={{ height: 340 }} notMerge={true} />
        </div>
        <div className="content-card p-4">
          <h4 className="font-semibold text-sm mb-3">按岗位装备分布</h4>
          <ReactEChartsCore option={postOption} style={{ height: 340 }} notMerge={true} />
        </div>
      </div>
    </div>
  )
}
