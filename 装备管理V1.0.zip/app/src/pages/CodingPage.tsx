import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

const tabList: { key: string; label: string }[] = []

// ========== 编码段位配置 ==========
interface CodeSegment {
  id: number
  name: string
  length: number
  type: '字母' | '数字' | '字母数字'
  valueSource: '固定值' | '关联字典' | '自动流水'
  fixedValue?: string
  dictName?: string
  resetMode?: '按年度归零' | '按月度归零' | '永不归零'
  required: boolean
}

interface CodeRuleData {
  id: string
  name: string
  segments: CodeSegment[]
  status: 'active' | 'inactive'
  createTime: string
  updateTime: string
}

const rulesData: CodeRuleData[] = [
  {
    id: 'RUL001', name: '通用装备编码规则',
    segments: [
      { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
      { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
      { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
      { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
      { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
      { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
      { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
      { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
      { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
      { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
    ],
    status: 'active',
    createTime: '2024-01-10', updateTime: '2024-06-15'
  },
]

interface CodeRuleChangeLog {
  id: string
  ruleId: string
  operator: string
  time: string
  field: string
  oldValue: string
  newValue: string
  reason: string
}

type ApplyStatus = 'pending' | 'approved' | 'rejected'

interface CodeEquipItem {
  id: string
  applyId: string
  orderId: string
  orderNo: string
  supplier: string
  equipName: string
  code: string  // 完整编码，含占位符
  isPlaceholderCode: boolean  // 是否含未生成部分（生产日期/流水号）
  status: ApplyStatus
  applicant: string
  applyTime: string
  approver?: string
  approveTime?: string
  remark?: string
}

interface CodeApplyData {
  id: string
  orderId: string
  orderNo: string
  supplier: string
  applicant: string
  applyTime: string
  status: ApplyStatus
  approver?: string
  approveTime?: string
  items: CodeEquipItem[]
  remark?: string
}

// ========== 编码导入功能类型 ==========
type CheckResult = 'match' | 'conflict' | 'new'
type ConflictResolution = 'system' | 'excel' | 'skip'
type ImportStep = 'upload' | 'preview' | 'confirm' | 'done'

interface ImportRow {
  id: string
  rowNum: number
  orderNo: string
  equipName: string
  supplier: string
  excelCode: string
  systemCode: string
  checkResult: CheckResult
  conflictReason?: string
  resolution: ConflictResolution
  selected: boolean
}

interface ImportLog {
  id: string
  operator: string
  time: string
  filename: string
  totalCount: number
  matchCount: number
  conflictCount: number
  newCount: number
  skipCount: number
  details: string
}


// ========== 编码溯源功能类型 ==========
interface TraceRecord {
  id: string
  code: string
  equipName: string
  spec: string
  manufacturer: string
  supplier: string
  usingUnit: string
  currentOwner: string
  status: 'in_stock' | 'in_use' | 'under_repair' | 'transferred' | 'retired'
  warehouseTime: string
  lastOperationTime: string
  lastOperationType: string
  lastOperator: string
  lifecycle: TraceEvent[]
}

interface TraceEvent {
  id: string
  time: string
  type: '入库' | '出库' | '使用' | '维修' | '调拨' | '盘点' | '报废'
  operator: string
  unit: string
  description: string
  detail?: string
}

const traceData: TraceRecord[] = [
  {
    id: 'TR001', code: '1-0-1-01-P001-001-20240315-05-001XXXXXX-0001', equipName: '数字对讲机 PD780G', spec: 'PD780G/400-470MHz',
    manufacturer: '海能达通信', supplier: '华为技术', usingUnit: '第一支队', currentOwner: '第一支队·通信科',
    status: 'in_use', warehouseTime: '2024-03-15 09:30', lastOperationTime: '2024-06-10 14:20',
    lastOperationType: '日常领用', lastOperator: '张三',
    lifecycle: [
      { id: 'EV001', time: '2024-03-15 09:30', type: '入库', operator: '李四', unit: '装备仓库', description: '新购入库', detail: '合同编号HT2024001，订单DD2024001，数量50台' },
      { id: 'EV002', time: '2024-03-20 10:00', type: '出库', operator: '王五', unit: '装备仓库', description: '分配至第一支队', detail: '出库单号CK2024001，分配数量10台' },
      { id: 'EV003', time: '2024-03-22 08:30', type: '使用', operator: '张三', unit: '第一支队', description: '日常通信保障', detail: '使用地点：指挥中心' },
      { id: 'EV004', time: '2024-05-10 11:20', type: '维修', operator: '赵六', unit: '维修中心', description: '更换电池', detail: '原电池老化，更换新电池，维修单WX2024001' },
      { id: 'EV005', time: '2024-06-01 09:00', type: '盘点', operator: '李四', unit: '第一支队', description: '季度盘点', detail: '状态正常，数量核对无误' },
      { id: 'EV006', time: '2024-06-10 14:20', type: '使用', operator: '张三', unit: '第一支队', description: '日常通信保障', detail: '使用地点：巡逻区域A' },
    ]
  },
  {
    id: 'TR002', code: '1-0-1-01-P002-002-20240401-05-002XXXXXX-0002', equipName: '应急照明灯 YJ-200', spec: 'YJ-200/LED 200W',
    manufacturer: '海洋王照明', supplier: '中兴通讯', usingUnit: '第二支队', currentOwner: '第二支队·应急科',
    status: 'in_stock', warehouseTime: '2024-04-01 10:00', lastOperationTime: '2024-05-28 16:00',
    lastOperationType: '入库验收', lastOperator: '钱七',
    lifecycle: [
      { id: 'EV007', time: '2024-04-01 10:00', type: '入库', operator: '钱七', unit: '装备仓库', description: '新购入库', detail: '合同编号HT2024002，订单DD2024002' },
      { id: 'EV008', time: '2024-05-28 16:00', type: '盘点', operator: '钱七', unit: '装备仓库', description: '月度盘点', detail: '库存20台，状态正常' },
    ]
  },
  {
    id: 'TR003', code: '1-0-1-01-P003-003-20240210-10-003XXXXXX-0003', equipName: '监控摄像头 HK-4K100', spec: 'HK-4K100/800万像素',
    manufacturer: '海康威视', supplier: '海康威视', usingUnit: '第三支队', currentOwner: '第三支队·技防科',
    status: 'under_repair', warehouseTime: '2024-02-10 14:00', lastOperationTime: '2024-06-08 09:30',
    lastOperationType: '故障报修', lastOperator: '孙八',
    lifecycle: [
      { id: 'EV009', time: '2024-02-10 14:00', type: '入库', operator: '周九', unit: '装备仓库', description: '新购入库' },
      { id: 'EV010', time: '2024-02-15 08:00', type: '出库', operator: '周九', unit: '装备仓库', description: '分配至第三支队' },
      { id: 'EV011', time: '2024-03-01 10:00', type: '调拨', operator: '吴十', unit: '指挥中心', description: '临时调拨至指挥中心', detail: '调拨单DB2024001' },
      { id: 'EV012', time: '2024-04-20 15:30', type: '调拨', operator: '吴十', unit: '第三支队', description: '调拨归还' },
      { id: 'EV013', time: '2024-06-08 09:30', type: '维修', operator: '孙八', unit: '维修中心', description: '镜头模糊，送修', detail: '维修单WX2024002，预计3个工作日' },
    ]
  },
]

const importLogData: ImportLog[] = [
  { id: 'IM001', operator: '管理员', time: '2024-06-15 14:30', filename: '装备编码导入_20240615.xlsx', totalCount: 50, matchCount: 42, conflictCount: 5, newCount: 3, skipCount: 0, details: '42条一致直接导入，5条冲突已按系统编码覆盖，3条新建编码' },
  { id: 'IM002', operator: '管理员', time: '2024-06-10 09:15', filename: '装备编码导入_20240610.xlsx', totalCount: 30, matchCount: 25, conflictCount: 3, newCount: 2, skipCount: 2, details: '25条一致，3条冲突采用Excel编码，2条新建，2条跳过' },
]

const changeLogData: CodeRuleChangeLog[] = [
  { id: 'LOG001', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:30', field: '规则名称', oldValue: '通用装备编码规则V1', newValue: '通用装备编码规则', reason: '简化命名' },
  { id: 'LOG002', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:32', field: '适用装备中类', oldValue: 'TX01', newValue: '全部', reason: '扩大适用范围' },
  { id: 'LOG003', ruleId: 'RUL001', operator: '管理员', time: '2024-06-15 10:35', field: '属性后缀-长度', oldValue: '1位', newValue: '2位', reason: '满足扩展需求' },
]

// 示例：订单关联后批量生成的装备编码明细
const codeApplyData: CodeApplyData[] = [
  {
    id: 'BM2024001', orderId: 'DD2024001', orderNo: 'DD2024001', supplier: '华为技术',
    status: 'approved', applicant: '张三', applyTime: '2024-03-01 09:30',
    approver: '李主任', approveTime: '2024-03-01 14:00', remark: '手持终端编码申请',
    items: [
      { id: 'E001', applyId: 'BM2024001', orderId: 'DD2024001', orderNo: 'DD2024001', supplier: '华为技术', equipName: '数字对讲机 PD780G', code: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', isPlaceholderCode: true, status: 'approved', applicant: '张三', applyTime: '2024-03-01 09:30', approver: '李主任', approveTime: '2024-03-01 14:00' },
    ]
  },
  {
    id: 'BM2024002', orderId: 'DD2024002', orderNo: 'DD2024002', supplier: '中兴通讯',
    status: 'pending', applicant: '李四', applyTime: '2024-03-05 10:15', remark: '应急照明设备编码申请',
    items: [
      { id: 'E002', applyId: 'BM2024002', orderId: 'DD2024002', orderNo: 'DD2024002', supplier: '中兴通讯', equipName: '应急照明灯 YJ-200', code: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', isPlaceholderCode: true, status: 'pending', applicant: '李四', applyTime: '2024-03-05 10:15' },
    ]
  },
  {
    id: 'BM2024003', orderId: 'DD2024003', orderNo: 'DD2024003', supplier: '海康威视',
    status: 'pending', applicant: '王五', applyTime: '2024-03-10 11:00', remark: '监控摄像头编码申请',
    items: [
      { id: 'E003', applyId: 'BM2024003', orderId: 'DD2024003', orderNo: 'DD2024003', supplier: '海康威视', equipName: '监控摄像头 HK-4K100', code: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0003', isPlaceholderCode: true, status: 'pending', applicant: '王五', applyTime: '2024-03-10 11:00' },
    ]
  },
  {
    id: 'BM2024004', orderId: 'DD2024004', orderNo: 'DD2024004', supplier: '大疆创新',
    status: 'rejected', applicant: '赵六', applyTime: '2024-03-12 14:20',
    approver: '李主任', approveTime: '2024-03-12 15:00', remark: '信息不完整，驳回补充',
    items: [
      { id: 'E004', applyId: 'BM2024004', orderId: 'DD2024004', orderNo: 'DD2024004', supplier: '大疆创新', equipName: '卫星便携站 S9000', code: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', isPlaceholderCode: true, status: 'rejected', applicant: '赵六', applyTime: '2024-03-12 14:20', approver: '李主任', approveTime: '2024-03-12 15:00' },
    ]
  },
  {
    id: 'BM2024005', orderId: 'DD2024005', orderNo: 'DD2024005', supplier: '海能达',
    status: 'pending', applicant: '钱七', applyTime: '2024-03-15 09:00', remark: '对讲机编码申请',
    items: [
      { id: 'E005', applyId: 'BM2024005', orderId: 'DD2024005', orderNo: 'DD2024005', supplier: '海能达', equipName: '对讲机 HP780', code: '1-0-1-01-P005-001-[日期]-05-005XXXXXX-0005', isPlaceholderCode: true, status: 'pending', applicant: '钱七', applyTime: '2024-03-15 09:00' },
    ]
  },
]

// ========== 编码字典 ==========
type DictType = '标签类别' | '一级分类' | '二级分类' | '三级分类' | '装备品种名称' | '型号编码' | '生产日期' | '有效期' | '供应商信用代码'

interface CodeDictData {
  id: string
  code: string
  name: string
  dictType: DictType
  parentCode?: string
  parentName?: string
  maintainCycle?: string
  validityPeriod?: string
  status: 'active' | 'inactive'
  sortOrder: number
  createTime: string
  remark?: string
}

const codeDictData: CodeDictData[] = [
  { id: 'D001', code: '0', name: '装备标签', dictType: '标签类别', status: 'active', sortOrder: 1, createTime: '2024-01-10', remark: '单个装备的标签' },
  { id: 'D002', code: '1', name: '箱标签', dictType: '标签类别', status: 'active', sortOrder: 2, createTime: '2024-01-10', remark: '整箱装备的标签' },
  { id: 'D003', code: 'YJ', name: '应急救援', dictType: '一级分类', status: 'active', sortOrder: 1, createTime: '2024-01-10', remark: '应急救援类装备' },
  { id: 'D004', code: 'TX', name: '通信装备', dictType: '一级分类', status: 'active', sortOrder: 2, createTime: '2024-01-10', remark: '通信类装备' },
  { id: 'D005', code: 'AQ', name: '安全防护', dictType: '一级分类', status: 'active', sortOrder: 3, createTime: '2024-01-10', remark: '安全防护类装备' },
  { id: 'D006', code: 'JT', name: '交通工具', dictType: '一级分类', status: 'active', sortOrder: 4, createTime: '2024-01-10', remark: '交通工具类装备' },
  { id: 'D007', code: 'YJ01', name: '救生器材', dictType: '二级分类', parentCode: 'YJ', parentName: '应急救援', status: 'active', sortOrder: 1, createTime: '2024-01-10' },
  { id: 'D008', code: 'YJ02', name: '消防器材', dictType: '二级分类', parentCode: 'YJ', parentName: '应急救援', status: 'active', sortOrder: 2, createTime: '2024-01-10' },
  { id: 'D009', code: 'TX01', name: '对讲机', dictType: '二级分类', parentCode: 'TX', parentName: '通信装备', status: 'active', sortOrder: 3, createTime: '2024-01-10' },
  { id: 'D010', code: 'TX02', name: '卫星便携站', dictType: '二级分类', parentCode: 'TX', parentName: '通信装备', status: 'active', sortOrder: 4, createTime: '2024-01-10' },
  { id: 'D011', code: 'TX0101', name: '数字对讲机', dictType: '三级分类', parentCode: 'TX01', parentName: '对讲机', status: 'active', sortOrder: 1, createTime: '2024-01-15' },
  { id: 'D012', code: 'TX0102', name: '模拟对讲机', dictType: '三级分类', parentCode: 'TX01', parentName: '对讲机', status: 'inactive', sortOrder: 2, createTime: '2024-01-15', remark: '逐步淘汰中' },
  { id: 'D013', code: 'P001', name: '海能达PD780G', dictType: '装备品种名称', parentCode: 'TX0101', parentName: '数字对讲机', status: 'active', sortOrder: 1, createTime: '2024-02-01', remark: '主流型号' },
  { id: 'D014', code: 'P002', name: '摩托罗拉P8668i', dictType: '装备品种名称', parentCode: 'TX0101', parentName: '数字对讲机', status: 'active', sortOrder: 2, createTime: '2024-02-01', remark: '高端型号' },
  // 生产日期（6位）
  { id: 'D015', code: 'PRODDATE', name: '生产日期', dictType: '生产日期', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '6位，YYMMDD格式' },
  { id: 'D016', code: '240315', name: '2024年3月15日', dictType: '生产日期', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '示例：240315' },
  { id: 'D017', code: '240601', name: '2024年6月1日', dictType: '生产日期', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '示例：240601' },
  // 有效期（2位）
  { id: 'D018', code: 'VALIDITY', name: '有效期', dictType: '有效期', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '2位，年数' },
  { id: 'D019', code: '05', name: '5年', dictType: '有效期', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '有效期5年' },
  { id: 'D020', code: '10', name: '10年', dictType: '有效期', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '有效期10年' },
  // 型号编码（3位）
  { id: 'DXH001', code: 'XH001', name: '型号编码', dictType: '型号编码', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '3位，装备型号编码' },
  { id: 'DXH002', code: '001', name: 'PD780G标准版', dictType: '型号编码', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '海能达PD780G' },
  { id: 'DXH003', code: '002', name: 'P8668i高端版', dictType: '型号编码', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '摩托罗拉P8668i' },
  { id: 'DXH004', code: '003', name: 'S9000卫星版', dictType: '型号编码', status: 'active', sortOrder: 4, createTime: '2024-03-01', remark: '卫星便携站S9000' },
  // 供应商信用代码（9位，组织机构代码第9-17位）
  { id: 'D021', code: 'SUPPCODE', name: '供应商信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 1, createTime: '2024-03-01', remark: '9位，组织机构代码第9-17位' },
  { id: 'D022', code: '001XXXXXX', name: '华为技术信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 2, createTime: '2024-03-01', remark: '示例' },
  { id: 'D023', code: '002XXXXXX', name: '海康威视信用代码', dictType: '供应商信用代码', status: 'active', sortOrder: 3, createTime: '2024-03-01', remark: '示例' },
]

const segmentColorMap: Record<number, string> = {
  1: '#1890ff', 2: '#52c41a', 3: '#faad14', 4: '#722ed1',
  5: '#13c2c2', 6: '#eb2f96', 7: '#f5222d', 8: '#fa8c16', 9: '#2f4554', 10: '#a0d911',
}

// CSS styles for code placeholder
const codeStyles = `
  .code-generated {
    color: #1890ff !important;
    font-family: monospace;
  }
  .code-placeholder-part {
    color: #8c8c8c !important;
    background: #f5f5f5 !important;
    border: 1px dashed #d9d9d9 !important;
    padding: 1px 4px !important;
    border-radius: 4px !important;
    font-family: monospace;
  }
  .code-placeholder-badge {
    color: #8c8c8c;
    background: #f5f5f5;
    border: 1px dashed #d9d9d9;
    padding: 1px 6px;
    border-radius: 4px;
    font-size: 10px;
    white-space: nowrap;
  }
`

// Inject styles
if (typeof document !== 'undefined') {
  const styleEl = document.getElementById('code-page-styles')
  if (!styleEl) {
    const s = document.createElement('style')
    s.id = 'code-page-styles'
    s.textContent = codeStyles
    document.head.appendChild(s)
  }
}

export default function CodingPage({ activeSubTab, onNavigate }: Props) {
  const validTabs = ['rule', 'approval', 'trace', 'codemgmt']
  const [activeTab, setActiveTab] = useState(activeSubTab && validTabs.includes(activeSubTab) ? activeSubTab : 'rule')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTitle, setDrawerTitle] = useState('')

  const [ruleList, setRuleList] = useState<CodeRuleData[]>(rulesData)
  const [selectedRule, setSelectedRule] = useState<CodeRuleData | null>(null)
  const [ruleEditMode, setRuleEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)
  const [selectedDeleteRule, setSelectedDeleteRule] = useState<CodeRuleData | null>(null)

  const [editingSegments, setEditingSegments] = useState<CodeSegment[]>([
    { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
    { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
    { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
    { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
    { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
    { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
    { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
    { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
    { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
    { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
  ])

  const [changelogOpen, setChangelogOpen] = useState(false)
  const [selectedChangelogRuleId, setSelectedChangelogRuleId] = useState('')

  // Code apply states
  const [applyList, setApplyList] = useState<CodeApplyData[]>(codeApplyData)
  const [applySearchKeyword, setApplySearchKeyword] = useState('')
  const [applySearchCode, setApplySearchCode] = useState('')
  const [applySearchCodeStatus, setApplySearchCodeStatus] = useState<'placeholder' | 'generated' | ''>('')
  const [applySearchStatus, setApplySearchStatus] = useState<ApplyStatus | ''>('')
  const [applyDetailOpen, setApplyDetailOpen] = useState(false)
  const [selectedApply, setSelectedApply] = useState<CodeApplyData | null>(null)
  const [applyViewMode, setApplyViewMode] = useState<'view' | 'approve' | 'add' | 'edit'>('view')
  const [approveConfirmOpen, setApproveConfirmOpen] = useState(false)
  const [approveAction, setApproveAction] = useState<'approve' | 'reject'>('approve')
  const [approveRemark, setApproveRemark] = useState('')
  const [selectedOrderId, setSelectedOrderId] = useState('')
  const [orderEquipList, setOrderEquipList] = useState<CodeEquipItem[]>([])

  // 可供选择的订单列表（模拟数据）
  const orderOptions = [
    { id: 'DD2024001', no: 'DD2024001', supplier: '海康威视', equipName: '监控摄像头 HK-4K100', qty: 50, status: '待编码' },
    { id: 'DD2024002', no: 'DD2024002', supplier: '华为技术', equipName: '数字对讲机 PD780G', qty: 30, status: '待编码' },
    { id: 'DD2024003', no: 'DD2024003', supplier: '中兴通讯', equipName: '应急照明灯 YJ-200', qty: 20, status: '待编码' },
    { id: 'DD2024004', no: 'DD2024004', supplier: '大疆创新', equipName: '卫星便携站 S9000', qty: 15, status: '待编码' },
  ]

  // Import feature states
  const [importModalOpen, setImportModalOpen] = useState(false)
  const [importStep, setImportStep] = useState<ImportStep>('upload')
  const [importRows, setImportRows] = useState<ImportRow[]>([])
  const [importFileName, setImportFileName] = useState('')
  const [importError, setImportError] = useState('')
  const [importLogs] = useState<ImportLog[]>(importLogData)
  const [importLogOpen, setImportLogOpen] = useState(false)
  const [traceSearchCode, setTraceSearchCode] = useState('')
  const [selectedTraceRecord, setSelectedTraceRecord] = useState<TraceRecord | null>(null)
  const [traceDetailOpen, setTraceDetailOpen] = useState(false)

  const [dictList] = useState<CodeDictData[]>(codeDictData)
  const [dictSearchType, setDictSearchType] = useState<DictType | ''>('')
  const [dictSearchKeyword, setDictSearchKeyword] = useState('')
  const [dictSearchStatus, setDictSearchStatus] = useState<'active' | 'inactive' | ''>('')

  useEffect(() => {
    if (activeSubTab && validTabs.includes(activeSubTab)) {
      setActiveTab(activeSubTab)
    } else if (!activeSubTab) {
      setActiveTab('rule')
    }
  }, [activeSubTab])

  const openRuleDetailWithSegments = (item: CodeRuleData, mode: 'view' | 'edit') => {
    setSelectedRule(item)
    setRuleEditMode(mode)
    setDrawerTitle(mode === 'edit' ? `编辑编码规则 - ${item.id}` : `编码规则详情 - ${item.id}`)
    setEditingSegments([...item.segments])
    setDrawerOpen(true)
  }

  const openAddRule = () => {
    setSelectedRule(null)
    setRuleEditMode('add')
    setDrawerTitle('新增编码规则')
    setEditingSegments([
      { id: 1, name: '标签类别', length: 1, type: '数字', valueSource: '关联字典', dictName: '标签类别', required: true },
      { id: 2, name: '装备一级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '一级分类', required: true },
      { id: 3, name: '装备二级分类编码', length: 1, type: '数字', valueSource: '关联字典', dictName: '二级分类', required: true },
      { id: 4, name: '装备三级分类编码', length: 2, type: '数字', valueSource: '关联字典', dictName: '三级分类', required: true },
      { id: 5, name: '装备名称编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '装备品种名称', required: true },
      { id: 6, name: '装备型号编码', length: 3, type: '数字', valueSource: '关联字典', dictName: '型号编码', required: true },
      { id: 7, name: '生产日期', length: 6, type: '数字', valueSource: '关联字典', dictName: '生产日期', required: true },
      { id: 8, name: '有效期', length: 2, type: '数字', valueSource: '关联字典', dictName: '有效期', required: true },
      { id: 9, name: '供应商信用代码', length: 9, type: '数字', valueSource: '关联字典', dictName: '供应商信用代码', required: true },
      { id: 10, name: '流水号', length: 4, type: '数字', valueSource: '自动流水', resetMode: '按年度归零', required: true },
    ])
    setDrawerOpen(true)
  }

  const toggleRuleStatus = (item: CodeRuleData) => {
    setRuleList(prev => prev.map(r =>
      r.id === item.id
        ? { ...r, status: r.status === 'active' ? 'inactive' as const : 'active' as const, updateTime: new Date().toISOString().slice(0, 10) }
        : r
    ))
  }

  const handleDeleteRule = (item: CodeRuleData) => {
    setSelectedDeleteRule(item)
    setDeleteConfirmOpen(true)
  }

  const confirmDeleteRule = () => {
    if (selectedDeleteRule) {
      setRuleList(prev => prev.filter(r => r.id !== selectedDeleteRule.id))
    }
    setDeleteConfirmOpen(false)
    setSelectedDeleteRule(null)
  }

  const handleAddSegment = () => {
    const newId = editingSegments.length > 0 ? Math.max(...editingSegments.map(s => s.id)) + 1 : 1
    setEditingSegments(prev => [...prev, { id: newId, name: '', length: 1, type: '字母数字', valueSource: '关联字典', dictName: '', required: false }])
  }

  const handleDeleteSegment = (segId: number) => {
    setEditingSegments(prev => prev.filter(s => s.id !== segId))
  }

  const handleSegmentChange = (segId: number, field: keyof CodeSegment, value: string | boolean | number) => {
    setEditingSegments(prev => prev.map(s => s.id === segId ? { ...s, [field]: value } : s))
  }

  const openChangelog = (ruleId: string) => {
    setSelectedChangelogRuleId(ruleId)
    setChangelogOpen(true)
  }

  // 编码预览生成：根据段位配置，从编码字典中取实际值生成预览
  // 占位符段位（生产日期、流水号）用灰色标识，表示"暂未生产"
  const generatePreviewCode = (rule?: CodeRuleData | null) => {
    if (!rule) {
      return [
        { value: codeDictData.find(d => d.dictType === '标签类别')?.code || '1', display: '标签类别', segmentName: '标签类别', isPlaceholder: true },
        { value: codeDictData.find(d => d.dictType === '一级分类')?.code || '0', display: codeDictData.find(d => d.dictType === '一级分类')?.code || '0', segmentName: '一级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '二级分类')?.code || '1', display: codeDictData.find(d => d.dictType === '二级分类')?.code || '1', segmentName: '二级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '三级分类')?.code || '01', display: codeDictData.find(d => d.dictType === '三级分类')?.code || '01', segmentName: '三级分类', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '装备品种名称')?.code || 'P001', display: codeDictData.find(d => d.dictType === '装备品种名称')?.code || 'P001', segmentName: '装备名称编码', isPlaceholder: false },
        { value: (codeDictData.find(d => d.dictType === '型号编码')?.code || '001').slice(0, 3), display: (codeDictData.find(d => d.dictType === '型号编码')?.code || '001').slice(0, 3), segmentName: '装备型号编码', isPlaceholder: false },
        { value: '[DATE]', display: '[日期]', segmentName: '生产日期', isPlaceholder: true },
        { value: codeDictData.find(d => d.dictType === '有效期')?.code || '05', display: codeDictData.find(d => d.dictType === '有效期')?.code || '05', segmentName: '有效期', isPlaceholder: false },
        { value: codeDictData.find(d => d.dictType === '供应商信用代码')?.code || '001XXXXXX', display: codeDictData.find(d => d.dictType === '供应商信用代码')?.code || '001XXXXXX', segmentName: '供应商代码', isPlaceholder: false },
        { value: '[SEQ]', display: '流水号', segmentName: '流水号', isPlaceholder: true },
      ]
    }
    return rule.segments.map((seg, idx) => {
      // 第一段：标签类别 → 显示文字"标签类别"灰色
      if (idx === 0 && seg.name === '标签类别') {
        return { value: '1', display: '标签类别', segmentName: seg.name, isPlaceholder: true }
      }
      // 最后一段：流水号 → 显示文字"流水号"灰色
      if (seg.name === '流水号') {
        return { value: '[SEQ]', display: '流水号', segmentName: seg.name, isPlaceholder: true }
      }
      const isPlaceholder = seg.name === '生产日期'
      if (isPlaceholder) {
        return { value: '[DATE]', display: '[日期]', segmentName: seg.name, isPlaceholder: true }
      }
      if (seg.valueSource === '固定值') {
        const val = (seg.fixedValue || 'X').padStart(seg.length, 'X').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      if (seg.valueSource === '关联字典') {
        const dictItem = codeDictData.find(d => d.dictType === seg.dictName)
        const code = dictItem?.code || ''
        const val = code.padStart(seg.length, '0').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      if (seg.valueSource === '自动流水') {
        const val = '0001'.padStart(seg.length, '0').slice(0, seg.length)
        return { value: val, display: val, segmentName: seg.name, isPlaceholder: false }
      }
      return { value: 'X'.repeat(seg.length), display: 'X'.repeat(seg.length), segmentName: seg.name, isPlaceholder: false }
    })
  }


  // Code dict drawer
  const [dictDrawerOpen, setDictDrawerOpen] = useState(false)
  const [dictDrawerTitle, setDictDrawerTitle] = useState('')
  const [selectedDict, setSelectedDict] = useState<CodeDictData | null>(null)
  const [dictEditMode, setDictEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const openDictDetail = (item: CodeDictData, mode: 'view' | 'edit') => {
    setSelectedDict(item)
    setDictEditMode(mode)
    setDictDrawerTitle(mode === 'edit' ? `编辑字典项 - ${item.id}` : `字典项详情 - ${item.id}`)
    setDictDrawerOpen(true)
  }

  const openAddDict = () => {
    setSelectedDict(null)
    setDictEditMode('add')
    setDictDrawerTitle('新增字典项')
    setDictDrawerOpen(true)
  }

  // Code apply helpers
  const openApplyDetail = (item: CodeApplyData, mode: 'view' | 'approve' | 'edit') => {
    setSelectedApply(item)
    setApplyViewMode(mode)
    setApproveRemark('')
    setSelectedOrderId(item.orderId)
    setOrderEquipList(item.items || [])
    setApplyDetailOpen(true)
  }

  const openAddApply = () => {
    setSelectedApply(null)
    setApplyViewMode('add')
    setApproveRemark('')
    setSelectedOrderId('')
    setOrderEquipList([])
    setApplyDetailOpen(true)
  }

  const handleApproveAction = (action: 'approve' | 'reject') => {
    setApproveAction(action)
    setApproveConfirmOpen(true)
  }


  // 将编码拆分为已生成（蓝色）和占位符（灰色）部分
  const renderSplitCode = (code: string) => {
    // 将编码按"-"分割
    // 第1段(标签类别) → 灰色显示"标签类别"
    // 第7段(日期,8位数字如20240315) → 灰色显示实际日期
    // 最后1段(流水号) → 灰色显示"流水号"
    // 其他段 → 蓝色
    const segments = code.split('-')
    return (
      <>
        {segments.map((seg, i) => {
          const isLast = i === segments.length - 1
          const isFirst = i === 0
          const isDate = /^\d{8}$/.test(seg) // 8位数字日期格式
          const isGray = isFirst || isLast || isDate
          // 显示文字：第一段→标签类别，最后一段→流水号，其他→原值
          let displayText = seg
          if (isFirst) displayText = '标签类别'
          else if (isLast) displayText = '流水号'
          const separator = i < segments.length - 1 ? '-' : ''
          return (
            <span key={i}>
              {isGray ? (
                <span style={{ color: '#8c8c8c', background: '#f5f5f5', border: '1px dashed #d9d9d9', padding: '1px 4px', borderRadius: '4px', fontFamily: 'monospace', fontSize: '11px' }}>{displayText}</span>
              ) : (
                <span style={{ color: '#1890ff', fontFamily: 'monospace', fontSize: '11px' }}>{displayText}</span>
              )}
              {separator && <span style={{ color: '#d9d9d9', fontFamily: 'monospace', fontSize: '11px' }}>{separator}</span>}
            </span>
          )
        })}
      </>
    )
  }
  // 根据装备名称和订单信息预生成编码（生产日期和流水号用占位符）
  const generateCodePreview = (_equipName: string, _orderNo: string) => {
    const nameDict = codeDictData.find(d => d.dictType === '装备品种名称')
    const modelDict = codeDictData.find(d => d.dictType === '型号编码')
    const validityDict = codeDictData.find(d => d.dictType === '有效期')
    const supplierDict = codeDictData.find(d => d.dictType === '供应商信用代码')
    return [
      codeDictData.find(d => d.dictType === '标签类别')?.code || '1',
      codeDictData.find(d => d.dictType === '一级分类')?.code || '0',
      codeDictData.find(d => d.dictType === '二级分类')?.code || '1',
      codeDictData.find(d => d.dictType === '三级分类')?.code || '01',
      (nameDict?.code || 'P001'),
      (modelDict?.code || '001').slice(0, 3),
      '[日期]',
      validityDict?.code || '05',
      supplierDict?.code || '001XXXXXX',
      '[流水]',
    ].join('-')
  }

  // 选择订单后批量列出装备明细
  const handleSelectOrder = (orderId: string) => {
    setSelectedOrderId(orderId)
    const order = orderOptions.find(o => o.id === orderId)
    if (!order) { setOrderEquipList([]); return }
    const items: CodeEquipItem[] = [{
      id: `EQ${Date.now()}`,
      applyId: '',
      orderId: order.id,
      orderNo: order.no,
      supplier: order.supplier,
      equipName: order.equipName,
      code: generateCodePreview(order.equipName, order.no),
      isPlaceholderCode: true,
      status: 'pending' as ApplyStatus,
      applicant: '当前用户',
      applyTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
    }]
    setOrderEquipList(items)
  }

  const confirmApproveAction = () => {
    if (selectedApply) {
      const newStatus = approveAction === 'approve' ? 'approved' as ApplyStatus : 'rejected' as ApplyStatus
      const now = new Date().toISOString().slice(0, 16).replace('T', ' ')
      setApplyList(prev => prev.map(a => a.id === selectedApply.id ? {
        ...a,
        status: newStatus,
        approver: '李主任',
        approveTime: now,
        items: a.items.map(it => ({ ...it, status: newStatus, approver: '李主任', approveTime: now }))
      } : a))
    }
    setApproveConfirmOpen(false)
    setApplyDetailOpen(false)
    setApproveRemark('')
  }

  // ========== 导入功能核心函数 ==========
  const openImportModal = () => {
    setImportModalOpen(true)
    setImportStep('upload')
    setImportRows([])
    setImportFileName('')
    setImportError('')
  }

  const closeImportModal = () => {
    setImportModalOpen(false)
    setImportStep('upload')
    setImportRows([])
    setImportFileName('')
    setImportError('')
  }

  const parseExcelFile = (fileName: string) => {
    setImportError('')
    const mockRows: ImportRow[] = [
      { id: 'R001', rowNum: 2, orderNo: 'DD2024001', equipName: '数字对讲机 PD780G', supplier: '华为技术', excelCode: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', systemCode: '1-0-1-01-P001-001-[日期]-05-001XXXXXX-0001', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R002', rowNum: 3, orderNo: 'DD2024002', equipName: '应急照明灯 YJ-200', supplier: '中兴通讯', excelCode: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', systemCode: '1-0-1-01-P002-002-[日期]-05-002XXXXXX-0002', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R003', rowNum: 4, orderNo: 'DD2024003', equipName: '监控摄像头 HK-4K100', supplier: '海康威视', excelCode: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0099', systemCode: '1-0-1-01-P003-003-[日期]-10-003XXXXXX-0003', checkResult: 'conflict', conflictReason: 'Excel流水号0099与系统流水号0003不一致', resolution: 'system', selected: false },
      { id: 'R004', rowNum: 5, orderNo: 'DD2024006', equipName: '手持终端 SC-500', supplier: '紫光电子', excelCode: '1-0-1-01-P006-004-[日期]-05-006XXXXXX-0006', systemCode: '1-0-1-01-P006-004-[日期]-05-006XXXXXX-0006', checkResult: 'new', resolution: 'system', selected: true },
      { id: 'R005', rowNum: 6, orderNo: 'DD2024004', equipName: '卫星便携站 S9000', supplier: '大疆创新', excelCode: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', systemCode: '1-0-1-01-P004-003-[日期]-10-004XXXXXX-0004', checkResult: 'match', resolution: 'system', selected: true },
      { id: 'R006', rowNum: 7, orderNo: 'DD2024007', equipName: '无人机 M300', supplier: '大疆创新', excelCode: '1-0-1-01-P007-005-[日期]-05-007XXXXXX-0150', systemCode: '1-0-1-01-P007-005-[日期]-05-007XXXXXX-0007', checkResult: 'conflict', conflictReason: 'Excel流水号0150与系统流水号0007不一致', resolution: 'system', selected: false },
    ]
    setImportRows(mockRows)
    setImportFileName(fileName)
    setImportStep('preview')
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.name.endsWith('.xlsx') && !file.name.endsWith('.xls') && !file.name.endsWith('.csv')) {
      setImportError('请上传 .xlsx、.xls 或 .csv 格式的文件')
      return
    }
    parseExcelFile(file.name)
  }

  const toggleRowSelected = (rowId: string) => {
    setImportRows(prev => prev.map(r => r.id === rowId ? { ...r, selected: !r.selected } : r))
  }

  const setRowResolution = (rowId: string, resolution: ConflictResolution) => {
    setImportRows(prev => prev.map(r => r.id === rowId ? { ...r, resolution, selected: resolution !== 'skip' } : r))
  }

  const batchResolution = (result: CheckResult, resolution: ConflictResolution) => {
    setImportRows(prev => prev.map(r => r.checkResult === result ? { ...r, resolution, selected: resolution !== 'skip' } : r))
  }

  const confirmImport = () => {
    setImportStep('done')
  }

  const checkResultConfig: Record<CheckResult, { label: string; color: string; bg: string }> = {
    match: { label: '一致', color: '#52c41a', bg: '#f6ffed' },
    conflict: { label: '冲突', color: '#ff4d4f', bg: '#fff2f0' },
    new: { label: '新建', color: '#1890ff', bg: '#e6f7ff' },
  }

  const applyStatusConfig: Record<ApplyStatus, { label: string; color: string; bg: string }> = {
    pending: { label: '待审批', color: '#faad14', bg: '#fffbe6' },
    approved: { label: '已通过', color: '#52c41a', bg: '#f6ffed' },
    rejected: { label: '已驳回', color: '#ff4d4f', bg: '#fff2f0' },
  }

  return (
    <div className="p-6 space-y-4">
      {activeTab === 'rule' && (
        <>
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setActiveTab('rule')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>编码规则</span>
          </div>
          {/* Toolbar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={openAddRule}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增规则
              </button>
            </div>
            <div className="flex gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#b7eb8f', background: '#f6ffed', color: '#52c41a' }}>已启用 {ruleList.filter(r => r.status === 'active').length}</span>
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#d9d9d9', background: '#f5f5f5', color: '#8c8c8c' }}>已禁用 {ruleList.filter(r => r.status === 'inactive').length}</span>
            </div>
          </div>

          {/* Search area */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则ID/名称</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>已启用</option><option>已禁用</option></select></div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default">重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>

          {/* Main content */}
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>规则ID</th><th>规则名称</th><th>段位数</th><th>状态</th><th>操作</th></tr>
              </thead>
              <tbody>
                {ruleList.map(r => (
                  <tr key={r.id}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{r.id}</td>
                    <td className="font-medium">{r.name}</td>
                    <td>{r.segments.length}段（共{r.segments.reduce((sum, s) => sum + s.length, 0)}位）</td>
                    <td><span className={`tag ${r.status === 'active' ? 'tag-green' : 'tag-gray'}`}>{r.status === 'active' ? '启用' : '禁用'}</span></td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openRuleDetailWithSegments(r, 'view')}>查看</button>
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openRuleDetailWithSegments(r, 'edit')}>编辑</button>
                        {r.status === 'active' ? (
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => toggleRuleStatus(r)}>禁用</button>
                        ) : (
                          <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => toggleRuleStatus(r)}>启用</button>
                        )}
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openChangelog(r.id)}>变更记录</button>
                        <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDeleteRule(r)}>删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>


          </div>
        </>
      )}

      {activeTab === 'approval' && (
        <>
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setActiveTab('rule')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>编码管理</span>
          </div>
          {/* Toolbar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={openAddApply}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增编码申请
              </button>
              <button className="btn-default flex items-center gap-1 text-xs" onClick={() => {
                const csv = ['\uFEFF关联订单,装备名称,供应商,编码,审批状态,申请人,申请时间,审批人,审批时间']
                applyList.forEach(a => {
                  a.items.forEach(it => {
                    const statusText = applyStatusConfig[it.status].label
                    csv.push(`${it.orderNo},${it.equipName},${it.supplier},${it.code},${statusText},${it.applicant},${it.applyTime},${it.approver || '-'},${it.approveTime || '-'}`)
                  })
                })
                const blob = new Blob([csv.join('\n')], { type: 'text/csv;charset=utf-8;' })
                const link = document.createElement('a')
                link.href = URL.createObjectURL(blob)
                link.download = `编码管理_${new Date().toISOString().slice(0, 10)}.csv`
                link.click()
              }}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                导出
              </button>
            </div>
            <div className="flex gap-2 text-xs items-center">
              {(Object.keys(applyStatusConfig) as ApplyStatus[]).map(s => (
                <span key={s} className="px-3 py-1 rounded-full border" style={{ borderColor: applyStatusConfig[s].color + '40', background: applyStatusConfig[s].bg, color: applyStatusConfig[s].color }}>
                  {applyStatusConfig[s].label} {applyList.reduce((sum, a) => sum + a.items.filter(it => it.status === s).length, 0)}
                </span>
              ))}

            </div>
          </div>

          {/* Search */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label>
                <input className="form-input w-36" placeholder="装备名称..." value={applySearchKeyword} onChange={e => setApplySearchKeyword(e.target.value)} />
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码</label>
                <input className="form-input w-40 font-mono" placeholder="编码..." value={applySearchCode} onChange={e => setApplySearchCode(e.target.value)} />
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码状态</label>
                <select className="form-input w-28" value={applySearchCodeStatus} onChange={e => setApplySearchCodeStatus(e.target.value as 'placeholder' | 'generated' | '')}>
                  <option value="">全部</option>
                  <option value="placeholder">预生成</option>
                  <option value="generated">已生成</option>
                </select>
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单</label>
                <input className="form-input w-36" placeholder="订单号..." value={applySearchKeyword} onChange={e => setApplySearchKeyword(e.target.value)} />
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                <select className="form-input w-24" value={applySearchStatus} onChange={e => setApplySearchStatus(e.target.value as ApplyStatus | '')}>
                  <option value="">全部</option>
                  <option value="pending">待审批</option>
                  <option value="approved">已通过</option>
                  <option value="rejected">已驳回</option>
                </select>
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                <input className="form-input w-32" placeholder="供应商..." value={applySearchKeyword} onChange={e => setApplySearchKeyword(e.target.value)} />
              </div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default" onClick={() => { setApplySearchKeyword(''); setApplySearchCode(''); setApplySearchCodeStatus(''); setApplySearchStatus('') }}>重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>

          {/* Table - grouped by apply batch */}
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-10"><input type="checkbox"/></th>
                  <th>装备名称</th>
                  <th>编码</th>
                  <th>编码状态</th>
                  <th>关联订单</th>
                  <th>审批状态</th>
                  <th>供应商</th>
                  <th>申请人</th>
                  <th>申请时间</th>
                  <th>审批人</th>
                  <th>审批时间</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {applyList
                  .filter(a => !applySearchStatus || a.items.some(it => it.status === applySearchStatus))
                  .filter(a => !applySearchKeyword || a.orderNo.includes(applySearchKeyword) || a.items.some(it => it.equipName.includes(applySearchKeyword) || it.supplier.includes(applySearchKeyword)))
                  .flatMap(a => a.items.map((it, idx) => ({ ...it, _apply: a, _isFirst: idx === 0 })))
                  .filter(it => !applySearchStatus || it.status === applySearchStatus)
                  .filter(it => !applySearchCode || it.code.includes(applySearchCode))
                  .filter(it => !applySearchCodeStatus || (applySearchCodeStatus === 'placeholder' ? it.isPlaceholderCode : !it.isPlaceholderCode))
                  .map(it => (
                    <tr key={it.id}>
                      <td><input type="checkbox"/></td>
                      <td className="text-sm font-medium">{it.equipName}</td>
                      <td>
                        <span className="font-mono text-xs">
                          {renderSplitCode(it.code)}
                        </span>
                      </td>
                      <td>
                        <span className="tag text-xs px-2 py-0.5" style={{
                          background: it.isPlaceholderCode ? '#fffbe6' : '#f6ffed',
                          color: it.isPlaceholderCode ? '#faad14' : '#52c41a',
                          border: `1px solid ${it.isPlaceholderCode ? '#ffe58f' : '#b7eb8f'}`
                        }}>
                          {it.isPlaceholderCode ? '预生成' : '已生成'}
                        </span>
                      </td>
                      <td className="font-mono text-xs">{it.orderNo}</td>
                      <td>
                        <span className="tag text-xs px-2 py-0.5" style={{ background: applyStatusConfig[it.status].bg, color: applyStatusConfig[it.status].color, border: `1px solid ${applyStatusConfig[it.status].color}30` }}>
                          {applyStatusConfig[it.status].label}
                        </span>
                      </td>
                      <td className="text-xs">{it.supplier}</td>
                      <td>{it.applicant}</td>
                      <td className="text-xs">{it.applyTime}</td>
                      <td>{it.approver || '-'}</td>
                      <td className="text-xs">{it.approveTime || '-'}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openApplyDetail(it._apply, 'view')}>查看</button>
                          {it.status === 'pending' && (
                            <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openApplyDetail(it._apply, 'approve')}>审批</button>
                          )}
                          {it.status === 'pending' && (
                            <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openApplyDetail(it._apply, 'edit')}>编辑</button>
                          )}
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }}>删除</button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </>
      )}





      {activeTab === 'codemgmt' && (
        <>
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setActiveTab('rule')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>编码字典</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={openAddDict}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增字典项
              </button>
            </div>
            <div className="flex gap-2 text-xs">
              {(['标签类别', '一级分类', '二级分类', '三级分类', '装备品种名称', '型号编码', '生产日期', '有效期', '供应商信用代码'] as DictType[]).map(t => (
                <span key={t} className="px-3 py-1 rounded-full border" style={{ borderColor: '#e6f7ff', background: '#f0f8ff', color: '#1890ff' }}>
                  {t} {dictList.filter(d => d.dictType === t).length}
                </span>
              ))}
            </div>
          </div>

          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典类型</label>
                <select className="form-input w-32" value={dictSearchType} onChange={e => setDictSearchType(e.target.value as DictType | '')}>
                  <option value="">全部</option>
                  <option>标签类别</option>
                  <option>一级分类</option>
                  <option>二级分类</option>
                  <option>三级分类</option>
                  <option>装备品种名称</option>
                  <option>型号编码</option>
                  <option>生产日期</option>
                  <option>有效期</option>
                  <option>供应商信用代码</option>
                </select>
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码/名称</label>
                <input className="form-input w-40" placeholder="请输入关键词..." value={dictSearchKeyword} onChange={e => setDictSearchKeyword(e.target.value)} />
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                <select className="form-input w-28" value={dictSearchStatus} onChange={e => setDictSearchStatus(e.target.value as 'active' | 'inactive' | '')}>
                  <option value="">全部</option>
                  <option value="active">启用</option>
                  <option value="inactive">禁用</option>
                </select>
              </div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default" onClick={() => { setDictSearchType(''); setDictSearchKeyword(''); setDictSearchStatus('') }}>重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>

          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-10"><input type="checkbox"/></th>
                  <th>序号</th>
                  <th>字典类型</th>
                  <th>编码</th>
                  <th>名称</th>
                  <th>上级分类</th>
                  <th>状态</th>
                  <th>排序号</th>
                  <th>扩展信息</th>
                  <th>创建时间</th>
                  <th>备注</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {dictList
                  .filter(d => !dictSearchType || d.dictType === dictSearchType)
                  .filter(d => !dictSearchStatus || d.status === dictSearchStatus)
                  .filter(d => !dictSearchKeyword || d.code.includes(dictSearchKeyword) || d.name.includes(dictSearchKeyword) || (d.parentName || '').includes(dictSearchKeyword))
                  .sort((a, b) => a.dictType.localeCompare(b.dictType) || a.sortOrder - b.sortOrder)
                  .map((d, idx) => (
                    <tr key={d.id}>
                      <td><input type="checkbox"/></td>
                      <td>{idx + 1}</td>
                      <td>
                        <span className="tag text-xs" style={{
                          background: d.dictType === '标签类别' ? '#e6f7ff' : d.dictType === '装备品种名称' ? '#f6ffed' : d.dictType === '型号编码' ? '#fff0f6' : '#fffbe6',
                          color: d.dictType === '标签类别' ? '#1890ff' : d.dictType === '装备品种名称' ? '#52c41a' : d.dictType === '型号编码' ? '#eb2f96' : '#faad14',
                          border: `1px solid ${d.dictType === '标签类别' ? '#91d5ff' : d.dictType === '装备品种名称' ? '#b7eb8f' : d.dictType === '型号编码' ? '#ffadd2' : '#ffe58f'}`
                        }}>
                          {d.dictType}
                        </span>
                      </td>
                      <td className="font-mono text-xs font-medium">{d.code}</td>
                      <td className="font-medium">{d.name}</td>
                      <td>{d.parentName ? <span><span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{d.parentCode}</span> · {d.parentName}</span> : '-'}</td>
                      <td><span className={`tag ${d.status === 'active' ? 'tag-green' : 'tag-gray'}`}>{d.status === 'active' ? '启用' : '禁用'}</span></td>
                      <td>{d.sortOrder}</td>
                      <td className="text-xs">{d.createTime}</td>
                      <td>
                        {(d.maintainCycle || d.validityPeriod) ? (
                          <div className="flex flex-col gap-0.5">
                            {d.maintainCycle && <span className="text-xs" style={{ color: '#13c2c2' }}>保养：{d.maintainCycle}月</span>}
                            {d.validityPeriod && <span className="text-xs" style={{ color: '#faad14' }}>有效：{d.validityPeriod}年</span>}
                          </div>
                        ) : (
                          <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>
                        )}
                      </td>
                      <td className="text-xs">{d.createTime}</td>
                      <td className="text-xs" style={{ color: 'var(--text-secondary)' }}>{d.remark || '-'}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDictDetail(d, 'view')}>查看</button>
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDictDetail(d, 'edit')}>编辑</button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Rule Detail / Add / Edit Drawer */}
      {drawerOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setDrawerOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{drawerTitle}</h3>
              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>规则基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则ID <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedRule?.id || ''} placeholder="系统自动生成" readOnly={ruleEditMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规则名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedRule?.name || ''} placeholder="请输入规则名称" readOnly={ruleEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码总长度</label>
                    <input className="form-input font-mono" value="32位" readOnly />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                    <select className="form-input" defaultValue={selectedRule?.status || 'active'} disabled={ruleEditMode === 'view'}>
                      <option value="active">启用</option>
                      <option value="inactive">禁用</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>段位配置 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（共{editingSegments.reduce((sum, s) => sum + s.length, 0)}位）</span></h4>
                <div className="space-y-3">
                  {editingSegments.map((seg, idx) => (
                    <div key={seg.id} className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: `${segmentColorMap[(idx % 10) + 1]}05` }}>
                      <div className="flex items-center gap-2 mb-3">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: segmentColorMap[(idx % 10) + 1] }}>{idx + 1}</div>
                        <span className="font-medium text-sm">{seg.name || `段位${idx + 1}`}</span>
                        <span className="text-xs font-mono ml-2" style={{ color: segmentColorMap[(idx % 10) + 1] }}>{seg.length}位 &middot; {seg.type}</span>
                        {seg.required && <span className="text-xs text-red-400">*</span>}
                        <div className="ml-auto flex items-center gap-1">
                          {ruleEditMode !== 'view' && editingSegments.length > 1 && (
                            <button className="p-1 rounded hover:bg-red-50" onClick={() => handleDeleteSegment(seg.id)} title="删除段位">
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>段位名称</label>
                          <input className="form-input text-sm" value={seg.name} onChange={e => handleSegmentChange(seg.id, 'name', e.target.value)} readOnly={ruleEditMode === 'view'} />
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>长度</label>
                          <input className="form-input text-sm font-mono" type="number" min={1} max={20} value={seg.length} onChange={e => handleSegmentChange(seg.id, 'length', parseInt(e.target.value) || 1)} readOnly={ruleEditMode === 'view'} />
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>类型</label>
                          <select className="form-input text-sm" value={seg.type} onChange={e => handleSegmentChange(seg.id, 'type', e.target.value)} disabled={ruleEditMode === 'view'}>
                            <option>字母</option>
                            <option>数字</option>
                            <option>字母数字</option>
                          </select>
                        </div>
                        <div className="col-span-2">
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>取值方式</label>
                          <select className="form-input text-sm" value={seg.valueSource} onChange={e => handleSegmentChange(seg.id, 'valueSource', e.target.value)} disabled={ruleEditMode === 'view'}>
                            <option>固定值</option>
                            <option>关联字典</option>
                            <option>自动流水</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否必填</label>
                          <div className="flex items-center gap-2 h-[34px]">
                            <input type="checkbox" checked={seg.required} onChange={e => handleSegmentChange(seg.id, 'required', e.target.checked)} disabled={ruleEditMode === 'view'} className="w-4 h-4" />
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{seg.required ? '必填' : '选填'}</span>
                          </div>
                        </div>
                        {seg.valueSource === '固定值' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>固定值</label>
                            <input className="form-input text-sm font-mono" value={seg.fixedValue || ''} onChange={e => handleSegmentChange(seg.id, 'fixedValue', e.target.value)} placeholder="请输入固定值" readOnly={ruleEditMode === 'view'} />
                          </div>
                        )}
                        {seg.valueSource === '关联字典' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联字典 <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>（从编码字典中选择）</span></label>
                            <select className="form-input text-sm" value={seg.dictName || ''} onChange={e => handleSegmentChange(seg.id, 'dictName', e.target.value)} disabled={ruleEditMode === 'view'}>
                              <option value="">请选择字典</option>
                              <option>标签类别</option>
                              <option>一级分类</option>
                              <option>二级分类</option>
                              <option>三级分类</option>
                              <option>装备品种名称</option>
                              <option>型号编码</option>
                              <option>生产日期</option>
                              <option>有效期</option>
                              <option>供应商信用代码</option>
                            </select>
                          </div>
                        )}
                        {seg.valueSource === '自动流水' && (
                          <div className="col-span-3">
                            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>流水号归零方式</label>
                            <select className="form-input text-sm" value={seg.resetMode || '按年度归零'} onChange={e => handleSegmentChange(seg.id, 'resetMode', e.target.value)} disabled={ruleEditMode === 'view'}>
                              <option>按年度归零</option>
                              <option>按月度归零</option>
                              <option>永不归零</option>
                            </select>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                {ruleEditMode !== 'view' && (
                  <button className="btn-default text-xs mt-3" onClick={handleAddSegment}>
                    <span className="flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      添加段位
                    </span>
                  </button>
                )}
              </div>

              {selectedRule && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>编码预览</h4>
                  <div className="p-4 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="flex items-center gap-1 flex-wrap mb-2">
                      {generatePreviewCode(selectedRule).map((part, i) => (
                        <span key={i} className="flex items-center gap-1">
                          <span className="group relative text-sm font-mono px-1.5 py-0.5 rounded cursor-help" style={part.isPlaceholder ? { color: '#8c8c8c', background: '#f5f5f5', border: '1px dashed #d9d9d9' } : { color: segmentColorMap[i + 1], background: `${segmentColorMap[i + 1]}10` }}>
                            {part.display}
                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block text-xs whitespace-nowrap px-2 py-1 rounded text-white z-20" style={{ background: part.isPlaceholder ? '#8c8c8c' : segmentColorMap[i + 1] }}>
                              {part.segmentName}{part.isPlaceholder ? '（暂未生产）' : ''}
                            </span>
                          </span>
                          {i < generatePreviewCode(selectedRule).length - 1 && <span className="text-sm font-mono" style={{ color: 'var(--text-disabled)' }}>-</span>}
                        </span>
                      ))}
                    </div>
                    <p className="text-sm font-mono font-bold" style={{ color: 'var(--primary-blue)' }}>= {generatePreviewCode(selectedRule).map(p => p.display).join('-')}</p>
                    <p className="text-xs mt-2" style={{ color: 'var(--text-secondary)' }}>
                      共32位 | 通过编码可解析装备分类、名称、型号、生产日期、有效期、供应商、流水号等关键属性
                    </p>
                  </div>
                </div>
              )}

              {selectedRule && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>系统信息</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span><span>{selectedRule.createTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>更新时间：</span><span>{selectedRule.updateTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建人员：</span><span>管理员</span></div>
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setDrawerOpen(false)}>{ruleEditMode === 'view' ? '关闭' : '取消'}</button>
              {ruleEditMode !== 'view' && <button className="btn-primary">保存</button>}
            </div>
          </div>
        </>
      )}

      {/* Code Dict Drawer */}
      {dictDrawerOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setDictDrawerOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{dictDrawerTitle}</h3>
              <button onClick={() => setDictDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典项ID <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.id || ''} placeholder="系统自动生成" readOnly={dictEditMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>字典类型 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedDict?.dictType || ''} disabled={dictEditMode === 'view'}>
                      <option value="">请选择</option>
                      <option>标签类别</option>
                      <option>一级分类</option>
                      <option>二级分类</option>
                      <option>三级分类</option>
                      <option>装备品种名称</option>
                      <option>型号编码</option>
                      <option>生产日期</option>
                      <option>有效期</option>
                      <option>供应商信用代码</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>编码 <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.code || ''} placeholder="请输入编码" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedDict?.name || ''} placeholder="请输入名称" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                    <select className="form-input" defaultValue={selectedDict?.status || 'active'} disabled={dictEditMode === 'view'}>
                      <option value="active">启用</option>
                      <option value="inactive">禁用</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号</label>
                    <input className="form-input font-mono" type="number" min={0} defaultValue={selectedDict?.sortOrder || 0} readOnly={dictEditMode === 'view'} />
                  </div>
                </div>
              </div>

              {/* 扩展信息：保养周期 + 有效期 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-purple-500"/>扩展信息（可选）</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养周期（月）</label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.maintainCycle || ''} placeholder="如：3 表示每3个月" readOnly={dictEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>有效期（装备有效年限）</label>
                    <input className="form-input font-mono" defaultValue={selectedDict?.validityPeriod || ''} placeholder="如：5 表示5年" readOnly={dictEditMode === 'view'} />
                  </div>
                </div>
              </div>

              {(selectedDict?.parentCode || dictEditMode !== 'view') && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>上级分类</h4>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>上级编码</label>
                      <input className="form-input font-mono" defaultValue={selectedDict?.parentCode || ''} placeholder="请输入上级编码" readOnly={dictEditMode === 'view'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>上级名称</label>
                      <input className="form-input" defaultValue={selectedDict?.parentName || ''} placeholder="请输入上级名称" readOnly={dictEditMode === 'view'} />
                    </div>
                  </div>
                </div>
              )}

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>备注</h4>
                <div>
                  <textarea className="form-input w-full text-sm" rows={3} defaultValue={selectedDict?.remark || ''} placeholder="请输入备注信息..." readOnly={dictEditMode === 'view'} />
                </div>
              </div>

              {selectedDict && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>系统信息</h4>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span><span>{selectedDict.createTime}</span></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>创建人员：</span><span>管理员</span></div>
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setDictDrawerOpen(false)}>{dictEditMode === 'view' ? '关闭' : '取消'}</button>
              {dictEditMode !== 'view' && <button className="btn-primary">保存</button>}
            </div>
          </div>
        </>
      )}

      {/* Delete Confirmation Modal */}
      {deleteConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认删除</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除编码规则"<span className="font-medium">{selectedDeleteRule?.id}</span>"？<br/>规则名称：<span className="font-medium">{selectedDeleteRule?.name}</span><br/>删除后数据将无法恢复，请谨慎操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setDeleteConfirmOpen(false)}>取消</button>
              <button className="btn-danger" onClick={confirmDeleteRule}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* Code Apply Detail / Approve / Add Drawer */}
      {applyDetailOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setApplyDetailOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {applyViewMode === 'add' ? '新增编码申请' : applyViewMode === 'approve' ? `审批编码申请 - ${selectedApply?.id}` : applyViewMode === 'edit' ? `编辑编码申请 - ${selectedApply?.id}` : `编码申请详情 - ${selectedApply?.id}`}
              </h3>
              <button onClick={() => setApplyDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6">
              {/* 申请信息 */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>申请信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单号 {applyViewMode === 'add' && <span className="text-red-400">*</span>}</label>
                    <input className="form-input font-mono" defaultValue={selectedApply?.id || ''} placeholder="系统自动生成" readOnly={applyViewMode !== 'add'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                    <input className="form-input" defaultValue={selectedApply?.supplier || ''} placeholder="-" readOnly={applyViewMode === 'view'} />
                  </div>
                </div>
                {/* 新增：关联订单选择/显示 */}
                {applyViewMode === 'add' ? (
                  <>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单 <span className="text-red-400">*</span></label>
                      <select className="form-input text-sm" value={selectedOrderId} onChange={e => handleSelectOrder(e.target.value)}>
                        <option value="">请选择关联订单</option>
                        {orderOptions.map(o => (
                          <option key={o.id} value={o.id}>{o.no} · {o.equipName} · {o.supplier} · {o.qty}件</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                      <input className="form-input" value={orderOptions.find(o => o.id === selectedOrderId)?.supplier || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
                      <input className="form-input" defaultValue="当前用户" readOnly />
                    </div>
                  </>
                ) : (
                  <>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单 <span className="text-red-400">*</span></label>
                      <input className="form-input font-mono" defaultValue={selectedApply?.orderNo || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                      <input className="form-input" defaultValue={selectedApply?.supplier || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label>
                      <input className="form-input" defaultValue={selectedApply?.applicant || ''} readOnly />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请时间</label>
                      <input className="form-input" defaultValue={selectedApply?.applyTime || ''} readOnly />
                    </div>
                  </>
                )}
                <div className="col-span-2">
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                  <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedApply?.remark || ''} placeholder="请输入备注..." readOnly={applyViewMode === 'view'} />
                </div>
              </div>

              {/* 装备编码明细 - 选择订单后批量列出 */}
              {orderEquipList.length > 0 && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-purple-500"/>装备编码明细 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（共{orderEquipList.length}件装备）</span></h4>
                  </div>
                  <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                    {orderEquipList.map((eq, i) => (
                      <div key={eq.id} className="flex items-center gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                        <span className="text-xs font-medium" style={{ color: 'var(--text-disabled)' }}>{i + 1}</span>
                        <div className="flex-1 min-w-0">
                          <input className="form-input text-xs py-1.5 w-full" defaultValue={eq.equipName} placeholder="装备名称" readOnly={applyViewMode === 'view'} />
                        </div>
                        <div className="flex-[2] min-w-0">
                          <span className="font-mono text-xs block">{renderSplitCode(eq.code)}</span>
                          {eq.isPlaceholderCode && (
                            <span className="code-placeholder-badge mt-0.5 inline-block">待生产分配</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  {orderEquipList.some(e => e.isPlaceholderCode) && (
                    <div className="mt-3 p-3 rounded-lg border" style={{ borderColor: '#faad1430', background: '#fffbe6' }}>
                      <p className="text-xs flex items-center gap-1" style={{ color: '#d48806' }}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#d48806" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                        灰色部分（[日期]、[流水]）为占位符，表示生产日期和流水号将在实际生产时自动分配
                      </p>
                    </div>
                  )}
                </div>
              )}

              {/* 审批流程 */}
              {selectedApply && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>审批流程</h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>1</div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">采购人发起编码申请</p>
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedApply.applicant} 于 {selectedApply.applyTime} 提交申请</p>
                      </div>
                      <span className="tag tag-green text-xs">已完成</span>
                    </div>
                    {selectedApply.status !== 'pending' ? (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: selectedApply.status === 'rejected' ? '#ff4d4f' : '#52c41a' }}>2</div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">上级单位审批</p>
                          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedApply.approver} 于 {selectedApply.approveTime} {selectedApply.status === 'rejected' ? '驳回申请' : '审批通过'}</p>
                        </div>
                        <span className={`tag text-xs ${selectedApply.status === 'rejected' ? 'tag-red' : 'tag-green'}`}>{selectedApply.status === 'rejected' ? '已驳回' : '已通过'}</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#faad14' }}>2</div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">上级单位审批</p>
                          <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>等待审批中...</p>
                        </div>
                        <span className="tag tag-yellow text-xs">进行中</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              {applyViewMode === 'approve' && selectedApply?.status === 'pending' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-danger" onClick={() => handleApproveAction('reject')}>驳回</button>
                  <button className="btn-primary" onClick={() => handleApproveAction('approve')}>审批通过</button>
                </>
              ) : applyViewMode === 'add' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-primary" disabled={!selectedOrderId || orderEquipList.length === 0}>提交申请</button>
                </>
              ) : applyViewMode === 'edit' ? (
                <>
                  <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>取消</button>
                  <button className="btn-primary">保存修改</button>
                </>
              ) : (
                <button className="btn-default" onClick={() => setApplyDetailOpen(false)}>关闭</button>
              )}
            </div>
          </div>
        </>
      )}

      {/* Approve Confirm Modal */}
      {approveConfirmOpen && selectedApply && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setApproveConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: approveAction === 'approve' ? '#f6ffed' : '#fff2f0' }}>
                {approveAction === 'approve' ? (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                ) : (
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                )}
              </div>
              <h3 className="text-base font-semibold">{approveAction === 'approve' ? '确认审批通过' : '确认驳回'}</h3>
            </div>
            <div className="mb-5">
              <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                申请单号：<span className="font-mono font-medium">{selectedApply.id}</span><br/>
                供应商：<span>{selectedApply.supplier}</span><br/>
                装备名称：<span>{selectedApply.items[0]?.equipName || '-'}</span><br/>
                编码：<span className="font-mono">{selectedApply.items[0]?.code || '-'}</span><br/>
                申请数量：<span className="font-medium">{selectedApply.items.length} 件</span>
              </p>
              {approveAction === 'approve' && (
                <div className="p-3 rounded-lg border mb-3" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                  <p className="text-xs" style={{ color: '#52c41a' }}>审批通过后，预生成编码中的占位符部分（生产日期、流水号）将在实际生产时自动分配。</p>
                </div>
              )}
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{approveAction === 'approve' ? '审批意见（可选）' : '驳回原因'}</label>
              <textarea className="form-input w-full text-sm" rows={2} placeholder={approveAction === 'approve' ? '请输入审批意见...' : '请输入驳回原因...'} value={approveRemark} onChange={e => setApproveRemark(e.target.value)} />
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setApproveConfirmOpen(false)}>取消</button>
              <button className={approveAction === 'approve' ? 'btn-primary' : 'btn-danger'} onClick={confirmApproveAction}>
                {approveAction === 'approve' ? '确认通过并生成编码' : '确认驳回'}
              </button>
            </div>
          </div>
        </div>
      )}


      {/* ==================== 编码溯源 ==================== */}
      {activeTab === 'trace' && (
        <>
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm pb-1">
            <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setActiveTab('rule')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
              返回工作台
            </button>
            <span style={{ color: 'var(--text-disabled)' }}>/</span>
            <span style={{ color: 'var(--text-secondary)' }}>编码溯源</span>
          </div>

          {/* Toolbar: Import moved from coding management */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-default flex items-center gap-1 text-xs" onClick={openImportModal}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                导入Excel
              </button>
              <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setImportLogOpen(true)}>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="inline mr-0.5"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                导入日志
              </button>
            </div>
          </div>

          {/* Search */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入装备名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</label><input className="form-input font-mono w-40" placeholder="请输入装备编码" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>生产商</label><select className="form-input w-36"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>大疆创新科技有限公司</option><option>中兴通讯股份有限公司</option><option>烽火通信科技股份有限公司</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>在库</option><option>出库</option><option>维修中</option><option>已报废</option></select></div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default">重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>

          {/* Trace list table */}
          <div className="content-card overflow-x-auto">
            <table className="data-table" style={{ minWidth: '900px' }}>
              <thead>
                <tr>
                  <th>装备编码</th>
                  <th>装备名称</th>
                  <th>规格型号</th>
                  <th>生产商</th>
                  <th>使用单位</th>
                  <th>当前所属</th>
                  <th>状态</th>
                  <th>入库时间</th>
                  <th>最近操作</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {traceData
                  .filter(t => !traceSearchCode || t.code.includes(traceSearchCode) || t.equipName.includes(traceSearchCode))
                  .map(t => (
                    <tr key={t.id}>
                      <td className="font-mono text-xs whitespace-nowrap" style={{ minWidth: '280px' }}>{t.code}</td>
                      <td className="text-sm font-medium">{t.equipName}</td>
                      <td className="text-xs">{t.spec}</td>
                      <td className="text-xs">{t.manufacturer}</td>
                      <td className="text-xs">{t.usingUnit}</td>
                      <td className="text-xs">{t.currentOwner}</td>
                      <td>
                        <span className="tag text-xs px-2 py-0.5" style={{
                          background: t.status === 'in_stock' ? '#f6ffed' : t.status === 'in_use' ? '#e6f7ff' : t.status === 'under_repair' ? '#fff2f0' : t.status === 'transferred' ? '#fffbe6' : '#f5f5f5',
                          color: t.status === 'in_stock' ? '#52c41a' : t.status === 'in_use' ? '#1890ff' : t.status === 'under_repair' ? '#ff4d4f' : t.status === 'transferred' ? '#faad14' : '#8c8c8c',
                          border: `1px solid ${t.status === 'in_stock' ? '#b7eb8f' : t.status === 'in_use' ? '#91d5ff' : t.status === 'under_repair' ? '#ffccc7' : t.status === 'transferred' ? '#ffe58f' : '#d9d9d9'}`
                        }}>
                          {t.status === 'in_stock' ? '在库' : t.status === 'in_use' ? '在用' : t.status === 'under_repair' ? '维修中' : t.status === 'transferred' ? '调拨中' : '已报废'}
                        </span>
                      </td>
                      <td className="text-xs">{t.warehouseTime}</td>
                      <td>
                        <span className="text-xs">{t.lastOperationType}</span>
                        <br/>
                        <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{t.lastOperationTime}</span>
                      </td>
                      <td>
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedTraceRecord(t); setTraceDetailOpen(true) }}>查看详情</button>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Change Log Modal */}
      {changelogOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setChangelogOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                </div>
                <h3 className="text-base font-semibold">变更记录 - {selectedChangelogRuleId}</h3>
              </div>
              <button onClick={() => setChangelogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).length === 0 ? (
                <div className="text-center py-12">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>暂无变更记录</p>
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更字段</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更前值</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更后值</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>变更原因</th>
                    </tr>
                  </thead>
                  <tbody>
                    {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).map(l => (
                      <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="px-3 py-2 font-mono text-xs">{l.id}</td>
                        <td className="px-3 py-2">{l.operator}</td>
                        <td className="px-3 py-2 text-xs">{l.time}</td>
                        <td className="px-3 py-2 font-medium">{l.field}</td>
                        <td className="px-3 py-2"><span className="text-xs" style={{ color: '#ff4d4f' }}>{l.oldValue}</span></td>
                        <td className="px-3 py-2"><span className="text-xs" style={{ color: '#52c41a' }}>{l.newValue}</span></td>
                        <td className="px-3 py-2 text-xs max-w-xs truncate" title={l.reason}>{l.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {changeLogData.filter(l => l.ruleId === selectedChangelogRuleId).length} 条记录</span>
              <button className="btn-default text-xs" onClick={() => setChangelogOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Import Modal (4-Step Wizard) ===== */}
      {importModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={closeImportModal} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[960px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                </div>
                <div>
                  <h3 className="text-base font-semibold">批量导入装备编码</h3>
                  {importFileName && <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{importFileName}</p>}
                </div>
              </div>
              <button onClick={closeImportModal} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Step Indicator */}
            <div className="px-6 py-3 border-b flex items-center gap-0" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
              {[
                { key: 'upload', label: '上传文件', icon: 'M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M17 8l-5-5-5 5M12 3v12' },
                { key: 'preview', label: '核对预览', icon: 'M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zm11 0a4 4 0 100-8 4 4 0 000 8z' },
                { key: 'confirm', label: '确认导入', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
                { key: 'done', label: '完成', icon: 'M22 11.08V12a10 10 0 11-5.93-9.14M22 4L12 14.01l-3-3' },
              ].map((s, i) => {
                const stepOrder = ['upload', 'preview', 'confirm', 'done']
                const currentIdx = stepOrder.indexOf(importStep)
                const stepIdx = stepOrder.indexOf(s.key)
                const isActive = stepIdx === currentIdx
                const isDone = stepIdx < currentIdx
                return (
                  <div key={s.key} className="flex items-center">
                    <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg" style={{
                      background: isActive ? '#e6f7ff' : 'transparent',
                    }}>
                      <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs text-white" style={{
                        background: isActive ? '#1890ff' : isDone ? '#52c41a' : '#d9d9d9'
                      }}>{isDone ? (<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>) : i + 1}</div>
                      <span className="text-xs font-medium" style={{ color: isActive ? '#1890ff' : isDone ? '#52c41a' : '#8c8c8c' }}>{s.label}</span>
                    </div>
                    {i < 3 && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-1"><polyline points="9 18 15 12 9 6"/></svg>}
                  </div>
                )
              })}
            </div>

            {/* Body */}
            <div className="flex-1 overflow-auto p-6">
              {/* === Step 1: Upload === */}
              {importStep === 'upload' && (
                <div className="space-y-4">
                  <div className="p-8 rounded-xl border-2 border-dashed text-center" style={{ borderColor: '#d9d9d9', background: '#fafafa' }}>
                    <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#e6f7ff' }}>
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    </div>
                    <p className="text-sm font-medium mb-1">点击上传或拖拽Excel文件到此处</p>
                    <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>支持 .xlsx、.xls、.csv 格式，文件大小不超过10MB</p>
                    <label className="btn-primary cursor-pointer inline-flex items-center gap-1">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      选择文件
                      <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFileUpload} />
                    </label>
                  </div>
                  {importError && (
                    <div className="p-3 rounded-lg border flex items-center gap-2" style={{ borderColor: '#ff4d4f', background: '#fff2f0' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                      <span className="text-xs" style={{ color: '#ff4d4f' }}>{importError}</span>
                    </div>
                  )}
                  <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <h5 className="text-xs font-semibold mb-2" style={{ color: 'var(--text-secondary)' }}>模板字段说明</h5>
                    <div className="grid grid-cols-4 gap-2 text-xs">
                      <span><span className="text-red-400">*</span> 关联订单</span>
                      <span><span className="text-red-400">*</span> 装备名称</span>
                      <span><span className="text-red-400">*</span> 供应商</span>
                      <span><span className="text-red-400">*</span> 编码</span>
                    </div>
                  </div>
                </div>
              )}

              {/* === Step 2: Preview / Check === */}
              {(importStep === 'preview' || importStep === 'confirm') && (
                <div className="space-y-4">
                  {/* Stats */}
                  <div className="flex gap-3">
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#52c41a40', background: '#f6ffed', color: '#52c41a' }}>
                      一致 {importRows.filter(r => r.checkResult === 'match').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#ff4d4f40', background: '#fff2f0', color: '#ff4d4f' }}>
                      冲突 {importRows.filter(r => r.checkResult === 'conflict').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#1890ff40', background: '#e6f7ff', color: '#1890ff' }}>
                      新建 {importRows.filter(r => r.checkResult === 'new').length}
                    </span>
                    <span className="px-3 py-1.5 rounded-full text-xs border" style={{ borderColor: '#8c8c8c40', background: '#f5f5f5', color: '#8c8c8c' }}>
                      跳过 {importRows.filter(r => r.resolution === 'skip').length}
                    </span>
                  </div>

                  {/* Batch actions for conflicts */}
                  {importRows.some(r => r.checkResult === 'conflict') && importStep === 'preview' && (
                    <div className="flex items-center gap-2 p-3 rounded-lg border" style={{ borderColor: '#faad1430', background: '#fffbe6' }}>
                      <span className="text-xs font-medium" style={{ color: '#d48806' }}>冲突处理：</span>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#b7eb8f', background: '#f6ffed', color: '#52c41a' }} onClick={() => batchResolution('conflict', 'system')}>全部以系统为准</button>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#ff4d4f30', background: '#fff2f0', color: '#ff4d4f' }} onClick={() => batchResolution('conflict', 'excel')}>全部以Excel为准</button>
                      <button className="text-xs px-2 py-1 rounded border" style={{ borderColor: '#d9d9d9', background: '#f5f5f5', color: '#8c8c8c' }} onClick={() => batchResolution('conflict', 'skip')}>全部跳过</button>
                    </div>
                  )}

                  {/* Preview Table */}
                  <div className="border rounded-lg overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)', width: 32 }}><input type="checkbox" checked={importRows.every(r => r.selected)} onChange={() => {}} /></th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)', width: 40 }}>行号</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>关联订单</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>装备名称</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>核对状态</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>Excel编码</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>系统编码</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>冲突原因</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>处理方式</th>
                        </tr>
                      </thead>
                      <tbody>
                        {importRows.map(row => (
                          <tr key={row.id} className="border-b" style={{ borderColor: 'var(--border-color)', opacity: row.resolution === 'skip' ? 0.5 : 1 }}>
                            <td className="px-2 py-2"><input type="checkbox" checked={row.selected} onChange={() => toggleRowSelected(row.id)} /></td>
                            <td className="px-2 py-2 text-xs" style={{ color: 'var(--text-disabled)' }}>{row.rowNum}</td>
                            <td className="px-2 py-2 font-mono text-xs">{row.orderNo}</td>
                            <td className="px-2 py-2 text-xs font-medium">{row.equipName}</td>
                            <td className="px-2 py-2">
                              <span className="tag text-xs px-1.5 py-0.5" style={{ background: checkResultConfig[row.checkResult].bg, color: checkResultConfig[row.checkResult].color, border: `1px solid ${checkResultConfig[row.checkResult].color}30` }}>
                                {checkResultConfig[row.checkResult].label}
                              </span>
                            </td>
                            <td className="px-2 py-2 font-mono text-xs">{row.excelCode}</td>
                            <td className="px-2 py-2 font-mono text-xs">{row.systemCode}</td>
                            <td className="px-2 py-2 text-xs" style={{ color: row.checkResult === 'conflict' ? '#ff4d4f' : 'var(--text-secondary)' }}>{row.conflictReason || '-'}</td>
                            <td className="px-2 py-2">
                              <select className="form-input text-xs py-1" value={row.resolution} onChange={e => setRowResolution(row.id, e.target.value as ConflictResolution)}>
                                <option value="system">系统编码</option>
                                <option value="excel">Excel编码</option>
                                <option value="skip">跳过</option>
                              </select>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* === Step 4: Done === */}
              {importStep === 'done' && (
                <div className="text-center py-12">
                  <div className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: '#f6ffed' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                  </div>
                  <h4 className="text-lg font-semibold mb-2" style={{ color: '#52c41a' }}>导入成功</h4>
                  <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>
                    共处理 {importRows.length} 条记录：
                    {importRows.filter(r => r.checkResult === 'match').length} 条一致、
                    {importRows.filter(r => r.checkResult === 'conflict').length} 条冲突已处理、
                    {importRows.filter(r => r.checkResult === 'new').length} 条新建
                  </p>
                  <div className="p-4 rounded-lg border max-w-md mx-auto text-left" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作人：管理员</p>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作时间：{new Date().toISOString().slice(0, 16).replace('T', ' ')}</p>
                    <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>文件名：{importFileName}</p>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>导入数量：{importRows.filter(r => r.resolution !== 'skip').length} 条</p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                {importStep === 'preview' && `共 ${importRows.length} 条 · 已选 ${importRows.filter(r => r.selected).length} 条`}
                {importStep === 'confirm' && `即将导入 ${importRows.filter(r => r.selected && r.resolution !== 'skip').length} 条编码`}
              </span>
              <div className="flex items-center gap-3">
                {importStep === 'upload' && (
                  <button className="btn-default text-xs" onClick={closeImportModal}>取消</button>
                )}
                {(importStep === 'preview' || importStep === 'confirm') && (
                  <>
                    <button className="btn-default text-xs" onClick={closeImportModal}>取消</button>
                    <button className="btn-default text-xs" onClick={() => setImportStep('preview')}>返回核对</button>
                    {importStep === 'preview' ? (
                      <button className="btn-primary text-xs" onClick={() => setImportStep('confirm')}>
                        下一步：确认导入
                      </button>
                    ) : (
                      <button className="btn-primary text-xs" onClick={confirmImport}>
                        确认导入并绑定装备
                      </button>
                    )}
                  </>
                )}
                {importStep === 'done' && (
                  <button className="btn-primary text-xs" onClick={closeImportModal}>完成</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Import Log Modal ===== */}
      {importLogOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setImportLogOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                </div>
                <h3 className="text-base font-semibold">编码导入日志</h3>
              </div>
              <button onClick={() => setImportLogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-auto p-6">
              {importLogs.length === 0 ? (
                <div className="text-center py-12">
                  <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>
                  <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>暂无导入记录</p>
                </div>
              ) : (
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>时间</th>
                      <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>文件名</th>
                      <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>总数</th>
                      <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>一致</th>
                      <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>冲突</th>
                      <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>新建</th>
                      <th className="px-3 py-2 text-right text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>跳过</th>
                    </tr>
                  </thead>
                  <tbody>
                    {importLogs.map(l => (
                      <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="px-3 py-2 font-mono text-xs">{l.id}</td>
                        <td className="px-3 py-2">{l.operator}</td>
                        <td className="px-3 py-2 text-xs">{l.time}</td>
                        <td className="px-3 py-2 text-xs font-medium">{l.filename}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs">{l.totalCount}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#52c41a' }}>{l.matchCount}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#ff4d4f' }}>{l.conflictCount}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#1890ff' }}>{l.newCount}</td>
                        <td className="px-3 py-2 text-right font-mono text-xs" style={{ color: '#8c8c8c' }}>{l.skipCount}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              {importLogs.length > 0 && (
                <div className="mt-4 space-y-2">
                  {importLogs.map(l => (
                    <div key={l.id + '_detail'} className="p-3 rounded-lg border text-xs" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{l.details}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {importLogs.length} 条记录</span>
              <button className="btn-default text-xs" onClick={() => setImportLogOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Trace Detail Modal ===== */}
      {traceDetailOpen && selectedTraceRecord && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTraceDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[90vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                </div>
                <div>
                  <h3 className="text-base font-semibold">编码溯源详情</h3>
                  <p className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedTraceRecord.code}</p>
                </div>
              </div>
              <button onClick={() => setTraceDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Body */}
            <div className="flex-1 overflow-auto p-6 space-y-6">
              {/* Basic Info */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本档案</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</span>
                    <span className="font-mono text-xs">{selectedTraceRecord.code}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</span>
                    <span className="text-sm font-medium">{selectedTraceRecord.equipName}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>规格型号</span>
                    <span className="text-xs">{selectedTraceRecord.spec}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>生产商</span>
                    <span className="text-xs">{selectedTraceRecord.manufacturer}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</span>
                    <span className="text-xs">{selectedTraceRecord.supplier}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>当前状态</span>
                    <span className="tag text-xs px-2 py-0.5" style={{
                      background: selectedTraceRecord.status === 'in_stock' ? '#f6ffed' : selectedTraceRecord.status === 'in_use' ? '#e6f7ff' : selectedTraceRecord.status === 'under_repair' ? '#fff2f0' : selectedTraceRecord.status === 'transferred' ? '#fffbe6' : '#f5f5f5',
                      color: selectedTraceRecord.status === 'in_stock' ? '#52c41a' : selectedTraceRecord.status === 'in_use' ? '#1890ff' : selectedTraceRecord.status === 'under_repair' ? '#ff4d4f' : selectedTraceRecord.status === 'transferred' ? '#faad14' : '#8c8c8c',
                      border: `1px solid ${selectedTraceRecord.status === 'in_stock' ? '#b7eb8f' : selectedTraceRecord.status === 'in_use' ? '#91d5ff' : selectedTraceRecord.status === 'under_repair' ? '#ffccc7' : selectedTraceRecord.status === 'transferred' ? '#ffe58f' : '#d9d9d9'}`
                    }}>
                      {selectedTraceRecord.status === 'in_stock' ? '在库' : selectedTraceRecord.status === 'in_use' ? '在用' : selectedTraceRecord.status === 'under_repair' ? '维修中' : selectedTraceRecord.status === 'transferred' ? '调拨中' : '已报废'}
                    </span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>使用单位</span>
                    <span className="text-xs font-medium">{selectedTraceRecord.usingUnit}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>当前所属</span>
                    <span className="text-xs font-medium">{selectedTraceRecord.currentOwner}</span>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>入库时间</span>
                    <span className="text-xs">{selectedTraceRecord.warehouseTime}</span>
                  </div>
                </div>
              </div>

              {/* Lifecycle Timeline */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>全生命周期记录</h4>
                <div className="relative pl-6">
                  {/* Timeline line */}
                  <div className="absolute left-2 top-0 bottom-0 w-px" style={{ background: 'var(--border-color)' }} />
                  <div className="space-y-4">
                    {selectedTraceRecord.lifecycle.map((ev) => {
                      const typeColors: Record<string, string> = { 入库: '#52c41a', 出库: '#1890ff', 使用: '#722ed1', 维修: '#ff4d4f', 调拨: '#faad14', 盘点: '#13c2c2', 报废: '#8c8c8c' }
                      const typeBgs: Record<string, string> = { 入库: '#f6ffed', 出库: '#e6f7ff', 使用: '#f9f0ff', 维修: '#fff2f0', 调拨: '#fffbe6', 盘点: '#e6fffb', 报废: '#f5f5f5' }
                      return (
                        <div key={ev.id} className="relative flex items-start gap-3">
                          <div className="absolute -left-4 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center" style={{ background: typeColors[ev.type] || '#d9d9d9', top: 2 }} />
                          <div className="flex-1 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="tag text-xs px-2 py-0.5" style={{ background: typeBgs[ev.type], color: typeColors[ev.type], border: `1px solid ${typeColors[ev.type]}30` }}>{ev.type}</span>
                              <span className="text-xs font-medium">{ev.time}</span>
                              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{ev.operator} &middot; {ev.unit}</span>
                            </div>
                            <p className="text-sm">{ev.description}</p>
                            {ev.detail && <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{ev.detail}</p>}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {selectedTraceRecord.lifecycle.length} 条生命周期记录</span>
              <button className="btn-default text-xs" onClick={() => setTraceDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
