import { useState } from 'react'

export default function WarehouseVisPage() {
  const [viewMode, setViewMode] = useState<'building' | 'location' | 'realtime' | 'business'>('building')
  const [selectedBuilding, setSelectedBuilding] = useState('A栋仓库')
  const [selectedFloor, setSelectedFloor] = useState('1层')

  const buildings = [
    { name: 'A栋仓库', area: 3200, floors: 3, rooms: 42, date: '2024-01-10' },
    { name: 'B栋装备室', area: 1800, floors: 2, rooms: 28, date: '2024-01-15' },
  ]

  const floors = ['1层', '2层', '3层']

  const rooms = [
    { id: '101', name: '仓库房', area: 85, status: 'normal', equipment: 12 },
    { id: '102', name: '设备间', area: 45, status: 'normal', equipment: 8 },
    { id: '103', name: '暂存区', area: 60, status: 'warning', equipment: 3 },
    { id: '104', name: '检验室', area: 35, status: 'normal', equipment: 5 },
    { id: '105', name: '发货区', area: 50, status: 'normal', equipment: 0 },
  ]

  const buildingColors: Record<string, string> = {
    normal: '#52c41a',
    warning: '#faad14',
    error: '#ff4d4f',
    empty: '#1890ff',
  }

  const viewModes = [
    { key: 'building' as const, label: '建筑可视化', icon: '🏠' },
    { key: 'location' as const, label: '存放位置', icon: '📍' },
    { key: 'realtime' as const, label: '实时监控', icon: '📊' },
    { key: 'business' as const, label: '业务动态', icon: '📈' },
  ]

  return (
    <div className="p-6 space-y-4">
      {/* View mode tabs */}
      <div className="flex items-center gap-2">
        {viewModes.map(mode => (
          <button
            key={mode.key}
            onClick={() => setViewMode(mode.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              viewMode === mode.key
                ? 'text-white shadow-md'
                : 'border hover:border-blue-400 hover:text-blue-500'
            }`}
            style={{
              background: viewMode === mode.key ? 'var(--primary-blue)' : '#fff',
              borderColor: viewMode === mode.key ? 'var(--primary-blue)' : 'var(--border-color)',
              color: viewMode === mode.key ? '#fff' : 'var(--text-secondary)',
            }}
          >
            {mode.label}
          </button>
        ))}
        <div className="ml-auto flex items-center gap-3">
          <select
            className="form-input w-40"
            value={selectedBuilding}
            onChange={e => setSelectedBuilding(e.target.value)}
          >
            {buildings.map(b => <option key={b.name} value={b.name}>{b.name}</option>)}
          </select>
          <select
            className="form-input w-32"
            value={selectedFloor}
            onChange={e => setSelectedFloor(e.target.value)}
          >
            {floors.map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
      </div>

      {/* Building View */}
      {viewMode === 'building' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 3D View placeholder */}
          <div className="lg:col-span-2 content-card p-0 overflow-hidden" style={{ height: 520 }}>
            <div className="relative w-full h-full flex items-center justify-center" style={{ background: 'linear-gradient(135deg, #001529 0%, #00284d 50%, #001529 100%)' }}>
              {/* Grid floor */}
              <div className="absolute inset-0" style={{
                backgroundImage: 'linear-gradient(rgba(24,144,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(24,144,255,0.1) 1px, transparent 1px)',
                backgroundSize: '40px 40px',
                transform: 'perspective(500px) rotateX(60deg)',
                transformOrigin: 'center bottom',
              }} />
              {/* Building wireframe */}
              <div className="relative z-10">
                <svg width="400" height="300" viewBox="0 0 400 300">
                  {/* Building outline */}
                  <rect x="50" y="50" width="300" height="200" fill="none" stroke="#1890ff" strokeWidth="2" opacity="0.6" rx="4"/>
                  <rect x="70" y="70" width="260" height="160" fill="rgba(24,144,255,0.05)" stroke="#1890ff" strokeWidth="1" opacity="0.4" rx="2"/>
                  {/* Room divisions */}
                  <line x1="50" y1="110" x2="350" y2="110" stroke="#1890ff" strokeWidth="1" opacity="0.3"/>
                  <line x1="50" y1="170" x2="350" y2="170" stroke="#1890ff" strokeWidth="1" opacity="0.3"/>
                  <line x1="130" y1="50" x2="130" y2="250" stroke="#1890ff" strokeWidth="1" opacity="0.3"/>
                  <line x1="210" y1="50" x2="210" y2="250" stroke="#1890ff" strokeWidth="1" opacity="0.3"/>
                  <line x1="290" y1="50" x2="290" y2="250" stroke="#1890ff" strokeWidth="1" opacity="0.3"/>
                  {/* Room labels */}
                  {[
                    { x: 90, y: 85, label: '101' },
                    { x: 170, y: 85, label: '102' },
                    { x: 250, y: 85, label: '103' },
                    { x: 320, y: 85, label: '104' },
                    { x: 90, y: 145, label: '105' },
                    { x: 170, y: 145, label: '106' },
                    { x: 250, y: 145, label: '107' },
                    { x: 320, y: 145, label: '108' },
                  ].map(room => (
                    <g key={room.label}>
                      <rect x={room.x - 25} y={room.y - 15} width="50" height="30" rx="4" fill="rgba(82,196,26,0.2)" stroke="#52c41a" strokeWidth="1"/>
                      <text x={room.x} y={room.y + 5} textAnchor="middle" fill="#52c41a" fontSize="12" fontFamily="JetBrains Mono">{room.label}</text>
                    </g>
                  ))}
                  {/* Axis labels */}
                  <text x="200" y="280" textAnchor="middle" fill="rgba(255,255,255,0.5)" fontSize="12">BIM 三维模型渲染区</text>
                </svg>
              </div>
              {/* Controls overlay */}
              <div className="absolute bottom-4 left-4 flex items-center gap-2">
                <button className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-all">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="11" y1="8" x2="11" y2="14"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
                </button>
                <button className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-all">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><line x1="8" y1="11" x2="14" y2="11"/></svg>
                </button>
                <button className="p-2 rounded-lg bg-white/10 text-white hover:bg-white/20 transition-all">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M23 4v6h-6"/><path d="M1 20v-6h6"/><path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/></svg>
                </button>
                <button className="px-3 py-2 rounded-lg bg-white/10 text-white text-xs hover:bg-white/20 transition-all">全屏</button>
              </div>
            </div>
          </div>

          {/* Info panel */}
          <div className="space-y-4">
            {/* Building info */}
            <div className="content-card p-5">
              <h4 className="font-semibold mb-3 flex items-center gap-2" style={{ color: 'var(--text-primary)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="var(--primary-blue)"><path d="M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z"/></svg>
                当前建筑信息
              </h4>
              {buildings.filter(b => b.name === selectedBuilding).map(b => (
                <div key={b.name} className="space-y-2 text-sm">
                  <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>建筑名称</span><span style={{ color: 'var(--text-primary)' }} className="font-medium">{b.name}</span></div>
                  <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>建筑面积</span><span style={{ color: 'var(--text-primary)' }}>{b.area}㎡</span></div>
                  <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>楼层数</span><span style={{ color: 'var(--text-primary)' }}>{b.floors}层</span></div>
                  <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>房间数</span><span style={{ color: 'var(--text-primary)' }}>{b.rooms}间</span></div>
                  <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>建模时间</span><span style={{ color: 'var(--text-primary)' }}>{b.date}</span></div>
                </div>
              ))}
            </div>

            {/* Floor distribution */}
            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>楼层分布统计</h4>
              <div className="space-y-3">
                {floors.map((floor, i) => (
                  <div key={floor}>
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span style={{ color: 'var(--text-secondary)' }}>{floor}</span>
                      <span style={{ color: 'var(--text-primary)' }}>{[14, 16, 12][i]}间 / {[1100, 1200, 900][i]}㎡</span>
                    </div>
                    <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                      <div className="h-full rounded-full transition-all duration-1000" style={{
                        width: `${[85, 95, 70][i]}%`,
                        background: `linear-gradient(90deg, var(--primary-blue), #69c0ff)`,
                      }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Room list */}
            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>房间清单</h4>
              <div className="space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
                {rooms.map(room => (
                  <div key={room.id} className="flex items-center justify-between p-2 rounded-lg hover:bg-blue-50 transition-colors cursor-pointer">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium font-mono" style={{ color: 'var(--text-primary)' }}>{room.id}</span>
                      <span className="text-sm" style={{ color: 'var(--text-secondary)' }}>{room.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{room.area}㎡</span>
                      <span className="status-dot online" style={{ background: buildingColors[room.status] }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Location View */}
      {viewMode === 'location' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 content-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold" style={{ color: 'var(--text-primary)' }}>存放位置映射</h4>
              <div className="flex items-center gap-3 text-xs">
                <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" defaultChecked className="accent-blue-500"/> 在库装备</label>
                <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" defaultChecked className="accent-blue-500"/> 空闲库位</label>
                <label className="flex items-center gap-1 cursor-pointer"><input type="checkbox" className="accent-blue-500"/> 异常</label>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {Array.from({ length: 20 }).map((_, i) => {
                const status = ['normal', 'normal', 'normal', 'warning', 'empty', 'normal'][i % 6]
                return (
                  <div key={i} className="rounded-lg p-3 border text-center cursor-pointer transition-all hover:scale-105 hover:shadow-md" style={{
                    borderColor: buildingColors[status],
                    background: `${buildingColors[status]}10`,
                  }}>
                    <div className="text-xs font-mono font-medium" style={{ color: buildingColors[status] }}>A-101-{String(i + 1).padStart(2, '0')}</div>
                    <div className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>
                      {status === 'empty' ? '空闲' : `${Math.floor(Math.random() * 8) + 1}件`}
                    </div>
                  </div>
                )
              })}
            </div>
            <div className="flex items-center gap-4 mt-4 text-xs">
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ background: buildingColors.normal }}/> 正常</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ background: buildingColors.warning }}/> 预警</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ background: buildingColors.error }}/> 异常</span>
              <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-sm" style={{ background: buildingColors.empty }}/> 空闲</span>
            </div>
          </div>
          <div className="content-card p-5">
            <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>库位详情</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>库位</span><span className="font-mono">A-102-03</span></div>
              <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>房间</span><span>102 设备间</span></div>
              <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>存放装备</span><span>3 件</span></div>
            </div>
            <div className="mt-4">
              <table className="w-full text-xs">
                <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="px-2 py-1 text-left">编码</th><th className="px-2 py-1 text-left">名称</th><th className="px-2 py-1 text-left">状态</th></tr></thead>
                <tbody>
                  <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}><td className="px-2 py-1 font-mono">ZB001</td><td className="px-2 py-1">手持终端</td><td className="px-2 py-1"><span className="tag tag-green">在库</span></td></tr>
                  <tr className="border-b" style={{ borderColor: 'var(--border-color)' }}><td className="px-2 py-1 font-mono">ZB002</td><td className="px-2 py-1">对讲机</td><td className="px-2 py-1"><span className="tag tag-green">在库</span></td></tr>
                  <tr><td className="px-2 py-1 font-mono">ZB003</td><td className="px-2 py-1">手电筒</td><td className="px-2 py-1"><span className="tag tag-green">在库</span></td></tr>
                </tbody>
              </table>
            </div>
            <div className="flex gap-2 mt-4">
              <button className="btn-primary text-xs flex-1">查看详情</button>
              <button className="btn-default text-xs flex-1">打印标签</button>
            </div>
          </div>
        </div>
      )}

      {/* Realtime View */}
      {viewMode === 'realtime' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 content-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold" style={{ color: 'var(--text-primary)' }}>实时监控</h4>
              <select className="form-input w-40 text-xs">
                <option>全部传感器</option>
                <option>温湿度</option>
                <option>光照</option>
                <option>烟感</option>
              </select>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {Array.from({ length: 16 }).map((_, i) => {
                const temp = 20 + Math.random() * 15
                const color = temp > 30 ? '#ff4d4f' : temp > 25 ? '#faad14' : '#52c41a'
                return (
                  <div key={i} className="rounded-lg p-3 border text-center" style={{ borderColor: `${color}30`, background: `${color}08` }}>
                    <div className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>A-102-{String(i + 1).padStart(2, '0')}</div>
                    <div className="text-lg font-bold my-1" style={{ color, fontFamily: 'JetBrains Mono' }}>{temp.toFixed(1)}°C</div>
                    <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{(40 + Math.random() * 30).toFixed(0)}%湿度</div>
                  </div>
                )
              })}
            </div>
          </div>
          <div className="space-y-4">
            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>实时数据总览</h4>
              <div className="space-y-3">
                <div className="flex items-center justify-between"><span style={{ color: 'var(--text-secondary)' }}>平均温度</span><span className="font-bold" style={{ fontFamily: 'JetBrains Mono' }}>24.5°C</span></div>
                <div className="flex items-center justify-between"><span style={{ color: 'var(--text-secondary)' }}>平均湿度</span><span className="font-bold" style={{ fontFamily: 'JetBrains Mono' }}>62%</span></div>
                <div className="flex items-center justify-between"><span style={{ color: 'var(--text-secondary)' }}>烟感状态</span><span className="tag tag-green">正常 x12</span></div>
                <div className="flex items-center justify-between"><span style={{ color: 'var(--text-secondary)' }}>异常传感器</span><span className="tag tag-red">1 个</span></div>
              </div>
            </div>
            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>异常预警</h4>
              <div className="space-y-2">
                <div className="p-2 rounded-lg border-l-4" style={{ borderLeftColor: '#ff4d4f', background: '#fff2f0' }}>
                  <p className="text-xs font-medium" style={{ color: '#ff4d4f' }}>A-103 温度 32°C 超过阈值</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Business View */}
      {viewMode === 'business' && (
        <div className="content-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold" style={{ color: 'var(--text-primary)' }}>业务动态</h4>
            <div className="flex items-center gap-2 text-xs">
              <span>时间轴控制：</span>
              <button className="p-1 rounded hover:bg-gray-100"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5"/></svg></button>
              <span>2024-03-15</span>
              <button className="p-1 rounded hover:bg-gray-100"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19"/></svg></button>
              <button className="btn-primary text-xs px-2 py-1">播放</button>
              <span style={{ color: 'var(--text-disabled)' }}>速度: 1x</span>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-4 mb-6">
            <div className="text-center p-4 rounded-lg" style={{ background: '#e6f7ff' }}>
              <div className="text-2xl font-bold" style={{ color: '#1890ff' }}>12</div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>今日入库</div>
            </div>
            <div className="text-center p-4 rounded-lg" style={{ background: '#fff7e6' }}>
              <div className="text-2xl font-bold" style={{ color: '#faad14' }}>8</div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>今日出库</div>
            </div>
            <div className="text-center p-4 rounded-lg" style={{ background: '#fffbe6' }}>
              <div className="text-2xl font-bold" style={{ color: '#faad14' }}>3</div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>维修中</div>
            </div>
            <div className="text-center p-4 rounded-lg" style={{ background: '#e6fffb' }}>
              <div className="text-2xl font-bold" style={{ color: '#13c2c2' }}>2</div>
              <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>调拨中</div>
            </div>
          </div>
          <div className="space-y-2">
            {[
              { time: '10:23', action: 'A-102 入库 5件', user: '张三', type: 'in' },
              { time: '10:15', action: 'A-105 出库 2件', user: '李四', type: 'out' },
              { time: '09:58', action: 'A-101 维修完成', user: '王五', type: 'repair' },
            ].map((event, i) => (
              <div key={i} className="flex items-center gap-4 p-3 rounded-lg border hover:shadow-sm transition-all" style={{ borderColor: 'var(--border-color)' }}>
                <span className="text-xs font-mono" style={{ color: 'var(--text-disabled)' }}>{event.time}</span>
                <span className={`w-2 h-2 rounded-full flex-shrink-0 ${event.type === 'in' ? 'status-dot online' : event.type === 'out' ? 'status-dot warning' : 'status-dot offline'}`} style={{
                  background: event.type === 'in' ? '#52c41a' : event.type === 'out' ? '#faad14' : '#ff4d4f',
                }} />
                <span className="text-sm flex-1" style={{ color: 'var(--text-primary)' }}>{event.action}</span>
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{event.user}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
