import { useState, useEffect } from 'react'
import { contractData } from './ProcurementPage'



interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
  contractData?: any[]
  orderData?: any[]
}



const tabList = [
  { key: 'enterprise', label: '供应商信息' },
  { key: 'product', label: '装备管理' },
  { key: 'penalty', label: '处罚管理' },
  { key: 'complaint', label: '投诉管理' },
]



type EnterpriseType = 'producer' | 'supplier'

type ProductStatus = 'review' | 'on' | 'off'

/* ─── Complaint Types ─── */

interface Complaint {
  id: string
  complainant: string
  org: string
  targetType: string
  targetName: string
  content: string
  time: string
  status: 'pending' | 'processing' | 'resolved'
  reply?: string
}

const currentUser = { name: '赵明', org: '朝阳分局' }

const complaintTargets = [
  '华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司',
  '中兴通讯股份有限公司', '大华股份有限公司', '宇视科技',
  '张伟', '李强', '王芳',
]

const complaintMock: Complaint[] = [
  { id: 'C20250501001', complainant: '郑华', org: '大兴分局', targetType: '供应商', targetName: '华为技术有限公司', content: '供货周期过长，约定30天到货，实际用了45天。', time: '2025-05-01 11:00', status: 'pending' },
  { id: 'C20250428002', complainant: '陈静', org: '房山分局', targetType: '维修人员', targetName: '某维修点', content: '维修后设备频繁死机，维修质量不达标。', time: '2025-04-28 13:40', status: 'processing' },
  { id: 'C20250420003', complainant: '黄磊', org: '顺义分局', targetType: '产品质量', targetName: '执法记录仪X5', content: '电池续航与标称不符，实际使用不到4小时。', time: '2025-04-20 10:15', status: 'resolved', reply: '已联系厂家更换电池模组，请留意后续使用。' },
]

const statusColors: Record<string, { text: string; color: string }> = {
  pending: { text: '待处理', color: '#ff4d4f' },
  processing: { text: '处理中', color: '#1890ff' },
  resolved: { text: '已解决', color: '#52c41a' },
}



interface ProductData {
  id: string
  name: string
  category1: string
  category2: string
  category3: string
  model: string
  price: number
  unit: string
  hasBattery: boolean
  maintainPeriod: string
  remark: string
  applicantSupplier: string
  supplierId: string
  status: ProductStatus
  createTime: string
}



type PenaltyType = 'warning' | 'suspend' | 'cancel'



interface PenaltyData {
  id: string
  supplierName: string
  supplierId: string
  enterpriseType: EnterpriseType
  penaltyType: PenaltyType
  reason: string
  penaltyDate: string
  duration: string
  durationStart: string
  durationEnd: string
  dept: string
  relatedOrderId: string
  relatedOrderNo: string
  source: 'internal' | 'sync'
  contentType: 'penalty' | 'review'
  remarks?: string
}





/* ─── Equipment Control Types ─── */

interface ControlRecord {
  id: string
  target: string
  reason: string
  startTime: string
  endTime: string
  owner: string
  supplier: string
  status: 'active' | 'released'
}

const systemTargets = ['华为技术有限公司', '中兴通讯股份有限公司', '海康威视数字技术', '大疆创新科技有限公司', '海能达通信股份有限公司', '紫光电子集团有限公司']

const controlOwnerTree = [
  { id: 'D001', name: '一部', members: [{ id: 'U101', name: '张三' }, { id: 'U102', name: '李四' }] },
  { id: 'D002', name: '二部', members: [{ id: 'U201', name: '王五' }, { id: 'U202', name: '赵六' }] },
  { id: 'D003', name: '三部', members: [{ id: 'U301', name: '孙七' }, { id: 'U302', name: '周八' }] },
]


const products: ProductData[] = [
  { id: 'SP001', name: '手持终端', category1: '通信设备', category2: '手持设备', category3: '智能手持终端', model: 'XT-2000', price: 2500, unit: '台', hasBattery: true, maintainPeriod: '6个月', remark: '含充电底座', applicantSupplier: '华为技术有限公司', supplierId: 'SUP001', status: 'on', createTime: '2024-03-10' },
  { id: 'SP002', name: '执法记录仪', category1: '监控设备', category2: '记录设备', category3: '执法记录仪', model: 'DSJ-A7', price: 1200, unit: '台', hasBattery: true, maintainPeriod: '3个月', remark: '32G存储', applicantSupplier: '海康威视数字技术股份有限公司', supplierId: 'SUP002', status: 'on', createTime: '2024-03-09' },
  { id: 'SP003', name: '无人机', category1: '救援装备', category2: '空中设备', category3: '多旋翼无人机', model: 'M300-RTK', price: 45000, unit: '台', hasBattery: true, maintainPeriod: '12个月', remark: '55min续航', applicantSupplier: '大疆创新科技有限公司', supplierId: 'SUP003', status: 'review', createTime: '2024-03-08' },
  { id: 'SP004', name: '应急照明灯', category1: '照明设备', category2: '便携照明', category3: 'LED应急灯', model: 'YD-100', price: 350, unit: '台', hasBattery: true, maintainPeriod: '3个月', remark: '1000流明', applicantSupplier: '中兴通讯股份有限公司', supplierId: 'SUP004', status: 'off', createTime: '2024-03-05' },
  { id: 'SP005', name: '对讲机', category1: '通信设备', category2: '无线通信', category3: '数字对讲机', model: 'PD780G', price: 1800, unit: '台', hasBattery: true, maintainPeriod: '6个月', remark: '双模定位', applicantSupplier: '烽火通信科技股份有限公司', supplierId: 'SUP005', status: 'review', createTime: '2024-03-01' },
  { id: 'SP006', name: '防弹背心', category1: '防护装备', category2: '防护服装', category3: '防弹背心', model: 'FDY-3R', price: 3200, unit: '件', hasBattery: false, maintainPeriod: '12个月', remark: '三级防护', applicantSupplier: '华为技术有限公司', supplierId: 'SUP001', status: 'on', createTime: '2024-02-28' },
  { id: 'SP007', name: '战术头盔', category1: '防护装备', category2: '头部防护', category3: '防弹头盔', model: 'MICH-2000', price: 1800, unit: '顶', hasBattery: false, maintainPeriod: '12个月', remark: '导轨系统', applicantSupplier: '海康威视数字技术股份有限公司', supplierId: 'SUP002', status: 'review', createTime: '2024-02-25' },
  { id: 'SP008', name: '便携式卫星通信终端', category1: '通信设备', category2: '卫星通信', category3: '便携卫星终端', model: 'SAT-100', price: 85000, unit: '台', hasBattery: true, maintainPeriod: '6个月', remark: 'Ku波段', applicantSupplier: '大疆创新科技有限公司', supplierId: 'SUP003', status: 'on', createTime: '2024-02-20' },
]



const penalties: PenaltyData[] = [
  // 内部 + 处罚
  { id: 'CF2024001', supplierName: '华为技术有限公司', supplierId: 'SUP001', enterpriseType: 'producer', penaltyType: 'warning', reason: '延期交货15天，影响项目进度', penaltyDate: '2024-03-10', duration: '3个月', durationStart: '2024-03-10', durationEnd: '2024-06-10', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD001', relatedOrderNo: 'CG2024001', source: 'internal', contentType: 'penalty' },
  // 内部 + 评价
  { id: 'CF2024002', supplierName: '海康威视数字技术股份有限公司', supplierId: 'SUP002', enterpriseType: 'producer', penaltyType: 'warning', reason: '售后服务响应不及时，技术支持评分低于标准', penaltyDate: '2024-04-15', duration: '3个月', durationStart: '2024-04-15', durationEnd: '2024-07-15', dept: 'XX市局科信处', relatedOrderId: '', relatedOrderNo: '', source: 'internal', contentType: 'review' },
  // 采购平台 + 处罚
  { id: 'CF2024003', supplierName: '烽火通信科技股份有限公司', supplierId: 'SUP005', enterpriseType: 'supplier', penaltyType: 'suspend', reason: '批次产品质量不合格，抽检发现缺陷', penaltyDate: '2024-05-01', duration: '3个月', durationStart: '2024-05-01', durationEnd: '2025-05-01', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD003', relatedOrderNo: 'CG2024008', source: 'sync', contentType: 'penalty' },
  // 采购平台 + 评价
  { id: 'CF2024004', supplierName: '中兴通讯股份有限公司', supplierId: 'SUP004', enterpriseType: 'producer', penaltyType: 'warning', reason: '合同变更未按时报备，被采购平台标记', penaltyDate: '2024-05-20', duration: '3个月', durationStart: '2024-05-20', durationEnd: '2024-08-20', dept: 'XX市局科信处', relatedOrderId: '', relatedOrderNo: '', source: 'sync', contentType: 'review' },
  // 内部 + 处罚
  { id: 'CF2024005', supplierName: '浪潮集团有限公司', supplierId: 'SUP006', enterpriseType: 'supplier', penaltyType: 'cancel', reason: '交付的存储设备配置与合同不符，实际容量低于约定规格', penaltyDate: '2024-06-10', duration: '3个月', durationStart: '2024-06-10', durationEnd: '2024-09-10', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD005', relatedOrderNo: 'CG2024015', source: 'internal', contentType: 'penalty' },
]



type SupplierType = 'supplier' | 'producer' | 'agreement'
type QualifyStatus = 'normal' | 'paused' | 'void' | 'pending_audit'
type AuditStatus = 'pending' | 'approved' | 'rejected'

interface EnterpriseData {
  id: string
  name: string
  shortName?: string
  creditCode: string
  address: string
  legalPerson: string
  contact: string
  techContact?: string
  phone: string
  email: string
  registerTime: string
  mainProducts: string
  policeAccess: boolean
  isSecret: boolean
  supplierTypes: SupplierType[]
  qualifyStatus: QualifyStatus
  auditStatus: AuditStatus
  certNo?: string
  brandName?: string
  frameworkNo?: string
  frameworkStart?: string
  frameworkEnd?: string
  supplyArea?: string
  bankAccount?: string
  remark: string
  createTime: string
  updateTime: string
  registeredCapital?: string
  province?: string
  coopUnit?: string
  contactPerson?: string
  idType?: string
  idNumber?: string
  contactPhone?: string
  manager?: string
}



const enterprises: EnterpriseData[] = [
  {
    id: 'SUP001', name: '华为技术有限公司', creditCode: '914403001XXXXXXX88', address: '深圳市龙岗区坂田华为基地',
    legalPerson: '任正非', contact: '张经理', phone: '13800138001', email: 'hw@huawei.com', registerTime: '2015-03-20',
    mainProducts: '通信设备/应急通信/指挥调度/服务器', policeAccess: true, isSecret: false,
    supplierTypes: ['supplier', 'producer'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-001', brandName: '华为', frameworkNo: 'XY-2024-001', frameworkStart: '2024-01-01', frameworkEnd: '2025-12-31',
    supplyArea: '全国', bankAccount: '招商银行深圳分行 7559XXXXXXXX1234',
    remark: '一级供应商，长期合作', createTime: '2024-01-15 09:00', updateTime: '2024-03-10 15:30',
  },
  {
    id: 'SUP002', name: '海康威视数字技术股份有限公司', creditCode: '913300007XXXXXXX99', address: '杭州市滨江区阡陌路555号',
    legalPerson: '陈宗年', contact: '李经理', phone: '13900139002', email: 'hk@hikvision.com', registerTime: '2010-08-12',
    mainProducts: '视频监控/安防设备/应急照明/智能分析', policeAccess: true, isSecret: false,
    supplierTypes: ['producer'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-002', brandName: '海康威视',
    remark: '', createTime: '2024-02-01 10:00', updateTime: '2024-03-05 14:20',
  },
  {
    id: 'SUP003', name: '大疆创新科技有限公司', creditCode: '914403003XXXXXXX77', address: '深圳市南山区高新南四道18号',
    legalPerson: '汪滔', contact: '王经理', phone: '13700137003', email: 'dj@dji.com', registerTime: '2012-06-05',
    mainProducts: '无人机/航拍设备/救援装备/测绘设备', policeAccess: true, isSecret: true,
    supplierTypes: ['producer', 'agreement'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-005', brandName: '大疆', frameworkNo: 'XY-2024-005', frameworkStart: '2024-03-01', frameworkEnd: '2024-12-31',
    supplyArea: '华南/华东', bankAccount: '工商银行深圳分行 6222XXXXXXXX8888',
    remark: '涉密生产商，需保密协议', createTime: '2024-03-01 08:00', updateTime: '2024-03-12 16:00',
  },
  {
    id: 'SUP004', name: '中兴通讯股份有限公司', creditCode: '914403002XXXXXXX66', address: '深圳市南山区高新技术产业园',
    legalPerson: '李自学', contact: '赵经理', phone: '18600186004', email: 'zhao@zte.com.cn', registerTime: '2008-01-15',
    mainProducts: '通信设备/网络设备/卫星设备/终端设备', policeAccess: true, isSecret: false,
    supplierTypes: ['supplier'], qualifyStatus: 'normal', auditStatus: 'approved',
    frameworkNo: 'XY-2024-003', frameworkStart: '2024-01-15', frameworkEnd: '2024-12-31',
    supplyArea: '华南/华东', bankAccount: '招商银行深圳分行 7559XXXXXXXX1234',
    remark: '框架协议有效期内', createTime: '2024-01-10 09:30', updateTime: '2024-03-08 11:00',
  },
  {
    id: 'SUP005', name: '烽火通信科技股份有限公司', creditCode: '914201006XXXXXXX55', address: '武汉市东湖新技术开发区高新四路6号',
    legalPerson: '曾军', contact: '钱经理', phone: '18700187005', email: 'qian@fiberhome.com', registerTime: '2011-11-20',
    mainProducts: '通信设备/光纤设备/传输设备', policeAccess: false, isSecret: false,
    supplierTypes: ['supplier', 'agreement'], qualifyStatus: 'paused', auditStatus: 'approved',
    frameworkNo: 'XY-2024-006', frameworkStart: '2024-02-01', frameworkEnd: '2024-08-31',
    supplyArea: '华中/西南', bankAccount: '中国银行武汉支行 5678XXXXXXXX9012',
    remark: '资质暂停中，暂停供货', createTime: '2024-02-05 10:00', updateTime: '2024-03-15 09:00',
  },
  {
    id: 'SUP006', name: '浪潮集团有限公司', creditCode: '913700006XXXXXXX44', address: '济南市浪潮路1036号',
    legalPerson: '孙丕恕', contact: '孙经理', phone: '18800188006', email: 'sun@inspur.com', registerTime: '2005-04-10',
    mainProducts: '服务器/存储设备/计算设备/云服务', policeAccess: true, isSecret: false,
    supplierTypes: ['agreement'], qualifyStatus: 'void', auditStatus: 'approved',
    frameworkNo: 'XY-2024-008', frameworkStart: '2024-01-01', frameworkEnd: '2024-12-31',
    supplyArea: '华北/华东', bankAccount: '建设银行济南分行 1234XXXXXXXX5678',
    remark: '框架协议已到期作废', createTime: '2024-01-20 08:30', updateTime: '2024-04-01 14:00',
  },
  {
    id: 'SUP007', name: '大华技术股份有限公司', creditCode: '913300007XXXXXXX77', address: '杭州市滨江区滨安路1187号',
    legalPerson: '傅利泉', contact: '刘经理', phone: '18900189007', email: 'liu@dahuatech.com', registerTime: '2018-06-15',
    mainProducts: '视频监控/智能分析/存储设备/报警系统', policeAccess: false, isSecret: false,
    supplierTypes: ['producer', 'supplier'], qualifyStatus: 'pending_audit', auditStatus: 'pending',
    remark: '新申请入驻，待资质审核', createTime: '2024-05-20 10:00', updateTime: '2024-05-20 10:00',
  },
]



type SyncDiffLevel = 'normal' | 'warning' | 'critical'

type ExternalStatus = 'active' | 'revoked' | 'cancelled'



// Penalty sync types

type PenaltySyncStatus = 'pending' | 'adopted' | 'rejected' | 'ignored'

type SyncAction = 'reference_only' | 'sync_status'



interface PenaltySyncDiffItem {

  id: string

  externalPenaltyId: string

  supplierName: string

  externalSupplierName: string

  creditCode: string

  penaltyType: PenaltyType

  reason: string

  penaltyDate: string

  duration: string

  sourcePlatform: string

  localMatchResult: string

  localSupplierStatus: string

  syncStatus: PenaltySyncStatus

  syncTime: string

  adoptOperator?: string

  adoptTime?: string

  localPenaltyId?: string

  actionType?: SyncAction

  rejectReason?: string

  isCritical: boolean

}



interface PenaltySyncLogItem {

  id: string

  operator: string

  ip: string

  time: string

  type: '逐条' | '批量'

  externalPenaltyId: string

  supplierName: string

  result: '采纳' | '驳回'

  actionType?: string

  reason: string

}



interface SyncDiffItem {

  id: string

  enterpriseId: string

  enterpriseName: string

  creditCode: string

  enterpriseType: EnterpriseType

  fieldName: string

  localValue: string

  externalValue: string

  diffLevel: SyncDiffLevel

  externalStatus: ExternalStatus

  externalFetchTime: string

  syncReason: string

  synced: boolean

}



const syncDiffData: SyncDiffItem[] = [

  {

    id: 'SYNC001', enterpriseId: 'SUP001', enterpriseName: '华为技术有限公司',

    creditCode: '914403001XXXXXXX88', enterpriseType: 'producer',

    fieldName: '法人姓名', localValue: '任正非', externalValue: '任正非（已变更）',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC002', enterpriseId: 'SUP001', enterpriseName: '华为技术有限公司',

    creditCode: '914403001XXXXXXX88', enterpriseType: 'producer',

    fieldName: '注册地址', localValue: '深圳市龙岗区坂田华为基地', externalValue: '深圳市龙岗区坂田华为基地B区',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC003', enterpriseId: 'SUP003', enterpriseName: '大疆创新科技有限公司',

    creditCode: '914403003XXXXXXX77', enterpriseType: 'producer',

    fieldName: '联系电话', localValue: '13700137003', externalValue: '0755-26656677',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC004', enterpriseId: 'SUP005', enterpriseName: '烽火通信科技股份有限公司',

    creditCode: '914201006XXXXXXX55', enterpriseType: 'supplier',

    fieldName: '法人姓名', localValue: '曾军', externalValue: '鲁国庆',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC005', enterpriseId: 'SUP005', enterpriseName: '烽火通信科技股份有限公司',

    creditCode: '914201006XXXXXXX55', enterpriseType: 'supplier',

    fieldName: '注册地址', localValue: '武汉市东湖新技术开发区高新四路6号', externalValue: '武汉市东湖新技术开发区高新四路6号烽火科技园',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC006', enterpriseId: 'SUP006', enterpriseName: '浪潮集团有限公司',

    creditCode: '913700006XXXXXXX44', enterpriseType: 'supplier',

    fieldName: '资质状态', localValue: '正常', externalValue: '作废',

    diffLevel: 'critical', externalStatus: 'cancelled', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC007', enterpriseId: 'SUP004', enterpriseName: '中兴通讯股份有限公司',

    creditCode: '914403002XXXXXXX66', enterpriseType: 'supplier',

    fieldName: '联系电话', localValue: '18600186004', externalValue: '18600186005',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC008', enterpriseId: 'SUP002', enterpriseName: '海康威视数字技术股份有限公司',

    creditCode: '913300007XXXXXXX99', enterpriseType: 'producer',

    fieldName: '统一社会信用代码', localValue: '913300007XXXXXXX99', externalValue: '913300007XXXXXXX00',

    diffLevel: 'warning', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

]

/* ================================================================
   装备分类数据
   ================================================================ */
interface EquipCategory {
  id: string
  level1: string
  level1Code: string
  level2: string
  level2Code: string
  level3: string
  level3Code: string
  breedName: string
  breedCode: string
  modelName: string
  modelCode: string
  measureUnit: string      // 计量单位
  hasBattery: boolean      // 是否电池
  maintainPeriodMonth: number  // 保养周期（月）
}

const equipCategories: EquipCategory[] = [
  { id: '1', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹背心', level3Code: '01', breedName: '防弹背心-A型', breedCode: '1101001', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '2', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹背心', level3Code: '01', breedName: '防弹背心-B型', breedCode: '1101002', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '3', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹背心', level3Code: '01', breedName: '防弹背心-C型', breedCode: '1101003', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '4', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹头盔', level3Code: '02', breedName: '战术头盔-A型', breedCode: '1102001', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '5', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹头盔', level3Code: '02', breedName: '战术头盔-B型', breedCode: '1102002', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '6', level1: '防护装备', level1Code: '1', level2: '防弹防护', level2Code: '1', level3: '防弹头盔', level3Code: '02', breedName: '战术头盔-C型', breedCode: '1102003', modelName: '', modelCode: '', measureUnit: '件', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '7', level1: '防护装备', level1Code: '1', level2: '防暴防护', level2Code: '2', level3: '防暴盾牌', level3Code: '01', breedName: '防暴盾牌-A型', breedCode: '1201001', modelName: '', modelCode: '', measureUnit: '面', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '8', level1: '防护装备', level1Code: '1', level2: '防暴防护', level2Code: '2', level3: '防暴盾牌', level3Code: '01', breedName: '防暴盾牌-B型', breedCode: '1201002', modelName: '', modelCode: '', measureUnit: '面', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '9', level1: '防护装备', level1Code: '1', level2: '防暴防护', level2Code: '2', level3: '防暴盾牌', level3Code: '01', breedName: '防暴盾牌-C型', breedCode: '1201003', modelName: '', modelCode: '', measureUnit: '面', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '10', level1: '防护装备', level1Code: '1', level2: '防暴防护', level2Code: '2', level3: '防暴盾牌', level3Code: '01', breedName: '防暴盾牌-D型', breedCode: '1201004', modelName: '', modelCode: '', measureUnit: '面', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '11', level1: '防护装备', level1Code: '1', level2: '防暴防护', level2Code: '2', level3: '防暴盾牌', level3Code: '01', breedName: '防暴盾牌-E型', breedCode: '1201005', modelName: '', modelCode: '', measureUnit: '面', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '12', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '对讲机', level3Code: '01', breedName: '手持对讲机-A型', breedCode: '2101001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '13', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '对讲机', level3Code: '01', breedName: '手持对讲机-B型', breedCode: '2101002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '14', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '对讲机', level3Code: '01', breedName: '手持对讲机-C型', breedCode: '2101003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '15', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '对讲机', level3Code: '01', breedName: '手持对讲机-D型', breedCode: '2101004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '16', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '手持终端', level3Code: '02', breedName: '手持终端-A型', breedCode: '2102001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '17', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '手持终端', level3Code: '02', breedName: '手持终端-B型', breedCode: '2102002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '18', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '手持终端', level3Code: '02', breedName: '手持终端-C型', breedCode: '2102003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '19', level1: '通信装备', level1Code: '2', level2: '无线通信', level2Code: '1', level3: '手持终端', level3Code: '02', breedName: '手持终端-D型', breedCode: '2102004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '20', level1: '通信装备', level1Code: '2', level2: '卫星通信', level2Code: '2', level3: '卫星电话', level3Code: '01', breedName: '卫星电话-A型', breedCode: '2201001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '21', level1: '通信装备', level1Code: '2', level2: '卫星通信', level2Code: '2', level3: '卫星电话', level3Code: '01', breedName: '卫星电话-B型', breedCode: '2201002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '22', level1: '通信装备', level1Code: '2', level2: '卫星通信', level2Code: '2', level3: '卫星电话', level3Code: '01', breedName: '卫星电话-C型', breedCode: '2201003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '23', level1: '通信装备', level1Code: '2', level2: '卫星通信', level2Code: '2', level3: '卫星电话', level3Code: '01', breedName: '卫星电话-D型', breedCode: '2201004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '24', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪', level3Code: '01', breedName: '执法记录仪-A型', breedCode: '3101001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '25', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪', level3Code: '01', breedName: '执法记录仪-B型', breedCode: '3101002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '26', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪', level3Code: '01', breedName: '执法记录仪-C型', breedCode: '3101003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '27', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪A8', level3Code: '02', breedName: '执法记录仪A8-A型', breedCode: '3102001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '28', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪A8', level3Code: '02', breedName: '执法记录仪A8-B型', breedCode: '3102002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '29', level1: '取证装备', level1Code: '3', level2: '视听取证', level2Code: '1', level3: '执法记录仪A8', level3Code: '02', breedName: '执法记录仪A8-C型', breedCode: '3102003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '30', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-A型', breedCode: '3201001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '31', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-B型', breedCode: '3201002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '32', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-C型', breedCode: '3201003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '33', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-D型', breedCode: '3201004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '34', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-E型', breedCode: '3201005', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '35', level1: '取证装备', level1Code: '3', level2: '照相取证', level2Code: '2', level3: '现场勘查相机', level3Code: '01', breedName: '现场勘查相机-F型', breedCode: '3201006', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '36', level1: '交通管理', level1Code: '4', level2: '酒精检测', level2Code: '1', level3: '酒精测试仪', level3Code: '01', breedName: '酒精测试仪-A型', breedCode: '4101001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '37', level1: '交通管理', level1Code: '4', level2: '酒精检测', level2Code: '1', level3: '酒精测试仪', level3Code: '01', breedName: '酒精测试仪-B型', breedCode: '4101002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '38', level1: '交通管理', level1Code: '4', level2: '酒精检测', level2Code: '1', level3: '酒精测试仪', level3Code: '01', breedName: '酒精测试仪-C型', breedCode: '4101003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '39', level1: '交通管理', level1Code: '4', level2: '测速设备', level2Code: '2', level3: '雷达测速仪', level3Code: '01', breedName: '雷达测速仪-A型', breedCode: '4201001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '40', level1: '交通管理', level1Code: '4', level2: '测速设备', level2Code: '2', level3: '雷达测速仪', level3Code: '01', breedName: '雷达测速仪-B型', breedCode: '4201002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '41', level1: '交通管理', level1Code: '4', level2: '测速设备', level2Code: '2', level3: '雷达测速仪', level3Code: '01', breedName: '雷达测速仪-C型', breedCode: '4201003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '42', level1: '应急救援', level1Code: '5', level2: '照明设备', level2Code: '1', level3: '应急照明灯', level3Code: '01', breedName: '应急照明灯-A型', breedCode: '5101001', modelName: '', modelCode: '', measureUnit: '盏', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '43', level1: '应急救援', level1Code: '5', level2: '照明设备', level2Code: '1', level3: '应急照明灯', level3Code: '01', breedName: '应急照明灯-B型', breedCode: '5101002', modelName: '', modelCode: '', measureUnit: '盏', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '44', level1: '应急救援', level1Code: '5', level2: '照明设备', level2Code: '1', level3: '应急照明灯', level3Code: '01', breedName: '应急照明灯-C型', breedCode: '5101003', modelName: '', modelCode: '', measureUnit: '盏', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '45', level1: '应急救援', level1Code: '5', level2: '破拆救援', level2Code: '2', level3: '液压破拆工具', level3Code: '01', breedName: '液压破拆工具-A型', breedCode: '5201001', modelName: '', modelCode: '', measureUnit: '套', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '46', level1: '应急救援', level1Code: '5', level2: '破拆救援', level2Code: '2', level3: '液压破拆工具', level3Code: '01', breedName: '液压破拆工具-B型', breedCode: '5201002', modelName: '', modelCode: '', measureUnit: '套', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '47', level1: '应急救援', level1Code: '5', level2: '破拆救援', level2Code: '2', level3: '液压破拆工具', level3Code: '01', breedName: '液压破拆工具-C型', breedCode: '5201003', modelName: '', modelCode: '', measureUnit: '套', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '48', level1: '应急救援', level1Code: '5', level2: '破拆救援', level2Code: '2', level3: '液压破拆工具', level3Code: '01', breedName: '液压破拆工具-D型', breedCode: '5201004', modelName: '', modelCode: '', measureUnit: '套', hasBattery: true, maintainPeriodMonth: 6 },
  { id: '49', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '手铐', level3Code: '01', breedName: '手铐-A型', breedCode: '6101001', modelName: '', modelCode: '', measureUnit: '副', hasBattery: true, maintainPeriodMonth: 24 },
  { id: '50', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '手铐', level3Code: '01', breedName: '手铐-B型', breedCode: '6101002', modelName: '', modelCode: '', measureUnit: '副', hasBattery: true, maintainPeriodMonth: 24 },
  { id: '51', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '手铐', level3Code: '01', breedName: '手铐-C型', breedCode: '6101003', modelName: '', modelCode: '', measureUnit: '副', hasBattery: true, maintainPeriodMonth: 24 },
  { id: '52', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '手铐', level3Code: '01', breedName: '手铐-D型', breedCode: '6101004', modelName: '', modelCode: '', measureUnit: '副', hasBattery: true, maintainPeriodMonth: 24 },
  { id: '53', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '警绳', level3Code: '02', breedName: '警绳-A型', breedCode: '6102001', modelName: '', modelCode: '', measureUnit: '条', hasBattery: true, maintainPeriodMonth: 12 },
  { id: '54', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '警绳', level3Code: '02', breedName: '警绳-B型', breedCode: '6102002', modelName: '', modelCode: '', measureUnit: '条', hasBattery: true, maintainPeriodMonth: 12 },
  { id: '55', level1: '警械装备', level1Code: '6', level2: '约束器材', level2Code: '1', level3: '警绳', level3Code: '02', breedName: '警绳-C型', breedCode: '6102003', modelName: '', modelCode: '', measureUnit: '条', hasBattery: true, maintainPeriodMonth: 12 },
  { id: '56', level1: '侦查装备', level1Code: '7', level2: '无人机', level2Code: '1', level3: '警用无人机', level3Code: '01', breedName: '警用无人机-A型', breedCode: '7101001', modelName: '', modelCode: '', measureUnit: '架', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '57', level1: '侦查装备', level1Code: '7', level2: '无人机', level2Code: '1', level3: '警用无人机', level3Code: '01', breedName: '警用无人机-B型', breedCode: '7101002', modelName: '', modelCode: '', measureUnit: '架', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '58', level1: '侦查装备', level1Code: '7', level2: '无人机', level2Code: '1', level3: '警用无人机', level3Code: '01', breedName: '警用无人机-C型', breedCode: '7101003', modelName: '', modelCode: '', measureUnit: '架', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '59', level1: '侦查装备', level1Code: '7', level2: '无人机', level2Code: '1', level3: '警用无人机', level3Code: '01', breedName: '警用无人机-D型', breedCode: '7101004', modelName: '', modelCode: '', measureUnit: '架', hasBattery: false, maintainPeriodMonth: 3 },
  { id: '60', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-A型', breedCode: '7201001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '61', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-B型', breedCode: '7201002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '62', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-C型', breedCode: '7201003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '63', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-D型', breedCode: '7201004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '64', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-E型', breedCode: '7201005', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '65', level1: '侦查装备', level1Code: '7', level2: '夜视器材', level2Code: '2', level3: '红外夜视仪', level3Code: '01', breedName: '红外夜视仪-F型', breedCode: '7201006', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '66', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '干粉灭火器', level3Code: '01', breedName: '干粉灭火器-A型', breedCode: '8101001', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '67', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '干粉灭火器', level3Code: '01', breedName: '干粉灭火器-B型', breedCode: '8101002', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '68', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '干粉灭火器', level3Code: '01', breedName: '干粉灭火器-C型', breedCode: '8101003', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '69', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '干粉灭火器', level3Code: '01', breedName: '干粉灭火器-D型', breedCode: '8101004', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '70', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-A型', breedCode: '8102001', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '71', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-B型', breedCode: '8102002', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '72', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-C型', breedCode: '8102003', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '73', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-D型', breedCode: '8102004', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '74', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-E型', breedCode: '8102005', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '75', level1: '消防装备', level1Code: '8', level2: '灭火器材', level2Code: '1', level3: '二氧化碳灭火器', level3Code: '02', breedName: '二氧化碳灭火器-F型', breedCode: '8102006', modelName: '', modelCode: '', measureUnit: '具', hasBattery: false, maintainPeriodMonth: 12 },
  { id: '76', level1: '安防监控', level1Code: '9', level2: '视频监控', level2Code: '1', level3: '网络摄像机', level3Code: '01', breedName: '网络摄像机-A型', breedCode: '9101001', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '77', level1: '安防监控', level1Code: '9', level2: '视频监控', level2Code: '1', level3: '网络摄像机', level3Code: '01', breedName: '网络摄像机-B型', breedCode: '9101002', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '78', level1: '安防监控', level1Code: '9', level2: '视频监控', level2Code: '1', level3: '网络摄像机', level3Code: '01', breedName: '网络摄像机-C型', breedCode: '9101003', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '79', level1: '安防监控', level1Code: '9', level2: '视频监控', level2Code: '1', level3: '网络摄像机', level3Code: '01', breedName: '网络摄像机-D型', breedCode: '9101004', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
  { id: '80', level1: '安防监控', level1Code: '9', level2: '视频监控', level2Code: '1', level3: '网络摄像机', level3Code: '01', breedName: '网络摄像机-E型', breedCode: '9101005', modelName: '', modelCode: '', measureUnit: '台', hasBattery: false, maintainPeriodMonth: 6 },
]

/* 从 equipCategories 构建三级联动树 */
interface CategoryTree {
  [level1Name: string]: {
    code: string
    children: {
      [level2Name: string]: {
        code: string
        children: {
          [level3Name: string]: { code: string }
        }
      }
    }
  }
}

function buildCategoryTree(categories: EquipCategory[]): CategoryTree {
  const tree: CategoryTree = {}
  for (const c of categories) {
    if (!tree[c.level1]) {
      tree[c.level1] = { code: c.level1Code, children: {} }
    }
    if (!tree[c.level1].children[c.level2]) {
      tree[c.level1].children[c.level2] = { code: c.level2Code, children: {} }
    }
    if (!tree[c.level1].children[c.level2].children[c.level3]) {
      tree[c.level1].children[c.level2].children[c.level3] = { code: c.level3Code }
    }
  }
  return tree
}

const categoryTree = buildCategoryTree(equipCategories)

/* 装备编码自动生成：前缀 = 一级码(1位) + 二级码(1位) + 三级码(2位)，顺序号取最大+1 */
function generateEquipCode(level1Code: string, level2Code: string, level3Code: string, existingProducts: ProductData[]): string {
  const prefix = level1Code.slice(-1) + level2Code.slice(-1) + level3Code.slice(-2)
  let maxSeq = 0
  for (const p of existingProducts) {
    if (p.id && p.id.startsWith(prefix)) {
      const seq = parseInt(p.id.slice(prefix.length), 10)
      if (!isNaN(seq) && seq > maxSeq) maxSeq = seq
    }
  }
  const nextSeq = (maxSeq + 1).toString().padStart(3, '0')
  return prefix + nextSeq
}



const syncLogData = [

  { id: 'LOG001', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:00', type: '逐条', enterpriseId: 'SUP001', field: '法人姓名', oldValue: '任正非', newValue: '任正非（已变更）', reason: '营业执照变更' },

  { id: 'LOG002', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:05', type: '批量', enterpriseId: 'SUP001', field: '注册地址', oldValue: '深圳市龙岗区坂田华为基地', newValue: '深圳市龙岗区坂田华为基地B区', reason: '企业搬迁' },

  { id: 'LOG003', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:10', type: '逐条', enterpriseId: 'SUP003', field: '联系电话', oldValue: '13700137003', newValue: '0755-26656677', reason: '企业电话变更' },

]



const penaltySyncDiffData: PenaltySyncDiffItem[] = [

  {

    id: 'PS001', externalPenaltyId: 'JW2024015', supplierName: '华为技术有限公司',

    externalSupplierName: '华为技术有限公司', creditCode: '914403001XXXXXXX88',

    penaltyType: 'suspend', reason: '串通投标，经查实在某项目投标中存在串标行为',

    penaltyDate: '2024-03-15', duration: '12个月', sourcePlatform: '省政府采购网',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

  {

    id: 'PS002', externalPenaltyId: 'SC2024088', supplierName: '海康威视数字技术股份有限公司',

    externalSupplierName: '海康威视数字技术股份有限公司', creditCode: '913300007XXXXXXX99',

    penaltyType: 'warning', reason: '延期交货，合同约定30天内交付，实际延期45天',

    penaltyDate: '2024-06-20', duration: '6个月', sourcePlatform: '市交易中心',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: false

  },

  {

    id: 'PS003', externalPenaltyId: 'CG2024102', supplierName: '中兴通讯股份有限公司',

    externalSupplierName: '中兴通讯股份有限公司', creditCode: '914403002XXXXXXX66',

    penaltyType: 'warning', reason: '合同变更未按时报备',

    penaltyDate: '2024-08-10', duration: '永久', sourcePlatform: '公安部装财局平台',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: false

  },

  {

    id: 'PS004', externalPenaltyId: 'JW2024110', supplierName: 'XX科技有限公司',

    externalSupplierName: 'XX科技有限公司', creditCode: '914403003XXXXXXX77',

    penaltyType: 'cancel', reason: '售后服务严重不达标，多次投诉未处理，已终止合作',

    penaltyDate: '2024-09-01', duration: '永久', sourcePlatform: '省政府采购网',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

  {

    id: 'PS005', externalPenaltyId: 'SC2024125', supplierName: '烽火通信科技股份有限公司',

    externalSupplierName: '烽火通信科技股份有限公司', creditCode: '914201006XXXXXXX55',

    penaltyType: 'suspend', reason: '产品质量抽检不合格，批次产品存在严重缺陷',

    penaltyDate: '2024-10-05', duration: '6个月', sourcePlatform: '市交易中心',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

]



const penaltySyncLogData: PenaltySyncLogItem[] = [

  { id: 'PLOG001', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:00', type: '逐条', externalPenaltyId: 'JW2024015', supplierName: '华为技术有限公司', result: '采纳', actionType: '同步变更供应商状态', reason: '串通投标事实清楚，证据确凿' },

  { id: 'PLOG002', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:05', type: '逐条', externalPenaltyId: 'SC2024088', supplierName: '海康威视数字技术股份有限公司', result: '采纳', actionType: '仅记录为外部参考', reason: '延期交货属实，但已协商解决' },

  { id: 'PLOG003', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:10', type: '批量', externalPenaltyId: 'CG2024102,CG2024103', supplierName: '中兴通讯股份有限公司', result: '采纳', actionType: '仅记录为外部参考', reason: '批量处理合同变更类警告' },

]





/* ================================================================
   装备分类表格组件
   ================================================================ */
/* ================================================================
   装备分类树状表格组件
   ================================================================ */

interface TreeCategoryData {
  key: string
  level: number        // 1=一级分类, 2=二级分类, 3=三级分类, 4=品种
  name: string
  code: string
  indent: number       // 缩进级别
  data?: EquipCategory // 只有level4有
  count?: number       // 子节点数量（一级/二级/三级）
}

function buildCatTreeData(items: EquipCategory[]): TreeCategoryData[] {
  const result: TreeCategoryData[] = []
  // 按一级→二级→三级分组
  const l1Map: any = {}

  for (const item of items) {
    if (!l1Map[item.level1]) {
      l1Map[item.level1] = { code: item.level1Code, l2Map: {} }
    }
    if (!l1Map[item.level1].l2Map[item.level2]) {
      l1Map[item.level1].l2Map[item.level2] = { code: item.level2Code, l3Map: {} }
    }
    if (!l1Map[item.level1].l2Map[item.level2].l3Map[item.level3]) {
      l1Map[item.level1].l2Map[item.level2].l3Map[item.level3] = { code: item.level3Code, items: [] }
    }
    l1Map[item.level1].l2Map[item.level2].l3Map[item.level3].items.push(item)
  }

  for (const [l1Name, l1Data] of Object.entries(l1Map)) {
    const l1d = l1Data as any
    const l1Count = items.filter(i => i.level1 === l1Name).length
    result.push({ key: `l1-${l1Name}`, level: 1, name: l1Name, code: l1d.code, indent: 0, count: l1Count })
    for (const [l2Name, l2Data] of Object.entries(l1d.l2Map)) {
      const l2d = l2Data as any
      const l2Count = items.filter(i => i.level1 === l1Name && i.level2 === l2Name).length
      result.push({ key: `l2-${l1Name}-${l2Name}`, level: 2, name: l2Name, code: l2d.code, indent: 1, count: l2Count })
      for (const [l3Name, l3Data] of Object.entries(l2d.l3Map)) {
        const l3d = l3Data as any
        const l3Count = l3d.items.length
        result.push({ key: `l3-${l1Name}-${l2Name}-${l3Name}`, level: 3, name: l3Name, code: l3d.code, indent: 2, count: l3Count })
        for (const item of l3d.items as EquipCategory[]) {
          result.push({ key: `item-${item.id}`, level: 4, name: item.breedName, code: item.breedCode, indent: 3, data: item })
        }
      }
    }
  }
  return result
}

function TreeCategoryTable({ data, onEdit, onDelete }: { data: EquipCategory[]; onEdit: (item: EquipCategory) => void; onDelete: (id: string) => void }) {
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set())

  // 默认展开一级
  useEffect(() => {
    const keys = new Set<string>()
    const l1Set = new Set(data.map(d => d.level1))
    l1Set.forEach(l1 => keys.add(`l1-${l1}`))
    setExpandedKeys(keys)
  }, [])

  const toggleKey = (key: string) => {
    setExpandedKeys(prev => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  const treeData = buildCatTreeData(data)

  // 根据展开状态过滤可见节点
  const visibleRows: TreeCategoryData[] = []
  let l1Expanded = false
  let l2Expanded = false
  let l3Expanded = false
  for (const row of treeData) {
    if (row.level === 1) {
      l1Expanded = expandedKeys.has(row.key)
      visibleRows.push(row)
    } else if (row.level === 2) {
      if (!l1Expanded) continue
      l2Expanded = expandedKeys.has(row.key)
      visibleRows.push(row)
    } else if (row.level === 3) {
      if (!l2Expanded) continue
      l3Expanded = expandedKeys.has(row.key)
      visibleRows.push(row)
    } else if (row.level === 4) {
      if (!l3Expanded) continue
      visibleRows.push(row)
    }
  }

  const getIndentStyle = (indent: number) => ({ paddingLeft: `${indent * 24 + 8}px` })

  return (
    <table className="data-table">
      <thead>
        <tr>
          <th className="w-1/3">分类/品种</th>
          <th className="w-16">分类码</th>
          <th className="w-24">装备编码</th>
          <th className="w-16">计量单位</th>
          <th className="w-16">是否电池</th>
          <th className="w-20">保养周期(月)</th>
          <th className="w-24">型号名称</th>
          <th className="w-16">型号编码</th>
          <th className="w-16">操作</th>
        </tr>
      </thead>
      <tbody>
        {visibleRows.map(row => {
          if (row.level <= 3) {
            // 分类节点
            const isExpanded = expandedKeys.has(row.key)
            return (
              <tr key={row.key} className="hover:bg-gray-50 cursor-pointer" onClick={() => toggleKey(row.key)}>
                <td style={getIndentStyle(row.indent)}>
                  <div className="flex items-center gap-1.5">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
                    <span className={`text-sm font-medium ${row.level === 1 ? 'text-[#1a4b8c]' : ''}`}>{row.name}</span>
                    <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>({row.count})</span>
                  </div>
                </td>
                <td className="font-mono text-xs">{row.code}</td>
                <td>—</td>
                <td>—</td>
                <td>—</td>
                <td>—</td>
                <td>—</td>
                <td>—</td>
                <td>—</td>
              </tr>
            )
          } else {
            // 品种行
            const item = row.data!
            return (
              <tr key={row.key} className="hover:bg-gray-50">
                <td style={getIndentStyle(row.indent)}>
                  <span className="text-sm">{row.name}</span>
                </td>
                <td>—</td>
                <td className="font-mono text-xs">{item.breedCode}</td>
                <td>{item.measureUnit}</td>
                <td>{item.hasBattery ? '有' : '无'}</td>
                <td>{item.maintainPeriodMonth}</td>
                <td>{item.modelName || ''}</td>
                <td className="font-mono text-xs">{item.modelCode || ''}</td>
                <td>
                  <div className="flex items-center gap-2">
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={(e) => { e.stopPropagation(); onEdit(item) }}>编辑</button>
                    <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={(e) => { e.stopPropagation(); onDelete(item.id) }}>删除</button>
                  </div>
                </td>
              </tr>
            )
          }
        })}
      </tbody>
    </table>
  )
}



function EquipCategoryTable() {
  const [catList, setCatList] = useState<EquipCategory[]>(equipCategories)
  const [catSearch, setCatSearch] = useState('')

  // 当前选中的分类节点 { level: 1|2|3, l1: '', l2: '', l3: '' }
  const [selectedNode, setSelectedNode] = useState<{ level: number; l1: string; l2: string; l3: string }>({ level: 1, l1: '防护装备', l2: '', l3: '' })

  // 展开状态
  const [expandedL1, setExpandedL1] = useState<Set<string>>(new Set(['防护装备']))
  const [expandedL2, setExpandedL2] = useState<Set<string>>(new Set())

  // 批量选择
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())

  // Modal states
  const [catModalOpen, setCatModalOpen] = useState(false)
  const [catEditMode, setCatEditMode] = useState<'add' | 'edit'>('add')
  const [catEditId, setCatEditId] = useState('')

  // Form states
  const [catFormL1, setCatFormL1] = useState('')
  const [catFormL2, setCatFormL2] = useState('')
  const [catFormL3, setCatFormL3] = useState('')
  const [catFormBreedName, setCatFormBreedName] = useState('')
  const [catFormBreedCode, setCatFormBreedCode] = useState('')
  const [catFormModelName, setCatFormModelName] = useState('')
  const [catFormModelCode, setCatFormModelCode] = useState('')
  const [catLevel1Code, setCatLevel1Code] = useState('')
  const [catLevel2Code, setCatLevel2Code] = useState('')
  const [catLevel3Code, setCatLevel3Code] = useState('')

  // Delete confirm
  const [catDeleteOpen, setCatDeleteOpen] = useState(false)
  const [catDeleteId, setCatDeleteId] = useState('')
  const [batchDeleteOpen, setBatchDeleteOpen] = useState(false)

  // Context menu for tree nodes
  const [contextMenu, setContextMenu] = useState<{ x: number; y: number; visible: boolean; nodeType: 'l1' | 'l2' | 'l3'; l1: string; l2: string; l3: string }>({ x: 0, y: 0, visible: false, nodeType: 'l1', l1: '', l2: '', l3: '' })

  // 面包屑路径
  const breadcrumb = (() => {
    const { l1, l2, l3 } = selectedNode
    const parts = ['装备分类']
    if (l1) parts.push(l1)
    if (l2) parts.push(l2)
    if (l3) parts.push(l3)
    return parts
  })()

  // 右侧明细数据：根据选中的节点过滤
  const detailList = (() => {
    const { level, l1, l2, l3 } = selectedNode
    let filtered = catList
    if (level >= 1 && l1) filtered = filtered.filter(c => c.level1 === l1)
    if (level >= 2 && l2) filtered = filtered.filter(c => c.level2 === l2)
    if (level >= 3 && l3) filtered = filtered.filter(c => c.level3 === l3)
    if (catSearch) filtered = filtered.filter(c => c.breedName.includes(catSearch) || c.breedCode.includes(catSearch))
    return filtered
  })()

  // Reset form
  const resetCatForm = () => {
    setCatFormL1('')
    setCatFormL2('')
    setCatFormL3('')
    setCatFormBreedName('')
    setCatFormBreedCode('')
    setCatFormModelName('')
    setCatFormModelCode('')
    setCatLevel1Code('')
    setCatLevel2Code('')
    setCatLevel3Code('')
    setCatEditId('')
  }

  // Open add modal - 自动填充当前选中分类并生成分类码
  const openAddCat = () => {
    setCatEditMode('add')
    resetCatForm()
    // 自动生成分类码
    const l1Keys = Object.keys(categoryTree)
    const nextL1Code = (Math.max(0, ...l1Keys.map(k => parseInt(categoryTree[k]?.code || '0'))) + 1).toString()
    setCatLevel1Code(nextL1Code)
    setCatLevel2Code('1')
    setCatLevel3Code('01')
    setCatModalOpen(true)
  }

  // Open edit modal
  const openEditCat = (item: EquipCategory) => {
    setCatEditMode('edit')
    setCatEditId(item.id)
    setCatFormL1(item.level1)
    setCatFormL2(item.level2)
    setCatFormL3(item.level3)
    setCatFormBreedName(item.breedName)
    setCatFormBreedCode(item.breedCode)
    setCatFormModelName(item.modelName)
    setCatFormModelCode(item.modelCode)
    setCatModalOpen(true)
  }

  // Save new category
  const handleSaveCat = () => {
    if (!catFormL1 || !catFormL2 || !catFormL3) { alert('请输入全部分类名称'); return }

    if (catEditMode === 'edit' && catEditId) {
      // 编辑模式：更新品种信息
      setCatList(prev => prev.map(c => c.id === catEditId ? {
        ...c,
        breedName: catFormBreedName,
        breedCode: catFormBreedCode,
        modelName: catFormModelName,
        modelCode: catFormModelCode
      } : c))
      alert('编辑成功')
      setCatModalOpen(false)
      resetCatForm()
      return
    }

    // 新增模式：生成3-6个随机品种
    if (!catFormBreedName) { alert('请输入品种名称'); return }

    const prefix = catLevel1Code + catLevel2Code + catLevel3Code
    let startSeq = 1
    for (const c of catList) {
      if (c.breedCode && c.breedCode.startsWith(prefix) && c.breedCode.length === 7) {
        const seq = parseInt(c.breedCode.slice(prefix.length), 10)
        if (!isNaN(seq) && seq >= startSeq) startSeq = seq + 1
      }
    }

    const baseId = Math.max(...catList.map(c => parseInt(c.id)), 0) + 1
    const seq = startSeq.toString().padStart(3, '0')

    setCatList(prev => [...prev, {
      id: baseId.toString(),
      level1: catFormL1,
      level1Code: catLevel1Code,
      level2: catFormL2,
      level2Code: catLevel2Code,
      level3: catFormL3,
      level3Code: catLevel3Code,
      breedName: catFormBreedName,
      breedCode: catFormBreedCode || (prefix + seq),
      modelName: catFormModelName,
      modelCode: catFormModelCode,
      measureUnit: '件',
      hasBattery: false,
      maintainPeriodMonth: 12,
    }])

    // 更新categoryTree
    if (!categoryTree[catFormL1]) {
      (categoryTree as any)[catFormL1] = { code: catLevel1Code, children: {} }
    }
    if (!(categoryTree as any)[catFormL1].children[catFormL2]) {
      (categoryTree as any)[catFormL1].children[catFormL2] = { code: catLevel2Code, children: {} }
    }
    if (!(categoryTree as any)[catFormL1].children[catFormL2].children[catFormL3]) {
      (categoryTree as any)[catFormL1].children[catFormL2].children[catFormL3] = { code: catLevel3Code }
    }

    alert('新增品种成功')
    setCatModalOpen(false)
    resetCatForm()
  }

  // Delete single
  const confirmDeleteCat = () => {
    if (catDeleteId) {
      setCatList(prev => prev.filter(c => c.id !== catDeleteId))
      setSelectedIds(prev => { const next = new Set(prev); next.delete(catDeleteId); return next })
      alert('删除成功')
    }
    setCatDeleteOpen(false)
    setCatDeleteId('')
  }

  // Batch delete
  const handleBatchDelete = () => {
    if (selectedIds.size === 0) return
    setCatList(prev => prev.filter(c => !selectedIds.has(c.id)))
    setSelectedIds(new Set())
    setBatchDeleteOpen(false)
    alert(`批量删除成功，共删除 ${selectedIds.size} 条`)
  }

  // Toggle expand
  const toggleL1 = (l1: string) => {
    setExpandedL1(prev => {
      const next = new Set(prev)
      if (next.has(l1)) next.delete(l1)
      else next.add(l1)
      return next
    })
  }
  const toggleL2 = (key: string) => {
    setExpandedL2(prev => {
      const next = new Set(prev)
      if (next.has(key)) next.delete(key)
      else next.add(key)
      return next
    })
  }

  // Build tree structure for left panel
  const treeNodes = (() => {
    const l1Map: any = {}
    for (const c of catList) {
      if (!l1Map[c.level1]) l1Map[c.level1] = {}
      if (!l1Map[c.level1][c.level2]) l1Map[c.level1][c.level2] = new Set()
      l1Map[c.level1][c.level2].add(c.level3)
    }
    return l1Map
  })()

  return (
    <div className="flex gap-3" style={{ height: 'calc(100vh - 180px)' }}>
      {/* ===== Left: Category Tree ===== */}
      <div className="w-[260px] flex-shrink-0 content-card overflow-hidden flex flex-col">
        <div className="px-3 py-3 border-b" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
          <div className="font-semibold text-sm mb-2">装备分类</div>
          <div className="flex items-center gap-1.5">
            <button className="btn-default text-xs px-2 py-1" onClick={() => { resetCatForm(); setCatLevel1Code((Math.max(0, ...Object.keys(categoryTree).map(k => parseInt(categoryTree[k]?.code || '0'))) + 1).toString()); setCatLevel2Code('1'); setCatLevel3Code('01'); setCatModalOpen(true) }}>同级</button>
            <button className="btn-default text-xs px-2 py-1" onClick={() => { resetCatForm(); const { l1, l2 } = selectedNode; if (l1) { setCatFormL1(l1); setCatLevel1Code(categoryTree[l1]?.code || '') } if (l2) { setCatFormL2(l2); setCatLevel2Code(categoryTree[l1]?.children?.[l2]?.code || '') } setCatLevel3Code((Math.max(0, ...Object.keys((categoryTree[l1]?.children?.[l2]?.children) || {}).map(k => parseInt(categoryTree[l1]?.children?.[l2]?.children?.[k]?.code || '0'))) + 1).toString().padStart(2, '0')); setCatModalOpen(true) }}>子级</button>
            <button className="btn-default text-xs px-2 py-1" onClick={() => {
              // 找到当前选中节点下的第一个品种进行编辑
              const items = catList.filter(c => {
                if (selectedNode.l3) return c.level1 === selectedNode.l1 && c.level2 === selectedNode.l2 && c.level3 === selectedNode.l3
                if (selectedNode.l2) return c.level1 === selectedNode.l1 && c.level2 === selectedNode.l2
                return c.level1 === selectedNode.l1
              })
              if (items.length > 0) openEditCat(items[0])
              else alert('当前分类下没有品种可编辑')
            }}>编辑</button>
            <button className="text-xs px-2 py-1 rounded" style={{ color: '#ff4d4f', border: '1px solid #ffa39e' }} onClick={() => { const toDelete = catList.filter(c => { if (selectedNode.l3) return c.level3 === selectedNode.l3; if (selectedNode.l2) return c.level2 === selectedNode.l2; return c.level1 === selectedNode.l1 }); if (toDelete.length > 0 && confirm(`确认删除选中的 ${toDelete.length} 个品种？`)) { setCatList(prev => prev.filter(c => !toDelete.some(d => d.id === c.id))) } }}>删除</button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          {Object.entries(treeNodes).map(([l1, l2Map]: [string, any]) => {
            const isL1Expanded = expandedL1.has(l1)
            const isL1Selected = selectedNode.level === 1 && selectedNode.l1 === l1
            return (
              <div key={l1}>
                {/* Level 1 */}
                <div
                  className={`flex items-center gap-1.5 px-2 py-1.5 rounded cursor-pointer text-sm ${isL1Selected ? 'font-semibold' : ''}`}
                  style={{ background: isL1Selected ? '#e8eef5' : 'transparent', color: '#1a4b8c' }}
                  onClick={() => { setSelectedNode({ level: 1, l1, l2: '', l3: '' }); toggleL1(l1) }}
                  onContextMenu={(e) => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY, visible: true, nodeType: 'l1', l1, l2: '', l3: '' }) }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2" className={`transition-transform flex-shrink-0 ${isL1Expanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
                  <span className="truncate">{l1}</span>
                </div>
                {/* Level 2 */}
                {isL1Expanded && Object.keys(l2Map).map(l2 => {
                  const l2Key = `${l1}-${l2}`
                  const isL2Expanded = expandedL2.has(l2Key)
                  const isL2Selected = selectedNode.level === 2 && selectedNode.l1 === l1 && selectedNode.l2 === l2
                  const l3Set = l2Map[l2] as Set<string>
                  return (
                    <div key={l2Key}>
                      <div
                        className={`flex items-center gap-1.5 px-2 py-1.5 rounded cursor-pointer text-xs ml-4 ${isL2Selected ? 'font-semibold' : ''}`}
                        style={{ background: isL2Selected ? '#e8eef5' : 'transparent' }}
                        onClick={() => { setSelectedNode({ level: 2, l1, l2, l3: '' }); toggleL2(l2Key) }}
                        onContextMenu={(e) => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY, visible: true, nodeType: 'l2', l1, l2, l3: '' }) }}
                      >
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2" className={`transition-transform flex-shrink-0 ${isL2Expanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
                        <span className="truncate">{l2}</span>
                        <span className="text-xs flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>({catList.filter(c => c.level1 === l1 && c.level2 === l2).length})</span>
                      </div>
                      {/* Level 3 */}
                      {isL2Expanded && Array.from(l3Set).map((l3: string) => {
                        const isL3Selected = selectedNode.level === 3 && selectedNode.l1 === l1 && selectedNode.l2 === l2 && selectedNode.l3 === l3
                        return (
                          <div
                            key={`${l2Key}-${l3}`}
                            className={`flex items-center px-2 py-1 rounded cursor-pointer text-xs ml-8 truncate ${isL3Selected ? 'font-semibold' : ''}`}
                            style={{ background: isL3Selected ? '#e8eef5' : 'transparent' }}
                            onClick={() => setSelectedNode({ level: 3, l1, l2, l3 })}
                            onContextMenu={(e) => { e.preventDefault(); setContextMenu({ x: e.clientX, y: e.clientY, visible: true, nodeType: 'l3', l1, l2, l3 }) }}
                          >
                            {l3}
                            <span className="text-xs flex-shrink-0 ml-1" style={{ color: 'var(--text-disabled)' }}>({catList.filter(c => c.level1 === l1 && c.level2 === l2 && c.level3 === l3).length})</span>
                          </div>
                        )
                      })}
                    </div>
                  )
                })}
              </div>
            )
          })}
        </div>


        {/* Context Menu */}
        {contextMenu.visible && (
          <>
            <div className="fixed inset-0 z-[80]" onClick={() => setContextMenu(prev => ({ ...prev, visible: false }))} />
            <div
              className="fixed z-[90] bg-white rounded-lg shadow-xl border py-1 min-w-[120px]"
              style={{ left: contextMenu.x, top: contextMenu.y, borderColor: 'var(--border-color)' }}
            >
              <button
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-gray-50 flex items-center gap-2"
                onClick={() => { setSelectedNode({ level: contextMenu.nodeType === 'l1' ? 1 : contextMenu.nodeType === 'l2' ? 2 : 3, l1: contextMenu.l1, l2: contextMenu.l2, l3: contextMenu.l3 }); setContextMenu(prev => ({ ...prev, visible: false })) }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a4b8c" strokeWidth="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                查看
              </button>
              <div className="border-t my-0.5" style={{ borderColor: 'var(--border-color)' }} />
              <button
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-gray-50 flex items-center gap-2"
                onClick={() => {
                  setContextMenu(prev => ({ ...prev, visible: false }))
                  // 预填分类信息
                  setCatFormL1(contextMenu.l1)
                  setCatFormL2(contextMenu.l2)
                  setCatFormL3(contextMenu.l3)
                  // 生成分类码
                  const l1c = categoryTree[contextMenu.l1]?.code || ''
                  const l2c = contextMenu.l2 ? (categoryTree[contextMenu.l1]?.children?.[contextMenu.l2]?.code || '') : ''
                  const l3c = contextMenu.l3 ? (categoryTree[contextMenu.l1]?.children?.[contextMenu.l2]?.children?.[contextMenu.l3]?.code || '') : ''
                  setCatLevel1Code(l1c)
                  setCatLevel2Code(l2c || '1')
                  setCatLevel3Code(l3c || '01')
                  setCatModalOpen(true)
                }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增子项
              </button>
              <div className="border-t my-0.5" style={{ borderColor: 'var(--border-color)' }} />
              <button
                className="w-full text-left px-3 py-1.5 text-xs hover:bg-gray-50 flex items-center gap-2 text-red-500"
                onClick={() => {
                  setContextMenu(prev => ({ ...prev, visible: false }))
                  // 删除该节点下的所有品种
                  const toDelete = catList.filter(c => {
                    if (contextMenu.nodeType === 'l1') return c.level1 === contextMenu.l1
                    if (contextMenu.nodeType === 'l2') return c.level1 === contextMenu.l1 && c.level2 === contextMenu.l2
                    return c.level1 === contextMenu.l1 && c.level2 === contextMenu.l2 && c.level3 === contextMenu.l3
                  })
                  if (toDelete.length > 0 && confirm(`确认删除 ${contextMenu.nodeType === 'l1' ? contextMenu.l1 : contextMenu.nodeType === 'l2' ? contextMenu.l2 : contextMenu.l3} 下的 ${toDelete.length} 个品种？`)) {
                    setCatList(prev => prev.filter(c => !toDelete.some(d => d.id === c.id)))
                  }
                }}
              >
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                删除
              </button>
            </div>
          </>
        )}
      </div>

      {/* ===== Right: Detail Table ===== */}
      <div className="flex-1 content-card overflow-hidden flex flex-col">
        {/* Breadcrumb */}
        <div className="px-4 py-3 border-b flex items-center gap-1 text-xs" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
          {breadcrumb.map((part, idx) => (
            <span key={idx}>
              {idx > 0 && <span className="mx-1" style={{ color: 'var(--text-disabled)' }}>/</span>}
              <span style={{ color: idx === breadcrumb.length - 1 ? 'var(--primary-blue)' : 'var(--text-secondary)', fontWeight: idx === breadcrumb.length - 1 ? 600 : 400 }}>{part}</span>
            </span>
          ))}
          <span className="ml-2 text-xs" style={{ color: 'var(--text-disabled)' }}>(共 {detailList.length} 条)</span>
        </div>

        {/* Toolbar */}
        <div className="px-4 py-2 border-b flex items-center gap-2" style={{ borderColor: 'var(--border-color)' }}>
          <input
            className="form-input w-48 text-xs"
            placeholder="搜索品种名称/编码"
            value={catSearch}
            onChange={e => setCatSearch(e.target.value)}
          />
          <div className="flex gap-2 ml-auto">
            {selectedIds.size > 0 && (
              <>
                <span className="text-xs self-center" style={{ color: 'var(--text-secondary)' }}>已选 {selectedIds.size} 条</span>
                <button className="btn-danger text-xs" onClick={() => setBatchDeleteOpen(true)}>批量删除</button>
              </>
            )}
            <button className="btn-default text-xs" onClick={() => alert('导入功能开发中')}>导入</button>
            <button className="btn-default text-xs" onClick={() => alert('导出功能开发中')}>导出</button>
            <button className="btn-primary text-xs" onClick={() => {
              resetCatForm()
              const { l1, l2, l3 } = selectedNode
              let finalL1 = l1, finalL2 = l2, finalL3 = l3
              // 自动填充分类
              if (finalL1) {
                setCatFormL1(finalL1)
                setCatLevel1Code(categoryTree[finalL1]?.code || '')
              } else {
                // 未选中任何分类，取第一个一级分类
                finalL1 = Object.keys(categoryTree)[0] || ''
                setCatFormL1(finalL1)
                setCatLevel1Code(categoryTree[finalL1]?.code || '')
              }
              if (finalL2) {
                setCatFormL2(finalL2)
                setCatLevel2Code(categoryTree[finalL1]?.children?.[finalL2]?.code || '')
              } else if (finalL1 && categoryTree[finalL1]?.children) {
                // 未选中二级，取第一个二级
                finalL2 = Object.keys(categoryTree[finalL1].children)[0] || ''
                setCatFormL2(finalL2)
                setCatLevel2Code(categoryTree[finalL1]?.children?.[finalL2]?.code || '')
              }
              if (finalL3) {
                setCatFormL3(finalL3)
                setCatLevel3Code(categoryTree[finalL1]?.children?.[finalL2]?.children?.[finalL3]?.code || '')
              } else if (finalL1 && finalL2 && categoryTree[finalL1]?.children?.[finalL2]?.children) {
                // 未选中三级，取第一个三级
                finalL3 = Object.keys(categoryTree[finalL1].children[finalL2].children)[0] || ''
                setCatFormL3(finalL3)
                setCatLevel3Code(categoryTree[finalL1]?.children?.[finalL2]?.children?.[finalL3]?.code || '')
              }
              // 自动生成装备编码
              const prefix = (categoryTree[finalL1]?.code || '') + (categoryTree[finalL1]?.children?.[finalL2]?.code || '') + (categoryTree[finalL1]?.children?.[finalL2]?.children?.[finalL3]?.code || '')
              if (prefix) {
                let maxSeq = 0
                for (const c of catList) {
                  if (c.breedCode && c.breedCode.startsWith(prefix) && c.breedCode.length === 7) {
                    const seq = parseInt(c.breedCode.slice(prefix.length), 10)
                    if (!isNaN(seq) && seq > maxSeq) maxSeq = seq
                  }
                }
                setCatFormBreedCode(prefix + (maxSeq + 1).toString().padStart(3, '0'))
              }
              setCatModalOpen(true)
            }}>新增品种</button>
          </div>
        </div>

        {/* Table */}
        <div className="flex-1 overflow-auto">
          <table className="data-table">
            <thead className="sticky top-0 z-10">
              <tr>
                <th className="w-10">
                  <input
                    type="checkbox"
                    checked={detailList.length > 0 && detailList.every(c => selectedIds.has(c.id))}
                    onChange={e => {
                      if (e.target.checked) {
                        setSelectedIds(prev => {
                          const next = new Set(prev)
                          detailList.forEach(c => next.add(c.id))
                          return next
                        })
                      } else {
                        setSelectedIds(prev => {
                          const next = new Set(prev)
                          detailList.forEach(c => next.delete(c.id))
                          return next
                        })
                      }
                    }}
                  />
                </th>
                <th>品种名称</th>
                <th>装备编码</th>
                <th>计量单位</th>
                <th>是否电池</th>
                <th>保养周期(月)</th>
                <th>型号</th>
                <th>型号编码</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {detailList.map(item => (
                <tr key={item.id}>
                  <td className="text-center">
                    <input
                      type="checkbox"
                      checked={selectedIds.has(item.id)}
                      onChange={e => {
                        setSelectedIds(prev => {
                          const next = new Set(prev)
                          if (e.target.checked) next.add(item.id)
                          else next.delete(item.id)
                          return next
                        })
                      }}
                    />
                  </td>
                  <td className="font-medium">{item.breedName}</td>
                  <td className="font-mono text-xs">{item.breedCode}</td>
                  <td>{item.measureUnit}</td>
                  <td>{item.hasBattery ? '有' : '无'}</td>
                  <td>{item.maintainPeriodMonth}</td>
                  <td>{item.modelName || '-'}</td>
                  <td className="font-mono text-xs">{item.modelCode || '-'}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openEditCat(item)}>编辑</button>
                      <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => { setCatDeleteId(item.id); setCatDeleteOpen(true) }}>删除</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {detailList.length === 0 && (
            <div className="py-12 text-center text-xs" style={{ color: 'var(--text-disabled)' }}>暂无数据</div>
          )}
        </div>
      </div>

      {/* ===== Modals ===== */}
      {/* Add/Edit Modal */}
      {catModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setCatModalOpen(false); resetCatForm() }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{catEditMode === 'edit' ? '编辑品种' : '新增品种'}</h3>
              <button onClick={() => { setCatModalOpen(false); resetCatForm() }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                {/* 一级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>一级分类 <span className="text-red-400">*</span></label>
                  <input className={`form-input w-full text-sm ${catEditMode === 'edit' ? 'bg-gray-50' : ''}`} value={catFormL1} onChange={catEditMode === 'edit' ? undefined : e => setCatFormL1(e.target.value)} readOnly={catEditMode === 'edit'} placeholder="请输入一级分类名称" />
                </div>
                {/* 一级分类码 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>一级分类码</label>
                  <input className="form-input w-full text-sm font-mono bg-gray-50" value={catLevel1Code} readOnly />
                </div>
                {/* 二级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>二级分类 <span className="text-red-400">*</span></label>
                  <input className={`form-input w-full text-sm ${catEditMode === 'edit' ? 'bg-gray-50' : ''}`} value={catFormL2} onChange={catEditMode === 'edit' ? undefined : e => setCatFormL2(e.target.value)} readOnly={catEditMode === 'edit'} placeholder="请输入二级分类名称" />
                </div>
                {/* 二级分类码 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>二级分类码</label>
                  <input className="form-input w-full text-sm font-mono bg-gray-50" value={catLevel2Code} readOnly />
                </div>
                {/* 三级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>三级分类 <span className="text-red-400">*</span></label>
                  <input className={`form-input w-full text-sm ${catEditMode === 'edit' ? 'bg-gray-50' : ''}`} value={catFormL3} onChange={catEditMode === 'edit' ? undefined : e => setCatFormL3(e.target.value)} readOnly={catEditMode === 'edit'} placeholder="请输入三级分类名称" />
                </div>
                {/* 三级分类码 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>三级分类码</label>
                  <input className="form-input w-full text-sm font-mono bg-gray-50" value={catLevel3Code} readOnly />
                </div>
                {/* 品种名称 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>品种名称 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full text-sm" value={catFormBreedName} onChange={e => setCatFormBreedName(e.target.value)} placeholder="请输入品种名称" />
                </div>
                {/* 装备编码 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>装备编码</label>
                  <input className={`form-input w-full text-sm font-mono ${catEditMode === 'edit' ? 'bg-gray-50' : ''}`} value={catFormBreedCode} onChange={catEditMode === 'edit' ? undefined : e => setCatFormBreedCode(e.target.value)} readOnly={catEditMode === 'edit'} placeholder="请输入装备编码" />
                </div>
                {/* 型号名称 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>型号名称</label>
                  <input className="form-input w-full text-sm" value={catFormModelName} onChange={e => setCatFormModelName(e.target.value)} placeholder="请输入型号名称" />
                </div>
                {/* 型号编码 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>型号编码</label>
                  <input className="form-input w-full text-sm font-mono" value={catFormModelCode} onChange={e => setCatFormModelCode(e.target.value)} placeholder="请输入型号编码" />
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setCatModalOpen(false); resetCatForm() }}>取消</button>
              <button className="btn-primary" onClick={handleSaveCat}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Single Confirm */}
      {catDeleteOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCatDeleteOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认删除</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除该品种记录？删除后数据将无法恢复。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setCatDeleteOpen(false)}>取消</button>
              <button className="btn-danger" onClick={confirmDeleteCat}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Delete Confirm */}
      {batchDeleteOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setBatchDeleteOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
              </div>
              <h3 className="text-base font-semibold">批量删除确认</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除选中的 {selectedIds.size} 条品种记录？删除后数据将无法恢复。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setBatchDeleteOpen(false)}>取消</button>
              <button className="btn-danger" onClick={handleBatchDelete}>确认删除</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}



export default function SupplierPage({ activeSubTab, onNavigate, contractData, orderData }: Props) {

  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'enterprise')
  const [productSubTab, setProductSubTab] = useState<'audit' | 'category'>('audit')

  const [drawerOpen, setDrawerOpen] = useState(false)

  const [drawerTitle, setDrawerTitle] = useState('')

  const [selectedEnterprise, setSelectedEnterprise] = useState<EnterpriseData | null>(null)

  // enterprise list state (unified, no longer split by producer/supplier view)

  const [editMode, setEditMode] = useState<'add' | 'edit' | 'view' | 'audit'>('view')
  const [auditComment, setAuditComment] = useState('')

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)

  const [_enterpriseList, setEnterpriseList] = useState(enterprises)



  // Sync info states

  const [syncDiffList, setSyncDiffList] = useState(syncDiffData)

  const [syncLogList] = useState(syncLogData)

  const [_syncView, setSyncView] = useState<'diff' | 'log'>('diff')

  const [syncDetailOpen, setSyncDetailOpen] = useState(false)

  const [selectedDiff, setSelectedDiff] = useState<SyncDiffItem | null>(null)

  const [syncReason, setSyncReason] = useState('')

  const [batchSyncOpen, setBatchSyncOpen] = useState(false)

  const [batchReason, setBatchReason] = useState('')

  const [syncTriggerOpen, setSyncTriggerOpen] = useState(false)

  const [logModalOpen, setLogModalOpen] = useState(false)



  // Product management states

  const [selectedProduct, setSelectedProduct] = useState<ProductData | null>(null)

  const [productEditMode, setProductEditMode] = useState<'add' | 'edit' | 'view'>('view')

  // Product audit modal
  const [auditModalOpen, setAuditModalOpen] = useState(false)
  const [auditProduct, setAuditProduct] = useState<ProductData | null>(null)
  const [auditResult, setAuditResult] = useState<'pass' | 'reject'>('pass')
  const [auditOpinion, setAuditOpinion] = useState('')
  const [auditCategory1, setAuditCategory1] = useState('')
  const [auditCategory2, setAuditCategory2] = useState('')
  const [auditCategory3, setAuditCategory3] = useState('')
  const [auditLevel1Code, setAuditLevel1Code] = useState('')
  const [auditLevel2Code, setAuditLevel2Code] = useState('')
  const [auditLevel3Code, setAuditLevel3Code] = useState('')
  const [auditCode, setAuditCode] = useState('')
  const [auditApplicantSupplier, setAuditApplicantSupplier] = useState('')
  const [auditSupplierName, setAuditSupplierName] = useState('')

  const [productList, setProductList] = useState(products)

  // Enterprise products modal
  const [enterpriseProductsOpen, setEnterpriseProductsOpen] = useState(false)
  const [selectedEnterpriseForProducts, setSelectedEnterpriseForProducts] = useState<EnterpriseData | null>(null)



  // Penalty management states

  const [selectedPenalty, setSelectedPenalty] = useState<PenaltyData | null>(null)

  const [penaltyEditMode, setPenaltyEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const [penaltyList, _setPenaltyList] = useState(penalties)

  const [penaltyDeleteOpen, setPenaltyDeleteOpen] = useState(false)

  const [penaltyDrawerOpen, setPenaltyDrawerOpen] = useState(false)



  // Penalty sync states

  const [penaltySyncView, setPenaltySyncView] = useState<'list' | 'diff' | 'log'>('list')

  const [penaltySyncDiffList, setPenaltySyncDiffList] = useState(penaltySyncDiffData)

  const [penaltySyncLogList] = useState(penaltySyncLogData)

  const [penaltySyncDetailOpen, setPenaltySyncDetailOpen] = useState(false)

  const [selectedPenaltyDiff, setSelectedPenaltyDiff] = useState<PenaltySyncDiffItem | null>(null)

  const [penaltySyncReason, setPenaltySyncReason] = useState('')

  const [penaltyBatchSyncOpen, setPenaltyBatchSyncOpen] = useState(false)

  const [penaltyBatchReason, setPenaltyBatchReason] = useState('')

  const [penaltySyncTriggerOpen, setPenaltySyncTriggerOpen] = useState(false)

  /* ─── Complaint management states ─── */
  const [complaintList, setComplaintList] = useState<Complaint[]>(complaintMock)
  const [complaintSearch, setComplaintSearch] = useState('')
  const [complaintStatusFilter, setComplaintStatusFilter] = useState('')
  const [complaintModalOpen, setComplaintModalOpen] = useState(false)
  const [complaintForm, setComplaintForm] = useState({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
  const [replyComplaint, setReplyComplaint] = useState<Complaint | null>(null)
  const [replyContent, setReplyContent] = useState('')
  const [replyOpen, setReplyOpen] = useState(false)
  const [targetSearchText, setTargetSearchText] = useState('')
  const [targetSearchOpen, setTargetSearchOpen] = useState(false)

  /* ─── Equipment Control states ─── */
  const [controls, setControls] = useState<ControlRecord[]>([
    { id: 'GK000001', target: '华为技术', reason: '质量问题批次', startTime: '2024-01-10', endTime: '2024-07-10', owner: '张三', supplier: '华为技术有限公司', status: 'active' },
    { id: 'GK000002', target: 'ZB005批次', reason: '安全隐患', startTime: '2024-02-01', endTime: '-', owner: '李四', supplier: '烽火通信', status: 'active' },
    { id: 'GK000003', target: 'XX电子', reason: '资质过期', startTime: '2023-12-01', endTime: '2024-01-15', owner: '王五', supplier: 'XX电子科技', status: 'released' },
  ])
  const [controlModalOpen, setControlModalOpen] = useState(false)
  const [controlModalMode, setControlModalMode] = useState<'add' | 'view'>('add')
  const [selectedControl, setSelectedControl] = useState<ControlRecord | null>(null)
  const [controlForm, setControlForm] = useState({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
  const [controlTargetSearch, setControlTargetSearch] = useState('')
  const [showTargetDropdown, setShowTargetDropdown] = useState(false)
  const [showOwnerTree, setShowOwnerTree] = useState(false)
  const [releaseConfirmOpen, setReleaseConfirmOpen] = useState(false)
  const [releasingControlId, setReleasingControlId] = useState<string | null>(null)


  const [penaltyAdoptAction, setPenaltyAdoptAction] = useState<SyncAction>('reference_only')

  const [penaltyRejectReason, setPenaltyRejectReason] = useState('')

  const [penaltyLogModalOpen, setPenaltyLogModalOpen] = useState(false)



  useEffect(() => {

    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {

      setActiveTab(activeSubTab)

    }

  }, [activeSubTab])



  // filtered list is now directly filtered by enterpriseView in the render



  const openDetail = (item: EnterpriseData, mode: 'view' | 'edit' | 'audit') => {

    setSelectedEnterprise(item)

    setEditMode(mode)

    setDrawerTitle(mode === 'edit' ? `编辑企业 - ${item.name}` : mode === 'audit' ? `企业审核 - ${item.name}` : `企业详情 - ${item.name}`)

    setAuditComment('')

    setDrawerOpen(true)

  }



  const openAdd = () => {
    setSelectedEnterprise(null)
    setEditMode('add')
    setDrawerTitle('新增企业')
    setDrawerOpen(true)
  }



  const openProductDetail = (item: ProductData, mode: 'view' | 'edit') => {

    setSelectedProduct(item)

    setProductEditMode(mode)

    setDrawerTitle(mode === 'edit' ? `编辑商品 - ${item.name}` : `商品详情 - ${item.name}`)

    setDrawerOpen(true)

  }



  const openAddProduct = () => {

    setSelectedProduct(null)

    setProductEditMode('add')

    setDrawerTitle('新增商品报备')

    setDrawerOpen(true)

  }

  const openAuditModal = (item: ProductData) => {
    setAuditProduct(item)
    setAuditResult('pass')
    setAuditOpinion('')
    // 查找分类编码
    const cat = equipCategories.find(c => c.level1 === item.category1 && c.level2 === item.category2 && c.level3 === item.category3)
    setAuditCategory1(item.category1)
    setAuditCategory2(item.category2)
    setAuditCategory3(item.category3)
    setAuditLevel1Code(cat?.level1Code || '')
    setAuditLevel2Code(cat?.level2Code || '')
    setAuditLevel3Code(cat?.level3Code || '')
    // 从 enterprises 查找供应商名称
    const ent = enterprises.find(e => e.id === item.supplierId)
    setAuditSupplierName(ent?.name || item.applicantSupplier)
    setAuditApplicantSupplier(item.applicantSupplier)
    // 如果已有编码则保留，否则自动生成
    if (item.id && /^\d{7}$/.test(item.id)) {
      setAuditCode(item.id)
    } else if (cat) {
      setAuditCode(generateEquipCode(cat.level1Code, cat.level2Code, cat.level3Code, productList))
    } else {
      setAuditCode(item.id)
    }
    setAuditModalOpen(true)
  }

  const handleAudit = () => {
    if (!auditProduct) return
    const newStatus = auditResult === 'pass' ? 'on' : 'off'
    setProductList(prev => prev.map(p => p.id === auditProduct.id ? {
      ...p,
      status: newStatus as ProductStatus,
      category1: auditCategory1,
      category2: auditCategory2,
      category3: auditCategory3,
      id: auditCode || p.id,
      applicantSupplier: auditSupplierName,
    } : p))
    setAuditModalOpen(false)
    setAuditProduct(null)
    alert(auditResult === 'pass' ? '审核通过' : '审核已驳回')
  }



  const openEnterpriseProducts = (item: EnterpriseData) => {

    setSelectedEnterpriseForProducts(item)

    setEnterpriseProductsOpen(true)

  }



  const openPenaltyDetail = (item: PenaltyData, mode: 'view' | 'edit') => {

    setSelectedPenalty(item)

    setPenaltyEditMode(mode)

    setPenaltyDrawerOpen(true)

  }



  const openAddPenalty = () => {

    setSelectedPenalty(null)

    setPenaltyEditMode('add')

    setPenaltyDrawerOpen(true)

  }



  const handleDeletePenalty = (item: PenaltyData) => {

    setSelectedPenalty(item)

    setPenaltyDeleteOpen(true)

  }



  const confirmDeletePenalty = () => {

    if (selectedPenalty) {

      _setPenaltyList(prev => prev.filter(p => p.id !== selectedPenalty.id))

    }

    setPenaltyDeleteOpen(false)

    setSelectedPenalty(null)

  }

  /* ─── Complaint handlers ─── */

  const addComplaint = () => {
    const finalForm = { ...complaintForm, complainant: currentUser.name, org: currentUser.org }
    if (!finalForm.targetName || !finalForm.content) return
    const newItem: Complaint = {
      id: `C${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(complaintList.length + 1).padStart(3, '0')}`,
      ...finalForm,
      time: new Date().toLocaleString('zh-CN'),
      status: 'pending',
    }
    setComplaintList(prev => [newItem, ...prev])
    setComplaintModalOpen(false)
    setComplaintForm({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
    setTargetSearchText('')
  }

  const submitReply = () => {
    if (!replyComplaint || !replyContent) return
    setComplaintList(prev => prev.map(c => c.id === replyComplaint.id ? { ...c, status: 'resolved', reply: replyContent } : c))
    setReplyOpen(false)
    setReplyContent('')
    setReplyComplaint(null)
  }

  const processComplaint = (id: string) => {
    setComplaintList(prev => prev.map(c => c.id === id ? { ...c, status: 'processing' } : c))
  }



  /* ─── Equipment Control handlers ─── */
  const openControlModal = (mode: 'add' | 'view', control?: ControlRecord) => {
    setControlModalMode(mode)
    if (control) {
      setSelectedControl(control)
    } else {
      setSelectedControl(null)
      setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
      setControlTargetSearch('')
      setShowTargetDropdown(false)
      setShowOwnerTree(false)
    }
    setControlModalOpen(true)
  }

  const saveControl = () => {
    if (!controlForm.target || !controlForm.reason) return
    const newControl: ControlRecord = {
      id: `GK${String(Date.now()).slice(-6)}`,
      target: controlForm.target, reason: controlForm.reason,
      startTime: controlForm.startTime || new Date().toISOString().slice(0, 10),
      endTime: controlForm.endTime || '-', owner: controlForm.owner || '当前用户',
      supplier: controlTargetSearch || '',
      status: 'active',
    }
    setControls(prev => [newControl, ...prev])
    setControlModalOpen(false)
    setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
    setControlTargetSearch('')
    setShowTargetDropdown(false)
    setShowOwnerTree(false)
  }

  const releaseControl = (id: string) => {
    setControls(prev => prev.map(c => c.id === id ? { ...c, status: 'released' as const, endTime: new Date().toISOString().slice(0, 10) } : c))
    setReleaseConfirmOpen(false)
    setReleasingControlId(null)
  }

  const filteredComplaint = complaintList.filter(c => {
    const matchSearch = !complaintSearch || c.complainant.includes(complaintSearch) || c.targetName.includes(complaintSearch)
    const matchStatus = !complaintStatusFilter || c.status === complaintStatusFilter
    return matchSearch && matchStatus
  })



  const _openPenaltySyncDetail = (item: PenaltySyncDiffItem) => {

    setSelectedPenaltyDiff(item)

    setPenaltySyncReason('')

    setPenaltyAdoptAction('reference_only')

    setPenaltyRejectReason('')

    setPenaltySyncDetailOpen(true)

  }



  const _openPenaltyBatchSync = () => {

    setPenaltyBatchReason('')

    setPenaltyBatchSyncOpen(true)

  }



  const confirmSinglePenaltySync = () => {

    if (selectedPenaltyDiff) {

      setPenaltySyncDiffList(prev => prev.map(d => d.id === selectedPenaltyDiff.id ? { ...d, syncStatus: 'adopted' as PenaltySyncStatus, adoptOperator: '管理员', adoptTime: new Date().toISOString().slice(0, 16).replace('T', ' '), localPenaltyId: 'CF' + Date.now().toString().slice(-8) } : d))

    }

    setPenaltySyncDetailOpen(false)

    setSelectedPenaltyDiff(null)

  }



  const rejectSinglePenaltySync = () => {

    if (selectedPenaltyDiff) {

      setPenaltySyncDiffList(prev => prev.map(d => d.id === selectedPenaltyDiff.id ? { ...d, syncStatus: 'rejected' as PenaltySyncStatus, rejectReason: penaltyRejectReason } : d))

    }

    setPenaltySyncDetailOpen(false)

    setPenaltyRejectReason('')

    setSelectedPenaltyDiff(null)

  }



  const confirmBatchPenaltySync = () => {

    setPenaltySyncDiffList(prev => prev.map(d => d.syncStatus === 'pending' && !d.isCritical ? { ...d, syncStatus: 'adopted' as PenaltySyncStatus, adoptOperator: '管理员', adoptTime: new Date().toISOString().slice(0, 16).replace('T', ' '), localPenaltyId: 'CF' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 1000) } : d))

    setPenaltyBatchSyncOpen(false)

    setPenaltyBatchReason('')

  }



  const _openSyncDetail = (item: SyncDiffItem) => {

    setSelectedDiff(item)

    setSyncReason('')

    setSyncDetailOpen(true)

  }



  const openBatchSync = () => {

    const normalDiffs = syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced)

    if (normalDiffs.length === 0) return

    setBatchReason('')

    setBatchSyncOpen(true)

  }



  const confirmSingleSync = () => {

    if (selectedDiff && syncReason.trim()) {

      setSyncDiffList(prev => prev.map(d => d.id === selectedDiff.id ? { ...d, synced: true, syncReason } : d))

    }

    setSyncDetailOpen(false)

    setSelectedDiff(null)

    setSyncReason('')

  }



  const confirmBatchSync = () => {

    if (batchReason.trim()) {

      setSyncDiffList(prev => prev.map(d => d.diffLevel !== 'critical' && !d.synced ? { ...d, synced: true, syncReason: batchReason } : d))

    }

    setBatchSyncOpen(false)

    setBatchReason('')

  }



  const _handleDelete = (item: EnterpriseData) => {

    setSelectedEnterprise(item)

    setDeleteConfirmOpen(true)

  }



  const confirmDelete = () => {

    if (selectedEnterprise) {

      setEnterpriseList(prev => prev.filter(e => e.id !== selectedEnterprise.id))

    }

    setDeleteConfirmOpen(false)

    setSelectedEnterprise(null)

  }



  const _pendingSuppliers = [

    { name: '华为技术公司', code: '91440300XXXXXXXX', contact: '张经理', date: '2024-01-10', status: 'pending' },

    { name: '海康威视公司', code: '91330000XXXXXXXX', contact: '李经理', date: '2024-01-09', status: 'pending' },

    { name: '大华技术公司', code: '91330000XXXXXXXX', contact: '王经理', date: '2024-01-08', status: 'pending' },

  ]



  const _qualifyStatusMap: Record<string, { label: string; color: string }> = {

    normal: { label: '正常', color: '#52c41a' },

    paused: { label: '暂停', color: '#faad14' },

    void: { label: '作废', color: '#ff4d4f' },

  }



  return (
    <div className="p-6 space-y-4">
      {/* 统计卡片 - 与采购及售后管理统一 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: '总合同数', value: `${(contractData || []).length} 个`, color: '#1a4b8c', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
          { label: '总合同金额', value: `¥ ${(contractData || []).reduce((s: number, c: any) => s + c.amount, 0).toLocaleString()}`, color: '#1a4b8c', icon: 'M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6' },
          { label: '总企业数', value: `${enterprises.length} 家`, color: '#1a4b8c', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
          { label: '待审核企业数', value: `${_enterpriseList.filter((e: any) => e.auditStatus === 'pending').length} 家`, color: '#d4880f', icon: 'M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
          { label: '待审核商品数', value: `${productList.filter((p: any) => p.status === 'review').length} 件`, color: '#1a4b8c', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-lg font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 快捷入口 - 与采购及售后管理统一 */}
      <div className="content-card p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { key: 'contract', label: '合同管理', desc: '合同签订与执行', count: 0, color: '#1a4b8c', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
            { key: 'order', label: '订单管理', desc: '订单验收与管理', count: 0, color: '#1a4b8c', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
            { key: 'enterprise', label: '供应商信息', desc: '供应商企业档案', count: 0, color: '#1a4b8c', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
            { key: 'product', label: '装备管理', desc: '装备基础信息与审核', count: productList.filter((p: any) => p.status === 'review').length, color: '#1a4b8c', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
            { key: 'penalty', label: '处罚管理', desc: '违规处罚与记录', count: 0, color: '#c0392b', icon: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z' },
            { key: 'complaint', label: '投诉管理', desc: '投诉举报处理', count: 0, color: '#c0392b', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => {
                if (item.key === 'contract' || item.key === 'order') {
                  onNavigate?.('procurement', item.key)
                } else {
                  setActiveTab(item.key)
                }
              }}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': item.color } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                  <path d={item.icon}/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium flex items-center gap-2">
                  {item.label}
                  {item.count > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full text-xs text-white" style={{ background: item.color }}>{item.count}</span>
                  )}
                </div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>


      {activeTab === 'penalty' && (
          <>
            <button className="btn-primary text-xs ml-auto" onClick={openAddPenalty}>+ 新增处罚登记</button>

            <button className="btn-default text-xs hidden" onClick={() => setPenaltySyncTriggerOpen(true)} style={{display: 'none'}}>

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>

                同步信息

              </span>

            </button>

            <button className="btn-default text-xs" onClick={() => setPenaltyLogModalOpen(true)}>

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                操作日志

              </span>

            </button>

          </>

        )}



      {/* Search + Action - Enterprise Only */}
      {activeTab === 'enterprise' && (
        <>
          <div className="flex items-center gap-2">
            <button className="btn-primary text-xs" onClick={() => openAdd()}>
              <span className="flex items-center gap-1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增企业
              </span>
            </button>
            <div className="ml-auto flex items-center gap-2">
              <button className="btn-default text-xs" onClick={() => setSyncTriggerOpen(true)}>
                <span className="flex items-center gap-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
                  同步供应商信息
                </span>
              </button>
            </div>
          </div>

          {/* Search area */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业名称</label><input className="form-input w-48" placeholder="请输入企业名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业类型</label><select className="form-input w-36"><option>全部</option><option>管理供应商</option><option>生产商</option><option>协议供货商</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系人</label><input className="form-input w-32" placeholder="请输入联系人" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系电话</label><input className="form-input w-36" placeholder="请输入联系电话" /></div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default">重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>
        </>
      )}



      {/* Search area - penalty only */}
      {activeTab === 'penalty' && (
        <div className="content-card p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商名称</label><select className="form-input w-44"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>烽火通信科技股份有限公司</option><option>中兴通讯股份有限公司</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业类型</label><select className="form-input w-32"><option>全部</option><option>生产商</option><option>供货商</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚类型</label><select className="form-input w-32"><option>全部</option><option>警告</option><option>暂停资格</option><option>取消资格</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚期限</label><input className="form-input w-32" type="date" /></div>
            <div className="flex gap-2 ml-auto">
              <button className="btn-default">重置</button>
              <button className="btn-primary">查询</button>
            </div>
          </div>
        </div>
      )}

      {/* Search area - complaint only */}
      {activeTab === 'complaint' && (
        <div className="flex justify-between items-center">
          <div className="flex gap-3 items-center">
            <input
              placeholder="投诉人/投诉对象"
              value={complaintSearch}
              onChange={e => setComplaintSearch(e.target.value)}
              className="form-input w-56"
            />
            <select
              value={complaintStatusFilter}
              onChange={e => setComplaintStatusFilter(e.target.value)}
              className="form-input w-32"
            >
              <option value="">全部状态</option>
              <option value="pending">待处理</option>
              <option value="processing">处理中</option>
              <option value="resolved">已解决</option>
            </select>
            <button className="btn-primary text-xs">查询</button>
            {(complaintSearch || complaintStatusFilter) && (
              <button onClick={() => { setComplaintSearch(''); setComplaintStatusFilter('') }} className="text-xs" style={{ color: 'var(--text-secondary)' }}>重置</button>
            )}
          </div>
          <button
            onClick={() => setComplaintModalOpen(true)}
            className="btn-danger text-xs"
          >投诉登记</button>
        </div>
      )}

      {/* Complaint List */}
      {activeTab === 'complaint' && (
        <div className="space-y-3">
          {filteredComplaint.map(item => (
            <div key={item.id} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs" style={{ color: 'var(--text-disabled)' }}>{item.id}</span>
                  <span className="text-sm font-medium">{item.complainant}</span>
                  <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.org}</span>
                  <span className="tag tag-gray text-xs">{item.targetType}</span>
                </div>
                <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                  {statusColors[item.status].text}
                </span>
              </div>
              <div className="text-sm mb-2">
                <span style={{ color: 'var(--text-secondary)' }}>投诉对象：</span>{item.targetName}
              </div>
              <p className="text-sm mb-3">{item.content}</p>
              <div className="flex justify-between items-center text-xs" style={{ color: 'var(--text-disabled)' }}>
                <span>{item.time}</span>
                <div className="flex gap-2">
                  {item.status === 'pending' && (
                    <button onClick={() => processComplaint(item.id)} className="px-3 py-1 rounded border text-xs hover:bg-blue-50" style={{ borderColor: '#1890ff', color: '#1890ff' }}>受理</button>
                  )}
                  {(item.status === 'processing' || item.status === 'pending') && (
                    <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="px-3 py-1 rounded border text-xs hover:bg-green-50" style={{ borderColor: '#52c41a', color: '#52c41a' }}>回复</button>
                  )}
                  {item.reply && (
                    <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>查看回复</button>
                  )}
                </div>
              </div>
              {item.reply && (
                <div className="mt-3 p-3 rounded text-sm" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                  <span style={{ color: '#52c41a' }} className="font-medium">回复：</span>
                  <span>{item.reply}</span>
                </div>
              )}
            </div>
          ))}
          {filteredComplaint.length === 0 && (
            <div className="text-center py-16 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无投诉记录</div>
          )}
        </div>
      )}

            {/* Enterprise List Table */}
      {activeTab === 'enterprise' && (
        <div className="content-card overflow-hidden">
          <table className="data-table">
            <thead>
              <tr>
                <th>企业名称</th>
                <th>统一社会信用代码</th>
                <th>联系人</th>
                <th>联系电话</th>
                <th>供应商类型</th>
                <th>资质状态</th>
                <th>注册时间</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {enterprises.map(e => (
                <tr key={e.id}>
                  <td className="font-medium">{e.name}</td>
                  <td className="font-mono text-xs">{e.creditCode}</td>
                  <td>{e.contact}</td>
                  <td>{e.phone}</td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {e.supplierTypes.map(t => (
                        <span key={t} className="tag text-xs" style={{
                          background: t === 'supplier' ? '#e6f7ff' : t === 'producer' ? '#f6ffed' : '#fff7e6',
                          color: t === 'supplier' ? '#1890ff' : t === 'producer' ? '#52c41a' : '#faad14',
                          border: `1px solid ${t === 'supplier' ? '#91d5ff' : t === 'producer' ? '#b7eb8f' : '#ffd591'}`
                        }}>
                          {t === 'supplier' ? '管理供应商' : t === 'producer' ? '生产商' : '协议供货商'}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <span className={`tag text-xs ${e.qualifyStatus === 'normal' ? 'tag-green' : e.qualifyStatus === 'paused' ? 'tag-yellow' : e.qualifyStatus === 'pending_audit' ? 'tag-orange' : 'tag-gray'}`}>
                      {e.qualifyStatus === 'normal' ? '正常' : e.qualifyStatus === 'paused' ? '暂停' : e.qualifyStatus === 'pending_audit' ? '待审核' : '作废'}
                    </span>
                  </td>
                  <td className="text-xs">{e.registerTime}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDetail(e, 'view')}>查看</button>
                      {e.qualifyStatus === 'pending_audit' && (
                        <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openDetail(e, 'audit')}>审核</button>
                      )}
                      <button className="text-xs hover:underline" style={{ color: '#722ed1' }} onClick={() => openEnterpriseProducts(e)}>商品</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Enterprise Products Modal */}
      {enterpriseProductsOpen && selectedEnterpriseForProducts && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEnterpriseProductsOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-lg font-semibold">{selectedEnterpriseForProducts.name} — 关联商品</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>统一社会信用代码：{selectedEnterpriseForProducts.creditCode}</p>
              </div>
              <button onClick={() => setEnterpriseProductsOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              {(() => {
                const relatedProducts = productList.filter(p => p.supplierId === selectedEnterpriseForProducts.id)
                if (relatedProducts.length === 0) {
                  return (
                    <div className="flex flex-col items-center justify-center py-12" style={{ color: 'var(--text-disabled)' }}>
                      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mb-3"><path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2z"/></svg>
                      <p className="text-sm">该企业暂无关联商品</p>
                    </div>
                  )
                }
                return (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>一级分类</th>
                        <th>二级分类</th>
                        <th>三级分类</th>
                        <th>装备名称</th>
                        <th>型号</th>
                        <th>装备编码</th>
                        <th>申请供应商</th>
                        <th>计量单位</th>
                        <th>参考单价 *</th>
                        <th>是否电池</th>
                        <th>保养周期</th>
                        <th>备注</th>
                        <th>状态</th>
                        <th>操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {relatedProducts.map(p => (
                        <tr key={p.id}>
                          <td>{p.category1}</td>
                          <td>{p.category2}</td>
                          <td>{p.category3}</td>
                          <td className="font-medium">{p.name}</td>
                          <td className="font-mono text-xs">{p.model}</td>
                          <td className="font-mono text-xs">{p.id}</td>
                          <td>{p.applicantSupplier}</td>
                          <td>{p.unit}</td>
                          <td className="font-mono">¥{p.price.toLocaleString()}</td>
                          <td><span className={`tag text-xs ${p.hasBattery ? 'tag-green' : 'tag-gray'}`}>{p.hasBattery ? '是' : '否'}</span></td>
                          <td>{p.maintainPeriod}</td>
                          <td className="text-xs">{p.remark}</td>
                          <td><span className={`tag text-xs ${p.status === 'on' ? 'tag-green' : p.status === 'review' ? 'tag-orange' : 'tag-gray'}`}>{p.status === 'on' ? '已通过' : p.status === 'review' ? '待审核' : '已驳回'}</span></td>
                          <td>
                            <div className="flex items-center gap-2">
                              <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openProductDetail(p, 'view')}>查看</button>
                              {p.status === 'review' && <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openAuditModal(p)}>审核</button>}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )
              })()}
            </div>
            <div className="sticky bottom-0 z-10 px-6 py-3 border-t bg-gray-50 flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                共 {productList.filter(p => p.supplierId === selectedEnterpriseForProducts.id).length} 个关联商品
              </span>
              <button className="btn-default" onClick={() => setEnterpriseProductsOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* Product Search + List */}
      {activeTab === 'product' && (
        <>
          {/* 子Tab切换 */}
          <div className="flex gap-0 border-b" style={{ borderColor: 'var(--border-color)' }}>
            <button className={`px-4 py-2 text-xs font-medium border-b-2 transition-colors ${productSubTab === 'audit' ? 'border-blue-500' : 'border-transparent'}`} style={{ color: productSubTab === 'audit' ? 'var(--primary-blue)' : 'var(--text-secondary)' }} onClick={() => setProductSubTab('audit')}>装备信息审核</button>
            <button className={`px-4 py-2 text-xs font-medium border-b-2 transition-colors ${productSubTab === 'category' ? 'border-blue-500' : 'border-transparent'}`} style={{ color: productSubTab === 'category' ? 'var(--primary-blue)' : 'var(--text-secondary)' }} onClick={() => setProductSubTab('category')}>装备分类</button>
          </div>

          {productSubTab === 'audit' && (
            <>
              <div className="flex items-center gap-2">
                <button className="btn-primary text-xs" onClick={openAddProduct}>
                  <span className="flex items-center gap-1">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    新增商品报备
                  </span>
                </button>
              </div>
              <div className="content-card p-4">
                <div className="flex flex-wrap items-end gap-3">
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业名称</label><select className="form-input w-48"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>大疆创新科技有限公司</option><option>中兴通讯股份有限公司</option><option>烽火通信科技股份有限公司</option></select></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入装备名称" /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>警采入围</label><select className="form-input w-28"><option>全部</option><option>已入围</option><option>未入围</option></select></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报备状态</label><select className="form-input w-28"><option>全部</option><option>待审</option><option>已上架</option><option>已下架</option></select></div>
                  <div className="flex gap-2 ml-auto">
                    <button className="btn-default">重置</button>
                    <button className="btn-primary">查询</button>
                  </div>
                </div>
              </div>
              <div className="content-card overflow-hidden">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>一级分类</th>
                      <th>二级分类</th>
                      <th>三级分类</th>
                      <th>装备名称</th>
                      <th>型号</th>
                      <th>装备编码</th>
                      <th>申请供应商</th>
                      <th>计量单位</th>
                      <th>参考单价 *</th>
                      <th>是否电池</th>
                      <th>保养周期</th>
                      <th>备注</th>
                      <th>状态</th>
                      <th>操作</th>
                    </tr>
                  </thead>
                  <tbody>
                    {productList.map(p => (
                      <tr key={p.id}>
                        <td>{p.category1}</td>
                        <td>{p.category2}</td>
                        <td>{p.category3}</td>
                        <td className="font-medium">{p.name}</td>
                        <td className="font-mono text-xs">{p.model}</td>
                        <td className="font-mono text-xs">{p.id}</td>
                        <td>{p.applicantSupplier}</td>
                        <td>{p.unit}</td>
                        <td className="font-mono">¥{p.price.toLocaleString()}</td>
                        <td><span className={`tag text-xs ${p.hasBattery ? 'tag-green' : 'tag-gray'}`}>{p.hasBattery ? '是' : '否'}</span></td>
                        <td>{p.maintainPeriod}</td>
                        <td className="text-xs">{p.remark}</td>
                        <td><span className={`tag text-xs ${p.status === 'on' ? 'tag-green' : p.status === 'review' ? 'tag-orange' : 'tag-gray'}`}>{p.status === 'on' ? '已通过' : p.status === 'review' ? '待审核' : '已驳回'}</span></td>
                        <td>
                          <div className="flex items-center gap-2">
                            <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openProductDetail(p, 'view')}>查看</button>
                            {p.status === 'review' && <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openAuditModal(p)}>审核</button>}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          {productSubTab === 'category' && <EquipCategoryTable />}
        </>
      )}

      {/* Product Audit Modal */}
      {auditModalOpen && auditProduct && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAuditModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">装备管理</h3>
              <button onClick={() => setAuditModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Body */}
            <div className="px-6 py-5 space-y-4">
              {/* Editable Basic Info */}
              <div className="grid grid-cols-2 gap-3">
                {/* 一级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>一级分类</label>
                  <select
                    className="form-input w-full text-sm"
                    value={auditCategory1}
                    onChange={e => {
                      const val = e.target.value
                      setAuditCategory1(val)
                      setAuditCategory2('')
                      setAuditCategory3('')
                      setAuditLevel2Code('')
                      setAuditLevel3Code('')
                      if (val && categoryTree[val]) {
                        setAuditLevel1Code(categoryTree[val].code)
                      }
                      setAuditCode('')
                    }}
                  >
                    <option value="">请选择</option>
                    {Object.keys(categoryTree).map(l1 => (
                      <option key={l1} value={l1}>{l1}</option>
                    ))}
                  </select>
                </div>
                {/* 二级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>二级分类</label>
                  <select
                    className="form-input w-full text-sm"
                    value={auditCategory2}
                    onChange={e => {
                      const val = e.target.value
                      setAuditCategory2(val)
                      setAuditCategory3('')
                      setAuditLevel3Code('')
                      if (val && auditCategory1 && categoryTree[auditCategory1]?.children[val]) {
                        setAuditLevel2Code(categoryTree[auditCategory1].children[val].code)
                      }
                      setAuditCode('')
                    }}
                    disabled={!auditCategory1}
                  >
                    <option value="">请选择</option>
                    {auditCategory1 && categoryTree[auditCategory1] && Object.keys(categoryTree[auditCategory1].children).map(l2 => (
                      <option key={l2} value={l2}>{l2}</option>
                    ))}
                  </select>
                </div>
                {/* 三级分类 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>三级分类</label>
                  <select
                    className="form-input w-full text-sm"
                    value={auditCategory3}
                    onChange={e => {
                      const val = e.target.value
                      setAuditCategory3(val)
                      if (val && auditCategory1 && auditCategory2 && categoryTree[auditCategory1]?.children[auditCategory2]?.children[val]) {
                        const l3Code = categoryTree[auditCategory1].children[auditCategory2].children[val].code
                        setAuditLevel3Code(l3Code)
                        // 自动生成装备编码
                        const l1Code = categoryTree[auditCategory1].code
                        const l2Code = categoryTree[auditCategory1].children[auditCategory2].code
                        setAuditCode(generateEquipCode(l1Code, l2Code, l3Code, productList))
                      }
                    }}
                    disabled={!auditCategory2}
                  >
                    <option value="">请选择</option>
                    {auditCategory1 && auditCategory2 && categoryTree[auditCategory1]?.children[auditCategory2] && Object.keys(categoryTree[auditCategory1].children[auditCategory2].children).map(l3 => (
                      <option key={l3} value={l3}>{l3}</option>
                    ))}
                  </select>
                </div>
                {/* 装备编码 — 自动生成，只读 */}
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>装备编码 <span style={{ color: 'var(--text-disabled)' }}>(自动生成)</span></label>
                  <input className="form-input w-full text-sm font-mono bg-gray-50" value={auditCode} readOnly />
                </div>
                {/* 装备名称 */}
                <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                  <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</span>
                  <span className="text-sm font-medium">{auditProduct.name}</span>
                </div>
                {/* 型号 */}
                <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                  <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>型号</span>
                  <span className="text-sm font-medium">{auditProduct.model}</span>
                </div>
                {/* 申请供应商 — 自动填写，不可修改 */}
                <div className="col-span-2">
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>申请供应商</label>
                  <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={auditSupplierName} readOnly />
                </div>
              </div>

              {/* Audit Result */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <label className="block text-sm font-medium mb-2">审核结果</label>
                <div className="flex items-center gap-6">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="auditResult"
                      value="pass"
                      checked={auditResult === 'pass'}
                      onChange={() => setAuditResult('pass')}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">通过</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="auditResult"
                      value="reject"
                      checked={auditResult === 'reject'}
                      onChange={() => setAuditResult('reject')}
                      className="w-4 h-4"
                    />
                    <span className="text-sm">驳回</span>
                  </label>
                </div>
              </div>

              {/* Audit Opinion */}
              <div>
                <label className="block text-sm font-medium mb-2">审核意见</label>
                <textarea
                  className="form-input w-full h-20 resize-none"
                  placeholder="请输入审核意见..."
                  value={auditOpinion}
                  onChange={e => setAuditOpinion(e.target.value)}
                />
                <p className="text-xs mt-1.5" style={{ color: '#faad14' }}>注：审核通过后，将自动归入装备编码库</p>
              </div>
            </div>
            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setAuditModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleAudit}>确认</button>
            </div>
          </div>
        </div>
      )}

      {/* Sync search area */}

      {activeTab === 'sync' && (

        <>

          <div className="flex items-center gap-2">

            <button

              className="btn-default text-xs"

              onClick={() => setActiveTab('enterprise')}

            >

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>

                返回供应商信息

              </span>

            </button>

            <button

              className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors border`}

              style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}

              onClick={() => setSyncView('log')}

            >

              同步日志

            </button>

              <button className="btn-primary ml-3 text-xs" onClick={openBatchSync}>

                <span className="flex items-center gap-1">

                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

                  一键全部覆盖修改

                </span>

              </button>



          </div>

        </>

      )}

        {activeTab === 'penalty' && penaltySyncView === 'list' && (

          <table className="data-table">

            <thead>

              <tr><th className="w-10"><input type="checkbox"/></th><th>处罚单号</th><th>供应商名称</th><th>企业类型</th><th>处罚类型</th><th>处罚事由</th><th>处罚日期</th><th>处罚期限</th><th>发布单位</th><th>操作</th></tr>

            </thead>

            <tbody>

              {penaltyList.map(p => (

                <tr key={p.id}>

                  <td><input type="checkbox"/></td>

                  <td className="font-mono text-xs">{p.id}</td>

                  <td>{p.supplierName}</td>

                  <td><span className="tag text-xs" style={{ background: p.enterpriseType === 'producer' ? '#e6f7ff' : '#f6ffed', color: p.enterpriseType === 'producer' ? '#1890ff' : '#52c41a', border: `1px solid ${p.enterpriseType === 'producer' ? '#91d5ff' : '#b7eb8f'}` }}>{p.enterpriseType === 'producer' ? '生产商' : '协议供货商'}</span></td>

                  <td><span className={`tag text-xs ${p.penaltyType === 'warning' ? 'tag-yellow' : p.penaltyType === 'suspend' ? 'tag-red' : 'tag-gray'}`}>{p.penaltyType === 'warning' ? '⚠️ 警告' : p.penaltyType === 'suspend' ? '⏸ 暂停资格' : '🚫 取消资格'}</span></td>

                  <td>{p.reason}</td>

                  <td>{p.penaltyDate}</td>

                  <td className="text-xs">{p.durationStart} ~ {p.durationEnd}</td>

                  <td>{p.dept}</td>
                  <td>

                    <div className="flex items-center gap-2">

                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openPenaltyDetail(p, 'view')}>查看</button>

                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openPenaltyDetail(p, 'edit')}>修改</button>

                      <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDeletePenalty(p)}>删除</button>

                    </div>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        )}





      {/* Enterprise Detail / Add / Edit Drawer */}

      {drawerOpen && activeTab === 'enterprise' && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <h3 className="text-lg font-semibold">{drawerTitle}</h3>

              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* Section 1: 企业基本信息 */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>企业基本信息</h4>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 企业名称</label>
                    <input className="form-input" defaultValue={selectedEnterprise?.name || ''} placeholder="请输入企业名称" readOnly={editMode === 'view' || editMode === 'audit'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单位简称</label>
                    <input className="form-input" defaultValue={selectedEnterprise?.shortName || ''} placeholder="请输入单位简称" readOnly={editMode === 'view' || editMode === 'audit'} />
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 统一社会信用代码</label>
                      <input className="form-input font-mono" defaultValue={selectedEnterprise?.creditCode || ''} placeholder="请输入统一社会信用代码" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                    {editMode !== 'view' && editMode !== 'audit' && (
                      <div className="flex items-end">
                        <button className="btn-default text-xs px-3 py-1.5 mb-0.5" style={{ color: '#1890ff', borderColor: '#91caff' }}>注册信息验证</button>
                      </div>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 注册地</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.address || ''} placeholder="请输入注册地" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 法定代表人/注册人</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.legalPerson || ''} placeholder="请输入法定代表人" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 注册资金</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.registeredCapital || ''} placeholder="请输入注册资金" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 注册地-省（市）</label>
                      <select className="form-input" defaultValue={selectedEnterprise?.province || ''} disabled={editMode === 'view' || editMode === 'audit'}>
                        <option value="">请选择</option>
                        <option>北京市</option><option>上海市</option><option>广东省</option><option>江苏省</option>
                        <option>浙江省</option><option>山东省</option><option>河南省</option><option>四川省</option>
                        <option>湖北省</option><option>湖南省</option><option>河北省</option><option>福建省</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 营业执照</label>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-auto mb-2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>图片上传，最多可上传5个文件，每个文件不超过10M</p>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-2" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 供应商类型 <span className="text-xs font-normal" style={{ color: 'var(--text-disabled)' }}>（可多选）</span></label>
                    <div className="grid grid-cols-3 gap-3">
                      {[
                        { key: 'producer', label: '生产商' },
                        { key: 'agreement', label: '协议供货商' },
                        { key: 'supplier', label: '供应商' },
                      ].map(t => (
                        <label key={t.key} className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 cursor-pointer transition-all ${selectedEnterprise?.supplierTypes?.includes(t.key as SupplierType) ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}>
                          <input type="checkbox" className="hidden" defaultChecked={selectedEnterprise?.supplierTypes?.includes(t.key as SupplierType) || false} disabled={editMode === 'view' || editMode === 'audit'} />
                          <div className={`w-4 h-4 rounded border flex items-center justify-center ${selectedEnterprise?.supplierTypes?.includes(t.key as SupplierType) ? 'bg-blue-500 border-blue-500' : 'border-gray-300'}`}>
                            {selectedEnterprise?.supplierTypes?.includes(t.key as SupplierType) && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
                          </div>
                          <span className="text-xs">{t.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 合作单位</label>
                    <select className="form-input" defaultValue={selectedEnterprise?.coopUnit || ''} disabled={editMode === 'view' || editMode === 'audit'}>
                      <option value="">请选择意向供货单位</option>
                      <option>省公安厅 / 科信处</option>
                      <option>省公安厅 / 网安总队</option>
                      <option>省公安厅 / 刑侦总队</option>
                      <option>省公安厅 / 治安总队</option>
                      <option>省公安厅 / 交警总队</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Section 2: 联系人信息 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ color: 'var(--text-secondary)' }}><path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/></svg> 联系人信息</h4>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 联系人</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.contactPerson || ''} placeholder="请输入联系人" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 证件类型</label>
                      <select className="form-input" defaultValue={selectedEnterprise?.idType || '身份证'} disabled={editMode === 'view' || editMode === 'audit'}>
                        <option value="">请选择</option>
                        <option>身份证</option>
                        <option>护照</option>
                        <option>港澳通行证</option>
                      </select>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 证件号码</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.idNumber || ''} placeholder="请输入证件号码" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 联系电话</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.contactPhone || ''} placeholder="请输入联系电话" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 验证码</label>
                      <div className="flex gap-2">
                        <input className="form-input flex-1" placeholder="请输入验证码" readOnly={editMode === 'view' || editMode === 'audit'} />
                        {editMode !== 'view' && editMode !== 'audit' && (
                          <button className="btn-default text-xs px-3 py-1 whitespace-nowrap" style={{ color: '#1890ff', borderColor: '#91caff' }}>发送验证码</button>
                        )}
                      </div>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>电子邮箱</label>
                      <input className="form-input" defaultValue={selectedEnterprise?.email || ''} placeholder="请输入电子邮箱" readOnly={editMode === 'view' || editMode === 'audit'} />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 负责人</label>
                    <input className="form-input" defaultValue={selectedEnterprise?.manager || ''} placeholder="请输入负责人" readOnly={editMode === 'view' || editMode === 'audit'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}><span className="text-red-400">*</span> 身份证正反面</label>
                    <div className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-auto mb-2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>请上传清晰的身份证照片，支持JPG、PNG格式，每个文件不超过10M</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 3: 资质材料 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>资质材料</h4>
                <div className="mb-6">
                  <h5 className="text-sm font-medium mb-3 flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> 一、必填</h5>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: '营业执照副本', sub: '（原件扫描/加盖公章）' },
                      { label: '法定代表人身份证', sub: '（正反面）' },
                      { label: '相关生产经营资质许可证', sub: '（如行业强制资质，非通用资质）' },
                      { label: '"信用中国"信用信息报告', sub: '' },
                      { label: '"中国政府采购网"信用查询截图', sub: '' },
                    ].map((item, idx) => (
                      <div key={idx} className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                        <p className="text-xs font-medium mb-1">{item.label} <span className="font-normal" style={{ color: 'var(--text-secondary)' }}>{item.sub}</span></p>
                        <div className="border border-dashed rounded p-3 text-center mt-2" style={{ borderColor: 'var(--border-color)' }}>
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-auto mb-1"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                          <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>点击上传</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h5 className="text-sm font-medium mb-3 flex items-center gap-2"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg> 二、选填</h5>
                  <div className="grid grid-cols-2 gap-3">
                    {[
                      { label: '开户许可证或基本存款账户信息', sub: '' },
                      { label: '近半年内任一月份完税证明', sub: '' },
                      { label: '上一年度税务评级截图', sub: '' },
                      { label: '公司及产品简介', sub: '（图文/PPT均可）' },
                      { label: '供货业绩', sub: '（可隐去敏感信息的合同/中标通知书）' },
                    ].map((item, idx) => (
                      <div key={idx} className="border rounded-lg p-4 cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                        <p className="text-xs font-medium mb-1">{item.label} <span className="font-normal" style={{ color: 'var(--text-secondary)' }}>{item.sub}</span></p>
                        <div className="border border-dashed rounded p-3 text-center mt-2" style={{ borderColor: 'var(--border-color)' }}>
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="2" className="mx-auto mb-1"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                          <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>点击上传</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* 审批意见 - 仅审核模式显示 */}
              {editMode === 'audit' && (
                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-orange-500"/>审批意见</h4>
                  <textarea
                    className="form-input w-full text-sm"
                    rows={3}
                    value={auditComment}
                    onChange={e => setAuditComment(e.target.value)}
                    placeholder="请输入审批意见..."
                  />
                </div>
              )}
            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setDrawerOpen(false); setAuditComment('') }}>
                {editMode === 'view' ? '关闭' : '取消'}
              </button>
              {editMode === 'audit' && (
                <>
                  <button className="btn-danger" onClick={() => { alert(`已驳回\n审批意见：${auditComment || '无'}`); setDrawerOpen(false); setAuditComment('') }}>驳回</button>
                  <button className="btn-primary" onClick={() => { alert(`审核通过\n审批意见：${auditComment || '无'}`); setDrawerOpen(false); setAuditComment('') }}>通过</button>
                </>
              )}
              {(editMode === 'edit' || editMode === 'add') && (
                <>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary">保存</button>
                </>
              )}
            </div>

          </div>

        </div>

      )}



      {/* Register audit drawer */}

      



      {/* Delete Confirmation Modal */}

      {deleteConfirmOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirmOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-4">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>

              </div>

              <h3 className="text-base font-semibold">确认删除</h3>

            </div>

            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除企业"<span className="font-medium">{selectedEnterprise?.name}</span>"？删除后数据将无法恢复，请谨慎操作。</p>

            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => setDeleteConfirmOpen(false)}>取消</button>

              <button className="btn-danger" onClick={confirmDelete}>确认删除</button>

            </div>

          </div>

        </div>

      )}



      {/* Sync Detail Modal - Single Item */}

      {syncDetailOpen && selectedDiff && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setSyncDetailOpen(false); setSyncReason('') }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">


            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

              </div>

              <h3 className="text-base font-semibold">逐条确认修改</h3>

            </div>



            {/* Enterprise info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

              <div className="flex items-center justify-between mb-2">

                <span className="font-medium">{selectedDiff.enterpriseName}</span>

                <span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedDiff.creditCode}</span>

              </div>

              <div className="flex items-center gap-3 text-xs">

                <span style={{ color: 'var(--text-secondary)' }}>字段：<span className="font-medium" style={{ color: 'var(--text-primary)' }}>{selectedDiff.fieldName}</span></span>

                <span style={{ color: 'var(--text-secondary)' }}>类型：<span className="tag text-xs" style={{ background: selectedDiff.enterpriseType === 'producer' ? '#e6f7ff' : '#f6ffed', color: selectedDiff.enterpriseType === 'producer' ? '#1890ff' : '#52c41a', border: `1px solid ${selectedDiff.enterpriseType === 'producer' ? '#91d5ff' : '#b7eb8f'}` }}>{selectedDiff.enterpriseType === 'producer' ? '生产商' : '协议供货商'}</span></span>

              </div>

            </div>



            {/* Value comparison */}

            <div className="grid grid-cols-2 gap-4 mb-4">

              <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>系统现有值</p>

                <p className="text-sm font-medium">{selectedDiff.localValue}</p>

              </div>

              <div className="p-3 rounded-lg border" style={{ borderColor: selectedDiff.diffLevel === 'critical' ? '#ffccc7' : '#ffe58f', background: selectedDiff.diffLevel === 'critical' ? '#fff2f0' : '#fffbe6' }}>

                <p className="text-xs mb-1" style={{ color: selectedDiff.diffLevel === 'critical' ? '#ff4d4f' : '#faad14' }}>外部平台值</p>

                <p className="text-sm font-medium" style={{ color: selectedDiff.diffLevel === 'critical' ? '#ff4d4f' : 'var(--text-primary)' }}>{selectedDiff.externalValue}</p>

              </div>

            </div>



            {/* External status */}

            <div className="flex items-center gap-4 mb-4 text-xs">

              <span style={{ color: 'var(--text-secondary)' }}>外部企业状态：{selectedDiff.externalStatus === 'active' ? <span className="tag tag-green text-xs">正常</span> : selectedDiff.externalStatus === 'revoked' ? <span className="tag tag-red text-xs">吊销</span> : <span className="tag tag-red text-xs">注销</span>}</span>

              <span style={{ color: 'var(--text-secondary)' }}>抓取时间：{selectedDiff.externalFetchTime}</span>

              <span style={{ color: 'var(--text-secondary)' }}>差异级别：{selectedDiff.diffLevel === 'critical' ? <span className="tag tag-red text-xs">严重异常</span> : selectedDiff.diffLevel === 'warning' ? <span className="tag tag-orange text-xs">警告</span> : <span className="tag tag-yellow text-xs">普通不一致</span>}</span>

            </div>



            {/* Reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>修改原因 <span className="text-red-400">*</span></label>

              <textarea

                className="form-input w-full text-sm"

                rows={3}

                placeholder="请填写修改原因（如：营业执照变更、数据录入错误、系统误判）..."

                value={syncReason}

                onChange={e => setSyncReason(e.target.value)}

              />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setSyncDetailOpen(false); setSyncReason('') }}>取消</button>

              <button

                className="btn-primary"

                disabled={!syncReason.trim()}

                onClick={confirmSingleSync}

              >

                确认修改

              </button>

            </div>

          </div>

        </div>

      )}



      {/* Batch Sync Modal */}

      {batchSyncOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setBatchSyncOpen(false); setBatchReason('') }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">


            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

              </div>

              <h3 className="text-base font-semibold">一键全部覆盖修改</h3>

            </div>



            {/* Auto-filter info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>

              <div className="flex items-center gap-2 mb-2">

                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>

                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>自动过滤完成</span>

              </div>

              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统已自动剔除 <span className="font-medium" style={{ color: '#ff4d4f' }}>{syncDiffList.filter(d => d.diffLevel === 'critical' && !d.synced).length}</span> 条严重异常记录。本次将批量处理 <span className="font-medium">{syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced).length}</span> 条普通差异。</p>

            </div>



            {/* Affected items list */}

            <div className="mb-4 max-h-40 overflow-y-auto">

              <p className="text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>待处理差异列表：</p>

              {syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced).map(d => (

                <div key={d.id} className="flex items-center justify-between p-2 rounded border mb-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <span className="text-xs">{d.enterpriseName} - {d.fieldName}</span>

                  <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{d.localValue} → <span style={{ color: 'var(--primary-blue)' }}>{d.externalValue}</span></span>

                </div>

              ))}

            </div>



            {/* Batch reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批量修改原因 <span className="text-red-400">*</span></label>

              <textarea

                className="form-input w-full text-sm"

                rows={3}

                placeholder="请填写批量修改原因（如：企业统一地址变更、批量资质更新）..."

                value={batchReason}

                onChange={e => setBatchReason(e.target.value)}

              />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setBatchSyncOpen(false); setBatchReason('') }}>取消</button>

              <button

                className="btn-primary"

                disabled={!batchReason.trim()}

                onClick={confirmBatchSync}

              >

                确认全部修改

              </button>

            </div>

          </div>

        </div>

      )}



      {/* Product Detail / Edit Drawer */}

      {drawerOpen && activeTab === 'product' && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <h3 className="text-lg font-semibold">{drawerTitle}</h3>

              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="p-6 space-y-5 overflow-y-auto flex-1">

              {/* Section 1: Basic Info */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>商品信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" placeholder="请输入物资名称" defaultValue={selectedProduct?.name || ''} readOnly={productEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规格型号</label>
                    <input className="form-input" placeholder="请输入规格型号" defaultValue={selectedProduct?.model || ''} readOnly={productEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>一级分类 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.category1 || ''} disabled={productEditMode === 'view'}>
                      <option>请选择</option><option>通信设备</option><option>照明设备</option><option>监控设备</option><option>救援装备</option><option>防护装备</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>二级分类 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.category2 || ''} disabled={productEditMode === 'view'}>
                      <option>请选择</option><option>手持设备</option><option>记录设备</option><option>空中设备</option><option>便携照明</option><option>防护服装</option><option>头部防护</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>三级分类 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.category3 || ''} disabled={productEditMode === 'view'}>
                      <option>请选择</option><option>智能手持终端</option><option>执法记录仪</option><option>多旋翼无人机</option><option>LED应急灯</option><option>防弹背心</option><option>防弹头盔</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单位 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.unit || '台'} disabled={productEditMode === 'view'}>
                      <option>台</option><option>套</option><option>件</option><option>个</option><option>支</option><option>面</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单价(¥) <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" type="number" placeholder="¥" defaultValue={selectedProduct?.price || ''} readOnly={productEditMode === 'view'} />
                  </div>
                </div>
              </div>

              {/* Section 2: Extra Info */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>其他信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否电池</label>
                    <select className="form-input" defaultValue={selectedProduct?.hasBattery ? '是' : '否'} disabled={productEditMode === 'view'}>
                      <option>否</option><option>是</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>保养周期</label>
                    <select className="form-input" defaultValue={selectedProduct?.maintainPeriod || ''} disabled={productEditMode === 'view'}>
                      <option>请选择</option><option>3个月</option><option>6个月</option><option>12个月</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                    <input className="form-input w-full" placeholder="请输入备注" defaultValue={selectedProduct?.remark || ''} readOnly={productEditMode === 'view'} />
                  </div>
                </div>
              </div>







              {/* Section 4: Image Upload */}

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>商品图片</h4>

                <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>

                  <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{productEditMode === 'view' ? '暂无商品图片' : '请上传商品图片'}</p>

                  <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 JPG、PNG 格式</p>

                </div>

              </div>



              {/* Section 5: Audit Flow */}

              {selectedProduct && (

                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>报备流程</h4>

                  <div className="flex items-center gap-2">

                    {[

                      { label: '填写信息', active: true },

                      { label: '提交报备', active: selectedProduct.status !== 'off' },

                      { label: '审核', active: selectedProduct.status === 'on' || selectedProduct.status === 'off' },

                      { label: selectedProduct.status === 'on' ? '已通过' : selectedProduct.status === 'off' ? '已驳回' : '待审核', active: selectedProduct.status === 'on' || selectedProduct.status === 'off' },

                    ].map((step, i, arr) => (

                      <div key={i} className="flex items-center gap-2 flex-1">

                        <div className="flex flex-col items-center">

                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${step.active ? 'text-white' : 'text-gray-400'}`} style={{ background: step.active ? '#52c41a' : '#f5f5f5', border: `2px solid ${step.active ? '#52c41a' : '#d9d9d9'}` }}>

                            {step.active ? i + 1 : <span style={{ color: '#bfbfbf' }}>{i + 1}</span>}

                          </div>

                          <span className={`text-xs mt-1 ${step.active ? 'text-green-600 font-medium' : 'text-gray-400'}`}>{step.label}</span>

                        </div>

                        {i < arr.length - 1 && <div className="flex-1 h-0.5 mx-1" style={{ background: step.active ? '#52c41a' : '#d9d9d9' }} />}

                      </div>

                    ))}

                  </div>

                </div>

              )}

            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default" onClick={() => setDrawerOpen(false)}>{productEditMode === 'view' ? '关闭' : '取消'}</button>

              {productEditMode !== 'view' && (

                <>

                  <button className="btn-default">保存草稿</button>

                  <button className="btn-primary">提交报备</button>

                </>

              )}

            </div>

          </div>

        </div>

      )}



      {/* Sync Trigger Modal — 自动同步确认 */}
      {syncTriggerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSyncTriggerOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
              </div>
              <h3 className="text-base font-semibold">同步供应商信息</h3>
            </div>
            <div className="mb-5 space-y-3">
              <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                <div className="flex items-center gap-2 mb-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  <span className="text-sm font-medium" style={{ color: '#52c41a' }}>采购平台已接入</span>
                </div>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统将自动对接采购平台获取最新企业数据</p>
              </div>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>点击确认后，系统将自动执行以下操作：</p>
              <ol className="text-sm space-y-1 ml-4" style={{ color: 'var(--text-secondary)' }}>
                <li>1. 从采购平台获取供应商、生产商、协议供货商最新信息</li>
                <li>2. 自动同步所有企业数据到本系统</li>
                <li>3. 更新企业档案和关联信息</li>
              </ol>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setSyncTriggerOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => { setSyncTriggerOpen(false); alert('同步成功！已同步 128 家供应商信息。') }}>确认同步</button>
            </div>
          </div>
        </div>
      )}



      {/* Log Modal — 供应商信息页点击"操作日志"弹出 */}

      {logModalOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setLogModalOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>

              <div className="flex items-center gap-3">

                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                </div>

                <h3 className="text-base font-semibold">同步操作日志</h3>

              </div>

              <button onClick={() => setLogModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>


              <table className="w-full text-sm">

                <thead>

                  <tr style={{ background: 'var(--table-header-bg)' }}>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>类型</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>企业ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改字段</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改前</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改后</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改原因</th>

                  </tr>

                </thead>

                <tbody>

                  {syncLogList.map(l => (

                    <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>

                      <td className="px-3 py-2 font-mono text-xs">{l.id}</td>

                      <td className="px-3 py-2">{l.operator}</td>

                      <td className="px-3 py-2 text-xs">{l.time}</td>

                      <td className="px-3 py-2"><span className={`tag ${l.type === '逐条' ? 'tag-blue' : 'tag-green'} text-xs`}>{l.type}</span></td>

                      <td className="px-3 py-2 font-mono text-xs">{l.enterpriseId}</td>

                      <td className="px-3 py-2">{l.field}</td>

                      <td className="px-3 py-2 text-xs" style={{ color: 'var(--text-secondary)' }}>{l.oldValue}</td>

                      <td className="px-3 py-2 text-xs font-medium">{l.newValue}</td>

                      <td className="px-3 py-2 text-xs">{l.reason}</td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

            <div className="px-6 py-4 border-t flex items-center justify-end" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default text-xs" onClick={() => setLogModalOpen(false)}>关闭</button>

            </div>

          </div>

      )}



      {/* Penalty Sync Trigger Modal */}

      {penaltySyncTriggerOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltySyncTriggerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
              </div>
              <h3 className="text-base font-semibold">同步外部处罚信息</h3>
            </div>
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
              <div className="flex items-center gap-2 mb-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>采购平台已接入</span>
              </div>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统将自动对接采购平台，同步供应商处罚记录和评价信息到本系统，无需差异对比。</p>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setPenaltySyncTriggerOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => { setPenaltySyncTriggerOpen(false); alert('同步成功！已从采购平台同步 3 条处罚记录。'); }}>确认同步</button>
            </div>
          </div>

        </div>

      )}



      {/* Penalty Sync Detail Modal - Single Item */}

      {penaltySyncDetailOpen && selectedPenaltyDiff && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setPenaltySyncDetailOpen(false); setPenaltySyncReason(''); setPenaltyRejectReason(''); }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">


            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

              </div>

              <h3 className="text-base font-semibold">逐条确认</h3>

              {selectedPenaltyDiff.isCritical && <span className="tag tag-red text-xs">严重-强制逐条</span>}

            </div>



            {/* External penalty info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

              <div className="flex items-center justify-between mb-2">

                <span className="font-medium">{selectedPenaltyDiff.externalSupplierName}</span>

                <span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenaltyDiff.creditCode}</span>

              </div>

              <div className="flex items-center gap-3 text-xs">

                <span style={{ color: 'var(--text-secondary)' }}>外部编号：<span className="font-medium font-mono">{selectedPenaltyDiff.externalPenaltyId}</span></span>

                <span style={{ color: 'var(--text-secondary)' }}>来源：<span className="font-medium">{selectedPenaltyDiff.sourcePlatform}</span></span>

                <span className="tag text-xs" style={{ background: selectedPenaltyDiff.penaltyType === 'warning' ? '#fffbe6' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#fff2f0' : '#f5f5f5', color: selectedPenaltyDiff.penaltyType === 'warning' ? '#faad14' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#ff4d4f' : '#8c8c8c', border: `1px solid ${selectedPenaltyDiff.penaltyType === 'warning' ? '#ffe58f' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#ffccc7' : '#d9d9d9'}` }}>{selectedPenaltyDiff.penaltyType === 'warning' ? '⚠️ 警告' : selectedPenaltyDiff.penaltyType === 'suspend' ? '⏸ 暂停资格' : '🚫 取消资格'}</span>

              </div>

            </div>



            {/* Detail info */}

            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">

              <div><span style={{ color: 'var(--text-secondary)' }}>处罚日期：</span><span className="font-medium">{selectedPenaltyDiff.penaltyDate}</span></div>

              <div><span style={{ color: 'var(--text-secondary)' }}>处罚期限：</span><span className="font-medium">{selectedPenaltyDiff.duration}</span></div>

              <div className="col-span-2"><span style={{ color: 'var(--text-secondary)' }}>处罚事由：</span><span>{selectedPenaltyDiff.reason}</span></div>

            </div>



            {/* Local match */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#91d5ff', background: '#e6f7ff' }}>

              <p className="text-xs font-medium mb-1" style={{ color: '#1890ff' }}>本地匹配结果</p>

              <p className="text-sm">供应商：{selectedPenaltyDiff.supplierName}（当前资质状态：<span className="tag tag-green text-xs">{selectedPenaltyDiff.localSupplierStatus}</span>）</p>

            </div>



            {/* Adopt action selection */}

            <div className="mb-4">

              <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>采纳操作 <span className="text-red-400">*</span></label>

              <div className="space-y-2">

                <label className="flex items-center gap-2 p-3 rounded border cursor-pointer" style={{ borderColor: penaltyAdoptAction === 'reference_only' ? '#1890ff' : 'var(--border-color)', background: penaltyAdoptAction === 'reference_only' ? '#e6f7ff' : '#fafafa' }}>

                  <input type="radio" name="adoptAction" value="reference_only" checked={penaltyAdoptAction === 'reference_only'} onChange={() => setPenaltyAdoptAction('reference_only')} />

                  <div>

                    <p className="text-sm font-medium">仅记录为外部参考</p>

                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>写入本地处罚表，但不自动变更供应商状态</p>

                  </div>

                </label>

                <label className="flex items-center gap-2 p-3 rounded border cursor-pointer" style={{ borderColor: penaltyAdoptAction === 'sync_status' ? '#1890ff' : 'var(--border-color)', background: penaltyAdoptAction === 'sync_status' ? '#e6f7ff' : '#fafafa' }}>

                  <input type="radio" name="adoptAction" value="sync_status" checked={penaltyAdoptAction === 'sync_status'} onChange={() => setPenaltyAdoptAction('sync_status')} />

                  <div>

                    <p className="text-sm font-medium">同步变更供应商状态</p>

                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>写入本地处罚表，且根据处罚类型联动更新供应商资质状态</p>

                  </div>

                </label>

              </div>

            </div>



            {/* Sync reason */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采纳原因 <span className="text-red-400">*</span></label>

              <textarea className="form-input w-full text-sm" rows={2} placeholder="请填写采纳原因..." value={penaltySyncReason} onChange={e => setPenaltySyncReason(e.target.value)} />

            </div>



            {/* Reject section */}

            <div className="border-t pt-4 mb-4" style={{ borderColor: 'var(--border-color)' }}>

              <label className="block text-xs mb-1 font-medium" style={{ color: '#ff4d4f' }}>驳回原因（如驳回请填写）</label>

              <textarea className="form-input w-full text-sm" rows={2} placeholder="如：信息不实、已过申诉期、与本省采购无关..." value={penaltyRejectReason} onChange={e => setPenaltyRejectReason(e.target.value)} />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setPenaltySyncDetailOpen(false); setPenaltySyncReason(''); setPenaltyRejectReason(''); }}>取消</button>

              <button className="btn-danger" disabled={!penaltyRejectReason.trim()} onClick={rejectSinglePenaltySync}>驳回</button>

              <button className="btn-primary" disabled={!penaltySyncReason.trim()} onClick={confirmSinglePenaltySync}>采纳</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Batch Sync Modal */}

      {penaltyBatchSyncOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setPenaltyBatchSyncOpen(false); setPenaltyBatchReason(''); }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">


            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

              </div>

              <h3 className="text-base font-semibold">批量确认采纳</h3>

            </div>



            {/* Auto-filter info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>

              <div className="flex items-center gap-2 mb-2">

                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>

                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>自动过滤完成</span>

              </div>

              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统已自动剔除 <span className="font-medium" style={{ color: '#ff4d4f' }}>{penaltySyncDiffList.filter(d => d.isCritical && d.syncStatus === 'pending').length}</span> 条严重记录（取消资格/暂停资格）。本次将批量处理 <span className="font-medium">{penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length}</span> 条警告类记录。</p>

            </div>



            {/* Affected items list */}

            <div className="mb-4 max-h-40 overflow-y-auto">

              <p className="text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>待批量处理列表：</p>

              {penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').map(d => (

                <div key={d.id} className="flex items-center justify-between p-2 rounded border mb-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <span className="text-xs">{d.externalSupplierName} - {d.externalPenaltyId}</span>

                  <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{d.sourcePlatform}</span>

                </div>

              ))}

              {penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length === 0 && (

                <p className="text-xs text-center py-2" style={{ color: 'var(--text-secondary)' }}>无符合条件的记录</p>

              )}

            </div>



            {/* Batch reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批量采纳原因 <span className="text-red-400">*</span></label>

              <textarea className="form-input w-full text-sm" rows={3} placeholder="请填写批量采纳原因..." value={penaltyBatchReason} onChange={e => setPenaltyBatchReason(e.target.value)} />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setPenaltyBatchSyncOpen(false); setPenaltyBatchReason(''); }}>取消</button>

              <button className="btn-primary" disabled={!penaltyBatchReason.trim() || penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length === 0} onClick={confirmBatchPenaltySync}>确认批量采纳</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Log Modal */}

      {penaltyLogModalOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyLogModalOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>

              <div className="flex items-center gap-3">

                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                </div>

                <h3 className="text-base font-semibold">处罚同步操作日志</h3>

              </div>

              <button onClick={() => setPenaltyLogModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>


              <table className="w-full text-sm">

                <thead>

                  <tr style={{ background: 'var(--table-header-bg)' }}>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>IP地址</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>类型</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>外部处罚编号</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>供应商名称</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>处理结果</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作方式</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>处理原因</th>

                  </tr>

                </thead>

                <tbody>

                  {penaltySyncLogList.map(l => (

                    <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>

                      <td className="px-3 py-2 font-mono text-xs">{l.id}</td>

                      <td className="px-3 py-2">{l.operator}</td>

                      <td className="px-3 py-2 font-mono text-xs">{l.ip}</td>

                      <td className="px-3 py-2 text-xs">{l.time}</td>

                      <td className="px-3 py-2"><span className={`tag text-xs ${l.type === '逐条' ? 'tag-blue' : 'tag-green'}`}>{l.type}</span></td>

                      <td className="px-3 py-2 font-mono text-xs">{l.externalPenaltyId}</td>

                      <td className="px-3 py-2">{l.supplierName}</td>

                      <td className="px-3 py-2"><span className={`tag text-xs ${l.result === '采纳' ? 'tag-green' : 'tag-red'}`}>{l.result}</span></td>

                      <td className="px-3 py-2 text-xs">{l.actionType || '-'}</td>

                      <td className="px-3 py-2 text-xs max-w-xs truncate" title={l.reason}>{l.reason}</td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

            <div className="px-6 py-4 border-t flex items-center justify-end" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default text-xs" onClick={() => setPenaltyLogModalOpen(false)}>关闭</button>

            </div>

          </div>

      )}



      {/* Penalty Detail / Edit Drawer */}

      {penaltyDrawerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyDrawerOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {penaltyEditMode === 'add' ? '新增处罚登记' : penaltyEditMode === 'edit' ? `编辑处罚 - ${selectedPenalty?.id}` : `处罚详情 - ${selectedPenalty?.id}`}
              </h3>
              <button onClick={() => setPenaltyDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* Basic Info */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-red-500"/>处罚基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联订单 <span className="text-red-400">*</span></label>
                    <select
                      className="form-input"
                      disabled={penaltyEditMode === 'view'}
                      onChange={(e) => {
                        const orderId = e.target.value
                        if (orderId && orderData) {
                          const order = orderData.find((o: any) => o.id === orderId)
                          if (order) {
                            // 自动填充供应商名称和类型
                            const supplierInput = document.getElementById('penalty-supplier-name') as HTMLInputElement
                            const typeInput = document.getElementById('penalty-supplier-type') as HTMLInputElement
                            if (supplierInput) supplierInput.value = order.supplier || ''
                            if (typeInput) typeInput.value = '企业供应商'
                          }
                        }
                      }}
                    >
                      <option value="">请选择关联订单</option>
                      {orderData?.map((order: any) => (
                        <option key={order.id} value={order.id}>{order.id} - {order.supplier} - {order.equipName}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商名称 <span className="text-red-400">*</span></label>
                    <input id="penalty-supplier-name" className="form-input" defaultValue={selectedPenalty?.supplierName || ''} placeholder="选择订单后自动填充" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚类型 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedPenalty?.penaltyType || 'warning'} disabled={penaltyEditMode === 'view'}>
                      <option value="warning">警告</option>
                      <option value="suspend">暂停资格</option>
                      <option value="cancel">取消资格</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚事由 <span className="text-red-400">*</span></label>
                    <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedPenalty?.reason || ''} placeholder="请详细描述处罚事由、事实依据..." readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚日期 <span className="text-red-400">*</span></label>
                    <input className="form-input" type="date" defaultValue={selectedPenalty?.penaltyDate || ''} readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚期限 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedPenalty?.duration || ''} placeholder="请输入处罚期限" readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商类型 #</label>
                    <input id="penalty-supplier-type" className="form-input" defaultValue={selectedPenalty?.enterpriseType || ''} placeholder="选择订单后自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发布单位 #</label>
                    <input className="form-input" defaultValue={selectedPenalty?.dept || ''} placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>来源 #</label>
                    <input className="form-input" defaultValue={selectedPenalty?.source === 'sync' ? '采购平台' : '内部'} placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                    <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedPenalty?.remarks || ''} placeholder="请输入备注信息..." readOnly={penaltyEditMode === 'view'} />
                  </div>
                </div>
              </div>



              {/* Process Info - View Only */}

              {penaltyEditMode === 'view' && selectedPenalty && (

                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>处理流程</h4>

                  <div className="space-y-3">

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>1</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">管理员发起处罚登记</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenalty.penaltyDate} 管理员录入处罚信息</p>

                      </div>

                      <span className="tag tag-green text-xs">已完成</span>

                    </div>

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>2</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">录入事实与依据</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenalty.reason}</p>

                      </div>

                      <span className="tag tag-green text-xs">已完成</span>

                    </div>

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#1890ff' }}>3</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">内部公示</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已同步更新供应商状态，对外公示中</p>

                      </div>

                      <span className="tag tag-blue text-xs">进行中</span>

                    </div>

                  </div>

                </div>

              )}

            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default" onClick={() => setPenaltyDrawerOpen(false)}>{penaltyEditMode === 'view' ? '关闭' : '取消'}</button>

              {penaltyEditMode !== 'view' && (

                <button className="btn-primary">保存</button>

              )}

            </div>

          </div>
        </div>
      )}

      {/* Penalty Delete Confirmation Modal */}

      {penaltyDeleteOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyDeleteOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">


            <div className="flex items-center gap-3 mb-4">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>

              </div>

              <h3 className="text-base font-semibold">确认删除</h3>

            </div>

            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除处罚记录"<span className="font-medium">{selectedPenalty?.id}</span>"？删除后数据将无法恢复，请谨慎操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setPenaltyDeleteOpen(false)}>取消</button>
              <button className="btn-danger" onClick={confirmDeletePenalty}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉登记 Modal ═══════════ */}

      {complaintModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center" onClick={() => setTargetSearchOpen(false)}>
          <div className="absolute inset-0 bg-black/40" onClick={() => setComplaintModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">投诉登记</h3>
              <button onClick={() => setComplaintModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉人</label>
                <input value={currentUser.name} readOnly className="form-input w-full bg-gray-50 text-gray-500" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属机构</label>
                <input value={currentUser.org} readOnly className="form-input w-full bg-gray-50 text-gray-500" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉类型</label>
                <select value={complaintForm.targetType} onChange={e => setComplaintForm({ ...complaintForm, targetType: e.target.value })} className="form-input w-full">
                  <option>供应商</option>
                  <option>维修人员</option>
                  <option>产品质量</option>
                  <option>服务态度</option>
                </select>
              </div>
              <div className="relative">
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉对象 <span className="text-red-400">*</span></label>
                <input
                  value={targetSearchText || complaintForm.targetName}
                  onChange={e => {
                    const val = e.target.value
                    setTargetSearchText(val)
                    setComplaintForm(prev => ({ ...prev, targetName: val, complainant: currentUser.name, org: currentUser.org }))
                    setTargetSearchOpen(!!val)
                  }}
                  onFocus={() => { if ((targetSearchText || complaintForm.targetName).length >= 1) setTargetSearchOpen(true) }}
                  className="form-input w-full"
                  placeholder="输入投诉对象名称搜索..."
                />
                {targetSearchOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 rounded-lg border shadow-lg z-50 max-h-[200px] overflow-y-auto" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
                    {complaintTargets
                      .filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase()))
                      .map(t => (
                        <button
                          key={t}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors"
                          onClick={() => {
                            setComplaintForm(prev => ({ ...prev, targetName: t, complainant: currentUser.name, org: currentUser.org }))
                            setTargetSearchText(t)
                            setTargetSearchOpen(false)
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    {complaintTargets.filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase())).length === 0 && (
                      <div className="px-3 py-2 text-sm" style={{ color: 'var(--text-disabled)' }}>无匹配数据</div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉内容 <span className="text-red-400">*</span></label>
                <textarea value={complaintForm.content} onChange={e => setComplaintForm({ ...complaintForm, content: e.target.value })} rows={3} className="form-input w-full" placeholder="请描述投诉内容..." />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setComplaintModalOpen(false)} className="btn-default">取消</button>
              <button onClick={addComplaint} className="btn-danger">提交投诉</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉回复 Modal ═══════════ */}

      {replyOpen && replyComplaint && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">投诉处理 - {replyComplaint.id}</h3>
              <button onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="mb-4 p-3 rounded text-sm" style={{ background: '#f5f5f5' }}>
              <div><span style={{ color: 'var(--text-secondary)' }}>投诉人：</span>{replyComplaint.complainant} / {replyComplaint.org}</div>
              <div><span style={{ color: 'var(--text-secondary)' }}>投诉对象：</span>{replyComplaint.targetName}</div>
              <div className="mt-1"><span style={{ color: 'var(--text-secondary)' }}>内容：</span>{replyComplaint.content}</div>
            </div>
            {replyComplaint.reply ? (
              <div className="p-3 rounded" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                <span style={{ color: '#52c41a' }} className="font-medium text-sm">已回复：</span>
                <p className="text-sm mt-1">{replyComplaint.reply}</p>
              </div>
            ) : (
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处理回复 <span className="text-red-400">*</span></label>
                <textarea value={replyContent} onChange={e => setReplyContent(e.target.value)} rows={4} className="form-input w-full" placeholder="请填写处理意见..." />
              </div>
            )}
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} className="btn-default">
                {replyComplaint.reply ? '关闭' : '取消'}
              </button>
              {!replyComplaint.reply && (
                <button onClick={submitReply} className="btn-primary">提交回复</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}