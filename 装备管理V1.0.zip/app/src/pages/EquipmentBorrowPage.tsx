import { useState } from 'react'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

// ===== 复用仓库数据（与入库管理一致） =====
interface Warehouse {
  id: string
  name: string
  parent?: string
  entityType: string
  level: string
  children?: Warehouse[]
}

const warehouseData: Warehouse[] = [
  {
    id: 'ES001', name: '省厅主仓库', parent: undefined, entityType: '仓库', level: '省级',
    children: [
      { id: 'ES001-A', name: 'A区-01货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-B', name: 'A区-02货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-C', name: 'A区-03货架', parent: 'ES001', entityType: '货架', level: '省级' },
    ]
  },
  {
    id: 'ES002', name: '市局限装备仓库', parent: undefined, entityType: '仓库', level: '市级',
    children: [
      { id: 'ES002-A', name: 'B区-01货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-B', name: 'B区-02货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-C', name: 'B区-03货架', parent: 'ES002', entityType: '货架', level: '市级' },
    ]
  },
  {
    id: 'ES003', name: 'A区县级装备库', parent: undefined, entityType: '分区', level: '区县级',
    children: [
      { id: 'ES003-A', name: 'C区-01货架', parent: 'ES003', entityType: '货架', level: '区县级' },
      { id: 'ES003-B', name: 'C区-02货架', parent: 'ES003', entityType: '货架', level: '区县级' },
    ]
  },
  { id: 'ES004', name: 'B区县级装备库', parent: undefined, entityType: '分区', level: '区县级', children: [] },
]

function flattenWarehouses(nodes: Warehouse[], depth = 0): { id: string; label: string }[] {
  const result: { id: string; label: string }[] = []
  for (const n of nodes) {
    const indent = '\u00A0\u00A0'.repeat(depth)
    result.push({ id: n.id, label: `${indent}${n.name}` })
    if (n.children) result.push(...flattenWarehouses(n.children, depth + 1))
  }
  return result
}

function getWarehouseName(id: string) {
  for (const w of warehouseData) {
    if (w.id === id) return w.name
    if (w.children) for (const c of w.children) if (c.id === id) return c.name
  }
  return id
}

// ===== 库存装备数据源（来自入库管理的已入库物资） =====
interface StockMaterial {
  id: string
  name: string
  category: string
  spec: string
  tags?: string[]
  qty: number
  unit: string
  produceDate: string
  validDate: string
  price: number
  total: number
  equipCode: string
  supplier: string
  remark: string
  location: string
  isFixedAsset: boolean
}

const stockMaterials: StockMaterial[] = [
  { id: 'S001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 50, unit: '台', produceDate: '2024-01-15', validDate: '2027-01-15', price: 2800, total: 140000, equipCode: '0101P00100', supplier: '华为技术有限公司', remark: '期初盘点', location: 'ES001-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S002', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 30, unit: '台', produceDate: '2024-02-01', validDate: '2027-02-01', price: 1500, total: 45000, equipCode: '0101P00500', supplier: '烽火通信科技股份有限公司', remark: '', location: 'ES001-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
  { id: 'S003', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 100, unit: '台', produceDate: '2024-02-20', validDate: '2027-02-20', price: 1800, total: 180000, equipCode: '0101P00200', supplier: '海康威视数字技术股份有限公司', remark: '批量采购', location: 'ES002-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 20, unit: '件', produceDate: '2024-01-10', validDate: '2029-01-10', price: 3200, total: 64000, equipCode: '0101P00300', supplier: '华为技术有限公司', remark: '从市局调拨', location: 'ES001-B', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 15, unit: '顶', produceDate: '2024-01-15', validDate: '2028-01-15', price: 2600, total: 39000, equipCode: '0101P00400', supplier: '中兴通讯股份有限公司', remark: '任务结束归还', location: 'ES003-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S006', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 40, unit: '根', produceDate: '2024-03-01', validDate: '2027-03-01', price: 350, total: 14000, equipCode: '0101P00600', supplier: '大华技术股份有限公司', remark: '派出所配发', location: 'ES002-B', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S007', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 60, unit: '件', produceDate: '2024-09-01', validDate: '2027-09-01', price: 45, total: 2700, equipCode: '0101P03400', supplier: '大华技术股份有限公司', remark: '', location: 'ES003-A', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
  { id: 'S008', name: '交通锥 JT-L', category: '交通装备', spec: 'JT-L/70cm', qty: 80, unit: '个', produceDate: '2024-09-05', validDate: '2027-09-05', price: 35, total: 2800, equipCode: '0101P03500', supplier: '中兴通讯股份有限公司', remark: '', location: 'ES003-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
  { id: 'S009', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 60, unit: '台', produceDate: '2024-04-15', validDate: '2027-04-15', price: 3500, total: 210000, equipCode: '0101P01600', supplier: '海康威视数字技术股份有限公司', remark: '指挥中心', location: 'ES001-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S010', name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', qty: 5, unit: '辆', produceDate: '2024-11-01', validDate: '2027-11-01', price: 28000, total: 140000, equipCode: '0101P04600', supplier: '中兴通讯股份有限公司', remark: '交警中队', location: 'ES003-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S011', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 20, unit: '面', produceDate: '2024-11-15', validDate: '2029-11-15', price: 680, total: 13600, equipCode: '0101P04700', supplier: '华为技术有限公司', remark: '', location: 'ES001-A', isFixedAsset: true, tags: ['状态类/临期30天'] },
  { id: 'S012', name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', qty: 45, unit: '根', produceDate: '2024-01-08', validDate: '2029-01-08', price: 380, total: 17100, equipCode: '0101P01000', supplier: '中兴通讯股份有限公司', remark: '', location: 'ES003-B', isFixedAsset: false, tags: ['品类特征/贵重仪器'] },
]

// ===== 状态定义 =====
type BorrowStatus = 'draft' | 'submitted' | 'approval1' | 'pending_out' | 'pending_return' | 'returned'

const statusMap: Record<BorrowStatus, { label: string; tag: string }> = {
  draft: { label: '草稿', tag: 'tag-gray' },
  submitted: { label: '已提交', tag: 'tag-blue' },
  approval1: { label: '审批1', tag: 'tag-purple' },
  pending_out: { label: '待出库', tag: 'tag-yellow' },
  pending_return: { label: '待归还', tag: 'tag-blue' },
  returned: { label: '已归还', tag: 'tag-green' },
}

// ===== 物资明细接口 =====
interface BorrowItem {
  id: string
  tags?: string[]
  name: string
  category: string
  spec: string
  qty: number
  remainQty: number
  produceDate: string
  validDate: string
  isFixedAsset: boolean
  unit: string
  subUnit: string
  price: number
  total: number
  equipCode: string
  supplier: string
  remark: string
}

// ===== 领用记录接口 =====
interface BorrowRecord {
  id: string
  applicant: string
  unit: string
  warehouse: string
  isBorrow: boolean
  expectReturnTime: string
  items: BorrowItem[]
  status: BorrowStatus
  description: string
  remark: string
  applyTime: string
}

const supplierOptions = ['华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司', '中兴通讯股份有限公司', '大华技术股份有限公司']

const emptyItem = (): BorrowItem => ({
  id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
  name: '', category: '', spec: '', qty: 0, remainQty: 0,
  produceDate: '', validDate: '', isFixedAsset: false,
  unit: '个', subUnit: '', price: 0, total: 0,
  equipCode: '', tags: [], supplier: '', remark: '',
})

// ===== 样例数据（8条，覆盖所有状态） =====
const borrowRecords: BorrowRecord[] = [
  {
    id: 'LY2024001', applicant: '王建国', unit: '刑警支队', warehouse: 'ES001',
    isBorrow: true, expectReturnTime: '2024-04-15 18:00',
    status: 'draft', description: '外勤执法使用', remark: '',
    applyTime: '2024-03-20 09:30',
    items: [
      { id: '1', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 3, remainQty: 3, produceDate: '2024-01-15', validDate: '2027-01-15', isFixedAsset: true, unit: '台', subUnit: '', price: 2800, total: 8400, equipCode: '0101P00100', supplier: '华为技术有限公司', remark: '' },
      { id: '2', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 5, remainQty: 5, produceDate: '2024-02-01', validDate: '2027-02-01', isFixedAsset: false, unit: '台', subUnit: '', price: 1500, total: 7500, equipCode: '0101P00500', supplier: '烽火通信科技股份有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024002', applicant: '李秀英', unit: '治安支队', warehouse: 'ES002',
    isBorrow: true, expectReturnTime: '2024-04-10 18:00',
    status: 'submitted', description: '大型活动安保', remark: '需提前一天准备',
    applyTime: '2024-03-18 10:00',
    items: [
      { id: '1', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 10, remainQty: 10, produceDate: '2024-02-20', validDate: '2027-02-20', isFixedAsset: true, unit: '台', subUnit: '', price: 1800, total: 18000, equipCode: '0101P00200', supplier: '海康威视数字技术股份有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024003', applicant: '', unit: '交警支队', warehouse: 'ES003',
    isBorrow: false, expectReturnTime: '',
    status: 'approval1', description: '长期调配使用', remark: '',
    applyTime: '2024-03-15 14:30',
    items: [
      { id: '1', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 30, remainQty: 30, produceDate: '2024-01-10', validDate: '2027-01-10', isFixedAsset: false, unit: '件', subUnit: '', price: 45, total: 1350, equipCode: '0101P03400', supplier: '大华技术股份有限公司', remark: '' },
      { id: '2', name: '交通锥 JT-L', category: '交通装备', spec: 'JT-L/70cm', qty: 50, remainQty: 50, produceDate: '2024-01-15', validDate: '2027-01-15', isFixedAsset: false, unit: '个', subUnit: '', price: 35, total: 1750, equipCode: '0101P03500', supplier: '中兴通讯股份有限公司', remark: '' },
      { id: '3', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 20, remainQty: 20, produceDate: '2024-04-15', validDate: '2027-04-15', isFixedAsset: true, unit: '台', subUnit: '', price: 3500, total: 70000, equipCode: '0101P01600', supplier: '海康威视数字技术股份有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024004', applicant: '赵志刚', unit: '特警支队', warehouse: 'ES001',
    isBorrow: true, expectReturnTime: '2024-05-01 18:00',
    status: 'pending_out', description: '集训使用', remark: '防弹装备',
    applyTime: '2024-03-25 08:00',
    items: [
      { id: '1', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 15, remainQty: 15, produceDate: '2024-01-10', validDate: '2029-01-10', isFixedAsset: true, unit: '件', subUnit: '', price: 3200, total: 48000, equipCode: '0101P00300', supplier: '华为技术有限公司', remark: '' },
      { id: '2', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 15, remainQty: 15, produceDate: '2024-01-15', validDate: '2028-01-15', isFixedAsset: true, unit: '顶', subUnit: '', price: 2600, total: 39000, equipCode: '0101P00400', supplier: '中兴通讯股份有限公司', remark: '' },
      { id: '3', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 5, remainQty: 5, produceDate: '2024-01-15', validDate: '2027-01-15', isFixedAsset: true, unit: '台', subUnit: '', price: 2800, total: 14000, equipCode: '0101P00100', supplier: '华为技术有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024005', applicant: '周丽华', unit: '网安支队', warehouse: 'ES002',
    isBorrow: false, expectReturnTime: '',
    status: 'returned', description: '设备调配', remark: '',
    applyTime: '2024-03-10 11:00',
    items: [
      { id: '1', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 25, remainQty: 0, produceDate: '2024-03-01', validDate: '2027-03-01', isFixedAsset: true, unit: '根', subUnit: '', price: 350, total: 8750, equipCode: '0101P00600', supplier: '大华技术股份有限公司', remark: '' },
      { id: '2', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 8, remainQty: 0, produceDate: '2024-04-15', validDate: '2027-04-15', isFixedAsset: true, unit: '台', subUnit: '', price: 3500, total: 28000, equipCode: '0101P01600', supplier: '海康威视数字技术股份有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024006', applicant: '吴天明', unit: '刑侦支队', warehouse: 'ES001',
    isBorrow: true, expectReturnTime: '2024-04-20 18:00',
    status: 'pending_return', description: '外出取证', remark: '等待归还',
    applyTime: '2024-03-22 15:00',
    items: [
      { id: '1', name: '数字取证工作站 FZ-WS', category: '取证设备', spec: 'FZ-WS/高性能', qty: 2, remainQty: 0, produceDate: '2024-01-20', validDate: '2027-01-20', isFixedAsset: true, unit: '台', subUnit: '', price: 28000, total: 56000, equipCode: '0101P03600', supplier: '中兴通讯股份有限公司', remark: '已归还' },
      { id: '2', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 3, remainQty: 1, produceDate: '2024-01-15', validDate: '2027-01-15', isFixedAsset: true, unit: '台', subUnit: '', price: 2800, total: 8400, equipCode: '0101P00100', supplier: '华为技术有限公司', remark: '还2借1' },
      { id: '3', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 5, remainQty: 2, produceDate: '2024-02-01', validDate: '2027-02-01', isFixedAsset: false, unit: '台', subUnit: '', price: 1500, total: 7500, equipCode: '0101P00500', supplier: '烽火通信科技股份有限公司', remark: '还3借2' },
    ]
  },
  {
    id: 'LY2024007', applicant: '孙秀兰', unit: '', warehouse: 'ES003',
    isBorrow: true, expectReturnTime: '2024-03-30 18:00',
    status: 'returned', description: '演练借用', remark: '已全部归还',
    applyTime: '2024-03-05 09:00',
    items: [
      { id: '1', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 5, remainQty: 0, produceDate: '2024-01-15', validDate: '2028-01-15', isFixedAsset: true, unit: '顶', subUnit: '', price: 2600, total: 13000, equipCode: '0101P00400', supplier: '中兴通讯股份有限公司', remark: '' },
    ]
  },
  {
    id: 'LY2024008', applicant: '马建国', unit: '反恐支队', warehouse: 'ES002',
    isBorrow: false, expectReturnTime: '',
    status: 'returned', description: '常规领用', remark: '',
    applyTime: '2024-03-28 16:00',
    items: [
      { id: '1', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 10, remainQty: 0, produceDate: '2024-02-20', validDate: '2029-02-20', isFixedAsset: true, unit: '面', subUnit: '', price: 680, total: 6800, equipCode: '0101P04700', supplier: '华为技术有限公司', remark: '' },
      { id: '2', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 8, remainQty: 0, produceDate: '2024-03-01', validDate: '2029-03-01', isFixedAsset: true, unit: '面', subUnit: '', price: 680, total: 5440, equipCode: '0101P04700', supplier: '华为技术有限公司', remark: '' },
    ]
  },
]

export default function EquipmentBorrowPage({ onNavigate }: Props) {
  const [borrowList, setBorrowList] = useState<BorrowRecord[]>(borrowRecords)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add')
  const [editingId, setEditingId] = useState('')
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<BorrowRecord | null>(null)
  const [confirmAction, setConfirmAction] = useState<{ type: string; record: BorrowRecord | null }>({ type: '', record: null })

  // 库存装备选择弹窗
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockSearchLocation, setStockSearchLocation] = useState('')
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: StockMaterial; qty: number }[]>([])

  // 表单状态
  const [formApplicant, setFormApplicant] = useState('')
  const [formUnit, setFormUnit] = useState('')
  const [formWarehouse, setFormWarehouse] = useState('')
  const [formIsBorrow, setFormIsBorrow] = useState(true)
  const [formExpectReturn, setFormExpectReturn] = useState('')
  const [formDescription, setFormDescription] = useState('')
  const [formRemark, setFormRemark] = useState('')
  const [formItems, setFormItems] = useState<BorrowItem[]>([])

  const resetForm = () => {
    setFormApplicant('')
    setFormUnit('')
    setFormWarehouse('')
    setFormIsBorrow(true)
    setFormExpectReturn('')
    setFormDescription('')
    setFormRemark('')
    setFormItems([])
    setEditingId('')
  }

  const openAdd = () => { resetForm(); setModalMode('add'); setModalOpen(true) }

  const openEdit = (r: BorrowRecord) => {
    setFormApplicant(r.applicant)
    setFormUnit(r.unit)
    setFormWarehouse(r.warehouse)
    setFormIsBorrow(r.isBorrow)
    setFormExpectReturn(r.expectReturnTime)
    setFormDescription(r.description)
    setFormRemark(r.remark)
    setFormItems(r.items.map(i => ({ ...i })))
    setEditingId(r.id)
    setModalMode('edit')
    setModalOpen(true)
  }

  const removeItem = (idx: number) => setFormItems(prev => prev.filter((_, i) => i !== idx))
  const updateItemQty = (idx: number, newQty: number) => {
    setFormItems(prev => prev.map((item, i) => i !== idx ? item : { ...item, qty: newQty, total: newQty * item.price }))
  }

  // 打开库存装备弹窗
  const openStockModal = () => {
    setStockSearchLocation('')
    setStockSearchName('')
    setStockSearchCategory('')
    setSelectedStockItems([])
    setStockModalOpen(true)
  }

  // 确认添加库存装备
  const confirmStockItems = () => {
    const newItems: BorrowItem[] = selectedStockItems.map(s => ({
      id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
      name: s.stock.name,
      category: s.stock.category,
      spec: s.stock.spec,
      qty: s.qty,
      remainQty: s.qty,
      produceDate: s.stock.produceDate,
      validDate: s.stock.validDate,
      isFixedAsset: s.stock.isFixedAsset,
      unit: s.stock.unit,
      subUnit: '',
      price: s.stock.price,
      total: s.stock.price * s.qty,
      equipCode: s.stock.equipCode,
      supplier: s.stock.supplier,
      remark: s.stock.remark,
    }))
    setFormItems(prev => [...prev, ...newItems])
    setStockModalOpen(false)
    setSelectedStockItems([])
  }

  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchLocation && !s.location.startsWith(stockSearchLocation)) return false
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    return true
  })

  const toggleStockSelect = (stock: StockMaterial) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.id === stock.id)
      if (exists) return prev.filter(p => p.stock.id !== stock.id)
      return [...prev, { stock, qty: 1 }]
    })
  }

  const updateSelectedQty = (stockId: string, newQty: number) => {
    const stock = stockMaterials.find(s => s.id === stockId)
    if (stock && newQty > stock.qty) { alert('申请数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.id === stockId ? { ...p, qty: Math.max(1, newQty) } : p))
  }

  const validateForm = () => {
    if (!formApplicant && !formUnit) { alert('申请人和申请单位至少填写一个'); return false }
    if (!formWarehouse) { alert('请选择调出仓库'); return false }
    if (formIsBorrow && !formExpectReturn) { alert('借用类型需填写预计归还时间'); return false }
    if (formItems.length === 0) { alert('请至少添加一件物资'); return false }
    if (formItems.some(i => !i.name || !i.qty)) { alert('请完善物资明细（物资名称、数量为必填）'); return false }
    return true
  }

  const handleSaveDraft = () => {
    if (!formApplicant && !formUnit) { alert('申请人和申请单位至少填写一个'); return }
    const newId = `LY2024${String(borrowList.length + 1).padStart(3, '0')}`
    const record: BorrowRecord = {
      id: newId, applicant: formApplicant, unit: formUnit, warehouse: formWarehouse,
      isBorrow: formIsBorrow, expectReturnTime: formExpectReturn,
      items: formItems.map(i => ({ ...i, total: i.qty * i.price, remainQty: i.qty })),
      status: 'draft', description: formDescription, remark: formRemark,
      applyTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    if (modalMode === 'edit' && editingId) {
      setBorrowList(prev => prev.map(b => b.id === editingId ? { ...record, id: editingId, status: b.status } : b))
    } else {
      setBorrowList(prev => [record, ...prev])
    }
    setModalOpen(false)
    resetForm()
    alert('已保存为草稿')
  }

  const handleSubmit = () => {
    if (!validateForm()) return
    const newId = `LY2024${String(borrowList.length + 1).padStart(3, '0')}`
    const record: BorrowRecord = {
      id: newId, applicant: formApplicant, unit: formUnit, warehouse: formWarehouse,
      isBorrow: formIsBorrow, expectReturnTime: formExpectReturn,
      items: formItems.map(i => ({ ...i, total: i.qty * i.price, remainQty: i.qty })),
      status: 'submitted', description: formDescription, remark: formRemark,
      applyTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    if (modalMode === 'edit' && editingId) {
      setBorrowList(prev => prev.map(b => b.id === editingId ? { ...record, id: editingId } : b))
    } else {
      setBorrowList(prev => [record, ...prev])
    }
    setModalOpen(false)
    resetForm()
    alert('提交成功')
  }

  const handleDelete = (r: BorrowRecord) => { setBorrowList(prev => prev.filter(b => b.id !== r.id)); setConfirmAction({ type: '', record: null }); alert('删除成功') }
  const handleWithdraw = (r: BorrowRecord) => { setBorrowList(prev => prev.map(b => b.id === r.id ? { ...b, status: 'draft' as BorrowStatus } : b)); setConfirmAction({ type: '', record: null }); alert('已撤回为草稿') }

  // 表格操作按钮
  const renderActions = (r: BorrowRecord) => {
    const buttons: any[] = []
    buttons.push(<button key="detail" className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedRecord(r); setDetailOpen(true) }}>详情</button>)
    if (r.status === 'draft') {
      buttons.push(<button key="edit" className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openEdit(r)}>编辑</button>)
      buttons.push(<button key="del" className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => setConfirmAction({ type: 'delete', record: r })}>删除</button>)
    }
    if (r.status === 'submitted') {
      buttons.push(<button key="withdraw" className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => setConfirmAction({ type: 'withdraw', record: r })}>撤回</button>)
    }
    // pending_out 和 pending_return 只能查看，不显示操作按钮
    // (pending_out 原确认出库功能已移除，仅保留详情)
    if (r.status === 'pending_out') {
      // 仅详情，无操作
    }
    return <div className="flex items-center gap-2 flex-wrap">{buttons}</div>
  }

  // 物资类别下拉选项
  const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>领用管理</span>
      </div>

      {/* 搜索 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>领用单号</label><input className="form-input w-36" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人</label><input className="form-input w-28" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位</label><select className="form-input w-32"><option>全部</option><option>刑警支队</option><option>治安支队</option><option>交警支队</option><option>特警支队</option><option>网安支队</option><option>刑侦支队</option><option>反恐支队</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库</label><WarehouseTreeSelect warehouseData={warehouseData} value="" onChange={() => {}} showAll allLabel="全部" className="w-32" /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option>{Object.entries(statusMap).map(([k, v]) => <option key={k}>{v.label}</option>)}</select></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* 操作按钮 */}
      <div className="flex items-center justify-between">
        <button className="btn-primary flex items-center gap-1" onClick={openAdd}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          新增领用申请
        </button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {borrowList.length} 条记录</span>
      </div>

      {/* 数据表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>领用单号</th>
              <th>申请人/单位</th>
              <th>调出仓库</th>
              <th>类型</th>
              <th>物资清单</th>
              <th>预计归还</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {borrowList.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td className="text-xs">{r.applicant || '-'}{r.applicant && r.unit ? ' / ' : ''}{r.unit || '-'}</td>
                <td className="text-xs">{getWarehouseName(r.warehouse)}</td>
                <td><span className={`tag text-xs ${r.isBorrow ? 'tag-blue' : 'tag-green'}`}>{r.isBorrow ? '借用' : '领用'}</span></td>
                <td>
                  <div className="flex flex-col gap-0.5">
                    {r.items.slice(0, 2).map((item, i) => (
                      <span key={i} className="text-xs truncate max-w-[180px]">{item.name} x{item.qty}</span>
                    ))}
                    {r.items.length > 2 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>+{r.items.length - 2} 种</span>}
                  </div>
                </td>
                <td className="text-xs">{r.expectReturnTime || '-'}</td>
                <td><span className={`tag text-xs ${statusMap[r.status].tag}`}>{statusMap[r.status].label}</span></td>
                <td>{renderActions(r)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== 新增/编辑弹窗 ===== */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1100px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{modalMode === 'add' ? '新增领用申请' : '编辑领用申请'}</h3>
              <button onClick={() => setModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* 基本信息 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#52c41a' }}>基本信息</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>领用单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={modalMode === 'edit' ? editingId : `LY2024${String(borrowList.length + 1).padStart(3, '0')}`} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入申请人" value={formApplicant} onChange={e => setFormApplicant(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full" value={formUnit} onChange={e => setFormUnit(e.target.value)}>
                      <option value="">请选择</option>
                      {['刑警支队', '治安支队', '交警支队', '特警支队', '网安支队', '刑侦支队', '反恐支队'].map(u => <option key={u}>{u}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库 <span className="text-red-400">*</span></label>
                    <WarehouseTreeSelect warehouseData={warehouseData} value={formWarehouse} onChange={setFormWarehouse} placeholder="请选择" />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>类型 <span className="text-red-400">*</span></label>
                    <div className="flex gap-4 mt-1">
                      <label className="flex items-center gap-1.5 cursor-pointer text-sm">
                        <input type="radio" checked={formIsBorrow} onChange={() => setFormIsBorrow(true)} /> 借用
                      </label>
                      <label className="flex items-center gap-1.5 cursor-pointer text-sm">
                        <input type="radio" checked={!formIsBorrow} onChange={() => setFormIsBorrow(false)} /> 领用
                      </label>
                    </div>
                  </div>
                  {formIsBorrow && (
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>预计归还时间 <span className="text-red-400">*</span></label>
                      <input type="datetime-local" className="form-input w-full" value={formExpectReturn} onChange={e => setFormExpectReturn(e.target.value)} />
                    </div>
                  )}
                  <div className={formIsBorrow ? '' : 'col-span-2'}>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>领用说明</label>
                    <input className="form-input w-full" placeholder="请输入领用说明" value={formDescription} onChange={e => setFormDescription(e.target.value)} />
                  </div>
                  <div className={formIsBorrow ? '' : 'col-span-1'}>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                    <input className="form-input w-full" placeholder="备注信息" value={formRemark} onChange={e => setFormRemark(e.target.value)} />
                  </div>
                </div>
              </div>

              {/* 物资明细 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细 <span style={{ color: 'var(--text-secondary)' }}>({formItems.length} 种)</span></h4>
                  <button onClick={openStockModal} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 添加物资</button>
                </div>

                {formItems.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>#</th>
                          <th className="border p-2 w-28" style={{ borderColor: 'var(--border-color)' }}>物资名称 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>物资类别(二级) <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>规格型号 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-12" style={{ borderColor: 'var(--border-color)' }}>数量 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>剩余数量 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-18" style={{ borderColor: 'var(--border-color)' }}>生产日期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-18" style={{ borderColor: 'var(--border-color)' }}>有效期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>是否固定资产 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>单位 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>单价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>总价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-22" style={{ borderColor: 'var(--border-color)' }}>装备编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>供应商 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                          <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formItems.map((item, idx) => (
                          <tr key={item.id}>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.name}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.category || '-'}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.spec || '-'}</td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.qty} onChange={e => updateItemQty(idx, Number(e.target.value))} /></td>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{item.remainQty}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.produceDate || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.validDate || '-'}</td>
                            <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.isFixedAsset ? '是' : '否'}</td>
                            <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.unit}{item.subUnit ? `(${item.subUnit})` : ''}</td>
                            <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.price?.toLocaleString()}</td>
                            <td className="border p-2 text-right font-mono font-medium" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                            <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.equipCode || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.supplier || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.remark || '-'}</td>
                            <td className="border p-1 text-center" style={{ borderColor: 'var(--border-color)' }}>
                              <button onClick={() => removeItem(idx)} className="text-red-400 hover:text-red-600">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {formItems.length > 0 && (
                  <div className="mt-3 flex items-center justify-end gap-4">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合计品种：{formItems.length} 种</span>
                    <span className="text-sm font-mono font-bold">合计金额：¥{formItems.reduce((s, m) => s + m.total, 0).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setModalOpen(false)}>取消</button>
              <button className="btn-default" onClick={handleSaveDraft}>保存草稿</button>
              <button className="btn-primary" onClick={handleSubmit}>提交</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备信息弹窗（左右分栏） ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[100dvh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* 搜索区域 */}
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置</label>
                  <select className="form-input w-32" value={stockSearchLocation} onChange={e => setStockSearchLocation(e.target.value)}>
                    <option value="">全部</option>
                    {flattenWarehouses(warehouseData).map(o => <option key={o.id} value={o.id}>{o.label}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label>
                  <input className="form-input w-28" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label>
                  <select className="form-input w-28" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}>
                    <option value="">全部</option>
                    {categoryOptions.map(c => <option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchLocation(''); setStockSearchName(''); setStockSearchCategory('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            {/* 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：库存装备列表 */}
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>
                        <input type="checkbox" disabled />
                      </th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>剩余数量</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.id === s.id)
                      return (
                        <tr
                          key={s.id}
                          className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`}
                          onClick={() => toggleStockSelect(s)}
                        >
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>
                            <input type="checkbox" checked={isSelected} readOnly />
                          </td>
                          <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{s.name}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.category}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.spec || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.produceDate || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.validDate || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{s.qty}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{s.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{s.equipCode}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.supplier}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.remark || '-'}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && (
                      <tr><td colSpan={13} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedStockItems.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备添加</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.id} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>余量: {s.stock.qty}</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.id, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.id !== s.stock.id))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情抽屉 ===== */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative w-[520px] bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="font-semibold text-base">领用申请详情</h3>
              <button className="p-1 rounded hover:bg-gray-100" onClick={() => setDetailOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息</h4>
                <div className="space-y-2">
                  {[
                    { label: '领用单号', value: selectedRecord.id },
                    { label: '申请人', value: selectedRecord.applicant || '-' },
                    { label: '申请单位', value: selectedRecord.unit || '-' },
                    { label: '调出仓库', value: getWarehouseName(selectedRecord.warehouse) },
                    { label: '类型', value: selectedRecord.isBorrow ? '借用' : '领用' },
                    { label: '预计归还时间', value: selectedRecord.expectReturnTime || '-' },
                    { label: '申请时间', value: selectedRecord.applyTime },
                    { label: '状态', value: statusMap[selectedRecord.status].label },
                    { label: '领用说明', value: selectedRecord.description || '-' },
                    { label: '备注', value: selectedRecord.remark || '-' },
                  ].map(f => (
                    <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium text-sm">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>物资明细（{selectedRecord.items.length} 种）</h4>
                {selectedRecord.items.map((m, i) => (
                  <div key={m.id} className="border rounded-lg p-3 mb-2" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="text-xs font-medium mb-2">#{i + 1} {m.name}</div>
                    <div className="grid grid-cols-2 gap-y-1 gap-x-4 text-xs">
                      <span style={{ color: 'var(--text-secondary)' }}>物资类别：<span className="text-gray-900">{m.category || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>规格型号：<span className="text-gray-900">{m.spec || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>数量：<span className="text-gray-900">{m.qty} {m.unit}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>剩余数量：<span className="text-gray-900">{m.remainQty}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>是否固定资产：<span className="text-gray-900">{m.isFixedAsset ? '是' : '否'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>单价：<span className="text-gray-900 font-mono">¥{m.price?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>总价：<span className="text-gray-900 font-mono font-medium">¥{m.total?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>生产日期：<span className="text-gray-900">{m.produceDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>有效期：<span className="text-gray-900">{m.validDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>装备编码：<span className="text-gray-900 font-mono">{m.equipCode || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>供应商：<span className="text-gray-900">{m.supplier || '-'}</span></span>
                      {m.remark && <span className="col-span-2" style={{ color: 'var(--text-secondary)' }}>备注：<span className="text-gray-900">{m.remark}</span></span>}
                    </div>
                  </div>
                ))}
                <div className="text-right text-sm font-mono font-bold mt-2">
                  合计金额：¥{selectedRecord.items.reduce((s, m) => s + m.total, 0).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="p-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 通用确认弹窗 ===== */}
      {confirmAction.type && confirmAction.record && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setConfirmAction({ type: '', record: null })} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[400px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: confirmAction.type === 'delete' ? '#fff2f0' : confirmAction.type === 'withdraw' ? '#fff7e6' : '#f9f0ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={confirmAction.type === 'delete' ? '#ff4d4f' : confirmAction.type === 'withdraw' ? '#faad14' : '#722ed1'} strokeWidth="2">
                  {confirmAction.type === 'delete' ? <><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></> :
                   confirmAction.type === 'withdraw' ? <><path d="M3 12h18M3 12l6-6M3 12l6 6"/></> :
                   <><path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></>}
                </svg>
              </div>
              <h3 className="text-base font-semibold">
                {confirmAction.type === 'delete' ? '确认删除' : confirmAction.type === 'withdraw' ? '撤回申请' : '确认出库'}
              </h3>
            </div>
            <p className="text-sm mb-5" style={{ color: 'var(--text-secondary)' }}>
              {confirmAction.type === 'delete' ? `确定要删除领用单 ${confirmAction.record.id} 吗？删除后数据将无法恢复。` :
               confirmAction.type === 'withdraw' ? `确认撤回领用单 ${confirmAction.record.id}？撤回后该申请将恢复为草稿状态。` :
               `确认领用单 ${confirmAction.record.id} 出库？出库后状态将更新为已归还。`}
            </p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setConfirmAction({ type: '', record: null })}>取消</button>
              <button
                className={confirmAction.type === 'delete' ? 'btn-danger' : 'btn-primary'}
                style={confirmAction.type === 'withdraw' ? { background: '#faad14' } : { background: '#722ed1' }}
                onClick={() => {
                  if (confirmAction.type === 'delete') handleDelete(confirmAction.record!)
                  else if (confirmAction.type === 'withdraw') handleWithdraw(confirmAction.record!)
                  else if (confirmAction.type === 'out') {
                    setBorrowList(prev => prev.map(b => b.id === confirmAction.record!.id ? { ...b, status: 'returned' as BorrowStatus } : b))
                    setConfirmAction({ type: '', record: null })
                    alert('出库成功')
                  }
                }}
              >
                {confirmAction.type === 'delete' ? '确认删除' : confirmAction.type === 'withdraw' ? '确认撤回' : '确认出库'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
