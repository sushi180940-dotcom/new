import { useState, useMemo } from 'react'
import ReactEChartsCore from 'echarts-for-react'

const regionData = [
  { city: '福州市', districts: ['鼓楼区','台江区','仓山区','晋安区','马尾区','长乐区','福清市','闽侯县','连江县','罗源县','闽清县','永泰县'] },
  { city: '厦门市', districts: ['思明区','湖里区','集美区','海沧区','同安区','翔安区'] },
  { city: '莆田市', districts: ['城厢区','涵江区','荔城区','秀屿区','仙游县'] },
  { city: '三明市', districts: ['三元区','沙县区','永安市','明溪县','清流县','宁化县','大田县','尤溪县','将乐县','泰宁县','建宁县'] },
  { city: '泉州市', districts: ['鲤城区','丰泽区','洛江区','泉港区','石狮市','晋江市','南安市','惠安县','安溪县','永春县','德化县'] },
  { city: '漳州市', districts: ['芗城区','龙文区','龙海区','长泰区','漳浦县','云霄县','诏安县','东山县','平和县','南靖县','华安县'] },
  { city: '南平市', districts: ['延平区','建阳区','邵武市','武夷山市','建瓯市','顺昌县','浦城县','光泽县','松溪县','政和县'] },
  { city: '龙岩市', districts: ['新罗区','永定区','漳平市','长汀县','上杭县','武平县','连城县'] },
  { city: '宁德市', districts: ['蕉城区','福安市','福鼎市','霞浦县','古田县','屏南县','寿宁县','周宁县','柘荣县'] },
]

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

const months = ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月']

export default function AnalysisAllocationPage({ onNavigate }: Props) {

  // ========== 1. 装备储备现状 ==========
  const reserveStatusOption = useMemo(() => ({
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', right: 10, top: 'center', textStyle: { fontSize: 11 } },
    series: [{
      type: 'pie', radius: ['35%', '65%'], center: ['35%', '50%'],
      avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{d}%' },
      data: [
        { value: 48600, name: '在库', itemStyle: { color: '#1890ff' } },
        { value: 85230, name: '在用', itemStyle: { color: '#52c41a' } },
        { value: 12450, name: '待修', itemStyle: { color: '#faad14' } },
        { value: 5820, name: '待报废', itemStyle: { color: '#ff4d4f' } },
        { value: 3130, name: '调拨中', itemStyle: { color: '#722ed1' } },
      ],
    }],
  }), [])

  const unitReserveOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['通信设备', '防护装备', '记录设备', '照明设备', '应急装备'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['省厅', '市局限', 'A区局', 'B区局', 'C区局', 'D区局', 'E区局', 'F区局'] },
    yAxis: { type: 'value', name: '数量(件)' },
    series: [
      { name: '通信设备', type: 'bar', stack: 'total', data: [2180, 1950, 820, 760, 640, 580, 490, 420], itemStyle: { color: '#1890ff' } },
      { name: '防护装备', type: 'bar', stack: 'total', data: [1850, 1620, 720, 680, 550, 510, 430, 380], itemStyle: { color: '#52c41a' } },
      { name: '记录设备', type: 'bar', stack: 'total', data: [1520, 1380, 580, 540, 460, 420, 350, 310], itemStyle: { color: '#faad14' } },
      { name: '照明设备', type: 'bar', stack: 'total', data: [980, 860, 380, 350, 300, 270, 230, 200], itemStyle: { color: '#722ed1' } },
      { name: '应急装备', type: 'bar', stack: 'total', data: [1280, 1150, 480, 450, 380, 350, 290, 260], itemStyle: { color: '#13c2c2' } },
    ],
  }), [])

  const equipCategoryOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '8%', containLabel: true },
    xAxis: { type: 'value', name: '数量(件)' },
    yAxis: { type: 'category', data: ['手持终端', '执法记录仪', '防弹背心', '对讲机', '战术头盔', '强光手电', '应急照明灯', '防弹盾牌'], axisLabel: { fontSize: 11 } },
    series: [
      { name: '库存量', type: 'bar', data: [12580, 11250, 9850, 8760, 7230, 6890, 5420, 3850], barWidth: 16, itemStyle: { color: '#1890ff', borderRadius: [0, 4, 4, 0] }, label: { show: true, position: 'right', fontSize: 11 } },
    ],
  }), [])

  // ========== 2. 流转频次 ==========
  const inOutTrendOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['入库量', '出库量', '调拨量'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: { type: 'value', name: '数量(件)' },
    series: [
      { name: '入库量', type: 'line', data: [1200, 1350, 1180, 1520, 1680, 1450, 1320, 1580, 1720, 1490, 1650, 1800], smooth: true, itemStyle: { color: '#1890ff' }, areaStyle: { color: 'rgba(24,144,255,0.08)' } },
      { name: '出库量', type: 'line', data: [980, 1120, 1050, 1280, 1420, 1250, 1180, 1350, 1480, 1320, 1450, 1580], smooth: true, itemStyle: { color: '#52c41a' }, areaStyle: { color: 'rgba(82,196,26,0.08)' } },
      { name: '调拨量', type: 'line', data: [180, 220, 195, 280, 320, 250, 210, 290, 340, 260, 310, 350], smooth: true, itemStyle: { color: '#faad14' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const turnoverRateOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['库存周转率(次/年)', '平均流转周期(天)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [
      { type: 'value', name: '周转率(次)', position: 'left' },
      { type: 'value', name: '天数', position: 'right' },
    ],
    series: [
      { name: '库存周转率(次/年)', type: 'line', data: [4.2, 4.5, 3.8, 5.1, 5.6, 4.8, 4.3, 5.2, 5.8, 4.6, 5.0, 5.5], smooth: true, itemStyle: { color: '#1890ff' } },
      { name: '平均流转周期(天)', type: 'line', yAxisIndex: 1, data: [18, 16, 21, 15, 13, 16, 17, 14, 12, 15, 14, 13], smooth: true, itemStyle: { color: '#ff4d4f' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const unitTransferOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['调入', '调出'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['省厅', '市局限', 'A区局', 'B区局', 'C区局', 'D区局', 'E区局', 'F区局'] },
    yAxis: { type: 'value', name: '调拨量(件)' },
    series: [
      { name: '调入', type: 'bar', data: [320, 580, 420, 380, 290, 250, 210, 180], itemStyle: { color: '#52c41a' }, barMaxWidth: 24 },
      { name: '调出', type: 'bar', data: [180, 420, 350, 320, 260, 220, 190, 160], itemStyle: { color: '#ff4d4f' }, barMaxWidth: 24 },
    ],
  }), [])

  // ========== 3. 损耗情况 ==========
  const faultTypeOption = useMemo(() => ({
    tooltip: { trigger: 'item' },
    legend: { orient: 'vertical', right: 10, top: 'center' },
    series: [{
      type: 'pie', radius: ['40%', '70%'], center: ['35%', '50%'],
      avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{b}\n{d}%' },
      data: [
        { value: 356, name: '硬件故障', itemStyle: { color: '#ff4d4f' } },
        { value: 248, name: '电池老化', itemStyle: { color: '#faad14' } },
        { value: 185, name: '接口损坏', itemStyle: { color: '#1890ff' } },
        { value: 128, name: '软件问题', itemStyle: { color: '#52c41a' } },
        { value: 98, name: '人为损坏', itemStyle: { color: '#722ed1' } },
        { value: 85, name: '其他', itemStyle: { color: '#999' } },
      ],
    }],
  }), [])

  const lossTrendOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['报修次数', '报废数量', '故障率(%)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [
      { type: 'value', name: '数量', position: 'left' },
      { type: 'value', name: '故障率(%)', position: 'right' },
    ],
    series: [
      { name: '报修次数', type: 'bar', data: [85, 92, 78, 105, 118, 95, 88, 102, 115, 98, 108, 125], itemStyle: { color: '#faad14' }, barMaxWidth: 20 },
      { name: '报废数量', type: 'bar', data: [32, 38, 28, 42, 48, 35, 30, 40, 45, 36, 42, 50], itemStyle: { color: '#ff4d4f' }, barMaxWidth: 20 },
      { name: '故障率(%)', type: 'line', yAxisIndex: 1, data: [3.2, 3.5, 2.8, 4.1, 4.5, 3.6, 3.3, 3.9, 4.3, 3.5, 3.8, 4.2], smooth: true, itemStyle: { color: '#722ed1' }, lineStyle: { width: 3 } },
    ],
  }), [])

  const equipLossOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '8%', containLabel: true },
    xAxis: { type: 'value', name: '数量(件)' },
    yAxis: { type: 'category', data: ['手持终端', '执法记录仪', '对讲机', '防弹背心', '强光手电', '战术头盔', '应急照明', '防弹盾牌'], axisLabel: { fontSize: 11 } },
    series: [
      { name: '报修数', type: 'bar', data: [185, 162, 98, 72, 85, 58, 68, 42], barWidth: 12, itemStyle: { color: '#faad14', borderRadius: [0, 4, 4, 0] } },
      { name: '报废数', type: 'bar', data: [68, 72, 35, 28, 42, 22, 32, 18], barWidth: 12, itemStyle: { color: '#ff4d4f', borderRadius: [0, 4, 4, 0] } },
    ],
  }), [])

  // ========== 4. 维保质量 ==========
  const maintenanceQualityOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['完好率(%)', '维修及时率(%)', '平均维修天数'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [
      { type: 'value', name: '百分比(%)', min: 80, max: 100, position: 'left' },
      { type: 'value', name: '天数', position: 'right' },
    ],
    series: [
      { name: '完好率(%)', type: 'line', data: [96.8, 96.2, 97.5, 95.9, 95.2, 96.5, 97.2, 96.4, 95.8, 97.0, 96.5, 96.0], smooth: true, itemStyle: { color: '#52c41a' }, lineStyle: { width: 3 } },
      { name: '维修及时率(%)', type: 'line', data: [92.5, 90.8, 93.2, 88.5, 86.2, 89.5, 91.2, 88.8, 87.5, 90.2, 89.5, 88.0], smooth: true, itemStyle: { color: '#1890ff' } },
      { name: '平均维修天数', type: 'line', yAxisIndex: 1, data: [5.2, 5.8, 4.5, 6.2, 7.0, 5.5, 4.8, 5.5, 6.5, 5.0, 5.2, 6.0], smooth: true, itemStyle: { color: '#faad14' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const supplierServiceOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '8%', bottom: '8%', containLabel: true },
    xAxis: { type: 'value', max: 100, name: '评分' },
    yAxis: { type: 'category', data: ['华为技术', '海康威视', '大华股份', '中兴通讯', '浪潮集团'], axisLabel: { fontSize: 11 } },
    series: [
      { name: '维保响应评分', type: 'bar', data: [92, 88, 82, 85, 78], barWidth: 16, itemStyle: { color: '#1890ff', borderRadius: [0, 4, 4, 0] }, label: { show: true, position: 'right', fontSize: 11 } },
    ],
  }), [])

  const unitMaintenanceOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['完好率(%)', '报修率(%)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['省厅', '市局限', 'A区局', 'B区局', 'C区局', 'D区局', 'E区局', 'F区局'] },
    yAxis: { type: 'value', name: '百分比(%)' },
    series: [
      { name: '完好率(%)', type: 'bar', data: [98.2, 96.8, 95.5, 94.2, 93.8, 95.0, 94.5, 96.0], itemStyle: { color: '#52c41a' }, barMaxWidth: 20 },
      { name: '报修率(%)', type: 'bar', data: [1.8, 3.2, 4.5, 5.8, 6.2, 5.0, 5.5, 4.0], itemStyle: { color: '#ff4d4f' }, barMaxWidth: 20 },
    ],
  }), [])

  // ========== 5. 资源调配短板 ==========
  const allocationGapOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['当前配备量', '标准配备量', '缺口'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: ['省厅', '市局限', 'A区局', 'B区局', 'C区局', 'D区局', 'E区局', 'F区局'] },
    yAxis: { type: 'value', name: '数量(件)' },
    series: [
      { name: '当前配备量', type: 'bar', data: [7820, 6920, 2980, 2780, 2330, 2150, 1790, 1570], itemStyle: { color: '#1890ff' }, barMaxWidth: 18 },
      { name: '标准配备量', type: 'bar', data: [8500, 7500, 3200, 3000, 2600, 2400, 2000, 1800], itemStyle: { color: '#52c41a' }, barMaxWidth: 18 },
      { name: '缺口', type: 'bar', data: [680, 580, 220, 220, 270, 250, 210, 230], itemStyle: { color: '#ff4d4f' }, barMaxWidth: 18 },
    ],
  }), [])

  const allocationEfficiencyOption = useMemo(() => ({
    tooltip: { trigger: 'axis' },
    legend: { data: ['调拨完成率(%)', '调拨响应时间(小时)'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', containLabel: true },
    xAxis: { type: 'category', data: months },
    yAxis: [
      { type: 'value', name: '完成率(%)', position: 'left' },
      { type: 'value', name: '小时', position: 'right' },
    ],
    series: [
      { name: '调拨完成率(%)', type: 'line', data: [92, 90, 93, 88, 85, 89, 91, 87, 84, 90, 88, 86], smooth: true, itemStyle: { color: '#1890ff' } },
      { name: '调拨响应时间(小时)', type: 'line', yAxisIndex: 1, data: [18, 22, 16, 28, 32, 24, 20, 30, 35, 25, 28, 34], smooth: true, itemStyle: { color: '#faad14' }, lineStyle: { type: 'dashed' } },
    ],
  }), [])

  const radarOption = useMemo(() => ({
    tooltip: {},
    radar: {
      indicator: [
        { name: '储备充足率', max: 100 },
        { name: '流转效率', max: 100 },
        { name: '损耗控制', max: 100 },
        { name: '维保质量', max: 100 },
        { name: '调配响应', max: 100 },
        { name: '信息化水平', max: 100 },
      ],
      radius: '60%',
    },
    legend: { bottom: 0 },
    series: [{
      type: 'radar',
      data: [
        { value: [88, 82, 75, 90, 78, 85], name: '全省平均', itemStyle: { color: '#1890ff' }, areaStyle: { color: 'rgba(24,144,255,0.2)' } },
        { value: [72, 68, 80, 85, 65, 70], name: '薄弱单位', itemStyle: { color: '#ff4d4f' }, areaStyle: { color: 'rgba(255,77,79,0.2)' } },
        { value: [95, 92, 88, 96, 90, 95], name: '标杆单位', itemStyle: { color: '#52c41a' }, areaStyle: { color: 'rgba(82,196,26,0.2)' } },
      ],
    }],
  }), [])

  const weakPointsData = [
    { name: 'C区局通信设备', gap: '缺口270件', reason: '编制扩充未同步配备', suggestion: '启动应急采购/跨区调拨' },
    { name: 'F区局防护装备', gap: '缺口230件', reason: '损耗率高、更新滞后', suggestion: '加强维保/批量更换' },
    { name: 'D区局应急装备', gap: '缺口250件', reason: '调配响应慢、储备不足', suggestion: '优化调拨流程/增加储备' },
    { name: 'E区局照明设备', gap: '缺口210件', reason: '预算不足、采购延迟', suggestion: '追加预算/分期采购' },
    { name: 'B区局记录设备', gap: '缺口220件', reason: '设备老化、故障率高', suggestion: '以旧换新/集中更新' },
  ]

  const [alTime, setAlTime] = useState('year')
  const [alCity, setAlCity] = useState('')
  const [alDistrict, setAlDistrict] = useState('')
  const districts = alCity ? (regionData.find(r => r.city === alCity)?.districts || []) : []

  return (
    <div className="p-6 space-y-6">
      <div className="content-card p-4 mb-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>时间范围</label>
            <select className="form-input w-32 text-sm" value={alTime} onChange={e => setAlTime(e.target.value)}>
              <option value="year">本年度</option>
              <option value="half">近半年</option>
              <option value="quarter">近季度</option>
              <option value="custom">自定义</option>
            </select>
          </div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>省</label><select className="form-input w-28 text-sm" disabled><option>福建省</option></select></div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>地市</label>
            <select className="form-input w-32 text-sm" value={alCity} onChange={e => { setAlCity(e.target.value); setAlDistrict('') }}>
              <option value="">全省</option>
              {regionData.map(r => <option key={r.city}>{r.city}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>区县</label>
            <select className="form-input w-32 text-sm" value={alDistrict} onChange={e => setAlDistrict(e.target.value)} disabled={!alCity}>
              <option value="">全部</option>
              {districts.map(d => <option key={d}>{d}</option>)}
            </select>
          </div>
          {alTime === 'custom' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>开始日期</label><input type="date" className="form-input w-32 text-sm" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>结束日期</label><input type="date" className="form-input w-32 text-sm" /></div>
            </>
          )}
        </div>
      </div>

      {/* ========== 1. 装备储备现状 ========== */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: '#1890ff' }} />
          <h3 className="font-semibold text-base">一、装备储备现状</h3>
        </div>
        <div className="grid grid-cols-5 gap-3 mb-4">
          {[
            { label: '装备总库存', value: '155,250件', color: '#1890ff' },
            { label: '在库金额', value: '4.68亿', color: '#52c41a' },
            { label: '在用装备', value: '85,230件', color: '#722ed1' },
            { label: '覆盖单位', value: '128个', color: '#faad14' },
            { label: '品类数量', value: '68种', color: '#13c2c2' },
          ].map(c => (
            <div key={c.label} className="content-card p-3 text-center">
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">装备状态分布</h4>
            <ReactEChartsCore option={reserveStatusOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各单位装备储备构成</h4>
            <ReactEChartsCore option={unitReserveOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各品类装备库存量</h4>
            <ReactEChartsCore option={equipCategoryOption} style={{ height: 260 }} notMerge={true} />
          </div>
        </div>
      </div>

      {/* ========== 2. 流转频次 ========== */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: '#52c41a' }} />
          <h3 className="font-semibold text-base">二、流转频次分析</h3>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label: '年入库总量', value: '17,840件', color: '#1890ff' },
            { label: '年出库总量', value: '15,620件', color: '#52c41a' },
            { label: '年调拨总量', value: '3,180件', color: '#faad14' },
            { label: '库存周转率', value: '5.2次/年', color: '#722ed1' },
          ].map(c => (
            <div key={c.label} className="content-card p-3 text-center">
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">出入库月度趋势</h4>
            <ReactEChartsCore option={inOutTrendOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">库存周转率与流转周期</h4>
            <ReactEChartsCore option={turnoverRateOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各单位调拨情况</h4>
            <ReactEChartsCore option={unitTransferOption} style={{ height: 260 }} notMerge={true} />
          </div>
        </div>
      </div>

      {/* ========== 3. 损耗情况 ========== */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: '#ff4d4f' }} />
          <h3 className="font-semibold text-base">三、损耗情况分析</h3>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label: '年报修总数', value: '1,200次', color: '#ff4d4f' },
            { label: '年报废总数', value: '445件', color: '#faad14' },
            { label: '平均故障率', value: '3.8%', color: '#1890ff' },
            { label: '平均报废率', value: '2.1%', color: '#722ed1' },
          ].map(c => (
            <div key={c.label} className="content-card p-3 text-center">
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">故障类型分布</h4>
            <ReactEChartsCore option={faultTypeOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">损耗月度趋势</h4>
            <ReactEChartsCore option={lossTrendOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各品类损耗对比</h4>
            <ReactEChartsCore option={equipLossOption} style={{ height: 260 }} notMerge={true} />
          </div>
        </div>
      </div>

      {/* ========== 4. 维保质量 ========== */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: '#faad14' }} />
          <h3 className="font-semibold text-base">四、维保质量分析</h3>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label: '装备完好率', value: '96.4%', color: '#52c41a' },
            { label: '维修及时率', value: '89.5%', color: '#1890ff' },
            { label: '平均维修时间', value: '5.5天', color: '#faad14' },
            { label: '售后满意度', value: '88.5%', color: '#722ed1' },
          ].map(c => (
            <div key={c.label} className="content-card p-3 text-center">
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">维保质量趋势</h4>
            <ReactEChartsCore option={maintenanceQualityOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">供应商维保响应评分</h4>
            <ReactEChartsCore option={supplierServiceOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各单位维保对比</h4>
            <ReactEChartsCore option={unitMaintenanceOption} style={{ height: 260 }} notMerge={true} />
          </div>
        </div>
      </div>

      {/* ========== 5. 资源调配短板 ========== */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <div className="w-1 h-5 rounded-full" style={{ background: '#722ed1' }} />
          <h3 className="font-semibold text-base">五、资源调配短板分析</h3>
        </div>
        <div className="grid grid-cols-4 gap-3 mb-4">
          {[
            { label: '配备缺口总数', value: '2,590件', color: '#ff4d4f' },
            { label: '调拨完成率', value: '88.2%', color: '#1890ff' },
            { label: '平均调拨响应', value: '26小时', color: '#faad14' },
            { label: '配备达标率', value: '83.6%', color: '#52c41a' },
          ].map(c => (
            <div key={c.label} className="content-card p-3 text-center">
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{c.label}</p>
              <p className="text-xl font-bold" style={{ color: c.color }}>{c.value}</p>
            </div>
          ))}
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">各单位配备缺口</h4>
            <ReactEChartsCore option={allocationGapOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">调拨效率趋势</h4>
            <ReactEChartsCore option={allocationEfficiencyOption} style={{ height: 260 }} notMerge={true} />
          </div>
          <div className="content-card p-4">
            <h4 className="font-semibold text-sm mb-3">综合能力雷达图</h4>
            <ReactEChartsCore option={radarOption} style={{ height: 260 }} notMerge={true} />
          </div>
        </div>
      </div>

      {/* 短板明细表 */}
      <div className="content-card overflow-hidden">
        <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
          <h4 className="font-semibold text-sm">资源调配短板明细</h4>
        </div>
        <table className="data-table text-sm">
          <thead>
            <tr>
              <th>短板项</th>
              <th>缺口情况</th>
              <th>原因分析</th>
              <th>改进建议</th>
            </tr>
          </thead>
          <tbody>
            {weakPointsData.map((item, i) => (
              <tr key={i}>
                <td className="font-medium">{item.name}</td>
                <td><span className="px-2 py-0.5 rounded text-xs" style={{ background: '#fff2f0', color: '#ff4d4f' }}>{item.gap}</span></td>
                <td style={{ color: 'var(--text-secondary)' }}>{item.reason}</td>
                <td style={{ color: 'var(--primary-blue)' }}>{item.suggestion}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
