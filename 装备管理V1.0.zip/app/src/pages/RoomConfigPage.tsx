import { useState } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

interface Room {
  id: string
  name: string
  address: string
  parent?: string
  roomType: string
  entityType?: string
  unit: string
  level: string
  manager: string
  remark: string
  status: string
}

export default function RoomConfigPage({ onNavigate }: Props) {
  const [modalOpen, setModalOpen] = useState(false)
  const [viewMode, setViewMode] = useState<'form' | 'card'>('card')
  const [roomForm, setRoomForm] = useState({
    parent: '', name: '', address: '', unit: '', level: '',
    roomType: '实体' as '实体' | '虚拟', entityType: '仓库' as '仓库' | '分区' | '货架',
    zoneName: '', manager: '', remark: ''
  })
  const [sortOrder, setSortOrder] = useState('')
  const [boardPos, setBoardPos] = useState('')

  const resetRoomForm = () => {
    setRoomForm({ parent: '', name: '', address: '', unit: '', level: '', roomType: '实体', entityType: '仓库', zoneName: '', manager: '', remark: '' })
    setSortOrder('')
    setBoardPos('')
  }

  const [rooms, setRooms] = useState<Room[]>([
    { id: 'ES001', name: '省厅主仓库', address: '省厅A栋1楼', roomType: '实体', entityType: '仓库', unit: '省厅装备处', level: '省级', manager: '张磊', remark: '主仓库', status: 'normal' },
    { id: 'ES002', name: '市局限装备仓库', address: '市局限A栋', roomType: '实体', entityType: '仓库', unit: '市局装备处', level: '市级', manager: '李强', remark: '市级仓库', status: 'normal' },
    { id: 'ES003', name: 'A区县级装备库', address: 'A区局B栋', roomType: '实体', entityType: '分区', unit: 'A区局', level: '区县级', manager: '王明', remark: '分区存储', status: 'normal' },
    { id: 'ES004', name: 'B区县级装备库', address: 'B区局地下一层', roomType: '实体', entityType: '分区', unit: 'B区局', level: '区县级', manager: '赵军', remark: '地下仓库', status: 'normal' },
  ])

  const statusMap: Record<string, { label: string; tag: string }> = {
    normal: { label: '正常', tag: 'tag-green' },
    full: { label: '已满', tag: 'tag-red' },
    maintenance: { label: '维护中', tag: 'tag-yellow' },
  }

  return (
    <div className="space-y-4">
      {/* Action bar */}
      <div className="flex items-center justify-between">
        <button className="btn-primary flex items-center gap-1 text-sm" onClick={() => setModalOpen(true)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          新增仓库
        </button>
        <div className="flex border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
          <button onClick={() => setViewMode('card')} className={`px-4 py-1.5 text-xs transition-all ${viewMode === 'card' ? 'font-medium' : ''}`} style={{ background: viewMode === 'card' ? 'var(--primary-blue)' : 'transparent', color: viewMode === 'card' ? '#fff' : 'var(--text-secondary)' }}>卡片</button>
          <button onClick={() => setViewMode('form')} className={`px-4 py-1.5 text-xs transition-all ${viewMode === 'form' ? 'font-medium' : ''}`} style={{ background: viewMode === 'form' ? 'var(--primary-blue)' : 'transparent', color: viewMode === 'form' ? '#fff' : 'var(--text-secondary)' }}>表单</button>
        </div>
      </div>

      {/* Card view */}
      {viewMode === 'card' && (
        <div className="grid grid-cols-2 gap-4">
          {rooms.map(room => (
            <div key={room.id} className="content-card p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: '#e6f4ff' }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="1.5">
                      <path d="M3 21h18M5 21V7l8-4 8 4v14M9 21v-6h6v6"/>
                    </svg>
                  </div>
                  <div>
                    <h4 className="font-semibold text-sm">{room.name}</h4>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{room.id}</p>
                  </div>
                </div>
                <span className={`tag ${statusMap[room.status]?.tag || 'tag-gray'} text-xs`}>{statusMap[room.status]?.label || room.status}</span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs mb-3">
                <div><span style={{ color: 'var(--text-secondary)' }}>仓库地址：</span>{room.address}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>库室类型：</span>{room.roomType}{room.entityType ? `/${room.entityType}` : ''}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>所属单位：</span>{room.unit}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>库室层级：</span>{room.level}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>负责人：</span>{room.manager}</div>
                <div><span style={{ color: 'var(--text-secondary)' }}>备注：</span>{room.remark || '-'}</div>
              </div>
              <div className="flex items-center justify-end gap-2 pt-2 border-t" style={{ borderColor: 'var(--border-color)' }}>
                <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>编辑</button>
                <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }}>删除</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Form view */}
      {viewMode === 'form' && (
        <div className="content-card overflow-hidden">
          <table className="data-table">
            <thead>
              <tr>
                <th>仓库编号</th>
                <th>仓库名称</th>
                <th>仓库地址</th>
                <th>库室类型</th>
                <th>所属单位</th>
                <th>库室层级</th>
                <th>负责人</th>
                <th>备注</th>
                <th>状态</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {rooms.map(room => (
                <tr key={room.id}>
                  <td className="font-mono text-xs">{room.id}</td>
                  <td className="font-medium text-sm">{room.name}</td>
                  <td className="text-xs">{room.address}</td>
                  <td><span className="tag tag-gray text-xs">{room.roomType}{room.entityType ? `/${room.entityType}` : ''}</span></td>
                  <td className="text-xs">{room.unit}</td>
                  <td><span className="tag text-xs" style={{ background: '#e6f7ff', color: '#1890ff' }}>{room.level}</span></td>
                  <td>{room.manager}</td>
                  <td className="text-xs">{room.remark || '-'}</td>
                  <td><span className={`tag ${statusMap[room.status]?.tag || 'tag-gray'} text-xs`}>{statusMap[room.status]?.label || room.status}</span></td>
                  <td>
                    <div className="flex gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>编辑</button>
                      <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }}>删除</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setModalOpen(false); resetRoomForm() }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[560px] p-6 animate-in fade-in zoom-in duration-200" style={{ maxHeight: '90vh', overflowY: 'auto' }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold">新增仓库</h3>
              <button onClick={() => { setModalOpen(false); resetRoomForm() }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>仓库名称 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" placeholder="请输入仓库名称" value={roomForm.name} onChange={e => setRoomForm({ ...roomForm, name: e.target.value })} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>仓库地址 <span className="text-red-400">*</span></label>
                <input className="form-input w-full" placeholder="请输入仓库地址" value={roomForm.address} onChange={e => setRoomForm({ ...roomForm, address: e.target.value })} />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>上级节点</label>
                <select className="form-input w-full" value={roomForm.parent} onChange={e => setRoomForm({ ...roomForm, parent: e.target.value })}>
                  <option value="">无（顶级节点）</option>
                  {rooms.map(r => (
                    <option key={r.id} value={r.id}>{r.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库室类型 <span className="text-red-400">*</span></label>
                <div className="flex gap-3 mb-2">
                  {(['实体', '虚拟'] as const).map(t => (
                    <label key={t} className={`flex items-center gap-1.5 px-3 py-1.5 rounded border text-xs cursor-pointer transition-all ${roomForm.roomType === t ? 'border-blue-500 bg-blue-50 text-blue-600' : 'border-gray-200'}`}>
                      <input type="radio" name="roomType" value={t} checked={roomForm.roomType === t} onChange={e => setRoomForm({ ...roomForm, roomType: e.target.value as '实体' | '虚拟' })} className="hidden" />
                      {t}
                    </label>
                  ))}
                </div>
                {roomForm.roomType === '实体' && (
                  <div className="p-3 rounded-lg border space-y-2" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                    <label className="block text-xs font-medium">货区货架</label>
                    <div className="flex gap-2 mb-2">
                      {(['仓库', '分区', '货架'] as const).map(t => (
                        <label key={t} className={`flex items-center gap-1.5 px-3 py-1 rounded border text-xs cursor-pointer transition-all ${roomForm.entityType === t ? 'border-green-500 bg-green-50 text-green-600' : 'border-gray-200'}`}>
                          <input type="radio" name="entityType" value={t} checked={roomForm.entityType === t} onChange={e => setRoomForm({ ...roomForm, entityType: e.target.value as '仓库' | '分区' | '货架' })} className="hidden" />
                          {t}
                        </label>
                      ))}
                    </div>
                    {roomForm.entityType === '仓库' && (
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号</label>
                        <input className="form-input w-full text-sm font-mono" type="number" placeholder="请输入排序号" value={sortOrder} onChange={e => setSortOrder(e.target.value)} />
                      </div>
                    )}
                    {(roomForm.entityType === '分区' || roomForm.entityType === '货架') && (
                      <div className="grid grid-cols-2 gap-3">
                        <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>看板位置</label><input className="form-input w-full text-sm" placeholder="如：A区01排" value={boardPos} onChange={e => setBoardPos(e.target.value)} /></div>
                        <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号</label><input className="form-input w-full text-sm font-mono" type="number" placeholder="请输入排序号" value={sortOrder} onChange={e => setSortOrder(e.target.value)} /></div>
                      </div>
                    )}
                  </div>
                )}
                {roomForm.roomType === '虚拟' && (
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>货区名称 <span className="text-red-400">*</span></label><input className="form-input w-full text-sm" placeholder="请输入货区名称" value={roomForm.zoneName} onChange={e => setRoomForm({ ...roomForm, zoneName: e.target.value })} /></div>
                      <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号</label><input className="form-input w-full text-sm font-mono" type="number" placeholder="请输入排序号" value={sortOrder} onChange={e => setSortOrder(e.target.value)} /></div>
                    </div>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属单位 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入所属单位" value={roomForm.unit} onChange={e => setRoomForm({ ...roomForm, unit: e.target.value })} /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库室层级 <span className="text-red-400">*</span></label><select className="form-input w-full" value={roomForm.level} onChange={e => setRoomForm({ ...roomForm, level: e.target.value })}>
                  <option value="">请选择</option>
                  <option value="省级">省级</option>
                  <option value="市级">市级</option>
                  <option value="区县级">区县级</option>
                  <option value="所级">所级</option>
                  <option value="其他">其他</option>
                </select></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>负责人 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入负责人" value={roomForm.manager} onChange={e => setRoomForm({ ...roomForm, manager: e.target.value })} /></div>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                <textarea className="form-input w-full text-sm" rows={2} placeholder="请输入备注信息..." value={roomForm.remark} onChange={e => setRoomForm({ ...roomForm, remark: e.target.value })} />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-5">
              <button className="btn-default" onClick={() => { setModalOpen(false); resetRoomForm() }}>取消</button>
              <button className="btn-primary" onClick={() => { setModalOpen(false); resetRoomForm(); alert('新增成功') }}>确认</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
