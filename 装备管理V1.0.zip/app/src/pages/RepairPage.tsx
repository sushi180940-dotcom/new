import { useState } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

// ===== 仓库数据（与入库管理一致） =====
interface Warehouse {
  id: string
  name: string
  parent?: string
  entityType: string
  level: string
  children?: Warehouse[]
}

const warehouseData: Warehouse[] = [
  {
    id: 'ES001', name: '省厅主仓库', parent: undefined, entityType: '仓库', level: '省级',
    children: [
      { id: 'ES001-A', name: 'A区-01货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-B', name: 'A区-02货架', parent: 'ES001', entityType: '货架', level: '省级' },
      { id: 'ES001-C', name: 'A区-03货架', parent: 'ES001', entityType: '货架', level: '省级' },
    ]
  },
  {
    id: 'ES002', name: '市局限装备仓库', parent: undefined, entityType: '仓库', level: '市级',
    children: [
      { id: 'ES002-A', name: 'B区-01货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-B', name: 'B区-02货架', parent: 'ES002', entityType: '货架', level: '市级' },
      { id: 'ES002-C', name: 'B区-03货架', parent: 'ES002', entityType: '货架', level: '市级' },
    ]
  },
  {
    id: 'ES003', name: 'A区县级装备库', parent: undefined, entityType: '分区', level: '区县级',
    children: [
      { id: 'ES003-A', name: 'C区-01货架', parent: 'ES003', entityType: '货架', level: '区县级' },
      { id: 'ES003-B', name: 'C区-02货架', parent: 'ES003', entityType: '货架', level: '区县级' },
    ]
  },
  { id: 'ES004', name: 'B区县级装备库', parent: undefined, entityType: '分区', level: '区县级', children: [] },
]

function flattenWarehouses(nodes: Warehouse[], depth = 0): { id: string; label: string }[] {
  const result: { id: string; label: string }[] = []
  for (const n of nodes) {
    const indent = '\u00A0\u00A0'.repeat(depth)
    result.push({ id: n.id, label: `${indent}${n.name}` })
    if (n.children) result.push(...flattenWarehouses(n.children, depth + 1))
  }
  return result
}

// ===== 库存装备数据源 =====
interface StockMaterial {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  unit: string
  produceDate: string
  validDate: string
  maintainPeriod: string
  price: number
  total: number
  equipCode: string
  rfidCode: string
  supplier: string
  remark: string
}

const stockMaterials: StockMaterial[] = [
  { id: 'S001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 50, unit: '台', produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', price: 2800, total: 140000, equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', supplier: '华为技术有限公司', remark: '期初盘点' },
  { id: 'S002', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 30, unit: '台', produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', price: 1500, total: 45000, equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', supplier: '烽火通信科技股份有限公司', remark: '' },
  { id: 'S003', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 100, unit: '台', produceDate: '2024-02-20', validDate: '2027-02-20', maintainPeriod: '6个月', price: 1800, total: 180000, equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', supplier: '海康威视数字技术股份有限公司', remark: '批量采购' },
  { id: 'S004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 20, unit: '件', produceDate: '2024-01-10', validDate: '2029-01-10', maintainPeriod: '12个月', price: 3200, total: 64000, equipCode: '0101P00300', rfidCode: '10101P0030012024021010004XXXXXX0004', supplier: '华为技术有限公司', remark: '从市局调拨' },
  { id: 'S005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 15, unit: '顶', produceDate: '2024-01-15', validDate: '2028-01-15', maintainPeriod: '6个月', price: 2600, total: 39000, equipCode: '0101P00400', rfidCode: '10101P0040012024031505005XXXXXX0005', supplier: '中兴通讯股份有限公司', remark: '任务结束归还' },
  { id: 'S006', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 40, unit: '根', produceDate: '2024-03-01', validDate: '2027-03-01', maintainPeriod: '6个月', price: 350, total: 14000, equipCode: '0101P00600', rfidCode: '10101P0060012024031505006XXXXXX0006', supplier: '大华技术股份有限公司', remark: '派出所配发' },
  { id: 'S007', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 60, unit: '件', produceDate: '2024-09-01', validDate: '2027-09-01', maintainPeriod: '3个月', price: 45, total: 2700, equipCode: '0101P03400', rfidCode: '10101P0340012024090105007XXXXXX0007', supplier: '大华技术股份有限公司', remark: '' },
  { id: 'S008', name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', qty: 5, unit: '辆', produceDate: '2024-11-01', validDate: '2027-11-01', maintainPeriod: '3个月', price: 28000, total: 140000, equipCode: '0101P04600', rfidCode: '10101P0460012024110105008XXXXXX0008', supplier: '中兴通讯股份有限公司', remark: '交警中队' },
  { id: 'S009', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 20, unit: '面', produceDate: '2024-11-15', validDate: '2029-11-15', maintainPeriod: '12个月', price: 680, total: 13600, equipCode: '0101P04700', rfidCode: '10101P0470012024111505009XXXXXX0009', supplier: '华为技术有限公司', remark: '' },
  { id: 'S010', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 60, unit: '台', produceDate: '2024-04-15', validDate: '2027-04-15', maintainPeriod: '6个月', price: 3500, total: 210000, equipCode: '0101P01600', rfidCode: '10101P0160012024041505010XXXXXX0010', supplier: '海康威视数字技术股份有限公司', remark: '指挥中心' },
  { id: 'S011', name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', qty: 45, unit: '根', produceDate: '2024-01-08', validDate: '2029-01-08', maintainPeriod: '6个月', price: 380, total: 17100, equipCode: '0101P01000', rfidCode: '10101P0100012024010805011XXXXXX0011', supplier: '中兴通讯股份有限公司', remark: '' },
  { id: 'S012', name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', qty: 50, unit: '个', produceDate: '2024-06-10', validDate: '2026-06-10', maintainPeriod: '6个月', price: 320, total: 16000, equipCode: '0101P02200', rfidCode: '10101P0220012024061005012XXXXXX0012', supplier: '烽火通信科技股份有限公司', remark: '过期提醒' },
]

// ===== 状态定义 =====
type RepairStatus = 'draft' | 'submitted' | 'approval1' | 'pending_out' | 'repairing' | 'repair_completed'

const statusMap: Record<RepairStatus, { label: string; tag: string }> = {
  draft: { label: '草稿', tag: 'tag-gray' },
  submitted: { label: '已提交', tag: 'tag-blue' },
  approval1: { label: '审批1', tag: 'tag-purple' },
  pending_out: { label: '待出库', tag: 'tag-yellow' },
  repairing: { label: '维修中', tag: 'tag-orange' },
  repair_completed: { label: '维修完成', tag: 'tag-green' },
}

// ===== 物资明细接口 =====
interface RepairItem {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  produceDate: string
  validDate: string
  maintainPeriod: string
  unit: string
  price: number
  total: number
  equipCode: string
  rfidCode: string
  supplier: string
  remark: string
}

// ===== 报修记录接口 =====
interface RepairRecord {
  id: string
  items: RepairItem[]
  description: string
  status: RepairStatus
  operator: string
  reportTime: string
}

const supplierOptions = ['华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司', '中兴通讯股份有限公司', '大华技术股份有限公司']

const emptyItem = (): RepairItem => ({
  id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
  name: '', category: '', spec: '', qty: 0,
  produceDate: '', validDate: '', maintainPeriod: '',
  unit: '个', price: 0, total: 0,
  equipCode: '', rfidCode: '', supplier: '', remark: '',
})

// ===== 样例数据（6条，每种状态1条） =====
const repairRecords: RepairRecord[] = [
  {
    id: 'BX2024001', description: '手持终端屏幕碎裂', status: 'draft', operator: '王建国', reportTime: '2024-03-15 09:30',
    items: [
      { id: '1', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 2, produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', unit: '台', price: 2800, total: 5600, equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', supplier: '华为技术有限公司', remark: '屏幕碎裂' },
      { id: '2', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 1, produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', unit: '台', price: 2800, total: 2800, equipCode: '0101P00100', rfidCode: '10101P0010012024031505001XXXXXX0001', supplier: '华为技术有限公司', remark: '无法开机' },
    ]
  },
  {
    id: 'BX2024002', description: '对讲机电池续航不足', status: 'submitted', operator: '李秀英', reportTime: '2024-03-18 10:00',
    items: [
      { id: '1', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 5, produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', unit: '台', price: 1500, total: 7500, equipCode: '0101P00500', rfidCode: '10101P0050012024031505002XXXXXX0002', supplier: '烽火通信科技股份有限公司', remark: '电池续航不足' },
    ]
  },
  {
    id: 'BX2024003', description: '执法记录仪存储故障', status: 'approval1', operator: '赵志刚', reportTime: '2024-03-20 14:30',
    items: [
      { id: '1', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 3, produceDate: '2024-02-20', validDate: '2027-02-20', maintainPeriod: '6个月', unit: '台', price: 1800, total: 5400, equipCode: '0101P00200', rfidCode: '10101P0020012024040105003XXXXXX0003', supplier: '海康威视数字技术股份有限公司', remark: '无法存储录像' },
      { id: '2', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 1, produceDate: '2024-04-15', validDate: '2027-04-15', maintainPeriod: '6个月', unit: '台', price: 3500, total: 3500, equipCode: '0101P01600', rfidCode: '10101P0020012024040105003XXXXXX0003', supplier: '海康威视数字技术股份有限公司', remark: '4G模块故障' },
    ]
  },
  {
    id: 'BX2024004', description: '防弹背心拉链损坏', status: 'pending_out', operator: '周丽华', reportTime: '2024-03-22 08:00',
    items: [
      { id: '1', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 8, produceDate: '2024-01-10', validDate: '2029-01-10', maintainPeriod: '12个月', unit: '件', price: 3200, total: 25600, equipCode: '0101P00300', rfidCode: '10101P0030012024021010004XXXXXX0004', supplier: '华为技术有限公司', remark: '拉链损坏需更换' },
    ]
  },
  {
    id: 'BX2024005', description: '战术头盔内衬老化', status: 'repairing', operator: '吴天明', reportTime: '2024-03-25 11:00',
    items: [
      { id: '1', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 10, produceDate: '2024-01-15', validDate: '2028-01-15', maintainPeriod: '6个月', unit: '顶', price: 2600, total: 26000, equipCode: '0101P00400', rfidCode: '10101P0040012024031505005XXXXXX0005', supplier: '中兴通讯股份有限公司', remark: '内衬老化需更换' },
      { id: '2', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 4, produceDate: '2024-11-15', validDate: '2029-11-15', maintainPeriod: '12个月', unit: '面', price: 680, total: 2720, equipCode: '0101P04700', rfidCode: '10101P0470012024111505009XXXXXX0009', supplier: '华为技术有限公司', remark: '表面划痕修复' },
    ]
  },
  {
    id: 'BX2024006', description: '警用手电开关失灵', status: 'repair_completed', operator: '孙秀兰', reportTime: '2024-03-28 16:00',
    items: [
      { id: '1', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 6, produceDate: '2024-03-01', validDate: '2027-03-01', maintainPeriod: '6个月', unit: '根', price: 350, total: 2100, equipCode: '0101P00600', rfidCode: '10101P0060012024031505006XXXXXX0006', supplier: '大华技术股份有限公司', remark: '开关已修复' },
      { id: '2', name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', qty: 3, produceDate: '2024-01-08', validDate: '2029-01-08', maintainPeriod: '6个月', unit: '根', price: 380, total: 1140, equipCode: '0101P01000', rfidCode: '10101P0100012024010805011XXXXXX0011', supplier: '中兴通讯股份有限公司', remark: '伸缩不顺已修复' },
      { id: '3', name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', qty: 2, produceDate: '2024-06-10', validDate: '2026-06-10', maintainPeriod: '6个月', unit: '个', price: 320, total: 640, equipCode: '0101P02200', rfidCode: '10101P0220012024061005012XXXXXX0012', supplier: '烽火通信科技股份有限公司', remark: '药品过期已更换' },
    ]
  },
]

export default function RepairPage({ onNavigate }: Props) {
  const [repairList, setRepairList] = useState<RepairRecord[]>(repairRecords)
  const [modalOpen, setModalOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<RepairRecord | null>(null)

  // 库存装备弹窗
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: StockMaterial; qty: number }[]>([])

  // 表单
  const [formDescription, setFormDescription] = useState('')
  const [formOperator, setFormOperator] = useState('')
  const [formItems, setFormItems] = useState<RepairItem[]>([])

  const resetForm = () => {
    setFormDescription('')
    setFormOperator('')
    setFormItems([])
  }

  // 库存弹窗操作
  const openStockModal = () => {
    setStockSearchName('')
    setStockSearchCategory('')
    setSelectedStockItems([])
    setStockModalOpen(true)
  }

  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    return true
  })

  const toggleStockSelect = (stock: StockMaterial) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.id === stock.id)
      if (exists) return prev.filter(p => p.stock.id !== stock.id)
      return [...prev, { stock, qty: 1 }]
    })
  }

  const updateSelectedQty = (stockId: string, newQty: number) => {
    const stock = stockMaterials.find(s => s.id === stockId)
    if (stock && newQty > stock.qty) { alert('申请数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.id === stockId ? { ...p, qty: Math.max(1, newQty) } : p))
  }

  const confirmStockItems = () => {
    const newItems: RepairItem[] = selectedStockItems.map(s => ({
      id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
      name: s.stock.name, category: s.stock.category, spec: s.stock.spec,
      qty: s.qty, produceDate: s.stock.produceDate, validDate: s.stock.validDate,
      maintainPeriod: s.stock.maintainPeriod, unit: s.stock.unit,
      price: s.stock.price, total: s.stock.price * s.qty,
      equipCode: s.stock.equipCode, rfidCode: s.stock.rfidCode,
      supplier: s.stock.supplier, remark: s.stock.remark,
    }))
    setFormItems(prev => [...prev, ...newItems])
    setStockModalOpen(false)
    setSelectedStockItems([])
  }

  const removeItem = (idx: number) => setFormItems(prev => prev.filter((_, i) => i !== idx))
  const updateItemQty = (idx: number, newQty: number) => {
    setFormItems(prev => prev.map((item, i) => i !== idx ? item : { ...item, qty: newQty, total: newQty * item.price }))
  }

  const validateForm = () => {
    if (!formDescription) { alert('请填写报修说明'); return false }
    if (formItems.length === 0) { alert('请至少添加一件物资'); return false }
    if (formItems.some(i => !i.name || !i.qty)) { alert('请完善物资明细'); return false }
    return true
  }

  const handleSaveDraft = () => {
    if (!formDescription) { alert('请填写报修说明'); return }
    const newId = `BX2024${String(repairList.length + 1).padStart(3, '0')}`
    const record: RepairRecord = {
      id: newId, description: formDescription, operator: formOperator || '当前用户',
      items: formItems.map(i => ({ ...i, total: i.qty * i.price })),
      status: 'draft', reportTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    setRepairList(prev => [record, ...prev])
    setModalOpen(false)
    resetForm()
    alert('已保存为草稿')
  }

  const handleSubmit = () => {
    if (!validateForm()) return
    const newId = `BX2024${String(repairList.length + 1).padStart(3, '0')}`
    const record: RepairRecord = {
      id: newId, description: formDescription, operator: formOperator || '当前用户',
      items: formItems.map(i => ({ ...i, total: i.qty * i.price })),
      status: 'submitted', reportTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    setRepairList(prev => [record, ...prev])
    setModalOpen(false)
    resetForm()
    alert('提交成功')
  }

  const handleDelete = (r: RepairRecord) => { setRepairList(prev => prev.filter(x => x.id !== r.id)); alert('删除成功') }
  const handleWithdraw = (r: RepairRecord) => { setRepairList(prev => prev.map(x => x.id === r.id ? { ...x, status: 'draft' as RepairStatus } : x)); alert('已撤回为草稿') }

  const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))

  // 操作按钮
  const renderActions = (r: RepairRecord) => {
    const buttons: any[] = []
    buttons.push(<button key="detail" className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedRecord(r); setDetailOpen(true) }}>详情</button>)
    if (r.status === 'draft') {
      buttons.push(<button key="del" className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => { if (confirm(`删除 ${r.id}？`)) handleDelete(r) }}>删除</button>)
    }
    if (r.status === 'submitted') {
      buttons.push(<button key="withdraw" className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => handleWithdraw(r)}>撤回</button>)
    }
    // approval1 / pending_out / repairing / repair_completed 仅查看
    return <div className="flex items-center gap-2 flex-wrap">{buttons}</div>
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>报修管理</span>
      </div>

      {/* 操作按钮（去掉统计卡片） */}
      <div className="flex items-center justify-between">
        <button className="btn-primary flex items-center gap-1" onClick={() => { resetForm(); setModalOpen(true) }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          发起报修
        </button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {repairList.length} 条记录</span>
      </div>

      {/* 搜索 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报修单号</label><input className="form-input w-36" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label><input className="form-input w-28" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option>{Object.entries(statusMap).map(([k, v]) => <option key={k}>{v.label}</option>)}</select></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* 数据表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>报修单号</th>
              <th>物资清单</th>
              <th>报修说明</th>
              <th>经办人</th>
              <th>申请时间</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {repairList.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td>
                  <div className="flex flex-col gap-0.5">
                    {r.items.slice(0, 2).map((item, i) => (
                      <span key={i} className="text-xs truncate max-w-[180px]">{item.name} x{item.qty}</span>
                    ))}
                    {r.items.length > 2 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>+{r.items.length - 2} 种</span>}
                  </div>
                </td>
                <td className="text-xs max-w-[200px] truncate">{r.description}</td>
                <td className="text-xs">{r.operator}</td>
                <td className="text-xs">{r.reportTime}</td>
                <td><span className={`tag text-xs ${statusMap[r.status].tag}`}>{statusMap[r.status].label}</span></td>
                <td>{renderActions(r)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== 发起报修弹窗 ===== */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1100px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">发起报修</h3>
              <button onClick={() => setModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* 基本信息 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#52c41a' }}>基本信息</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报修单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={`BX2024${String(repairList.length + 1).padStart(3, '0')}`} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报修说明 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入报修说明" value={formDescription} onChange={e => setFormDescription(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full" placeholder="请输入经办人" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
                  </div>
                </div>
              </div>

              {/* 物资明细 */}
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细 <span className="text-red-400">*</span> <span style={{ color: 'var(--text-secondary)' }}>({formItems.length} 种)</span></h4>
                  <button onClick={openStockModal} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 添加物资</button>
                </div>

                {formItems.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>#</th>
                          <th className="border p-2 w-28" style={{ borderColor: 'var(--border-color)' }}>物资名称 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>物资类别(二级) <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>规格型号 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-12" style={{ borderColor: 'var(--border-color)' }}>数量 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-18" style={{ borderColor: 'var(--border-color)' }}>生产日期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-18" style={{ borderColor: 'var(--border-color)' }}>有效期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>保养期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-14" style={{ borderColor: 'var(--border-color)' }}>单位 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>单价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>总价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-22" style={{ borderColor: 'var(--border-color)' }}>装备编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-24" style={{ borderColor: 'var(--border-color)' }}>RFID编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20" style={{ borderColor: 'var(--border-color)' }}>供应商 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                          <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formItems.map((item, idx) => (
                          <tr key={item.id}>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.name}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.category || '-'}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{item.spec || '-'}</td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.qty} onChange={e => updateItemQty(idx, Number(e.target.value))} /></td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.produceDate || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.validDate || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.maintainPeriod || '-'}</td>
                            <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{item.unit}</td>
                            <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{item.price?.toLocaleString()}</td>
                            <td className="border p-2 text-right font-mono font-medium" style={{ borderColor: 'var(--border-color)' }}>¥{item.total.toLocaleString()}</td>
                            <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.equipCode || '-'}</td>
                            <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.rfidCode || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.supplier || '-'}</td>
                            <td className="border p-2 text-xs" style={{ borderColor: 'var(--border-color)' }}>{item.remark || '-'}</td>
                            <td className="border p-1 text-center" style={{ borderColor: 'var(--border-color)' }}>
                              <button onClick={() => removeItem(idx)} className="text-red-400 hover:text-red-600">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {formItems.length > 0 && (
                  <div className="mt-3 flex items-center justify-end gap-4">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合计品种：{formItems.length} 种</span>
                    <span className="text-sm font-mono font-bold">合计金额：¥{formItems.reduce((s, m) => s + m.total, 0).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setModalOpen(false)}>取消</button>
              <button className="btn-default" onClick={handleSaveDraft}>保存草稿</button>
              <button className="btn-primary" onClick={handleSubmit}>提交</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备选择弹窗 ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[100dvh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* 搜索 */}
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label><input className="form-input w-28" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label><select className="form-input w-28" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}><option value="">全部</option>{categoryOptions.map(c => <option key={c}>{c}</option>)}</select></div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchName(''); setStockSearchCategory('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            {/* 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" disabled /></th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资名称</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>生产日期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>有效期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>保养期</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>剩余数量</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单位</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>单价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>总价</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>RFID编码</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>供应商</th>
                      <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.id === s.id)
                      return (
                        <tr key={s.id} className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`} onClick={() => toggleStockSelect(s)}>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" checked={isSelected} readOnly /></td>
                          <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{s.name}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.category}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.spec || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.produceDate || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.validDate || '-'}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.maintainPeriod || '-'}</td>
                          <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{s.qty}</td>
                          <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}>{s.unit}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono" style={{ borderColor: 'var(--border-color)' }}>¥{s.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{s.equipCode}</td>
                          <td className="border p-2 font-mono text-xs" style={{ borderColor: 'var(--border-color)' }}>{s.rfidCode}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.supplier}</td>
                          <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{s.remark || '-'}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && <tr><td colSpan={15} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>}
                  </tbody>
                </table>
              </div>

              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>已选择装备 ({selectedStockItems.length})</div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}><p className="text-xs">请点击左侧装备添加</p></div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.id} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>余量: {s.stock.qty}</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.id, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.id !== s.stock.id))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情抽屉 ===== */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative w-[520px] bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="font-semibold text-base">报修详情</h3>
              <button className="p-1 rounded hover:bg-gray-100" onClick={() => setDetailOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息</h4>
                <div className="space-y-2">
                  {[
                    { label: '报修单号', value: selectedRecord.id },
                    { label: '报修说明', value: selectedRecord.description },
                    { label: '经办人', value: selectedRecord.operator },
                    { label: '申请时间', value: selectedRecord.reportTime },
                    { label: '状态', value: statusMap[selectedRecord.status].label },
                  ].map(f => (
                    <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium text-sm">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>物资明细（{selectedRecord.items.length} 种）</h4>
                {selectedRecord.items.map((m, i) => (
                  <div key={m.id} className="border rounded-lg p-3 mb-2" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="text-xs font-medium mb-2">#{i + 1} {m.name}</div>
                    <div className="grid grid-cols-2 gap-y-1 gap-x-4 text-xs">
                      <span style={{ color: 'var(--text-secondary)' }}>物资类别：<span className="text-gray-900">{m.category || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>规格型号：<span className="text-gray-900">{m.spec || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>数量：<span className="text-gray-900">{m.qty} {m.unit}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>生产日期：<span className="text-gray-900">{m.produceDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>有效期：<span className="text-gray-900">{m.validDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>保养期：<span className="text-gray-900">{m.maintainPeriod || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>单价：<span className="text-gray-900 font-mono">¥{m.price?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>总价：<span className="text-gray-900 font-mono font-medium">¥{m.total?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>装备编码：<span className="text-gray-900 font-mono">{m.equipCode || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>RFID编码：<span className="text-gray-900 font-mono">{m.rfidCode || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>供应商：<span className="text-gray-900">{m.supplier || '-'}</span></span>
                      {m.remark && <span className="col-span-2" style={{ color: 'var(--text-secondary)' }}>备注：<span className="text-gray-900">{m.remark}</span></span>}
                    </div>
                  </div>
                ))}
                <div className="text-right text-sm font-mono font-bold mt-2">
                  合计金额：¥{selectedRecord.items.reduce((s, m) => s + m.total, 0).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="p-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
