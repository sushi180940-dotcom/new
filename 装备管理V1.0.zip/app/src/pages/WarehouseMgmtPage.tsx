import { useState, useEffect } from 'react'

// Sub-pages
import InventoryPage from './InventoryPage'
import StockStatsPage from './StockStatsPage'
import InboundPage from './InboundPage'
import OutboundPage from './OutboundPage'
import SafetyStockPage from './SafetyStockPage'
import RoomConfigPage from './RoomConfigPage'
import InventoryCheckPage from './InventoryCheckPage'
import TagManagement from '../components/TagManagement'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
  activeSubTab?: string
}

type SubModule = 'inventory' | 'stats' | 'inbound' | 'outbound' | 'safety-stock' | 'room-config' | 'tag-mgmt' | 'check' | 'records'

const navItems: { key: SubModule; label: string; icon: string }[] = [
  { key: 'stats', label: '库存统计', icon: 'M3 3h18v18H3V3zm16 16V5H5v14h14zM7 7h4v4H7V7zm0 6h4v4H7v-4zm6-6h4v4h-4V7zm0 6h4v4h-4v-4z' },
  { key: 'inbound', label: '入库管理', icon: 'M12 5v14M5 12l7-7 7 7M3 12h18' },
  { key: 'outbound', label: '出库管理', icon: 'M12 5v14M5 12l7 7 7-7M3 12h18' },
  { key: 'inventory', label: '台账管理', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
  { key: 'check', label: '装备盘点', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
  { key: 'safety-stock', label: '安全库存', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z' },
  { key: 'room-config', label: '仓库配置', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' },
  { key: 'tag-mgmt', label: '标签管理', icon: 'M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82zM7 7h.01' },
  { key: 'records', label: '出入库记录', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
]

function InOutRecordsPage() {
  const [records] = useState<InOutRecord[]>(recordsData)
  const [searchId, setSearchId] = useState('')
  const [searchRfid, setSearchRfid] = useState('')
  const [filterType, setFilterType] = useState('all')
  const [filterLegal, setFilterLegal] = useState('all')
  const [filterDate, setFilterDate] = useState('')

  const today = '2024-03-15'
  const todayIn = records.filter(r => r.type === 'in' && r.time.startsWith(today)).length
  const todayOut = records.filter(r => r.type === 'out' && r.time.startsWith(today)).length
  const legalCount = records.filter(r => r.isLegal).length
  const illegalCount = records.filter(r => !r.isLegal).length

  const filtered = records.filter(r => {
    if (searchId && !r.id.toLowerCase().includes(searchId.toLowerCase())) return false
    if (searchRfid && !r.rfidCode.includes(searchRfid)) return false
    if (filterType !== 'all' && r.type !== filterType) return false
    if (filterLegal !== 'all') {
      if (filterLegal === 'legal' && !r.isLegal) return false
      if (filterLegal === 'illegal' && r.isLegal) return false
    }
    if (filterDate && !r.time.startsWith(filterDate)) return false
    return true
  })

  return (
    <div className="space-y-4">
      {/* Search */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>记录编号</label><input className="form-input w-28" placeholder="请输入" value={searchId} onChange={e => setSearchId(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>RFID编码</label><input className="form-input w-32" placeholder="请输入RFID编码" value={searchRfid} onChange={e => setSearchRfid(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作类型</label><select className="form-input w-24" value={filterType} onChange={e => setFilterType(e.target.value)}><option value="all">全部</option><option value="in">入库</option><option value="out">出库</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合法性标志</label><select className="form-input w-24" value={filterLegal} onChange={e => setFilterLegal(e.target.value)}><option value="all">全部</option><option value="legal">合法</option><option value="illegal">非法</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发生日期</label><input className="form-input w-28" type="date" value={filterDate} onChange={e => setFilterDate(e.target.value)} /></div>
          <div className="flex gap-2 ml-auto"><button className="btn-default" onClick={() => { setSearchId(''); setSearchRfid(''); setFilterType('all'); setFilterLegal('all'); setFilterDate('') }}>重置</button><button className="btn-primary">查询</button></div>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="content-card p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M12 5v14M5 12l7-7 7 7"/></svg>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>今日入库</span>
          </div>
          <p className="text-2xl font-bold" style={{ color: '#52c41a' }}>{todayIn}</p>
        </div>
        <div className="content-card p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>今日出库</span>
          </div>
          <p className="text-2xl font-bold" style={{ color: '#ff4d4f' }}>{todayOut}</p>
        </div>
        <div className="content-card p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合法记录</span>
          </div>
          <p className="text-2xl font-bold" style={{ color: '#52c41a' }}>{legalCount}</p>
        </div>
        <div className="content-card p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>非法记录</span>
          </div>
          <p className="text-2xl font-bold" style={{ color: '#ff4d4f' }}>{illegalCount}</p>
        </div>
      </div>

      {/* Table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox" /></th>
              <th>记录编号</th>
              <th>RFID编码</th>
              <th>装备名称</th>
              <th>操作类型</th>
              <th>发生时间</th>
              <th>通道ID/操作人</th>
              <th>通道类型</th>
              <th>合法性</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={10} className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
            {filtered.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox" /></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td className="font-mono text-xs">{r.rfidCode}</td>
                <td>{r.name}</td>
                <td><span className={`tag text-xs ${r.type === 'in' ? 'tag-green' : 'tag-red'}`}>{r.type === 'in' ? '入库' : '出库'}</span></td>
                <td className="text-xs">{r.time}</td>
                <td className="text-xs">{r.channelId}{r.operator ? ` - ${r.operator}` : ''}</td>
                <td><span className="tag tag-gray text-xs">{r.channelType}</span></td>
                <td><span className={`tag text-xs ${r.isLegal ? 'tag-green' : 'tag-red'}`}>{r.isLegal ? '合法' : '非法'}</span></td>
                <td><button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>详情</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}


export default function WarehouseMgmtPage({ onNavigate, activeSubTab }: Props) {
  const [activeSub, setActiveSub] = useState<SubModule>('stats')

  useEffect(() => {
    if (activeSubTab) {
      const validSubs: SubModule[] = ['inventory', 'stats', 'inbound', 'outbound', 'safety-stock', 'room-config', 'tag-mgmt', 'check', 'records']
      if (validSubs.includes(activeSubTab as SubModule)) {
        setActiveSub(activeSubTab as SubModule)
      }
    }
  }, [activeSubTab])

  const renderContent = () => {
    switch (activeSub) {
      case 'stats': return <StockStatsPage onNavigate={onNavigate} />
      case 'inventory': return <InventoryPage onNavigate={onNavigate} />
      case 'inbound': return <InboundPage onNavigate={onNavigate} />
      case 'outbound': return <OutboundPage onNavigate={onNavigate} />
      case 'safety-stock': return <SafetyStockPage onNavigate={onNavigate} />
      case 'room-config': return <RoomConfigPage onNavigate={onNavigate} />
      case 'tag-mgmt': return <TagManagement />
      case 'check': return <InventoryCheckPage onNavigate={onNavigate} />
      case 'records': return <InOutRecordsPage />
      default: return <StockStatsPage onNavigate={onNavigate} />
    }
  }

  return (
    <div className="h-full flex">
      {/* Left nav */}
      <aside className="w-48 border-r flex-shrink-0 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
        <div className="p-3 space-y-1">
          {navItems.map(item => (
            <button
              key={item.key}
              onClick={() => setActiveSub(item.key)}
              className={`flex items-center gap-2 w-full px-3 py-2.5 rounded-lg text-sm transition-all ${activeSub === item.key ? 'font-medium' : 'hover:bg-gray-50'}`}
              style={{
                color: activeSub === item.key ? 'var(--primary-blue)' : 'var(--text-secondary)',
                background: activeSub === item.key ? 'rgba(24, 144, 255, 0.06)' : 'transparent',
              }}
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d={item.icon} />
              </svg>
              <span className="whitespace-nowrap">{item.label}</span>
            </button>
          ))}
        </div>
      </aside>

      {/* Content */}
      <main className="flex-1 overflow-y-auto p-6">
        {renderContent()}
      </main>
    </div>
  )
}


/* ================================================================
   In/Out Records Page - 出入库记录
   ================================================================ */

interface InOutRecord {
  id: string
  rfidCode: string
  name: string
  spec: string
  type: 'in' | 'out'
  time: string
  channelId: string
  channelType: '智能通道' | '人工'
  detectType: '智能感知' | '人工操作'
  isLegal: boolean
  operator?: string
}

const recordsData: InOutRecord[] = [
  { id: 'CR2024001', rfidCode: '10101P00100...', name: '手持终端XT-2000', spec: 'XT-2000/黑色', type: 'in', time: '2024-03-15 08:23:15', channelId: 'A栋主通道-01', channelType: '智能通道', detectType: '智能感知', isLegal: true },
  { id: 'CR2024002', rfidCode: '10101P00200...', name: '执法记录仪DSJ-A7', spec: 'DSJ-A7/64G', type: 'out', time: '2024-03-15 07:45:30', channelId: 'A栋主通道-01', channelType: '智能通道', detectType: '智能感知', isLegal: true },
  { id: 'CR2024003', rfidCode: '10101P00300...', name: '防弹背心FDY-3R', spec: 'FDY-3R/三级', type: 'out', time: '2024-03-14 23:12:05', channelId: 'B栋侧门-02', channelType: '智能通道', detectType: '智能感知', isLegal: false },
  { id: 'CR2024004', rfidCode: '10101P00500...', name: '对讲机PD780G', spec: 'PD780G/U段', type: 'in', time: '2024-03-14 18:30:22', channelId: 'A栋主通道-01', channelType: '人工', detectType: '人工操作', isLegal: true, operator: '张三' },
  { id: 'CR2024005', rfidCode: '10101P00400...', name: '战术头盔MICH-2000', spec: 'MICH-2000/L号', type: 'out', time: '2024-03-14 14:15:10', channelId: 'A栋主通道-01', channelType: '智能通道', detectType: '智能感知', isLegal: true },
  { id: 'CR2024006', rfidCode: '10101P00100...', name: '手持终端XT-2000', spec: 'XT-2000/黑色', type: 'out', time: '2024-03-14 09:00:45', channelId: 'B栋侧门-02', channelType: '人工', detectType: '人工操作', isLegal: true, operator: '李四' },
  { id: 'CR2024007', rfidCode: '10101P00200...', name: '执法记录仪DSJ-A7', spec: 'DSJ-A7/64G', type: 'in', time: '2024-03-13 20:45:18', channelId: 'A栋主通道-01', channelType: '智能通道', detectType: '智能感知', isLegal: false },
  { id: 'CR2024008', rfidCode: '10101P00500...', name: '对讲机PD780G', spec: 'PD780G/U段', type: 'out', time: '2024-03-13 16:20:33', channelId: 'B栋侧门-02', channelType: '智能通道', detectType: '智能感知', isLegal: true },
  { id: 'CR2024009', rfidCode: '10101P00300...', name: '防弹背心FDY-3R', spec: 'FDY-3R/三级', type: 'in', time: '2024-03-13 12:10:50', channelId: 'A栋主通道-01', channelType: '人工', detectType: '人工操作', isLegal: true, operator: '王五' },
  { id: 'CR2024010', rfidCode: '10101P00100...', name: '手持终端XT-2000', spec: 'XT-2000/黑色', type: 'in', time: '2024-03-13 08:55:42', channelId: 'A栋主通道-01', channelType: '智能通道', detectType: '智能感知', isLegal: true },
]
