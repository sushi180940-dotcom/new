import { useState, useMemo } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type CheckStatus = 'pending' | 'checking' | 'submitted' | 'approving' | 'approved' | 'rejected'
type CheckCycle = 'monthly' | 'quarterly' | 'yearly'

interface CheckItem {
  equipCode: string      // 装备编码
  equipName: string      // 物资名称
  category: string       // 物资类别
  unit: string           // 单位
  spec: string           // 规格型号
  rfid: string           // RFID编码
  bookQty: number        // 数量
  actualQty: number | null  // 盘点数量
  diffQty: number | null    // 盈亏数量
  checkStatus: string    // 盘点状态
  stockStatus: string    // 库存状态
  adjustStock: boolean   // 是否修改库存
  remark: string         // 备注
  warehouse: string      // 所属仓库
  location: string       // 存放位置
  produceDate: string    // 生产日期
  validDate: string      // 有效期
  maintainPeriod: string // 保养期
  unitPrice: number      // 单价
  supplier: string       // 供应商
  rfidList?: string[]    // RFID展开列表（数量>1时使用）
}

interface CheckTask {
  id: string
  name: string
  scope: string
  cycle: CheckCycle
  status: CheckStatus
  checker: string
  creator: string
  createTime: string
  startTime: string | null
  submitTime: string | null
  approveTime: string | null
  items: CheckItem[]
  remark: string
}

const cycleLabels: Record<CheckCycle, string> = {
  monthly: '月度盘点',
  quarterly: '季度盘点',
  yearly: '年度盘点',
}

const statusMap: Record<CheckStatus, { label: string; tag: string; color: string }> = {
  pending: { label: '待盘点', tag: 'tag-yellow', color: '#faad14' },
  checking: { label: '盘点中', tag: 'tag-blue', color: '#1890ff' },
  submitted: { label: '待确认', tag: 'tag-orange', color: '#fa8c16' },
  approving: { label: '审批中', tag: 'tag-purple', color: '#722ed1' },
  approved: { label: '已调整', tag: 'tag-green', color: '#52c41a' },
  rejected: { label: '已驳回', tag: 'tag-red', color: '#ff4d4f' },
}

const flowSteps = [
  { key: 'create', label: '创建任务' },
  { key: 'check', label: '执行盘点' },
  { key: 'submit', label: '提交结果' },
  { key: 'approve', label: '差异审批' },
  { key: 'adjust', label: '调整库存' },
]

const initialItems: CheckItem[] = [
  { equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', category: '通信设备', unit: '台', spec: 'XT-2000/黑色/128G', rfid: 'RFID0010001', bookQty: 86, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'A区-01货架' },
  { equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', category: '记录设备', unit: '台', spec: 'DSJ-A7/64G/高清', rfid: 'RFID0010002', bookQty: 52, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'A区-02货架' },
  { equipCode: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', category: '防护装备', unit: '件', spec: 'FDY-3R/三级/L', rfid: 'RFID0010003', bookQty: 35, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'B区-01货架' },
  { equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', equipName: '对讲机 PD780G', category: '通信设备', unit: '台', spec: 'PD780G/U段', rfid: 'RFID0010005', bookQty: 120, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'A区-03货架' },
  { equipCode: '1-0-1-01-P007-001-20240310-05-007XXXXXX-0006', equipName: '强光手电 QG-500', category: '照明设备', unit: '支', spec: 'QG-500/充电款', rfid: 'RFID0010006', bookQty: 200, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'C区-01货架' },
  { equipCode: '1-0-1-01-P008-001-20240120-10-008XXXXXX-0007', equipName: '应急照明灯 YD-100', category: '照明设备', unit: '台', spec: 'YD-100/LED', rfid: 'RFID0010007', bookQty: 65, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'C区-02货架' },
  { equipCode: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', equipName: '战术头盔 MICH-2000', category: '防护装备', unit: '顶', spec: 'MICH-2000/L号', rfid: 'RFID0010004', bookQty: 48, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'B区-02货架' },
  { equipCode: '1-0-1-01-P006-001-20240220-10-006XXXXXX-0004', equipName: '防弹盾牌 FDP-3S', category: '防护装备', unit: '面', spec: 'FDP-3S/手持型', rfid: 'RFID0010008', bookQty: 18, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '省厅主仓库', location: 'B区-03货架' },
]

const warehouseItems: Record<string, CheckItem[]> = {
  '省厅主仓库': initialItems,
  '市局限装备仓库': [
    { equipCode: '2-0-1-02-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', category: '通信设备', unit: '台', spec: 'XT-2000/黑色/128G', rfid: 'RFID0020001', bookQty: 42, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '市局限装备仓库', location: '1号库-A架' },
    { equipCode: '2-0-1-02-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', category: '记录设备', unit: '台', spec: 'DSJ-A7/64G/高清', rfid: 'RFID0020002', bookQty: 28, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '市局限装备仓库', location: '1号库-B架' },
    { equipCode: '2-0-1-02-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', category: '防护装备', unit: '件', spec: 'FDY-3R/三级/L', rfid: 'RFID0020003', bookQty: 56, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '市局限装备仓库', location: '2号库-A架' },
    { equipCode: '2-0-1-02-P004-001-20240305-05-005XXXXXX-0005', equipName: '对讲机 PD780G', category: '通信设备', unit: '台', spec: 'PD780G/U段', rfid: 'RFID0020004', bookQty: 75, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '市局限装备仓库', location: '1号库-C架' },
    { equipCode: '2-0-1-02-P005-001-20240310-05-007XXXXXX-0006', equipName: '强光手电 QG-500', category: '照明设备', unit: '支', spec: 'QG-500/充电款', rfid: 'RFID0020005', bookQty: 130, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: '市局限装备仓库', location: '3号库-A架' },
  ],
  'A区县级装备库': [
    { equipCode: '3-0-1-03-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', category: '通信设备', unit: '台', spec: 'XT-2000/黑色/128G', rfid: 'RFID0030001', bookQty: 15, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'A区县级装备库', location: '主库-01架' },
    { equipCode: '3-0-1-03-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', category: '记录设备', unit: '台', spec: 'DSJ-A7/64G/高清', rfid: 'RFID0030002', bookQty: 20, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'A区县级装备库', location: '主库-02架' },
    { equipCode: '3-0-1-03-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', category: '防护装备', unit: '件', spec: 'FDY-3R/三级/L', rfid: 'RFID0030003', bookQty: 12, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'A区县级装备库', location: '主库-03架' },
  ],
  'B区县级装备库': [
    { equipCode: '4-0-1-04-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', category: '通信设备', unit: '台', spec: 'XT-2000/黑色/128G', rfid: 'RFID0040001', bookQty: 10, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'B区县级装备库', location: '东区-01柜' },
    { equipCode: '4-0-1-04-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', category: '记录设备', unit: '台', spec: 'DSJ-A7/64G/高清', rfid: 'RFID0040002', bookQty: 18, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'B区县级装备库', location: '东区-02柜' },
    { equipCode: '4-0-1-04-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', category: '防护装备', unit: '件', spec: 'FDY-3R/三级/L', rfid: 'RFID0040003', bookQty: 8, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'B区县级装备库', location: '西区-01柜' },
  ],
  'C区县级装备室': [
    { equipCode: '5-0-1-05-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', category: '通信设备', unit: '台', spec: 'XT-2000/黑色/128G', rfid: 'RFID0050001', bookQty: 6, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'C区县级装备室', location: 'A柜-01层' },
    { equipCode: '5-0-1-05-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', category: '记录设备', unit: '台', spec: 'DSJ-A7/64G/高清', rfid: 'RFID0050002', bookQty: 12, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'C区县级装备室', location: 'A柜-02层' },
    { equipCode: '5-0-1-05-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', category: '防护装备', unit: '件', spec: 'FDY-3R/三级/L', rfid: 'RFID0050003', bookQty: 5, actualQty: null, diffQty: null, checkStatus: '待盘点', stockStatus: '正常', adjustStock: false, remark: '', produceDate: '2023-06', validDate: '2028-06', maintainPeriod: '12个月', unitPrice: 0, supplier: '', warehouse: 'C区县级装备室', location: 'B柜-01层' },
  ],
}

const initialTasks: CheckTask[] = [
  {
    id: 'PD2024001', name: '2024年3月度装备盘点', scope: '省厅主仓库全部装备', cycle: 'monthly',
    status: 'approved', checker: '张三', creator: 'admin', createTime: '2024-03-25 09:00:00',
    startTime: '2024-03-26 08:30:00', submitTime: '2024-03-26 16:00:00', approveTime: '2024-03-27 10:00:00',
    items: [
      { ...initialItems[0], actualQty: 84, diffQty: -2, checkStatus: '盘亏', adjustStock: true, remark: '2台待修转出未登记' },
      { ...initialItems[1], actualQty: 52, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[2], actualQty: 35, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[3], actualQty: 118, diffQty: -2, checkStatus: '盘亏', adjustStock: true, remark: '2台调拨至交警支队' },
      { ...initialItems[4], actualQty: 200, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[5], actualQty: 63, diffQty: -2, checkStatus: '盘亏', adjustStock: true, remark: '2台报废未登记' },
      { ...initialItems[6], actualQty: 48, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[7], actualQty: 18, diffQty: 0, checkStatus: '正常' },
    ],
    remark: '3月度例行盘点，发现4件装备盘亏，已审批调整库存',
  },
  {
    id: 'PD2024002', name: '2024年Q1季度装备盘点', scope: '省厅主仓库+市局限装备仓库', cycle: 'quarterly',
    status: 'submitted', checker: '李四', creator: 'admin', createTime: '2024-03-28 14:00:00',
    startTime: '2024-03-29 09:00:00', submitTime: '2024-03-29 17:30:00', approveTime: null,
    items: [
      { ...initialItems[0], actualQty: 86, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[1], actualQty: 50, diffQty: -2, checkStatus: '盘亏', remark: '2台报修中' },
      { ...initialItems[2], actualQty: 36, diffQty: 1, checkStatus: '盘盈', remark: '退回入库未登记' },
      { ...initialItems[3], actualQty: 120, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[4], actualQty: 198, diffQty: -2, checkStatus: '盘亏', remark: '2支损坏待报废' },
      { ...initialItems[5], actualQty: 65, diffQty: 0, checkStatus: '正常' },
      { ...initialItems[6], actualQty: 47, diffQty: -1, checkStatus: '盘亏', remark: '1顶维修中' },
      { ...initialItems[7], actualQty: 19, diffQty: 1, checkStatus: '盘盈', remark: '调拨入库未登记' },
    ],
    remark: 'Q1季度盘点，部分装备存在差异，等待审批',
  },
  {
    id: 'PD2024003', name: '2024年4月度装备盘点', scope: '省厅主仓库全部装备', cycle: 'monthly',
    status: 'checking', checker: '王五', creator: 'admin', createTime: '2024-04-26 09:00:00',
    startTime: '2024-04-27 08:00:00', submitTime: null, approveTime: null,
    items: initialItems.map(i => ({ ...i })),
    remark: '4月度例行盘点，正在进行中',
  },
  {
    id: 'PD2024004', name: '2024年5月度装备盘点', scope: '省厅主仓库全部装备', cycle: 'monthly',
    status: 'pending', checker: '赵六', creator: 'admin', createTime: '2024-05-26 09:00:00',
    startTime: null, submitTime: null, approveTime: null,
    items: initialItems.map(i => ({ ...i })),
    remark: '5月度例行盘点，等待执行',
  },
]

function getStepStatus(task: CheckTask, stepKey: string): 'done' | 'current' | 'pending' {
  const statusOrder: CheckStatus[] = ['pending', 'checking', 'submitted', 'approving', 'approved']
  const idx = statusOrder.indexOf(task.status)
  if (task.status === 'rejected') {
    if (stepKey === 'create' || stepKey === 'check' || stepKey === 'submit') return 'done'
    if (stepKey === 'approve') return 'current'
    return 'pending'
  }
  const stepIdx = flowSteps.findIndex(s => s.key === stepKey)
  if (stepIdx <= idx) return 'done'
  if (stepIdx === idx + 1) return 'current'
  return 'pending'
}

export default function InventoryCheckPage({ onNavigate }: Props) {
  const [tasks, setTasks] = useState<CheckTask[]>(initialTasks)
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [filterCycle, setFilterCycle] = useState<string>('all')
  const [searchKw, setSearchKw] = useState('')

  // Modals
  const [createOpen, setCreateOpen] = useState(false)
  const [checkOpen, setCheckOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedTask, setSelectedTask] = useState<CheckTask | null>(null)

  // Detail mode: 'view' | 'approve'
  const [detailMode, setDetailMode] = useState<'view' | 'approve'>('view')

  // Surplus / Deficit expand state
  const [surplusExpanded, setSurplusExpanded] = useState(false)
  const [deficitExpanded, setDeficitExpanded] = useState(false)

  // Create form
  const [formId, setFormId] = useState('')
  const [formOperator, setFormOperator] = useState('')
  const [formDept, setFormDept] = useState('')
  const [formType, setFormType] = useState<'initial' | 'inventory' | 'final'>('inventory')
  const [formWarehouse, setFormWarehouse] = useState('')
  const [formDate, setFormDate] = useState('')
  const [formItems, setFormItems] = useState<CheckItem[]>([])
  const [formSelectedItems, setFormSelectedItems] = useState<string[]>([])

  const typeLabels: Record<string, string> = { initial: '期初盘点', inventory: '存货盘点', final: '期末盘点' }

  const filtered = tasks.filter(t => {
    if (filterStatus !== 'all' && t.status !== filterStatus) return false
    if (filterCycle !== 'all' && t.cycle !== filterCycle) return false
    if (searchKw) {
      const kw = searchKw.toLowerCase()
      return t.id.toLowerCase().includes(kw) || t.name.includes(kw) || t.scope.includes(kw) || t.checker.includes(kw)
    }
    return true
  })

  const handleCreate = () => {
    if (!formId || !formOperator || !formDept || !formWarehouse || !formDate) { alert('请填写盘点单号、经办人、经办单位、仓库和盘点时间'); return }
    if (formItems.length === 0) { alert('请至少添加一件装备到盘点明细'); return }
    const typeLabel = typeLabels[formType]
    const scopeLabel = `${formWarehouse}全部装备`
    setTasks(prev => [{
      id: formId, name: `${formDate.slice(0, 7).replace('-', '年')}月${typeLabel}`, scope: scopeLabel, cycle: 'monthly' as CheckCycle, status: 'pending',
      checker: formOperator, creator: '当前用户',
      createTime: `${formDate} 09:00:00`,
      startTime: null, submitTime: null, approveTime: null,
      items: formItems.map(i => ({ ...i, warehouse: formWarehouse })),
      remark: `${typeLabel} · ${formDept}`,
    }, ...prev])
    setCreateOpen(false)
    resetForm()
    alert(`盘点任务 ${formId} 已创建，共 ${formItems.length} 件装备`)
  }

  const resetForm = () => {
    setFormId('')
    setFormOperator('')
    setFormDept('')
    setFormType('inventory')
    setFormWarehouse('')
    setFormDate('')
    setFormItems([])
    setFormSelectedItems([])
  }

  // 装备选择弹窗状态
  const [equipSelectOpen, setEquipSelectOpen] = useState(false)
  const [equipC1, setEquipC1] = useState('全部')
  const [equipC2, setEquipC2] = useState('全部')
  const [equipC3, setEquipC3] = useState('全部')
  const [equipNameSearch, setEquipNameSearch] = useState('')
  const [equipWarehouseFilter, setEquipWarehouseFilter] = useState('全部')
  const [selectedEquips, setSelectedEquips] = useState<{ item: CheckItem; qty: number }[]>([])

  // RFID展开状态
  const [expandedRfids, setExpandedRfids] = useState<Set<string>>(new Set())

  const addFormItem = () => {
    setEquipSelectOpen(true)
    setEquipC1('全部'); setEquipC2('全部'); setEquipC3('全部'); setEquipNameSearch(''); setEquipWarehouseFilter('全部'); setSelectedEquips([])
  }

  const removeFormItems = () => {
    if (formSelectedItems.length === 0) { alert('请先选择要删除的装备'); return }
    setFormItems(prev => prev.filter(i => !formSelectedItems.includes(i.equipCode)))
    setFormSelectedItems([])
  }

  const updateFormItem = (code: string, field: keyof CheckItem, value: any) => {
    setFormItems(prev => prev.map(i => i.equipCode === code ? { ...i, [field]: value } : i))
  }

  const exportFormItems = () => {
    const header = ['物资名称', '物资类别', '规格型号', '数量', '生产日期', '有效期', '保养期', '单位', '单价', '总价', '装备编码', 'RFID编码', '供应商', '备注']
    const rows = formItems.map(i => [
      i.equipName, i.category, i.spec, String(i.bookQty), i.produceDate, i.validDate, i.maintainPeriod,
      i.unit, String(i.unitPrice), String(i.bookQty * i.unitPrice), i.equipCode, i.rfid, i.supplier, i.remark
    ])
    const allRows = [header, ...rows]
    const csv = allRows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `盘点明细_${formId || 'template'}.csv`
    a.click()
  }

  const importFormItems = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      const text = ev.target?.result as string
      if (!text) return
      const lines = text.split('\n').filter(l => l.trim())
      const imported: CheckItem[] = []
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',').map(c => c.replace(/^"|"$/g, '').trim())
        if (cols.length >= 4 && cols[0]) {
          imported.push({
            equipCode: cols[10] || `EQ${String(imported.length + 1).padStart(5, '0')}`,
            equipName: cols[0] || '',
            category: cols[1] || '',
            unit: cols[7] || '件',
            spec: cols[2] || '',
            rfid: cols[11] || '',
            bookQty: Number(cols[3]) || 0,
            actualQty: null,
            diffQty: null,
            checkStatus: '待盘点',
            stockStatus: '正常',
            adjustStock: false,
            remark: cols[13] || '',
            warehouse: formWarehouse,
            location: '',
            produceDate: cols[4] || '',
            validDate: cols[5] || '',
            maintainPeriod: cols[6] || '',
            unitPrice: Number(cols[8]) || 0,
            supplier: cols[12] || '',
          })
        }
      }
      if (imported.length > 0) {
        setFormItems(prev => [...prev, ...imported])
        alert(`成功导入 ${imported.length} 条装备明细`)
      } else {
        alert('未识别到有效数据，请检查文件格式')
      }
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  const handleStartCheck = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? {
      ...t, status: 'checking', startTime: new Date().toLocaleString('zh-CN', { hour12: false })
    } : t))
    alert('盘点已开始，请记录实际数量')
  }

  const handleUpdateActualQty = (taskId: string, equipCode: string, actualQty: number) => {
    setTasks(prev => prev.map(t => t.id === taskId ? {
      ...t, items: t.items.map(i => i.equipCode === equipCode ? {
        ...i, actualQty, diffQty: actualQty - i.bookQty
      } : i)
    } : t))
  }

  const handleSubmitResult = (id: string) => {
    const task = tasks.find(t => t.id === id)
    if (!task) return
    const hasDiff = task.items.some(i => i.actualQty === null)
    if (hasDiff) { alert('请完成所有装备的实际数量录入'); return }
    setTasks(prev => prev.map(t => t.id === id ? {
      ...t, status: 'submitted', submitTime: new Date().toLocaleString('zh-CN', { hour12: false })
    } : t))
    setCheckOpen(false)
    setSelectedTask(null)
    alert('盘点结果已提交，等待审批')
  }

  const handleApprove = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? {
      ...t, status: 'approved', approveTime: new Date().toLocaleString('zh-CN', { hour12: false })
    } : t))
    alert('盘点差异已审批，库存已调整')
  }

  const handleReject = (id: string) => {
    setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'rejected' } : t))
    alert('盘点结果已退回，需重新盘点')
  }

  const openCheckModal = (task: CheckTask) => {
    setSelectedTask(task)
    setCheckOpen(true)
  }

  const openDetailModal = (task: CheckTask) => {
    setSelectedTask(task)
    setDetailOpen(true)
  }

  const openApproveModal = (task: CheckTask) => {
    setDetailMode('approve')
    setSurplusExpanded(false)
    setDeficitExpanded(false)
    setSelectedTask(task)
    setDetailOpen(true)
  }

  const currentTask = selectedTask ? tasks.find(t => t.id === selectedTask.id) || selectedTask : null

  const diffSummary = useMemo(() => {
    if (!currentTask) return { total: 0, surplus: 0, deficit: 0, unchanged: 0 }
    const items = currentTask.items.filter(i => i.actualQty !== null)
    return {
      total: items.length,
      surplus: items.filter(i => (i.diffQty || 0) > 0).length,
      deficit: items.filter(i => (i.diffQty || 0) < 0).length,
      unchanged: items.filter(i => (i.diffQty || 0) === 0).length,
    }
  }, [currentTask])

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm pb-1">
          <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
          </button>
          <span style={{ color: 'var(--text-disabled)' }}>/</span>
          <span style={{ color: 'var(--text-secondary)' }}>装备盘点</span>
        </div>
      </div>

      {/* Action bar */}
      <div className="flex items-center justify-between">
        <button className="btn-primary text-sm flex items-center gap-1" onClick={() => { resetForm(); setCreateOpen(true) }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          创建盘点任务
        </button>
        <div className="flex gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-full border bg-white">待盘点 {tasks.filter(t => t.status === 'pending').length}</span>
          <span className="px-3 py-1.5 rounded-full border bg-white" style={{ color: '#1890ff' }}>盘点中 {tasks.filter(t => t.status === 'checking').length}</span>
          <span className="px-3 py-1.5 rounded-full border bg-white" style={{ color: '#faad14' }}>待确认 {tasks.filter(t => t.status === 'submitted').length}</span>
          <span className="px-3 py-1.5 rounded-full border bg-white" style={{ color: '#52c41a' }}>已完成 {tasks.filter(t => t.status === 'approved').length}</span>
        </div>
      </div>

      {/* Filters */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>盘点状态</label>
            <select className="form-input w-28" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">全部</option>
              <option value="pending">待盘点</option>
              <option value="checking">盘点中</option>
              <option value="submitted">待确认</option>
              <option value="approved">已调整</option>
              <option value="rejected">已驳回</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>盘点周期</label>
            <select className="form-input w-28" value={filterCycle} onChange={e => setFilterCycle(e.target.value)}>
              <option value="all">全部</option>
              <option value="monthly">月度</option>
              <option value="quarterly">季度</option>
              <option value="yearly">年度</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关键词</label>
            <input className="form-input w-40" placeholder="单号/名称/范围" value={searchKw} onChange={e => setSearchKw(e.target.value)} />
          </div>
          <div className="ml-auto flex gap-2">
            <button className="btn-default text-xs" onClick={() => { setFilterStatus('all'); setFilterCycle('all'); setSearchKw('') }}>重置</button>
            <button className="btn-primary text-xs">查询</button>
          </div>
        </div>
      </div>

      {/* Task list table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>盘点单号</th>
              <th>盘点名称</th>
              <th>盘点范围</th>
              <th>盘点周期</th>
              <th>盘点人</th>
              <th>创建时间</th>
              <th>差异数</th>
              <th>处理状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={9} className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无盘点任务</td></tr>}
            {filtered.map(t => {
              const diffCount = t.items.filter(i => i.actualQty !== null && i.diffQty !== 0).length
              return (
                <tr key={t.id}>
                  <td className="font-mono text-xs font-medium">{t.id}</td>
                  <td className="font-medium text-sm">{t.name}</td>
                  <td className="text-xs">{t.scope}</td>
                  <td><span className="tag text-xs" style={{ background: t.cycle === 'monthly' ? '#e6f4ff' : t.cycle === 'quarterly' ? '#f6ffed' : '#fff7e6', color: t.cycle === 'monthly' ? '#1890ff' : t.cycle === 'quarterly' ? '#52c41a' : '#faad14' }}>{cycleLabels[t.cycle]}</span></td>
                  <td>{t.checker}</td>
                  <td className="text-xs">{t.createTime}</td>
                  <td className="font-mono text-xs">{diffCount > 0 ? <span style={{ color: '#ff4d4f' }}>{diffCount}件差异</span> : t.status === 'approved' ? '无差异' : '-'}</td>
                  <td><span className={`tag ${statusMap[t.status].tag} text-xs`}>{statusMap[t.status].label}</span></td>
                  <td>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDetailModal(t)}>查看</button>
                      {t.status === 'pending' && (
                        <button className="text-xs hover:underline" style={{ color: '#1890ff' }} onClick={() => handleStartCheck(t.id)}>开始盘点</button>
                      )}
                      {t.status === 'checking' && (
                        <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openCheckModal(t)}>录入结果</button>
                      )}
                      {t.status === 'submitted' && (
                        <>
                          <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openApproveModal(t)}>通过</button>
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleReject(t.id)}>重新盘点</button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* ===== Create Modal ===== */}
      {createOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCreateOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">创建盘点任务</h3>
              <button onClick={() => setCreateOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {/* Basic info */}
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>盘点单号 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full font-mono text-sm" placeholder="如：PD2024005" value={formId} onChange={e => setFormId(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>盘点时间 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full text-sm" type="date" value={formDate} onChange={e => setFormDate(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>盘点类型 <span className="text-red-400">*</span></label>
                  <select className="form-input w-full text-sm" value={formType} onChange={e => setFormType(e.target.value as 'initial' | 'inventory' | 'final')}>
                    <option value="initial">期初盘点</option>
                    <option value="inventory">存货盘点</option>
                    <option value="final">期末盘点</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full text-sm" placeholder="请输入经办人姓名" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办单位 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full text-sm" placeholder="请输入经办单位" value={formDept} onChange={e => setFormDept(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>仓库 <span className="text-red-400">*</span></label>
                  <select className="form-input w-full text-sm" value={formWarehouse} onChange={e => {
                    const wh = e.target.value
                    setFormWarehouse(wh)
                    if (warehouseItems[wh]) {
                      setFormItems(warehouseItems[wh])
                    } else {
                      setFormItems([])
                    }
                  }}>
                    <option value="">请选择</option>
                    <option>省厅主仓库</option>
                    <option>市局限装备仓库</option>
                    <option>A区县级装备库</option>
                    <option>B区县级装备库</option>
                    <option>C区县级装备室</option>
                  </select>
                </div>
              </div>

              {/* Equipment detail list */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-sm font-semibold">装备盘点明细 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（共 {formItems.length} 件）</span></h4>
                  <div className="flex gap-2">
                    <button className="btn-default text-xs flex items-center gap-1 px-2 py-1" onClick={exportFormItems}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                      导出
                    </button>
                    <label className="btn-default text-xs flex items-center gap-1 px-2 py-1 cursor-pointer">
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      导入
                      <input type="file" accept=".csv,.xls,.xlsx" className="hidden" onChange={importFormItems} />
                    </label>
                    {formSelectedItems.length > 0 && (
                      <button className="btn-danger text-xs flex items-center gap-1 px-2 py-1" onClick={removeFormItems}>
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                        删除 ({formSelectedItems.length})
                      </button>
                    )}
                    <button className="btn-primary text-xs flex items-center gap-1 px-2 py-1" onClick={addFormItem}>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      新增
                    </button>
                  </div>
                </div>
                <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="max-h-[320px] overflow-y-auto">
                    <table className="w-full text-xs">
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="p-2 text-left w-6"><input type="checkbox" checked={formSelectedItems.length > 0 && formSelectedItems.length === formItems.length} onChange={() => setFormSelectedItems(formSelectedItems.length === formItems.length ? [] : formItems.map(i => i.equipCode))} /></th>
                          <th className="p-2 text-left w-20">物资名称</th>
                          <th className="p-2 text-left w-14">物资类别</th>
                          <th className="p-2 text-left w-16">规格型号</th>
                          <th className="p-2 text-right w-10">数量</th>
                          <th className="p-2 text-left w-14">生产日期</th>
                          <th className="p-2 text-left w-14">有效期</th>
                          <th className="p-2 text-left w-12">保养期</th>
                          <th className="p-2 text-center w-8">单位</th>
                          <th className="p-2 text-right w-12">单价</th>
                          <th className="p-2 text-right w-14">总价</th>
                          <th className="p-2 text-left w-16">装备编码</th>
                          <th className="p-2 text-left w-14">RFID编码</th>
                          <th className="p-2 text-left w-14">供应商</th>
                          <th className="p-2 text-left w-16">备注</th>
                          <th className="p-2 text-center w-10">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formItems.length === 0 && (
                          <tr><td colSpan={16} className="p-6 text-center" style={{ color: 'var(--text-disabled)' }}>暂无装备明细，请点击「新增」添加或「导入」批量导入</td></tr>
                        )}
                        {formItems.map((item, idx) => {
                          const isRfidExpanded = expandedRfids.has(item.equipCode)
                          const hasMultipleRfids = (item.rfidList && item.rfidList.length > 1) || item.bookQty > 1
                          return (
                            <>
                              <tr key={item.equipCode} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                                <td className="p-2"><input type="checkbox" checked={formSelectedItems.includes(item.equipCode)} onChange={() => setFormSelectedItems(prev => prev.includes(item.equipCode) ? prev.filter(c => c !== item.equipCode) : [...prev, item.equipCode])} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.equipName} onChange={e => updateFormItem(item.equipCode, 'equipName', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.category} onChange={e => updateFormItem(item.equipCode, 'category', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.spec} onChange={e => updateFormItem(item.equipCode, 'spec', e.target.value)} /></td>
                                <td className="p-2"><input type="number" min={0} className="form-input w-full text-xs text-right py-0.5 font-mono" value={item.bookQty} onChange={e => updateFormItem(item.equipCode, 'bookQty', Number(e.target.value))} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.produceDate} onChange={e => updateFormItem(item.equipCode, 'produceDate', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.validDate} onChange={e => updateFormItem(item.equipCode, 'validDate', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.maintainPeriod} onChange={e => updateFormItem(item.equipCode, 'maintainPeriod', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs text-center py-0.5" value={item.unit} onChange={e => updateFormItem(item.equipCode, 'unit', e.target.value)} /></td>
                                <td className="p-2"><input type="number" min={0} className="form-input w-full text-xs text-right py-0.5 font-mono" value={item.unitPrice} onChange={e => updateFormItem(item.equipCode, 'unitPrice', Number(e.target.value))} /></td>
                                <td className="p-2 text-right font-mono font-medium" style={{ color: 'var(--primary-blue)' }}>¥{(item.bookQty * item.unitPrice).toLocaleString()}</td>
                                <td className="p-2"><input className="form-input w-full text-xs font-mono py-0.5" value={item.equipCode} onChange={e => updateFormItem(item.equipCode, 'equipCode', e.target.value)} /></td>
                                <td className="p-2">
                                  {hasMultipleRfids ? (
                                    <button className="flex items-center gap-1 text-xs" style={{ color: '#1890ff' }} onClick={() => setExpandedRfids(prev => { const n = new Set(prev); if (n.has(item.equipCode)) n.delete(item.equipCode); else n.add(item.equipCode); return n; })}>
                                      <span className="font-mono text-[10px]">{item.rfid || 'RFID...'}</span>
                                      <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isRfidExpanded ? 'rotate-180' : ''}`}><polyline points="6 9 12 15 18 9"/></svg>
                                      <span className="text-[10px]">({item.rfidList?.length || item.bookQty})</span>
                                    </button>
                                  ) : (
                                    <input className="form-input w-full text-xs font-mono py-0.5" value={item.rfid} onChange={e => updateFormItem(item.equipCode, 'rfid', e.target.value)} />
                                  )}
                                </td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.supplier} onChange={e => updateFormItem(item.equipCode, 'supplier', e.target.value)} /></td>
                                <td className="p-2"><input className="form-input w-full text-xs py-0.5" value={item.remark} onChange={e => updateFormItem(item.equipCode, 'remark', e.target.value)} /></td>
                                <td className="p-2 text-center">
                                  <button onClick={() => setFormItems(prev => prev.filter(i => i.equipCode !== item.equipCode))} className="text-red-400 hover:text-red-600">
                                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                                  </button>
                                </td>
                              </tr>
                              {isRfidExpanded && hasMultipleRfids && (
                                <tr style={{ background: '#fafafa' }}>
                                  <td colSpan={16} className="p-2">
                                    <div className="flex flex-wrap gap-2">
                                      {(item.rfidList || Array.from({ length: item.bookQty }, (_, i) => {
                                        const base = item.rfid.replace(/\d{4}$/, '') || 'RFID0000'
                                        const seq = String(i + 1).padStart(4, '0')
                                        return base + seq
                                      })).map((r, ri) => (
                                        <span key={ri} className="text-[10px] font-mono px-2 py-0.5 rounded border" style={{ borderColor: 'var(--border-color)' }}>{r}</span>
                                      ))}
                                    </div>
                                  </td>
                                </tr>
                              )}
                            </>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
                <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>导入格式：CSV文件，列顺序为「物资名称,物资类别,规格型号,数量,生产日期,有效期,保养期,单位,单价,总价,装备编码,RFID编码,供应商,备注」</p>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setCreateOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleCreate}>创建盘点任务</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Equip Select Modal ===== */}
      {equipSelectOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEquipSelectOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[1100px] max-w-[95vw] h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setEquipSelectOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧 */}
              <div className="flex-1 flex flex-col border-r" style={{ borderColor: 'var(--border-color)' }}>
                <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex flex-wrap items-end gap-3">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>仓库</label>
                      <select className="form-input w-36 text-xs" value={equipWarehouseFilter} onChange={e => setEquipWarehouseFilter(e.target.value)}>
                        <option>全部</option>
                        <option>省厅主仓库</option>
                        <option>市局限装备仓库</option>
                        <option>A区县级装备库</option>
                        <option>B区县级装备库</option>
                        <option>C区县级装备室</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>一级分类</label>
                      <select className="form-input w-28 text-xs" value={equipC1} onChange={e => { setEquipC1(e.target.value); setEquipC2('全部'); setEquipC3('全部') }}>
                        <option>全部</option>
                        {Array.from(new Set(initialItems.map(i => i.category))).filter(Boolean).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>二级分类</label>
                      <select className="form-input w-28 text-xs" value={equipC2} onChange={e => { setEquipC2(e.target.value); setEquipC3('全部') }}>
                        <option>全部</option>
                        {['通信设备', '记录设备', '防护装备', '照明设备', '应急装备'].map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>三级分类</label>
                      <select className="form-input w-28 text-xs" value={equipC3} onChange={e => setEquipC3(e.target.value)}>
                        <option>全部</option>
                        {['手持终端', '执法记录', '防弹防护', '照明设备', '急救装备', '消防装备'].map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称/编码</label>
                      <input className="form-input w-40 text-xs" placeholder="装备名称/装备编码" value={equipNameSearch} onChange={e => setEquipNameSearch(e.target.value)} />
                    </div>
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                  {(() => {
                    const allItems = [...initialItems]
                    const filtered = allItems.filter(e => {
                      if (equipWarehouseFilter !== '全部' && e.warehouse !== equipWarehouseFilter) return false
                      if (equipC1 !== '全部' && e.category !== equipC1) return false
                      if (equipNameSearch && !e.equipName.toLowerCase().includes(equipNameSearch.toLowerCase()) && !e.equipCode.toLowerCase().includes(equipNameSearch.toLowerCase())) return false
                      return true
                    })
                    return (
                      <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                        <thead>
                          <tr style={{ background: 'var(--table-header-bg)' }}>
                            <th className="border p-2 w-10"><input type="checkbox" disabled /></th>
                            <th className="border p-2">装备名称</th>
                            <th className="border p-2">一级分类</th>
                            <th className="border p-2">二级分类</th>
                            <th className="border p-2">三级分类</th>
                            <th className="border p-2">规格型号</th>
                            <th className="border p-2">装备编码</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map(e => {
                            const isSel = selectedEquips.some(s => s.item.equipCode === e.equipCode)
                            return (
                              <tr key={e.equipCode} className={`cursor-pointer transition-colors ${isSel ? 'bg-blue-50' : 'hover:bg-gray-50'}`} onClick={() => {
                                setSelectedEquips(prev => {
                                  const exists = prev.find(p => p.item.equipCode === e.equipCode)
                                  if (exists) return prev.filter(p => p.item.equipCode !== e.equipCode)
                                  return [...prev, { item: e, qty: 1 }]
                                })
                              }}>
                                <td className="border p-2 text-center"><input type="checkbox" checked={isSel} readOnly /></td>
                                <td className="border p-2 font-medium">{e.equipName}</td>
                                <td className="border p-2">{e.category}</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">-</td>
                                <td className="border p-2">{e.spec}</td>
                                <td className="border p-2 font-mono text-[10px]">{e.equipCode}</td>
                              </tr>
                            )
                          })}
                          {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
                        </tbody>
                      </table>
                    )
                  })()}
                </div>
              </div>
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>已选择装备 ({selectedEquips.length})</div>
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  {selectedEquips.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}><p className="text-xs">请点击左侧装备选择</p></div>
                  ) : selectedEquips.map((s, i) => (
                    <div key={s.item.equipCode} className="border rounded-lg p-3" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium">{s.item.equipName}</span>
                        <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedEquips(prev => prev.filter((_, idx) => idx !== i))}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                        </button>
                      </div>
                      <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>数量：{s.item.bookQty}</div>
                      <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>单价：¥{Math.floor(Math.random() * 5000 + 500)}</div>
                      <div className="flex items-center gap-2">
                        <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: Math.max(1, p.qty - 1) } : p))}>-</button>
                        <span className="text-xs font-mono w-8 text-center">{s.qty}</span>
                        <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: p.qty + 1 } : p))}>+</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => setEquipSelectOpen(false)}>关闭</button>
              <button className="btn-primary text-xs" disabled={selectedEquips.length === 0} onClick={() => {
                const newItems = selectedEquips.map((s, i) => {
                  const baseRfid = s.item.rfid || 'RFID0000'
                  const rfidList = s.qty > 1 ? Array.from({ length: s.qty }, (_, ri) => {
                    const base = baseRfid.replace(/\d{4}$/, '')
                    return base + String(ri + 1).padStart(4, '0')
                  }) : [baseRfid]
                  return {
                    ...s.item,
                    bookQty: s.qty,
                    rfid: baseRfid,
                    rfidList,
                    produceDate: s.item.produceDate || '2023-06',
                    validDate: s.item.validDate || '2028-06',
                    maintainPeriod: s.item.maintainPeriod || '12个月',
                    unitPrice: s.item.unitPrice || Math.floor(Math.random() * 5000 + 500),
                    supplier: s.item.supplier || '',
                    warehouse: formWarehouse || s.item.warehouse,
                  }
                })
                setFormItems(prev => [...prev, ...newItems])
                setEquipSelectOpen(false)
                setSelectedEquips([])
              }}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Check Entry Modal ===== */}
      {checkOpen && currentTask && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCheckOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-lg font-semibold">盘点录入 - {currentTask.name}</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{currentTask.id} · 盘点人：{currentTask.checker}</p>
              </div>
              <button onClick={() => setCheckOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {/* Summary */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>装备总数</p>
                  <p className="text-xl font-bold">{currentTask.items.length} 件</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)', background: '#f6ffed' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>无差异</p>
                  <p className="text-xl font-bold" style={{ color: '#52c41a' }}>{diffSummary.unchanged} 件</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: '#ffccc7', background: '#fff2f0' }}>
                  <p className="text-xs" style={{ color: '#ff4d4f' }}>盘亏</p>
                  <p className="text-xl font-bold" style={{ color: '#ff4d4f' }}>{diffSummary.deficit} 件</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: '#d9f7be', background: '#f6ffed' }}>
                  <p className="text-xs" style={{ color: '#52c41a' }}>盘盈</p>
                  <p className="text-xl font-bold" style={{ color: '#52c41a' }}>{diffSummary.surplus} 件</p>
                </div>
              </div>

              {/* Toolbar */}
              <div className="flex items-center gap-2">
                <button className="btn-primary text-xs flex items-center gap-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="4" y="8" width="16" height="12" rx="2"/><path d="M8 8V6a4 4 0 018 0v2"/>
                  </svg>
                  RFID扫描
                </button>
                <button className="btn-default text-xs flex items-center gap-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
                    <polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>
                  </svg>
                  导入Excel
                </button>
              </div>

              {/* Check table */}
              <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-sm">
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="p-2 text-left">序号</th>
                      <th className="p-2 text-left">装备编码</th>
                      <th className="p-2 text-left">装备</th>
                      <th className="p-2 text-left">装备类别</th>
                      <th className="p-2 text-center">单位</th>
                      <th className="p-2 text-left">规格型号</th>
                      <th className="p-2 text-left">RFID编号</th>
                      <th className="p-2 text-right">库存数量</th>
                      <th className="p-2 text-right" style={{ color: '#1890ff' }}>盘点数量</th>
                      <th className="p-2 text-right">盈亏</th>
                    </tr>
                  </thead>
                  <tbody>
                    {currentTask.items.map((item, i) => {
                      const diff = item.diffQty
                      const diffColor = diff === null ? 'var(--text-disabled)' : diff < 0 ? '#ff4d4f' : diff > 0 ? '#52c41a' : 'var(--text-secondary)'
                      return (
                        <tr key={item.equipCode} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="p-2 text-xs">{i + 1}</td>
                          <td className="p-2 font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{item.equipCode}</td>
                          <td className="p-2 font-medium">{item.equipName}</td>
                          <td className="p-2 text-xs">{item.category}</td>
                          <td className="p-2 text-xs text-center">{item.unit}</td>
                          <td className="p-2 text-xs" style={{ color: 'var(--text-secondary)' }}>{item.spec}</td>
                          <td className="p-2 text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{item.rfid}</td>
                          <td className="p-2 text-right font-mono">{item.bookQty}</td>
                          <td className="p-2 text-right">
                            <input
                              type="number"
                              min={0}
                              className="form-input w-16 text-xs text-right py-0.5"
                              value={item.actualQty ?? ''}
                              placeholder="录入"
                              onChange={e => handleUpdateActualQty(currentTask.id, item.equipCode, Number(e.target.value))}
                            />
                          </td>
                          <td className="p-2 text-right font-mono font-medium" style={{ color: diffColor }}>
                            {diff === null ? '-' : diff > 0 ? `+${diff}` : diff}
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setCheckOpen(false)}>暂存</button>
              <button className="btn-primary" onClick={() => handleSubmitResult(currentTask.id)}>提交盘点结果</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Detail Modal ===== */}
      {detailOpen && currentTask && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-lg font-semibold">{detailMode === 'approve' ? '盘点详情 - 待确认' : `盘点详情 - ${currentTask.name}`}</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{currentTask.id}</p>
              </div>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {/* Flow timeline */}
              <div>
                <h4 className="text-sm font-semibold mb-3">盘点流程</h4>
                <div className="flex items-center justify-center gap-2 py-3">
                  {flowSteps.map((step, i) => {
                    const st = getStepStatus(currentTask, step.key)
                    const isRejected = currentTask.status === 'rejected' && step.key === 'approve'
                    return (
                      <div key={step.key} className="flex items-center gap-2">
                        <div className="text-center">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center mx-auto ${st === 'done' ? 'text-white' : st === 'current' ? 'border-2' : 'border-2 border-dashed'}`}
                            style={{
                              background: st === 'done' ? (isRejected ? '#ff4d4f' : '#52c41a') : st === 'current' ? '#1890ff' : 'transparent',
                              borderColor: st === 'done' ? (isRejected ? '#ff4d4f' : '#52c41a') : st === 'current' ? '#1890ff' : '#d9d9d9',
                            }}>
                            {st === 'done' ? (isRejected ? <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> : <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>) : st === 'current' ? <div className="w-2.5 h-2.5 rounded-full bg-white" /> : <span className="text-xs" style={{ color: '#d9d9d9' }}>{i + 1}</span>}
                          </div>
                          <p className="text-xs font-medium mt-1.5">{step.label}</p>
                        </div>
                        {i < flowSteps.length - 1 && <svg width="24" height="12" viewBox="0 0 24 12" fill="none"><path d="M0 6h20m0 0l-4-4m4 4l-4 4" stroke={st === 'done' && !isRejected ? '#52c41a' : '#d9d9d9'} strokeWidth="1.5" /></svg>}
                      </div>
                    )
                  })}
                </div>
              </div>

              {/* Info cards */}
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>盘点名称</p>
                  <p className="text-sm font-medium">{currentTask.name}</p>
                </div>
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>盘点范围</p>
                  <p className="text-sm font-medium">{currentTask.scope}</p>
                </div>
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>当前状态</p>
                  <p className="text-sm font-bold" style={{ color: statusMap[currentTask.status].color }}>{statusMap[currentTask.status].label}</p>
                </div>
              </div>

              {/* Detail info */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 rounded-lg border space-y-1" style={{ borderColor: 'var(--border-color)' }}>
                  <p><span style={{ color: 'var(--text-secondary)' }}>盘点人：</span>{currentTask.checker}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>创建人：</span>{currentTask.creator}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span>{currentTask.createTime}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>开始时间：</span>{currentTask.startTime || '-'}</p>
                </div>
                <div className="p-3 rounded-lg border space-y-1" style={{ borderColor: 'var(--border-color)' }}>
                  <p><span style={{ color: 'var(--text-secondary)' }}>提交时间：</span>{currentTask.submitTime || '-'}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>审批时间：</span>{currentTask.approveTime || '-'}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>盘点周期：</span>{cycleLabels[currentTask.cycle]}</p>
                  <p><span style={{ color: 'var(--text-secondary)' }}>说明：</span>{currentTask.remark || '-'}</p>
                </div>
              </div>

              {/* Surplus / Deficit Summary - only in approve mode */}
              {detailMode === 'approve' && currentTask.items.some(i => i.actualQty !== null) && (
                <div className="space-y-3">
                  {/* 盘盈区域 */}
                  {(() => {
                    const surplusItems = currentTask.items.filter(i => i.actualQty !== null && (i.diffQty || 0) > 0)
                    if (surplusItems.length === 0) return null
                    return (
                      <div className="border rounded-lg overflow-hidden" style={{ borderColor: '#b7eb8f' }}>
                        <div
                          className="flex items-center justify-between p-3 cursor-pointer"
                          style={{ background: '#f6ffed' }}
                          onClick={() => setSurplusExpanded(!surplusExpanded)}
                        >
                          <span className="font-medium text-sm" style={{ color: '#52c41a' }}>盘盈（{surplusItems.length}件）</span>
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2" className={`transition-transform ${surplusExpanded ? 'rotate-180' : ''}`}><polyline points="6 9 12 15 18 9"/></svg>
                        </div>
                        {surplusExpanded && (
                          <div className="p-3 space-y-2">
                            {surplusItems.map(item => (
                              <div key={item.equipCode} className="flex items-center justify-between p-2 rounded border" style={{ borderColor: 'var(--border-color)' }}>
                                <div>
                                  <span className="font-medium text-sm">{item.equipName}</span>
                                  <span className="text-xs ml-2" style={{ color: 'var(--text-secondary)' }}>账面{item.bookQty} / 实盘{item.actualQty} / +{item.diffQty}</span>
                                </div>
                                <button
                                  className="text-xs px-2 py-1 rounded text-white"
                                  style={{ background: '#52c41a' }}
                                  onClick={() => { if (confirm('请确认是否重新入库？')) alert(`已确认入库：${item.equipName}`) }}
                                >入库</button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )
                  })()}

                  {/* 盘亏区域 */}
                  {(() => {
                    const deficitItems = currentTask.items.filter(i => i.actualQty !== null && (i.diffQty || 0) < 0)
                    if (deficitItems.length === 0) return null
                    return (
                      <div className="border rounded-lg overflow-hidden" style={{ borderColor: '#ffccc7' }}>
                        <div
                          className="flex items-center justify-between p-3 cursor-pointer"
                          style={{ background: '#fff2f0' }}
                          onClick={() => setDeficitExpanded(!deficitExpanded)}
                        >
                          <span className="font-medium text-sm" style={{ color: '#ff4d4f' }}>盘亏（{deficitItems.length}件）</span>
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2" className={`transition-transform ${deficitExpanded ? 'rotate-180' : ''}`}><polyline points="6 9 12 15 18 9"/></svg>
                        </div>
                        {deficitExpanded && (
                          <div className="p-3 space-y-2">
                            {deficitItems.map(item => (
                              <div key={item.equipCode} className="flex items-center justify-between p-2 rounded border" style={{ borderColor: 'var(--border-color)' }}>
                                <div>
                                  <span className="font-medium text-sm">{item.equipName}</span>
                                  <span className="text-xs ml-2" style={{ color: 'var(--text-secondary)' }}>账面{item.bookQty} / 实盘{item.actualQty} / {item.diffQty}</span>
                                </div>
                                <button
                                  className="text-xs px-2 py-1 rounded text-white"
                                  style={{ background: '#ff4d4f' }}
                                  onClick={() => { if (confirm('请确认是否重新出库？')) alert(`已确认出库：${item.equipName}`) }}
                                >出库</button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )
                  })()}
                </div>
              )}

              {/* Items table with results */}
              {currentTask.items.some(i => i.actualQty !== null) && (
                <div>
                  <h4 className="text-sm font-semibold mb-2">盘点明细</h4>
                  <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                    <table className="w-full text-sm">
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="p-2 text-left">装备编码</th>
                          <th className="p-2 text-left">装备</th>
                          <th className="p-2 text-left">装备类别</th>
                          <th className="p-2 text-center">单位</th>
                          <th className="p-2 text-left">规格型号</th>
                          <th className="p-2 text-left">RFID编号</th>
                          <th className="p-2 text-right">库存数量</th>
                          <th className="p-2 text-right">盘点数量</th>
                          <th className="p-2 text-right">盈亏</th>
                          <th className="p-2 text-center">盘点状态</th>
                          <th className="p-2 text-center">修改库存</th>
                          <th className="p-2 text-left">备注</th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentTask.items.filter(i => i.actualQty !== null).map(item => {
                          const diff = item.diffQty || 0
                          return (
                            <tr key={item.equipCode} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                              <td className="p-2 font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{item.equipCode}</td>
                              <td className="p-2">{item.equipName}</td>
                              <td className="p-2 text-xs">{item.category}</td>
                              <td className="p-2 text-xs text-center">{item.unit}</td>
                              <td className="p-2 text-xs" style={{ color: 'var(--text-secondary)' }}>{item.spec}</td>
                              <td className="p-2 text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{item.rfid}</td>
                              <td className="p-2 text-right font-mono">{item.bookQty}</td>
                              <td className="p-2 text-right font-mono">{item.actualQty}</td>
                              <td className="p-2 text-right font-mono font-medium" style={{ color: diff < 0 ? '#ff4d4f' : diff > 0 ? '#52c41a' : 'var(--text-secondary)' }}>
                                {diff > 0 ? `+${diff}` : diff === 0 ? '无' : diff}
                              </td>
                              <td className="p-2 text-center"><span className={`tag text-xs ${item.checkStatus === '正常' ? 'tag-green' : item.checkStatus === '盘亏' ? 'tag-red' : 'tag-blue'}`}>{item.checkStatus}</span></td>
                              <td className="p-2 text-center">{item.adjustStock ? <span style={{ color: '#52c41a' }}>是</span> : <span style={{ color: '#999' }}>否</span>}</td>
                              <td className="p-2 text-xs" style={{ color: 'var(--text-secondary)' }}>{item.remark || '-'}</td>
                            </tr>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-3 pt-2">
                {detailMode === 'approve' ? (
                  <>
                    <button className="btn-default" onClick={() => { setDetailOpen(false); setDetailMode('view') }}>取消</button>
                    <button className="btn-primary" onClick={() => { handleApprove(currentTask.id); setDetailOpen(false); setDetailMode('view') }}>确认通过</button>
                  </>
                ) : (
                  <>
                    <button className="btn-default" onClick={() => setDetailOpen(false)}>关闭</button>
                    {currentTask.status === 'submitted' && (
                      <>
                        <button className="btn-danger" onClick={() => { handleReject(currentTask.id); setDetailOpen(false) }}>重新盘点</button>
                        <button className="btn-primary" onClick={() => { handleApprove(currentTask.id); setDetailOpen(false) }}>审批通过</button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
