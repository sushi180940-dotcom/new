import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

const tabList = [
  { key: 'purchase', label: '装备需求申报' },
  { key: 'contract', label: '合同管理' },
  { key: 'order', label: '订单管理' },
]

type ApprovalStatus = 'draft' | 'budget_approved' | 'submitted' | 'unit_pending' | 'unit_rejected' | 'jb_pending' | 'jb_rejected' | 'approved'

interface OrgNode {
  id: string
  label: string
  expanded?: boolean
  children?: OrgNode[]
}

const orgTreeData: OrgNode[] = [
  {
    id: 'org-root',
    label: '省公安厅',
    expanded: true,
    children: [
      { id: 'org-zhzx', label: '指挥中心' },
      { id: 'org-xjzd', label: '刑警支队' },
      { id: 'org-zazd', label: '治安支队' },
      { id: 'org-jjzd', label: '交警支队' },
      { id: 'org-twjd', label: '特警支队' },
      {
        id: 'org-kffj', label: '开发区分局',
        children: [
          { id: 'org-kfpcs', label: '开发区派出所' },
          { id: 'org-kfjws', label: '开发区警务室' },
        ]
      },
      {
        id: 'org-gxfj', label: '高新分局',
        children: [
          { id: 'org-gxpcs', label: '高新派出所' },
          { id: 'org-gxjws', label: '高新警务室' },
        ]
      },
    ]
  }
]

export const contractData = [
  { id: 'HT2024001', partyA: '省公安厅 / 科信处', partyB: '华为技术有限公司', contractName: '指挥调度系统建设合同', amount: 680000, date: '2024-03-10', deliveryDate: '2024-06-10', status: 'draft', applicant: '王强', attachment: '合同附件-HT2024001.pdf', remark: '' },
  { id: 'HT2024002', partyA: '省公安厅 / 网安总队', partyB: '华为技术有限公司', contractName: '网络安全设备采购合同', amount: 360000, date: '2024-03-15', deliveryDate: '2024-05-15', status: 'fulfilling', applicant: '李明', attachment: '', remark: '' },
  { id: 'HT2024003', partyA: '省公安厅 / 刑侦总队', partyB: '华为技术有限公司', contractName: '通信保障设备采购合同', amount: 500000, date: '2024-03-20', deliveryDate: '2024-07-20', status: 'completed', applicant: '赵峰', attachment: '', remark: '' },
  { id: 'HT2024004', partyA: '省公安厅 / 治安总队', partyB: '华为技术有限公司', contractName: '应急救援装备采购合同', amount: 510000, date: '2024-03-25', deliveryDate: '2024-06-25', status: 'draft', applicant: '陈刚', attachment: '', remark: '' },
  { id: 'HT2024005', partyA: '省公安厅 / 交警总队', partyB: '华为技术有限公司', contractName: '智能交通系统升级合同', amount: 680000, date: '2024-03-10', deliveryDate: '2024-09-10', status: 'fulfilling', applicant: '王强', attachment: '', remark: '' },
  { id: 'HT2024006', partyA: '省公安厅 / 科信处', partyB: '华为技术有限公司', contractName: '数据中心建设合同', amount: 360000, date: '2024-04-01', deliveryDate: '2024-08-01', status: 'completed', applicant: '李明', attachment: '', remark: '' },
]

export const orderData = [
  {
    id: 'DD2024001', contractId: 'HT2024002', orderName: '网络安全设备首批订单', contractName: '网络安全设备采购合同', supplier: '华为技术有限公司', enterpriseCode: '001234567',
    equipName: '网络安全设备套装', orderQty: 15, unit: '套', unitPrice: 24000,
    shipped: 15, received: 0, status: 'pending_ship' as 'pending_ship', applyUnit: '省厅科信处', applicant: '李明', contact: '13800138001', orderDate: '2024-03-15', shipAddress: '省公安厅主楼3楼',
    materials: [
      { id: 'M002-1', name: '防火墙设备', model: 'USG-6000E', code: '1101001', qty: 10, rfid: ['192837465718', '192837465719', '192837465720', '192837465721', '192837465722', '192837465723', '192837465724', '192837465725', '192837465726', '192837465727'], isFixed: true },
      { id: 'M002-2', name: '入侵检测系统', model: 'IDS-2000', code: '1101002', qty: 5, rfid: ['564738291045', '564738291046', '564738291047', '564738291048', '564738291049'], isFixed: true },
    ],
    items: [
      { id: 'M002-1', name: '防火墙设备', spec: 'USG-6000E', code: '1101001', qty: 10, unit: '台', price: 24000, amount: 240000 },
      { id: 'M002-2', name: '入侵检测系统', spec: 'IDS-2000', code: '1101002', qty: 5, unit: '台', price: 24000, amount: 120000 },
    ],
    deliveryList: [
      { deliveryId: 'SH2024003', orderId: 'DD2024001', shipDate: '2024-04-02', carrier: '顺丰速运', trackingNo: 'SF1234567891', receiver: '王警官', receivePhone: '13900139001', status: 'shipped' as 'shipped', signed: false, signDate: '', materials: [{ id: 'M002-1', name: '防火墙设备', model: 'USG-6000E', code: '1101001', qty: 10, rfid: ['192837465718', '192837465719', '192837465720', '192837465721', '192837465722', '192837465723', '192837465724', '192837465725', '192837465726', '192837465727'], isFixed: true }], receiveList: [] },
    ],
    receiveRecords: [],
    unqualifiedRfidMap: {},
  },
  {
    id: 'DD2024002', contractId: 'HT2024001', orderName: '指挥调度系统硬件订单', contractName: '指挥调度系统建设合同', supplier: '华为技术有限公司', enterpriseCode: '001234567',
    equipName: '指挥调度终端设备', orderQty: 8, unit: '套', unitPrice: 85000,
    shipped: 0, received: 0, status: 'pending_ship' as 'pending_ship', applyUnit: '省厅指挥中心', applicant: '王强', contact: '13800138002', orderDate: '2024-03-12', shipAddress: '省公安厅指挥中心B栋',
    materials: [
      { id: 'M001-1', name: '指挥调度服务器', model: 'RH-2288H', code: '1202001', qty: 2, rfid: ['1098765432101', '1098765432102'], isFixed: true },
      { id: 'M001-2', name: '调度终端设备', model: 'DP-800', code: '1202002', qty: 6, rfid: ['1122334455661', '1122334455662', '1122334455663', '1122334455664', '1122334455665', '1122334455666'], isFixed: true },
    ],
    items: [
      { id: 'M001-1', name: '指挥调度服务器', spec: 'RH-2288H', code: '1202001', qty: 2, unit: '台', price: 85000, amount: 170000 },
      { id: 'M001-2', name: '调度终端设备', spec: 'DP-800', code: '1202002', qty: 6, unit: '台', price: 85000, amount: 510000 },
    ],
    deliveryList: [
      { deliveryId: 'SH2024001', orderId: 'DD2024002', shipDate: '2024-03-20', carrier: '京东物流', trackingNo: 'JD9876543210', receiver: '赵科长', receivePhone: '13900139002', status: 'signed' as 'signed', signed: true, signDate: '2024-03-22', materials: [{ id: 'M001-1', name: '指挥调度服务器', model: 'RH-2288H', code: '1202001', qty: 2, rfid: ['1098765432101', '1098765432102'], isFixed: true }], receiveList: [{ receiveId: 'RS2024001', deliveryId: 'SH2024001', receiveDate: '2024-03-22', receiver: '赵科长', status: 'all' as 'all', materials: [{ id: 'M001-1', name: '指挥调度服务器', model: 'RH-2288H', code: '1202001', qty: 2, rfid: ['1098765432101', '1098765432102'], isFixed: true }] }] },
      { deliveryId: 'SH2024002', orderId: 'DD2024002', shipDate: '2024-04-01', carrier: '德邦快递', trackingNo: 'DB1122334455', receiver: '赵科长', receivePhone: '13900139002', status: 'pending_receipt' as 'pending_receipt', signed: false, signDate: '', materials: [{ id: 'M001-2', name: '调度终端设备', model: 'DP-800', code: '1202002', qty: 6, rfid: ['1122334455661', '1122334455662', '1122334455663', '1122334455664', '1122334455665', '1122334455666'], isFixed: true }], receiveList: [] },
    ],
    receiveRecords: [
      { receiveId: 'RS2024001', deliveryId: 'SH2024001', receiveDate: '2024-03-22', receiver: '赵科长', status: 'all' as 'all', materials: [{ id: 'M001-1', name: '指挥调度服务器', model: 'RH-2288H', code: '1202001', qty: 2, rfid: ['1098765432101', '1098765432102'], isFixed: true }] }
    ],
    unqualifiedRfidMap: {},
  },
  {
    id: 'DD2024003', contractId: 'HT2024005', orderName: '智能交通设备订单', contractName: '智能交通系统升级合同', supplier: '华为技术有限公司', enterpriseCode: '001234567',
    equipName: '智能交通监控设备', orderQty: 20, unit: '套', unitPrice: 34000,
    shipped: 0, received: 0, status: 'pending_ship' as 'pending_ship', applyUnit: '交警总队科技处', applicant: '王强', contact: '13800138003', orderDate: '2024-03-18', shipAddress: '交警总队装备库',
    materials: [
      { id: 'M003-1', name: '交通监控摄像头', model: 'IPC-4K-PTZ', code: '2101001', qty: 12, rfid: [], isFixed: true },
      { id: 'M003-2', name: '车牌识别设备', model: 'LPR-3000', code: '2101002', qty: 8, rfid: [], isFixed: true },
    ],
    items: [
      { id: 'M003-1', name: '交通监控摄像头', spec: 'IPC-4K-PTZ', code: '2101001', qty: 12, unit: '台', price: 34000, amount: 408000 },
      { id: 'M003-2', name: '车牌识别设备', spec: 'LPR-3000', code: '2101002', qty: 8, unit: '台', price: 34000, amount: 272000 },
    ],
    deliveryList: [],
    receiveRecords: [],
    unqualifiedRfidMap: {},
  },
]

export default function ProcurementPage({ activeSubTab, onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'contract')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTitle, setDrawerTitle] = useState('')
  const [selectedRow, setSelectedRow] = useState<any>(null)
  const [syncLogOpen, setSyncLogOpen] = useState(false)

  // Drawer read-only mode
  const isDrawerReadOnly = !!selectedRow && drawerTitle.startsWith('需求详情')

  // Line items for purchase detail
  const [lineItems, setLineItems] = useState([
    { id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' },
  ])

  // Contract form states
  const [linkedPurchase, setLinkedPurchase] = useState('')
  const [contractName, setContractName] = useState('')
  const [supplierSearch, setSupplierSearch] = useState('')
  const [contractFiles, setContractFiles] = useState<{ id: string; name: string; size: string }[]>([])
  const [contractDetailOpen, setContractDetailOpen] = useState(false)
  const [contractDetailData, setContractDetailData] = useState<any>(null)
  const [contractFormOpen, setContractFormOpen] = useState(false)
  const [contractFormMode, setContractFormMode] = useState<'add' | 'edit'>('add')
  const [contractFormData, setContractFormData] = useState({
    partyA: '', partyB: '华为技术有限公司', contractName: '', amount: '', date: '', deliveryDate: '', remark: '', attachment: ''
  })
  const [contractList, setContractList] = useState(contractData)
  const [orderConfirmOpen, setOrderConfirmOpen] = useState(false)
  const [completeConfirmOpen, setCompleteConfirmOpen] = useState(false)
  const [terminateReason, setTerminateReason] = useState('')
  const [terminateConfirmOpen, setTerminateConfirmOpen] = useState(false)
  const [storageConfirmOpen, setStorageConfirmOpen] = useState(false)
  const [expandedRfidRows, setExpandedRfidRows] = useState<number[]>([0])
  const [rfidMap, setRfidMap] = useState<Record<string, string[]>>({})
  const [unqualifiedRfidMap, setUnqualifiedRfidMap] = useState<Record<string, string[]>>({})
  const [rfidCompareMap, setRfidCompareMap] = useState<Record<string, { match: string[]; extra: string[]; missing: string[] }>>({})
  const [receiptPreviewOpen, setReceiptPreviewOpen] = useState(false) // 收货单预览
  const [returnPreviewOpen, setReturnPreviewOpen] = useState(false)   // 退货单预览
  const [orderModalOpen, setOrderModalOpen] = useState(false)
  const [acceptModalOpen, setAcceptModalOpen] = useState(false)
  const [acceptForm, setAcceptForm] = useState({
    itemName: '',
    itemId: '',
    result: 'pass' as 'pass' | 'fail',
    opinion: '',
    checker: '当前用户',
    checkTime: new Date().toISOString().slice(0, 16),
    handleWay: '',
    qualifiedQty: '',
    unqualifiedRfids: [] as string[],
    totalQty: 0,
  })
  const [acceptViewMode, setAcceptViewMode] = useState(false)
  const [purchaseDropdownOpen, setPurchaseDropdownOpen] = useState(false)
  const [supplierDropdownOpen, setSupplierDropdownOpen] = useState(false)
  // 订单弹窗中供应商搜索
  const [orderSupplier, setOrderSupplier] = useState('')
  const [orderSupplierOpen, setOrderSupplierOpen] = useState(false)
  // 新增企业弹窗
  const [addSupplierOpen, setAddSupplierOpen] = useState(false)
  const [newSupplierName, setNewSupplierName] = useState('')
  const [newSupplierCode, setNewSupplierCode] = useState('')
  const [newSupplierShort, setNewSupplierShort] = useState('')
  const [newSupplierTech, setNewSupplierTech] = useState('')
  const [newSupplierPhone, setNewSupplierPhone] = useState('')
  const [newSupplierPolice, setNewSupplierPolice] = useState('否')
  const [newSupplierSecret, setNewSupplierSecret] = useState('否')
  const [newSupplierStatus, setNewSupplierStatus] = useState('正常')
  const [newSupplierTypes, setNewSupplierTypes] = useState<string[]>([])
  const [newSupplierRemark, setNewSupplierRemark] = useState('')
  // 申请单位下拉树
  const [applyUnitOpen, setApplyUnitOpen] = useState(false)
  const [applyUnitVal, setApplyUnitVal] = useState('')
  const [applyUnitId, setApplyUnitId] = useState('')
  const [applyUnitSearch, setApplyUnitSearch] = useState('')
  const [orgTreeExpanded, setOrgTreeExpanded] = useState<Record<string, boolean>>({ 'org-root': true })

  const [supplierListState, setSupplierListState] = useState([
    '华为技术', '海康威视', '大疆创新', '中兴通讯', '烽火通信', '浪潮集团', '科大讯飞', '大华股份', '宇视科技', '科达股份'
  ])

  // 装备选择弹窗
  const [equipSelectOpen, setEquipSelectOpen] = useState(false)
  const [equipC1, setEquipC1] = useState('全部')
  const [equipC2, setEquipC2] = useState('全部')
  const [equipC3, setEquipC3] = useState('全部')
  const [equipNameSearch, setEquipNameSearch] = useState('')
  const [selectedEquips, setSelectedEquips] = useState<{ equip: EquipBase; qty: number }[]>([])

  // 装备基础数据
  interface EquipBase {
    id: string; name: string; code: string
    category1: string; category2: string; category3: string
    spec: string; stockQty: number; unit: string; unitPrice: number
  }
  const equipBaseData: EquipBase[] = [
    { id: 'e1', name: '手持终端 XT-2000', code: 'ZB-2023-001', category1: '通信设备', category2: '指挥调度装备', category3: '指挥决策', spec: 'XT-2000/黑色', stockQty: 50, unit: '台', unitPrice: 3200 },
    { id: 'e2', name: '对讲机 PD780G', code: 'ZB-2023-002', category1: '通信设备', category2: '通信保障装备', category3: '无线通信', spec: 'PD780G/U段', stockQty: 30, unit: '台', unitPrice: 1800 },
    { id: 'e3', name: '执法记录仪 DSJ-A7', code: 'ZB-2023-003', category1: '记录设备', category2: '现场记录装备', category3: '执法记录', spec: 'DSJ-A7/64G', stockQty: 80, unit: '台', unitPrice: 1200 },
    { id: 'e4', name: '防弹背心 FDY-3R', code: 'ZB-2023-004', category1: '防护装备', category2: '个人防护装备', category3: '防弹防护', spec: 'FDY-3R/三级', stockQty: 20, unit: '件', unitPrice: 2500 },
    { id: 'e5', name: '战术头盔 MICH-2000', code: 'ZB-2023-005', category1: '防护装备', category2: '个人防护装备', category3: '头部防护', spec: 'MICH-2000/L号', stockQty: 15, unit: '顶', unitPrice: 1500 },
    { id: 'e6', name: '警用强光手电', code: 'ZB-2023-006', category1: '应急装备', category2: '照明装备', category3: '手持照明', spec: 'CREE T6/1000流明', stockQty: 100, unit: '根', unitPrice: 280 },
    { id: 'e7', name: '急救包 JJB-A', code: 'ZB-2023-009', category1: '应急装备', category2: '医疗急救装备', category3: '急救包', spec: 'JJB-A/综合型', stockQty: 40, unit: '个', unitPrice: 220 },
    { id: 'e8', name: '防暴盾牌 FB-P', code: 'ZB-2023-007', category1: '防护装备', category2: '防暴防护装备', category3: '防暴盾牌', spec: 'FB-P/铝合金', stockQty: 25, unit: '面', unitPrice: 800 },
    { id: 'e9', name: '伸缩警棍 ZG-T', code: 'ZB-2023-008', category1: '应急装备', category2: '制服装备', category3: '警棍', spec: 'ZG-T/钛合金', stockQty: 60, unit: '根', unitPrice: 350 },
    { id: 'e10', name: '卫星便携站', code: 'ZB-2023-015', category1: '通信设备', category2: '应急通信装备', category3: '卫星通信', spec: '便携式/2.4m天线', stockQty: 5, unit: '套', unitPrice: 120000 },
    { id: 'e11', name: '调度控制台', code: 'ZB-2023-016', category1: '通信设备', category2: '指挥调度装备', category3: '指挥决策', spec: '三联屏/可升降', stockQty: 3, unit: '套', unitPrice: 45000 },
    { id: 'e12', name: '消防水带', code: 'ZB-2023-017', category1: '应急装备', category2: '消防装备', category3: '灭火器材', spec: '65mm/20m/有衬里', stockQty: 200, unit: '条', unitPrice: 180 },
  ]
  const supplierList = supplierListState

  // 供应商企业数据（与SupplierPage共享，用于统计）
  const enterprises = [
    { id: 'SUP001', name: '华为技术有限公司', auditStatus: 'approved' },
    { id: 'SUP002', name: '海康威视数字技术股份有限公司', auditStatus: 'approved' },
    { id: 'SUP003', name: '大疆创新科技有限公司', auditStatus: 'approved' },
    { id: 'SUP004', name: '中兴通讯股份有限公司', auditStatus: 'approved' },
    { id: 'SUP005', name: '烽火通信科技股份有限公司', auditStatus: 'pending' },
    { id: 'SUP006', name: '浪潮集团有限公司', auditStatus: 'pending' },
    { id: 'SUP007', name: '大华技术股份有限公司', auditStatus: 'pending' },
  ]

  // 商品数据（与SupplierPage共享，用于统计）
  const products = [
    { id: 'SP001', name: '手持终端', status: 'on' },
    { id: 'SP002', name: '执法记录仪', status: 'on' },
    { id: 'SP003', name: '无人机', status: 'review' },
    { id: 'SP004', name: '应急照明灯', status: 'off' },
    { id: 'SP005', name: '对讲机', status: 'review' },
    { id: 'SP006', name: '防弹背心', status: 'on' },
    { id: 'SP007', name: '战术头盔', status: 'review' },
    { id: 'SP008', name: '便携式卫星通信终端', status: 'on' },
  ]

  const approvedPurchases = [
    { id: 'CG2024015', project: '[XM2024015] 2025年度应急物资储备扩充', name: '应急发电一体机', amount: 680000 },
    { id: 'CG2024011', project: '[XM2024011] 2025年度消防装备更新项目', name: '消防水带', amount: 36000 },
    { id: 'CG2024012', project: '[XM2024012] 2025年度指挥调度系统建设', name: '调度控制台', amount: 360000 },
    { id: 'CG2024013', project: '[XM2024013] 2025年度救援车辆配备项目', name: '液压破拆工具组', amount: 510000 },
    { id: 'CG2024014', project: '[XM2024014] 2025年度通信保障设备采购', name: '卫星便携站', amount: 500000 },
  ]

  const addLineItem = () => {
    setLineItems(prev => [...prev, { id: Date.now(), name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }])
  }

  const removeLineItem = (id: number) => {
    setLineItems(prev => prev.filter(item => item.id !== id))
  }

  const updateLineItem = (id: number, field: string, value: string | number) => {
    setLineItems(prev => prev.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value }
        if (field === 'qty' || field === 'price') {
          updated.amount = Number(updated.qty) * Number(updated.price)
        }
        return updated
      }
      return item
    }))
  }

  const totalAmount = lineItems.reduce((sum, item) => sum + item.amount, 0)

  useEffect(() => {
    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])


  const purchaseData = [
    { id: 'CG2024011', projectName: '2025年度消防装备更新项目', projectType: '货物采购', budget: 360000, source: '财政', multiYear: false, applyUnit: '消防支队', operator: '王强', projectIntro: '更新消防水带等装备，提升消防救援能力。', projectJustify: '现有装备老化严重，需及时更新换代。', applyDate: '2024-03-01', status: 'draft' as ApprovalStatus },
    { id: 'CG2024012', projectName: '2025年度指挥调度系统建设', projectType: '系统集成', budget: 360000, source: '专项', multiYear: true, applyUnit: '指挥中心', operator: '李明', projectIntro: '建设新一代指挥调度系统，提升应急响应效率。', projectJustify: '现有系统已无法满足日益增长的指挥调度需求。', applyDate: '2024-03-05', status: 'submitted' as ApprovalStatus },
    { id: 'CG2024013', projectName: '2025年度救援车辆配备项目', projectType: '货物采购', budget: 510000, source: '自筹', multiYear: false, applyUnit: '救援队', operator: '陈刚', projectIntro: '配备液压破拆工具组，提升车辆救援能力。', projectJustify: '根据年度工作计划，需补充救援装备。', applyDate: '2024-03-08', status: 'unit_pending' as ApprovalStatus },
    { id: 'CG2024014', projectName: '2025年度通信保障设备采购', projectType: '货物采购', budget: 500000, source: '财政', multiYear: false, applyUnit: '通信处', operator: '刘洋', projectIntro: '采购卫星便携站等通信保障设备。', projectJustify: '保障应急通信能力，满足实战需求。', applyDate: '2024-03-10', status: 'jb_pending' as ApprovalStatus },
    { id: 'CG2024015', projectName: '2025年度应急物资储备扩充', projectType: '货物采购', budget: 680000, source: '专项', multiYear: true, applyUnit: '应急管理处', operator: '赵峰', projectIntro: '扩充应急发电一体机等储备物资。', projectJustify: '提升应急物资储备水平，保障突发事件应对能力。', applyDate: '2024-03-12', status: 'approved' as ApprovalStatus },
    { id: 'CG2024016', projectName: '2025年度防汛排涝设备采购', projectType: '货物采购', budget: 360000, source: '其他', multiYear: false, applyUnit: '防汛办', operator: '周伟', projectIntro: '采购移动排水泵车等防汛设备。', projectJustify: '汛期将至，需提前配备防汛排涝装备。', applyDate: '2024-03-15', status: 'budget_approved' as ApprovalStatus },
  ]



  type AcceptanceStatus = 'pending_check' | 'pending_storage' | 'stored'
  type CheckResult = 'pass' | 'fail'

  const acceptanceData = [
    {
      id: 'YS2024001', orderId: 'DD2024003', contractId: 'HT2024004',
      itemName: '液压破拆工具组', itemSpec: '60MPa/全套',
      code: 'ZB-2025-003', qty: 6, unit: '套',
      result: 'pass' as CheckResult, status: 'pending_storage' as AcceptanceStatus,
      inspector: '赵伟', date: '2024-04-01 10:30',
      problemDesc: '', handleMethod: '', attachments: 3
    },
    {
      id: 'YS2024002', orderId: 'DD2024001', contractId: 'HT2024002',
      itemName: '调度控制台', itemSpec: '双屏/42U',
      code: '待编码', qty: 8, unit: '套',
      result: 'fail' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '孙丽', date: '2024-04-03 14:20',
      problemDesc: '2套控制台外观有轻微划痕，1套缺少电源适配器。', handleMethod: '换货',
      attachments: 5
    },
    {
      id: 'YS2024003', orderId: 'DD2024002', contractId: 'HT2024003',
      itemName: '卫星便携站', itemSpec: 'Ku频段/2Mbps',
      code: 'ZB-2025-001', qty: 2, unit: '套',
      result: 'fail' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '周强', date: '2024-04-05 09:15',
      problemDesc: '设备无法正常开机，经检测为主板故障。', handleMethod: '退货',
      attachments: 2
    },
    {
      id: 'YS2024004', orderId: 'DD2024001', contractId: 'HT2024002',
      itemName: '调度控制台', itemSpec: '双屏/42U',
      code: '待编码', qty: 8, unit: '套',
      result: '' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '', date: '',
      problemDesc: '', handleMethod: '',
      attachments: 0
    },
  ]

  const statusMap: Record<ApprovalStatus | string, { label: string; tag: string }> = {
    draft: { label: '草稿', tag: 'tag-gray' },
    budget_approved: { label: '预算批复', tag: 'tag-green' },
    submitted: { label: '提交申请', tag: 'tag-blue' },
    unit_pending: { label: '单位审批', tag: 'tag-yellow' },
    unit_rejected: { label: '单位驳回', tag: 'tag-red' },
    jb_pending: { label: 'JB部审批', tag: 'tag-yellow' },
    jb_rejected: { label: 'JB部驳回', tag: 'tag-red' },
    approved: { label: '审批完成', tag: 'tag-green' },
    executing: { label: '执行中', tag: 'tag-blue' },
    fulfilling: { label: '履行中', tag: 'tag-blue' },
    accepted: { label: '已验收', tag: 'tag-green' },
    pending_ship: { label: '待验收', tag: 'tag-yellow' },
    partial_ship: { label: '部分验收', tag: 'tag-blue' },
    pending_storage: { label: '待入库', tag: 'tag-orange' },
    stored: { label: '已入库', tag: 'tag-green' },
    terminated: { label: '终止/作废', tag: 'tag-red' },
    pass: { label: '合格', tag: 'tag-green' },
    fail: { label: '不合格', tag: 'tag-red' },
  }

  // Approval flow config: 5 nodes
  const flowNodes = [
    { key: 'submitted', label: '提交申请', desc: '申请人：张三', startTime: '2024-03-01 09:00', endTime: '2024-03-01 09:15' },
    { key: 'unit_pending', label: '单位审批', desc: '审批人：单位负责人', startTime: '2024-03-01 10:00', endTime: '2024-03-02 14:30' },
    { key: 'jb_pending', label: 'JB部审批', desc: '审批人：JB部负责人', startTime: '2024-03-02 16:00', endTime: '2024-03-04 11:00' },
    { key: 'budget_approved', label: '预算批复', desc: '自动同步', startTime: '2024-03-04 14:00', endTime: '2024-03-05 09:00' },
    { key: 'approved', label: '审批完成', desc: '全部审批通过', startTime: '2024-03-05 10:00', endTime: '2024-03-05 10:00' },
  ]

  // Determine each node's visual state based on current status
  function getNodeState(nodeKey: string, rowStatus: ApprovalStatus | null, isNew: boolean) {
    if (isNew) {
      // New application: only "提交申请" is done (info filled), rest are waiting
      if (nodeKey === 'submitted') return 'done'
      return 'waiting'
    }

    // Draft: same as new (not yet submitted)
    if (rowStatus === 'draft') {
      if (nodeKey === 'submitted') return 'done'
      return 'waiting'
    }

    // Detail view: determine based on row status
    if (!rowStatus) return 'waiting'

    const statusOrder = ['draft', 'submitted', 'unit_pending', 'unit_rejected', 'jb_pending', 'jb_rejected', 'budget_approved', 'approved']
    const currentIdx = statusOrder.indexOf(rowStatus)
    const nodeIdx = statusOrder.indexOf(nodeKey)

    // rejected states
    if (rowStatus === 'unit_rejected') {
      if (nodeKey === 'submitted') return 'done'
      if (nodeKey === 'unit_pending') return 'rejected'
      return 'skip'
    }
    if (rowStatus === 'jb_rejected') {
      if (nodeKey === 'submitted') return 'done'
      if (nodeKey === 'unit_pending') return 'done'
      if (nodeKey === 'jb_pending') return 'rejected'
      return 'skip'
    }

    // approved - all done
    if (rowStatus === 'approved') {
      return nodeIdx <= currentIdx ? 'done' : 'skip'
    }

    // budget_approved - all prior nodes done
    if (rowStatus === 'budget_approved') {
      if (nodeKey === 'budget_approved') return 'active'
      if (nodeIdx < currentIdx) return 'done'
      return 'skip'
    }

    // pending states (current step is the active one)
    if (nodeIdx < currentIdx) return 'done'
    if (nodeIdx === currentIdx) return 'active'
    return 'waiting'
  }

  // 工作台统计数据
  const totalProjects = purchaseData.length
  const totalBudget = purchaseData.reduce((s, r) => s + (r.budget || 0), 0)
  const totalContractCount = contractList.length
  const totalContract = contractList.reduce((s, r) => s + r.amount, 0)
  const totalPaid = purchaseData.reduce((s, r) => s + Math.floor((r.budget || 0) * 0.6), 0)
  const pendingPurchase = purchaseData.filter(r => r.status === 'submitted' || r.status === 'unit_pending' || r.status === 'jb_pending').length

  // 合同管理处理函数
  const openContractDetail = (row: any) => {
    setContractDetailData(row)
    setContractDetailOpen(true)
  }
  const openContractEdit = (row: any) => {
    setContractFormMode('edit')
    setContractFormData({
      partyA: row.partyA || '',
      partyB: row.partyB || '华为技术有限公司',
      contractName: row.contractName || '',
      amount: row.amount ? String(row.amount) : '',
      date: row.date || '',
      deliveryDate: row.deliveryDate || '',
      remark: row.remark || '',
      attachment: row.attachment || ''
    })
    setContractFormOpen(true)
  }
  const openContractAdd = () => {
    setContractFormMode('add')
    setContractFormData({
      partyA: '', partyB: '华为技术有限公司', contractName: '', amount: '', date: '', deliveryDate: '', remark: '', attachment: ''
    })
    setContractFormOpen(true)
  }
  const handleDeleteContract = (id: string) => {
    if (confirm('确认删除该合同？')) {
      setContractList(prev => prev.filter(c => c.id !== id))
    }
  }
  const handleSaveContract = () => {
    if (!contractFormData.partyA || !contractFormData.contractName || !contractFormData.amount || !contractFormData.date || !contractFormData.deliveryDate) {
      alert('请填写必填项')
      return
    }
    if (contractFormMode === 'add') {
      const newId = 'HT2024' + String(contractList.length + 1).padStart(3, '0')
      setContractList(prev => [...prev, {
        id: newId,
        partyA: contractFormData.partyA,
        partyB: contractFormData.partyB,
        contractName: contractFormData.contractName,
        amount: Number(contractFormData.amount),
        date: contractFormData.date,
        deliveryDate: contractFormData.deliveryDate,
        status: 'draft',
        applicant: '当前用户',
        attachment: contractFormData.attachment,
        remark: contractFormData.remark
      }])
    } else if (contractDetailData) {
      setContractList(prev => prev.map(c => c.id === contractDetailData.id ? { ...c, ...contractFormData, amount: Number(contractFormData.amount) } : c))
    }
    setContractFormOpen(false)
  }
  const partyAOptions = [
    '省公安厅 / 科信处',
    '省公安厅 / 网安总队',
    '省公安厅 / 刑侦总队',
    '省公安厅 / 治安总队',
    '省公安厅 / 交警总队'
  ]

  // 组织架构辅助函数
  const findOrgNode = (nodes: OrgNode[], id: string): OrgNode | null => {
    for (const n of nodes) {
      if (n.id === id) return n
      if (n.children) {
        const found = findOrgNode(n.children, id)
        if (found) return found
      }
    }
    return null
  }
  const collectOrgNodes = (nodes: OrgNode[]): OrgNode[] => {
    const res: OrgNode[] = []
    nodes.forEach(n => {
      res.push(n)
      if (n.children) res.push(...collectOrgNodes(n.children))
    })
    return res
  }
  const renderOrgTree = (nodes: OrgNode[], depth: number) => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const isExpanded = orgTreeExpanded[node.id] ?? false
      const isMatch = !applyUnitSearch || node.label.toLowerCase().includes(applyUnitSearch.toLowerCase())
      if (!isMatch && hasChildren) {
        const childMatch = collectOrgNodes(node.children || []).some(c => c.label.toLowerCase().includes(applyUnitSearch.toLowerCase()))
        if (!childMatch) return null
      }
      if (!isMatch && !hasChildren) return null
      return (
        <div key={node.id}>
          <div
            className={`flex items-center gap-1 px-2 py-1.5 cursor-pointer hover:bg-blue-50 transition-colors ${applyUnitId === node.id ? 'bg-blue-50 text-blue-600 font-medium' : ''}`}
            style={{ paddingLeft: `${12 + depth * 16}px` }}
            onClick={() => {
              if (hasChildren) {
                setOrgTreeExpanded(prev => ({ ...prev, [node.id]: !isExpanded }))
              }
              setApplyUnitVal(node.label)
              setApplyUnitId(node.id)
              setApplyUnitOpen(false)
            }}
          >
            {hasChildren && (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
            )}
            {!hasChildren && <span className="w-3" />}
            <span className="text-xs">{node.label}</span>
          </div>
          {hasChildren && isExpanded && renderOrgTree(node.children!, depth + 1)}
        </div>
      )
    }).filter(Boolean)
  }
  const fulfillingContract = contractList.filter(r => r.status === 'fulfilling').length
  const pendingOrder = orderData.filter(r => r.status === 'pending_ship').length
  const pendingAcceptance = acceptanceData.filter(r => r.status === 'pending_check').length

  return (
    <div className="p-6 space-y-4">
      {/* 统计卡片 - 所有页面共享 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: '总合同数', value: `${totalContractCount} 个`, color: '#1a4b8c', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
          { label: '总合同金额', value: `¥ ${totalContract.toLocaleString()}`, color: '#1a4b8c', icon: 'M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6' },
          { label: '总企业数', value: `${enterprises.length} 家`, color: '#1a4b8c', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
          { label: '待审核企业数', value: `${enterprises.filter((e: any) => e.auditStatus === 'pending').length} 家`, color: '#d4880f', icon: 'M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
          { label: '待审核商品数', value: `${products.filter((p: any) => p.status === 'review').length} 件`, color: '#1a4b8c', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-xl font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 快捷入口 - 所有页面共享 */}
      <div className="content-card p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { key: 'contract', label: '合同管理', desc: '合同签订与执行', count: fulfillingContract, color: '#1a4b8c', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
            { key: 'order', label: '订单管理', desc: '订单验收与管理', count: pendingOrder, color: '#1a4b8c', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
            { key: 'enterprise', label: '供应商信息', desc: '供应商企业信息', count: 0, color: '#1a4b8c', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5' },
            { key: 'product-review', label: '装备管理', desc: '装备基础信息与审核', count: 0, color: '#1a4b8c', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
            { key: 'penalty', label: '处罚管理', desc: '违规处罚记录', count: 0, color: '#1a4b8c', icon: 'M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
            { key: 'complaint', label: '投诉管理', desc: '投诉举报处理', count: 0, color: '#1a4b8c', icon: 'M18 8h1a4 4 0 010 8h-1M2 8h16v9a4 4 0 01-4 4H6a4 4 0 01-4-4V8zM6 1v3M10 1v3M14 1v3' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => {
                if (item.key === 'contract' || item.key === 'order') {
                  setActiveTab(item.key)
                } else {
                  onNavigate?.('supplier', item.key === 'product-review' ? 'product' : item.key)
                }
              }}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': item.color } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                  <path d={item.icon}/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium flex items-center gap-2">
                  {item.label}
                  {item.count > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full text-xs text-white" style={{ background: item.color }}>{item.count}</span>
                  )}
                </div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* Search area */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              {activeTab === 'purchase' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购单号</label>
                <input className="form-input w-40" placeholder="请输入采购单号..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属项目</label>
                <input className="form-input w-40" placeholder="请输入项目名称..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                <select className="form-input w-32">
                  <option>全部</option>
                  <option>草稿</option>
                  <option>预算批复</option>
                  <option>提交申请</option>
                  <option>单位审批</option>
                  <option>JB部审批</option>
                  <option>审批完成</option>
                  <option>单位驳回</option>
                  <option>JB部驳回</option>
                </select>
              </div>
            </>
          )}
          {activeTab === 'order' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label>
                <input className="form-input w-40" placeholder="请输入装备名称..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                <input className="form-input w-40" placeholder="请输入供应商..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称/合同编号</label>
                <input className="form-input w-44" placeholder="请输入合同信息..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                <select className="form-input w-32">
                  <option>全部</option>
                  <option>待验收</option>
                  <option>部分验收</option>
                  <option>已办结</option>
                </select>
              </div>
            </>
          )}
          {activeTab === 'contract' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同编号</label>
                <input className="form-input w-40" placeholder="请输入..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                <input className="form-input w-40" placeholder="请输入..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                <select className="form-input w-32"><option>全部</option><option>草稿</option><option>履行中</option><option>已验收</option><option>已办结</option></select>
              </div>
            </>
          )}
          {![ 'purchase', 'contract', 'order' ].includes(activeTab) && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关键词</label>
                <input className="form-input w-40" placeholder="请输入关键词..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                <select className="form-input w-32"><option>全部</option><option>待处理</option><option>处理中</option><option>已完成</option></select>
              </div>
            </>
          )}
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>时间范围</label>
            <div className="flex items-center gap-1">
              <input className="form-input w-32" type="date" />
              <span className="text-gray-400">~</span>
              <input className="form-input w-32" type="date" />
            </div>
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {(['contract', 'order', 'purchase'] as string[]).includes(activeTab) && (
            <button
              className="btn-primary flex items-center gap-1"
              onClick={() => {
                if (activeTab === 'order') {
                  setSelectedRow(null)
                  setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }])
                  setOrderModalOpen(true)
                } else if (activeTab === 'contract') {
                  openContractAdd()
                } else {
                  setDrawerTitle(activeTab === 'purchase' ? '新增需求申请' : '')
                  setSelectedRow(null)
                  setDrawerOpen(true)
                }
              }}
            >
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
              {activeTab === 'order' ? '新增采购订单' : `新增${activeTab === 'purchase' ? '申请' : activeTab === 'contract' ? '合同' : ''}`}
            </button>
          )}
          <button className="btn-default flex items-center gap-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            导出
          </button>
        </div>
        <div className="flex items-center gap-1 text-xs">
          <span className="px-3 py-1 rounded-full border" style={{ borderColor: 'var(--border-color)' }}>
            {activeTab === 'purchase' ? '待审批 3' : activeTab === 'contract' ? '执行中 2' : activeTab === 'order' ? '待验收 2' : ''}
          </span>
        </div>
      </div>

      {/* Tables */}
      <div className="content-card overflow-hidden">
        {activeTab === 'purchase' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" className="accent-blue-500" /></th>
                <th>采购单号</th><th>项目名称</th><th>项目类型</th><th>采购预算金额</th><th>申请单位</th><th>经办人</th><th>申请日期</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {purchaseData.map(row => (
                <tr key={row.id}>
                  <td><input type="checkbox" className="accent-blue-500" /></td>
                  <td className="font-mono text-xs">{row.id}</td>
                  <td className="text-xs font-medium">{row.projectName}</td>
                  <td><span className="tag tag-gray">{row.projectType}</span></td>
                  <td className="font-mono">¥{row.budget.toLocaleString()}</td>
                  <td>{row.applyUnit}</td>
                  <td>{row.operator}</td>
                  <td className="text-xs">{row.applyDate}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`需求详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>查看</button>
                      {(row.status === 'draft' || row.status === 'unit_rejected' || row.status === 'jb_rejected') && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`编辑需求申请 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>编辑</button>
                      )}
                      {row.status === 'budget_approved' && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`确认预算批复 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>确认批复</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {activeTab === 'contract' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" /></th>
                <th>甲方</th><th>乙方</th><th>合同名称</th><th>合同金额</th><th>签订日期</th><th>最终交货日期</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {contractList.map(row => (
                <tr key={row.id}>
                  <td><input type="checkbox" /></td>
                  <td>{row.partyA}</td>
                  <td>{row.partyB}</td>
                  <td className="text-sm font-medium">{row.contractName}</td>
                  <td className="font-mono">¥{row.amount.toLocaleString()}</td>
                  <td>{row.date}</td>
                  <td>{row.deliveryDate}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openContractDetail(row)}>查看</button>
                      {row.status === 'draft' && (
                        <>
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openContractEdit(row)}>编辑</button>
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDeleteContract(row.id)}>删除</button>
                        </>
                      )}
                      {row.status === 'fulfilling' && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setOrderConfirmOpen(true)}>填写订单</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {activeTab === 'order' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" /></th>
                <th>订单名称</th><th>关联合同</th><th>供应商</th><th>企业编码</th><th>预计送货日期</th><th>收货对象</th><th>状态</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {orderData.map(row => {
                const totalItems = row.materials.reduce((s: number, i: any) => s + i.qty, 0)
                const checkedItems = row.materials.filter((i: any) => i.checkStatus === 'pass').reduce((s: number, i: any) => s + i.qty, 0)
                const displayStatus: string = checkedItems === totalItems ? 'stored' : checkedItems > 0 ? 'partial_ship' : 'pending_ship'
                const statusLabel = displayStatus === 'pending_ship' ? '待发货' : displayStatus === 'partial_ship' ? '已发货' : '待入库'
                return (
                <tr key={row.id}>
                  <td><input type="checkbox" /></td>
                  <td className="text-sm font-medium">{row.orderName}</td>
                  <td>{row.contractName}</td>
                  <td>{row.supplier}</td>
                  <td className="font-mono text-xs">{row.enterpriseCode}</td>
                  <td>{row.orderDate}</td>
                  <td>{row.shipAddress}</td>
                  <td>{statusLabel} {checkedItems}/{totalItems}</td>
                  <td>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`订单详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>查看</button>
                      {(row.status === 'pending_ship' || row.status === 'partial_ship') && (
                        <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => { setDrawerTitle(`订单验收 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>验收</button>
                      )}
                      {(row.status as string) === 'pending_storage' && (
                        <button className="text-xs hover:underline" style={{ color: '#1890ff' }} onClick={() => { setDrawerTitle(`订单详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true); alert('入库操作：将订单状态变更为已入库') }}>入库</button>
                      )}
                    </div>
                  </td>
                </tr>
              )
            })}</tbody>
          </table>
        )}
        {![ 'purchase', 'contract', 'order' ].includes(activeTab) && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-16 h-16 rounded-full flex items-center justify-center mb-4" style={{ background: '#f5f5f5' }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#bfbfbf" strokeWidth="2">
                <path d="M12 2a10 10 0 100 20 10 10 0 000-20z"/><path d="M12 8v4"/><path d="M12 16h.01"/>
              </svg>
            </div>
            <p className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>功能开发中</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>该模块正在建设中，敬请期待</p>
          </div>
        )}
        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {purchaseData.length} 条</span>
          <div className="flex items-center gap-1">
            {['<', '1', '2', '3', '...', '>'].map((p, i) => (
              <button key={i} className={`w-8 h-8 rounded text-xs flex items-center justify-center transition-all ${p === '1' ? 'text-white' : 'hover:bg-gray-100'}`} style={p === '1' ? { background: 'var(--primary-blue)' } : {}}>{p}</button>
            ))}
            <select className="form-input w-20 text-xs ml-2"><option>20条/页</option><option>50条/页</option><option>100条/页</option></select>
          </div>
        </div>
      </div>

      {/* Sync Log Drawer */}
      {syncLogOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setSyncLogOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">同步日志</h3>
              <button onClick={() => setSyncLogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6">
              {/* Sync status cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {[
                  { name: '采购预算数据', lastSync: '2024-03-15 02:00', status: 'success', count: '156 条', icon: 'M21 4H3a2 2 0 00-2 2v12a2 2 0 002 2h18a2 2 0 002-2V6a2 2 0 00-2-2zm0 14H3V6h18v12zM7 8h10v2H7V8zm0 4h6v2H7v-2z' },
                  { name: '采购预算执行数据', lastSync: '2024-03-15 02:05', status: 'success', count: '89 条', icon: 'M12 20V10M18 20V4M6 20v-4' },
                  { name: '采购文件', lastSync: '2024-03-15 02:10', status: 'partial', count: '34 个文件', icon: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z' },
                ].map(item => (
                  <div key={item.name} className="p-4 rounded-lg border flex items-center gap-4" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: item.status === 'success' ? '#e6f7ff' : '#fffbe6' }}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={item.status === 'success' ? '#1890ff' : '#faad14'} strokeWidth="2">
                        <path d={item.icon}/>
                      </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{item.name}</p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--text-disabled)' }}>上次同步：{item.lastSync}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{item.count}</span>
                        <span className={`tag ${item.status === 'success' ? 'tag-green' : 'tag-yellow'} text-xs`}>{item.status === 'success' ? '同步成功' : '部分异常'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {/* Sync Log Table */}
              <h5 className="text-sm font-medium mb-3">同步执行日志</h5>
              <div className="content-card overflow-hidden">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th className="text-xs">时间</th>
                      <th className="text-xs">模块</th>
                      <th className="text-xs">操作</th>
                      <th className="text-xs">结果</th>
                      <th className="text-xs">详情</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { time: '2024-03-15 02:10:05', module: '采购文件', action: '文件同步', result: 'warning', msg: '3个文件上传失败，已重试' },
                      { time: '2024-03-15 02:05:23', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送89条执行记录' },
                      { time: '2024-03-15 02:00:15', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取156条预算数据' },
                      { time: '2024-03-14 02:08:45', module: '采购文件', action: '文件同步', result: 'success', msg: '成功同步31个文件' },
                      { time: '2024-03-14 02:03:12', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送92条执行记录' },
                      { time: '2024-03-14 01:58:30', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取158条预算数据' },
                      { time: '2024-03-13 02:07:18', module: '采购文件', action: '文件同步', result: 'success', msg: '成功同步28个文件' },
                      { time: '2024-03-13 02:02:05', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送87条执行记录' },
                      { time: '2024-03-13 01:57:42', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取160条预算数据' },
                      { time: '2024-03-12 02:09:33', module: '采购文件', action: '文件同步', result: 'error', msg: '网络超时，同步失败' },
                    ].map((log, i) => (
                      <tr key={i}>
                        <td className="text-xs font-mono" style={{ color: 'var(--text-disabled)' }}>{log.time}</td>
                        <td><span className="tag tag-gray text-xs">{log.module}</span></td>
                        <td className="text-xs" style={{ color: 'var(--text-secondary)' }}>{log.action}</td>
                        <td><span className={`tag ${log.result === 'success' ? 'tag-green' : log.result === 'warning' ? 'tag-yellow' : 'tag-red'} text-xs`}>{log.result === 'success' ? '成功' : log.result === 'warning' ? '异常' : '失败'}</span></td>
                        <td className="text-xs" style={{ color: 'var(--text-primary)' }}>{log.msg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ====== Center Modal (shared) ====== */}
      {drawerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b bg-white flex-shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{drawerTitle}</h3>
              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {activeTab === 'purchase' && (
                <>
                  {/* Section 1: 项目基本信息 */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>项目基本信息</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>项目名称 <span className="text-red-500">*</span></label>
                        <input className="form-input" placeholder="请输入项目名称" defaultValue={selectedRow?.projectName || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>项目类型 <span className="text-red-500">*</span></label>
                        {isDrawerReadOnly ? (
                          <input className="form-input" defaultValue={selectedRow?.projectType || ''} readOnly style={{ background: '#fafafa' }} />
                        ) : (
                          <select className="form-input" defaultValue={selectedRow?.projectType || ''}>
                            <option>货物采购</option>
                            <option>服务采购</option>
                            <option>系统集成</option>
                            <option>工程采购</option>
                            <option>其他</option>
                          </select>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购预算金额 <span className="text-red-500">*</span></label>
                        <input className="form-input font-mono" placeholder="¥" defaultValue={selectedRow ? `¥${selectedRow.budget.toLocaleString()}` : ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div className="relative">
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位 <span className="text-red-500">*</span></label>
                        {isDrawerReadOnly ? (
                          <input className="form-input" defaultValue={selectedRow?.applyUnit || ''} readOnly style={{ background: '#fafafa' }} />
                        ) : (
                          <>
                            <input
                              className="form-input w-full"
                              placeholder="请选择申请单位"
                              value={applyUnitVal}
                              onChange={e => { setApplyUnitVal(e.target.value); setApplyUnitOpen(true); setApplyUnitSearch(e.target.value) }}
                              onFocus={() => setApplyUnitOpen(true)}
                            />
                            {applyUnitOpen && (
                              <>
                                <div className="fixed inset-0 z-[55]" onClick={() => setApplyUnitOpen(false)} />
                                <div className="absolute z-[60] left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-[260px] overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
                                  {renderOrgTree(orgTreeData, 0)}
                                </div>
                              </>
                            )}
                          </>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人</label>
                        <input className="form-input" defaultValue={selectedRow?.operator || '当前用户'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请日期</label>
                        <input className="form-input" defaultValue={selectedRow?.applyDate || new Date().toISOString().slice(0, 10)} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购单号</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.id || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: 项目介绍与论证 */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold flex items-center gap-2 mb-4"><span className="w-1 h-4 rounded-full bg-blue-500"/>项目介绍与论证</h4>
                    <div className="space-y-4">
                      {/* 项目介绍 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>项目介绍 <span className="text-red-400">*</span></label>
                        {isDrawerReadOnly ? (
                          <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>
                            {selectedRow?.projectIntro || '暂无'}
                          </div>
                        ) : (
                          <textarea className="form-input w-full text-sm" rows={3} placeholder="请简要介绍本项目背景、目标及主要内容..." defaultValue={selectedRow?.projectIntro || ''} />
                        )}
                      </div>
                      {/* 项目论证 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>项目论证</label>
                        {isDrawerReadOnly ? (
                          <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>
                            {selectedRow?.projectJustify || '暂无'}
                          </div>
                        ) : (
                          <textarea className="form-input w-full text-sm" rows={3} placeholder="请说明采购的必要性和可行性..." defaultValue={selectedRow?.projectJustify || ''} />
                        )}
                      </div>
                      {/* 附件上传 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>附件上传</label>
                        {isDrawerReadOnly ? (
                          <div className="flex flex-wrap gap-2">
                            {selectedRow?.attachments && selectedRow.attachments.length > 0 ? (
                              selectedRow.attachments.map((att: any, i: number) => (
                                <span key={i} className="tag tag-blue text-xs flex items-center gap-1">
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                                  {att.name}
                                </span>
                              ))
                            ) : (
                              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>未上传附件</span>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center gap-3 flex-wrap">
                            <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: '#d9d9d9' }}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                              <span className="text-xs" style={{ color: '#8c8c8c' }}>上传附件</span>
                              <input type="file" multiple className="hidden" onChange={(e) => {
                                const files = e.target.files
                                if (files && files.length > 0) {
                                  const names = Array.from(files).map(f => f.name).join(', ')
                                  alert(`已选择 ${files.length} 个文件: ${names}`)
                                }
                              }} />
                            </label>
                            <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 PDF、Word、Excel 格式</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Approval Flow - always shown */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <span className="w-1 h-4 rounded-full bg-green-500"/>
                      审批流程
                    </h4>
                    <div className="relative">
                      <div className="flex items-center justify-between">
                        {flowNodes.map((node, i) => {
                          const isNew = !selectedRow
                          const state = getNodeState(node.key, selectedRow?.status || null, isNew)
                          const circleColors: Record<string, { bg: string; border: string; text?: string }> = {
                            done: { bg: '#52c41a', border: '#52c41a' },
                            active: { bg: 'var(--primary-blue)', border: 'var(--primary-blue)' },
                            rejected: { bg: '#ff4d4f', border: '#ff4d4f' },
                            waiting: { bg: '#ffffff', border: '#d9d9d9' },
                            skip: { bg: '#f5f5f5', border: '#d9d9d9' },
                          }
                          const c = circleColors[state]
                          return (
                            <div key={i} className="flex-1 flex flex-col items-center relative">
                              {i > 0 && (
                                <div className="absolute right-1/2 top-5 -translate-y-1/2 h-0.5 w-full" style={{
                                  background: ['done', 'active'].includes(state) ? '#52c41a' : state === 'rejected' ? '#ff4d4f' : '#d9d9d9',
                                }} />
                              )}
                              <div className="relative z-10 w-10 h-10 rounded-full flex items-center justify-center border-2" style={{ background: c.bg, borderColor: c.border }}>
                                {state === 'done' && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
                                {state === 'active' && <span className="text-sm font-bold text-white">{i + 1}</span>}
                                {state === 'rejected' && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>}
                                {state === 'waiting' && <span className="text-sm font-medium" style={{ color: '#8c8c8c' }}>{i + 1}</span>}
                                {state === 'skip' && <span className="text-sm" style={{ color: '#bfbfbf' }}>{i + 1}</span>}
                              </div>
                              <p className={`text-xs font-medium mt-2 ${state === 'done' ? 'text-green-600' : state === 'active' ? 'text-blue-600' : state === 'rejected' ? 'text-red-500' : state === 'skip' ? 'text-gray-400' : 'text-gray-600'}`}>{node.label}</p>
                              <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{node.desc}</p>
                              {state !== 'waiting' && state !== 'skip' && (
                                <p className="text-xs mt-0.5 font-mono" style={{ color: 'var(--text-disabled)' }}>
                                  {node.startTime}{(state === 'done' || state === 'rejected') && node.endTime ? ` ~ ${node.endTime}` : ''}
                                </p>
                              )}
                            </div>
                          )
                        })}
                      </div>
                      {selectedRow && (selectedRow.status === 'unit_rejected' || selectedRow.status === 'jb_rejected') && (
                        <div className="mt-4 p-3 rounded-lg border-l-4" style={{ borderLeftColor: '#ff4d4f', background: '#fff2f0' }}>
                          <p className="text-sm font-medium" style={{ color: '#ff4d4f' }}>驳回原因</p>
                          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{selectedRow.status === 'unit_rejected' ? '预算超支，请重新调整采购数量后再次提交。' : '不符合采购计划，请核实后重新提交。'}</p>
                          <p className="text-xs mt-1 font-mono" style={{ color: 'var(--text-disabled)' }}>驳回人：{selectedRow.status === 'unit_rejected' ? '单位负责人' : 'JB部负责人'}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Section: Budget Approval Upload - only for budget_approved */}
                  {selectedRow?.status === 'budget_approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        预算批复数据
                      </h4>
                      <div className="space-y-4">
                        {/* Status alert */}
                        <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                          <div className="flex items-center gap-2">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span className="text-sm font-medium" style={{ color: '#52c41a' }}>等待预算批复</span>
                          </div>
                          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>系统已提交至财政预算系统，请手动上传批复文件及批复金额</p>
                        </div>
                        {/* Manual input for approval amount */}
                        {!isDrawerReadOnly && (
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批复金额 <span className="text-red-400">*</span></label>
                              <input className="form-input font-mono" placeholder="¥" />
                            </div>
                            <div>
                              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批复文号 <span className="text-red-400">*</span></label>
                              <input className="form-input" placeholder="请输入批复文号" />
                            </div>
                          </div>
                        )}
                        {/* File upload */}
                        <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              <span className="text-sm font-medium">批复文件</span>
                              <span className="text-red-400">*</span>
                            </div>
                            {!isDrawerReadOnly && (
                              <label className="btn-primary text-xs px-3 py-1.5 cursor-pointer flex items-center gap-1">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                上传文件
                                <input type="file" className="hidden" accept=".pdf,.doc,.docx" />
                              </label>
                            )}
                          </div>
                          <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                            <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{isDrawerReadOnly ? '暂无批复文件' : '请上传预算批复文件（PDF/Word）'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Section: Budget Execution Data - only for approved */}
                  {selectedRow?.status === 'approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        采购预算执行数据
                      </h4>
                      <div className="space-y-3">
                        {/* Budget summary cards */}
                        <div className="grid grid-cols-3 gap-3">
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#f6ffed' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>项目总预算</p>
                            <p className="text-sm font-mono font-medium mt-1">¥{selectedRow.totalBudget.toLocaleString()}</p>
                          </div>
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#e6f7ff' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已执行金额</p>
                            <p className="text-sm font-mono font-medium mt-1">¥{Math.round(selectedRow.totalBudget * selectedRow.executionRate / 100).toLocaleString()}</p>
                          </div>
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fff7e6' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已支付金额</p>
                            <p className="text-sm font-mono font-medium mt-1" style={{ color: '#fa8c16' }}>¥{selectedRow.paidAmount.toLocaleString()}</p>
                          </div>
                        </div>
                        {/* Execution rate progress */}
                        <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>预算执行率</span>
                            <span className="text-xs font-mono font-medium">{selectedRow.executionRate}%</span>
                          </div>
                          <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                            <div className="h-full rounded-full" style={{ width: `${selectedRow.executionRate}%`, background: selectedRow.executionRate > 80 ? '#ff4d4f' : 'var(--primary-blue)' }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Section: Purchase Files - only for approved */}
                  {selectedRow?.status === 'approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        采购文件
                      </h4>
                      <div className="space-y-2">
                        {[
                          { name: '预算批复文件.pdf', type: '批复文件', date: '2024-03-05', size: '1.2 MB' },
                          { name: '需求申请表.docx', type: '申请文件', date: '2024-03-01', size: '856 KB' },
                          { name: '招标文件.pdf', type: '招标文件', date: '2024-03-08', size: '3.5 MB' },
                        ].map((file, i) => (
                          <div key={i} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0" style={{ background: '#e6f7ff' }}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              </div>
                              <div>
                                <p className="text-sm font-medium">{file.name}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="tag tag-gray text-xs">{file.type}</span>
                                  <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{file.size}</span>
                                  <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{file.date}</span>
                                </div>
                              </div>
                            </div>
                            <button className="btn-default text-xs px-2 py-1">下载</button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
              {activeTab === 'contract' && (
                <div className="space-y-5">
                  {/* Section 1: Contract Basic Info */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>合同基本信息</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同单号 #</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.id || 'HT2024003'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称 <span className="text-red-400">*</span></label>
                        <input className="form-input" placeholder="请输入合同名称" defaultValue={selectedRow?.name || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同金额 <span className="text-red-400">*</span></label>
                        <input className="form-input font-mono" placeholder="¥" defaultValue={selectedRow ? `¥${selectedRow.amount.toLocaleString()}` : ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>乙方 <span className="text-red-400">*</span></label>
                        <input className="form-input" placeholder="请输入乙方名称" defaultValue={selectedRow?.supplier || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>签订日期 <span className="text-red-400">*</span></label>
                        <input className="form-input" type="date" defaultValue={selectedRow?.signDate || '2024-03-01'} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Order Details */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单明细</h4>
                    <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                      {selectedRow?.orderDetails ? (
                        <div className="space-y-2 text-sm">
                          {selectedRow.orderDetails.map((item: any, i: number) => (
                            <div key={i} className="flex justify-between py-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
                              <span>{item.name} ({item.spec}) x{item.qty}{item.unit}</span>
                              <span className="font-mono">¥{item.price.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-center" style={{ color: 'var(--text-disabled)' }}>暂无订单明细</p>
                      )}
                    </div>
                  </div>

                  {/* Section 3: Linked Purchase */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>关联采购</h4>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联采购项目</label>
                      <div className="relative">
                        <input
                          className="form-input w-full"
                          placeholder="搜索采购项目..."
                          value={linkedPurchase ? approvedPurchases.find(p => p.id === linkedPurchase)?.project || linkedPurchase : ''}
                          onFocus={() => setPurchaseDropdownOpen(true)}
                          onBlur={() => setTimeout(() => setPurchaseDropdownOpen(false), 150)}
                          onChange={e => { setLinkedPurchase(e.target.value); setPurchaseDropdownOpen(true) }}
                          style={{ paddingRight: 28, background: isDrawerReadOnly ? '#fafafa' : undefined }}
                          readOnly={isDrawerReadOnly}
                        />
                        {purchaseDropdownOpen && !isDrawerReadOnly && (
                          <div className="absolute left-0 right-0 top-full mt-1 rounded-lg border shadow-lg z-50 max-h-48 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            {approvedPurchases.filter(p => p.project.toLowerCase().includes((linkedPurchase || '').toLowerCase()) || p.id.toLowerCase().includes((linkedPurchase || '').toLowerCase())).map(p => (
                              <div key={p.id} className="px-3 py-2 hover:bg-blue-50 cursor-pointer flex items-center justify-between" onClick={() => { setLinkedPurchase(p.id); setPurchaseDropdownOpen(false) }}>
                                <span className="text-sm">{p.project}</span>
                                <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>¥{p.amount.toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Section 4: Remarks */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>备注</h4>
                    {isDrawerReadOnly ? (
                      <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>{selectedRow?.remarks || '暂无备注'}</div>
                    ) : (
                      <textarea className="form-input w-full text-sm" rows={3} placeholder="请输入备注信息..." defaultValue={selectedRow?.remarks || ''} />
                    )}
                  </div>

                  {/* Section 5: Attachments */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>附件</h4>
                      {!isDrawerReadOnly && (
                        <label className="btn-primary text-xs px-3 py-1.5 cursor-pointer flex items-center gap-1">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                          上传附件
                          <input type="file" className="hidden" multiple onChange={e => {
                            const files = e.target.files
                            if (files) {
                              const newFiles = Array.from(files).map(f => ({
                                id: Math.random().toString(36).substring(2, 10),
                                name: f.name,
                                size: f.size > 1024 * 1024 ? (f.size / (1024 * 1024)).toFixed(2) + ' MB' : (f.size / 1024).toFixed(1) + ' KB'
                              }))
                              setContractFiles(prev => [...prev, ...newFiles])
                            }
                          }} />
                        </label>
                      )}
                    </div>
                    {contractFiles.length === 0 ? (
                      <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                        <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>暂无附件</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {contractFiles.map(f => (
                          <div key={f.id} className="flex items-center justify-between p-2 rounded border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                            <div className="flex items-center gap-2">
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              <span className="text-sm">{f.name}</span>
                              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>({f.size})</span>
                            </div>
                            {!isDrawerReadOnly && (
                              <button className="text-red-400 hover:text-red-600 transition-colors" onClick={() => setContractFiles(prev => prev.filter(file => file.id !== f.id))}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
              {activeTab === 'order' && (
                <div className="space-y-5">
                  {/* Section 1: Order Basic Info */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本信息</h4>
                    <div className={`grid gap-4 ${(drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) ? 'grid-cols-3' : 'grid-cols-2'}`}>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>订单名称</label>
                        <input className="form-input" defaultValue={selectedRow?.orderName || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联合同</label>
                        <input className="form-input" defaultValue={selectedRow?.contractName || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                        <input className="form-input" defaultValue={selectedRow?.supplier || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业编码</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.enterpriseCode || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>预计送货日期</label>
                        <input className="form-input" defaultValue={selectedRow?.deliveryDate || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>收货对象</label>
                        <input className="form-input" defaultValue={selectedRow?.receiver || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Equipment Info Table */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>装备信息</h4>
                    <div className="grid gap-1 px-2 py-1.5 text-xs font-medium rounded-t-lg" style={{ background: 'var(--card-header-bg)', gridTemplateColumns: (drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) ? 'minmax(80px,1fr) minmax(80px,1fr) minmax(80px,1fr) minmax(120px,1fr) minmax(80px,1fr) minmax(100px,1fr) 56px 70px 48px 80px' : '28px minmax(120px,1fr) minmax(100px,1fr) 48px 36px 56px 70px minmax(60px,0.8fr) 80px' }}>
                      {(drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) ? (
                        <>
                          <span>一级分类</span>
                          <span>二级分类</span>
                          <span>三级分类</span>
                          <span>装备名称</span>
                          <span>型号</span>
                          <span>装备编码</span>
                          <span className="text-center">计量单位</span>
                          <span className="text-right">单价</span>
                          <span className="text-center">数量</span>
                          <span className="text-right">金额</span>
                        </>
                      ) : (
                        <>
                          <span>#</span>
                          <span>物资名称 <span className="text-red-400">*</span></span>
                          <span>规格型号</span>
                          <span className="text-center">数量 <span className="text-red-400">*</span></span>
                          <span className="text-center">单位</span>
                          <span className="text-right">单价 <span className="text-red-400">*</span></span>
                          <span className="text-right">总价 #</span>
                          <span>备注</span>
                          <span className="text-center">{selectedRow ? '验收' : '操作'}</span>
                        </>
                      )}
                    </div>
                    <div className="space-y-1 max-h-[480px] overflow-y-auto pr-1">
                      {(selectedRow?.items || lineItems).map((item: any, idx: number) => (
                        <div key={item.id} className="grid gap-1 px-2 py-1.5 items-center rounded text-xs" style={{ background: idx % 2 === 0 ? '#fff' : 'var(--content-bg)', gridTemplateColumns: (drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) ? 'minmax(80px,1fr) minmax(80px,1fr) minmax(80px,1fr) minmax(120px,1fr) minmax(80px,1fr) minmax(100px,1fr) 56px 70px 48px 80px' : '28px minmax(120px,1fr) minmax(100px,1fr) 48px 36px 56px 70px minmax(60px,0.8fr) 80px' }}>
                          {(drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) ? (
                            <>
                              <span>{item.category1 || '-'}</span>
                              <span>{item.category2 || '-'}</span>
                              <span>{item.category3 || '-'}</span>
                              <span className="font-medium">{item.name}</span>
                              <span>{item.model || item.spec || '-'}</span>
                              <span className="font-mono text-xs">{item.code || '-'}</span>
                              <span className="text-center">{item.unit || '台'}</span>
                              <span className="font-mono text-right">¥{(item.price || 0).toLocaleString()}</span>
                              <span className="text-center">{item.qty || 0}</span>
                              <span className="font-mono font-semibold text-right" style={{ color: 'var(--primary-blue)' }}>¥{(item.amount || 0).toLocaleString()}</span>
                            </>
                          ) : (
                            <>
                              <span className="font-medium" style={{ color: 'var(--text-disabled)' }}>{idx + 1}</span>
                              <input className="form-input text-xs py-1 w-full" defaultValue={item.name} placeholder="装备名称" readOnly={!!selectedRow} />
                              <input className="form-input text-xs py-1 w-full" defaultValue={item.spec} placeholder="规格型号" readOnly={!!selectedRow} />
                              <input className="form-input text-xs py-1 font-mono text-center w-full" type="number" min={0} defaultValue={item.qty || ''} readOnly={!!selectedRow} />
                              {selectedRow ? (
                                <input className="form-input text-xs py-1 text-center w-full" defaultValue={item.unit || '台'} readOnly />
                              ) : (
                                <select className="form-input text-xs py-1 w-full text-center" defaultValue={item.unit || '台'}>
                                  <option>台</option><option>套</option><option>件</option><option>个</option>
                                </select>
                              )}
                              <input className="form-input text-xs py-1 font-mono text-right w-full" type="number" min={0} defaultValue={item.price || ''} readOnly={!!selectedRow} />
                              <span className="font-mono font-semibold text-right" style={{ color: 'var(--primary-blue)' }}>¥{(item.amount || 0).toLocaleString()}</span>
                              <input className="form-input text-xs py-1 w-full" defaultValue={item.note || ''} placeholder="备注" readOnly={!!selectedRow} />
                              {selectedRow ? (
                                item.checkStatus === 'pass' ? (
                                  <div className="flex items-center justify-center">
                                    <button className="px-2 py-0.5 rounded text-xs border transition-colors hover:bg-blue-50" style={{ color: '#1890ff', borderColor: '#91caff' }} onClick={() => { setAcceptForm({ itemName: item.name, itemId: item.id, result: 'pass', opinion: item.checkDetail?.opinion || '', checker: item.checkDetail?.checker || '当前用户', checkTime: item.checkDetail?.checkTime || new Date().toISOString().slice(0, 16), handleWay: item.checkDetail?.handleWay || '', qualifiedQty: item.checkDetail?.qualifiedQty || '', unqualifiedRfids: item.checkDetail?.unqualifiedRfids || [], totalQty: item.qty || 1 }); setAcceptViewMode(true); setAcceptModalOpen(true) }}>详情</button>
                                  </div>
                                ) : (
                                  <div className="flex items-center gap-1 justify-center">
                                    <button className="px-1.5 py-0.5 rounded text-xs border transition-colors hover:bg-green-50" style={{ color: '#52c41a', borderColor: '#b7eb8f' }} onClick={() => { setAcceptForm({ itemName: item.name, itemId: item.id, result: 'pass', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '', qualifiedQty: '', unqualifiedRfids: [], totalQty: item.qty || 1 }); setAcceptViewMode(false); setAcceptModalOpen(true) }}>合格</button>
                                    <button className="px-1.5 py-0.5 rounded text-xs border transition-colors hover:bg-red-50" style={{ color: '#ff4d4f', borderColor: '#ffa39e' }} onClick={() => { setAcceptForm({ itemName: item.name, itemId: item.id, result: 'fail', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '', qualifiedQty: '', unqualifiedRfids: [], totalQty: item.qty || 1 }); setAcceptViewMode(false); setAcceptModalOpen(true) }}>不合格</button>
                                  </div>
                                )
                              ) : lineItems.length > 1 && (
                                <button onClick={() => removeLineItem(item.id)} className="text-red-400 hover:text-red-600 transition-colors text-center">
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      ))}
                    </div>
                    <div className="flex items-center justify-end gap-4 mt-3 pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {(selectedRow?.items || lineItems).length} 件装备</span>
                      <span className="text-sm font-semibold">合计金额：<span className="font-mono" style={{ color: 'var(--primary-blue)' }}>¥{(selectedRow?.items || lineItems).reduce((s: number, it: any) => s + (it.amount || 0), 0).toLocaleString()}</span></span>
                    </div>
                  </div>

                  {/* Section 3: Equipment Acceptance (only in acceptance mode) */}
                  {drawerTitle.startsWith('订单验收') && selectedRow && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>装备验收</h4>
                        <div className="flex items-center gap-2">
                          <button className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 12h8M12 8v8"/></svg>
                            RFID扫描
                          </button>
                          <button className="btn-default text-xs px-3 py-1.5 flex items-center gap-1">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                            导入Excel
                          </button>
                          <button className="btn-default text-xs px-3 py-1.5 flex items-center gap-1" onClick={() => setReceiptPreviewOpen(true)}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                            收货单打印
                          </button>
                          <button className="btn-default text-xs px-3 py-1.5 flex items-center gap-1" onClick={() => setReturnPreviewOpen(true)}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 14L4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 015.5 5.5v0a5.5 5.5 0 01-5.5 5.5H11"/></svg>
                            退货单打印
                          </button>
                        </div>
                      </div>
                      <div className="grid gap-1 px-2 py-1.5 text-xs font-medium rounded-t-lg" style={{ background: 'var(--card-header-bg)', gridTemplateColumns: '36px minmax(120px,1fr) minmax(100px,1fr) 48px 80px 120px' }}>
                        <span className="text-center">#</span>
                        <span className="text-center">装备名称</span>
                        <span className="text-center">规格型号</span>
                        <span className="text-center">数量</span>
                        <span className="text-center">RFID编码</span>
                        <span className="text-center">验收</span>
                      </div>
                      <div className="space-y-1">
                        {selectedRow.items.map((item: any, idx: number) => {
                          const isExpanded = expandedRfidRows.includes(idx)
                          const rfids = rfidMap[item.id] || Array(item.qty || 1).fill('')
                          return (
                            <div key={item.id}>
                              {/* 主行 */}
                              <div className="grid gap-1 px-2 py-1.5 items-center rounded text-xs" style={{ background: idx % 2 === 0 ? '#fff' : 'var(--content-bg)', gridTemplateColumns: '36px minmax(120px,1fr) minmax(100px,1fr) 48px 80px 120px' }}>
                                <span className="text-center font-medium" style={{ color: 'var(--text-disabled)' }}>{idx + 1}</span>
                                <span className="text-center">{item.name}</span>
                                <span className="text-center">{item.spec || '-'}</span>
                                <span className="text-center">{item.qty || 0}</span>
                                <div className="text-center">
                                  <button
                                    className="text-xs px-2 py-0.5 rounded border transition-colors hover:bg-blue-50"
                                    style={{ color: '#1a4b8c', borderColor: '#b8c8db' }}
                                    onClick={() => setExpandedRfidRows(prev => prev.includes(idx) ? prev.filter(i => i !== idx) : [...prev, idx])}
                                  >
                                    {isExpanded ? '收起' : `展开(${item.qty || 0})`}
                                  </button>
                                </div>
                                <div className="flex items-center gap-1 justify-center">
                                  <button className="px-2 py-0.5 rounded text-xs border transition-colors hover:bg-green-50" style={{ color: '#52c41a', borderColor: '#b7eb8f' }} onClick={() => { setAcceptForm({ itemName: item.name, itemId: item.id, result: 'pass', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '', qualifiedQty: '', unqualifiedRfids: [], totalQty: item.qty || 1 }); setAcceptViewMode(false); setAcceptModalOpen(true) }}>合格</button>
                                  <button className="px-2 py-0.5 rounded text-xs border transition-colors hover:bg-red-50" style={{ color: '#ff4d4f', borderColor: '#ffa39e' }} onClick={() => { setAcceptForm({ itemName: item.name, itemId: item.id, result: 'fail', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '', qualifiedQty: '', unqualifiedRfids: [], totalQty: item.qty || 1 }); setAcceptViewMode(false); setAcceptModalOpen(true) }}>不合格</button>
                                </div>
                              </div>
                              {/* 展开行 - RFID编码列表 */}
                              {isExpanded && (
                                <div className="mx-2 mb-2 p-2 rounded border" style={{ background: '#f8fafc', borderColor: '#e2e8f0' }}>
                                  <div className="flex items-center justify-between mb-2">
                                    <div className="flex items-center gap-2">
                                      <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>RFID编码列表（{rfids.filter(r => r).length}/{item.qty || 0}）</span>
                                      {rfidCompareMap[item.id] && (
                                        <span className="text-[10px] px-2 py-0.5 rounded-full font-medium" style={{ background: '#e8f5e9', color: '#2e7d32' }}>
                                          ✅{rfidCompareMap[item.id].match.length} ⚠️{rfidCompareMap[item.id].extra.length} ❌{rfidCompareMap[item.id].missing.length}
                                        </span>
                                      )}
                                    </div>
                                    <button
                                      className="btn-primary text-xs px-2 py-0.5 flex items-center gap-1"
                                      onClick={() => {
                                        const newRfids = rfids.map(() => {
                                          let r = ''
                                          for (let i = 0; i < 4; i++) r += Math.floor(1000000000 + Math.random() * 9000000000).toString()
                                          return r.slice(0, 32)
                                        })
                                        setRfidMap(prev => ({ ...prev, [item.id]: newRfids }))
                                        // RFID到货一致性校验
                                        const orderRow = selectedRow
                                        const materialCode = item.code
                                        const originalRfids: string[] = []
                                        if (orderRow && orderRow.deliveryList) {
                                          orderRow.deliveryList.forEach((d: any) => {
                                            if (d.materials) {
                                              d.materials.forEach((m: any) => {
                                                if (m.code === materialCode && m.rfid) {
                                                  originalRfids.push(...m.rfid)
                                                }
                                              })
                                            }
                                          })
                                        }
                                        if (originalRfids.length > 0) {
                                          const originalSet = new Set(originalRfids)
                                          const scanSet = new Set(newRfids)
                                          const match = newRfids.filter((r: string) => originalSet.has(r))
                                          const extra = newRfids.filter((r: string) => !originalSet.has(r))
                                          const missing = originalRfids.filter((r: string) => !scanSet.has(r))
                                          setRfidCompareMap(prev => ({ ...prev, [item.id]: { match, extra, missing } }))
                                        }
                                      }}
                                    >
                                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 12h2M8 16h2M8 8h2M14 8h2M14 12h2M14 16h2"/></svg>
                                      扫描填充
                                    </button>
                                  </div>
                                  {(() => {
                                    const qualifiedList = unqualifiedRfidMap[item.id] || []
                                    // 只有当该装备已做过合格确认（unqualifiedRfidMap中有数据），才显示不合格标记
                                    const hasChecked = item.id in unqualifiedRfidMap
                                    return (
                                      <>
                                      <div className="grid grid-cols-2 gap-2">
                                        {rfids.map((rfid, ridx) => {
                                          // 已验收且RFID有值且不在合格列表中 = 不合格
                                          const isUnqualified = hasChecked && !!(rfid && !qualifiedList.includes(rfid))
                                          // RFID到货一致性标记
                                          const compare = rfidCompareMap[item.id]
                                          const compareStatus = !compare || !rfid ? null : compare.match.includes(rfid) ? 'match' : compare.extra.includes(rfid) ? 'extra' : null
                                          return (
                                            <div key={ridx} className="flex items-center gap-2">
                                              <span className="text-xs w-5 text-right" style={{ color: 'var(--text-disabled)' }}>{ridx + 1}.</span>
                                              <div className="relative flex-1">
                                                <input
                                                  className={`form-input text-xs py-1 w-full font-mono ${isUnqualified ? 'bg-red-50 line-through text-red-400' : compareStatus === 'match' ? 'border-green-400 bg-green-50' : compareStatus === 'extra' ? 'border-yellow-400 bg-yellow-50' : ''}`}
                                                  value={rfid}
                                                  onChange={e => {
                                                    if (isUnqualified) return
                                                    const newRfids = [...rfids]
                                                    newRfids[ridx] = e.target.value
                                                    setRfidMap(prev => ({ ...prev, [item.id]: newRfids }))
                                                  }}
                                                  placeholder={isUnqualified ? '不合格' : '点击左侧图标扫描'}
                                                  maxLength={32}
                                                  readOnly={isUnqualified}
                                                />
                                                {!isUnqualified && rfid && (
                                                  <button
                                                    type="button"
                                                    className="absolute right-1 top-1/2 -translate-y-1/2 z-10 p-0.5 rounded hover:bg-red-50"
                                                    onClick={(e) => {
                                                      e.preventDefault()
                                                      e.stopPropagation()
                                                      const newRfids = [...rfids]
                                                      newRfids[ridx] = ''
                                                      setRfidMap(prev => ({ ...prev, [item.id]: newRfids }))
                                                    }}
                                                    title="删除RFID"
                                                  >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                                                  </button>
                                                )}
                                                {!isUnqualified && !rfid && (
                                                  <button
                                                    type="button"
                                                    className="absolute right-1 top-1/2 -translate-y-1/2 z-10 p-0.5 rounded hover:bg-blue-50"
                                                    onClick={(e) => {
                                                      e.preventDefault()
                                                      e.stopPropagation()
                                                      let newRfid = ''
                                                      for (let i = 0; i < 4; i++) newRfid += Math.floor(1000000000 + Math.random() * 9000000000).toString()
                                                      const newRfids = [...rfids]
                                                      newRfids[ridx] = newRfid.slice(0, 32)
                                                      setRfidMap(prev => ({ ...prev, [item.id]: newRfids }))
                                                    }}
                                                    title="扫描RFID"
                                                  >
                                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#1a4b8c" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 12h2M8 16h2M8 8h2M14 8h2M14 12h2M14 16h2"/></svg>
                                                  </button>
                                                )}
                                                {isUnqualified && (
                                                  <span className="absolute right-1 top-1/2 -translate-y-1/2 z-10 px-1.5 py-0.5 rounded text-xs font-medium bg-red-100 text-red-600 border border-red-200">
                                                    不合格
                                                  </span>
                                                )}
                                              </div>
                                            </div>
                                          )
                                        })}
                                      </div>
                                      {/* 缺失RFID显示 */}
                                      {rfidCompareMap[item.id]?.missing && rfidCompareMap[item.id]!.missing.length > 0 && (
                                        <div className="mt-2 p-2 rounded border" style={{ background: '#fef2f2', borderColor: '#fecaca' }}>
                                          <div className="flex items-center gap-1 mb-1.5">
                                            <span className="text-xs font-medium" style={{ color: '#dc2626' }}>未到货RFID（{rfidCompareMap[item.id].missing.length}条）</span>
                                            <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: '#fee2e2', color: '#991b1b' }}>来自发货清单</span>
                                          </div>
                                          <div className="grid grid-cols-2 gap-1.5">
                                            {rfidCompareMap[item.id].missing.map((r: string, mIdx: number) => (
                                              <div key={mIdx} className="flex items-center gap-1.5 px-2 py-1 rounded text-xs border" style={{ background: '#fff', borderColor: '#fecaca', color: '#dc2626' }}>
                                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#dc2626" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
                                                <span className="font-mono truncate">{r}</span>
                                              </div>
                                            ))}
                                          </div>
                                        </div>
                                      )}
                                    </>
                                    )
                                  })()}
                                </div>
                              )}
                            </div>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  {/* Section 4: Equipment Coding (view mode only) */}
                  {!(drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) && selectedRow && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>装备编码</h4>
                      <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span className="text-sm font-medium" style={{ color: '#52c41a' }}>编码已自动生成</span>
                          </div>
                          <button className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            导出编码
                          </button>
                        </div>
                        <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>订单创建时装备编码已自动生成，可直接导出使用。</p>
                        <div className="space-y-1">
                          {selectedRow?.items?.filter((i: any) => i.code).map((item: any, idx: number) => (
                            <div key={idx} className="flex items-center gap-2 text-xs py-0.5">
                              <span style={{ color: 'var(--text-secondary)' }}>{item.name}:</span>
                              <span className="font-mono font-medium">{item.code}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Section 5: Shipping Status (view mode only) */}
                  {!(drawerTitle.startsWith('订单验收') || drawerTitle.startsWith('订单详情')) && selectedRow && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>发货状态</h4>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`tag ${statusMap[selectedRow.status]?.tag}`}>{statusMap[selectedRow.status]?.label}</span>
                          {(selectedRow.status as any) === 'stored' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>全部装备已入库</span>}
                          {(selectedRow.status as any) === 'pending_storage' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>全部装备已完成验收，待入库</span>}
                          {(selectedRow.status as any) === 'partial_ship' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>部分装备已验收，剩余待验收</span>}
                          {(selectedRow.status as any) === 'pending_ship' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>装备待验收</span>}
                        </div>
                        <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                          <div className="h-full rounded-full" style={{
                            width: `${(selectedRow.status as any) === 'stored' || (selectedRow.status as any) === 'pending_storage' ? 100 : (selectedRow.status as any) === 'partial_ship' ? 50 : 0}%`,
                            background: (selectedRow.status as any) === 'stored' ? '#52c41a' : (selectedRow.status as any) === 'pending_storage' ? '#faad14' : 'var(--primary-blue)'
                          }} />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white flex-shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              {isDrawerReadOnly ? (
                <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>关闭</button>
              ) : activeTab === 'contract' ? (
                <>
                  <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setContractName(''); setLinkedPurchase(''); setSupplierSearch(''); setContractFiles([]) }}>取消</button>
                  <button className="btn-default">保存</button>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary" onClick={() => setOrderConfirmOpen(true)}>填写订单</button>
                </>
              ) : activeTab === 'order' ? (
                drawerTitle.startsWith('订单验收') ? (
                  <>
                    <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>取消</button>
                    <button className="btn-primary" onClick={() => { alert('验收结果已提交，订单状态已更新。'); setDrawerOpen(false); setSelectedRow(null) }}>确认通过</button>
                    <button className="btn-primary" onClick={() => setStorageConfirmOpen(true)}>入库</button>
                  </>
                ) : drawerTitle.startsWith('订单详情') ? (
                  <>
                    <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>关闭</button>
                  </>
                ) : (
                  <>
                    <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>取消</button>
                    <button className="btn-default">保存</button>
                    <button className="btn-default">保存草稿</button>
                    <label className="btn-primary flex items-center gap-1 cursor-pointer">
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      导入Excel
                      <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={() => alert('导入Excel功能开发中...')} />
                    </label>
                  </>
                )
              ) : (
                <>
                  <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]) }}>取消</button>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed" disabled={totalAmount <= 0}>提交</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Order Modal (Popup) */}
      {orderModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-start justify-center pt-10">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOrderModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增采购订单</h3>
              <button onClick={() => setOrderModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
              {/* Section 1: Basic Info */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>订单名称 <span className="text-red-400">*</span></label>
                    <input className="form-input text-xs w-full" placeholder="请输入订单名称" />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联合同 <span className="text-red-400">*</span></label>
                    <select className="form-input text-xs w-full">
                      <option value="">请选择合同</option>
                      {contractData.map(c => <option key={c.id} value={c.id}>{c.contractName}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商（自动填入）</label>
                    <input className="form-input text-xs w-full" defaultValue="华为技术有限公司" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商企业编码（自动填入）</label>
                    <input className="form-input text-xs w-full font-mono" defaultValue="001234567" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>预计送货日期 <span className="text-red-400">*</span></label>
                    <input className="form-input text-xs w-full" type="date" />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>收货对象 <span className="text-red-400">*</span></label>
                    <select className="form-input text-xs w-full">
                      <option value="">请选择收货对象</option>
                      <option>省公安厅 / 科信处</option>
                      <option>省公安厅 / 网安总队</option>
                      <option>省公安厅 / 刑侦总队</option>
                      <option>省公安厅 / 治安总队</option>
                      <option>省公安厅 / 交警总队</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Section 2: Equipment Info */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold flex items-center gap-2 text-sm"><span className="w-1 h-4 rounded-full bg-blue-500"/>装备信息</h4>
                  <button onClick={() => { setEquipSelectOpen(true); setEquipC1('全部'); setEquipC2('全部'); setEquipC3('全部'); setEquipNameSearch(''); setSelectedEquips([]) }} className="btn-primary text-xs px-2 py-1 flex items-center gap-1">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    添加装备
                  </button>
                </div>

                {lineItems.filter(i => i.name).length === 0 ? (
                  <div className="text-center py-10 rounded-lg border border-dashed" style={{ borderColor: 'var(--border-color)' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>暂无装备信息，点击'添加装备'按钮添加</span>
                  </div>
                ) : (
                  <>
                    {/* Table Header */}
                    <div className="grid gap-1 px-2 py-1.5 text-xs font-medium rounded-t-lg" style={{ background: 'var(--card-header-bg)', gridTemplateColumns: '28px minmax(100px,1fr) minmax(80px,1fr) 48px 36px 56px 64px minmax(60px,1fr) 60px' }}>
                      <span>#</span>
                      <span>物资名称 <span className="text-red-400">*</span></span>
                      <span>规格型号</span>
                      <span className="text-center">数量 <span className="text-red-400">*</span></span>
                      <span className="text-center">单位</span>
                      <span className="text-right">单价 <span className="text-red-400">*</span></span>
                      <span className="text-right">总价 #</span>
                      <span>备注</span>
                      <span className="text-center">操作</span>
                    </div>

                    {/* Table Body */}
                    <div className="space-y-1 max-h-[200px] overflow-y-auto pr-1">
                      {lineItems.filter(i => i.name).map((item, idx) => (
                        <div key={item.id} className="grid gap-1 px-2 py-1 items-center rounded text-xs" style={{ background: idx % 2 === 0 ? '#fff' : 'var(--content-bg)', gridTemplateColumns: '28px minmax(100px,1fr) minmax(80px,1fr) 48px 36px 56px 64px minmax(60px,1fr) 60px' }}>
                          <span className="font-medium" style={{ color: 'var(--text-disabled)' }}>{idx + 1}</span>
                          <input className="form-input text-xs py-1 w-full" value={item.name} onChange={e => updateLineItem(item.id, 'name', e.target.value)} placeholder="物资名称" />
                          <input className="form-input text-xs py-1 w-full" value={item.spec} onChange={e => updateLineItem(item.id, 'spec', e.target.value)} placeholder="规格型号" />
                          <input className="form-input text-xs py-1 font-mono text-center w-full" type="number" min={0} value={item.qty || ''} onChange={e => updateLineItem(item.id, 'qty', Number(e.target.value))} />
                          <select className="form-input text-xs py-1 w-full text-center" value={item.unit} onChange={e => updateLineItem(item.id, 'unit', e.target.value)}>
                            <option>台</option><option>套</option><option>件</option><option>个</option>
                          </select>
                          <input className="form-input text-xs py-1 font-mono text-right w-full" type="number" min={0} value={item.price || ''} onChange={e => updateLineItem(item.id, 'price', Number(e.target.value))} />
                          <span className="font-mono font-semibold text-right" style={{ color: 'var(--primary-blue)' }}>¥{item.amount.toLocaleString()}</span>
                          <input className="form-input text-xs py-1 w-full" value={item.remark || ''} onChange={e => updateLineItem(item.id, 'remark', e.target.value)} placeholder="备注" />
                          <div className="text-center">
                            <button onClick={() => removeLineItem(item.id)} className="text-red-400 hover:text-red-600 transition-colors">
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Summary */}
                    <div className="flex items-center justify-end gap-4 mt-3 pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {lineItems.filter(i => i.name).length} 件装备</span>
                      <span className="text-sm font-semibold">合计：<span className="font-mono" style={{ color: 'var(--primary-blue)' }}>¥{totalAmount.toLocaleString()}</span></span>
                    </div>
                  </>
                )}
              </div>

            </div>

            {/* Modal Footer */}
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => { setOrderModalOpen(false); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]); setOrderSupplier(''); setOrderSupplierOpen(false) }}>取消</button>
              <button className="btn-primary text-xs">提交</button>
            </div>
          </div>
        </div>
      )}
      {/* Equip Select Modal */}
      {equipSelectOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEquipSelectOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">选择装备</h3>
              <button onClick={() => setEquipSelectOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Body - 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：装备信息 */}
              <div className="flex-1 flex flex-col border-r" style={{ borderColor: 'var(--border-color)' }}>
                {/* 搜索区域 */}
                <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="text-sm font-semibold mb-3">装备信息</h4>
                  <div className="flex flex-wrap items-end gap-3">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>一级分类</label>
                      <select className="form-input w-32 text-xs" value={equipC1} onChange={e => { setEquipC1(e.target.value); setEquipC2('全部'); setEquipC3('全部') }}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.map(e => e.category1))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>二级分类</label>
                      <select className="form-input w-36 text-xs" value={equipC2} onChange={e => { setEquipC2(e.target.value); setEquipC3('全部') }}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.filter(e => equipC1 === '全部' || e.category1 === equipC1).map(e => e.category2))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>三级分类</label>
                      <select className="form-input w-32 text-xs" value={equipC3} onChange={e => setEquipC3(e.target.value)}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.filter(e => (equipC1 === '全部' || e.category1 === equipC1) && (equipC2 === '全部' || e.category2 === equipC2)).map(e => e.category3))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称/编码</label>
                      <input className="form-input w-40 text-xs" placeholder="装备名称/装备编码" value={equipNameSearch} onChange={e => setEquipNameSearch(e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* 装备表格 */}
                <div className="flex-1 overflow-y-auto p-4">
                  {(() => {
                    const filtered = equipBaseData.filter(e => {
                      if (equipC1 !== '全部' && e.category1 !== equipC1) return false
                      if (equipC2 !== '全部' && e.category2 !== equipC2) return false
                      if (equipC3 !== '全部' && e.category3 !== equipC3) return false
                      if (equipNameSearch && !e.name.toLowerCase().includes(equipNameSearch.toLowerCase()) && !e.code.toLowerCase().includes(equipNameSearch.toLowerCase())) return false
                      if (selectedEquips.some(s => s.equip.id === e.id)) return false
                      return true
                    })
                    return (
                      <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                        <thead>
                          <tr style={{ background: 'var(--table-header-bg)' }}>
                            <th className="border p-2 w-10" style={{ borderColor: 'var(--border-color)' }}>
                              <input type="checkbox" disabled />
                            </th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>一级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>二级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>三级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map(e => (
                            <tr key={e.id} className="cursor-pointer hover:bg-blue-50 transition-colors" onClick={() => setSelectedEquips(prev => [...prev, { equip: e, qty: 1 }])}>
                              <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" readOnly /></td>
                              <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{e.name}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category1}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category2}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category3}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.spec}</td>
                              <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{e.code}</td>
                            </tr>
                          ))}
                          {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
                        </tbody>
                      </table>
                    )
                  })()}
                </div>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedEquips.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  {selectedEquips.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备选择</p>
                    </div>
                  ) : (
                    selectedEquips.map((s, i) => (
                      <div key={s.equip.id} className="border rounded-lg p-3" style={{ borderColor: 'var(--border-color)' }}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium">{s.equip.name}</span>
                          <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedEquips(prev => prev.filter((_, idx) => idx !== i))}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          </button>
                        </div>
                        <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>数量：{s.equip.stockQty}</div>
                        <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>单价：¥{s.equip.unitPrice.toLocaleString()}</div>
                        <div className="flex items-center gap-2">
                          <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: Math.max(1, p.qty - 1) } : p))}>-</button>
                          <span className="text-xs font-mono w-8 text-center">{s.qty}</span>
                          <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: p.qty + 1 } : p))}>+</button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => setEquipSelectOpen(false)}>关闭</button>
              <button
                className="btn-primary text-xs"
                disabled={selectedEquips.length === 0}
                onClick={() => {
                  const newItems = selectedEquips.map((s, i) => ({
                    id: lineItems.length + i + 1,
                    name: s.equip.name,
                    spec: s.equip.spec,
                    model: s.equip.spec,
                    qty: s.qty,
                    unit: s.equip.unit,
                    price: s.equip.unitPrice,
                    amount: s.equip.unitPrice * s.qty,
                    code: s.equip.code,
                    remark: '',
                  }))
                  setLineItems(prev => [...prev, ...newItems])
                  setEquipSelectOpen(false)
                  setSelectedEquips([])
                }}
              >
                确定
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {addSupplierOpen && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAddSupplierOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增企业</h3>
              <button onClick={() => setAddSupplierOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* 供应商信息 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>供应商信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商全称 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs" placeholder="请输入供应商全称" value={newSupplierName} onChange={e => setNewSupplierName(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业信用代码 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs font-mono" placeholder="请输入企业信用代码" value={newSupplierCode} onChange={e => setNewSupplierCode(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商简称</label>
                    <input className="form-input w-full text-xs" placeholder="请输入供应商简称" value={newSupplierShort} onChange={e => setNewSupplierShort(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>技术负责人</label>
                    <input className="form-input w-full text-xs" placeholder="请输入技术负责人" value={newSupplierTech} onChange={e => setNewSupplierTech(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系电话 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs" placeholder="请输入联系电话" value={newSupplierPhone} onChange={e => setNewSupplierPhone(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>警用准入 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full text-xs" value={newSupplierPolice} onChange={e => setNewSupplierPolice(e.target.value)}>
                      <option>否</option>
                      <option>是</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否涉密 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full text-xs" value={newSupplierSecret} onChange={e => setNewSupplierSecret(e.target.value)}>
                      <option>否</option>
                      <option>是</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>资质状态</label>
                    <select className="form-input w-full text-xs" value={newSupplierStatus} onChange={e => setNewSupplierStatus(e.target.value)}>
                      <option>正常</option>
                      <option>异常</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* 供应商类型 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#722ed1' }}/>供应商类型 <span className="text-red-400">*</span></h4>
                <div className="flex gap-6">
                  {['生产商', '协议供货商', '供应商'].map(type => (
                    <label key={type} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input type="checkbox" className="rounded" checked={newSupplierTypes.includes(type)} onChange={e => {
                        if (e.target.checked) setNewSupplierTypes(prev => [...prev, type])
                        else setNewSupplierTypes(prev => prev.filter(t => t !== type))
                      }} />
                      <span className="text-xs">{type}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 备注 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                <textarea className="form-input w-full text-xs" rows={3} placeholder="请输入备注" value={newSupplierRemark} onChange={e => setNewSupplierRemark(e.target.value)} />
              </div>

              {/* 系统信息 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#8c8c8c' }}/>系统信息</h4>
                <div className="grid grid-cols-3 gap-4 text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <div>创建人员：<span className="font-medium">-</span></div>
                  <div>创建时间：<span className="font-medium">-</span></div>
                  <div>更新时间：<span className="font-medium">-</span></div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => setAddSupplierOpen(false)}>取消</button>
              <button className="btn-default text-xs">保存草稿</button>
              <button
                className="btn-primary text-xs"
                onClick={() => {
                  if (!newSupplierName.trim()) { alert('请输入供应商全称'); return }
                  setSupplierListState(prev => [...prev, newSupplierName.trim()])
                  setOrderSupplier(newSupplierName.trim())
                  setNewSupplierName(''); setNewSupplierCode(''); setNewSupplierShort(''); setNewSupplierTech(''); setNewSupplierPhone('')
                  setNewSupplierPolice('否'); setNewSupplierSecret('否'); setNewSupplierStatus('正常'); setNewSupplierTypes([]); setNewSupplierRemark('')
                  setAddSupplierOpen(false)
                }}
              >
                保存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Acceptance Check Modal */}
      {acceptModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAcceptModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">合格确认 — {acceptForm.itemName}</h3>
              <button onClick={() => setAcceptModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              {/* 验收结果 */}
              <div>
                <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收结果</label>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1.5 rounded text-sm font-medium ${acceptForm.result === 'pass' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                    {acceptForm.result === 'pass' ? '合格' : '不合格'}
                  </span>
                </div>
              </div>

              {/* 验收人 + 验收时间 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收人</label>
                  <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.checker} readOnly />
                </div>
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收时间</label>
                  {acceptViewMode ? (
                    <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.checkTime} readOnly />
                  ) : (
                    <input
                      className="form-input w-full text-sm"
                      type="datetime-local"
                      value={acceptForm.checkTime}
                      onChange={e => setAcceptForm({ ...acceptForm, checkTime: e.target.value })}
                    />
                  )}
                </div>
              </div>

              {/* 合格数量 - 不合格时显示 */}
              {acceptForm.result === 'fail' && (
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>合格数量</label>
                  {acceptViewMode ? (
                    <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.qualifiedQty || '0'} readOnly />
                  ) : (
                    <input
                      className="form-input w-full text-sm"
                      type="number"
                      min={0}
                      max={acceptForm.totalQty}
                      value={acceptForm.qualifiedQty}
                      onChange={e => {
                        const qty = parseInt(e.target.value) || 0
                        // 改为生成 qualifiedQty 个RFID输入框（合格的装备RFID）
                        const qualifiedCount = qty
                        const newRfids = Array(qualifiedCount).fill('').map((_, i) => acceptForm.unqualifiedRfids[i] || '')
                        setAcceptForm({ ...acceptForm, qualifiedQty: e.target.value, unqualifiedRfids: newRfids })
                      }}
                      placeholder={`请输入合格数量（总数：${acceptForm.totalQty}）`}
                    />
                  )}
                </div>
              )}

              {/* 合格的装备RFID编码 - 不合格时显示 */}
              {acceptForm.result === 'fail' && !acceptViewMode && (
                <div>
                  <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>
                    合格的装备RFID编码（共{acceptForm.unqualifiedRfids.length}个）
                  </label>
                  <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1">
                    {acceptForm.unqualifiedRfids.map((rfid, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <span className="text-xs w-6 text-right" style={{ color: 'var(--text-disabled)' }}>{idx + 1}.</span>
                        <div className="relative flex-1">
                          <input
                            className="form-input w-full text-xs py-1.5 pl-8"
                            value={rfid}
                            onChange={e => {
                              const newRfids = [...acceptForm.unqualifiedRfids]
                              newRfids[idx] = e.target.value
                              setAcceptForm({ ...acceptForm, unqualifiedRfids: newRfids })
                            }}
                            placeholder={`RFID编码 ${idx + 1}`}
                          />
                          <button
                            type="button"
                            className="absolute left-1 top-1/2 -translate-y-1/2 z-10 p-1 rounded hover:bg-blue-50"
                            onClick={(e) => {
                              e.preventDefault()
                              e.stopPropagation()
                              const itemRfids = rfidMap[acceptForm.itemId] || []
                              const newRfids = [...acceptForm.unqualifiedRfids]
                              // 取RFID编码列表中前 qualifiedQty 个的对应位置编码
                              if (itemRfids[idx]) {
                                newRfids[idx] = itemRfids[idx]
                              } else {
                                newRfids[idx] = 'RFID-' + Math.floor(10000000 + Math.random() * 90000000)
                              }
                              setAcceptForm({ ...acceptForm, unqualifiedRfids: newRfids })
                            }}
                            title="填入RFID"
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><rect x="4" y="4" width="16" height="16" rx="2"/><path d="M8 12h2M8 16h2M8 8h2M14 8h2M14 12h2M14 16h2"/></svg>
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 合格的装备RFID编码 - 查看模式显示 */}
              {acceptForm.result === 'fail' && acceptViewMode && acceptForm.unqualifiedRfids.length > 0 && (
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>合格的装备RFID编码</label>
                  <div className="form-input w-full text-sm bg-gray-50 min-h-[32px] py-2">
                    {acceptForm.unqualifiedRfids.map((rfid, idx) => (
                      <span key={idx} className="inline-block px-1.5 py-0.5 rounded text-xs mr-1 mb-1" style={{ background: '#f6ffed', color: '#52c41a' }}>{rfid}</span>
                    ))}
                  </div>
                </div>
              )}

              {/* 处理方式 - 不合格时显示 */}
              {acceptForm.result === 'fail' && (
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>处理方式</label>
                  {acceptViewMode ? (
                    <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.handleWay === 'return' ? '退货' : acceptForm.handleWay === 'exchange' ? '换货' : '-'} readOnly />
                  ) : (
                    <select
                      className="form-input w-full text-sm"
                      value={acceptForm.handleWay}
                      onChange={e => setAcceptForm({ ...acceptForm, handleWay: e.target.value })}
                    >
                      <option value="">请选择</option>
                      <option value="return">退货</option>
                      <option value="exchange">换货</option>
                    </select>
                  )}
                </div>
              )}

              {/* 验收意见 */}
              <div>
                <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收意见</label>
                {acceptViewMode ? (
                  <div className="form-input w-full text-sm bg-gray-50 text-gray-700 min-h-[60px] py-2">
                    {acceptForm.opinion || <span style={{ color: 'var(--text-disabled)' }}>无验收意见</span>}
                  </div>
                ) : (
                  <textarea
                    className="form-input w-full text-sm"
                    rows={3}
                    value={acceptForm.opinion}
                    onChange={e => setAcceptForm({ ...acceptForm, opinion: e.target.value })}
                    placeholder={acceptForm.result === 'pass' ? '请填写合格验收意见...' : '请填写不合格原因及处理建议...'}
                  />
                )}
              </div>

              {/* 附件上传 - 查看模式下隐藏 */}
              {!acceptViewMode && (
                <div>
                  <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>附件上传</label>
                  <div className="flex items-center gap-3 flex-wrap">
                    <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: '#d9d9d9' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      <span className="text-xs" style={{ color: '#8c8c8c' }}>上传照片</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => {
                        const files = e.target.files
                        if (files && files.length > 0) {
                          const names = Array.from(files).map(f => f.name).join(', ')
                          alert(`已选择 ${files.length} 个文件: ${names}`)
                        }
                      }} />
                    </label>
                    <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 JPG、PNG 格式</span>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              {acceptViewMode ? (
                <button className="btn-default text-xs" onClick={() => { setAcceptModalOpen(false); setAcceptViewMode(false) }}>关闭</button>
              ) : (
                <>
                  <button className="btn-default text-xs" onClick={() => setAcceptModalOpen(false)}>取消</button>
                  <button
                    className="btn-primary text-xs"
                    style={{ background: '#52c41a' }}
                    onClick={() => {
                      if (!acceptForm.opinion) { alert('请填写验收意见'); return }
                      if (acceptForm.result === 'fail') {
                        if (!acceptForm.qualifiedQty) { alert('请输入合格数量'); return }
                        // RFID编码非必填，允许为空
                        if (!acceptForm.handleWay) { alert('请选择处理方式'); return }
                        // 校验：填写的合格RFID编码必须存在于该装备的RFID编码列表中
                        if (acceptForm.unqualifiedRfids.length > 0) {
                          const itemRfids = rfidMap[acceptForm.itemId] || []
                          const invalidRfids = acceptForm.unqualifiedRfids.filter(r => r && !itemRfids.includes(r))
                          if (invalidRfids.length > 0) { alert(`以下RFID编码不在该装备的RFID列表中，请检查：${invalidRfids.join('、')}`); return }
                        }
                        // 保存合格的装备RFID编码到全局状态
                        if (acceptForm.itemId) {
                          setUnqualifiedRfidMap(prev => ({ ...prev, [acceptForm.itemId]: [...acceptForm.unqualifiedRfids] }))
                        }
alert(`${acceptForm.itemName} 已标记为「不合格」，合格数量：${acceptForm.qualifiedQty}，合格的装备RFID：${acceptForm.unqualifiedRfids.join('、') || '无'}，处理方式：${acceptForm.handleWay === 'return' ? '退货' : '换货'}，验收意见已保存。`)
                      } else {
                        alert(`${acceptForm.itemName} 已标记为「合格」，验收意见已保存。`)
                      }
                      setAcceptModalOpen(false)
                      setAcceptForm({ itemName: '', itemId: '', result: 'pass', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '', qualifiedQty: '', unqualifiedRfids: [], totalQty: 0 })
                    }}
                  >保存</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 收货单预览弹窗 */}
      {receiptPreviewOpen && selectedRow && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setReceiptPreviewOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">收货单预览</h3>
              <div className="flex items-center gap-3">
                <button className="btn-primary text-sm px-4 py-2 flex items-center gap-2" onClick={() => window.print()}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  打印收货单
                </button>
                <button onClick={() => setReceiptPreviewOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8">
              <div className="max-w-[800px] mx-auto border-2 border-gray-300 p-8" style={{ background: '#fff' }}>
                {/* 标题 */}
                <h2 className="text-2xl font-bold text-center mb-6 tracking-widest">收 货 单</h2>
                {/* 基本信息 */}
                <table className="w-full border-collapse text-sm mb-4">
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 w-[20%] font-medium bg-gray-50">收货单号</td>
                      <td className="border border-gray-300 px-3 py-2 w-[30%]">{selectedRow.id}</td>
                      <td className="border border-gray-300 px-3 py-2 w-[20%] font-medium bg-gray-50">供应商</td>
                      <td className="border border-gray-300 px-3 py-2 w-[30%]">{selectedRow.supplier}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">供应商企业编码</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.enterpriseCode}</td>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">关联合同</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.contractName}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">预计送货日期</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.deliveryDate}</td>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">收货对象</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.receiver}</td>
                    </tr>
                  </tbody>
                </table>
                {/* 装备明细 */}
                <table className="w-full border-collapse text-sm mb-4">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-2 py-2 text-center w-[8%]">序号</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[20%]">装备名称</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[15%]">规格型号</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[10%]">计量单位</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[8%]">数量</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[12%]">单价</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[15%]">装备编码</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[12%]">金额</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedRow.items.map((item: any, idx: number) => (
                      <tr key={item.id}>
                        <td className="border border-gray-300 px-2 py-2 text-center">{idx + 1}</td>
                        <td className="border border-gray-300 px-2 py-2">{item.name}</td>
                        <td className="border border-gray-300 px-2 py-2">{item.spec}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center">{item.unit}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center">{item.qty}</td>
                        <td className="border border-gray-300 px-2 py-2 text-right">¥{item.price?.toLocaleString()}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center font-mono">{item.code}</td>
                        <td className="border border-gray-300 px-2 py-2 text-right">¥{item.amount?.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* 合计 */}
                <div className="text-right mb-6 text-sm">
                  <span className="font-medium">合计金额：</span>
                  <span className="font-bold text-lg">¥{selectedRow.items.reduce((s: number, it: any) => s + (it.amount || 0), 0).toLocaleString()}</span>
                </div>
                {/* 签字 */}
                <div className="flex justify-between text-sm mt-8 pt-4 border-t border-gray-300">
                  <div>发货方签字：______________</div>
                  <div>收货方签字：______________</div>
                  <div>日期：______年____月____日</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 退货单预览弹窗 */}
      {returnPreviewOpen && selectedRow && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setReturnPreviewOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">退货单预览</h3>
              <div className="flex items-center gap-3">
                <button className="btn-primary text-sm px-4 py-2 flex items-center gap-2" onClick={() => window.print()}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
                  打印退货单
                </button>
                <button onClick={() => setReturnPreviewOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                </button>
              </div>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto p-8">
              <div className="max-w-[800px] mx-auto border-2 border-gray-300 p-8" style={{ background: '#fff' }}>
                {/* 标题 */}
                <h2 className="text-2xl font-bold text-center mb-6 tracking-widest">退 货 单</h2>
                {/* 基本信息 */}
                <table className="w-full border-collapse text-sm mb-4">
                  <tbody>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 w-[20%] font-medium bg-gray-50">退货单号</td>
                      <td className="border border-gray-300 px-3 py-2 w-[30%]">{selectedRow.id}-TH</td>
                      <td className="border border-gray-300 px-3 py-2 w-[20%] font-medium bg-gray-50">供应商</td>
                      <td className="border border-gray-300 px-3 py-2 w-[30%]">{selectedRow.supplier}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">供应商企业编码</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.enterpriseCode}</td>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">关联合同</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.contractName}</td>
                    </tr>
                    <tr>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">原订单号</td>
                      <td className="border border-gray-300 px-3 py-2">{selectedRow.id}</td>
                      <td className="border border-gray-300 px-3 py-2 font-medium bg-gray-50">退货日期</td>
                      <td className="border border-gray-300 px-3 py-2">{new Date().toISOString().slice(0, 10)}</td>
                    </tr>
                  </tbody>
                </table>
                {/* 退货原因 */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-sm font-medium">退货原因：</span>
                    <span className="text-sm">□ 质量不合格  □ 规格不符  □ 数量不符  □ 其他：__________</span>
                  </div>
                </div>
                {/* 装备明细 */}
                <table className="w-full border-collapse text-sm mb-4">
                  <thead>
                    <tr className="bg-gray-100">
                      <th className="border border-gray-300 px-2 py-2 text-center w-[8%]">序号</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[20%]">装备名称</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[15%]">规格型号</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[10%]">计量单位</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[8%]">退货数量</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[12%]">单价</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[15%]">装备编码</th>
                      <th className="border border-gray-300 px-2 py-2 text-center w-[12%]">金额</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedRow.items.map((item: any, idx: number) => (
                      <tr key={item.id}>
                        <td className="border border-gray-300 px-2 py-2 text-center">{idx + 1}</td>
                        <td className="border border-gray-300 px-2 py-2">{item.name}</td>
                        <td className="border border-gray-300 px-2 py-2">{item.spec}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center">{item.unit}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center">{item.qty}</td>
                        <td className="border border-gray-300 px-2 py-2 text-right">¥{item.price?.toLocaleString()}</td>
                        <td className="border border-gray-300 px-2 py-2 text-center font-mono">{item.code}</td>
                        <td className="border border-gray-300 px-2 py-2 text-right">¥{item.amount?.toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                {/* 合计 */}
                <div className="text-right mb-6 text-sm">
                  <span className="font-medium">合计金额：</span>
                  <span className="font-bold text-lg">¥{selectedRow.items.reduce((s: number, it: any) => s + (it.amount || 0), 0).toLocaleString()}</span>
                </div>
                {/* 签字 */}
                <div className="flex justify-between text-sm mt-8 pt-4 border-t border-gray-300">
                  <div>退货方签字：______________</div>
                  <div>供应商签字：______________</div>
                  <div>日期：______年____月____日</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Order Confirmation Modal */}
      {orderConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOrderConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认填写订单</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否保存合同信息，并填写订单信息？</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setOrderConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setOrderConfirmOpen(false)
                  setDrawerOpen(false)
                  setActiveTab('order')
                  setDrawerTitle('新增订单')
                  setDrawerOpen(true)
                }}
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Confirmation Modal */}
      {completeConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCompleteConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认办结</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认将该合同标记为"已办结"？办结后合同将关闭，无法再进行填写订单等操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setCompleteConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setCompleteConfirmOpen(false)
                }}
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Terminate Confirmation Modal */}
      {terminateConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setTerminateConfirmOpen(false); setTerminateReason('') }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
              </div>
              <h3 className="text-base font-semibold">终止/作废合同</h3>
            </div>
            <div className="mb-6 space-y-3">
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>终止/作废后，合同将关闭且无法恢复。请填写终止/作废原因以备查询。</p>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>终止/作废原因 <span className="text-red-400">*</span></label>
                <textarea
                  className="form-input w-full text-sm"
                  rows={4}
                  placeholder="请输入终止/作废原因..."
                  value={terminateReason}
                  onChange={e => setTerminateReason(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => { setTerminateConfirmOpen(false); setTerminateReason('') }}>取消</button>
              <button
                className="btn-primary"
                style={{ background: '#ff4d4f' }}
                disabled={!terminateReason.trim()}
                onClick={() => {
                  setTerminateConfirmOpen(false)
                  setTerminateReason('')
                }}
              >
                确认终止/作废
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Storage Confirm Modal - 入库二次确认 */}
      {storageConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStorageConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e8eef5' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1a4b8c" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              </div>
              <h3 className="text-base font-semibold">入库确认</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>请确认是否保存验收意见，并进行入库？</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setStorageConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setStorageConfirmOpen(false)
                  setDrawerOpen(false)
                  setSelectedRow(null)
                  onNavigate?.('warehouse-mgmt', 'inbound')
                }}
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Contract Detail Modal ===== */}
      {contractDetailOpen && contractDetailData && (
        <div className="fixed inset-0 z-[70] flex items-start justify-center pt-10">
          <div className="absolute inset-0 bg-black/40" onClick={() => setContractDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">合同详情</h3>
              <button onClick={() => setContractDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Content */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-5">
              {/* Basic Info Section */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                  <h4 className="text-sm font-semibold">基本信息</h4>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>甲方</div>
                    <div className="text-sm font-medium">{contractDetailData.partyA}</div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>乙方</div>
                    <div className="text-sm font-medium">{contractDetailData.partyB}</div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称</div>
                    <div className="text-sm font-medium">{contractDetailData.contractName}</div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同金额</div>
                    <div className="text-sm font-medium" style={{ color: '#1890ff' }}>¥{contractDetailData.amount?.toLocaleString()}</div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>签订日期</div>
                    <div className="text-sm font-medium">{contractDetailData.date}</div>
                  </div>
                  <div className="p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>最终交货日期</div>
                    <div className="text-sm font-medium">{contractDetailData.deliveryDate}</div>
                  </div>
                </div>
              </div>

              {/* Attachment Section */}
              {contractDetailData.attachment && (
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                  <div className="flex items-center gap-2">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合同附件</span>
                    <span className="text-sm font-medium">{contractDetailData.attachment}</span>
                  </div>
                </div>
              )}

              {/* Related Orders Section */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#faad14" strokeWidth="2"><path d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/><polyline points="9 11 12 14 15 11"/></svg>
                  <h4 className="text-sm font-semibold">关联订单</h4>
                </div>
                {(() => {
                  const relatedOrders = orderData.filter(o => o.contractId === contractDetailData.id)
                  if (relatedOrders.length === 0) {
                    return <div className="text-center py-8 text-sm rounded-lg border border-dashed" style={{ color: 'var(--text-disabled)', borderColor: 'var(--border-color)' }}>暂无关联订单</div>
                  }
                  return (
                    <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                      <table className="w-full text-sm">
                        <thead>
                          <tr style={{ background: 'var(--table-header-bg)' }}>
                            <th className="border-b p-3 text-left text-xs" style={{ borderColor: 'var(--border-color)' }}>订单名称</th>
                            <th className="border-b p-3 text-left text-xs" style={{ borderColor: 'var(--border-color)' }}>预计送货日期</th>
                            <th className="border-b p-3 text-left text-xs" style={{ borderColor: 'var(--border-color)' }}>收货对象</th>
                            <th className="border-b p-3 text-right text-xs" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                          </tr>
                        </thead>
                        <tbody>
                          {relatedOrders.map(o => (
                            <tr key={o.id}>
                              <td className="p-3 text-sm font-medium">{o.contractName}订单</td>
                              <td className="p-3 text-xs">{o.orderDate}</td>
                              <td className="p-3 text-xs">{contractDetailData.partyA}</td>
                              <td className="p-3 text-right">
                                <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => { setContractDetailOpen(false); setDrawerTitle(`订单详情 - ${o.id}`); setSelectedRow(o); setDrawerOpen(true) }}>查看</button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )
                })()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Contract Form Modal (Add/Edit) ===== */}
      {contractFormOpen && (
        <div className="fixed inset-0 z-[70] flex items-start justify-center pt-10">
          <div className="absolute inset-0 bg-black/40" onClick={() => setContractFormOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[75vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{contractFormMode === 'add' ? '新增合同' : '编辑合同'}</h3>
              <button onClick={() => setContractFormOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Form Content */}
            <div className="flex-1 overflow-y-auto px-6 py-5 space-y-4">
              {/* 甲方 */}
              <div>
                <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 甲方</label>
                <select
                  className="form-input w-full"
                  value={contractFormData.partyA}
                  onChange={e => setContractFormData({ ...contractFormData, partyA: e.target.value })}
                >
                  <option value="">请选择意向供货单位</option>
                  {partyAOptions.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
              </div>
              {/* 乙方 */}
              <div>
                <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 乙方</label>
                <input className="form-input w-full bg-gray-50" value={contractFormData.partyB} readOnly />
              </div>
              {/* 合同名称 */}
              <div>
                <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 合同名称</label>
                <input
                  className="form-input w-full"
                  placeholder="请输入合同名称"
                  value={contractFormData.contractName}
                  onChange={e => setContractFormData({ ...contractFormData, contractName: e.target.value })}
                />
              </div>
              {/* 合同金额 */}
              <div>
                <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 合同金额</label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm" style={{ color: 'var(--text-disabled)' }}>¥</span>
                  <input
                    className="form-input w-full pl-7"
                    placeholder="请输入合同金额"
                    type="number"
                    value={contractFormData.amount}
                    onChange={e => setContractFormData({ ...contractFormData, amount: e.target.value })}
                  />
                </div>
              </div>
              {/* 签订日期 + 最终交货日期 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 签订日期</label>
                  <input
                    className="form-input w-full"
                    type="date"
                    value={contractFormData.date}
                    onChange={e => setContractFormData({ ...contractFormData, date: e.target.value })}
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1.5"><span className="text-red-400">*</span> 最终交货日期</label>
                  <input
                    className="form-input w-full"
                    type="date"
                    value={contractFormData.deliveryDate}
                    onChange={e => setContractFormData({ ...contractFormData, deliveryDate: e.target.value })}
                  />
                </div>
              </div>
              {/* 备注 */}
              <div>
                <label className="block text-sm mb-1.5">备注</label>
                <textarea
                  className="form-input w-full h-20 resize-none"
                  placeholder="请输入备注..."
                  value={contractFormData.remark}
                  onChange={e => setContractFormData({ ...contractFormData, remark: e.target.value })}
                />
              </div>
              {/* 合同附件 */}
              <div>
                <label className="block text-sm mb-1.5">合同附件</label>
                <div className="p-6 rounded-lg border border-dashed flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#bfbfbf" strokeWidth="1.5"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                  <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>点击上传合同附件（PDF/Word/图片）</span>
                </div>
              </div>
            </div>
            {/* Footer */}
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setContractFormOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleSaveContract}>提交</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}