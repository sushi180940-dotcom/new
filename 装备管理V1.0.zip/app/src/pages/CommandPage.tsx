import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
}

const tabList = [
  { key: 'map', label: '全省管理一张图' },
  { key: 'command-map', label: '指挥决策一张图' },
]

export default function CommandPage({ activeSubTab }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab || 'map')

  useEffect(() => {
    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])


  return (
    <div className="p-6 space-y-4">
      {activeTab === 'map' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 content-card p-0 overflow-hidden" style={{ height: 540 }}>
            <div className="relative w-full h-full" style={{ background: 'linear-gradient(135deg, #0a1f3d 0%, #0d2b52 50%, #0a1f3d 100%)' }}>
              <div className="absolute inset-0" style={{
                backgroundImage: 'linear-gradient(rgba(24,144,255,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(24,144,255,0.08) 1px, transparent 1px)',
                backgroundSize: '60px 60px',
              }} />
              {[
                { x: 55, y: 35, label: '杭州', status: 'normal', value: '32,500' },
                { x: 75, y: 25, label: '宁波', status: 'normal', value: '18,200' },
                { x: 65, y: 55, label: '金华', status: 'warning', value: '12,800' },
                { x: 45, y: 30, label: '湖州', status: 'normal', value: '8,600' },
                { x: 80, y: 50, label: '台州', status: 'normal', value: '15,300' },
                { x: 50, y: 55, label: '衢州', status: 'normal', value: '6,700' },
                { x: 70, y: 40, label: '绍兴', status: 'normal', value: '14,100' },
                { x: 85, y: 35, label: '舟山', status: 'normal', value: '5,400' },
              ].map(city => (
                <div key={city.label} className="absolute flex flex-col items-center cursor-pointer group" style={{ left: `${city.x}%`, top: `${city.y}%`, transform: 'translate(-50%, -50%)' }}>
                  <div className={`w-4 h-4 rounded-full border-2 transition-all group-hover:scale-150`} style={{
                    background: city.status === 'warning' ? '#faad14' : '#52c41a',
                    borderColor: city.status === 'warning' ? '#faad14' : '#52c41a',
                    boxShadow: `0 0 12px ${city.status === 'warning' ? 'rgba(250,173,20,0.5)' : 'rgba(82,196,26,0.5)'}`,
                  }} />
                  <span className="text-xs mt-1 font-medium" style={{ color: 'rgba(255,255,255,0.9)' }}>{city.label}</span>
                  <span className="text-xs font-mono" style={{ color: 'rgba(255,255,255,0.6)' }}>{city.value}</span>
                </div>
              ))}
              <div className="absolute bottom-4 left-4 flex items-center gap-4 text-xs" style={{ color: 'rgba(255,255,255,0.6)' }}>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500"/> 正常</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-500"/> 预警</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500"/> 告警</span>
              </div>
              <div className="absolute top-4 right-4 text-xs px-3 py-1.5 rounded-lg" style={{ color: 'rgba(255,255,255,0.8)', background: 'rgba(0,0,0,0.3)' }}>
                点击地市下钻至区县
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="content-card p-5">
              <h4 className="font-semibold mb-4" style={{ color: 'var(--text-primary)' }}>实时数据展示</h4>
              <div className="grid grid-cols-3 gap-3 mb-4">
                {[
                  { label: '装备总数量', value: '156,230' },
                  { label: '在库数量', value: '120,500' },
                  { label: '出库数量', value: '35,730' },
                ].map(s => (
                  <div key={s.label} className="text-center p-3 rounded-lg" style={{ background: 'var(--content-bg)' }}>
                    <p className="text-lg font-bold font-mono" style={{ color: 'var(--primary-blue)' }}>{s.value}</p>
                    <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{s.label}</p>
                  </div>
                ))}
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>过期装备</span><span className="font-mono">23</span></div>
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>商品总数</span><span className="font-mono">1,256</span></div>
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>生产商</span><span className="font-mono">56</span></div>
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>经销商</span><span className="font-mono">128</span></div>
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>待审批编码</span><span className="font-mono" style={{ color: 'var(--error)' }}>15</span></div>
                <div className="flex justify-between"><span style={{ color: 'var(--text-secondary)' }}>待签合同</span><span className="font-mono" style={{ color: '#faad14' }}>8</span></div>
              </div>
            </div>

            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>系统使用情况</h4>
              <div className="flex justify-between text-sm">
                <span style={{ color: 'var(--text-secondary)' }}>在线</span><span className="font-mono font-medium">128人</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span style={{ color: 'var(--text-secondary)' }}>今日登录</span><span className="font-mono font-medium">356</span>
              </div>
              <div className="flex justify-between text-sm mt-1">
                <span style={{ color: 'var(--text-secondary)' }}>累计</span><span className="font-mono font-medium">2,000</span>
              </div>
            </div>

            <div className="content-card p-5">
              <h4 className="font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>待办事项</h4>
              <div className="space-y-2">
                {[
                  { label: '编码审批', count: 15, color: '#1890ff' },
                  { label: '合同审批', count: 8, color: '#52c41a' },
                  { label: '调拨审批', count: 3, color: '#faad14' },
                ].map(item => (
                  <div key={item.label} className="flex items-center justify-between p-2 rounded hover:bg-blue-50 cursor-pointer transition-colors">
                    <span className="text-sm">{item.label}</span>
                    <span className="text-sm font-bold" style={{ color: item.color }}>{item.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'command-map' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 content-card p-0 overflow-hidden" style={{ height: 540 }}>
            <div className="relative w-full h-full" style={{ background: 'linear-gradient(135deg, #1a0f0f 0%, #2d1a1a 50%, #1a0f0f 100%)' }}>
              <div className="absolute inset-0" style={{
                backgroundImage: 'linear-gradient(rgba(255,77,79,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(255,77,79,0.08) 1px, transparent 1px)',
                backgroundSize: '60px 60px',
              }} />
              <div className="absolute flex flex-col items-center" style={{ left: '50%', top: '40%', transform: 'translate(-50%, -50%)' }}>
                <div className="w-6 h-6 rounded-full animate-ping" style={{ background: 'rgba(255,77,79,0.4)', position: 'absolute' }} />
                <div className="w-6 h-6 rounded-full border-2 border-red-500 flex items-center justify-center relative z-10" style={{ background: '#ff4d4f' }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="white"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"/></svg>
                </div>
                <span className="text-xs mt-2 font-medium text-red-400">事发地点</span>
              </div>
              {[
                { x: 30, y: 30, label: 'A市仓库' },
                { x: 70, y: 60, label: 'B市仓库' },
              ].map(wh => (
                <div key={wh.label} className="absolute flex flex-col items-center" style={{ left: `${wh.x}%`, top: `${wh.y}%`, transform: 'translate(-50%, -50%)' }}>
                  <div className="w-4 h-4 rounded-full border-2 border-blue-400" style={{ background: 'rgba(24,144,255,0.3)' }} />
                  <span className="text-xs mt-1" style={{ color: 'rgba(255,255,255,0.7)' }}>{wh.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <div className="content-card p-5 border-l-4" style={{ borderLeftColor: '#ff4d4f' }}>
              <h4 className="font-semibold mb-3 flex items-center gap-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                当前应急事件
              </h4>
              <div className="space-y-2 text-sm">
                <p><span style={{ color: 'var(--text-secondary)' }}>事件ID：</span><span className="font-mono">E2024001</span></p>
                <p><span style={{ color: 'var(--text-secondary)' }}>类型：</span>自然灾害-洪水</p>
                <p><span style={{ color: 'var(--text-secondary)' }}>等级：</span><span style={{ color: '#ff4d4f', fontWeight: 600 }}>II级（重大）</span></p>
                <p><span style={{ color: 'var(--text-secondary)' }}>地点：</span>XX市XX区XX街道</p>
                <p><span style={{ color: 'var(--text-secondary)' }}>时间：</span>2024-03-15 08:30</p>
                <p><span style={{ color: 'var(--text-secondary)' }}>状态：</span><span className="tag tag-red">处置中</span></p>
              </div>
            </div>

            <div className="content-card p-5">
              <h4 className="font-semibold mb-3">自动分析结果</h4>
              <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>推荐装备清单：</p>
              <div className="space-y-1 text-sm">
                <p>• 应急帐篷 50顶</p>
                <p>• 救生衣 100件</p>
                <p>• 应急照明灯 30个</p>
              </div>
            </div>

            <div className="content-card p-5">
              <h4 className="font-semibold mb-3">周边库存分布（半径50km）</h4>
              <div className="space-y-2 text-sm">
                <div className="p-2 rounded" style={{ background: 'var(--content-bg)' }}>
                  <p className="font-medium">A市仓库</p>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>帐篷20 | 救生衣50 | 照明灯10</p>
                </div>
                <div className="p-2 rounded" style={{ background: 'var(--content-bg)' }}>
                  <p className="font-medium">B市仓库</p>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>帐篷30 | 救生衣60 | 照明灯20</p>
                </div>
                <p className="text-sm font-medium" style={{ color: '#52c41a' }}>满足度：100%</p>
              </div>
            </div>

            <div className="flex gap-2">
              <button className="btn-danger flex-1 flex items-center justify-center gap-1">⚡ 一键启动自动调拨</button>
              <button className="btn-default flex-1">手动调整</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
