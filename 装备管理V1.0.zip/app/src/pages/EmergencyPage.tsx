import { useState, useEffect } from 'react'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'
import { warehouseData } from '../pages/InboundPage'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

/* ================================================================
   Transfer Management Types & Data
   ================================================================ */

type TransferType = 'emergency' | 'approval'
type TransferStatus = 'draft' | 'submitted' | 'approval1' | 'pending_out' | 'outed' | 'rejected'

interface TransferEquip {
  code: string          // 物资编码（去-后32位）
  name: string          // 物资名称
  category: string      // 物资类别（二级）
  spec: string          // 规格型号
  tags?: string[]       // 标签
  qty: number           // 数量
  remainQty: number     // 剩余数量
  produceDate: string   // 生产日期
  validDate: string     // 有效期
  maintainPeriod: string // 保养期
  unit: string          // 单位
  isBox: boolean        // 是否为箱
  boxSpec: string       // 箱规格（1箱/X个）
  unitPrice: number     // 单价
  totalPrice: number    // 总价
  equipCode: string     // 装备编码（10位）
  supplier: string      // 供应商
  remark: string        // 备注
}

interface TransferRecord {
  id: string
  type: TransferType
  desc: string          // 调拨性质说明
  fromWarehouse: string
  toWarehouse: string
  sender: string        // 发物单位
  receiver: string      // 收物单位
  equipList: TransferEquip[]
  status: TransferStatus
  applicant: string
  approver?: string
  applyTime: string
  approveTime?: string
  outboundTime?: string
  outedTime?: string
  rejectReason?: string
}

const warehouseList = ['省厅装备库A', '省厅装备库B', '杭州市局装备库', '西湖分局装备库', '拱墅分局装备库', '宁波市局装备库', '温州市局装备库']

const transferStatusMap: Record<TransferStatus, { label: string; tag: string; color: string }> = {
  draft: { label: '草稿', tag: 'tag-gray', color: '#999' },
  submitted: { label: '已提交', tag: 'tag-yellow', color: '#faad14' },
  approval1: { label: '审批1', tag: 'tag-blue', color: '#1890ff' },
  pending_out: { label: '待出库', tag: 'tag-cyan', color: '#13c2c2' },
  outed: { label: '已出库', tag: 'tag-green', color: '#52c41a' },
  rejected: { label: '已驳回', tag: 'tag-red', color: '#ff4d4f' },
}

const typeLabel = (t: TransferType) => t === 'emergency' ? '应急调拨' : '审批调拨'

// 库存装备数据（与入库管理一致）
const stockMaterials: Omit<TransferEquip, 'qty' | 'totalPrice' | 'remark' | 'boxSpec'>[] = [
  { code: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', remainQty: 50, produceDate: '2024-01-15', validDate: '2029-01-14', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 3200, equipCode: '0101P00100',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0020012024040105002XXXXXX0002', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', remainQty: 30, produceDate: '2024-02-20', validDate: '2029-02-19', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 1800, equipCode: '0101P00200',
    tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', remainQty: 100, produceDate: '2024-01-20', validDate: '2029-01-19', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 1200, equipCode: '0101P00500',
    tags: ['活动类/双11备货'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', remainQty: 20, produceDate: '2023-11-10', validDate: '2033-11-09', maintainPeriod: '12个月', unit: '件', isBox: false, unitPrice: 2800, equipCode: '0101P00300',
    tags: ['品类特征/易碎品'], supplier: '华为技术有限公司' },
  { code: '10101P0040012024011510005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', remainQty: 40, produceDate: '2023-12-05', validDate: '2033-12-04', maintainPeriod: '12个月', unit: '顶', isBox: false, unitPrice: 1500, equipCode: '0101P00400',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0060012024022010006XXXXXX0006', name: '防弹盾牌 FDP-3S', category: '防护装备', spec: 'FDP-3S/手持型', remainQty: 10, produceDate: '2023-10-15', validDate: '2033-10-14', maintainPeriod: '12个月', unit: '面', isBox: false, unitPrice: 3500, equipCode: '0101P00600',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0070012024031005007XXXXXX0007', name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', remainQty: 200, produceDate: '2024-03-01', validDate: '2029-02-28', maintainPeriod: '3个月', unit: '支', isBox: false, unitPrice: 280, equipCode: '0101P00700',
    tags: ['状态类/临期30天'], supplier: '大华技术股份有限公司' },
  { code: '10101P0080012024012010008XXXXXX0008', name: '应急照明灯 YD-100', category: '照明设备', spec: 'YD-100/LED', remainQty: 60, produceDate: '2024-01-25', validDate: '2034-01-24', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 680, equipCode: '0101P00800',
    tags: ['活动类/双11备货'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0090012023120505009XXXXXX0009', name: '激光测距仪 CJY-500', category: '测量设备', spec: 'CJY-500/500m', remainQty: 15, produceDate: '2023-08-20', validDate: '2028-08-19', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 4500, equipCode: '0101P00900',
    tags: ['品类特征/易碎品'], supplier: '大华技术股份有限公司' },
  { code: '10101P0100012024050605010XXXXXX0010', name: '无人机 M300', category: '飞行器', spec: 'M300/RTK', remainQty: 8, produceDate: '2024-04-10', validDate: '2029-04-09', maintainPeriod: '3个月', unit: '架', isBox: false, unitPrice: 28000, equipCode: '0101P01000',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '大疆创新科技有限公司' },
  { code: '10101P0110012024051005011XXXXXX0011', name: '卫星便携站 S9000', category: '通信装备', spec: 'S9000/Ku频段', remainQty: 5, produceDate: '2024-04-15', validDate: '2034-04-14', maintainPeriod: '6个月', unit: '套', isBox: false, unitPrice: 350000, equipCode: '0101P01100',
    tags: ['品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0120012024022105012XXXXXX0012', name: '防暴盾牌 FB-01', category: '防护装备', spec: 'FB-01/透明', remainQty: 80, produceDate: '2024-02-10', validDate: '2034-02-09', maintainPeriod: '12个月', unit: '面', isBox: false, unitPrice: 350, equipCode: '0101P01200',
    tags: ['状态类/临期30天'], supplier: '华为技术有限公司' },
  { code: '10101P0130012024030505013XXXXXX0013', name: '急救包 JJ-02', category: '应急救援', spec: 'JJ-02/综合型', remainQty: 50, produceDate: '2024-03-01', validDate: '2027-02-28', maintainPeriod: '6个月', unit: '个', isBox: false, unitPrice: 580, equipCode: '0101P01300',
    tags: ['活动类/双11备货'], supplier: '华为技术有限公司' },
  { code: '10101P0140012024042805014XXXXXX0014', name: '单兵图传设备 TC-100', category: '通信装备', spec: 'TC-100/4G', remainQty: 25, produceDate: '2024-03-15', validDate: '2029-03-14', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 8800, equipCode: '0101P01400',
    tags: ['品类特征/易碎品'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0150012024012505015XXXXXX0015', name: '破门工具组 PM-03', category: '破拆装备', spec: 'PM-03/液压', remainQty: 12, produceDate: '2023-12-20', validDate: '2033-12-19', maintainPeriod: '12个月', unit: '套', isBox: false, unitPrice: 12000, equipCode: '0101P01500',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0160012024041505016XXXXXX0016', name: '狙击步枪支架 JZ-01', category: '武器配件', spec: 'JZ-01/碳纤', remainQty: 18, produceDate: '2024-04-01', validDate: '2034-03-31', maintainPeriod: '12个月', unit: '个', isBox: false, unitPrice: 2200, equipCode: '0101P01600',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0170012024060505017XXXXXX0017', name: '排爆机器人 PB-500', category: '应急救援', spec: 'PB-500/履带', remainQty: 4, produceDate: '2024-05-20', validDate: '2034-05-19', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 850000, equipCode: '0101P01700',
    tags: ['状态类/临期30天'], supplier: '大华技术股份有限公司' },
  { code: '10101P0180012024062005018XXXXXX0018', name: '红外热成像仪 HR-100', category: '侦察设备', spec: 'HR-100/640x512', remainQty: 10, produceDate: '2024-06-01', validDate: '2029-05-31', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 65000, equipCode: '0101P01800',
    tags: ['活动类/双11备货'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0190012024062005019XXXXXX0019', name: '数字显微镜 XW-300', category: '侦察设备', spec: 'XW-300/1000x', remainQty: 6, produceDate: '2024-05-15', validDate: '2029-05-14', maintainPeriod: '12个月', unit: '台', isBox: false, unitPrice: 28000, equipCode: '0101P01900',
    tags: ['品类特征/易碎品'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0200012024071505020XXXXXX0020', name: '防化服 FH-02', category: '防护装备', spec: 'FH-02/A级', remainQty: 30, produceDate: '2024-07-01', validDate: '2034-06-30', maintainPeriod: '6个月', unit: '套', isBox: false, unitPrice: 4500, equipCode: '0101P02000',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0210012024071805021XXXXXX0021', name: '电子围栏 DW-100', category: '安防设备', spec: 'DW-100/脉冲', remainQty: 20, produceDate: '2024-06-25', validDate: '2034-06-24', maintainPeriod: '12个月', unit: '套', isBox: false, unitPrice: 15000, equipCode: '0101P02100',
    tags: ['品类特征/贵重仪器'], supplier: '大华技术股份有限公司' },
  { code: '10101P0220012024061005022XXXXXX0022', name: '生命探测仪 SM-200', category: '应急救援', spec: 'SM-200/雷达', remainQty: 8, produceDate: '2024-05-10', validDate: '2029-05-09', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 95000, equipCode: '0101P02200',
    tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0230012024071505023XXXXXX0023', name: '移动指挥车 YZ-01', category: '交通工具', spec: 'YZ-01/越野', remainQty: 3, produceDate: '2024-07-01', validDate: '2034-06-30', maintainPeriod: '3个月', unit: '辆', isBox: false, unitPrice: 1800000, equipCode: '0101P02300',
    tags: ['活动类/双11备货'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0240012024071805024XXXXXX0024', name: '执法记录仪 DSJ-A8', category: '执法设备', spec: 'DSJ-A8/128G', remainQty: 45, produceDate: '2024-06-20', validDate: '2029-06-19', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 2200, equipCode: '0101P02400',
    tags: ['品类特征/易碎品'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0250012024071205025XXXXXX0025', name: '战术背心 ZS-01', category: '防护装备', spec: 'ZS-01/MOLLE', remainQty: 55, produceDate: '2024-06-15', validDate: '2034-06-14', maintainPeriod: '12个月', unit: '件', isBox: false, unitPrice: 800, equipCode: '0101P02500',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0260012024031505026XXXXXX0026', name: '强光手电 QG-600', category: '照明设备', spec: 'QG-600/LED', remainQty: 150, produceDate: '2024-02-28', validDate: '2029-02-27', maintainPeriod: '3个月', unit: '支', isBox: false, unitPrice: 320, equipCode: '0101P02600',
    tags: ['品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0270012024051005027XXXXXX0027', name: '防弹衣 FDY-2R', category: '防护装备', spec: 'FDY-2R/二级', remainQty: 35, produceDate: '2024-04-05', validDate: '2034-04-04', maintainPeriod: '12个月', unit: '件', isBox: false, unitPrice: 2200, equipCode: '0101P02700',
    tags: ['状态类/临期30天'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0280012024062005028XXXXXX0028', name: '无人机 M30T', category: '飞行器', spec: 'M30T/热成像', remainQty: 6, produceDate: '2024-05-25', validDate: '2029-05-24', maintainPeriod: '3个月', unit: '架', isBox: false, unitPrice: 45000, equipCode: '0101P02800',
    tags: ['活动类/双11备货'], supplier: '大疆创新科技有限公司' },
  { code: '10101P0290012024070105029XXXXXX0029', name: '卫星电话 WX-100', category: '通信装备', spec: 'WX-100/铱星', remainQty: 12, produceDate: '2024-06-01', validDate: '2034-05-31', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 12000, equipCode: '0101P02900',
    tags: ['品类特征/易碎品'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0300012024081505030XXXXXX0030', name: '战术手套 ST-02', category: '防护装备', spec: 'ST-02/防割', remainQty: 200, produceDate: '2024-07-20', validDate: '2034-07-19', maintainPeriod: '12个月', unit: '双', isBox: false, unitPrice: 180, equipCode: '0101P03000',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0310012024052005031XXXXXX0031', name: '便携式打印机 BJ-100', category: '办公设备', spec: 'BJ-100/热敏', remainQty: 25, produceDate: '2024-04-15', validDate: '2029-04-14', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 1500, equipCode: '0101P03100',
    tags: ['品类特征/贵重仪器'], supplier: '大华技术股份有限公司' },
  { code: '10101P0320012024080105032XXXXXX0032', name: '防毒面具 FD-03', category: '防护装备', spec: 'FD-03/全面罩', remainQty: 40, produceDate: '2024-07-01', validDate: '2034-06-30', maintainPeriod: '12个月', unit: '个', isBox: false, unitPrice: 650, equipCode: '0101P03200',
    tags: ['状态类/临期30天'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0330012024081005033XXXXXX0033', name: '移动硬盘 YD-2T', category: '存储设备', spec: 'YD-2T/USB3.0', remainQty: 60, produceDate: '2024-07-10', validDate: '2029-07-09', maintainPeriod: '3个月', unit: '个', isBox: false, unitPrice: 480, equipCode: '0101P03300',
    tags: ['活动类/双11备货'], supplier: '华为技术有限公司' },
  { code: '10101P0340012024090105034XXXXXX0034', name: '执法记录仪 DSJ-A9', category: '执法设备', spec: 'DSJ-A9/256G', remainQty: 20, produceDate: '2024-08-01', validDate: '2029-07-31', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 2800, equipCode: '0101P03400',
    tags: ['品类特征/易碎品'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0350012024080505035XXXXXX0035', name: '战术腰带 YD-01', category: '防护装备', spec: 'YD-01/多功能', remainQty: 100, produceDate: '2024-07-15', validDate: '2034-07-14', maintainPeriod: '12个月', unit: '条', isBox: false, unitPrice: 220, equipCode: '0101P03500',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0360012024090105036XXXXXX0036', name: '手持终端 XT-3000', category: '通信装备', spec: 'XT-3000/5G', remainQty: 30, produceDate: '2024-08-01', validDate: '2029-07-31', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 4500, equipCode: '0101P03600',
    tags: ['品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0370012024070105037XXXXXX0037', name: '夜视仪 YS-200', category: '侦察设备', spec: 'YS-200/二代', remainQty: 15, produceDate: '2024-06-15', validDate: '2029-06-14', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 35000, equipCode: '0101P03700',
    tags: ['状态类/临期30天'], supplier: '大华技术股份有限公司' },
  { code: '10101P0380012024030105038XXXXXX0038', name: '破门锤 PM-01', category: '破拆装备', spec: 'PM-01/手动', remainQty: 25, produceDate: '2024-02-10', validDate: '2034-02-09', maintainPeriod: '12个月', unit: '把', isBox: false, unitPrice: 850, equipCode: '0101P03800',
    tags: ['活动类/双11备货'], supplier: '华为技术有限公司' },
  { code: '10101P0390012024112005039XXXXXX0039', name: '防弹盾牌 FDP-5S', category: '防护装备', spec: 'FDP-5S/轮式', remainQty: 8, produceDate: '2024-10-01', validDate: '2034-09-30', maintainPeriod: '12个月', unit: '面', isBox: false, unitPrice: 8500, equipCode: '0101P03900',
    tags: ['品类特征/易碎品'], supplier: '华为技术有限公司' },
  { code: '10101P0400012024112005040XXXXXX0040', name: '战术背包 ZB-01', category: '防护装备', spec: 'ZB-01/45L', remainQty: 70, produceDate: '2024-10-15', validDate: '2034-10-14', maintainPeriod: '12个月', unit: '个', isBox: false, unitPrice: 380, equipCode: '0101P04000',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0410012024120105041XXXXXX0041', name: '执法终端 ZD-200', category: '执法设备', spec: 'ZD-200/安卓', remainQty: 35, produceDate: '2024-10-20', validDate: '2029-10-19', maintainPeriod: '3个月', unit: '台', isBox: false, unitPrice: 5200, equipCode: '0101P04100',
    tags: ['品类特征/贵重仪器'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0420012024100105042XXXXXX0042', name: '救生绳索 JS-100', category: '应急救援', spec: 'JS-100/50m', remainQty: 20, produceDate: '2024-09-01', validDate: '2034-08-31', maintainPeriod: '12个月', unit: '条', isBox: false, unitPrice: 1200, equipCode: '0101P04200',
    tags: ['状态类/临期30天'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0430012024061005043XXXXXX0043', name: '移动照明车 YD-500', category: '照明设备', spec: 'YD-500/LED', remainQty: 10, produceDate: '2024-05-10', validDate: '2029-05-09', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 18000, equipCode: '0101P04300',
    tags: ['活动类/双11备货'], supplier: '大华技术股份有限公司' },
  { code: '10101P0440012024112005044XXXXXX0044', name: '防刺服 FC-01', category: '防护装备', spec: 'FC-01/轻型', remainQty: 45, produceDate: '2024-10-05', validDate: '2034-10-04', maintainPeriod: '12个月', unit: '件', isBox: false, unitPrice: 1500, equipCode: '0101P04400',
    tags: ['品类特征/易碎品'], supplier: '华为技术有限公司' },
  { code: '10101P0450012024112005045XXXXXX0045', name: '搜爆服 SB-01', category: '防护装备', spec: 'SB-01/水冷', remainQty: 6, produceDate: '2024-10-10', validDate: '2034-10-09', maintainPeriod: '12个月', unit: '套', isBox: false, unitPrice: 120000, equipCode: '0101P04500',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0460012024110105046XXXXXX0046', name: '破窗器 PC-01', category: '破拆装备', spec: 'PC-01/电动', remainQty: 30, produceDate: '2024-09-20', validDate: '2034-09-19', maintainPeriod: '12个月', unit: '把', isBox: false, unitPrice: 680, equipCode: '0101P04600',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0470012024111505047XXXXXX0047', name: '指挥调度台 ZD-100', category: '通信装备', spec: 'ZD-100/大屏', remainQty: 4, produceDate: '2024-09-01', validDate: '2029-08-31', maintainPeriod: '3个月', unit: '套', isBox: false, unitPrice: 250000, equipCode: '0101P04700',
    tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司' },
  { code: '10101P0480012024031505048XXXXXX0048', name: '生命探测仪 SM-300', category: '应急救援', spec: 'SM-300/音视频', remainQty: 10, produceDate: '2024-02-01', validDate: '2029-01-31', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 68000, equipCode: '0101P04800',
    tags: ['活动类/双11备货'], supplier: '大华技术股份有限公司' },
  { code: '10101P0490012024120105049XXXXXX0049', name: '气体检测仪 QT-100', category: '侦察设备', spec: 'QT-100/多气体', remainQty: 18, produceDate: '2024-10-25', validDate: '2029-10-24', maintainPeriod: '6个月', unit: '台', isBox: false, unitPrice: 8500, equipCode: '0101P04900',
    tags: ['品类特征/易碎品'], supplier: '烽火通信科技股份有限公司' },
  { code: '10101P0500012024060105050XXXXXX0050', name: '排爆杆 PB-100', category: '破拆装备', spec: 'PB-100/伸缩', remainQty: 8, produceDate: '2024-05-01', validDate: '2034-04-30', maintainPeriod: '12个月', unit: '根', isBox: false, unitPrice: 3500, equipCode: '0101P05000',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
  { code: '10101P0510012024090105051XXXXXX0051', name: '防弹玻璃 FD-01', category: '防护装备', spec: 'FD-01/50mm', remainQty: 15, produceDate: '2024-08-01', validDate: '2034-07-31', maintainPeriod: '12个月', unit: '块', isBox: false, unitPrice: 2800, equipCode: '0101P05100',
    tags: ['品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司' },
  { code: '10101P0520012024102005052XXXXXX0052', name: '战术梯 ZT-01', category: '破拆装备', spec: 'ZT-01/铝合金', remainQty: 12, produceDate: '2024-09-10', validDate: '2034-09-09', maintainPeriod: '12个月', unit: '架', isBox: false, unitPrice: 1800, equipCode: '0101P05200',
    tags: ['状态类/临期30天'], supplier: '华为技术有限公司' },
]

// 仓库树形结构
const warehouseTree = [
  { name: '省厅装备库', children: ['省厅装备库A', '省厅装备库B'] },
  { name: '杭州市局', children: ['杭州市局装备库', '西湖分局装备库', '拱墅分局装备库'] },
  { name: '宁波市局', children: ['宁波市局装备库'] },
  { name: '温州市局', children: ['温州市局装备库'] },
]

const initialTransferData: TransferRecord[] = [
  {
    id: 'DB2024001', type: 'approval', desc: '年度常规调拨', fromWarehouse: '省厅装备库A', toWarehouse: '杭州市局装备库', sender: '省厅装备处', receiver: '杭州市局装备科',
    equipList: [
      { code: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 10, remainQty: 50, produceDate: '2024-01-15', validDate: '2029-01-14', maintainPeriod: '3个月', unit: '台', isBox: false, boxSpec: '', unitPrice: 3200, totalPrice: 32000, equipCode: '0101P00100',
    tags: ['活动类/双11备货'], supplier: '华为技术有限公司', remark: '' },
    ],
    status: 'draft', applicant: '张三', applyTime: '2024-03-15 09:30'
  },
  {
    id: 'DB2024002', type: 'emergency', desc: '突发事件应急支援', fromWarehouse: '杭州市局装备库', toWarehouse: '西湖分局装备库', sender: '杭州市局装备科', receiver: '西湖分局装备室',
    equipList: [
      { code: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 5, remainQty: 20, produceDate: '2023-11-10', validDate: '2033-11-09', maintainPeriod: '12个月', unit: '件', isBox: false, boxSpec: '', unitPrice: 2800, totalPrice: 14000, equipCode: '0101P00300',
    tags: ['品类特征/易碎品'], supplier: '华为技术有限公司', remark: '' },
      { code: '10101P0040012024011510005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 5, remainQty: 40, produceDate: '2023-12-05', validDate: '2033-12-04', maintainPeriod: '12个月', unit: '顶', isBox: false, boxSpec: '', unitPrice: 1500, totalPrice: 7500, equipCode: '0101P00400',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司', remark: '' },
    ],
    status: 'submitted', applicant: '李四', applyTime: '2024-03-14 14:20'
  },
  {
    id: 'DB2024003', type: 'approval', desc: '跨区域支援', fromWarehouse: '省厅装备库A', toWarehouse: '宁波市局装备库', sender: '省厅装备处', receiver: '宁波市局装备科',
    equipList: [
      { code: '10101P0060012024022010006XXXXXX0006', name: '防弹盾牌 FDP-3S', category: '防护装备', spec: 'FDP-3S/手持型', qty: 3, remainQty: 10, produceDate: '2023-10-15', validDate: '2033-10-14', maintainPeriod: '12个月', unit: '面', isBox: false, boxSpec: '', unitPrice: 3500, totalPrice: 10500, equipCode: '0101P00600',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司', remark: '' },
    ],
    status: 'approval1', applicant: '王五', applyTime: '2024-03-13 11:00'
  },
  {
    id: 'DB2024004', type: 'approval', desc: '装备轮换', fromWarehouse: '温州市局装备库', toWarehouse: '省厅装备库B', sender: '温州市局装备科', receiver: '省厅装备处',
    equipList: [
      { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 15, remainQty: 100, produceDate: '2024-01-20', validDate: '2029-01-19', maintainPeriod: '3个月', unit: '台', isBox: false, boxSpec: '', unitPrice: 1200, totalPrice: 18000, equipCode: '0101P00500',
    tags: ['状态类/临期30天'], supplier: '烽火通信科技股份有限公司', remark: '' },
      { code: '10101P0070012024031005007XXXXXX0007', name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', qty: 20, remainQty: 200, produceDate: '2024-03-01', validDate: '2029-02-28', maintainPeriod: '3个月', unit: '支', isBox: false, boxSpec: '', unitPrice: 280, totalPrice: 5600, equipCode: '0101P00700',
    tags: ['活动类/双11备货'], supplier: '大华技术股份有限公司', remark: '' },
    ],
    status: 'pending_out', applicant: '赵六', applyTime: '2024-03-12 16:45', approver: '李主任', approveTime: '2024-03-13 09:00'
  },
  {
    id: 'DB2024005', type: 'emergency', desc: '临时调拨', fromWarehouse: '西湖分局装备库', toWarehouse: '拱墅分局装备库', sender: '西湖分局装备室', receiver: '拱墅分局装备室',
    equipList: [
      { code: '10101P0020012024040105002XXXXXX0002', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 8, remainQty: 30, produceDate: '2024-02-20', validDate: '2029-02-19', maintainPeriod: '6个月', unit: '台', isBox: false, boxSpec: '', unitPrice: 1800, totalPrice: 14400, equipCode: '0101P00200',
    tags: ['品类特征/易碎品'], supplier: '海康威视数字技术股份有限公司', remark: '' },
    ],
    status: 'outed', applicant: '钱七', applyTime: '2024-03-10 10:15', approver: '系统(应急)', approveTime: '2024-03-10 10:16', outboundTime: '2024-03-11 08:30', outedTime: '2024-03-11 14:00'
  },
]

/* ================================================================
   Tab Configuration
   ================================================================ */

const tabList = [
  { key: 'transfer', label: '装备调拨' },
  { key: 'team-distribute', label: '所队装备配发' },
  { key: 'personal-alloc', label: '个人装备分配' },
]

/* ================================================================
   Main Component
   ================================================================ */

export default function EmergencyPage({ activeSubTab, onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab || 'transfer')

  useEffect(() => {
    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])

  return (
    <div className="p-6 space-y-4">
      {activeTab === 'transfer' && <TransferManagement onNavigate={onNavigate} />}
      {activeTab === 'team-distribute' && <TeamDistribute />}
      {activeTab === 'personal-alloc' && <PersonalAllocPage onNavigate={onNavigate} />}
    </div>
  )
}

/* ================================================================
   Transfer Management Sub-Component
   ================================================================ */

function TransferManagement({ onNavigate }: { onNavigate?: Props['onNavigate'] }) {
  const [records, setRecords] = useState<TransferRecord[]>(initialTransferData)
  const [filterType, setFilterType] = useState<string>('all')
  const [filterStatus, setFilterStatus] = useState<string>('all')
  const [filterFrom, setFilterFrom] = useState<string>('all')
  const [filterTo, setFilterTo] = useState<string>('all')
  const [searchId, setSearchId] = useState('')

  // Modals
  const [applyOpen, setApplyOpen] = useState(false)
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<TransferRecord | null>(null)
  const [editRecord, setEditRecord] = useState<TransferRecord | null>(null)

  // Apply form
  const [applyType, setApplyType] = useState<TransferType>('approval')
  const [applyDesc, setApplyDesc] = useState('')
  const [applyFrom, setApplyFrom] = useState('')
  const [applyTo, setApplyTo] = useState('')
  const [applySender, setApplySender] = useState('')
  const [applyReceiver, setApplyReceiver] = useState('')
  const [selectedEquips, setSelectedEquips] = useState<TransferEquip[]>([])

  // Reject modal
  const [rejectOpen, setRejectOpen] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [rejectRecord, setRejectRecord] = useState<TransferRecord | null>(null)

  // Approve modal
  const [approveOpen, setApproveOpen] = useState(false)
  const [approveRemark, setApproveRemark] = useState('')
  const [approveRecord, setApproveRecord] = useState<TransferRecord | null>(null)

  // Equipment select modal
  const [equipSelectOpen, setEquipSelectOpen] = useState(false)
  const [equipSearchLocation, setEquipSearchLocation] = useState('')
  const [equipSearchName, setEquipSearchName] = useState('')
  const [equipSearchCategory, setEquipSearchCategory] = useState('')

  const filtered = records.filter(r => {
    if (filterType !== 'all' && r.type !== filterType) return false
    if (filterStatus !== 'all' && r.status !== filterStatus) return false
    if (filterFrom !== 'all' && r.fromWarehouse !== filterFrom) return false
    if (filterTo !== 'all' && r.toWarehouse !== filterTo) return false
    if (searchId && !r.id.toLowerCase().includes(searchId.toLowerCase())) return false
    return true
  })

  const resetApplyForm = () => {
    setApplyType('approval')
    setApplyDesc('')
    setApplyFrom('')
    setApplyTo('')
    setApplySender('')
    setApplyReceiver('')
    setSelectedEquips([])
  }

  const handleApplySubmit = (status: 'draft' | 'submitted') => {
    if (!applyFrom || !applyTo) { alert('请选择调出和调入仓库'); return }
    if (applyFrom === applyTo) { alert('调出仓库和调入仓库不能相同'); return }
    if (selectedEquips.length === 0) { alert('请至少选择一件装备'); return }

    const newId = `DB2024${String(records.length + 1).padStart(3, '0')}`
    const now = new Date().toLocaleString('zh-CN', { hour12: false })

    const newRecord: TransferRecord = {
      id: newId,
      type: applyType,
      desc: applyDesc,
      fromWarehouse: applyFrom,
      toWarehouse: applyTo,
      sender: applySender || applyFrom,
      receiver: applyReceiver || applyTo,
      equipList: selectedEquips.map(e => ({ ...e })),
      status,
      applicant: '当前用户',
      applyTime: now,
    }
    setRecords(prev => [newRecord, ...prev])
    setApplyOpen(false)
    setEditRecord(null)
    resetApplyForm()
    alert(status === 'draft' ? `调拨单 ${newId} 已保存为草稿` : `调拨申请 ${newId} 已提交`)
  }

  const handleEditSave = (status: 'draft' | 'submitted') => {
    if (!editRecord) return
    if (!applyFrom || !applyTo) { alert('请选择调出和调入仓库'); return }
    if (applyFrom === applyTo) { alert('调出仓库和调入仓库不能相同'); return }
    if (selectedEquips.length === 0) { alert('请至少选择一件装备'); return }

    setRecords(prev => prev.map(r => r.id === editRecord.id ? {
      ...r,
      type: applyType,
      desc: applyDesc,
      fromWarehouse: applyFrom,
      toWarehouse: applyTo,
      sender: applySender || applyFrom,
      receiver: applyReceiver || applyTo,
      equipList: selectedEquips.map(e => ({ ...e })),
      status,
    } : r))
    setApplyOpen(false)
    setEditRecord(null)
    resetApplyForm()
    alert(`调拨单 ${editRecord.id} 已${status === 'draft' ? '保存' : '重新提交'}`)
  }

  const openEdit = (record: TransferRecord) => {
    setEditRecord(record)
    setApplyType(record.type)
    setApplyDesc(record.desc)
    setApplyFrom(record.fromWarehouse)
    setApplyTo(record.toWarehouse)
    setApplySender(record.sender)
    setApplyReceiver(record.receiver)
    setSelectedEquips(record.equipList.map(e => ({ ...e })))
    setApplyOpen(true)
  }

  const handleApproveClick = (record: TransferRecord) => {
    setApproveRecord(record)
    setApproveRemark('')
    setApproveOpen(true)
  }

  const confirmApprove = () => {
    if (!approveRecord) return
    setRecords(prev => prev.map(r => r.id === approveRecord.id ? {
      ...r, status: 'pending_out' as TransferStatus, approver: '当前用户', approveTime: new Date().toLocaleString('zh-CN', { hour12: false })
    } : r))
    setApproveOpen(false)
    setApproveRecord(null)
    setApproveRemark('')
    alert(`调拨单 ${approveRecord.id} 已审批通过，待出库`)
  }

  const handleRejectClick = (record: TransferRecord) => {
    setRejectRecord(record)
    setRejectReason('')
    setRejectOpen(true)
  }

  const confirmReject = () => {
    if (!rejectReason.trim()) { alert('请输入驳回原因'); return }
    if (!rejectRecord) return
    setRecords(prev => prev.map(r => r.id === rejectRecord.id ? {
      ...r, status: 'rejected' as TransferStatus, approver: '当前用户', approveTime: new Date().toLocaleString('zh-CN', { hour12: false }), rejectReason: rejectReason.trim()
    } : r))
    setRejectOpen(false)
    setRejectRecord(null)
    setRejectReason('')
    alert(`调拨单 ${rejectRecord.id} 已驳回`)
  }

  const handleOutbound = (record: TransferRecord) => {
    setRecords(prev => prev.map(r => r.id === record.id ? {
      ...r, status: 'outed' as TransferStatus, outboundTime: new Date().toLocaleString('zh-CN', { hour12: false })
    } : r))
    alert(`调拨单 ${record.id} 已确认出库`)
  }

  const handleDelete = (record: TransferRecord) => {
    if (confirm(`确定删除调拨单 ${record.id} 吗？`)) {
      setRecords(prev => prev.filter(r => r.id !== record.id))
    }
  }

  const openDetail = (record: TransferRecord) => {
    setSelectedRecord(record)
    setDetailOpen(true)
  }

  const addEquipFromStock = (mat: typeof stockMaterials[0]) => {
    const exists = selectedEquips.find(e => e.code === mat.code)
    if (exists) {
      setSelectedEquips(prev => prev.map(e => e.code === mat.code ? { ...e, qty: e.qty + 1, totalPrice: (e.qty + 1) * e.unitPrice } : e))
    } else {
      const newEquip: TransferEquip = {
        ...mat,
        qty: 1,
        totalPrice: mat.unitPrice,
        isBox: false,
        boxSpec: '',
        remark: '',
      }
      setSelectedEquips(prev => [...prev, newEquip])
    }
  }

  const removeEquip = (code: string) => {
    setSelectedEquips(prev => prev.filter(e => e.code !== code))
  }

  const updateEquipQty = (code: string, qty: number) => {
    setSelectedEquips(prev => prev.map(e => e.code === code ? { ...e, qty: Math.max(1, qty), totalPrice: Math.max(1, qty) * e.unitPrice } : e))
  }

  const updateEquipBox = (code: string, isBox: boolean) => {
    setSelectedEquips(prev => prev.map(e => e.code === code ? { ...e, isBox, boxSpec: isBox ? '1箱/10个' : '' } : e))
  }

  const updateEquipBoxSpec = (code: string, boxSpec: string) => {
    setSelectedEquips(prev => prev.map(e => e.code === code ? { ...e, boxSpec } : e))
  }

  const filteredStock = stockMaterials.filter(m => {
    if (equipSearchLocation && !m.supplier.includes(equipSearchLocation)) return false
    if (equipSearchName && !m.name.includes(equipSearchName)) return false
    if (equipSearchCategory && !m.category.includes(equipSearchCategory)) return false
    return true
  })

  const selectedStockCodes = new Set(selectedEquips.map(e => e.code))

  return (
    <div className="space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备调拨</span>
      </div>

      {/* Action bar - 无统计卡片 */}
      <div className="flex items-center gap-2">
        <button className="btn-primary flex items-center gap-1" onClick={() => { resetApplyForm(); setEditRecord(null); setApplyOpen(true) }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          发起调拨
        </button>
      </div>

      {/* Filter area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨单号</label>
            <input className="form-input w-36" placeholder="请输入..." value={searchId} onChange={e => setSearchId(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨类型</label>
            <select className="form-input w-28" value={filterType} onChange={e => setFilterType(e.target.value)}>
              <option value="all">全部</option>
              <option value="emergency">应急调拨</option>
              <option value="approval">审批调拨</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨状态</label>
            <select className="form-input w-28" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
              <option value="all">全部</option>
              <option value="draft">草稿</option>
              <option value="submitted">已提交</option>
              <option value="approval1">审批1</option>
              <option value="pending_out">待出库</option>
              <option value="outed">已出库</option>
              <option value="rejected">已驳回</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库</label>
            <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={filterFrom} onChange={setFilterFrom} mode="name" showAll allValue="all" className="w-32" />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调入仓库</label>
            <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={filterTo} onChange={setFilterTo} mode="name" showAll allValue="all" className="w-32" />
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default" onClick={() => { setFilterType('all'); setFilterStatus('all'); setFilterFrom('all'); setFilterTo('all'); setSearchId('') }}>重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Data table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>调拨单号</th>
              <th>调拨类型</th>
              <th>调出仓库</th>
              <th>调入仓库</th>
              <th>装备清单</th>
              <th>申请人</th>
              <th>申请时间</th>
              <th>调拨状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={10} className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>
            )}
            {filtered.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td><span className={`tag ${r.type === 'emergency' ? 'tag-red' : 'tag-blue'} text-xs`}>{typeLabel(r.type)}</span></td>
                <td>{r.fromWarehouse}</td>
                <td>{r.toWarehouse}</td>
                <td>
                  <div className="text-xs max-w-[200px]">
                    {r.equipList.map((e, i) => (
                      <span key={i} className="inline-block mr-2">{e.name} x{e.qty}</span>
                    ))}
                  </div>
                </td>
                <td>{r.applicant}</td>
                <td className="text-xs">{r.applyTime}</td>
                <td><span className={`tag ${transferStatusMap[r.status].tag} text-xs`}>{transferStatusMap[r.status].label}</span></td>
                <td>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDetail(r)}>查看</button>
                    {r.status === 'approval1' && (
                      <>
                        <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => handleApproveClick(r)}>通过</button>
                        <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleRejectClick(r)}>驳回</button>
                      </>
                    )}
                    {/* pending_out: 仅查看，无操作按钮 */}
                    {(r.status === 'draft' || r.status === 'rejected') && (
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openEdit(r)}>编辑</button>
                    )}
                    {(r.status === 'draft' || r.status === 'rejected') && (
                      <button className="text-xs hover:underline" style={{ color: '#999' }} onClick={() => handleDelete(r)}>删除</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== Apply/Edit Modal ===== */}
      {applyOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setApplyOpen(false); setEditRecord(null); resetApplyForm() }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {editRecord ? `编辑调拨单 - ${editRecord.id}` : applyType === 'emergency' ? '应急快速调拨' : '发起调拨申请'}
              </h3>
              <button onClick={() => { setApplyOpen(false); setEditRecord(null); resetApplyForm() }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              {/* Type selector - 保持按钮切换 */}
              {!editRecord && (
                <div className="flex items-center gap-4">
                  <span className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>调拨类型</span>
                  <div className="flex gap-2">
                    <button onClick={() => setApplyType('approval')} className={`px-4 py-2 text-sm rounded-lg border transition-all ${applyType === 'approval' ? 'border-blue-500 text-blue-600 bg-blue-50 font-medium' : 'border-gray-200 hover:border-gray-300'}`}>审批调拨</button>
                    <button onClick={() => setApplyType('emergency')} className={`px-4 py-2 text-sm rounded-lg border transition-all ${applyType === 'emergency' ? 'border-red-500 text-red-600 bg-red-50 font-medium' : 'border-gray-200 hover:border-gray-300'}`}>应急调拨</button>
                  </div>
                </div>
              )}

              {/* 调拨性质说明 */}
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调拨性质说明</label>
                <input className="form-input w-full" placeholder="请输入调拨性质说明..." value={applyDesc} onChange={e => setApplyDesc(e.target.value)} />
              </div>

              {/* Warehouse selection */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库 <span className="text-red-400">*</span></label>
                  <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={applyFrom} onChange={val => { setApplyFrom(val); setApplySender(val) }} mode="name" placeholder="请选择" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调入仓库 <span className="text-red-400">*</span></label>
                  <WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={applyTo} onChange={val => { setApplyTo(val); setApplyReceiver(val) }} mode="name" placeholder="请选择" />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发物单位</label>
                  <input className="form-input w-full" placeholder="自动带出" value={applySender} onChange={e => setApplySender(e.target.value)} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>收物单位</label>
                  <input className="form-input w-full" placeholder="自动带出" value={applyReceiver} onChange={e => setApplyReceiver(e.target.value)} />
                </div>
              </div>

              {/* Equipment selection */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium" style={{ color: 'var(--text-primary)' }}>物资明细 <span className="text-red-400">*</span></label>
                  <button className="btn-primary text-xs flex items-center gap-1 px-3 py-1.5" onClick={() => { setEquipSearchLocation(''); setEquipSearchName(''); setEquipSearchCategory(''); setEquipSelectOpen(true) }}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    添加物资
                  </button>
                </div>
                <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <table className="w-full text-xs">
                    <thead>
                      <tr style={{ background: 'var(--table-header-bg)' }}>
                        <th className="p-2 text-left">物资名称</th>
                        <th className="p-2 text-left">物资类别</th>
                        <th className="p-2 text-left">规格型号</th>
                        <th className="p-2 text-center w-14">数量</th>
                        <th className="p-2 text-center w-14">剩余数量</th>
                        <th className="p-2 text-center w-10">单位</th>
                        <th className="p-2 text-right w-16">单价</th>
                        <th className="p-2 text-right w-16">总价</th>
                        <th className="p-2 text-left w-24">装备编码</th>
                        <th className="p-2 text-left">供应商</th>
                        <th className="p-2 w-12"></th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedEquips.length === 0 && (
                        <tr><td colSpan={11} className="p-6 text-center text-xs" style={{ color: 'var(--text-disabled)' }}>请点击「添加物资」按钮添加装备</td></tr>
                      )}
                      {selectedEquips.map(e => (
                        <tr key={e.code} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="p-2 font-medium">{e.name}</td>
                          <td className="p-2">{e.category}</td>
                          <td className="p-2">{e.spec}</td>
                          <td className="p-2 text-center">
                            <input type="number" min={1} max={e.remainQty} className="form-input w-14 text-xs text-center py-0.5" value={e.qty} onChange={ev => updateEquipQty(e.code, Number(ev.target.value))} />
                          </td>
                          <td className="p-2 text-center" style={{ color: '#52c41a' }}>{e.remainQty}</td>
                          <td className="p-2 text-center">{e.unit}</td>
                          <td className="p-2 text-right font-mono">{e.unitPrice.toLocaleString()}</td>
                          <td className="p-2 text-right font-mono font-medium" style={{ color: '#1890ff' }}>{e.totalPrice.toLocaleString()}</td>
                          <td className="p-2 font-mono">{e.equipCode}</td>
                          <td className="p-2">{e.supplier}</td>
                          <td className="p-2 text-center">
                            <button className="text-xs px-1.5 rounded hover:bg-red-50 transition-colors" style={{ color: '#ff4d4f' }} onClick={() => removeEquip(e.code)}>删除</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    {selectedEquips.length > 0 && (
                      <tfoot>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <td colSpan={7} className="p-2 text-right text-xs font-semibold">合计</td>
                          <td className="p-2 text-right text-xs font-mono font-bold" style={{ color: '#1890ff' }}>¥{selectedEquips.reduce((sum, e) => sum + e.totalPrice, 0).toLocaleString()}</td>
                          <td colSpan={3}></td>
                        </tr>
                      </tfoot>
                    )}
                  </table>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setApplyOpen(false); setEditRecord(null); resetApplyForm() }}>取消</button>
              {editRecord ? (
                <>
                  <button className="btn-default" onClick={() => handleEditSave('draft')}>保存草稿</button>
                  <button className="btn-primary" onClick={() => handleEditSave('submitted')}>再次提交</button>
                </>
              ) : (
                <>
                  <button className="btn-default" onClick={() => handleApplySubmit('draft')}>保存草稿</button>
                  <button className="btn-primary" onClick={() => handleApplySubmit('submitted')}>提交申请</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ===== Equipment Select Modal (左右分栏) ===== */}
      {equipSelectOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setEquipSelectOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200" style={{ width: '75vw', height: '90vh' }}>
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setEquipSelectOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            {/* Search */}
            <div className="px-6 py-3 border-b flex items-center gap-3" style={{ borderColor: 'var(--border-color)' }}>
              <select className="form-input text-sm w-36" value={equipSearchLocation} onChange={e => setEquipSearchLocation(e.target.value)}>
                <option value="">全部位置</option>
                {warehouseList.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
              <input className="form-input text-sm w-40" placeholder="物资名称..." value={equipSearchName} onChange={e => setEquipSearchName(e.target.value)} />
              <select className="form-input text-sm w-32" value={equipSearchCategory} onChange={e => setEquipSearchCategory(e.target.value)}>
                <option value="">全部类别</option>
                <option>通信装备</option>
                <option>执法设备</option>
                <option>防护装备</option>
                <option>照明设备</option>
                <option>应急救援</option>
                <option>侦察设备</option>
                <option>破拆装备</option>
                <option>交通工具</option>
              </select>
              <button className="btn-primary text-xs" onClick={() => {}}>查询</button>
            </div>
            {/* Content - 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：库存装备列表 */}
              <div className="w-[60%] border-r overflow-y-auto p-4" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs">
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="p-2 text-center w-8"><input type="checkbox" /></th>
                      <th className="p-2 text-left">物资名称</th>
                      <th className="p-2 text-left">物资类别</th>
                      <th className="p-2 text-left">规格型号</th>
                      <th className="p-2 text-center">生产日期</th>
                      <th className="p-2 text-center">有效期</th>
                      <th className="p-2 text-right">剩余</th>
                      <th className="p-2 text-center">单位</th>
                      <th className="p-2 text-right">单价</th>
                      <th className="p-2 text-left">装备编码</th>
                      <th className="p-2 text-left">供应商</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.length === 0 && (
                      <tr><td colSpan={11} className="p-6 text-center" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>
                    )}
                    {filteredStock.map(m => (
                      <tr key={m.code} className="border-t hover:bg-blue-50/50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="p-2 text-center">
                          <input type="checkbox" checked={selectedStockCodes.has(m.code)} onChange={() => addEquipFromStock(m)} />
                        </td>
                        <td className="p-2 font-medium">{m.name}</td>
                        <td className="p-2">{m.category}</td>
                        <td className="p-2">{m.spec}</td>
                        <td className="p-2 text-center">{m.produceDate}</td>
                        <td className="p-2 text-center">{m.validDate}</td>
                        <td className="p-2 text-right font-mono" style={{ color: '#52c41a' }}>{m.remainQty}</td>
                        <td className="p-2 text-center">{m.unit}</td>
                        <td className="p-2 text-right font-mono">{m.unitPrice.toLocaleString()}</td>
                        <td className="p-2 font-mono">{m.equipCode}</td>
                        <td className="p-2">{m.supplier}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* 右侧：已选择装备 */}
              <div className="w-[40%] overflow-y-auto p-4" style={{ background: 'var(--content-bg)' }}>
                <h4 className="text-sm font-semibold mb-3">已选择装备 ({selectedEquips.length})</h4>
                {selectedEquips.length === 0 && (
                  <div className="text-center py-12 text-sm" style={{ color: 'var(--text-disabled)' }}>请点击左侧装备进行添加</div>
                )}
                <div className="space-y-2">
                  {selectedEquips.map(e => (
                    <div key={e.code} className="p-3 rounded-lg border bg-white" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">{e.name}</span>
                        <button className="text-xs px-1.5 rounded hover:bg-red-50" style={{ color: '#ff4d4f' }} onClick={() => removeEquip(e.code)}>删除</button>
                      </div>
                      <div className="grid grid-cols-2 gap-1 text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>
                        <span>类别: {e.category}</span>
                        <span>规格: {e.spec}</span>
                        <span>编码: {e.equipCode}</span>
                        <span>余量: {e.remainQty}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs">数量:</span>
                        <input type="number" min={1} max={e.remainQty} className="form-input w-16 text-xs text-center py-0.5" value={e.qty} onChange={ev => updateEquipQty(e.code, Number(ev.target.value))} />
                        <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>单价: ¥{e.unitPrice.toLocaleString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
                {selectedEquips.length > 0 && (
                  <button className="btn-primary w-full mt-4" onClick={() => setEquipSelectOpen(false)}>确认添加</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Detail Modal ===== */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">调拨详情 - {selectedRecord.id}</h3>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* Info cards */}
              <div className="grid grid-cols-4 gap-3">
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>调拨类型</p>
                  <p className="text-sm font-bold mt-1" style={{ color: selectedRecord.type === 'emergency' ? '#ff4d4f' : '#1890ff' }}>{typeLabel(selectedRecord.type)}</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>调拨路线</p>
                  <p className="text-sm font-bold mt-1">{selectedRecord.fromWarehouse} → {selectedRecord.toWarehouse}</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>当前状态</p>
                  <p className="text-sm font-bold mt-1" style={{ color: transferStatusMap[selectedRecord.status].color }}>{transferStatusMap[selectedRecord.status].label}</p>
                </div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>调拨性质</p>
                  <p className="text-sm font-bold mt-1">{selectedRecord.desc || '-'}</p>
                </div>
              </div>

              {/* Basic info */}
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>调拨信息</p>
                  <div className="space-y-1">
                    <p><span style={{ color: 'var(--text-secondary)' }}>发物单位：</span>{selectedRecord.sender}</p>
                    <p><span style={{ color: 'var(--text-secondary)' }}>收物单位：</span>{selectedRecord.receiver}</p>
                    <p><span style={{ color: 'var(--text-secondary)' }}>申请人：</span>{selectedRecord.applicant}</p>
                    <p><span style={{ color: 'var(--text-secondary)' }}>申请时间：</span>{selectedRecord.applyTime}</p>
                    {selectedRecord.approver && <p><span style={{ color: 'var(--text-secondary)' }}>审批人：</span>{selectedRecord.approver}</p>}
                    {selectedRecord.approveTime && <p><span style={{ color: 'var(--text-secondary)' }}>审批时间：</span>{selectedRecord.approveTime}</p>}
                  </div>
                </div>
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>时间节点</p>
                  <div className="space-y-1">
                    {selectedRecord.outboundTime && <p><span style={{ color: 'var(--text-secondary)' }}>出库时间：</span>{selectedRecord.outboundTime}</p>}
                    {selectedRecord.outedTime && <p><span style={{ color: 'var(--text-secondary)' }}>完成时间：</span>{selectedRecord.outedTime}</p>}
                    {selectedRecord.rejectReason && <p><span style={{ color: '#ff4d4f' }}>驳回原因：</span>{selectedRecord.rejectReason}</p>}
                  </div>
                </div>
              </div>

              {/* Equipment list */}
              <div>
                <h4 className="text-sm font-semibold mb-2">装备清单</h4>
                <table className="w-full text-xs border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="p-2 text-left">物资名称</th>
                      <th className="p-2 text-left">物资类别</th>
                      <th className="p-2 text-left">规格型号</th>
                      <th className="p-2 text-center">数量</th>
                      <th className="p-2 text-center">单位</th>
                      <th className="p-2 text-right">单价</th>
                      <th className="p-2 text-right">总价</th>
                      <th className="p-2 text-left">装备编码</th>
                      <th className="p-2 text-left">供应商</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedRecord.equipList.map((e, i) => (
                      <tr key={i} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="p-2 font-medium">{e.name}</td>
                        <td className="p-2">{e.category}</td>
                        <td className="p-2">{e.spec}</td>
                        <td className="p-2 text-center">{e.qty}</td>
                        <td className="p-2 text-center">{e.unit}{e.isBox ? `(${e.boxSpec})` : ''}</td>
                        <td className="p-2 text-right font-mono">{e.unitPrice.toLocaleString()}</td>
                        <td className="p-2 text-right font-mono font-medium" style={{ color: '#1890ff' }}>{e.totalPrice.toLocaleString()}</td>
                        <td className="p-2 font-mono">{e.equipCode}</td>
                        <td className="p-2">{e.supplier}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <td colSpan={6} className="p-2 text-right text-xs font-semibold">合计</td>
                      <td className="p-2 text-right text-xs font-mono font-bold" style={{ color: '#1890ff' }}>¥{selectedRecord.equipList.reduce((s, e) => s + e.totalPrice, 0).toLocaleString()}</td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {/* Action buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button className="btn-default" onClick={() => setDetailOpen(false)}>关闭</button>
                {selectedRecord.status === 'approval1' && (
                  <>
                    <button className="btn-primary" onClick={() => { handleApproveClick(selectedRecord); setDetailOpen(false) }}>通过</button>
                    <button className="btn-danger" onClick={() => { handleRejectClick(selectedRecord); setDetailOpen(false) }}>驳回</button>
                  </>
                )}
                {selectedRecord.status === 'pending_out' && (
                  <button className="btn-primary" onClick={() => { handleOutbound(selectedRecord); setDetailOpen(false) }}>确认出库</button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Approve Modal ===== */}
      {approveOpen && approveRecord && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setApproveOpen(false); setApproveRecord(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
              </div>
              <h3 className="text-base font-semibold">审批通过</h3>
            </div>
            <div className="mb-5">
              <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                调拨单号：<span className="font-mono font-medium">{approveRecord.id}</span><br/>
                调出仓库：<span>{approveRecord.fromWarehouse}</span> → 调入仓库：<span>{approveRecord.toWarehouse}</span>
              </p>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批意见（可选）</label>
              <textarea className="form-input w-full text-sm" rows={3} placeholder="请输入审批意见..." value={approveRemark} onChange={e => setApproveRemark(e.target.value)} />
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => { setApproveOpen(false); setApproveRecord(null) }}>取消</button>
              <button className="btn-primary" onClick={confirmApprove}>确认通过</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Reject Modal ===== */}
      {rejectOpen && rejectRecord && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setRejectOpen(false); setRejectRecord(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </div>
              <h3 className="text-base font-semibold">驳回调拨申请</h3>
            </div>
            <div className="mb-5">
              <p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>
                调拨单号：<span className="font-mono font-medium">{rejectRecord.id}</span><br/>
                调出仓库：<span>{rejectRecord.fromWarehouse}</span> → 调入仓库：<span>{rejectRecord.toWarehouse}</span>
              </p>
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>驳回原因 <span className="text-red-400">*</span></label>
              <textarea className="form-input w-full text-sm" rows={3} placeholder="请输入驳回原因..." value={rejectReason} onChange={e => setRejectReason(e.target.value)} />
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => { setRejectOpen(false); setRejectRecord(null) }}>取消</button>
              <button className="btn-danger" onClick={confirmReject}>确认驳回</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ================================================================
   Team Distribute - Personal Equipment Allocation
   ================================================================ */

interface Person {
  id: string
  name: string
  badge: string
  dept: string
  equips: { allocId: string; code: string; name: string; spec: string; unit: string; allocTime: string; status: 'allocated' | 'cancelled' }[]
}

const depts = ['刑警支队', '治安支队', '交警支队', '特警支队', '网安支队']

const equipPool = [
  { code: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', name: '手持终端 XT-2000', spec: 'XT-2000/黑色', unit: '台' },
  { code: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', name: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G', unit: '台' },
  { code: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', name: '对讲机 PD780G', spec: 'PD780G/U段', unit: '台' },
  { code: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', name: '防弹背心 FDY-3R', spec: 'FDY-3R/三级', unit: '件' },
  { code: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', name: '战术头盔 MICH-2000', spec: 'MICH-2000/L号', unit: '顶' },
  { code: '1-0-1-01-P007-001-20240310-05-007XXXXXX-0006', name: '强光手电 QG-500', spec: 'QG-500/充电款', unit: '支' },
  { code: '1-0-1-01-P008-001-20240120-10-008XXXXXX-0007', name: '应急照明灯 YD-100', spec: 'YD-100/LED', unit: '台' },
  { code: '1-0-1-01-P006-001-20240220-10-006XXXXXX-0004', name: '防弹盾牌 FDP-3S', spec: 'FDP-3S/手持型', unit: '面' },
]

const initialPersons: Person[] = [
  { id: 'P001', name: '张警官', badge: 'JS001', dept: '刑警支队', equips: [
    { allocId: 'PF2024001', code: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', name: '手持终端 XT-2000', spec: 'XT-2000/黑色', unit: '台', allocTime: '2024-03-01 09:30:00', status: 'allocated' },
    { allocId: 'PF2024002', code: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', name: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G', unit: '台', allocTime: '2024-03-01 09:30:00', status: 'allocated' },
  ]},
  { id: 'P002', name: '李警官', badge: 'JS002', dept: '治安支队', equips: [
    { allocId: 'PF2024003', code: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', name: '对讲机 PD780G', spec: 'PD780G/U段', unit: '台', allocTime: '2024-03-05 14:00:00', status: 'allocated' },
  ]},
  { id: 'P003', name: '王警官', badge: 'JS003', dept: '交警支队', equips: [] },
  { id: 'P004', name: '赵警官', badge: 'JS004', dept: '特警支队', equips: [
    { allocId: 'PF2024004', code: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', name: '防弹背心 FDY-3R', spec: 'FDY-3R/三级', unit: '件', allocTime: '2024-02-20 10:00:00', status: 'allocated' },
    { allocId: 'PF2024005', code: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', name: '战术头盔 MICH-2000', spec: 'MICH-2000/L号', unit: '顶', allocTime: '2024-02-20 10:00:00', status: 'allocated' },
    { allocId: 'PF2024006', code: '1-0-1-01-P006-001-20240220-10-006XXXXXX-0004', name: '防弹盾牌 FDP-3S', spec: 'FDP-3S/手持型', unit: '面', allocTime: '2024-02-20 10:00:00', status: 'allocated' },
  ]},
  { id: 'P005', name: '钱警官', badge: 'JS005', dept: '刑警支队', equips: [] },
  { id: 'P006', name: '孙警官', badge: 'JS006', dept: '网安支队', equips: [
    { allocId: 'PF2024007', code: '1-0-1-01-P007-001-20240310-05-007XXXXXX-0006', name: '强光手电 QG-500', spec: 'QG-500/充电款', unit: '支', allocTime: '2024-03-10 08:30:00', status: 'allocated' },
  ]},
]

/* ================================================================
   Team Distribute - 所队配发管理 (重构版)
   ================================================================ */

type DistributeStatus = 'draft' | 'submitted' | 'approval1' | 'pending_out' | 'outed'

interface DistributeEquip {
  code: string
  tags?: string[]
  name: string
  category: string
  spec: string
  qty: number
  remainQty: number
  produceDate: string
  validDate: string
  maintainPeriod: string
  unit: string
  unitPrice: number
  totalPrice: number
  equipCode: string
  supplier: string
  remark: string
}

interface DistributeRecord {
  id: string
  fromWarehouse: string
  distributeUnit: string
  equipList: DistributeEquip[]
  remark: string
  status: DistributeStatus
  applicant: string
  approver?: string
  applyTime: string
  approveTime?: string
}

const distributeStatusMap: Record<DistributeStatus, { label: string; tag: string }> = {
  draft: { label: '草稿', tag: 'tag-gray' },
  submitted: { label: '已提交', tag: 'tag-yellow' },
  approval1: { label: '审批1', tag: 'tag-blue' },
  pending_out: { label: '待出库', tag: 'tag-cyan' },
  outed: { label: '已出库', tag: 'tag-green' },
}

// 组织结构树形数据
interface OrgTreeNode {
  id: string
  name: string
  children?: OrgTreeNode[]
  badge?: string
}

const orgTreeData: OrgTreeNode[] = [
  {
    id: 'ORG001', name: '浙江省公安厅',
    children: [
      {
        id: 'ORG002', name: '杭州市局',
        children: [
          {
            id: 'ORG003', name: '西湖分局',
            children: [
              { id: 'P001', name: '张三', badge: 'JS001' },
              { id: 'P002', name: '李四', badge: 'JS002' },
              { id: 'P003', name: '王五', badge: 'JS003' },
            ]
          },
          {
            id: 'ORG004', name: '拱墅分局',
            children: [
              { id: 'P004', name: '赵六', badge: 'JS004' },
              { id: 'P005', name: '钱七', badge: 'JS005' },
            ]
          },
        ]
      },
      { id: 'ORG005', name: '宁波市局', children: [{ id: 'P006', name: '孙八', badge: 'JS006' }] },
      { id: 'ORG006', name: '温州市局', children: [{ id: 'P007', name: '周九', badge: 'JS007' }] },
    ]
  },
]

// 预制装备模板
interface EquipTemplate {
  id: string
  name: string
  equips: TemplateEquip[]
}

interface TemplateEquip {
  code: string
  name: string
  category: string
  spec: string
  qty: number
  unit: string
  unitPrice: number
  equipCode: string
  supplier: string
  tags?: string[]
}

const initialTemplates: EquipTemplate[] = [
  {
    id: 'TP001', name: '刑警支队模板',
    equips: [
      { code: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 10, unit: '台', unitPrice: 3200, equipCode: '0101P00100',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
      { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 10, unit: '台', unitPrice: 1200, equipCode: '0101P00500',
    tags: ['品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
      { code: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 5, unit: '件', unitPrice: 2800, equipCode: '0101P00300',
    tags: ['状态类/临期30天'], supplier: '华为技术有限公司' },
      { code: '10101P0040012024011510005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 5, unit: '顶', unitPrice: 1500, equipCode: '0101P00400',
    tags: ['活动类/双11备货'], supplier: '中兴通讯股份有限公司' },
      { code: '10101P0020012024040105003XXXXXX0003', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 5, unit: '台', unitPrice: 1800, equipCode: '0101P00200',
    tags: ['品类特征/易碎品'], supplier: '海康威视数字技术股份有限公司' },
    ]
  },
  {
    id: 'TP002', name: '治安支队模板',
    equips: [
      { code: '10101P0020012024040105003XXXXXX0003', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 10, unit: '台', unitPrice: 1800, equipCode: '0101P00200',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '海康威视数字技术股份有限公司' },
      { code: '10101P0070012024031005007XXXXXX0007', name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', qty: 20, unit: '支', unitPrice: 280, equipCode: '0101P00700',
    tags: ['品类特征/贵重仪器'], supplier: '大华技术股份有限公司' },
      { code: '10101P0130012024030505013XXXXXX0013', name: '急救包 JJ-02', category: '应急救援', spec: 'JJ-02/综合型', qty: 10, unit: '个', unitPrice: 580, equipCode: '0101P01300',
    tags: ['状态类/临期30天'], supplier: '华为技术有限公司' },
      { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 5, unit: '台', unitPrice: 1200, equipCode: '0101P00500',
    tags: ['活动类/双11备货'], supplier: '烽火通信科技股份有限公司' },
    ]
  },
  {
    id: 'TP003', name: '交警支队模板',
    equips: [
      { code: '10101P0070012024031005007XXXXXX0007', name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', qty: 20, unit: '支', unitPrice: 280, equipCode: '0101P00700',
    tags: ['品类特征/易碎品'], supplier: '大华技术股份有限公司' },
      { code: '10101P0020012024040105003XXXXXX0003', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 5, unit: '台', unitPrice: 1800, equipCode: '0101P00200',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '海康威视数字技术股份有限公司' },
      { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 5, unit: '台', unitPrice: 1200, equipCode: '0101P00500',
    tags: ['品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
      { code: '10101P0080012024012010008XXXXXX0008', name: '应急照明灯 YD-100', category: '照明设备', spec: 'YD-100/LED', qty: 3, unit: '台', unitPrice: 680, equipCode: '0101P00800',
    tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司' },
    ]
  },
  {
    id: 'TP004', name: '特警支队模板',
    equips: [
      { code: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 10, unit: '件', unitPrice: 2800, equipCode: '0101P00300',
    tags: ['活动类/双11备货'], supplier: '华为技术有限公司' },
      { code: '10101P0040012024011510005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 10, unit: '顶', unitPrice: 1500, equipCode: '0101P00400',
    tags: ['品类特征/易碎品'], supplier: '中兴通讯股份有限公司' },
      { code: '10101P0120012024022105012XXXXXX0012', name: '防暴盾牌 FB-01', category: '防护装备', spec: 'FB-01/透明', qty: 5, unit: '面', unitPrice: 350, equipCode: '0101P01200',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
      { code: '10101P0150012024012505015XXXXXX0015', name: '破门工具组 PM-03', category: '破拆装备', spec: 'PM-03/液压', qty: 3, unit: '套', unitPrice: 12000, equipCode: '0101P01500',
    tags: ['品类特征/贵重仪器'], supplier: '烽火通信科技股份有限公司' },
    ]
  },
  {
    id: 'TP005', name: '网安支队模板',
    equips: [
      { code: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 5, unit: '台', unitPrice: 3200, equipCode: '0101P00100',
    tags: ['状态类/临期30天'], supplier: '华为技术有限公司' },
      { code: '10101P0140012024030505014XXXXXX0014', name: '单兵图传设备 TC-100', category: '通信装备', spec: 'TC-100/4G', qty: 3, unit: '台', unitPrice: 8800, equipCode: '0101P01400',
    tags: ['活动类/双11备货'], supplier: '海康威视数字技术股份有限公司' },
      { code: '10101P0310012024052005031XXXXXX0031', name: '便携式打印机 BJ-100', category: '办公设备', spec: 'BJ-100/热敏', qty: 3, unit: '台', unitPrice: 1500, equipCode: '0101P03100',
    tags: ['品类特征/易碎品'], supplier: '大华技术股份有限公司' },
      { code: '10101P0330012024081005033XXXXXX0033', name: '移动硬盘 YD-2T', category: '存储设备', spec: 'YD-2T/USB3.0', qty: 5, unit: '个', unitPrice: 480, equipCode: '0101P03300',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '华为技术有限公司' },
    ]
  },
]

const initialDistributeData: DistributeRecord[] = [
  {
    id: 'PF2024001', fromWarehouse: '省厅装备库A', distributeUnit: '刑警支队',
    equipList: [
      { code: '10101P0010012024031505001XXXXXX0001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 10, remainQty: 50, produceDate: '2024-01-15', validDate: '2029-01-14', maintainPeriod: '3个月', unit: '台', unitPrice: 3200, totalPrice: 32000, equipCode: '0101P00100',
    tags: ['品类特征/贵重仪器'], supplier: '华为技术有限公司', remark: '' },
    ],
    remark: '年度装备配发', status: 'draft', applicant: '张三', applyTime: '2024-03-15 09:30',
  },
  {
    id: 'PF2024002', fromWarehouse: '杭州市局装备库', distributeUnit: '治安支队',
    equipList: [
      { code: '10101P0020012024040105003XXXXXX0003', name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G', qty: 5, remainQty: 30, produceDate: '2024-02-20', validDate: '2029-02-19', maintainPeriod: '6个月', unit: '台', unitPrice: 1800, totalPrice: 9000, equipCode: '0101P00200',
    tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司', remark: '' },
      { code: '10101P0050012024031505003XXXXXX0003', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 10, remainQty: 100, produceDate: '2024-01-20', validDate: '2029-01-19', maintainPeriod: '3个月', unit: '台', unitPrice: 1200, totalPrice: 12000, equipCode: '0101P00500',
    tags: ['活动类/双11备货'], supplier: '烽火通信科技股份有限公司', remark: '' },
    ],
    remark: '季度配发', status: 'submitted', applicant: '李四', applyTime: '2024-03-14 14:20',
  },
  {
    id: 'PF2024003', fromWarehouse: '省厅装备库B', distributeUnit: '特警支队',
    equipList: [
      { code: '10101P0030012024021010004XXXXXX0004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 8, remainQty: 20, produceDate: '2023-11-10', validDate: '2033-11-09', maintainPeriod: '12个月', unit: '件', unitPrice: 2800, totalPrice: 22400, equipCode: '0101P00300',
    tags: ['品类特征/易碎品'], supplier: '华为技术有限公司', remark: '' },
      { code: '10101P0040012024011510005XXXXXX0005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 8, remainQty: 40, produceDate: '2023-12-05', validDate: '2033-12-04', maintainPeriod: '12个月', unit: '顶', unitPrice: 1500, totalPrice: 12000, equipCode: '0101P00400',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], supplier: '中兴通讯股份有限公司', remark: '' },
    ],
    remark: '应急配发', status: 'approval1', applicant: '王五', applyTime: '2024-03-13 11:00',
  },
  {
    id: 'PF2024004', fromWarehouse: '杭州市局装备库', distributeUnit: '交警支队',
    equipList: [
      { code: '10101P0070012024031005007XXXXXX0007', name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', qty: 30, remainQty: 200, produceDate: '2024-03-01', validDate: '2029-02-28', maintainPeriod: '3个月', unit: '支', unitPrice: 280, totalPrice: 8400, equipCode: '0101P00700', tags: ['品类特征/贵重仪器'], supplier: '大华技术股份有限公司', remark: '' },
    ],
    remark: '日常配发', status: 'pending_out', applicant: '赵六', applyTime: '2024-03-12 16:45', approver: '李主任', approveTime: '2024-03-13 09:00',
  },
  {
    id: 'PF2024005', fromWarehouse: '西湖分局装备库', distributeUnit: '网安支队',
    equipList: [
      { code: '10101P0140012024030505014XXXXXX0014', name: '单兵图传设备 TC-100', category: '通信装备', spec: 'TC-100/4G', qty: 3, remainQty: 10, produceDate: '2024-03-15', validDate: '2029-03-14', maintainPeriod: '3个月', unit: '台', unitPrice: 8800, totalPrice: 26400, equipCode: '0101P01400', tags: ['状态类/临期30天'], supplier: '海康威视数字技术股份有限公司', remark: '' },
    ],
    remark: '', status: 'outed', applicant: '钱七', applyTime: '2024-03-10 10:15', approver: '系统', approveTime: '2024-03-10 10:16',
  },
]

function renderOrgTree(
  nodes: OrgTreeNode[],
  expanded: Set<string>,
  setExpanded: React.Dispatch<React.SetStateAction<Set<string>>>,
  selected: string[],
  setSelected: React.Dispatch<React.SetStateAction<string[]>>,
  search: string,
  depth = 0
) {
  return (
    <>
      {nodes.map(node => {
        const isExpanded = expanded.has(node.id)
        const hasChildren = node.children && node.children.length > 0
        const isPerson = !hasChildren && node.badge
        const displayName = isPerson ? `${node.name}（${node.badge}）` : node.name

        if (search && !displayName.includes(search)) {
          if (hasChildren) {
            const filteredChildren = renderOrgTree(node.children!, expanded, setExpanded, selected, setSelected, search, depth + 1)
            if (!filteredChildren) return null
            return (
              <div key={node.id} style={{ marginLeft: depth * 16 }}>
                <button className="flex items-center gap-1 py-1 text-sm w-full text-left hover:bg-gray-50 rounded px-1" onClick={() => {
                  setExpanded(prev => { const next = new Set(prev); if (next.has(node.id)) next.delete(node.id); else next.add(node.id); return next })
                }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`} style={{ color: 'var(--text-disabled)' }}><polyline points="9 18 15 12 9 6"/></svg>
                  <span className="font-medium" style={{ color: 'var(--text-secondary)' }}>{node.name}</span>
                </button>
                {isExpanded && <div>{filteredChildren}</div>}
              </div>
            )
          }
          return null
        }

        return (
          <div key={node.id} style={{ marginLeft: depth * 16 }}>
            <div className="flex items-center gap-2 py-1 hover:bg-gray-50 rounded px-1">
              {hasChildren ? (
                <>
                  <button onClick={() => {
                    setExpanded(prev => { const next = new Set(prev); if (next.has(node.id)) next.delete(node.id); else next.add(node.id); return next })
                  }}>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`} style={{ color: 'var(--text-disabled)' }}><polyline points="9 18 15 12 9 6"/></svg>
                  </button>
                  <span className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>{node.name}</span>
                </>
              ) : (
                <>
                  <span className="w-3" />
                  <input
                    type="checkbox"
                    className="accent-blue-500"
                    checked={selected.includes(displayName)}
                    onChange={() => {
                      setSelected(prev => prev.includes(displayName) ? prev.filter(x => x !== displayName) : [...prev, displayName])
                    }}
                  />
                  <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs text-white flex-shrink-0" style={{ background: '#1890ff' }}>{node.name[0]}</div>
                  <span className="text-sm">{node.name} <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{node.badge}</span></span>
                </>
              )}
            </div>
            {hasChildren && isExpanded && (
              <div>{renderOrgTree(node.children!, expanded, setExpanded, selected, setSelected, search, depth + 1)}</div>
            )}
          </div>
        )
      })}
    </>
  )
}

function TeamDistribute() {
  const [records, setRecords] = useState<DistributeRecord[]>(initialDistributeData)
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterWarehouse, setFilterWarehouse] = useState('all')
  const [searchId, setSearchId] = useState('')

  // Form modal
  const [formOpen, setFormOpen] = useState(false)
  const [editRecord, setEditRecord] = useState<DistributeRecord | null>(null)
  const [formWarehouse, setFormWarehouse] = useState('')
  const [formPersons, setFormPersons] = useState<string[]>([])
  const [formRemark, setFormRemark] = useState('')
  const [selectedEquips, setSelectedEquips] = useState<DistributeEquip[]>([])

  // Template modal
  const [templateOpen, setTemplateOpen] = useState(false)
  const [templates, setTemplates] = useState<EquipTemplate[]>(initialTemplates)
  const [templateEditOpen, setTemplateEditOpen] = useState(false)
  const [editTemplate, setEditTemplate] = useState<EquipTemplate | null>(null)
  const [templateName, setTemplateName] = useState('')
  const [templateEquips, setTemplateEquips] = useState<TemplateEquip[]>([])

  // Person select modal
  const [personOpen, setPersonOpen] = useState(false)
  const [personSearchName, setPersonSearchName] = useState('')
  const [expandedOrgs, setExpandedOrgs] = useState<Set<string>>(new Set(['ORG001', 'ORG002']))

  // Detail modal
  const [detailOpen, setDetailOpen] = useState(false)
  const [detailRecord, setDetailRecord] = useState<DistributeRecord | null>(null)

  // Approve modal
  const [approveOpen, setApproveOpen] = useState(false)
  const [approveRemark, setApproveRemark] = useState('')
  const [approveRecord, setApproveRecord] = useState<DistributeRecord | null>(null)

  // Reject modal
  const [rejectOpen, setRejectOpen] = useState(false)
  const [rejectReason, setRejectReason] = useState('')
  const [rejectRecord, setRejectRecord] = useState<DistributeRecord | null>(null)

  // Equipment select modal
  const [equipOpen, setEquipOpen] = useState(false)
  const [equipForTemplate, setEquipForTemplate] = useState(false)
  const [equipSearchName, setEquipSearchName] = useState('')
  const [equipSearchCategory, setEquipSearchCategory] = useState('')

  const filtered = records.filter(r => {
    if (filterStatus !== 'all' && r.status !== filterStatus) return false
    if (filterWarehouse !== 'all' && r.fromWarehouse !== filterWarehouse) return false
    if (searchId && !r.id.toLowerCase().includes(searchId.toLowerCase())) return false
    return true
  })

  const selectedStockCodes = new Set(selectedEquips.map(e => e.code))

  const toggleOrg = (id: string) => {
    setExpandedOrgs(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const resetForm = () => {
    setFormWarehouse('')
    setFormPersons([])
    setFormRemark('')
    setSelectedEquips([])
    setEditRecord(null)
  }

  const openNew = () => { resetForm(); setFormOpen(true) }
  const openEdit = (r: DistributeRecord) => {
    setEditRecord(r)
    setFormWarehouse(r.fromWarehouse)
    setFormPersons(r.distributeUnit.split('、').filter(Boolean))
    setFormRemark(r.remark)
    setSelectedEquips(r.equipList.map(e => ({ ...e })))
    setFormOpen(true)
  }

  const handleSubmit = (status: DistributeStatus) => {
    if (!formWarehouse) { alert('请选择调出仓库'); return }
    if (formPersons.length === 0) { alert('请选择配发人员'); return }
    if (selectedEquips.length === 0) { alert('请至少选择一件装备'); return }
    const now = new Date().toLocaleString('zh-CN', { hour12: false })
    if (editRecord) {
      setRecords(prev => prev.map(r => r.id === editRecord.id ? { ...r, fromWarehouse: formWarehouse, distributeUnit: formPersons.join('、'), remark: formRemark, equipList: selectedEquips.map(e => ({ ...e })), status } : r))
      alert(`配发单 ${editRecord.id} 已${status === 'draft' ? '保存' : '提交'}`)
    } else {
      const newId = `PF2024${String(records.length + 1).padStart(3, '0')}`
      setRecords(prev => [{ id: newId, fromWarehouse: formWarehouse, distributeUnit: formPersons.join('、'), equipList: selectedEquips.map(e => ({ ...e })), remark: formRemark, status, applicant: '当前用户', applyTime: now }, ...prev])
      alert(`配发单 ${newId} 已${status === 'draft' ? '保存为草稿' : '提交'}`)
    }
    setFormOpen(false)
    resetForm()
  }

  const handleApproveClick = (r: DistributeRecord) => { setApproveRecord(r); setApproveRemark(''); setApproveOpen(true) }
  const confirmApprove = () => {
    if (!approveRecord) return
    setRecords(prev => prev.map(r => r.id === approveRecord.id ? { ...r, status: 'pending_out', approver: '当前用户', approveTime: new Date().toLocaleString('zh-CN', { hour12: false }) } : r))
    setApproveOpen(false); setApproveRecord(null); setApproveRemark('')
    alert(`配发单 ${approveRecord.id} 已审批通过`)
  }

  const handleRejectClick = (r: DistributeRecord) => { setRejectRecord(r); setRejectReason(''); setRejectOpen(true) }
  const confirmReject = () => {
    if (!rejectReason.trim()) { alert('请输入驳回原因'); return }
    if (!rejectRecord) return
    setRecords(prev => prev.filter(r => r.id !== rejectRecord.id))
    setRejectOpen(false); setRejectRecord(null); setRejectReason('')
    alert(`配发单 ${rejectRecord.id} 已驳回删除`)
  }

  const addEquip = (m: typeof stockMaterials[0]) => {
    if (equipForTemplate) {
      setTemplateEquips(prev => {
        const exists = prev.find(e => e.code === m.code)
        if (exists) return prev.map(e => e.code === m.code ? { ...e, qty: e.qty + 1 } : e)
        return [...prev, { code: m.code, name: m.name, category: m.category, spec: m.spec, qty: 1, unit: m.unit, unitPrice: m.unitPrice, equipCode: m.equipCode, supplier: m.supplier }]
      })
    } else {
      if (selectedStockCodes.has(m.code)) {
        setSelectedEquips(prev => prev.map(e => e.code === m.code ? { ...e, qty: e.qty + 1, totalPrice: (e.qty + 1) * e.unitPrice } : e))
      } else {
        setSelectedEquips(prev => [...prev, { code: m.code, name: m.name, category: m.category, spec: m.spec, qty: 1, remainQty: m.remainQty, produceDate: m.produceDate, validDate: m.validDate, maintainPeriod: m.maintainPeriod, unit: m.unit, unitPrice: m.unitPrice, totalPrice: m.unitPrice, equipCode: m.equipCode, supplier: m.supplier, remark: '' }])
      }
    }
  }

  const removeEquip = (code: string) => { setSelectedEquips(prev => prev.filter(e => e.code !== code)) }
  const updateQty = (code: string, q: number) => { setSelectedEquips(prev => prev.map(e => e.code === code ? { ...e, qty: Math.max(1, q), totalPrice: Math.max(1, q) * e.unitPrice } : e)) }

  const filteredStock = stockMaterials.filter(m => {
    if (equipSearchName && !m.name.includes(equipSearchName)) return false
    if (equipSearchCategory && !m.category.includes(equipSearchCategory)) return false
    return true
  })

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button className="btn-primary flex items-center gap-1" onClick={openNew}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>发起配发
        </button>
        <button className="btn-default flex items-center gap-1 text-sm" onClick={() => setTemplateOpen(true)}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
          预制装备模板
        </button>
      </div>

      {/* Filters */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>配发单号</label><input className="form-input w-36" placeholder="请输入..." value={searchId} onChange={e => setSearchId(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库</label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={filterWarehouse} onChange={setFilterWarehouse} mode="name" showAll allValue="all" className="w-32" /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}><option value="all">全部</option><option value="draft">草稿</option><option value="submitted">已提交</option><option value="approval1">审批1</option><option value="pending_out">待出库</option><option value="outed">已出库</option></select></div>
          <div className="flex gap-2 ml-auto"><button className="btn-default" onClick={() => { setFilterStatus('all'); setFilterWarehouse('all'); setSearchId('') }}>重置</button><button className="btn-primary">查询</button></div>
        </div>
      </div>

      {/* Table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead><tr><th className="w-10"><input type="checkbox" /></th><th>配发单号</th><th>调出仓库</th><th>配发单位</th><th>装备清单</th><th>申请人</th><th>申请时间</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={9} className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
            {filtered.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox" /></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td>{r.fromWarehouse}</td>
                <td>{r.distributeUnit}</td>
                <td><div className="text-xs max-w-[200px]">{r.equipList.map((e, i) => <span key={i} className="inline-block mr-2">{e.name} x{e.qty}</span>)}</div></td>
                <td>{r.applicant}</td>
                <td className="text-xs">{r.applyTime}</td>
                <td><span className={`tag ${distributeStatusMap[r.status].tag} text-xs`}>{distributeStatusMap[r.status].label}</span></td>
                <td><div className="flex items-center gap-2 flex-wrap">
                  <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDetailRecord(r); setDetailOpen(true) }}>查看</button>
                  {r.status === 'approval1' && <><button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => handleApproveClick(r)}>通过</button><button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleRejectClick(r)}>驳回</button></>}
                  {(r.status === 'draft') && <><button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openEdit(r)}>编辑</button><button className="text-xs hover:underline" style={{ color: '#999' }} onClick={() => { if (confirm(`删除配发单 ${r.id}？`)) setRecords(prev => prev.filter(x => x.id !== r.id)) }}>删除</button></>}
                </div></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== Form Modal ===== */}
      {formOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setFormOpen(false); resetForm() }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{editRecord ? `编辑配发单 - ${editRecord.id}` : '发起配发申请'}</h3>
              <button onClick={() => { setFormOpen(false); resetForm() }} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-3 gap-4">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>配发单字号</label><input className="form-input font-mono" value={editRecord ? editRecord.id : '系统自动生成'} readOnly /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>调出仓库 <span className="text-red-400">*</span></label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={formWarehouse} onChange={setFormWarehouse} mode="name" placeholder="请选择" /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>配发人员 <span className="text-red-400">*</span></label>
                  <div className="relative">
                    <div className="form-input w-full cursor-pointer min-h-[34px] flex flex-wrap gap-1 items-center" onClick={() => { setPersonSearchName(''); setPersonOpen(true) }}>
                      {formPersons.length === 0 && <span className="text-sm" style={{ color: 'var(--text-disabled)' }}>点击选择配发人员...</span>}
                      {formPersons.map(p => (
                        <span key={p} className="text-xs px-2 py-0.5 rounded-full flex items-center gap-1" style={{ background: '#e6f7ff', color: '#1890ff' }}>
                          {p} <button onClick={e => { e.stopPropagation(); setFormPersons(prev => prev.filter(x => x !== p)) }}>×</button>
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label><input className="form-input w-full" placeholder="请输入备注..." value={formRemark} onChange={e => setFormRemark(e.target.value)} /></div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-xs font-medium">物资明细 <span className="text-red-400">*</span></label>
                  <div className="flex items-center gap-2">
                    <button className="btn-default text-xs flex items-center gap-1 px-3 py-1.5" onClick={() => setTemplateOpen(true)}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z"/></svg>
                      选择模板
                    </button>
                    <button className="btn-primary text-xs flex items-center gap-1 px-3 py-1.5" onClick={() => { setEquipForTemplate(false); setEquipSearchName(''); setEquipSearchCategory(''); setEquipOpen(true) }}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      添加物资
                    </button>
                  </div>
                </div>
                <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <table className="w-full text-xs">
                    <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="p-2 text-left">物资名称</th><th className="p-2 text-left">物资类别</th><th className="p-2 text-left">规格型号</th><th className="p-2 text-center w-14">数量</th><th className="p-2 text-center">生产日期</th><th className="p-2 text-center">有效期</th><th className="p-2 text-center">保养期</th><th className="p-2 text-center w-10">单位</th><th className="p-2 text-right w-16">单价</th><th className="p-2 text-right w-16">总价</th><th className="p-2 text-left w-24">装备编码</th><th className="p-2 text-left">供应商</th><th className="p-2 w-12"></th></tr></thead>
                    <tbody>
                      {selectedEquips.length === 0 && <tr><td colSpan={13} className="p-6 text-center text-xs" style={{ color: 'var(--text-disabled)' }}>请点击「添加物资」按钮添加装备</td></tr>}
                      {selectedEquips.map(e => (
                        <tr key={e.code} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="p-2 font-medium">{e.name}</td><td className="p-2">{e.category}</td><td className="p-2">{e.spec}</td>
                          <td className="p-2 text-center"><input type="number" min={1} className="form-input w-14 text-xs text-center py-0.5" value={e.qty} onChange={ev => updateQty(e.code, Number(ev.target.value))} /></td>
                          <td className="p-2 text-center">{e.produceDate}</td><td className="p-2 text-center">{e.validDate}</td><td className="p-2 text-center">{e.maintainPeriod}</td>
                          <td className="p-2 text-center">{e.unit}</td><td className="p-2 text-right font-mono">{e.unitPrice.toLocaleString()}</td><td className="p-2 text-right font-mono font-medium" style={{ color: '#1890ff' }}>{e.totalPrice.toLocaleString()}</td>
                          <td className="p-2 font-mono">{e.equipCode}</td><td className="p-2">{e.supplier}</td>
                          <td className="p-2 text-center"><button className="text-xs px-1.5 rounded hover:bg-red-50" style={{ color: '#ff4d4f' }} onClick={() => removeEquip(e.code)}>删除</button></td>
                        </tr>
                      ))}
                    </tbody>
                    {selectedEquips.length > 0 && <tfoot><tr style={{ background: 'var(--table-header-bg)' }}><td colSpan={9} className="p-2 text-right text-xs font-semibold">合计</td><td className="p-2 text-right text-xs font-mono font-bold" style={{ color: '#1890ff' }}>¥{selectedEquips.reduce((s, e) => s + e.totalPrice, 0).toLocaleString()}</td><td colSpan={3}></td></tr></tfoot>}
                  </table>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => { setFormOpen(false); resetForm() }}>取消</button>
              <button className="btn-default" onClick={() => handleSubmit('draft')}>保存草稿</button>
              <button className="btn-primary" onClick={() => handleSubmit('submitted')}>提交申请</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Equipment Select Modal ===== */}
      {equipOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setEquipOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200" style={{ width: '75vw', height: '90vh' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}><h3 className="text-lg font-semibold">库存装备信息</h3><button onClick={() => setEquipOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
            <div className="px-6 py-3 border-b flex items-center gap-3" style={{ borderColor: 'var(--border-color)' }}>
              <input className="form-input text-sm w-40" placeholder="物资名称..." value={equipSearchName} onChange={e => setEquipSearchName(e.target.value)} />
              <select className="form-input text-sm w-32" value={equipSearchCategory} onChange={e => setEquipSearchCategory(e.target.value)}><option value="">全部类别</option><option>通信装备</option><option>执法设备</option><option>防护装备</option><option>照明设备</option><option>应急救援</option><option>侦察设备</option><option>破拆装备</option><option>交通工具</option></select>
              <button className="btn-primary text-xs">查询</button>
            </div>
            <div className="flex flex-1 overflow-hidden">
              <div className="w-[60%] border-r overflow-y-auto p-4" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs">
                  <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="p-2 text-center w-8"><input type="checkbox" /></th><th className="p-2 text-left">物资名称</th><th className="p-2 text-left">物资类别</th><th className="p-2 text-left">规格型号</th><th className="p-2 text-center">生产日期</th><th className="p-2 text-center">有效期</th><th className="p-2 text-right">剩余</th><th className="p-2 text-center">单位</th><th className="p-2 text-right">单价</th><th className="p-2 text-left">装备编码</th><th className="p-2 text-left">供应商</th></tr></thead>
                  <tbody>
                    {filteredStock.length === 0 && <tr><td colSpan={11} className="p-6 text-center" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>}
                    {filteredStock.map(m => (
                      <tr key={m.code} className="border-t hover:bg-blue-50/50 transition-colors" style={{ borderColor: 'var(--border-color)' }}>
                        <td className="p-2 text-center"><input type="checkbox" checked={selectedStockCodes.has(m.code)} onChange={() => addEquip(m)} /></td>
                        <td className="p-2 font-medium">{m.name}</td><td className="p-2">{m.category}</td><td className="p-2">{m.spec}</td>
                        <td className="p-2 text-center">{m.produceDate}</td><td className="p-2 text-center">{m.validDate}</td>
                        <td className="p-2 text-right font-mono" style={{ color: '#52c41a' }}>{m.remainQty}</td><td className="p-2 text-center">{m.unit}</td>
                        <td className="p-2 text-right font-mono">{m.unitPrice.toLocaleString()}</td><td className="p-2 font-mono">{m.equipCode}</td><td className="p-2">{m.supplier}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="w-[40%] overflow-y-auto p-4" style={{ background: 'var(--content-bg)' }}>
                <h4 className="text-sm font-semibold mb-3">已选择装备 ({selectedEquips.length})</h4>
                {selectedEquips.length === 0 && <div className="text-center py-12 text-sm" style={{ color: 'var(--text-disabled)' }}>请点击左侧装备进行添加</div>}
                <div className="space-y-2">
                  {selectedEquips.map(e => (
                    <div key={e.code} className="p-3 rounded-lg border bg-white" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between mb-2"><span className="text-sm font-medium">{e.name}</span><button className="text-xs px-1.5 rounded hover:bg-red-50" style={{ color: '#ff4d4f' }} onClick={() => removeEquip(e.code)}>删除</button></div>
                      <div className="grid grid-cols-2 gap-1 text-xs mb-2" style={{ color: 'var(--text-secondary)' }}><span>类别: {e.category}</span><span>规格: {e.spec}</span><span>编码: {e.equipCode}</span><span>余量: {e.remainQty}</span></div>
                      <div className="flex items-center gap-2"><span className="text-xs">数量:</span><input type="number" min={1} max={e.remainQty} className="form-input w-16 text-xs text-center py-0.5" value={e.qty} onChange={ev => updateQty(e.code, Number(ev.target.value))} /><span className="text-xs" style={{ color: 'var(--text-disabled)' }}>单价: ¥{e.unitPrice.toLocaleString()}</span></div>
                    </div>
                  ))}
                </div>
                {selectedEquips.length > 0 && <button className="btn-primary w-full mt-4" onClick={() => setEquipOpen(false)}>确认添加</button>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Person Select Modal (Tree) ===== */}
      {personOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setPersonOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200" style={{ width: '500px', height: '70vh' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">选择配发人员</h3>
              <div className="flex items-center gap-2">
                <button className="text-xs px-3 py-1.5 rounded border" style={{ borderColor: '#d9d9d9' }} onClick={() => setFormPersons([])}>清空</button>
                <button onClick={() => setPersonOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
              </div>
            </div>
            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <input className="form-input text-sm w-full" placeholder="搜索姓名..." value={personSearchName} onChange={e => setPersonSearchName(e.target.value)} />
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {renderOrgTree(orgTreeData, expandedOrgs, setExpandedOrgs, formPersons, setFormPersons, personSearchName)}
            </div>
            <div className="sticky bottom-0 px-6 py-3 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex items-center justify-between">
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>已选择 {formPersons.length} 人</span>
                <button className="btn-primary text-xs" onClick={() => setPersonOpen(false)}>确认</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Detail Modal ===== */}
      {detailOpen && detailRecord && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-2/3 h-full flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}><h3 className="text-lg font-semibold">配发详情 - {detailRecord.id}</h3><button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              <div className="grid grid-cols-3 gap-3">
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}><p className="text-xs" style={{ color: 'var(--text-secondary)' }}>调出仓库</p><p className="text-sm font-bold mt-1">{detailRecord.fromWarehouse}</p></div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}><p className="text-xs" style={{ color: 'var(--text-secondary)' }}>配发人员</p><p className="text-sm font-bold mt-1">{detailRecord.distributeUnit}</p></div>
                <div className="p-3 rounded-lg border text-center" style={{ borderColor: 'var(--border-color)' }}><p className="text-xs" style={{ color: 'var(--text-secondary)' }}>状态</p><p className="text-sm font-bold mt-1">{distributeStatusMap[detailRecord.status].label}</p></div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>基本信息</p>
                  <div className="space-y-1"><p><span style={{ color: 'var(--text-secondary)' }}>申请人：</span>{detailRecord.applicant}</p><p><span style={{ color: 'var(--text-secondary)' }}>申请时间：</span>{detailRecord.applyTime}</p>{detailRecord.approver && <p><span style={{ color: 'var(--text-secondary)' }}>审批人：</span>{detailRecord.approver}</p>}{detailRecord.approveTime && <p><span style={{ color: 'var(--text-secondary)' }}>审批时间：</span>{detailRecord.approveTime}</p>}</div>
                </div>
                <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}><p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>备注</p><p className="text-sm">{detailRecord.remark || '-'}</p></div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-2">装备清单</h4>
                <table className="w-full text-xs border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="p-2 text-left">物资名称</th><th className="p-2 text-left">物资类别</th><th className="p-2 text-left">规格型号</th><th className="p-2 text-center">数量</th><th className="p-2 text-center">单位</th><th className="p-2 text-right">单价</th><th className="p-2 text-right">总价</th><th className="p-2 text-left">装备编码</th><th className="p-2 text-left">供应商</th></tr></thead>
                  <tbody>{detailRecord.equipList.map((e, i) => <tr key={i} className="border-t" style={{ borderColor: 'var(--border-color)' }}><td className="p-2 font-medium">{e.name}</td><td className="p-2">{e.category}</td><td className="p-2">{e.spec}</td><td className="p-2 text-center">{e.qty}</td><td className="p-2 text-center">{e.unit}</td><td className="p-2 text-right font-mono">{e.unitPrice.toLocaleString()}</td><td className="p-2 text-right font-mono font-medium" style={{ color: '#1890ff' }}>{e.totalPrice.toLocaleString()}</td><td className="p-2 font-mono">{e.equipCode}</td><td className="p-2">{e.supplier}</td></tr>)}</tbody>
                  <tfoot><tr style={{ background: 'var(--table-header-bg)' }}><td colSpan={6} className="p-2 text-right text-xs font-semibold">合计</td><td className="p-2 text-right text-xs font-mono font-bold" style={{ color: '#1890ff' }}>¥{detailRecord.equipList.reduce((s, e) => s + e.totalPrice, 0).toLocaleString()}</td><td colSpan={2}></td></tr></tfoot>
                </table>
              </div>
              <div className="flex items-center justify-end gap-3 pt-2">
                <button className="btn-default" onClick={() => setDetailOpen(false)}>关闭</button>
                {detailRecord.status === 'approval1' && <><button className="btn-primary" onClick={() => { handleApproveClick(detailRecord); setDetailOpen(false) }}>通过</button><button className="btn-danger" onClick={() => { handleRejectClick(detailRecord); setDetailOpen(false) }}>驳回</button></>}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===== Approve Modal ===== */}
      {approveOpen && approveRecord && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setApproveOpen(false); setApproveRecord(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5"><div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg></div><h3 className="text-base font-semibold">审批通过</h3></div>
            <div className="mb-5"><p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>配发单号：<span className="font-mono font-medium">{approveRecord.id}</span><br/>调出仓库：<span>{approveRecord.fromWarehouse}</span> → 配发单位：<span>{approveRecord.distributeUnit}</span></p><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批意见（可选）</label><textarea className="form-input w-full text-sm" rows={3} placeholder="请输入审批意见..." value={approveRemark} onChange={e => setApproveRemark(e.target.value)} /></div>
            <div className="flex items-center justify-end gap-3"><button className="btn-default" onClick={() => { setApproveOpen(false); setApproveRecord(null) }}>取消</button><button className="btn-primary" onClick={confirmApprove}>确认通过</button></div>
          </div>
        </div>
      )}

      {/* ===== Reject Modal ===== */}
      {rejectOpen && rejectRecord && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setRejectOpen(false); setRejectRecord(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5"><div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></div><h3 className="text-base font-semibold">驳回配发申请</h3></div>
            <div className="mb-5"><p className="text-sm mb-3" style={{ color: 'var(--text-secondary)' }}>配发单号：<span className="font-mono font-medium">{rejectRecord.id}</span><br/>调出仓库：<span>{rejectRecord.fromWarehouse}</span> → 配发人员：<span>{rejectRecord.distributeUnit}</span></p><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>驳回原因 <span className="text-red-400">*</span></label><textarea className="form-input w-full text-sm" rows={3} placeholder="请输入驳回原因..." value={rejectReason} onChange={e => setRejectReason(e.target.value)} /></div>
            <div className="flex items-center justify-end gap-3"><button className="btn-default" onClick={() => { setRejectOpen(false); setRejectRecord(null) }}>取消</button><button className="btn-danger" onClick={confirmReject}>确认驳回</button></div>
          </div>
        </div>
      )}

      {/* ===== Template Manage Modal ===== */}
      {templateOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setTemplateOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200" style={{ width: '700px', height: '80vh' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">管理警种装备模板</h3>
              <div className="flex items-center gap-2">
                <button className="btn-primary text-xs flex items-center gap-1" onClick={() => { setEditTemplate(null); setTemplateName(''); setTemplateEquips([]); setTemplateEditOpen(true) }}>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增模板
                </button>
                <button onClick={() => setTemplateOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6">
              {templates.length === 0 && <div className="text-center py-12 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无模板，请点击「新增模板」创建</div>}
              <div className="space-y-4">
                {templates.map(t => {
                  const iconMap: Record<string, { emoji: string; color: string }> = {
                    '刑警支队模板': { emoji: '🔵', color: '#1890ff' },
                    '交警模板': { emoji: '🚦', color: '#faad14' },
                    '特警支队模板': { emoji: '🛡', color: '#722ed1' },
                    '网安支队模板': { emoji: '💻', color: '#13c2c2' },
                    '治安支队模板': { emoji: '📻', color: '#eb2f96' },
                  }
                  const icon = iconMap[t.name] || { emoji: '📦', color: '#8c8c8c' }
                  return (
                    <div key={t.id} className="p-4 rounded-lg border bg-white" style={{ borderColor: 'var(--border-color)' }}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{icon.emoji}</span>
                          <h4 className="font-semibold text-sm">{t.name.replace('模板', '')}</h4>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#e6f7ff', color: '#1890ff' }}>{t.equips.length}件</span>
                          <button className="p-1 rounded hover:bg-blue-50" style={{ color: 'var(--primary-blue)' }} onClick={() => { setEditTemplate(t); setTemplateName(t.name); setTemplateEquips(t.equips.map(e => ({ ...e }))); setTemplateEditOpen(true) }} title="编辑">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                          </button>
                          <button className="p-1 rounded hover:bg-red-50" style={{ color: '#ff4d4f' }} onClick={() => { if (confirm(`确定删除模板「${t.name}」？`)) setTemplates(prev => prev.filter(x => x.id !== t.id)) }} title="删除">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                          </button>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-x-4 gap-y-1 mb-3">
                        {t.equips.map((e, i) => (
                          <span key={i} className="text-xs" style={{ color: 'var(--text-secondary)' }}>{e.name}</span>
                        ))}
                      </div>
                      <button className="btn-primary text-xs w-full" onClick={() => {
                        const newEquips: DistributeEquip[] = t.equips.map(e => ({
                          code: e.code, name: e.name, category: e.category, spec: e.spec,
                          qty: e.qty, remainQty: 999, produceDate: '', validDate: '', maintainPeriod: '',
                          unit: e.unit, unitPrice: e.unitPrice, totalPrice: e.qty * e.unitPrice,
                          equipCode: e.equipCode, supplier: e.supplier, remark: ''
                        }))
                        setSelectedEquips(newEquips)
                        setTemplateOpen(false)
                        alert(`已应用模板「${t.name}」，共 ${t.equips.length} 件装备`)
                      }}>应用此模板</button>
                    </div>
                  )
                })}
              </div>
            </div>
            <div className="sticky bottom-0 px-6 py-3 border-t bg-white flex justify-end" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setTemplateOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Template Edit Modal ===== */}
      {templateEditOpen && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/60" onClick={() => setTemplateEditOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl flex flex-col animate-in fade-in zoom-in duration-200" style={{ width: '600px', height: '80vh' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{editTemplate ? `编辑模板 - ${editTemplate.name}` : '新增模板'}</h3>
              <button onClick={() => setTemplateEditOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>模板名称 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入模板名称..." value={templateName} onChange={e => setTemplateName(e.target.value)} /></div>
              <div>
                <div className="flex items-center justify-between mb-2"><label className="text-xs font-medium">装备列表</label><button className="btn-primary text-xs flex items-center gap-1 px-2 py-1" onClick={() => { setEquipForTemplate(true); setEquipSearchName(''); setEquipSearchCategory(''); setEquipOpen(true) }}>+ 添加装备</button></div>
                <div className="border rounded-lg overflow-hidden" style={{ borderColor: 'var(--border-color)' }}>
                  <table className="w-full text-xs">
                    <thead><tr style={{ background: 'var(--table-header-bg)' }}><th className="p-2 text-left">物资名称</th><th className="p-2 text-left">规格型号</th><th className="p-2 text-center w-14">数量</th><th className="p-2 text-center w-10">单位</th><th className="p-2 w-12"></th></tr></thead>
                    <tbody>
                      {templateEquips.length === 0 && <tr><td colSpan={5} className="p-4 text-center text-xs" style={{ color: 'var(--text-disabled)' }}>请添加装备</td></tr>}
                      {templateEquips.map((e, i) => (
                        <tr key={i} className="border-t" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="p-2 font-medium">{e.name}</td><td className="p-2">{e.spec}</td>
                          <td className="p-2 text-center"><input type="number" min={1} className="form-input w-14 text-xs text-center py-0.5" value={e.qty} onChange={ev => setTemplateEquips(prev => prev.map((item, idx) => idx === i ? { ...item, qty: Math.max(1, Number(ev.target.value)) } : item))} /></td>
                          <td className="p-2 text-center">{e.unit}</td>
                          <td className="p-2 text-center"><button className="text-xs px-1.5 rounded hover:bg-red-50" style={{ color: '#ff4d4f' }} onClick={() => setTemplateEquips(prev => prev.filter((_, idx) => idx !== i))}>删除</button></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setTemplateEditOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => {
                if (!templateName.trim()) { alert('请输入模板名称'); return }
                if (templateEquips.length === 0) { alert('请至少添加一件装备'); return }
                if (editTemplate) {
                  setTemplates(prev => prev.map(t => t.id === editTemplate.id ? { ...t, name: templateName.trim(), equips: templateEquips.map(e => ({ ...e })) } : t))
                  alert(`模板「${templateName.trim()}」已更新`)
                } else {
                  const newId = `TP${String(templates.length + 1).padStart(3, '0')}`
                  setTemplates(prev => [...prev, { id: newId, name: templateName.trim(), equips: templateEquips.map(e => ({ ...e })) }])
                  alert(`模板「${templateName.trim()}」已创建`)
                }
                setTemplateEditOpen(false)
              }}>{editTemplate ? '保存修改' : '创建模板'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ================================================================
   Personal Allocation Page
   ================================================================ */

function PersonalAllocPage({ onNavigate }: { onNavigate?: Props['onNavigate'] }) {
  const [persons] = useState<Person[]>(initialPersons)
  const [selectedPerson, setSelectedPerson] = useState<Person | null>(null)
  const [showDetail, setShowDetail] = useState(false)

  const stats = {
    totalPersons: persons.length,
    totalEquips: persons.reduce((s, p) => s + p.equips.filter(e => e.status === 'allocated').length, 0),
    cancelledEquips: persons.reduce((s, p) => s + p.equips.filter(e => e.status === 'cancelled').length, 0),
  }

  return (
    <div className="space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>个人装备分配</span>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="content-card p-4 text-center">
          <p className="text-2xl font-bold" style={{ color: '#1890ff' }}>{stats.totalPersons}</p>
          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>人员总数</p>
        </div>
        <div className="content-card p-4 text-center">
          <p className="text-2xl font-bold" style={{ color: '#52c41a' }}>{stats.totalEquips}</p>
          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>已配发装备</p>
        </div>
        <div className="content-card p-4 text-center">
          <p className="text-2xl font-bold" style={{ color: '#ff4d4f' }}>{stats.cancelledEquips}</p>
          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>已撤销装备</p>
        </div>
      </div>

      {/* Person list */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>编号</th>
              <th>姓名</th>
              <th>警号</th>
              <th>部门</th>
              <th>已配发装备</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {persons.map(person => (
              <tr key={person.id}>
                <td className="font-mono text-xs">{person.id}</td>
                <td className="font-medium">{person.name}</td>
                <td className="font-mono text-xs">{person.badge}</td>
                <td><span className="tag tag-blue text-xs">{person.dept}</span></td>
                <td>
                  <div className="flex flex-wrap gap-1">
                    {person.equips.filter(e => e.status === 'allocated').map(e => (
                      <span key={e.allocId} className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#e6f7ff', color: '#1890ff' }}>{e.name}</span>
                    ))}
                    {person.equips.filter(e => e.status === 'allocated').length === 0 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>-</span>}
                  </div>
                </td>
                <td>
                  <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedPerson(person); setShowDetail(true) }}>查看详情</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Detail Modal */}
      {showDetail && selectedPerson && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowDetail(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[600px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">个人装备 - {selectedPerson.name}</h3>
              <button onClick={() => setShowDetail(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-lg font-medium text-white" style={{ background: '#1890ff' }}>
                  {selectedPerson.name[0]}
                </div>
                <div>
                  <p className="font-semibold">{selectedPerson.name}</p>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPerson.dept} · {selectedPerson.badge}</p>
                </div>
              </div>
              <h4 className="text-sm font-semibold mb-3">装备清单</h4>
              <div className="space-y-2">
                {selectedPerson.equips.map(e => (
                  <div key={e.allocId} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                    <div>
                      <p className="text-sm font-medium">{e.name}</p>
                      <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{e.spec} · 配发时间：{e.allocTime}</p>
                    </div>
                    <span className={`tag text-xs ${e.status === 'allocated' ? 'tag-green' : 'tag-red'}`}>{e.status === 'allocated' ? '已配发' : '已撤销'}</span>
                  </div>
                ))}
                {selectedPerson.equips.length === 0 && (
                  <p className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无装备配发记录</p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
