import { useState } from 'react'
import EquipSelectorModal from '../components/EquipSelectorModal'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

// ===== 安全库存主数据 =====
interface SafetyStockItem {
  id: string
  name: string
  category: string
  currentStock: number
  threshold: number
}

const safetyData: SafetyStockItem[] = [
  { id: 'P001', name: '手持终端 XT-2000', category: '通信装备', currentStock: 45, threshold: 30 },
  { id: 'P002', name: '执法记录仪 DSJ-A7', category: '通用装备', currentStock: 12, threshold: 20 },
  { id: 'P003', name: '防弹背心 FDY-3R', category: '防护装备', currentStock: 30, threshold: 25 },
  { id: 'P004', name: '战术头盔 MICH-2000', category: '防护装备', currentStock: 25, threshold: 30 },
  { id: 'P005', name: '对讲机 PD780G', category: '通信装备', currentStock: 38, threshold: 30 },
  { id: 'P006', name: '应急照明灯 YD-100', category: '应急装备', currentStock: 60, threshold: 40 },
  { id: 'P007', name: '防弹盾牌 FDP-3S', category: '防护装备', currentStock: 18, threshold: 20 },
  { id: 'P008', name: '催泪喷射器 CL-200', category: '执法装备', currentStock: 100, threshold: 50 },
  { id: 'P009', name: '手铐 SK-01', category: '执法装备', currentStock: 200, threshold: 100 },
  { id: 'P010', name: '警棍 JB-100', category: '执法装备', currentStock: 150, threshold: 100 },
  { id: 'P011', name: '强光手电 QG-500', category: '个人装备', currentStock: 8, threshold: 15 },
  { id: 'P012', name: '防刺手套 FC-02', category: '个人装备', currentStock: 55, threshold: 40 },
]

const categoryOptions = ['通用装备', '通信装备', '应急装备', '防护装备', '急救装备', '个人装备', '执法装备']

// ===== 模板数据结构 =====
interface TemplateNode {
  id: string
  label: string
  expanded?: boolean
  children?: TemplateNode[]
  items?: TemplateItem[]
}

interface TemplateItem {
  id: string
  equipName: string
  category: string
  threshold: number
}

const initialTree: TemplateNode[] = [
  {
    id: 'tpl-root', label: '安全库存模板', expanded: true,
    children: [
      {
        id: 'tpl-prov', label: '省厅层级模板', expanded: false,
        children: [
          {
            id: 'tpl-prov-1', label: '通用装备',
            items: [
              { id: 't1', equipName: '服务器', category: '通用装备', threshold: 2 },
              { id: 't2', equipName: '调度控制台', category: '通用装备', threshold: 3 },
            ]
          },
          {
            id: 'tpl-prov-2', label: '通信装备',
            items: [
              { id: 't3', equipName: '对讲机', category: '通信装备', threshold: 15 },
              { id: 't4', equipName: '卫星便携站', category: '通信装备', threshold: 2 },
            ]
          },
        ]
      },
      {
        id: 'tpl-city', label: '市级层级模板', expanded: false,
        children: [
          {
            id: 'tpl-city-1', label: '通用装备',
            items: [
              { id: 't5', equipName: '执法车辆', category: '通用装备', threshold: 8 },
              { id: 't6', equipName: '办公电脑', category: '通用装备', threshold: 25 },
            ]
          },
          {
            id: 'tpl-city-2', label: '通信装备',
            items: [
              { id: 't7', equipName: '对讲机', category: '通信装备', threshold: 30 },
              { id: 't8', equipName: '基站设备', category: '通信装备', threshold: 3 },
            ]
          },
          {
            id: 'tpl-city-3', label: '应急装备',
            items: [
              { id: 't9', equipName: '急救包', category: '急救装备', threshold: 20 },
              { id: 't10', equipName: '强光手电', category: '个人装备', threshold: 40 },
            ]
          },
        ]
      },
      {
        id: 'tpl-county', label: '县局层级模板', expanded: false,
        children: [
          {
            id: 'tpl-county-1', label: '防护装备',
            items: [
              { id: 't11', equipName: '防弹背心', category: '防护装备', threshold: 20 },
              { id: 't12', equipName: '防暴盾牌', category: '防护装备', threshold: 15 },
            ]
          },
          {
            id: 'tpl-county-2', label: '急救装备',
            items: [
              { id: 't13', equipName: '急救包', category: '急救装备', threshold: 20 },
              { id: 't14', equipName: '绷带', category: '急救装备', threshold: 50 },
            ]
          },
        ]
      },
      {
        id: 'tpl-base', label: '基层所队模板', expanded: false,
        children: [
          {
            id: 'tpl-base-1', label: '个人装备',
            items: [
              { id: 't15', equipName: '对讲机', category: '通信装备', threshold: 8 },
              { id: 't16', equipName: '强光手电', category: '个人装备', threshold: 15 },
            ]
          },
          {
            id: 'tpl-base-2', label: '执法装备',
            items: [
              { id: 't17', equipName: '执法记录仪', category: '通用装备', threshold: 8 },
              { id: 't18', equipName: '执法包', category: '执法装备', threshold: 10 },
            ]
          },
        ]
      },
    ]
  }
]

export default function SafetyStockPage({ onNavigate }: Props) {
  const [items, setItems] = useState<SafetyStockItem[]>(safetyData)
  const [searchKeyword, setSearchKeyword] = useState('')
  const [filterStatus, setFilterStatus] = useState<'all' | 'normal' | 'warning'>('all')

  // 模板状态
  const [templateOpen, setTemplateOpen] = useState(false)
  const [treeData, setTreeData] = useState<TemplateNode[]>(initialTree)
  const [treeExpanded, setTreeExpanded] = useState<Record<string, boolean>>({ 'tpl-root': true })
  const [selectedNodeId, setSelectedNodeId] = useState('')
  const [currentTemplateItems, setCurrentTemplateItems] = useState<TemplateItem[]>([])

  // 添加分类弹窗
  const [addNodeModalOpen, setAddNodeModalOpen] = useState(false)
  const [newNodeName, setNewNodeName] = useState('')

  // 装备选择弹窗
  const [equipSelectorOpen, setEquipSelectorOpen] = useState(false)

  const filtered = items.filter(i => {
    const matchKeyword = i.name.toLowerCase().includes(searchKeyword.toLowerCase()) || i.id.includes(searchKeyword) || i.category.includes(searchKeyword)
    if (filterStatus === 'normal') return matchKeyword && i.currentStock >= i.threshold
    if (filterStatus === 'warning') return matchKeyword && i.currentStock < i.threshold
    return matchKeyword
  })

  const normalCount = items.filter(i => i.currentStock >= i.threshold).length
  const warningCount = items.filter(i => i.currentStock < i.threshold).length

  const handleThresholdChange = (id: string, newValue: number) => {
    setItems(prev => prev.map(i => i.id === id ? { ...i, threshold: newValue } : i))
  }

  // 收集叶子节点的 items
  const collectLeafItems = (nodes: TemplateNode[]): TemplateItem[] => {
    const res: TemplateItem[] = []
    nodes.forEach(n => {
      if (n.items) res.push(...n.items)
      if (n.children) res.push(...collectLeafItems(n.children))
    })
    return res
  }

  // 根据 nodeId 找到对应的 items
  const findNodeItems = (nodes: TemplateNode[], nodeId: string): TemplateItem[] => {
    for (const n of nodes) {
      if (n.id === nodeId) {
        if (n.items) return [...n.items]
        if (n.children) return collectLeafItems(n.children)
        return []
      }
      if (n.children) {
        const found = findNodeItems(n.children, nodeId)
        if (found.length > 0) return found
      }
    }
    return []
  }

  // 找到节点的路径
  const findNodePath = (nodes: TemplateNode[], nodeId: string, path: string[] = []): string[] | null => {
    for (const n of nodes) {
      if (n.id === nodeId) return [...path, n.label]
      if (n.children) {
        const result = findNodePath(n.children, nodeId, [...path, n.label])
        if (result) return result
      }
    }
    return null
  }

  // 更新树中指定节点的 items
  const updateNodeItems = (nodes: TemplateNode[], nodeId: string, newItems: TemplateItem[]): TemplateNode[] => {
    return nodes.map(n => {
      if (n.id === nodeId) {
        return { ...n, items: newItems }
      }
      if (n.children) {
        return { ...n, children: updateNodeItems(n.children, nodeId, newItems) }
      }
      return n
    })
  }

  // 添加子节点到指定父节点
  const addChildNode = (parentId: string, label: string) => {
    const newNode: TemplateNode = {
      id: `tpl-${Date.now()}`,
      label,
      expanded: false,
      items: [],
    }

    setTreeData(prev => {
      const walk = (nodes: TemplateNode[]): TemplateNode[] => {
        return nodes.map(n => {
          if (n.id === parentId) {
            return { ...n, expanded: true, children: [...(n.children || []), newNode] }
          }
          if (n.children) {
            return { ...n, children: walk(n.children) }
          }
          return n
        })
      }
      return walk(prev)
    })

    // 自动展开父节点并选中新建节点
    setTreeExpanded(prev => ({ ...prev, [parentId]: true }))
    setSelectedNodeId(newNode.id)
    setCurrentTemplateItems([])
  }

  // 删除节点
  const deleteNode = (nodes: TemplateNode[], nodeId: string): TemplateNode[] => {
    return nodes.filter(n => n.id !== nodeId).map(n => ({
      ...n,
      children: n.children ? deleteNode(n.children, nodeId) : undefined,
    }))
  }

  // 应用模板
  const applyTemplate = () => {
    // 同步当前编辑的 items 到树中
    let finalTree = treeData
    if (selectedNodeId) {
      finalTree = updateNodeItems(treeData, selectedNodeId, currentTemplateItems)
      setTreeData(finalTree)
    }

    const allItems = collectLeafItems(finalTree)
    if (allItems.length === 0) { setTemplateOpen(false); return }

    setItems(prev => {
      const newItems = [...prev]
      allItems.forEach(tpl => {
        const exists = newItems.find(i => i.name === tpl.equipName)
        if (exists) {
          exists.threshold = tpl.threshold
          exists.category = tpl.category
        } else {
          newItems.push({
            id: `P${String(newItems.length + 1).padStart(3, '0')}`,
            name: tpl.equipName,
            category: tpl.category,
            currentStock: 0,
            threshold: tpl.threshold,
          })
        }
      })
      return newItems
    })
    setTemplateOpen(false)
    setCurrentTemplateItems([])
    setSelectedNodeId('')
  }

  // 处理装备选择确认
  const handleEquipConfirm = (selectedEquips: any[]) => {
    const newItems: TemplateItem[] = selectedEquips.map((e, i) => ({
      id: `t-${Date.now()}-${i}`,
      equipName: e.name,
      category: e.category,
      threshold: 5,
    }))

    const updated = [...currentTemplateItems, ...newItems]
    setCurrentTemplateItems(updated)

    // 同步到树
    if (selectedNodeId) {
      setTreeData(prev => updateNodeItems(prev, selectedNodeId, updated))
    }
  }

  // 处理添加分类
  const handleAddNode = () => {
    if (!newNodeName.trim()) return
    const parentId = selectedNodeId || 'tpl-root'
    addChildNode(parentId, newNodeName.trim())
    setNewNodeName('')
    setAddNodeModalOpen(false)
  }

  // 渲染树节点
  const renderTreeNodes = (nodes: TemplateNode[], depth: number) => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const isExpanded = treeExpanded[node.id] ?? false
      const isSelected = selectedNodeId === node.id
      return (
        <div key={node.id}>
          <div
            className={`group flex items-center gap-1 px-2 py-1.5 cursor-pointer transition-colors text-xs ${isSelected ? 'bg-blue-50 text-blue-600 font-medium' : 'hover:bg-gray-50'}`}
            style={{ paddingLeft: `${8 + depth * 16}px` }}
            onClick={() => {
              if (hasChildren) {
                setTreeExpanded(prev => ({ ...prev, [node.id]: !isExpanded }))
              }
              setSelectedNodeId(node.id)
              const foundItems = findNodeItems(treeData, node.id)
              setCurrentTemplateItems(foundItems.length > 0 ? foundItems : [])
            }}
          >
            {hasChildren && (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
            )}
            {!hasChildren && <span className="w-3" />}
            <span className="truncate flex-1">{node.label}</span>
            {node.items && <span className="text-[10px] ml-1" style={{ color: 'var(--text-disabled)' }}>({node.items.length})</span>}

            {/* Hover delete */}
            {node.id !== 'tpl-root' && (
              <button
                className="opacity-0 group-hover:opacity-100 w-5 h-5 rounded flex items-center justify-center hover:bg-red-100 transition-opacity"
                onClick={e => {
                  e.stopPropagation()
                  if (confirm(`确认删除分类"${node.label}"？`)) {
                    setTreeData(prev => deleteNode(prev, node.id))
                    if (selectedNodeId === node.id) {
                      setSelectedNodeId('')
                      setCurrentTemplateItems([])
                    }
                  }
                }}
              >
                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              </button>
            )}
          </div>
          {hasChildren && isExpanded && renderTreeNodes(node.children!, depth + 1)}
        </div>
      )
    })
  }

  const selectedPath = selectedNodeId ? findNodePath(treeData, selectedNodeId) : null

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>安全库存</span>
      </div>

      {/* Search area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>品种名称/类别</label>
            <input className="form-input w-48" placeholder="请输入..." value={searchKeyword} onChange={e => setSearchKeyword(e.target.value)} />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
            <select className="form-input w-28" value={filterStatus} onChange={e => setFilterStatus(e.target.value as any)}>
              <option value="all">全部</option>
              <option value="normal">正常</option>
              <option value="warning">低于安全线</option>
            </select>
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default" onClick={() => { setSearchKeyword(''); setFilterStatus('all') }}>重置</button>
            <button className="btn-primary">查询</button>
            <button className="btn-default flex items-center gap-1" onClick={() => { setTemplateOpen(true); setSelectedNodeId(''); setCurrentTemplateItems([]) }}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
              选择模板
            </button>
          </div>
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-3 gap-4">
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>品种总数</div>
            <div className="text-lg font-bold" style={{ color: '#1890ff' }}>{items.length} 种</div>
          </div>
        </div>
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>库存正常</div>
            <div className="text-lg font-bold" style={{ color: '#52c41a' }}>{normalCount} 种</div>
          </div>
        </div>
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>低于安全线</div>
            <div className="text-lg font-bold" style={{ color: '#ff4d4f' }}>{warningCount} 种</div>
          </div>
        </div>
      </div>

      {/* Data table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th>装备名称</th>
              <th>物资类别</th>
              <th>当前总库存</th>
              <th>安全库存阈值</th>
              <th>差额</th>
              <th>状态</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(item => {
              const diff = item.currentStock - item.threshold
              const isWarning = item.currentStock < item.threshold
              return (
                <tr key={item.id} className={isWarning ? 'bg-red-50' : ''}>
                  <td className="font-medium">{item.name}</td>
                  <td>{item.category}</td>
                  <td className={`font-mono text-sm font-bold ${isWarning ? 'text-red-600' : ''}`}>{item.currentStock}</td>
                  <td>
                    <input
                      className="form-input w-20 text-center font-mono text-xs py-1"
                      type="number"
                      min={1}
                      value={item.threshold}
                      onChange={e => handleThresholdChange(item.id, Number(e.target.value))}
                    />
                  </td>
                  <td className={`font-mono text-xs ${isWarning ? 'text-red-600 font-bold' : 'text-green-600'}`}>
                    {diff >= 0 ? `+${diff}` : diff}
                  </td>
                  <td>
                    {isWarning ? (
                      <span className="tag tag-red text-xs">低于安全库存</span>
                    ) : (
                      <span className="tag tag-green text-xs">正常</span>
                    )}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* ===== Template Config Modal ===== */}
      {templateOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTemplateOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[1100px] max-w-[95vw] h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">安全库存模板配置</h3>
              <button onClick={() => setTemplateOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Body - left/right */}
            <div className="flex flex-1 overflow-hidden">
              {/* Left: tree */}
              <div className="w-[260px] border-r flex flex-col" style={{ borderColor: 'var(--border-color)' }}>
                <div className="p-3 font-medium text-sm border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  <span>层级分类</span>
                  <button
                    className="text-xs flex items-center gap-1 px-2 py-1 rounded hover:bg-blue-100 transition-colors"
                    style={{ color: 'var(--primary-blue)' }}
                    onClick={() => setAddNodeModalOpen(true)}
                  >
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    添加分类
                  </button>
                </div>
                <div className="flex-1 overflow-y-auto py-2">{renderTreeNodes(treeData, 0)}</div>
              </div>

              {/* Right: config table */}
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="text-sm font-semibold mb-1">模板明细配置</h4>
                  <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                    {selectedPath ? `已选择: ${selectedPath.join(' / ')}` : '请点击左侧层级分类选择模板'}
                    {currentTemplateItems.length > 0 && ` · 共 ${currentTemplateItems.length} 条`}
                  </p>
                </div>
                <div className="flex-1 overflow-y-auto p-4">
                  {currentTemplateItems.length === 0 ? (
                    <div className="text-center py-12" style={{ color: 'var(--text-disabled)' }}>
                      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mx-auto mb-3"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/></svg>
                      <p className="text-sm">请点击左侧层级分类选择模板</p>
                      <p className="text-xs mt-1">或点击下方"添加装备"按钮添加明细</p>
                    </div>
                  ) : (
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 w-8" style={{ borderColor: 'var(--border-color)' }}>#</th>
                          <th className="border p-2 w-40" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                          <th className="border p-2 w-32" style={{ borderColor: 'var(--border-color)' }}>物资类别</th>
                          <th className="border p-2 w-28" style={{ borderColor: 'var(--border-color)' }}>安全库存阈值</th>
                          <th className="border p-2 w-10" style={{ borderColor: 'var(--border-color)' }}>操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {currentTemplateItems.map((item, idx) => (
                          <tr key={item.id}>
                            <td className="border p-2 text-center font-mono" style={{ borderColor: 'var(--border-color)' }}>{idx + 1}</td>
                            <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>
                              <input className="w-full text-xs p-1 outline-none bg-transparent" value={item.equipName} onChange={e => {
                                const val = e.target.value
                                setCurrentTemplateItems(prev => { const u = prev.map((it, i) => i === idx ? { ...it, equipName: val } : it); if (selectedNodeId) setTreeData(t => updateNodeItems(t, selectedNodeId, u)); return u })
                              }} />
                            </td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                              <select className="w-full text-xs p-1 outline-none bg-transparent" value={item.category} onChange={e => {
                                const val = e.target.value
                                setCurrentTemplateItems(prev => { const u = prev.map((it, i) => i === idx ? { ...it, category: val } : it); if (selectedNodeId) setTreeData(t => updateNodeItems(t, selectedNodeId, u)); return u })
                              }}>
                                {categoryOptions.map(c => <option key={c}>{c}</option>)}
                              </select>
                            </td>
                            <td className="border p-1" style={{ borderColor: 'var(--border-color)' }}>
                              <input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.threshold} onChange={e => {
                                const val = Number(e.target.value)
                                setCurrentTemplateItems(prev => { const u = prev.map((it, i) => i === idx ? { ...it, threshold: val } : it); if (selectedNodeId) setTreeData(t => updateNodeItems(t, selectedNodeId, u)); return u })
                              }} />
                            </td>
                            <td className="border p-1 text-center" style={{ borderColor: 'var(--border-color)' }}>
                              <button className="text-red-400 hover:text-red-600" onClick={() => {
                                const updated = currentTemplateItems.filter((_, i) => i !== idx)
                                setCurrentTemplateItems(updated)
                                if (selectedNodeId) setTreeData(prev => updateNodeItems(prev, selectedNodeId, updated))
                              }}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                  {/* Add equip button */}
                  {selectedNodeId && (
                    <button
                      className="mt-4 btn-primary text-xs px-3 py-1.5 flex items-center gap-1 mx-auto"
                      onClick={() => setEquipSelectorOpen(true)}
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                      添加装备
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => { setTemplateOpen(false); setCurrentTemplateItems([]); setSelectedNodeId('') }}>取消</button>
              <button className="btn-primary text-xs" disabled={currentTemplateItems.length === 0} onClick={applyTemplate}>确定应用</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Add Node Modal ===== */}
      {addNodeModalOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAddNodeModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[400px] p-5 animate-in fade-in zoom-in duration-200">
            <h3 className="text-base font-semibold mb-4">添加分类</h3>
            <div className="mb-4">
              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>
                上级分类: <span className="font-medium" style={{ color: 'var(--text-primary)' }}>{selectedPath ? selectedPath.join(' / ') : '安全库存模板（根）'}</span>
              </label>
              <label className="block text-xs mb-1 mt-3" style={{ color: 'var(--text-secondary)' }}>新分类名称 <span className="text-red-400">*</span></label>
              <input
                className="form-input w-full"
                placeholder="请输入分类名称"
                value={newNodeName}
                onChange={e => setNewNodeName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleAddNode() }}
                autoFocus
              />
            </div>
            <div className="flex justify-end gap-2">
              <button className="btn-default text-xs" onClick={() => { setAddNodeModalOpen(false); setNewNodeName('') }}>取消</button>
              <button className="btn-primary text-xs" disabled={!newNodeName.trim()} onClick={handleAddNode}>确认添加</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Equip Selector Modal ===== */}
      <EquipSelectorModal
        open={equipSelectorOpen}
        onClose={() => setEquipSelectorOpen(false)}
        onConfirm={handleEquipConfirm}
      />
    </div>
  )
}
