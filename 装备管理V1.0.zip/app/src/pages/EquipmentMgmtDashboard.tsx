import { useState, useEffect } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

function AnimatedNumber({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      setDisplay(Math.floor((1 - Math.pow(1 - progress, 3)) * value))
      if (progress < 1) requestAnimationFrame(animate)
    }
    requestAnimationFrame(animate)
  }, [value, duration])
  return <span>{display.toLocaleString()}</span>
}

export default function EquipmentMgmtDashboard({ onNavigate }: Props) {
  const [activeQuickTab, setActiveQuickTab] = useState<'team' | 'emergency'>('team')

  // 6 stat cards
  const statCards = [
    { label: '装备总数量', value: 156230, unit: '件', color: '#1a4b8c', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z', trend: '+5.2%', trendColor: '#1a4b8c' },
    { label: '在库数量', value: 120500, unit: '件', color: '#1a4b8c', icon: 'M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2V9z', trend: '+3.1%', trendColor: '#1a4b8c' },
    { label: '出库数量', value: 35730, unit: '件', color: '#d4880f', icon: 'M12 5v14M5 12l7 7 7-7M3 12h18', trend: '-1.8%', trendColor: '#c0392b' },
    { label: '今日入库', value: 45, unit: '件', color: '#1a4b8c', icon: 'M12 5v14M5 12l7-7 7 7M3 12h18', trend: '+12件', trendColor: '#1a4b8c' },
    { label: '今日出库', value: 28, unit: '件', color: '#1a4b8c', icon: 'M12 5v14M5 12l7 7 7-7M3 12h18', trend: '-3件', trendColor: '#c0392b' },
    { label: '待审批事项', value: 26, unit: '项', color: '#c0392b', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4', trend: '需处理', trendColor: '#d4880f' },
  ]

  // Transfer approval items
  const transferApprovals = [
    { from: '省厅主仓库', to: '市局限装备仓库', equip: '手持终端 XT-2000', qty: 5, applicant: '张建国', unit: '刑警支队' },
    { from: '市局限装备仓库', to: '区县装备室', equip: '防弹背心 FDY-3R', qty: 3, applicant: '李强', unit: '治安支队' },
    { from: '省厅主仓库', to: '市局限装备仓库', equip: '执法记录仪 DSJ-A7', qty: 2, applicant: '王志强', unit: '特警支队' },
  ]

  // Stock warnings
  const stockWarnings = [
    { name: '手持终端 XT-2000', detail: '库存低于安全线', time: '10:30', level: 'warning' },
    { name: '防弹背心 FDY-3R', detail: '库存即将耗尽', time: '09:45', level: 'danger' },
    { name: '对讲机 PD780G', detail: '库存低于预设值', time: '09:15', level: 'warning' },
    { name: '应急照明灯 YD-100', detail: '库存补充提醒', time: '08:50', level: 'remind' },
  ]

  // Equipment warnings
  const equipWarnings = [
    { name: '执法记录仪 DSJ-A7', detail: '即将过质保期', time: '11:00', level: 'warning' },
    { name: '手持终端 XT-2000', detail: '连续超期未归还', time: '10:15', level: 'danger' },
    { name: '防弹背心 FDY-3R', detail: '检测到异常出库', time: '09:30', level: 'warning' },
    { name: '战术头盔 MICH-2000', detail: '保养周期到期', time: '08:20', level: 'remind' },
  ]

  // Quick entry items
  const teamQuickItems = [
    { label: '仓库管理', color: '#1a4b8c', icon: 'M12 5v14M5 12l7-7 7 7', onClick: () => onNavigate?.('warehouse-mgmt') },
    { label: '出库管理', color: '#d4880f', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4', onClick: () => onNavigate?.('warehouse-mgmt', 'outbound') },
    { label: '入库管理', color: '#1a4b8c', icon: 'M12 5v14M5 12l7-7 7 7', onClick: () => onNavigate?.('warehouse-mgmt', 'inbound') },
    { label: '调拨管理', color: '#1a4b8c', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4', onClick: () => onNavigate?.('emergency', 'transfer') },
    { label: '领用管理', color: '#1a4b8c', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', onClick: () => onNavigate?.('equip-borrow') },
    { label: '报修管理', color: '#c0392b', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z', onClick: () => onNavigate?.('repair') },
    { label: '报废管理', color: '#c0392b', icon: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16', onClick: () => onNavigate?.('scrap') },
    { label: '所队配发管理', color: '#1a4b8c', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z', onClick: () => onNavigate?.('emergency', 'team-distribute') },
    { label: '保养管理', color: '#1a4b8c', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z', onClick: () => onNavigate?.('maintenance') },
    { label: '拆分管理', color: '#1a4b8c', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4M4 3v18', onClick: () => onNavigate?.('split-management') },
  ]

  const emergencyQuickItems = [
    { label: '仓库可视化', color: '#1a4b8c', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z', onClick: () => onNavigate?.('warehouse', '') },
    { label: '仓库管理', color: '#1a4b8c', icon: 'M12 5v14M5 12l7-7 7 7', onClick: () => onNavigate?.('warehouse-mgmt') },
    { label: '调拨管理', color: '#1a4b8c', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4', onClick: () => onNavigate?.('emergency', 'transfer') },
    { label: '出库管理', color: '#d4880f', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4', onClick: () => onNavigate?.('warehouse-mgmt', 'outbound') },
    { label: '入库管理', color: '#1a4b8c', icon: 'M12 5v14M5 12l7-7 7 7', onClick: () => onNavigate?.('warehouse-mgmt', 'inbound') },
    { label: '领用管理', color: '#1a4b8c', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', onClick: () => onNavigate?.('equip-borrow') },
    { label: '报修管理', color: '#c0392b', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z', onClick: () => onNavigate?.('repair') },
    { label: '报废管理', color: '#c0392b', icon: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16', onClick: () => onNavigate?.('scrap') },
    { label: '保养管理', color: '#1a4b8c', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z', onClick: () => onNavigate?.('maintenance') },
    { label: '拆分管理', color: '#1a4b8c', icon: 'M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4M4 3v18', onClick: () => onNavigate?.('split-management') },
  ]

  const levelMap: Record<string, { label: string; color: string; bg: string }> = {
    warning: { label: '警告', color: '#d4880f', bg: '#e8eef5' },
    danger: { label: '紧急', color: '#c0392b', bg: '#fff2f0' },
    remind: { label: '提醒', color: '#1a4b8c', bg: '#e8eef5' },
  }

  return (
    <div className="p-4 space-y-4">
      {/* 6 Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        {statCards.map(card => (
          <div key={card.label} className="content-card p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2"><path d={card.icon}/></svg>
                <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{card.label}</span>
              </div>
            </div>
            <div className="text-2xl font-bold leading-tight" style={{ color: card.color }}>
              <AnimatedNumber value={card.value} />
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{card.unit}</span>
              <span className="text-xs font-medium" style={{ color: card.trendColor }}>{card.trend}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Three Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left: Quick Entry */}
        <div className="content-card p-4">
          <div className="flex border-b mb-3" style={{ borderColor: 'var(--border-color)' }}>
            <button onClick={() => setActiveQuickTab('team')} className={`px-3 py-2 text-xs font-medium border-b-2 transition-all ${activeQuickTab === 'team' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500'}`}>所队装备管理</button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {(activeQuickTab === 'team' ? teamQuickItems : emergencyQuickItems).map(item => (
              <button key={item.label} onClick={item.onClick || (() => alert('功能开发中...'))} className="flex items-center gap-2 p-2.5 rounded-lg border hover:shadow-sm transition-all text-left" style={{ borderColor: 'var(--border-color)' }}>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={item.color} strokeWidth="2"><path d={item.icon}/></svg>
                <span className="text-xs">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Middle: Transfer Approvals */}
        <div className="content-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold">调拨审批</h3>
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#fff2f0', color: '#c0392b' }}>{transferApprovals.length} 条待处理</span>
          </div>
          <div className="space-y-2">
            {transferApprovals.map((item, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg border cursor-pointer hover:border-blue-300 hover:shadow-sm transition-all"
                style={{ borderColor: 'var(--border-color)' }}
                onClick={() => onNavigate?.('emergency', 'transfer')}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-1.5 text-xs">
                    <span className="font-medium">{item.from}</span>
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    <span className="font-medium" style={{ color: 'var(--primary-blue)' }}>{item.to}</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: '#fffbe6', color: '#d4880f' }}>待审批</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                    <span>{item.equip}</span>
                    <span className="mx-1">x</span>
                    <span className="font-mono font-medium">{item.qty}</span>
                  </div>
                  <div className="text-[10px]" style={{ color: 'var(--text-disabled)' }}>
                    {item.applicant} / {item.unit}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right: Warnings */}
        <div className="space-y-4">
          {/* Stock Warnings */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-3">库存预警记录</h3>
            <div className="space-y-2">
              {stockWarnings.map((item, i) => {
                const l = levelMap[item.level]
                return (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background: l.bg }}>
                    <div>
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.detail}</div>
                      <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{item.time}</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-xs flex-shrink-0" style={{ background: '#fff', color: l.color, border: `1px solid ${l.color}` }}>{l.label}</span>
                  </div>
                )
              })}
            </div>
          </div>

          {/* Equipment Warnings */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-3">装备预警记录</h3>
            <div className="space-y-2">
              {equipWarnings.map((item, i) => {
                const l = levelMap[item.level]
                return (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg" style={{ background: l.bg }}>
                    <div>
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.detail}</div>
                      <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{item.time}</div>
                    </div>
                    <span className="px-2 py-0.5 rounded text-xs flex-shrink-0" style={{ background: '#fff', color: l.color, border: `1px solid ${l.color}` }}>{l.label}</span>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
