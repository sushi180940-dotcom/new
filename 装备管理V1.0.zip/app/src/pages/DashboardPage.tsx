import { useState, useEffect } from 'react'
import ReactECharts from 'echarts-for-react'

interface DashboardProps {
  onNavigate?: (module: string, subTab?: string) => void
}

function AnimatedNumber({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      setDisplay(Math.floor((1 - Math.pow(1 - progress, 3)) * value))
      if (progress < 1) requestAnimationFrame(animate)
    }
    requestAnimationFrame(animate)
  }, [value, duration])
  return <span>{display.toLocaleString()}</span>
}

/* ================================================================
   业务流水数据
   ================================================================ */
type BizType = '调拨' | '领用' | '报修' | '报废' | '所队配发' | '供应商审核' | '装备审核'

const bizColors: Record<BizType, string> = {
  '调拨': '#1890ff', '领用': '#722ed1', '报修': '#faad14', '报废': '#ff4d4f', '所队配发': '#52c41a',
  '供应商审核': '#eb2f96', '装备审核': '#13c2c2',
}

type StatusType = '待处理' | '已完成'

const statusMap: Record<StatusType, { color: string; bg: string }> = {
  '待处理': { color: '#d4880f', bg: '#f5efe6' },
  '已完成': { color: '#52c41a', bg: '#f6ffed' },
}

/* 调拨：调拨单号，调拨单位，装备清单，申请时间 */
interface TransferRecord { type: '调拨'; no: string; unit: string; equipList: string; time: string; status: StatusType }
/* 领用：申请单位/人，类型（借用/领用），装备清单，申请时间 */
interface BorrowRecord { type: '领用'; applicant: string; borrowType: string; equipList: string; time: string; status: StatusType }
/* 报修：申请单位/人，装备清单，申请时间 */
interface RepairRecord { type: '报修'; applicant: string; equipList: string; time: string; status: StatusType }
/* 报废：申请单位/人，装备清单，申请时间 */
interface ScrapRecord { type: '报废'; applicant: string; equipList: string; time: string; status: StatusType }
/* 所队配发：配发单位，装备清单，申请时间 */
interface DistributeRecord { type: '所队配发'; unit: string; equipList: string; time: string; status: StatusType }
/* 供应商审核：申请供应商名称、申请时间、供应商类型 */
interface SupplierAuditRecord { type: '供应商审核'; supplierName: string; applyTime: string; supplierType: string; status: StatusType }
/* 装备审核：申请供应商名称、申请时间、装备名称 */
interface EquipAuditRecord { type: '装备审核'; supplierName: string; applyTime: string; equipName: string; status: StatusType }

type BizRecord = TransferRecord | BorrowRecord | RepairRecord | ScrapRecord | DistributeRecord | SupplierAuditRecord | EquipAuditRecord

const bizRecords: Record<BizType, BizRecord[]> = {
  '调拨': [
    { type: '调拨', no: 'DB2024001', unit: '省厅主仓库 → 市局限装备仓库', equipList: '手持终端 XT-2000 x5', time: '2024-03-15 09:30', status: '待处理' },
    { type: '调拨', no: 'DB2024002', unit: '市局限装备仓库 → 区县装备室', equipList: '防弹背心 FDY-3R x3', time: '2024-03-15 10:15', status: '待处理' },
    { type: '调拨', no: 'DB2024003', unit: '省厅主仓库 → 交警总队', equipList: '执法记录仪 DSJ-A7 x10', time: '2024-03-15 11:00', status: '已完成' },
    { type: '调拨', no: 'DB2024004', unit: '区县装备室 → 派出所', equipList: '对讲机 PD780G x8', time: '2024-03-15 14:20', status: '待处理' },
    { type: '调拨', no: 'DB2024005', unit: '省厅主仓库 → 特警支队', equipList: '战术头盔 MICH-2000 x6', time: '2024-03-15 08:00', status: '已完成' },
    { type: '调拨', no: 'DB2024006', unit: '市局限装备仓库 → 刑警支队', equipList: '防暴盾牌 FB-P x4', time: '2024-03-14 16:30', status: '已完成' },
  ],
  '领用': [
    { type: '领用', applicant: '王志强/特警支队', borrowType: '领用', equipList: '手持终端 XT-2000 x2', time: '2024-03-15 08:30', status: '已完成' },
    { type: '领用', applicant: '赵明华/交警大队', borrowType: '借用', equipList: '执法记录仪 DSJ-A7 x3', time: '2024-03-15 09:45', status: '待处理' },
    { type: '领用', applicant: '陈晓东/网安支队', borrowType: '领用', equipList: '对讲机 PD780G x5', time: '2024-03-15 13:20', status: '待处理' },
    { type: '领用', applicant: '刘建华/巡警支队', borrowType: '借用', equipList: '防弹背心 FDY-3R x2', time: '2024-03-15 15:00', status: '已完成' },
    { type: '领用', applicant: '孙德胜/审计处', borrowType: '领用', equipList: '战术头盔 MICH-2000 x1', time: '2024-03-15 16:30', status: '已完成' },
    { type: '领用', applicant: '周文博/仓库管理组', borrowType: '领用', equipList: '应急照明灯 YD-100 x4', time: '2024-03-14 10:00', status: '待处理' },
  ],
  '报修': [
    { type: '报修', applicant: '郑国强/设备维护组', equipList: '手持终端 XT-2000（屏幕故障）', time: '2024-03-15 08:15', status: '待处理' },
    { type: '报修', applicant: '孙德胜/技术保障组', equipList: '对讲机 PD780G（无法开机）', time: '2024-03-15 09:30', status: '待处理' },
    { type: '报修', applicant: '马为民/资产管理组', equipList: '执法记录仪 DSJ-A7（摄像头模糊）', time: '2024-03-15 11:00', status: '已完成' },
    { type: '报修', applicant: '黄志勇/指挥中心', equipList: '应急照明灯 YD-100（电池损坏）', time: '2024-03-15 13:45', status: '已完成' },
    { type: '报修', applicant: '周丽华/审计处', equipList: '防弹背心 FDY-3R（ strap断裂）', time: '2024-03-15 15:20', status: '待处理' },
    { type: '报修', applicant: '吴天明/督查室', equipList: '战术头盔 MICH-2000（面罩松动）', time: '2024-03-14 14:00', status: '已完成' },
  ],
  '报废': [
    { type: '报废', applicant: '马为民/资产管理组', equipList: '手持终端 XT-2000（使用年限到期）', time: '2024-03-14 10:00', status: '已完成' },
    { type: '报废', applicant: '黄志勇/指挥中心', equipList: '对讲机 PD780G（无法修复）', time: '2024-03-14 11:30', status: '已完成' },
    { type: '报废', applicant: '赵明华/交警大队', equipList: '执法记录仪 DSJ-A7（主板烧毁）', time: '2024-03-14 14:00', status: '待处理' },
    { type: '报废', applicant: '周丽华/审计处', equipList: '防弹背心 FDY-3R（防护等级不达标）', time: '2024-03-14 16:30', status: '待处理' },
    { type: '报废', applicant: '吴天明/督查室', equipList: '应急照明灯 YD-100（灯管老化）', time: '2024-03-15 09:15', status: '已完成' },
    { type: '报废', applicant: '王建国/刑警支队', equipList: '战术头盔 MICH-2000（外壳破裂）', time: '2024-03-15 11:00', status: '已完成' },
  ],
  '所队配发': [
    { type: '所队配发', unit: '刑警支队', equipList: '手持终端 XT-2000 x10, 对讲机 x5', time: '2024-03-15 09:00', status: '已完成' },
    { type: '所队配发', unit: '交警大队', equipList: '执法记录仪 DSJ-A7 x15, 防弹背心 x8', time: '2024-03-15 10:30', status: '待处理' },
    { type: '所队配发', unit: '特警支队', equipList: '战术头盔 MICH-2000 x12, 防暴盾牌 x6', time: '2024-03-15 13:00', status: '待处理' },
    { type: '所队配发', unit: '巡警支队', equipList: '对讲机 PD780G x10, 应急照明灯 x5', time: '2024-03-15 14:30', status: '已完成' },
    { type: '所队配发', unit: '网安支队', equipList: '手持终端 XT-2000 x8, 执法记录仪 x6', time: '2024-03-14 11:00', status: '已完成' },
    { type: '所队配发', unit: '派出所', equipList: '对讲机 PD780G x6, 防弹背心 x4', time: '2024-03-14 15:00', status: '待处理' },
  ],
  '供应商审核': [
    { type: '供应商审核', supplierName: '大华安防科技有限公司', applyTime: '2024-03-15 09:00', supplierType: '生产商', status: '待处理' },
    { type: '供应商审核', supplierName: '海康威视数字技术股份有限公司', applyTime: '2024-03-15 10:30', supplierType: '供应商', status: '待处理' },
    { type: '供应商审核', supplierName: '中兴通讯股份有限公司', applyTime: '2024-03-14 14:00', supplierType: '供应商', status: '已完成' },
    { type: '供应商审核', supplierName: '浙江大华技术股份有限公司', applyTime: '2024-03-14 16:30', supplierType: '生产商', status: '已完成' },
    { type: '供应商审核', supplierName: '华为技术有限公司', applyTime: '2024-03-13 11:00', supplierType: '协议供货商', status: '已完成' },
    { type: '供应商审核', supplierName: '宇视科技有限公司', applyTime: '2024-03-13 09:30', supplierType: '供应商', status: '待处理' },
  ],
  '装备审核': [
    { type: '装备审核', supplierName: '大华安防科技有限公司', applyTime: '2024-03-15 08:30', equipName: '防暴盾牌 FB-P', status: '待处理' },
    { type: '装备审核', supplierName: '海康威视数字技术股份有限公司', applyTime: '2024-03-15 11:00', equipName: '执法记录仪 DSJ-A7', status: '待处理' },
    { type: '装备审核', supplierName: '华为技术有限公司', applyTime: '2024-03-14 09:45', equipName: '手持终端 XT-2000', status: '已完成' },
    { type: '装备审核', supplierName: '中兴通讯股份有限公司', applyTime: '2024-03-14 13:20', equipName: '对讲机 PD780G', status: '已完成' },
    { type: '装备审核', supplierName: '浙江大华技术股份有限公司', applyTime: '2024-03-13 15:00', equipName: '战术头盔 MICH-2000', status: '已完成' },
    { type: '装备审核', supplierName: '宇视科技有限公司', applyTime: '2024-03-13 10:15', equipName: '应急照明灯 YD-100', status: '待处理' },
  ],
}

/* ================================================================
   预警记录数据
   ================================================================ */
const warningRecords = [
  { name: '手持终端 XT-2000', detail: '库存低于安全线（当前15件，安全库存25件）', time: '10:30', level: 'warning' },
  { name: '防弹背心 FDY-3R', detail: '库存即将耗尽（当前3件，安全库存10件）', time: '09:45', level: 'danger' },
  { name: '对讲机 PD780G', detail: '库存低于预设值（当前8件，安全库存20件）', time: '09:15', level: 'warning' },
  { name: '应急照明灯 YD-100', detail: '库存补充提醒（当前12件，安全库存15件）', time: '08:50', level: 'remind' },
  { name: '执法记录仪 DSJ-A7', detail: '即将过质保期（剩余30天）', time: '11:00', level: 'warning' },
  { name: '手持终端 XT-2000', detail: '连续超期未归还（已超期15天）', time: '10:15', level: 'danger' },
  { name: '战术头盔 MICH-2000', detail: '保养周期到期（剩余7天）', time: '08:20', level: 'remind' },
  { name: '防暴盾牌 FB-P', detail: '检测到异常出库（昨日出库10件）', time: '09:30', level: 'warning' },
]

const levelMap: Record<string, { label: string; color: string; bg: string }> = {
  warning: { label: '警告', color: '#d4880f', bg: '#f5efe6' },
  danger: { label: '紧急', color: '#c0392b', bg: '#f5e6e6' },
  remind: { label: '提醒', color: '#1a4b8c', bg: '#e8eef5' },
}

/* ================
   主组件
   ================ */
export default function DashboardPage({ onNavigate }: DashboardProps) {
  const commonFunctions = [
    { label: '采购及售后管理', icon: 'M3 3h18v18H3V3zm16 16V5H5v14h14zM7 7h4v4H7V7zm0 6h4v4H7v-4zm6-6h4v4h-4V7zm0 6h4v4h-4v-4z', color: '#1a4b8c', onClick: () => onNavigate?.('procurement') },
    { label: '仓库管理', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z', color: '#1a4b8c', onClick: () => onNavigate?.('warehouse-mgmt') },
    { label: '装备领用', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', color: '#1a4b8c', onClick: () => onNavigate?.('equip-borrow') },
    { label: '报修管理', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z', color: '#1a4b8c', onClick: () => onNavigate?.('repair') },
    { label: '装备研判分析', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 002 2h2a2 2 0 002-2v-6', color: '#1a4b8c', onClick: () => onNavigate?.('analysis') },
    { label: '系统管理', icon: 'M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm0-14a4 4 0 100 8 4 4 0 000-8z', color: '#1a4b8c', onClick: () => onNavigate?.('system') },
  ]

  // 实时数据
  const statCards = [
    { label: '全省装备数量', value: 156230, unit: '件', color: '#1a4b8c', bg: '#e8eef5', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
    { label: '全省应急装备数量', value: 28356, unit: '件', color: '#1a4b8c', bg: '#e8eef5', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z' },
    { label: '供应商数量', value: 156, unit: '家', color: '#1a4b8c', bg: '#e8eef5', icon: 'M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z' },
    { label: '商品数量', value: 3680, unit: '种', color: '#1a4b8c', bg: '#e8eef5', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
  ]

  /* ================================================================
     通知公告数据
     ================================================================ */
  type NoticeType = '政策法规' | '业务通知' | '系统公告'

  const noticeConfig: Record<NoticeType, { color: string; bg: string; icon: string }> = {
    '政策法规': { color: '#1a4b8c', bg: '#e8eef5', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z' },
    '业务通知': { color: '#d4880f', bg: '#f5efe6', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
    '系统公告': { color: '#52c41a', bg: '#f6ffed', icon: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z' },
  }

  interface NoticeRecord {
    type: NoticeType
    title: string
    content: string
    publisher: string
    time: string
  }

  const noticeRecords: Record<NoticeType, NoticeRecord[]> = {
    '政策法规': [
      { type: '政策法规', title: '公安部关于进一步加强警用装备管理的通知', content: '公安部发布最新警用装备配备标准，要求各级公安机关严格执行装备采购、使用、报废全流程管理规范。', publisher: '公安部装备财务局', time: '2024-06-01 09:00' },
      { type: '政策法规', title: '新型警用装备配备标准（2024版）颁布实施', content: '新颁布的警用装备配备标准涵盖执法记录仪、防弹背心、手持终端等20类装备的技术规范和配备要求。', publisher: '公安部科技信息化局', time: '2024-05-28 14:30' },
      { type: '政策法规', title: '警用装备采购管理办法（修订版）', content: '修订后的采购管理办法对装备采购流程、供应商管理、验收标准等进行全面规范。', publisher: '省公安厅装备处', time: '2024-05-20 10:15' },
      { type: '政策法规', title: '应急物资储备管理规定', content: '明确应急装备物资储备的种类、数量、轮换机制和管理责任。', publisher: '省应急管理厅', time: '2024-05-15 16:00' },
      { type: '政策法规', title: '警用装备报废鉴定标准更新', content: '更新警用装备报废技术鉴定标准，明确各类装备使用年限和报废条件。', publisher: '公安部装备财务局', time: '2024-05-10 08:45' },
    ],
    '业务通知': [
      { type: '业务通知', title: '2024年第二季度装备采购计划公示', content: '本季度计划采购执法记录仪200台、防弹背心150件、手持终端300台，现予以公示。', publisher: '采购管理科', time: '2024-06-01 10:30' },
      { type: '业务通知', title: '省厅主仓库装备调拨通知', content: '向各地市发放应急照明灯500盏、对讲机200台，请各单位做好接收准备。', publisher: '仓库管理科', time: '2024-05-30 09:15' },
      { type: '业务通知', title: '2024年度装备盘点工作安排', content: '定于6月15日至30日开展全省装备盘点工作，请各单位提前准备。', publisher: '资产管理科', time: '2024-05-28 11:00' },
      { type: '业务通知', title: '第二季度装备维护保养计划', content: '请各单位按照维护计划对执法记录仪、对讲机等设备进行定期保养。', publisher: '设备维护科', time: '2024-05-25 14:20' },
      { type: '业务通知', title: 'XT-2000手持终端招标文件发布', content: 'XT-2000手持终端采购项目已发布招标公告，欢迎符合条件的供应商参与投标。', publisher: '采购管理科', time: '2024-05-22 16:30' },
    ],
    '系统公告': [
      { type: '系统公告', title: '系统升级维护通知（6月8日）', content: '定于6月8日（周六）凌晨2:00-6:00进行系统升级维护，期间系统将暂停服务。', publisher: '系统管理员', time: '2024-06-01 08:00' },
      { type: '系统公告', title: '装备溯源功能上线公告', content: '新增装备全生命周期溯源功能，支持扫码查看装备从采购到报废的完整轨迹。', publisher: '产品运营组', time: '2024-05-30 10:00' },
      { type: '系统公告', title: '系统使用培训安排（6月10日）', content: '定于6月10日举办系统操作培训，重点讲解新增功能和常见问题处理。', publisher: '培训管理部', time: '2024-05-28 09:30' },
      { type: '系统公告', title: '账号安全提醒：请及时修改初始密码', content: '为保障系统安全，请使用初始密码登录的用户在6月10日前完成密码修改。', publisher: '信息安全组', time: '2024-05-25 11:20' },
      { type: '系统公告', title: '新功能：智能库存预警已上线', content: '系统新增AI智能库存预警功能，可根据历史消耗自动预测库存需求。', publisher: '产品运营组', time: '2024-05-20 15:00' },
    ],
  }

  // 业务记录
  const bizTabs: BizType[] = ['调拨', '领用', '报修', '报废', '所队配发', '供应商审核', '装备审核']
  const [activeBizTab, setActiveBizTab] = useState<BizType>('调拨')

  // 计算各页签待处理数量
  const pendingCounts: Record<BizType, number> = {} as Record<BizType, number>
  bizTabs.forEach(tab => {
    pendingCounts[tab] = bizRecords[tab].filter(r => r.status === '待处理').length
  })

  const statusTagMap: Record<string, string> = {
    '已出库': 'tag-green', '已入库': 'tag-green', '已领用': 'tag-green', '已完成': 'tag-green', '已报废': 'tag-green',
    '出库中': 'tag-orange', '入库中': 'tag-orange', '维修中': 'tag-orange', '审批中': 'tag-purple',
    '待出库': 'tag-yellow', '待验收': 'tag-yellow', '待审批': 'tag-yellow', '待盘点': 'tag-yellow', '待处理': 'tag-yellow',
  }

  /* ===== 通知公告模块 ===== */
  function NoticeModule() {
    const noticeTabs: NoticeType[] = ['政策法规', '业务通知', '系统公告']
    const [activeNoticeTab, setActiveNoticeTab] = useState<NoticeType>('政策法规')

    return (
      <div className="content-card p-4 flex flex-col">
        <h3 className="text-sm font-semibold mb-3">通知公告</h3>
        <div className="flex gap-1 border-b mb-3 overflow-x-auto" style={{ borderColor: 'var(--border-color)' }}>
          {noticeTabs.map(tab => {
            const isActive = activeNoticeTab === tab
            const cfg = noticeConfig[tab]
            return (
              <button
                key={tab}
                className={isActive
                  ? 'relative px-3 py-2 text-xs font-medium transition-colors whitespace-nowrap'
                  : 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)] whitespace-nowrap'
                }
                style={isActive ? { color: cfg.color } : {}}
                onClick={() => setActiveNoticeTab(tab)}
              >
                <span className="flex items-center gap-1">
                  {tab}
                  <span className="text-[10px] px-1 py-0 rounded-full" style={{ background: cfg.bg, color: cfg.color }}>
                    {noticeRecords[tab].length}
                  </span>
                </span>
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: cfg.color }} />
                )}
              </button>
            )
          })}
        </div>
        <div className="space-y-2 max-h-[360px] overflow-y-auto flex-1">
          {noticeRecords[activeNoticeTab].map((item, idx) => {
            const cfg = noticeConfig[item.type]
            return (
              <div
                key={idx}
                className="p-3 rounded-lg border cursor-pointer hover:shadow-sm transition-all"
                style={{ borderColor: 'var(--border-color)', background: '#fff' }}
              >
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className="text-[10px] px-1.5 py-0.5 rounded flex-shrink-0" style={{ background: cfg.bg, color: cfg.color }}>{item.type}</span>
                  <span className="text-xs font-medium truncate flex-1">{item.title}</span>
                </div>
                <div className="text-[11px] mb-1" style={{ color: 'var(--text-secondary)' }}>{item.content}</div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px]" style={{ color: 'var(--text-secondary)' }}>{item.publisher}</span>
                  <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>{item.time}</span>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return (
    <div className="p-4 space-y-4">
      {/* ============ 常用功能 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>常用功能</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {commonFunctions.map(item => (
            <button
              key={item.label}
              onClick={item.onClick || (() => alert('功能开发中...'))}
              className="content-card p-4 flex flex-col items-center gap-3 hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110" style={{ background: `${item.color}15` }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={item.icon} /></svg>
              </div>
              <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ============ 实时数据展示 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>实时数据展示</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map(card => (
            <div key={card.label} className="content-card p-5 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: card.bg }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="1.5"><path d={card.icon} /></svg>
              </div>
              <div>
                <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                <div className="text-2xl font-bold" style={{ color: card.color }}><AnimatedNumber value={card.value} /></div>
                <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{card.unit}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============ 待办事项/已办事项 + 预警记录（同一行） ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>待办事项/已办事项</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 业务记录 */}
          <div className="content-card p-4">
            <div className="flex gap-1 border-b mb-3 overflow-x-auto" style={{ borderColor: 'var(--border-color)' }}>
              {bizTabs.map(tab => {
                const isActive = activeBizTab === tab
                const pendingCount = pendingCounts[tab]
                return (
                  <button
                    key={tab}
                    className={isActive
                      ? 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--primary-blue)] whitespace-nowrap'
                      : 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)] whitespace-nowrap'
                    }
                    onClick={() => setActiveBizTab(tab)}
                  >
                    <span className="flex items-center gap-1">
                      {tab}
                      {pendingCount > 0 && (
                        <span className="text-[10px] px-1 py-0 rounded-full" style={{ background: isActive ? '#f5e6e6' : '#f5e6e6', color: '#c0392b' }}>
                          {pendingCount}
                        </span>
                      )}
                    </span>
                    {isActive && (
                      <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: 'var(--primary-blue)' }} />
                    )}
                  </button>
                )
              })}
            </div>
            <div className="space-y-2 max-h-[360px] overflow-y-auto">
              {bizRecords[activeBizTab].map((r, i) => {
                const s = statusMap[r.status]
                // 获取标题：不同类型显示不同主标题
                const getTitle = () => {
                  if (r.type === '调拨') return r.no
                  if (r.type === '领用') return r.applicant
                  if (r.type === '报修') return r.applicant
                  if (r.type === '报废') return r.applicant
                  if (r.type === '所队配发') return r.unit
                  if (r.type === '供应商审核') return (r as SupplierAuditRecord).supplierName
                  if (r.type === '装备审核') return (r as EquipAuditRecord).supplierName
                  return ''
                }
                // 获取副标题描述
                const getDesc = () => {
                  if (r.type === '调拨') return `调拨单位：${r.unit}`
                  if (r.type === '领用') return `申请人：${r.applicant}`
                  if (r.type === '报修') return `申请人：${r.applicant}`
                  if (r.type === '报废') return `申请人：${r.applicant}`
                  if (r.type === '所队配发') return `配发单位：${r.unit}`
                  if (r.type === '供应商审核') return `供应商类型：${(r as SupplierAuditRecord).supplierType}`
                  if (r.type === '装备审核') return `装备名称：${(r as EquipAuditRecord).equipName}`
                  return ''
                }
                // 获取时间
                const getTime = () => {
                  if (r.type === '供应商审核' || r.type === '装备审核') {
                    return (r as SupplierAuditRecord | EquipAuditRecord).applyTime
                  }
                  return r.time
                }
                return (
                  <div key={i} className="p-2.5 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: bizColors[r.type] }} />
                        <span className="text-xs font-medium truncate" style={{ color: 'var(--primary-blue)' }}>
                          {getTitle()}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 flex-shrink-0">
                        <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: s.bg, color: s.color }}>{r.status}</span>
                        <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>{getTime()}</span>
                      </div>
                    </div>
                    {'borrowType' in r && (
                      <div className="text-[11px] mb-0.5" style={{ color: 'var(--text-secondary)' }}>
                        类型：{r.borrowType}
                      </div>
                    )}
                    <div className="text-[11px] truncate" style={{ color: 'var(--text-secondary)' }}>
                      {getDesc()}
                    </div>
                    {r.type !== '供应商审核' && r.type !== '装备审核' && (
                      <div className="text-[11px] mt-0.5 truncate" style={{ color: 'var(--text-secondary)' }}>
                        装备清单：{r.equipList}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          {/* 通知公告 */}
          <NoticeModule />

          {/* 预警记录 */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-3">预警记录</h3>
            <div className="space-y-2">
              {warningRecords.map((item, i) => {
                const l = levelMap[item.level]
                return (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg" style={{ background: l.bg }}>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.detail}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                      <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{item.time}</span>
                      <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: '#fff', color: l.color, border: `1px solid ${l.color}` }}>{l.label}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>

    </div>
  )
}
