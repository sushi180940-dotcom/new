import { useState, useMemo } from 'react'
import ReactEChartsCore from 'echarts-for-react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type Dimension = 'category' | 'spec' | 'name' | 'warehouse'
type StatusFilter = 'all' | 'available' | 'repair' | 'scrap'
type ChartType = 'bar' | 'pie' | 'stack'

interface StockItem {
  id: string
  warehouse: string
  jurisdiction: string
  category: string
  name: string
  spec: string
  available: number
  repair: number
  scrap: number
  safetyThreshold: number
}

const warehouses = ['省厅主仓库', '市局限装备仓库', 'A区县级装备库', 'B区县级装备库', 'C区县级装备室']
const jurisdictions = ['省厅直属', '市局管辖', '区县管辖']
const categories = ['通信设备', '记录设备', '防护装备', '照明设备', '应急装备', '警械装备', '催泪喷射器']

function generateData(): StockItem[] {
  const names: Record<string, string[]> = {
    '通信设备': ['手持终端 XT-2000', '对讲机 PD780G', '车载电台 TM-8100', '卫星电话 ST-900'],
    '记录设备': ['执法记录仪 DSJ-A7', '数据采集器 DC-500', '录音笔 LY-100'],
    '防护装备': ['防弹背心 FDY-3R', '战术头盔 MICH-2000', '防弹盾牌 FDP-3S', '防刺手套 FC-02', '防割护臂 FH-01'],
    '照明设备': ['应急照明灯 YD-100', '强光手电 QG-500', '头灯 TD-200'],
    '应急装备': ['急救包 JJ-01', '救生绳 JS-30', '消防斧 XF-100', '破拆工具组 PC-300'],
    '警械装备': ['手铐 SK-01', '警棍 JB-100', '约束带 XY-50'],
    '催泪喷射器': ['催泪喷射器 CL-200', '催泪弹 CD-100'],
  }
  const specs: Record<string, string[]> = {
    '手持终端 XT-2000': ['XT-2000/黑色/128G', 'XT-2000/白色/64G'],
    '对讲机 PD780G': ['PD780G/U段', 'PD780G/V段'],
    '车载电台 TM-8100': ['TM-8100/标准版', 'TM-8100/增强版'],
    '卫星电话 ST-900': ['ST-900/便携款'],
    '执法记录仪 DSJ-A7': ['DSJ-A7/64G/标准', 'DSJ-A7/128G/高清'],
    '数据采集器 DC-500': ['DC-500/WiFi版', 'DC-500/4G版'],
    '录音笔 LY-100': ['LY-100/32G'],
    '防弹背心 FDY-3R': ['FDY-3R/三级/M', 'FDY-3R/三级/L', 'FDY-3R/三级/XL'],
    '战术头盔 MICH-2000': ['MICH-2000/M号', 'MICH-2000/L号'],
    '防弹盾牌 FDP-3S': ['FDP-3S/手持型', 'FDP-3S/轮式'],
    '防刺手套 FC-02': ['FC-02/M', 'FC-02/L'],
    '防割护臂 FH-01': ['FH-01/均码'],
    '应急照明灯 YD-100': ['YD-100/LED', 'YD-100/氙气'],
    '强光手电 QG-500': ['QG-500/充电款', 'QG-500/电池款'],
    '头灯 TD-200': ['TD-200/防水型'],
    '急救包 JJ-01': ['JJ-01/标准型', 'JJ-01/增强型'],
    '救生绳 JS-30': ['JS-30/30米', 'JS-30/50米'],
    '消防斧 XF-100': ['XF-100/标准型'],
    '破拆工具组 PC-300': ['PC-300/液压型'],
    '手铐 SK-01': ['SK-01/标准型'],
    '警棍 JB-100': ['JB-100/伸缩型', 'JB-100/直杆型'],
    '约束带 XY-50': ['XY-50/尼龙'],
    '催泪喷射器 CL-200': ['CL-200/50ml', 'CL-200/100ml'],
    '催泪弹 CD-100': ['CD-100/训练型'],
  }
  const data: StockItem[] = []
  let id = 1
  categories.forEach(cat => {
    const catNames = names[cat] || []
    catNames.forEach(name => {
      const nameSpecs = specs[name] || ['标准型']
      nameSpecs.forEach(spec => {
        warehouses.forEach(wh => {
          const available = Math.floor(Math.random() * 80) + 10
          const repair = Math.floor(Math.random() * 15)
          const scrap = Math.floor(Math.random() * 8)
          const jdx = (warehouses.indexOf(wh) + id) % jurisdictions.length
          data.push({
            id: `EQ${String(id).padStart(5, '0')}`,
            warehouse: wh,
            jurisdiction: jurisdictions[jdx],
            category: cat,
            name,
            spec,
            available,
            repair,
            scrap,
            safetyThreshold: Math.floor(Math.random() * 30) + 15,
          })
          id++
        })
      })
    })
  })
  return data
}

const allData = generateData()

function toExcelBytes(rows: string[][]): Uint8Array {
  const esc = (v: string) => v.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
  let xml = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?>'
  xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet">'
  xml += '<Worksheet Name="库存统计"><Table>'
  rows.forEach(row => {
    xml += '<Row>' + row.map(c => `<Cell><Data ss:Type="String">${esc(c)}</Data></Cell>`).join('') + '</Row>'
  })
  xml += '</Table></Worksheet></Workbook>'
  return new Uint8Array([0xEF, 0xBB, 0xBF, ...new TextEncoder().encode(xml)])
}

const dimensionLabels: Record<Dimension, string> = {
  category: '装备类别',
  spec: '规格型号',
  name: '装备名称',
  warehouse: '仓库',
}

const statusLabels = {
  available: { label: '可用', color: '#52c41a' },
  repair: { label: '待修', color: '#faad14' },
  scrap: { label: '待报废', color: '#ff4d4f' },
}

export default function StockStatsPage({ onNavigate }: Props) {
  const [dimension, setDimension] = useState<Dimension>('category')
  const [scope, setScope] = useState('jurisdiction')
  const [selectedWarehouse, setSelectedWarehouse] = useState('all')
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('all')
  const [chartType, setChartType] = useState<ChartType>('stack')
  const [searchKeyword, setSearchKeyword] = useState('')
  const [showExportDropdown, setShowExportDropdown] = useState(false)

  const filtered = useMemo(() => {
    return allData.filter(d => {
      if (scope === 'warehouse' && selectedWarehouse !== 'all' && d.warehouse !== selectedWarehouse) return false
      if (scope === 'jurisdiction' && selectedWarehouse !== 'all' && d.jurisdiction !== selectedWarehouse) return false
      if (statusFilter !== 'all') {
        const val = d[statusFilter]
        if (val === 0) return false
      }
      if (searchKeyword) {
        const kw = searchKeyword.toLowerCase()
        return d.name.toLowerCase().includes(kw) || d.category.includes(kw) || d.spec.toLowerCase().includes(kw) || d.warehouse.includes(kw)
      }
      return true
    })
  }, [scope, selectedWarehouse, statusFilter, searchKeyword])

  // Aggregated data by dimension
  const aggData = useMemo(() => {
    const map = new Map<string, { key: string; available: number; repair: number; scrap: number }>()
    filtered.forEach(d => {
      const key = dimension === 'category' ? d.category : dimension === 'name' ? d.name : dimension === 'spec' ? d.spec : d.warehouse
      const existing = map.get(key)
      if (existing) {
        existing.available += d.available
        existing.repair += d.repair
        existing.scrap += d.scrap
      } else {
        map.set(key, { key, available: d.available, repair: d.repair, scrap: d.scrap })
      }
    })
    return Array.from(map.values()).sort((a, b) => (b.available + b.repair + b.scrap) - (a.available + a.repair + a.scrap))
  }, [filtered, dimension])

  const grandTotal = useMemo(() => filtered.reduce((s, d) => s + d.available + d.repair + d.scrap, 0), [filtered])
  const grandAvailable = useMemo(() => filtered.reduce((s, d) => s + d.available, 0), [filtered])
  const grandRepair = useMemo(() => filtered.reduce((s, d) => s + d.repair, 0), [filtered])
  const grandScrap = useMemo(() => filtered.reduce((s, d) => s + d.scrap, 0), [filtered])

  // ECharts options
  const stackBarOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['可用', '待修', '待报废'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', top: '8%', containLabel: true },
    xAxis: { type: 'category', data: aggData.map(d => d.key), axisLabel: { rotate: dimension === 'spec' ? 30 : 0, fontSize: 11 }, axisTick: { alignWithLabel: true } },
    yAxis: { type: 'value', name: '数量', nameTextStyle: { fontSize: 11 } },
    series: [
      { name: '可用', type: 'bar', stack: 'total', data: aggData.map(d => d.available), itemStyle: { color: '#52c41a' }, barMaxWidth: 40 },
      { name: '待修', type: 'bar', stack: 'total', data: aggData.map(d => d.repair), itemStyle: { color: '#faad14' }, barMaxWidth: 40 },
      { name: '待报废', type: 'bar', stack: 'total', data: aggData.map(d => d.scrap), itemStyle: { color: '#ff4d4f' }, barMaxWidth: 40 },
    ],
  }), [aggData, dimension])

  const barOption = useMemo(() => ({
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    legend: { data: ['可用', '待修', '待报废'], bottom: 0 },
    grid: { left: '3%', right: '4%', bottom: '12%', top: '8%', containLabel: true },
    xAxis: { type: 'category', data: aggData.map(d => d.key), axisLabel: { rotate: dimension === 'spec' ? 30 : 0, fontSize: 11 }, axisTick: { alignWithLabel: true } },
    yAxis: { type: 'value', name: '数量', nameTextStyle: { fontSize: 11 } },
    series: [
      { name: '可用', type: 'bar', data: aggData.map(d => d.available), itemStyle: { color: '#52c41a' }, barMaxWidth: 24 },
      { name: '待修', type: 'bar', data: aggData.map(d => d.repair), itemStyle: { color: '#faad14' }, barMaxWidth: 24 },
      { name: '待报废', type: 'bar', data: aggData.map(d => d.scrap), itemStyle: { color: '#ff4d4f' }, barMaxWidth: 24 },
    ],
  }), [aggData, dimension])

  const pieOption = useMemo(() => {
    const pieData = aggData.map(d => ({
      name: d.key,
      value: d.available + d.repair + d.scrap,
      available: d.available,
      repair: d.repair,
      scrap: d.scrap,
    }))
    return {
      tooltip: {
        trigger: 'item',
        formatter: (p: any) => {
          const d = pieData[p.dataIndex]
          return `${d.name}<br/>总数: ${d.value}<br/>可用: ${d.available}<br/>待修: ${d.repair}<br/>待报废: ${d.scrap}`
        },
      },
      legend: { type: 'scroll', orient: 'vertical', right: 10, top: 20, bottom: 20, textStyle: { fontSize: 11 } },
      series: [{
        type: 'pie', radius: ['40%', '70%'], center: ['35%', '50%'],
        avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
        label: { show: false }, emphasis: { label: { show: true, fontSize: 13, fontWeight: 'bold' } },
        data: pieData,
      }],
    }
  }, [aggData])

  const exportExcel = (type: 'summary' | 'detail') => {
    const dateStr = new Date().toLocaleString('zh-CN', { hour12: false })
    if (type === 'summary') {
      const rows = [
        ['库存统计报表'], [`导出时间: ${dateStr}`], [`管辖范围: ${scope === 'jurisdiction' ? '默认管辖范围' : selectedWarehouse === 'all' ? '全部仓库' : selectedWarehouse}`], [`统计维度: ${dimensionLabels[dimension]}`], [],
        ['维度值', '可用数量', '待修数量', '待报废数量', '合计'],
        ...aggData.map(d => [d.key, String(d.available), String(d.repair), String(d.scrap), String(d.available + d.repair + d.scrap)]),
        [], ['汇总', String(grandAvailable), String(grandRepair), String(grandScrap), String(grandTotal)],
      ]
      const bytes = toExcelBytes(rows)
      const blob = new Blob([new Uint8Array(bytes)])
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `库存统计汇总_${new Date().toISOString().slice(0, 10)}.xls`
      a.click()
    } else {
      const rows = [
        ['库存明细报表'], [`导出时间: ${dateStr}`], [`管辖范围: ${scope === 'jurisdiction' ? '默认管辖范围' : selectedWarehouse === 'all' ? '全部仓库' : selectedWarehouse}`], [`统计维度: ${dimensionLabels[dimension]}`], [],
        ['装备编码', '管辖范围', '仓库', '装备类别', '装备名称', '规格型号', '可用数量', '待修数量', '待报废数量', '合计', '安全库存'],
        ...filtered.map(d => [d.id, d.jurisdiction, d.warehouse, d.category, d.name, d.spec, String(d.available), String(d.repair), String(d.scrap), String(d.available + d.repair + d.scrap), String(d.safetyThreshold)]),
      ]
      const bytes = toExcelBytes(rows)
      const blob = new Blob([new Uint8Array(bytes)])
      const a = document.createElement('a')
      a.href = URL.createObjectURL(blob)
      a.download = `库存统计明细_${new Date().toISOString().slice(0, 10)}.xls`
      a.click()
    }
    setShowExportDropdown(false)
  }

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm pb-1">
          <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
          </button>
          <span style={{ color: 'var(--text-disabled)' }}>/</span>
          <span style={{ color: 'var(--text-secondary)' }}>库存统计</span>
        </div>
        <div className="relative">
          <button className="btn-primary flex items-center gap-1 text-xs" onClick={() => setShowExportDropdown(!showExportDropdown)}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/></svg>
            导出结果
          </button>
          {showExportDropdown && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setShowExportDropdown(false)} />
              <div className="absolute right-0 top-full mt-1 bg-white border rounded-lg shadow-lg z-50 py-1 min-w-[140px]">
                <button className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50" onClick={() => exportExcel('summary')}>导出统计汇总</button>
                <button className="w-full text-left px-4 py-2 text-sm hover:bg-gray-50" onClick={() => exportExcel('detail')}>导出明细数据</button>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Search / Filter area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>管辖范围</label>
            <select className="form-input w-32" value={scope} onChange={e => { setScope(e.target.value); setSelectedWarehouse('all') }}>
              <option value="jurisdiction">默认管辖范围</option>
              <option value="warehouse">指定仓库</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{scope === 'jurisdiction' ? '管辖单位' : '选择仓库'}</label>
            <select className="form-input w-36" value={selectedWarehouse} onChange={e => setSelectedWarehouse(e.target.value)}>
              <option value="all">全部</option>
              {(scope === 'jurisdiction' ? jurisdictions : warehouses).map(w => (
                <option key={w} value={w}>{w}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>统计维度</label>
            <select className="form-input w-28" value={dimension} onChange={e => setDimension(e.target.value as Dimension)}>
              <option value="category">装备类别</option>
              <option value="name">装备名称</option>
              <option value="spec">规格型号</option>
              <option value="warehouse">所属仓库</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态筛选</label>
            <select className="form-input w-24" value={statusFilter} onChange={e => setStatusFilter(e.target.value as StatusFilter)}>
              <option value="all">全部状态</option>
              <option value="available">仅可用</option>
              <option value="repair">仅待修</option>
              <option value="scrap">仅待报废</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关键词</label>
            <input className="form-input w-32" placeholder="名称/类别/规格" value={searchKeyword} onChange={e => setSearchKeyword(e.target.value)} />
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default" onClick={() => { setScope('jurisdiction'); setSelectedWarehouse('all'); setDimension('category'); setStatusFilter('all'); setSearchKeyword('') }}>重置</button>
            <button className="btn-primary">统计</button>
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: '库存总数', value: grandTotal, color: '#1890ff', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
          { label: '可用', value: grandAvailable, color: '#52c41a', icon: 'M5 13l4 4L19 7' },
          { label: '待修', value: grandRepair, color: '#faad14', icon: 'M12 6v6m0 0v6m0-6h6m-6 0H6' },
          { label: '待报废', value: grandScrap, color: '#ff4d4f', icon: 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2"><path d={card.icon}/></svg>
            </div>
            <div>
              <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-2xl font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Chart area */}
      <div className="content-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">按{dimensionLabels[dimension]}库存分布</h3>
          <div className="flex items-center gap-1 bg-gray-100 rounded-lg p-0.5">
            {[
              { key: 'stack', label: '堆叠图' },
              { key: 'bar', label: '分组图' },
              { key: 'pie', label: '饼图' },
            ].map(t => (
              <button key={t.key} onClick={() => setChartType(t.key as ChartType)}
                className={`px-3 py-1 text-xs rounded-md transition-all ${chartType === t.key ? 'bg-white shadow-sm font-medium' : 'hover:text-gray-700'}`}
                style={{ color: chartType === t.key ? 'var(--primary-blue)' : 'var(--text-secondary)' }}
              >{t.label}</button>
            ))}
          </div>
        </div>
        <ReactEChartsCore
          option={chartType === 'pie' ? pieOption : chartType === 'bar' ? barOption : stackBarOption}
          style={{ height: 380 }}
          notMerge={true}
        />
      </div>

      {/* Status Distribution Pie Charts */}
      <div className="grid grid-cols-3 gap-4">
        {(Object.keys(statusLabels) as Array<keyof typeof statusLabels>).map((status, idx) => {
          const statusData = aggData.filter(d => d[status] > 0).sort((a, b) => b[status] - a[status]).slice(0, 8)
          const option = {
            tooltip: { trigger: 'item' },
            series: [{
              type: 'pie', radius: ['30%', '60%'], center: ['50%', '50%'],
              avoidLabelOverlap: true, itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
              label: { show: true, fontSize: 10, formatter: '{b}\n{c}' },
              data: statusData.map(d => ({ name: d.key, value: d[status] })),
              color: idx === 0 ? ['#52c41a', '#73d13d', '#95de64', '#b7eb8f', '#d9f7be', '#f6ffed'] : idx === 1 ? ['#faad14', '#ffc53d', '#ffd666', '#ffe58f', '#fff1b8', '#fffbe6'] : ['#ff4d4f', '#ff7875', '#ffa39e', '#ffccc7', '#ffd8bf', '#fff2e8'],
            }],
          }
          return (
            <div key={status} className="content-card p-4">
              <h4 className="text-sm font-semibold mb-2 text-center" style={{ color: statusLabels[status].color }}>
                {statusLabels[status].label}数量分布
              </h4>
              <ReactEChartsCore option={option} style={{ height: 260 }} notMerge={true} />
            </div>
          )
        })}
      </div>

      {/* Data table */}
      <div className="content-card overflow-hidden">
        <div className="px-4 py-3 border-b flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
          <h3 className="font-semibold text-sm">统计明细表</h3>
          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {aggData.length} 条数据</span>
        </div>
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>序号</th>
                <th>{dimensionLabels[dimension]}</th>
                <th>可用</th>
                <th>待修</th>
                <th>待报废</th>
                <th>合计</th>
                <th>占比</th>
              </tr>
            </thead>
            <tbody>
              {aggData.map((item, i) => {
                const total = item.available + item.repair + item.scrap
                const pct = grandTotal > 0 ? ((total / grandTotal) * 100).toFixed(1) : '0.0'
                return (
                  <tr key={item.key}>
                    <td className="font-mono text-xs">{i + 1}</td>
                    <td className="font-medium text-sm">{item.key}</td>
                    <td className="font-mono text-sm" style={{ color: '#52c41a', fontWeight: 500 }}>{item.available}</td>
                    <td className="font-mono text-sm" style={{ color: '#faad14', fontWeight: 500 }}>{item.repair}</td>
                    <td className="font-mono text-sm" style={{ color: '#ff4d4f', fontWeight: 500 }}>{item.scrap}</td>
                    <td className="font-mono text-sm font-bold">{total}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-full rounded-full" style={{ width: `${pct}%`, background: '#1890ff' }} />
                        </div>
                        <span className="text-xs font-mono">{pct}%</span>
                      </div>
                    </td>
                  </tr>
                )
              })}
              <tr style={{ background: 'var(--table-header-bg)', fontWeight: 'bold' }}>
                <td colSpan={2} className="text-right pr-4">汇总</td>
                <td className="font-mono" style={{ color: '#52c41a' }}>{grandAvailable}</td>
                <td className="font-mono" style={{ color: '#faad14' }}>{grandRepair}</td>
                <td className="font-mono" style={{ color: '#ff4d4f' }}>{grandScrap}</td>
                <td className="font-mono">{grandTotal}</td>
                <td>100%</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
