import { useState } from 'react'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

// ===== 库存装备数据源（与入库管理一致，去掉RFID） =====
interface StockMaterial {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  unit: string
  produceDate: string
  validDate: string
  maintainPeriod: string
  price: number
  total: number
  equipCode: string
  supplier: string
  remark: string
}

const stockMaterials: StockMaterial[] = [
  { id: 'S001', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 50, unit: '台', produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', price: 2800, total: 140000, equipCode: '1-0-1-01-P001-001', supplier: '华为技术有限公司', remark: '期初盘点' },
  { id: 'S002', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 30, unit: '台', produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', price: 1500, total: 45000, equipCode: '1-0-1-01-P005-001', supplier: '烽火通信科技股份有限公司', remark: '' },
  { id: 'S003', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 100, unit: '台', produceDate: '2024-02-20', validDate: '2027-02-20', maintainPeriod: '6个月', price: 1800, total: 180000, equipCode: '1-0-1-01-P002-001', supplier: '海康威视数字技术股份有限公司', remark: '批量采购' },
  { id: 'S004', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 20, unit: '件', produceDate: '2024-01-10', validDate: '2029-01-10', maintainPeriod: '12个月', price: 3200, total: 64000, equipCode: '1-0-1-01-P003-001', supplier: '华为技术有限公司', remark: '从市局调拨' },
  { id: 'S005', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 15, unit: '顶', produceDate: '2024-01-15', validDate: '2028-01-15', maintainPeriod: '6个月', price: 2600, total: 39000, equipCode: '1-0-1-01-P004-001', supplier: '中兴通讯股份有限公司', remark: '任务结束归还' },
  { id: 'S006', name: '警用强光手电', category: '照明设备', spec: 'CREE T6/1000流明', qty: 40, unit: '根', produceDate: '2024-03-01', validDate: '2027-03-01', maintainPeriod: '6个月', price: 350, total: 14000, equipCode: '1-0-1-01-P006-001', supplier: '大华技术股份有限公司', remark: '派出所配发' },
  { id: 'S007', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 60, unit: '件', produceDate: '2024-09-01', validDate: '2027-09-01', maintainPeriod: '3个月', price: 45, total: 2700, equipCode: '1-0-1-01-P034-001', supplier: '大华技术股份有限公司', remark: '' },
  { id: 'S008', name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', qty: 5, unit: '辆', produceDate: '2024-11-01', validDate: '2027-11-01', maintainPeriod: '3个月', price: 28000, total: 140000, equipCode: '1-0-1-01-P046-001', supplier: '中兴通讯股份有限公司', remark: '交警中队' },
  { id: 'S009', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 20, unit: '面', produceDate: '2024-11-15', validDate: '2029-11-15', maintainPeriod: '12个月', price: 680, total: 13600, equipCode: '1-0-1-01-P047-001', supplier: '华为技术有限公司', remark: '' },
  { id: 'S010', name: '4G执法记录仪 DSJ-4G', category: '执法装备', spec: 'DSJ-4G/实时传输', qty: 60, unit: '台', produceDate: '2024-04-15', validDate: '2027-04-15', maintainPeriod: '6个月', price: 3500, total: 210000, equipCode: '1-0-1-01-P016-001', supplier: '海康威视数字技术股份有限公司', remark: '指挥中心' },
  { id: 'S011', name: '伸缩警棍 ZG-T', category: '警械', spec: 'ZG-T/钛合金', qty: 45, unit: '根', produceDate: '2024-01-08', validDate: '2029-01-08', maintainPeriod: '6个月', price: 380, total: 17100, equipCode: '1-0-1-01-P010-001', supplier: '中兴通讯股份有限公司', remark: '' },
  { id: 'S012', name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', qty: 50, unit: '个', produceDate: '2024-06-10', validDate: '2026-06-10', maintainPeriod: '6个月', price: 320, total: 16000, equipCode: '1-0-1-01-P022-001', supplier: '烽火通信科技股份有限公司', remark: '过期提醒' },
]

// ===== 状态定义 =====
type ScrapStatus = 'draft' | 'submitted' | 'approval1' | 'pending_out' | 'outed'

const statusMap: Record<ScrapStatus, { label: string; tag: string }> = {
  draft: { label: '草稿', tag: 'tag-gray' },
  submitted: { label: '已提交', tag: 'tag-blue' },
  approval1: { label: '审批1', tag: 'tag-purple' },
  pending_out: { label: '待出库', tag: 'tag-yellow' },
  outed: { label: '已出库', tag: 'tag-green' },
}

// ===== 物资明细接口（去掉RFID） =====
interface ScrapItem {
  id: string
  name: string
  category: string
  spec: string
  qty: number
  produceDate: string
  validDate: string
  maintainPeriod: string
  unit: string
  price: number
  total: number
  equipCode: string
  supplier: string
  remark: string
}

// ===== 报废记录接口 =====
interface ScrapRecord {
  id: string
  items: ScrapItem[]
  reason: string
  status: ScrapStatus
  operator: string
  applyTime: string
}

const emptyItem = (): ScrapItem => ({
  id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
  name: '', category: '', spec: '', qty: 0,
  produceDate: '', validDate: '', maintainPeriod: '',
  unit: '个', price: 0, total: 0,
  equipCode: '', supplier: '', remark: '',
})

// ===== 样例数据（5条，每种状态1条） =====
const scrapRecords: ScrapRecord[] = [
  {
    id: 'BF2024001', reason: '设备老化无法正常使用', status: 'draft', operator: '王建国', applyTime: '2024-03-15 09:30',
    items: [
      { id: '1', name: '手持终端 XT-2000', category: '通信装备', spec: 'XT-2000/黑色', qty: 3, produceDate: '2022-01-15', validDate: '2025-01-15', maintainPeriod: '3个月', unit: '台', price: 2800, total: 8400, equipCode: '1-0-1-01-P001-001', supplier: '华为技术有限公司', remark: '电池鼓包' },
      { id: '2', name: '对讲机 PD780G', category: '通信装备', spec: 'PD780G/U段', qty: 2, produceDate: '2021-06-01', validDate: '2024-06-01', maintainPeriod: '3个月', unit: '台', price: 1500, total: 3000, equipCode: '1-0-1-01-P005-001', supplier: '烽火通信科技股份有限公司', remark: '已过有效期' },
    ]
  },
  {
    id: 'BF2024002', reason: '更新换代淘汰设备', status: 'submitted', operator: '李秀英', applyTime: '2024-03-18 10:00',
    items: [
      { id: '1', name: '执法记录仪 DSJ-A7', category: '执法装备', spec: 'DSJ-A7/64G', qty: 10, produceDate: '2020-05-20', validDate: '2023-05-20', maintainPeriod: '6个月', unit: '台', price: 1800, total: 18000, equipCode: '1-0-1-01-P002-001', supplier: '海康威视数字技术股份有限公司', remark: '已停产' },
    ]
  },
  {
    id: 'BF2024003', reason: '损坏无法修复', status: 'approval1', operator: '赵志刚', applyTime: '2024-03-20 14:30',
    items: [
      { id: '1', name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级', qty: 5, produceDate: '2019-08-10', validDate: '2024-08-10', maintainPeriod: '12个月', unit: '件', price: 3200, total: 16000, equipCode: '1-0-1-01-P003-001', supplier: '华为技术有限公司', remark: '防弹层老化' },
      { id: '2', name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号', qty: 3, produceDate: '2020-03-15', validDate: '2025-03-15', maintainPeriod: '6个月', unit: '顶', price: 2600, total: 7800, equipCode: '1-0-1-01-P004-001', supplier: '中兴通讯股份有限公司', remark: '面罩碎裂' },
      { id: '3', name: '防暴盾牌 FB-P', category: '防暴装备', spec: 'FB-P/铝合金', qty: 4, produceDate: '2021-01-20', validDate: '2026-01-20', maintainPeriod: '12个月', unit: '面', price: 680, total: 2720, equipCode: '1-0-1-01-P047-001', supplier: '华为技术有限公司', remark: '变形' },
    ]
  },
  {
    id: 'BF2024004', reason: '过期药品销毁', status: 'pending_out', operator: '周丽华', applyTime: '2024-03-22 08:00',
    items: [
      { id: '1', name: '急救包 JJB-A', category: '医疗装备', spec: 'JJB-A/综合型', qty: 25, produceDate: '2022-04-10', validDate: '2024-04-10', maintainPeriod: '6个月', unit: '个', price: 320, total: 8000, equipCode: '1-0-1-01-P022-001', supplier: '烽火通信科技股份有限公司', remark: '药品全部过期' },
    ]
  },
  {
    id: 'BF2024005', reason: '车辆达到报废年限', status: 'outed', operator: '吴天明', applyTime: '2024-03-25 11:00',
    items: [
      { id: '1', name: '警用摩托车 MJ-300', category: '交通工具', spec: 'MJ-300/警用版', qty: 2, produceDate: '2018-11-01', validDate: '2023-11-01', maintainPeriod: '3个月', unit: '辆', price: 28000, total: 56000, equipCode: '1-0-1-01-P046-001', supplier: '中兴通讯股份有限公司', remark: '达到报废年限' },
      { id: '2', name: '反光背心 FG-L', category: '交通装备', spec: 'FG-L/荧光黄', qty: 30, produceDate: '2020-09-01', validDate: '2023-09-01', maintainPeriod: '3个月', unit: '件', price: 45, total: 1350, equipCode: '1-0-1-01-P034-001', supplier: '大华技术股份有限公司', remark: '反光涂层失效' },
    ]
  },
]

export default function ScrapPage({ onNavigate }: Props) {
  const [scrapList, setScrapList] = useState<ScrapRecord[]>(scrapRecords)
  const [modalOpen, setModalOpen] = useState(false)
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add')
  const [editingId, setEditingId] = useState('')
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<ScrapRecord | null>(null)

  // 库存装备弹窗
  const [stockModalOpen, setStockModalOpen] = useState(false)
  const [stockSearchName, setStockSearchName] = useState('')
  const [stockSearchCategory, setStockSearchCategory] = useState('')
  const [selectedStockItems, setSelectedStockItems] = useState<{ stock: StockMaterial; qty: number }[]>([])

  // 表单
  const [formReason, setFormReason] = useState('')
  const [formOperator, setFormOperator] = useState('')
  const [formItems, setFormItems] = useState<ScrapItem[]>([])

  const resetForm = () => {
    setFormReason('')
    setFormOperator('')
    setFormItems([])
    setEditingId('')
  }

  const openAdd = () => { resetForm(); setModalMode('add'); setModalOpen(true) }

  const openEdit = (r: ScrapRecord) => {
    setFormReason(r.reason)
    setFormOperator(r.operator)
    setFormItems(r.items.map(i => ({ ...i })))
    setEditingId(r.id)
    setModalMode('edit')
    setModalOpen(true)
  }

  // 库存弹窗操作
  const openStockModal = () => {
    setStockSearchName('')
    setStockSearchCategory('')
    setSelectedStockItems([])
    setStockModalOpen(true)
  }

  const filteredStock = stockMaterials.filter(s => {
    if (stockSearchName && !s.name.includes(stockSearchName)) return false
    if (stockSearchCategory && !s.category.includes(stockSearchCategory)) return false
    return true
  })

  const toggleStockSelect = (stock: StockMaterial) => {
    setSelectedStockItems(prev => {
      const exists = prev.find(p => p.stock.id === stock.id)
      if (exists) return prev.filter(p => p.stock.id !== stock.id)
      return [...prev, { stock, qty: 1 }]
    })
  }

  const updateSelectedQty = (stockId: string, newQty: number) => {
    const stock = stockMaterials.find(s => s.id === stockId)
    if (stock && newQty > stock.qty) { alert('申请数量不能超过库存余量'); return }
    setSelectedStockItems(prev => prev.map(p => p.stock.id === stockId ? { ...p, qty: Math.max(1, newQty) } : p))
  }

  const confirmStockItems = () => {
    const newItems: ScrapItem[] = selectedStockItems.map(s => ({
      id: Date.now().toString() + Math.random().toString(36).slice(2, 6),
      name: s.stock.name, category: s.stock.category, spec: s.stock.spec,
      qty: s.qty, produceDate: s.stock.produceDate, validDate: s.stock.validDate,
      maintainPeriod: s.stock.maintainPeriod, unit: s.stock.unit,
      price: s.stock.price, total: s.stock.price * s.qty,
      equipCode: s.stock.equipCode, supplier: s.stock.supplier, remark: s.stock.remark,
    }))
    setFormItems(prev => [...prev, ...newItems])
    setStockModalOpen(false)
    setSelectedStockItems([])
  }

  const removeItem = (idx: number) => setFormItems(prev => prev.filter((_, i) => i !== idx))
  const updateItemQty = (idx: number, newQty: number) => {
    setFormItems(prev => prev.map((item, i) => i !== idx ? item : { ...item, qty: newQty, total: newQty * item.price }))
  }

  const validateForm = () => {
    if (!formReason) { alert('请填写报废原因'); return false }
    if (formItems.length === 0) { alert('请至少添加一件物资'); return false }
    if (formItems.some(i => !i.name || !i.qty)) { alert('请完善物资明细'); return false }
    return true
  }

  const handleSaveDraft = () => {
    if (!formReason) { alert('请填写报废原因'); return }
    const newId = `BF2024${String(scrapList.length + 1).padStart(3, '0')}`
    const record: ScrapRecord = {
      id: newId, reason: formReason, operator: formOperator || '当前用户',
      items: formItems.map(i => ({ ...i, total: i.qty * i.price })),
      status: 'draft', applyTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    if (modalMode === 'edit' && editingId) {
      setScrapList(prev => prev.map(s => s.id === editingId ? { ...record, id: editingId, status: prev.find(x => x.id === editingId)?.status || 'draft' } : s))
    } else {
      setScrapList(prev => [record, ...prev])
    }
    setModalOpen(false)
    resetForm()
    alert('已保存为草稿')
  }

  const handleSubmit = () => {
    if (!validateForm()) return
    const newId = `BF2024${String(scrapList.length + 1).padStart(3, '0')}`
    const record: ScrapRecord = {
      id: newId, reason: formReason, operator: formOperator || '当前用户',
      items: formItems.map(i => ({ ...i, total: i.qty * i.price })),
      status: 'submitted', applyTime: new Date().toLocaleString('zh-CN', { hour12: false }),
    }
    if (modalMode === 'edit' && editingId) {
      setScrapList(prev => prev.map(s => s.id === editingId ? { ...record, id: editingId } : s))
    } else {
      setScrapList(prev => [record, ...prev])
    }
    setModalOpen(false)
    resetForm()
    alert('提交成功')
  }

  const handleDelete = (r: ScrapRecord) => { setScrapList(prev => prev.filter(x => x.id !== r.id)); alert('删除成功') }
  const handleWithdraw = (r: ScrapRecord) => { setScrapList(prev => prev.map(x => x.id === r.id ? { ...x, status: 'draft' as ScrapStatus } : x)); alert('已撤回为草稿') }

  const categoryOptions = Array.from(new Set(stockMaterials.map(s => s.category)))

  const renderActions = (r: ScrapRecord) => {
    const buttons: any[] = []
    buttons.push(<button key="detail" className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedRecord(r); setDetailOpen(true) }}>详情</button>)
    if (r.status === 'draft') {
      buttons.push(<button key="edit" className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openEdit(r)}>修改</button>)
      buttons.push(<button key="del" className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => { if (confirm(`删除 ${r.id}？`)) handleDelete(r) }}>删除</button>)
    }
    if (r.status === 'submitted') {
      buttons.push(<button key="withdraw" className="text-xs hover:underline" style={{ color: '#faad14' }} onClick={() => handleWithdraw(r)}>撤回</button>)
    }
    return <div className="flex items-center gap-2 flex-wrap">{buttons}</div>
  }

  return (
    <div className="p-6 space-y-4">
      {/* 面包屑 */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>装备管理</span>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>报废管理</span>
      </div>

      {/* 操作按钮（去掉统计） */}
      <div className="flex items-center justify-between">
        <button className="btn-primary flex items-center gap-1" onClick={openAdd}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          发起报废
        </button>
        <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {scrapList.length} 条记录</span>
      </div>

      {/* 搜索 */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废单号</label><input className="form-input w-36" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label><input className="form-input w-28" placeholder="请输入..." /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option>{Object.entries(statusMap).map(([k, v]) => <option key={k}>{v.label}</option>)}</select></div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* 数据表格 */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>报废单号</th>
              <th>物资清单</th>
              <th>报废原因</th>
              <th>经办人</th>
              <th>申请时间</th>
              <th>状态</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {scrapList.map(r => (
              <tr key={r.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td>
                  <div className="flex flex-col gap-0.5">
                    {r.items.slice(0, 2).map((item, i) => (
                      <span key={i} className="text-xs truncate max-w-[180px]">{item.name} x{item.qty}</span>
                    ))}
                    {r.items.length > 2 && <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>+{r.items.length - 2} 种</span>}
                  </div>
                </td>
                <td className="text-xs max-w-[200px] truncate">{r.reason}</td>
                <td className="text-xs">{r.operator}</td>
                <td className="text-xs">{r.applyTime}</td>
                <td><span className={`tag text-xs ${statusMap[r.status].tag}`}>{statusMap[r.status].label}</span></td>
                <td>{renderActions(r)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== 发起报废弹窗 ===== */}
      {modalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[95vw] max-w-[1100px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{modalMode === 'add' ? '发起报废' : '编辑报废申请'}</h3>
              <button onClick={() => setModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="p-6 space-y-5 overflow-y-auto flex-1">
              <div className="content-card p-4 border-l-4" style={{ borderColor: '#52c41a' }}>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#52c41a' }}>基本信息</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废单字号 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full font-mono text-xs bg-gray-50" readOnly value={modalMode === 'edit' ? editingId : `BF2024${String(scrapList.length + 1).padStart(3, '0')}`} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废原因 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full" placeholder="请输入报废原因" value={formReason} onChange={e => setFormReason(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人 <span style={{ color: 'var(--text-disabled)' }}>#</span></label>
                    <input className="form-input w-full" placeholder="请输入经办人" value={formOperator} onChange={e => setFormOperator(e.target.value)} />
                  </div>
                </div>
              </div>

              <div className="content-card p-4 border-l-4" style={{ borderColor: '#faad14' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-sm font-semibold" style={{ color: '#faad14' }}>物资明细 <span className="text-red-400">*</span> <span style={{ color: 'var(--text-secondary)' }}>({formItems.length} 种)</span></h4>
                  <button onClick={openStockModal} className="text-xs px-3 py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors">+ 添加物资</button>
                </div>

                {formItems.length === 0 ? (
                  <div className="text-center py-8 border-2 border-dashed rounded-lg" style={{ borderColor: 'var(--border-color)', color: 'var(--text-disabled)' }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
                    <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                      <thead>
                        <tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="border p-2 w-8">#</th>
                          <th className="border p-2 w-28">物资名称 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-20">物资类别(二级) <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20">规格型号 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-12">数量 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-18">生产日期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-18">有效期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-14">保养期 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-14">单位 <span className="text-red-400">*</span></th>
                          <th className="border p-2 w-16">单价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16">总价 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-22">装备编码 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-20">供应商 <span style={{ color: 'var(--text-disabled)' }}>#</span></th>
                          <th className="border p-2 w-16">备注</th>
                          <th className="border p-2 w-8">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {formItems.map((item, idx) => (
                          <tr key={item.id}>
                            <td className="border p-2 text-center font-mono">{idx + 1}</td>
                            <td className="border p-2">{item.name}</td>
                            <td className="border p-2">{item.category || '-'}</td>
                            <td className="border p-2">{item.spec || '-'}</td>
                            <td className="border p-1"><input className="w-full text-xs p-1 outline-none bg-transparent text-center font-mono" type="number" min={1} value={item.qty} onChange={e => updateItemQty(idx, Number(e.target.value))} /></td>
                            <td className="border p-2 text-xs">{item.produceDate || '-'}</td>
                            <td className="border p-2 text-xs">{item.validDate || '-'}</td>
                            <td className="border p-2 text-xs">{item.maintainPeriod || '-'}</td>
                            <td className="border p-2 text-center">{item.unit}</td>
                            <td className="border p-2 text-right font-mono">¥{item.price?.toLocaleString()}</td>
                            <td className="border p-2 text-right font-mono font-medium">¥{item.total.toLocaleString()}</td>
                            <td className="border p-2 font-mono text-xs">{item.equipCode || '-'}</td>
                            <td className="border p-2 text-xs">{item.supplier || '-'}</td>
                            <td className="border p-2 text-xs">{item.remark || '-'}</td>
                            <td className="border p-1 text-center">
                              <button onClick={() => removeItem(idx)} className="text-red-400 hover:text-red-600">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}

                {formItems.length > 0 && (
                  <div className="mt-3 flex items-center justify-end gap-4">
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>合计品种：{formItems.length} 种</span>
                    <span className="text-sm font-mono font-bold">合计金额：¥{formItems.reduce((s, m) => s + m.total, 0).toLocaleString()}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setModalOpen(false)}>取消</button>
              <button className="btn-default" onClick={handleSaveDraft}>保存草稿</button>
              <button className="btn-primary" onClick={handleSubmit}>提交</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 库存装备选择弹窗 ===== */}
      {stockModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStockModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[75vw] h-[100dvh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">库存装备信息</h3>
              <button onClick={() => setStockModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            <div className="px-6 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <div className="flex flex-wrap items-end gap-3">
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称</label><input className="form-input w-28" placeholder="模糊搜索" value={stockSearchName} onChange={e => setStockSearchName(e.target.value)} /></div>
                <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资类别</label><select className="form-input w-28" value={stockSearchCategory} onChange={e => setStockSearchCategory(e.target.value)}><option value="">全部</option>{categoryOptions.map(c => <option key={c}>{c}</option>)}</select></div>
                <div className="flex gap-2 ml-auto">
                  <button className="btn-default text-xs" onClick={() => { setStockSearchName(''); setStockSearchCategory('') }}>重置</button>
                  <button className="btn-primary text-xs">查询</button>
                </div>
              </div>
            </div>

            <div className="flex flex-1 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-4 border-r" style={{ borderColor: 'var(--border-color)' }}>
                <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                  <thead>
                    <tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="border p-2 w-8"><input type="checkbox" disabled /></th>
                      <th className="border p-2">物资名称</th>
                      <th className="border p-2">物资类别</th>
                      <th className="border p-2">规格型号</th>
                      <th className="border p-2">生产日期</th>
                      <th className="border p-2">有效期</th>
                      <th className="border p-2">保养期</th>
                      <th className="border p-2">剩余数量</th>
                      <th className="border p-2">单位</th>
                      <th className="border p-2">单价</th>
                      <th className="border p-2">总价</th>
                      <th className="border p-2">装备编码</th>
                      <th className="border p-2">供应商</th>
                      <th className="border p-2">备注</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredStock.map(s => {
                      const isSelected = selectedStockItems.some(p => p.stock.id === s.id)
                      return (
                        <tr key={s.id} className={`cursor-pointer transition-colors ${isSelected ? 'bg-blue-50' : 'hover:bg-gray-50'}`} onClick={() => toggleStockSelect(s)}>
                          <td className="border p-2 text-center"><input type="checkbox" checked={isSelected} readOnly /></td>
                          <td className="border p-2 font-medium">{s.name}</td>
                          <td className="border p-2">{s.category}</td>
                          <td className="border p-2">{s.spec || '-'}</td>
                          <td className="border p-2">{s.produceDate || '-'}</td>
                          <td className="border p-2">{s.validDate || '-'}</td>
                          <td className="border p-2">{s.maintainPeriod || '-'}</td>
                          <td className="border p-2 text-center font-mono">{s.qty}</td>
                          <td className="border p-2 text-center">{s.unit}</td>
                          <td className="border p-2 text-right font-mono">¥{s.price.toLocaleString()}</td>
                          <td className="border p-2 text-right font-mono">¥{s.total.toLocaleString()}</td>
                          <td className="border p-2 font-mono text-xs">{s.equipCode}</td>
                          <td className="border p-2">{s.supplier}</td>
                          <td className="border p-2">{s.remark || '-'}</td>
                        </tr>
                      )
                    })}
                    {filteredStock.length === 0 && <tr><td colSpan={14} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无匹配数据</td></tr>}
                  </tbody>
                </table>
              </div>

              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>已选择装备 ({selectedStockItems.length})</div>
                <div className="flex-1 overflow-y-auto p-3">
                  {selectedStockItems.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}><p className="text-xs">请点击左侧装备添加</p></div>
                  ) : (
                    <div className="space-y-2">
                      {selectedStockItems.map(s => (
                        <div key={s.stock.id} className="border rounded-lg p-2" style={{ borderColor: 'var(--border-color)' }}>
                          <div className="text-xs font-medium mb-1 truncate">{s.stock.name}</div>
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>余量: {s.stock.qty}</span>
                            <div className="flex items-center gap-1">
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty - 1)}>-</button>
                              <input className="w-10 text-xs text-center border rounded py-0.5 font-mono" type="number" min={1} max={s.stock.qty} value={s.qty} onChange={e => updateSelectedQty(s.stock.id, Number(e.target.value))} />
                              <button className="w-5 h-5 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => updateSelectedQty(s.stock.id, s.qty + 1)}>+</button>
                            </div>
                            <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedStockItems(prev => prev.filter(p => p.stock.id !== s.stock.id))}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setStockModalOpen(false)}>关闭</button>
              <button className="btn-primary" onClick={confirmStockItems} disabled={selectedStockItems.length === 0}>确定</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== 详情抽屉 ===== */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative w-[520px] bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="font-semibold text-base">报废详情</h3>
              <button className="p-1 rounded hover:bg-gray-100" onClick={() => setDetailOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#1890ff' }}>基本信息</h4>
                <div className="space-y-2">
                  {[
                    { label: '报废单号', value: selectedRecord.id },
                    { label: '报废原因', value: selectedRecord.reason },
                    { label: '经办人', value: selectedRecord.operator },
                    { label: '申请时间', value: selectedRecord.applyTime },
                    { label: '状态', value: statusMap[selectedRecord.status].label },
                  ].map(f => (
                    <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                      <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className="font-medium text-sm">{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-sm font-semibold mb-3" style={{ color: '#faad14' }}>物资明细（{selectedRecord.items.length} 种）</h4>
                {selectedRecord.items.map((m, i) => (
                  <div key={m.id} className="border rounded-lg p-3 mb-2" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="text-xs font-medium mb-2">#{i + 1} {m.name}</div>
                    <div className="grid grid-cols-2 gap-y-1 gap-x-4 text-xs">
                      <span style={{ color: 'var(--text-secondary)' }}>物资类别：<span className="text-gray-900">{m.category || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>规格型号：<span className="text-gray-900">{m.spec || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>数量：<span className="text-gray-900">{m.qty} {m.unit}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>生产日期：<span className="text-gray-900">{m.produceDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>有效期：<span className="text-gray-900">{m.validDate || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>保养期：<span className="text-gray-900">{m.maintainPeriod || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>单价：<span className="text-gray-900 font-mono">¥{m.price?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>总价：<span className="text-gray-900 font-mono font-medium">¥{m.total?.toLocaleString()}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>装备编码：<span className="text-gray-900 font-mono">{m.equipCode || '-'}</span></span>
                      <span style={{ color: 'var(--text-secondary)' }}>供应商：<span className="text-gray-900">{m.supplier || '-'}</span></span>
                      {m.remark && <span className="col-span-2" style={{ color: 'var(--text-secondary)' }}>备注：<span className="text-gray-900">{m.remark}</span></span>}
                    </div>
                  </div>
                ))}
                <div className="text-right text-sm font-mono font-bold mt-2">
                  合计金额：¥{selectedRecord.items.reduce((s, m) => s + m.total, 0).toLocaleString()}
                </div>
              </div>
            </div>
            <div className="p-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
