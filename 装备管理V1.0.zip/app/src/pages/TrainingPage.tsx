import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
}

const tabList = [
  { key: 'dashboard', label: '工作台' },
  { key: 'material', label: '培训资料' },
  { key: 'process', label: '培训过程' },
  { key: 'expert', label: '专家库' },
  { key: 'forum', label: '交流互动' },
]

// ========== 培训资料 ==========
interface Material {
  id: number
  title: string
  type: 'video' | 'doc' | 'ppt' | 'quiz'
  version: string
  target: string
  size: string
  uploadTime: string
}

// ========== 培训过程 ==========
interface Expert {
  id: string
  name: string
  field: string
  level: string
  phone: string
}

interface Trainee {
  name: string
  dept: string
  checkIn: boolean
}

interface TrainingPlan {
  id: string
  course: string
  instructor: string
  expertId?: string
  trainees: Trainee[]
  startTime: string
  endTime: string
  location: string
  status: 'pending' | 'active' | 'evaluating' | 'done'
  questionnaire: { question: string; avgScore: number }[]
  archiveNo?: string
}

// ========== 交流互动 ==========
interface ForumPost {
  id: string
  title: string
  author: string
  date: string
  category: 'question' | 'suggestion' | 'experience'
  replies: { author: string; date: string; content: string }[]
  views: number
  pinned: boolean
  solved: boolean
}

export default function TrainingPage({ activeSubTab }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'dashboard')
  useEffect(() => {
    setActiveTab(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'dashboard')
  }, [activeSubTab])

  // ===== 培训资料 states =====
  const [materials, setMaterials] = useState<Material[]>([
    { id: 1, title: '手持终端操作指南', type: 'video', version: 'v2.1', target: '手持终端', size: '156MB', uploadTime: '2024-03-01' },
    { id: 2, title: '应急照明灯维护手册', type: 'doc', version: 'v1.3', target: '照明设备', size: '8.5MB', uploadTime: '2024-02-15' },
    { id: 3, title: '对讲机使用培训PPT', type: 'ppt', version: 'v1.0', target: '对讲机', size: '24MB', uploadTime: '2024-03-10' },
    { id: 4, title: '装备保养知识题库', type: 'quiz', version: 'v3.0', target: '通用', size: '2.1MB', uploadTime: '2024-01-20' },
  ])
  const [matFilter, setMatFilter] = useState('all')
  const [uploadOpen, setUploadOpen] = useState(false)
  const [editMat, setEditMat] = useState<Material | null>(null)
  const [editOpen, setEditOpen] = useState(false)
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null)
  const [uploadForm, setUploadForm] = useState({ title: '', type: 'doc' as Material['type'], version: '', target: '' })

  // ===== 培训过程 states =====
  const [plans, setPlans] = useState<TrainingPlan[]>([
    {
      id: 'P001', course: '手持终端操作培训', instructor: '张工', startTime: '2024-03-20 09:00', endTime: '2024-03-20 17:00',
      location: '培训中心A301', status: 'pending',
      trainees: [
        { name: '王五', dept: '一支队', checkIn: false },
        { name: '赵六', dept: '一支队', checkIn: false },
        { name: '孙七', dept: '二支队', checkIn: false },
      ],
      questionnaire: []
    },
    {
      id: 'P002', course: '应急照明设备维护', instructor: '李工', startTime: '2024-03-15 09:00', endTime: '2024-03-15 12:00',
      location: '培训中心B201', status: 'active',
      trainees: [
        { name: '周八', dept: '三支队', checkIn: true },
        { name: '吴九', dept: '三支队', checkIn: true },
        { name: '郑十', dept: '四支队', checkIn: false },
      ],
      questionnaire: []
    },
    {
      id: 'P003', course: '对讲机使用与保养', instructor: '王工', startTime: '2024-03-10 14:00', endTime: '2024-03-10 16:00',
      location: '培训中心A302', status: 'evaluating',
      trainees: [
        { name: '陈一', dept: '五支队', checkIn: true },
        { name: '刘二', dept: '五支队', checkIn: true },
        { name: '黄三', dept: '六支队', checkIn: true },
      ],
      questionnaire: [
        { question: '课程内容实用性', avgScore: 4.5 },
        { question: '讲师授课水平', avgScore: 4.7 },
        { question: '培训组织安排', avgScore: 4.3 },
      ]
    },
    {
      id: 'P004', course: '监控摄像头安装调试', instructor: '赵工', startTime: '2024-02-28 09:00', endTime: '2024-02-28 17:00',
      location: '培训中心B101', status: 'done',
      trainees: [
        { name: '林四', dept: '七支队', checkIn: true },
        { name: '何五', dept: '七支队', checkIn: true },
      ],
      questionnaire: [
        { question: '课程内容实用性', avgScore: 4.8 },
        { question: '讲师授课水平', avgScore: 4.6 },
        { question: '培训组织安排', avgScore: 4.5 },
      ],
      archiveNo: 'GD-2024-004'
    },
  ])
  const [experts, setExperts] = useState<Expert[]>([
    { id: 'E001', name: '张工', field: '手持终端/对讲机', level: '高级', phone: '13800138001' },
    { id: 'E002', name: '李工', field: '应急照明/监控', level: '高级', phone: '13800138002' },
    { id: 'E003', name: '王工', field: '通信设备', level: '中级', phone: '13800138003' },
    { id: 'E004', name: '赵工', field: '安防监控', level: '高级', phone: '13800138004' },
  ])
  const [expertSearch, setExpertSearch] = useState('')
  const [expertFormOpen, setExpertFormOpen] = useState(false)
  const [expertFormMode, setExpertFormMode] = useState<'add' | 'edit' | 'view'>('add')
  const [editingExpert, setEditingExpert] = useState<Expert | null>(null)
  const [expertForm, setExpertForm] = useState({ name: '', field: '', level: '中级', phone: '' })
  const [expertDeleteConfirm, setExpertDeleteConfirm] = useState<string | null>(null)
  const [planOpen, setPlanOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState<TrainingPlan | null>(null)
  const [planDetailOpen, setPlanDetailOpen] = useState(false)
  const [expertOpen, setExpertOpen] = useState(false)
  const [evalOpen, setEvalOpen] = useState(false)
  const [evalForm, setEvalForm] = useState({ q1: 5, q2: 5, q3: 5 })
  const [newPlanForm, setNewPlanForm] = useState({ course: '', instructor: '', location: '', startTime: '', endTime: '' })

  // ===== 交流互动 states =====
  const [forumPosts, setForumPosts] = useState<ForumPost[]>([
    { id: 'F001', title: '装备管理系统常见问题汇总（官方）', author: '管理员', date: '2024-01-10', category: 'experience', replies: [{ author: '张三', date: '2024-01-12', content: '非常实用的汇总，收藏了！' }, { author: '李四', date: '2024-01-15', content: '建议补充手持终端部分' }], views: 1230, pinned: true, solved: true },
    { id: 'F002', title: '手持终端充不进去电怎么办？', author: '张三', date: '2024-03-15', category: 'question', replies: [{ author: '管理员', date: '2024-03-16', content: '建议先检查充电器和数据线，如仍无法解决请联系维修中心。' }], views: 45, pinned: false, solved: true },
    { id: 'F003', title: '建议增加批量导入功能', author: '李四', date: '2024-03-14', category: 'suggestion', replies: [], views: 23, pinned: false, solved: false },
    { id: 'F004', title: '卫星便携站信号不稳定的原因分析', author: '王五', date: '2024-03-12', category: 'experience', replies: [{ author: '赵六', date: '2024-03-13', content: '我们这边也有类似情况，后来更新固件解决了。' }], views: 67, pinned: false, solved: false },
  ])
  const [postOpen, setPostOpen] = useState(false)
  const [suggestOpen, setSuggestOpen] = useState(false)
  const [selectedPost, setSelectedPost] = useState<ForumPost | null>(null)
  const [postDetailOpen, setPostDetailOpen] = useState(false)
  const [postForm, setPostForm] = useState({ title: '', content: '' })
  const [replyContent, setReplyContent] = useState('')

  // ===== helpers =====
  const typeIcons: Record<string, string> = { video: '#722ed1', doc: '#1890ff', ppt: '#faad14', quiz: '#52c41a' }
  const typeLabels: Record<string, string> = { video: '视频', doc: '文档', ppt: 'PPT', quiz: '题库' }
  const statusConfig = {
    pending: { label: '待执行', color: '#595959', bg: '#f5f5f5' },
    active: { label: '执行中', color: '#1890ff', bg: '#e6f7ff' },
    evaluating: { label: '评估中', color: '#faad14', bg: '#fffbe6' },
    done: { label: '已归档', color: '#52c41a', bg: '#f6ffed' },
  }

  const handleUpload = () => {
    if (!uploadForm.title) return
    const newMat: Material = {
      id: Date.now(), title: uploadForm.title, type: uploadForm.type as Material['type'],
      version: uploadForm.version || 'v1.0', target: uploadForm.target || '通用',
      size: '0MB', uploadTime: new Date().toISOString().slice(0, 10),
    }
    setMaterials(prev => [newMat, ...prev])
    setUploadOpen(false)
    setUploadForm({ title: '', type: 'doc', version: '', target: '' })
  }

  const handleEditSave = () => {
    if (!editMat) return
    setMaterials(prev => prev.map(m => m.id === editMat.id ? editMat : m))
    setEditOpen(false)
    setEditMat(null)
  }

  const handleDelete = (id: number) => {
    setMaterials(prev => prev.filter(m => m.id !== id))
    setDeleteConfirm(null)
  }

  const openPlanDetail = (plan: TrainingPlan) => {
    setSelectedPlan(plan)
    setPlanDetailOpen(true)
  }

  const handleAddPlan = () => {
    if (!newPlanForm.course || !newPlanForm.instructor) return
    const newPlan: TrainingPlan = {
      id: `P${String(Date.now()).slice(-4)}`,
      course: newPlanForm.course, instructor: newPlanForm.instructor,
      location: newPlanForm.location || '待定',
      startTime: newPlanForm.startTime || '待定', endTime: newPlanForm.endTime || '待定',
      status: 'pending', trainees: [], questionnaire: [],
    }
    setPlans(prev => [newPlan, ...prev])
    setPlanOpen(false)
    setNewPlanForm({ course: '', instructor: '', location: '', startTime: '', endTime: '' })
  }

  const toggleCheckIn = (planId: string, traineeIdx: number) => {
    setPlans(prev => prev.map(p => {
      if (p.id !== planId) return p
      const newTrainees = [...p.trainees]
      newTrainees[traineeIdx] = { ...newTrainees[traineeIdx], checkIn: !newTrainees[traineeIdx].checkIn }
      return { ...p, trainees: newTrainees }
    }))
  }



  const openExpertForm = (mode: 'add' | 'edit' | 'view', expert?: Expert) => {
    setExpertFormMode(mode)
    if (expert) {
      setEditingExpert(expert)
      setExpertForm({ name: expert.name, field: expert.field, level: expert.level, phone: expert.phone })
    } else {
      setEditingExpert(null)
      setExpertForm({ name: '', field: '', level: '中级', phone: '' })
    }
    setExpertFormOpen(true)
  }

  const saveExpert = () => {
    if (!expertForm.name || !expertForm.field) return
    if (expertFormMode === 'add') {
      const newExpert: Expert = {
        id: `E${String(Date.now()).slice(-4)}`,
        name: expertForm.name,
        field: expertForm.field,
        level: expertForm.level as '高级' | '中级',
        phone: expertForm.phone || '-',
      }
      setExperts(prev => [newExpert, ...prev])
    } else if (expertFormMode === 'edit' && editingExpert) {
      setExperts(prev => prev.map(e => e.id === editingExpert.id ? { ...e, ...expertForm, level: expertForm.level as '高级' | '中级' } : e))
    }
    setExpertFormOpen(false)
    setEditingExpert(null)
    setExpertForm({ name: '', field: '', level: '中级', phone: '' })
  }

  const deleteExpert = (id: string) => {
    setExperts(prev => prev.filter(e => e.id !== id))
    setExpertDeleteConfirm(null)
  }

  const handlePostSubmit = (category: 'question' | 'suggestion') => {
    if (!postForm.title || !postForm.content) return
    const newPost: ForumPost = {
      id: `F${Date.now()}`, title: postForm.title, author: '当前用户',
      date: new Date().toISOString().slice(0, 10), category,
      replies: [], views: 0, pinned: false, solved: false,
    }
    setForumPosts(prev => [newPost, ...prev])
    setPostOpen(false)
    setSuggestOpen(false)
    setPostForm({ title: '', content: '' })
  }

  const handleReply = () => {
    if (!replyContent || !selectedPost) return
    const newReply = { author: '当前用户', date: new Date().toISOString().slice(0, 10), content: replyContent }
    setForumPosts(prev => prev.map(p => p.id === selectedPost.id ? { ...p, replies: [...p.replies, newReply] } : p))
    setSelectedPost(prev => prev ? { ...prev, replies: [...prev.replies, newReply] } : null)
    setReplyContent('')
  }

  const openPostDetail = (post: ForumPost) => {
    setSelectedPost(post)
    setPostDetailOpen(true)
    setForumPosts(prev => prev.map(p => p.id === post.id ? { ...p, views: p.views + 1 } : p))
  }

  const filteredMaterials = matFilter === 'all' ? materials : materials.filter(m => m.type === matFilter)

  return (
    <div className="p-6 space-y-4">
      {/* ==================== 工作台 ==================== */}
      {activeTab === 'dashboard' && (
        <div className="space-y-4 animate-fade-in">
          {/* 统计卡片 */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { label: '培训资料', value: `${materials.length} 个`, color: '#1890ff', icon: 'M4 19.5A2.5 2.5 0 016.5 17H20' },
              { label: '培训课程', value: `${plans.length} 门`, color: '#52c41a', icon: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z' },
              { label: '专家人数', value: `${experts.length} 人`, color: '#722ed1', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
              { label: '交流帖子', value: `${forumPosts.length} 条`, color: '#faad14', icon: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z' },
            ].map(card => (
              <div key={card.label} className="content-card p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d={card.icon}/>
                  </svg>
                </div>
                <div>
                  <div className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                  <div className="text-lg font-bold" style={{ color: card.color }}>{card.value}</div>
                </div>
              </div>
            ))}
          </div>

          {/* 快捷入口 */}
          <div className="content-card p-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>
              快捷入口
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {[
                { key: 'material', label: '培训资料', desc: '培训资料管理', color: '#1890ff', icon: 'M4 19.5A2.5 2.5 0 016.5 17H20' },
                { key: 'process', label: '培训过程', desc: '培训课程管理', color: '#52c41a', icon: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z' },
                { key: 'expert', label: '专家库', desc: '专家信息管理', color: '#722ed1', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
                { key: 'forum', label: '交流互动', desc: '交流互动平台', color: '#faad14', icon: 'M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z' },
              ].map(item => (
                <button
                  key={item.key}
                  onClick={() => setActiveTab(item.key)}
                  className="flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left"
                  style={{ borderColor: 'var(--border-color)', background: '#fff' }}
                >
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                      <path d={item.icon}/>
                    </svg>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium">{item.label}</div>
                    <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
                  </div>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                    <polyline points="9 18 15 12 9 6"/>
                  </svg>
                </button>
              ))}
            </div>
          </div>

          {/* 最近培训资料 */}
          <div className="content-card p-4">
            <h3 className="font-semibold mb-3">最近培训资料</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {materials.slice(0, 3).map(m => (
                <div key={m.id} className="rounded-lg border p-4 hover:shadow-md transition-all" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-center h-20 rounded-lg mb-3" style={{ background: `${typeIcons[m.type]}10` }}>
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={typeIcons[m.type]} strokeWidth="1.5">
                      <path d={m.type === 'video' ? 'M23 7l-7 5 7 5V7z M2 7v10h10V7H2z' : m.type === 'ppt' ? 'M4 3h16a2 2 0 012 2v14a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2zm0 2v14h16V5H4z' : m.type === 'quiz' ? 'M9 11l3 3L22 4M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11' : 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z'}/>
                    </svg>
                  </div>
                  <h4 className="font-medium text-sm mb-1 truncate">{m.title}</h4>
                  <div className="text-xs flex items-center gap-2" style={{ color: 'var(--text-secondary)' }}>
                    <span>{typeLabels[m.type]}</span>
                    <span>{m.size}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ==================== 培训资料 ==================== */}
      {activeTab === 'material' && (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {[{ key: 'all', label: '全部' }, { key: 'video', label: '视频' }, { key: 'doc', label: '文档' }, { key: 'ppt', label: 'PPT' }, { key: 'quiz', label: '题库' }].map(f => (
                <button key={f.key} onClick={() => setMatFilter(f.key)} className="px-3 py-1.5 rounded-full text-xs border transition-all"
                  style={{ borderColor: matFilter === f.key ? '#1890ff' : 'var(--border-color)', color: matFilter === f.key ? '#1890ff' : 'inherit', background: matFilter === f.key ? '#e6f7ff' : 'transparent' }}>{f.label}</button>
              ))}
            </div>
            <button className="btn-primary flex items-center gap-1" onClick={() => setUploadOpen(true)}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>上传资料</button>
          </div>
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3 mb-4">
              <div><label className="block text-xs mb-1">标题</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1">适用装备</label><select className="form-input w-32"><option>全部</option><option>手持终端</option><option>照明设备</option><option>对讲机</option></select></div>
              <div className="flex gap-2 ml-auto"><button className="btn-default">重置</button><button className="btn-primary">查询</button></div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredMaterials.map(m => (
                <div key={m.id} className="rounded-lg border p-4 hover:shadow-md transition-all" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-center h-24 rounded-lg mb-3" style={{ background: `${typeIcons[m.type]}10` }}>
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke={typeIcons[m.type]} strokeWidth="1.5">
                      {m.type === 'video' && <><rect x="2" y="2" width="20" height="20" rx="2.18"/><polygon points="10 8 16 12 10 16 10 8"/></>}
                      {m.type === 'doc' && <><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></>}
                      {m.type === 'ppt' && <><path d="M2 3h20"/><path d="M21 3v11a2 2 0 01-2 2H5a2 2 0 01-2-2V3"/><path d="M7 21h10"/><path d="M12 16v5"/></>}
                      {m.type === 'quiz' && <><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></>}
                    </svg>
                  </div>
                  <h5 className="font-medium text-sm mb-1">{m.title}</h5>
                  <div className="flex items-center justify-between text-xs" style={{ color: 'var(--text-secondary)' }}>
                    <span>版本：{m.version}</span>
                    <span>适用：{m.target}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>
                    <span>{typeLabels[m.type]}</span>
                    <span>{m.size} · {m.uploadTime}</span>
                  </div>
                  <div className="flex items-center justify-between mt-3">
                    <div className="flex gap-2">
                      <button className="text-xs" style={{ color: 'var(--primary-blue)' }}>预览</button>
                      <button className="text-xs" style={{ color: 'var(--primary-blue)' }}>下载</button>
                    </div>
                    <div className="flex gap-2">
                      <button className="text-xs" style={{ color: '#faad14' }} onClick={() => { setEditMat(m); setEditOpen(true) }}>修改</button>
                      <button className="text-xs" style={{ color: '#ff4d4f' }} onClick={() => setDeleteConfirm(m.id)}>删除</button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Upload Modal */}
          {uploadOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setUploadOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">上传培训资料</h3>
                  <button onClick={() => setUploadOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">资料标题 <span className="text-red-400">*</span></label><input className="form-input w-full" value={uploadForm.title} onChange={e => setUploadForm({ ...uploadForm, title: e.target.value })} placeholder="请输入资料标题" /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-xs mb-1">资料类型</label><select className="form-input w-full" value={uploadForm.type} onChange={e => setUploadForm({ ...uploadForm, type: e.target.value as Material['type'] })}><option value="video">视频</option><option value="doc">文档</option><option value="ppt">PPT</option><option value="quiz">题库</option></select></div>
                    <div><label className="block text-xs mb-1">版本号</label><input className="form-input w-full" value={uploadForm.version} onChange={e => setUploadForm({ ...uploadForm, version: e.target.value })} placeholder="如 v1.0" /></div>
                  </div>
                  <div><label className="block text-xs mb-1">适用装备</label><input className="form-input w-full" value={uploadForm.target} onChange={e => setUploadForm({ ...uploadForm, target: e.target.value })} placeholder="请输入适用装备" /></div>
                  <div className="p-4 rounded-lg border-2 border-dashed text-center" style={{ borderColor: '#d9d9d9', background: '#fafafa' }}>
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>点击或拖拽文件到此处上传</p>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setUploadOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={handleUpload}>确认上传</button>
                </div>
              </div>
            </div>
          )}

          {/* Edit Modal */}
          {editOpen && editMat && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setEditOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">修改资料</h3>
                  <button onClick={() => setEditOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">资料标题</label><input className="form-input w-full" value={editMat.title} onChange={e => setEditMat({ ...editMat, title: e.target.value })} /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-xs mb-1">资料类型</label><select className="form-input w-full" value={editMat.type} onChange={e => setEditMat({ ...editMat, type: e.target.value as Material['type'] })}><option value="video">视频</option><option value="doc">文档</option><option value="ppt">PPT</option><option value="quiz">题库</option></select></div>
                    <div><label className="block text-xs mb-1">版本号</label><input className="form-input w-full" value={editMat.version} onChange={e => setEditMat({ ...editMat, version: e.target.value })} /></div>
                  </div>
                  <div><label className="block text-xs mb-1">适用装备</label><input className="form-input w-full" value={editMat.target} onChange={e => setEditMat({ ...editMat, target: e.target.value })} /></div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setEditOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={handleEditSave}>保存</button>
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirm */}
          {deleteConfirm !== null && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirm(null)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#fff2f0' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认删除</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>删除后不可恢复，是否确认删除该资料？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setDeleteConfirm(null)}>取消</button>
                  <button className="btn-danger" onClick={() => handleDelete(deleteConfirm)}>确认删除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 培训过程 ==================== */}
      {activeTab === 'process' && (
        <>
          {/* Toolbar */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={() => setPlanOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>制定培训计划</button>
              <button className="btn-default flex items-center gap-1 text-xs" onClick={() => setExpertOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>专家库</button>
            </div>
            <div className="flex gap-2 text-xs">
              {Object.entries(statusConfig).map(([k, v]) => (
                <span key={k} className="px-3 py-1 rounded-full border" style={{ borderColor: v.color + '30', background: v.bg, color: v.color }}>
                  {v.label} {plans.filter(p => p.status === k).length}
                </span>
              ))}
            </div>
          </div>

          {/* Training Plan Kanban */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {Object.entries(statusConfig).map(([statusKey, config]) => {
              const items = plans.filter(p => p.status === statusKey)
              return (
                <div key={statusKey} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-3 h-3 rounded-full" style={{ background: config.color }} />
                    <h4 className="font-medium text-sm">{config.label}</h4>
                    <span className="ml-auto text-xs font-mono" style={{ color: 'var(--text-disabled)' }}>{items.length}</span>
                  </div>
                  <div className="space-y-3">
                    {items.map(plan => (
                      <div key={plan.id} className="p-3 rounded-lg border cursor-pointer hover:shadow-sm transition-all" style={{ borderColor: 'var(--border-color)' }} onClick={() => openPlanDetail(plan)}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs" style={{ color: 'var(--text-disabled)' }}>{plan.id}</span>
                          <span className="tag text-xs px-1.5 py-0.5" style={{ background: config.bg, color: config.color, border: `1px solid ${config.color}30` }}>{config.label}</span>
                        </div>
                        <p className="text-sm font-medium">{plan.course}</p>
                        <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>讲师：{plan.instructor}</p>
                        <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{plan.startTime}</p>
                        <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>地点：{plan.location}</p>
                        {plan.trainees.length > 0 && <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>参训 {plan.trainees.length} 人 · 已签到 {plan.trainees.filter(t => t.checkIn).length} 人</p>}
                        {plan.archiveNo && <p className="text-xs mt-1 font-mono" style={{ color: '#8c8c8c' }}>归档号：{plan.archiveNo}</p>}
                        {/* Participant actions */}
                        {plan.status === 'active' && (
                          <button className="btn-primary text-xs w-full mt-2 py-1.5 flex items-center justify-center gap-1"
                            onClick={e => { e.stopPropagation(); setSelectedPlan(plan); setPlanDetailOpen(true) }}>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="20 6 9 17 4 12"/></svg>
                            参与签到
                          </button>
                        )}
                        {plan.status === 'evaluating' && (
                          <button className="btn-primary text-xs w-full mt-2 py-1.5 flex items-center justify-center gap-1"
                            onClick={e => { e.stopPropagation(); setSelectedPlan(plan); setEvalOpen(true) }}>
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                            填写评估
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )
            })}
          </div>

          {/* New Plan Modal */}
          {planOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setPlanOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[560px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">制定培训计划</h3>
                  <button onClick={() => setPlanOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">课程名称 <span className="text-red-400">*</span></label><input className="form-input w-full" value={newPlanForm.course} onChange={e => setNewPlanForm({ ...newPlanForm, course: e.target.value })} placeholder="请输入课程名称" /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-xs mb-1">讲师 <span className="text-red-400">*</span></label>
                      <select className="form-input w-full" value={newPlanForm.instructor} onChange={e => setNewPlanForm({ ...newPlanForm, instructor: e.target.value })}>
                        <option value="">请选择讲师</option>
                        {experts.map(e => (<option key={e.id} value={e.name}>{e.name} · {e.field}</option>))}
                      </select>
                    </div>
                    <div><label className="block text-xs mb-1">培训地点</label><input className="form-input w-full" value={newPlanForm.location} onChange={e => setNewPlanForm({ ...newPlanForm, location: e.target.value })} placeholder="如：培训中心A301" /></div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-xs mb-1">开始时间</label><input className="form-input w-full" type="datetime-local" value={newPlanForm.startTime} onChange={e => setNewPlanForm({ ...newPlanForm, startTime: e.target.value })} /></div>
                    <div><label className="block text-xs mb-1">结束时间</label><input className="form-input w-full" type="datetime-local" value={newPlanForm.endTime} onChange={e => setNewPlanForm({ ...newPlanForm, endTime: e.target.value })} /></div>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setPlanOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={handleAddPlan}>保存计划</button>
                </div>
              </div>
            </div>
          )}

          {/* Plan Detail Modal */}
          {planDetailOpen && selectedPlan && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setPlanDetailOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[720px] max-h-[85vh] flex flex-col">
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <div>
                    <h3 className="text-lg font-semibold">{selectedPlan.status === 'active' ? '培训签到' : selectedPlan.course}</h3>
                    <span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPlan.id}</span>
                  </div>
                  <button onClick={() => setPlanDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="flex-1 overflow-auto p-6 space-y-5">
                  {/* Basic Info */}
                  <div className="grid grid-cols-3 gap-3">
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>培训计划ID</span>
                      <span className="font-mono text-xs">{selectedPlan.id || '-'}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>讲师</span>
                      <span className="text-sm">{selectedPlan.instructor || '-'}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>状态</span>
                      <span className="tag text-xs px-2 py-0.5" style={{ background: statusConfig[selectedPlan.status].bg, color: statusConfig[selectedPlan.status].color, border: `1px solid ${statusConfig[selectedPlan.status].color}30` }}>{statusConfig[selectedPlan.status].label}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>培训时间</span>
                      <span className="text-xs">{selectedPlan.startTime}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>培训地点</span>
                      <span className="text-xs">{selectedPlan.location}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>参训人数</span>
                      <span className="text-xs">{selectedPlan.trainees.length} 人</span>
                    </div>
                  </div>

                  {/* Check-in Table */}
                  {selectedPlan.trainees.length > 0 && (
                    <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>签到管理</h4>
                      <table className="w-full text-sm">
                        <thead><tr style={{ background: 'var(--table-header-bg)' }}>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>姓名</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>部门</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>签到状态</th>
                          <th className="px-2 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>操作</th>
                        </tr></thead>
                        <tbody>
                          {selectedPlan.trainees.map((t, i) => (
                            <tr key={i} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                              <td className="px-2 py-2">{t.name}</td>
                              <td className="px-2 py-2 text-xs">{t.dept}</td>
                              <td className="px-2 py-2">
                                <span className="tag text-xs px-2 py-0.5" style={{ background: t.checkIn ? '#f6ffed' : '#fff2f0', color: t.checkIn ? '#52c41a' : '#ff4d4f' }}>{t.checkIn ? '已签到' : '未签到'}</span>
                              </td>
                              <td className="px-2 py-2">
                                {selectedPlan.status === 'active' && (
                                  <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => toggleCheckIn(selectedPlan.id, i)}>
                                    {t.checkIn ? '取消签到' : '签到'}
                                  </button>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* Evaluation */}
                  {selectedPlan.questionnaire.length > 0 && (
                    <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>效果评估</h4>
                      <div className="space-y-2">
                        {selectedPlan.questionnaire.map((q, i) => (
                          <div key={i} className="flex items-center gap-3">
                            <span className="text-xs flex-1">{q.question}</span>
                            <div className="w-32 h-2 rounded-full" style={{ background: 'var(--border-color)' }}>
                              <div className="h-2 rounded-full" style={{ width: `${(q.avgScore / 5) * 100}%`, background: '#52c41a' }} />
                            </div>
                            <span className="text-xs font-mono w-8">{q.avgScore}</span>
                          </div>
                        ))}
                      </div>

                    </div>
                  )}
                </div>

                {/* Footer Actions */}
                <div className="px-6 py-4 border-t flex items-center justify-end gap-3" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setPlanDetailOpen(false)}>关闭</button>
                  {selectedPlan.status === 'active' && (
                    <button className="btn-primary" onClick={() => {
                      setPlans(prev => prev.map(p => p.id === selectedPlan.id ? { ...p, status: 'evaluating' as const } : p))
                      setPlanDetailOpen(false)
                    }}>结束并进入评估</button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Expert Library Modal (reuse planDetailOpen with empty plan) */}
          {/* Expert Library Modal — independent state */}
          {expertOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setExpertOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[640px] max-h-[80vh] flex flex-col">
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h3 className="text-lg font-semibold">专家库</h3>
                  <button onClick={() => setExpertOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="flex-1 overflow-auto p-6">
                  <table className="w-full text-sm">
                    <thead><tr style={{ background: 'var(--table-header-bg)' }}>
                      <th className="px-3 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>专家编号</th>
                      <th className="px-3 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>姓名</th>
                      <th className="px-3 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>专业领域</th>
                      <th className="px-3 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>级别</th>
                      <th className="px-3 py-2 text-left text-xs" style={{ color: 'var(--text-secondary)' }}>联系方式</th>
                    </tr></thead>
                    <tbody>
                      {experts.map(e => (
                        <tr key={e.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>
                          <td className="px-3 py-2 font-mono text-xs">{e.id}</td>
                          <td className="px-3 py-2 font-medium">{e.name}</td>
                          <td className="px-3 py-2 text-xs">{e.field}</td>
                          <td className="px-3 py-2"><span className="tag text-xs px-2 py-0.5" style={{ background: e.level === '高级' ? '#f6ffed' : '#e6f7ff', color: e.level === '高级' ? '#52c41a' : '#1890ff' }}>{e.level}</span></td>
                          <td className="px-3 py-2 text-xs">{e.phone}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="px-6 py-4 border-t flex items-center justify-end" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setExpertOpen(false)}>关闭</button>
                </div>
              </div>
            </div>
          )}

          {/* Evaluation Modal */}
          {evalOpen && selectedPlan && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setEvalOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">培训效果评估 — {selectedPlan.course}</h3>
                  <button onClick={() => setEvalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>1. 课程内容实用性（1-5分）</label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map(n => (
                        <button key={n} className="w-8 h-8 rounded-full text-xs border transition-all"
                          style={{ borderColor: evalForm.q1 >= n ? '#1890ff' : '#d9d9d9', background: evalForm.q1 >= n ? '#e6f7ff' : 'transparent', color: evalForm.q1 >= n ? '#1890ff' : '#8c8c8c' }}
                          onClick={() => setEvalForm({ ...evalForm, q1: n })}>{n}</button>
                      ))}
                      <span className="text-xs ml-2" style={{ color: '#1890ff' }}>{evalForm.q1} 分</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>2. 讲师授课水平（1-5分）</label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map(n => (
                        <button key={n} className="w-8 h-8 rounded-full text-xs border transition-all"
                          style={{ borderColor: evalForm.q2 >= n ? '#1890ff' : '#d9d9d9', background: evalForm.q2 >= n ? '#e6f7ff' : 'transparent', color: evalForm.q2 >= n ? '#1890ff' : '#8c8c8c' }}
                          onClick={() => setEvalForm({ ...evalForm, q2: n })}>{n}</button>
                      ))}
                      <span className="text-xs ml-2" style={{ color: '#1890ff' }}>{evalForm.q2} 分</span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>3. 培训组织安排（1-5分）</label>
                    <div className="flex items-center gap-2">
                      {[1, 2, 3, 4, 5].map(n => (
                        <button key={n} className="w-8 h-8 rounded-full text-xs border transition-all"
                          style={{ borderColor: evalForm.q3 >= n ? '#1890ff' : '#d9d9d9', background: evalForm.q3 >= n ? '#e6f7ff' : 'transparent', color: evalForm.q3 >= n ? '#1890ff' : '#8c8c8c' }}
                          onClick={() => setEvalForm({ ...evalForm, q3: n })}>{n}</button>
                      ))}
                      <span className="text-xs ml-2" style={{ color: '#1890ff' }}>{evalForm.q3} 分</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-5">
                  <button className="btn-default" onClick={() => setEvalOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => {
                    setPlans(prev => prev.map(p => p.id === selectedPlan.id ? {
                      ...p,
                      questionnaire: [
                        { question: '课程内容实用性', avgScore: evalForm.q1 },
                        { question: '讲师授课水平', avgScore: evalForm.q2 },
                        { question: '培训组织安排', avgScore: evalForm.q3 },
                      ]
                    } : p))
                    setEvalOpen(false)
                    setEvalForm({ q1: 5, q2: 5, q3: 5 })
                  }}>提交评估</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 专家库 ==================== */}
      {activeTab === 'expert' && (
        <>
          <div className="flex items-center justify-between">
            <button className="btn-primary flex items-center gap-1" onClick={() => openExpertForm('add')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增专家</button>
          </div>
          <div className="content-card p-4">
            <div className="flex items-end gap-3 mb-4">
              <div><label className="block text-xs mb-1">姓名/专业领域</label><input className="form-input w-40" placeholder="请输入..." value={expertSearch} onChange={e => setExpertSearch(e.target.value)} /></div>
              <div className="flex gap-2 ml-auto"><button className="btn-default" onClick={() => setExpertSearch('')}>重置</button><button className="btn-primary">查询</button></div>
            </div>
            <table className="data-table">
              <thead>
                <tr>
                  <th className="w-10"><input type="checkbox" /></th>
                  <th>专家编号</th>
                  <th>姓名</th>
                  <th>专业领域</th>
                  <th>级别</th>
                  <th>联系方式</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {experts
                  .filter(e => !expertSearch || e.name.includes(expertSearch) || e.field.includes(expertSearch))
                  .map(e => (
                    <tr key={e.id}>
                      <td><input type="checkbox" /></td>
                      <td className="font-mono text-xs">{e.id}</td>
                      <td className="font-medium">{e.name}</td>
                      <td className="text-xs">{e.field}</td>
                      <td><span className="tag text-xs px-2 py-0.5" style={{ background: e.level === '高级' ? '#f6ffed' : '#e6f7ff', color: e.level === '高级' ? '#52c41a' : '#1890ff' }}>{e.level}</span></td>
                      <td className="text-xs">{e.phone}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openExpertForm('view', e)}>查看</button>
                          <button className="text-xs" style={{ color: '#faad14' }} onClick={() => openExpertForm('edit', e)}>修改</button>
                          <button className="text-xs" style={{ color: '#ff4d4f' }} onClick={() => setExpertDeleteConfirm(e.id)}>删除</button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>

          {/* Expert Form Modal */}
          {expertFormOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setExpertFormOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">
                    {expertFormMode === 'add' ? '新增专家' : expertFormMode === 'edit' ? '修改专家' : '查看专家'}
                  </h3>
                  <button onClick={() => setExpertFormOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">姓名 {expertFormMode !== 'view' && <span className="text-red-400">*</span>}</label><input className="form-input w-full" value={expertForm.name} onChange={ev => setExpertForm({ ...expertForm, name: ev.target.value })} placeholder="请输入姓名" readOnly={expertFormMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1">专业领域 {expertFormMode !== 'view' && <span className="text-red-400">*</span>}</label><input className="form-input w-full" value={expertForm.field} onChange={ev => setExpertForm({ ...expertForm, field: ev.target.value })} placeholder="如：手持终端/对讲机" readOnly={expertFormMode === 'view'} /></div>
                  <div className="grid grid-cols-2 gap-3">
                    <div><label className="block text-xs mb-1">级别</label><select className="form-input w-full" value={expertForm.level} onChange={ev => setExpertForm({ ...expertForm, level: ev.target.value })} disabled={expertFormMode === 'view'}><option>高级</option><option>中级</option></select></div>
                    <div><label className="block text-xs mb-1">联系方式</label><input className="form-input w-full" value={expertForm.phone} onChange={ev => setExpertForm({ ...expertForm, phone: ev.target.value })} placeholder="手机号" readOnly={expertFormMode === 'view'} /></div>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setExpertFormOpen(false)}>关闭</button>
                  {expertFormMode !== 'view' && <button className="btn-primary" onClick={saveExpert}>保存</button>}
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirm Modal */}
          {expertDeleteConfirm && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setExpertDeleteConfirm(null)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#fff2f0' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认删除</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>删除后不可恢复，是否确认删除该专家？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setExpertDeleteConfirm(null)}>取消</button>
                  <button className="btn-danger" onClick={() => deleteExpert(expertDeleteConfirm)}>确认删除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 交流互动 ==================== */}
      {activeTab === 'forum' && (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={() => setPostOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>发帖提问</button>
              <button className="btn-default flex items-center gap-1" onClick={() => setSuggestOpen(true)}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>提建议</button>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: 'var(--border-color)' }}>我的帖子 3</span>
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: 'var(--border-color)' }}>关注的问题 5</span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>板块：</span>
            {['全部', '使用问题', '管理建议', '经验分享'].map(f => (
              <label key={f} className="flex items-center gap-1 text-xs cursor-pointer"><input type="checkbox" defaultChecked className="accent-blue-500"/> {f}</label>
            ))}
          </div>
          <div className="content-card divide-y" style={{ borderColor: 'var(--border-color)' }}>
            {forumPosts.map((post) => (
              <div key={post.id} className="p-4 hover:bg-blue-50/30 transition-colors cursor-pointer" onClick={() => openPostDetail(post)}>
                <div className="flex items-start gap-3">
                  {post.pinned && <span className="tag text-xs flex-shrink-0" style={{ background: '#fff2f0', color: '#ff4d4f' }}>置顶</span>}
                  <span className="tag text-xs flex-shrink-0" style={{
                    background: post.category === 'question' ? '#fffbe6' : post.category === 'suggestion' ? '#e6f7ff' : '#f6ffed',
                    color: post.category === 'question' ? '#faad14' : post.category === 'suggestion' ? '#1890ff' : '#52c41a'
                  }}>
                    {post.category === 'question' ? '提问' : post.category === 'suggestion' ? '建议' : '经验'}
                  </span>
                  <div className="flex-1">
                    <h5 className="text-sm font-medium mb-1">{post.title}</h5>
                    <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--text-secondary)' }}>
                      <span>{post.author}</span>
                      <span>{post.date}</span>
                      <span>回复 {post.replies.length}</span>
                      <span>浏览 {post.views.toLocaleString()}</span>
                      {!post.solved ? <span className="tag" style={{ background: '#fffbe6', color: '#faad14' }}>未解决</span> : <span className="tag" style={{ background: '#f6ffed', color: '#52c41a' }}>已解决</span>}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Post Question Modal */}
          {postOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setPostOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[560px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">发帖提问</h3>
                  <button onClick={() => setPostOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">标题 <span className="text-red-400">*</span></label><input className="form-input w-full" value={postForm.title} onChange={e => setPostForm({ ...postForm, title: e.target.value })} placeholder="请简要描述你的问题" /></div>
                  <div><label className="block text-xs mb-1">问题描述 <span className="text-red-400">*</span></label><textarea className="form-input w-full text-sm" rows={5} value={postForm.content} onChange={e => setPostForm({ ...postForm, content: e.target.value })} placeholder="请详细描述你遇到的问题..." /></div>
                  <div><label className="block text-xs mb-1">分类</label><select className="form-input w-full"><option>使用问题</option><option>管理建议</option><option>经验分享</option></select></div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setPostOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => handlePostSubmit('question')}>发布</button>
                </div>
              </div>
            </div>
          )}

          {/* Suggest Modal */}
          {suggestOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setSuggestOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[560px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">提建议</h3>
                  <button onClick={() => setSuggestOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="space-y-3">
                  <div><label className="block text-xs mb-1">建议标题 <span className="text-red-400">*</span></label><input className="form-input w-full" value={postForm.title} onChange={e => setPostForm({ ...postForm, title: e.target.value })} placeholder="请简要描述你的建议" /></div>
                  <div><label className="block text-xs mb-1">建议内容 <span className="text-red-400">*</span></label><textarea className="form-input w-full text-sm" rows={5} value={postForm.content} onChange={e => setPostForm({ ...postForm, content: e.target.value })} placeholder="请详细描述你的建议..." /></div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setSuggestOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => handlePostSubmit('suggestion')}>提交建议</button>
                </div>
              </div>
            </div>
          )}

          {/* Post Detail Modal */}
          {postDetailOpen && selectedPost && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setPostDetailOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[720px] max-h-[85vh] flex flex-col">
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center gap-2">
                    <span className="tag text-xs" style={{ background: selectedPost.category === 'question' ? '#fffbe6' : selectedPost.category === 'suggestion' ? '#e6f7ff' : '#f6ffed', color: selectedPost.category === 'question' ? '#faad14' : selectedPost.category === 'suggestion' ? '#1890ff' : '#52c41a' }}>
                      {selectedPost.category === 'question' ? '提问' : selectedPost.category === 'suggestion' ? '建议' : '经验'}
                    </span>
                    <h3 className="text-base font-semibold">{selectedPost.title}</h3>
                  </div>
                  <button onClick={() => setPostDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  </button>
                </div>
                <div className="flex-1 overflow-auto p-6 space-y-4">
                  <div className="flex items-center gap-3 text-xs" style={{ color: 'var(--text-secondary)' }}>
                    <span>作者：{selectedPost.author}</span>
                    <span>{selectedPost.date}</span>
                    <span>浏览 {selectedPost.views.toLocaleString()}</span>
                    {selectedPost.solved ? <span className="tag" style={{ background: '#f6ffed', color: '#52c41a' }}>已解决</span> : <span className="tag" style={{ background: '#fffbe6', color: '#faad14' }}>未解决</span>}
                  </div>

                  {/* Replies */}
                  <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-3 text-sm">回复 ({selectedPost.replies.length})</h4>
                    {selectedPost.replies.length === 0 ? (
                      <p className="text-xs text-center py-6" style={{ color: 'var(--text-secondary)' }}>暂无回复，来写第一条回复吧</p>
                    ) : (
                      <div className="space-y-3">
                        {selectedPost.replies.map((r, i) => (
                          <div key={i} className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium">{r.author}</span>
                              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{r.date}</span>
                            </div>
                            <p className="text-sm">{r.content}</p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Reply Input */}
                  <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                    <textarea className="form-input w-full text-sm" rows={3} value={replyContent} onChange={e => setReplyContent(e.target.value)} placeholder="写下你的回复..." />
                    <div className="flex justify-end mt-2">
                      <button className="btn-primary text-xs" onClick={handleReply}>回复</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
