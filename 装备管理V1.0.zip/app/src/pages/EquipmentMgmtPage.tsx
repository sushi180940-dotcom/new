import { useState, useEffect } from 'react'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'
import { warehouseData } from '../pages/InboundPage'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

interface RoomData {
  id: string
  name: string
  parentId: string
  parentName: string
  unit: string
  type: 'warehouse' | 'zone' | 'shelf'
  sortNo: number
  kanbanPos: 'left' | 'right' | 'none'
  address: string
  longitude: string
  latitude: string
  createTime: string
}

const tabList = [
  { key: 'room-config', label: '装备室配置管' },
  { key: 'tag-mgmt', label: '标签管理' },
  { key: 'inventory', label: '库存管理' },
  { key: 'personal-alloc', label: '个人装备分配' },
  { key: 'repair-mgmt', label: '报修管理' },
  { key: 'scrap-mgmt', label: '报废管理' },
]

const roomData: RoomData[] = [
  { id: 'KS001', name: '省厅主仓库', parentId: '', parentName: '无', unit: 'XX省公安厅', type: 'warehouse', sortNo: 1, kanbanPos: 'none', address: 'XX省XX市XX区XX路1号', longitude: '116.3974', latitude: '39.9093', createTime: '2023-01-15' },
  { id: 'KS002', name: '市局限A分区', parentId: 'KS001', parentName: '省厅主仓库', unit: 'XX市公安局', type: 'zone', sortNo: 0, kanbanPos: 'left', address: 'XX市XX区XX路88号', longitude: '116.4074', latitude: '39.9193', createTime: '2023-03-20' },
  { id: 'KS003', name: 'A分区-货架01', parentId: 'KS002', parentName: '市局限A分区', unit: 'XX市公安局', type: 'shelf', sortNo: 0, kanbanPos: 'left', address: 'XX市XX区XX路88号-A区', longitude: '116.4074', latitude: '39.9193', createTime: '2023-03-20' },
  { id: 'KS004', name: '区县B分区', parentId: 'KS001', parentName: '省厅主仓库', unit: 'XX区公安分局', type: 'zone', sortNo: 0, kanbanPos: 'right', address: 'XX区XX街道XX路15号', longitude: '116.3874', latitude: '39.8993', createTime: '2023-06-10' },
  { id: 'KS005', name: '小区C货架', parentId: 'KS004', parentName: '区县B分区', unit: 'XX街道派出所', type: 'shelf', sortNo: 0, kanbanPos: 'none', address: 'XX街道XX小区3号楼', longitude: '116.3774', latitude: '39.8893', createTime: '2024-01-08' },
]

interface AllocRecord {
  id: string
  personName: string
  personId: string
  personUnit: string
  equipCode: string
  equipName: string
  allocTime: string
  allocType: 'assign' | 'cancel'
  status: 'active' | 'returned' | 'overdue'
}

const allocRecords: AllocRecord[] = [
  { id: 'FP2024001', personName: '张三', personId: 'J001', personUnit: '刑警支队', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', equipName: '手持终端 XT-2000', allocTime: '2024-03-01 09:00', allocType: 'assign', status: 'active' },
  { id: 'FP2024002', personName: '张三', personId: 'J001', personUnit: '刑警支队', equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', equipName: '执法记录仪 DSJ-A7', allocTime: '2024-03-01 09:00', allocType: 'assign', status: 'active' },
  { id: 'FP2024003', personName: '李四', personId: 'J002', personUnit: '治安支队', equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', equipName: '对讲机 PD780G', allocTime: '2024-03-05 10:30', allocType: 'assign', status: 'active' },
  { id: 'FP2024004', personName: '王五', personId: 'J003', personUnit: '交警支队', equipCode: '1-0-1-01-P002-001-20240220-05-002XXXXXX-0004', equipName: '执法记录仪 DSJ-A7', allocTime: '2024-02-20 14:00', allocType: 'assign', status: 'overdue' },
  { id: 'FP2024005', personName: '赵六', personId: 'J004', personUnit: '特警支队', equipCode: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', equipName: '防弹背心 FDY-3R', allocTime: '2024-01-15 08:00', allocType: 'assign', status: 'returned' },
  { id: 'FP2024006', personName: '赵六', personId: 'J004', personUnit: '特警支队', equipCode: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', equipName: '战术头盔 MICH-2000', allocTime: '2024-01-15 08:00', allocType: 'assign', status: 'active' },
  { id: 'FP2024007', personName: '李四', personId: 'J002', personUnit: '治安支队', equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', equipName: '对讲机 PD780G', allocTime: '2024-04-01 16:00', allocType: 'cancel', status: 'returned' },
]

export default function EquipmentMgmtPage({ activeSubTab, onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab || 'inventory')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [roomModalOpen, setRoomModalOpen] = useState(false)
  const [selectedRoom, setSelectedRoom] = useState<RoomData | null>(null)
  const [roomEditMode, setRoomEditMode] = useState<'add' | 'view' | 'edit'>('add')
  const [allocModalOpen, setAllocModalOpen] = useState(false)
  const [allocMode, setAllocMode] = useState<'assign' | 'return'>('assign')
  const [selectedAlloc, setSelectedAlloc] = useState<AllocRecord | null>(null)
  const [selectedPersons, setSelectedPersons] = useState<string[]>([])
  const [selectedEquip, setSelectedEquip] = useState<string[]>([])
  const [jzConfigOpen, setJzConfigOpen] = useState(false)
  const [jzEditKey, setJzEditKey] = useState<string | null>(null)
  const [roomFormType, setRoomFormType] = useState<string>(selectedRoom?.type || '')
  const [roomDeleteOpen, setRoomDeleteOpen] = useState(false)
  const [roomToDelete, setRoomToDelete] = useState<RoomData | null>(null)

  useEffect(() => {
    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])


  const inventoryData = [
    { code: 'ZB2024005-001', name: '手持终端', model: 'XT-2000', warehouse: 'A栋仓库', location: 'A-102-03', status: 'in', qty: 1 },
    { code: 'ZB2024005-002', name: '手持终端', model: 'XT-2000', warehouse: 'A栋仓库', location: 'A-102-03', status: 'in', qty: 1 },
    { code: 'ZB2024005-003', name: '手持终端', model: 'XT-2000', warehouse: 'A栋仓库', location: 'A-102-03', status: 'out', qty: 0 },
    { code: 'ZB2024006-001', name: '应急照明灯', model: 'YD-100', warehouse: 'A栋仓库', location: 'A-103-01', status: 'in', qty: 1 },
    { code: 'ZB2024007-001', name: '对讲机', model: 'DJ-500', warehouse: 'B栋装备室', location: 'B-201-02', status: 'in', qty: 1 },
  ]

  const inboundData = [
    { id: 'RK2024001', code: 'ZB20001', name: '手持终端', qty: 5, location: 'A-102-03', operator: '张三', status: 'done' },
  ]

  const checkData = [
    { id: 'PD2024001', scope: 'A栋仓库', date: '2024-03-01', operator: '张三', status: 'done', diff: 0 },
    { id: 'PD2024002', scope: 'B栋装备室', date: '2024-03-01', operator: '李四', status: 'diff', diff: 3 },
  ]

  const statusMap: Record<string, { label: string; tag: string }> = {
    in: { label: '在库', tag: 'tag-green' },
    out: { label: '领用', tag: 'tag-yellow' },
    done: { label: '完成', tag: 'tag-green' },
    diff: { label: '差异待审批', tag: 'tag-yellow' },
  }

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb for personal-alloc */}
      {activeTab === 'personal-alloc' && (
        <div className="flex items-center gap-2 text-sm pb-1">
          <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
            返回工作台
          </button>
          <span style={{ color: 'var(--text-disabled)' }}>/</span>
          <span style={{ color: 'var(--text-secondary)' }}>个人装备分配</span>
        </div>
      )}

      {/* Search area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          {activeTab === 'inventory' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属库室</label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value="" onChange={() => {}} mode="name" showAll allLabel="全部" className="w-32" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>在库</option><option>领用</option></select></div>
            </>
          )}
          {activeTab === 'room-config' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库室名称</label><input className="form-input w-40" placeholder="请输入库室名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属上级</label><WarehouseTreeSelect warehouseData={warehouseData} value="" onChange={() => {}} mode="name" showAll allLabel="全部" className="w-36" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属单位</label><select className="form-input w-32"><option>全部</option><option>XX省公安厅</option><option>XX市公安局</option><option>XX区公安分局</option><option>XX街道派出所</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>类型</label><select className="form-input w-32"><option>全部</option><option>仓库</option><option>分区</option><option>货架</option></select></div>
            </>
          )}
          {activeTab === 'tag-mgmt' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>标签名称</label><input className="form-input w-40" placeholder="请输入标签名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>标签类型</label><select className="form-input w-32"><option>全部</option><option>装备标签</option><option>库位标签</option><option>人员标签</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-28"><option>全部</option><option>启用</option><option>停用</option></select></div>
            </>
          )}
          {activeTab === 'personal-alloc' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>人员姓名</label><input className="form-input w-32" placeholder="请输入姓名" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-32" placeholder="请输入装备名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>分配类型</label><select className="form-input w-28"><option>全部</option><option>发配</option><option>取消</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>当前状态</label><select className="form-input w-28"><option>全部</option><option>使用中</option><option>已归还</option><option>已超期</option></select></div>
            </>
          )}
          {activeTab === 'repair-mgmt' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报修状态</label><select className="form-input w-28"><option>全部</option><option>待处理</option><option>维修中</option><option>已完成</option></select></div>
            </>
          )}
          {activeTab === 'scrap-mgmt' && (
            <>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入..." /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废状态</label><select className="form-input w-28"><option>全部</option><option>待审批</option><option>已批准</option><option>已处理</option></select></div>
            </>
          )}
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 flex-wrap">
          {activeTab === 'inventory' && (
            <>
              <button className="btn-primary flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增装备</button>
              <button className="btn-default flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>导出</button>
              <button className="btn-default flex items-center gap-1">批量报修</button>
            </>
          )}
          {activeTab === 'room-config' && (
            <button className="btn-primary flex items-center gap-1" onClick={() => { setSelectedRoom(null); setRoomFormType(''); setRoomEditMode('add'); setRoomModalOpen(true) }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增装备室</button>
          )}
          {activeTab === 'tag-mgmt' && (
            <button className="btn-primary flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增标签</button>
          )}
          {activeTab === 'personal-alloc' && (
            <>
              <button className="btn-primary flex items-center gap-1" onClick={() => { setAllocMode('assign'); setSelectedPersons([]); setSelectedEquip([]); setAllocModalOpen(true) }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>分配装备</button>
              <button className="btn-default flex items-center gap-1 text-xs" onClick={() => setJzConfigOpen(true)}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/></svg>J种配置</button>
              <button className="btn-default flex items-center gap-1 text-xs"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 12v8a2 2 0 002 2h12a2 2 0 002-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg>批量收回</button>
            </>
          )}
          {activeTab === 'repair-mgmt' && (
            <button className="btn-primary flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增报修</button>
          )}
          {activeTab === 'scrap-mgmt' && (
            <button className="btn-primary flex items-center gap-1"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>申请报废</button>
          )}
        </div>
      </div>

      {/* Tab content */}
      <div className="content-card overflow-hidden">
        {/* 1. 装备室配置管 */}
        {activeTab === 'room-config' && (
          <table className="data-table">
            <thead><tr><th>库室ID</th><th>库室名称</th><th>所属上级</th><th>所属单位</th><th>类型</th><th>排序号/看板</th><th>物理地址</th><th>操作</th></tr></thead>
            <tbody>
              {roomData.map((r) => (
                <tr key={r.id}>
                  <td className="font-mono text-xs">{r.id}</td>
                  <td className="font-medium">{r.name}</td>
                  <td>{r.parentName || '-'}</td>
                  <td>{r.unit}</td>
                  <td><span className={`tag text-xs ${r.type === 'warehouse' ? 'tag-blue' : r.type === 'zone' ? 'tag-green' : 'tag-yellow'}`}>{r.type === 'warehouse' ? '仓库' : r.type === 'zone' ? '分区' : '货架'}</span></td>
                  <td>{r.type === 'warehouse' ? `排序号:${r.sortNo}` : `看板:${r.kanbanPos === 'left' ? '左' : r.kanbanPos === 'right' ? '右' : '无'}`}</td>
                  <td className="max-w-[150px] truncate text-xs" title={r.address}>{r.address}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedRoom(r); setRoomFormType(r.type); setRoomEditMode('view'); setRoomModalOpen(true) }}>查看</button>
                      <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => { setSelectedRoom(r); setRoomFormType(r.type); setRoomEditMode('edit'); setRoomModalOpen(true) }}>编辑</button>
                      <button className="text-xs hover:underline" style={{ color: '#fa8c16' }} onClick={() => { setSelectedRoom(r); setRoomFormType(''); setRoomEditMode('add'); setRoomModalOpen(true) }}>添加下级</button>
                      <button className="text-xs hover:underline" style={{ color: 'var(--error)' }} onClick={() => { setRoomToDelete(r); setRoomDeleteOpen(true) }}>删除</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 2. 标签管理 */}
        {activeTab === 'tag-mgmt' && (
          <div className="p-8 text-center">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5" className="mx-auto mb-3">
              <path d="M20.59 13.41l-7.17 7.17a2 2 0 01-2.83 0L2 12V2h10l8.59 8.59a2 2 0 010 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>
            </svg>
            <p className="text-sm font-medium" style={{ color: 'var(--text-secondary)' }}>标签管理功能开发中</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-disabled)' }}>该模块用于管理装备、库位、人员等标签的创建、编辑和绑定</p>
          </div>
        )}

        {/* 3. 库存管理 */}
        {activeTab === 'inventory' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox"/></th>
                <th>装备编码</th><th>装备名称</th><th>规格型号</th><th>库室</th><th>库位</th><th>状态</th><th>数量</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {inventoryData.map(row => (
                <tr key={row.code}>
                  <td><input type="checkbox"/></td>
                  <td className="font-mono text-xs">{row.code}</td>
                  <td className="font-medium">{row.name}</td>
                  <td className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{row.model}</td>
                  <td>{row.warehouse}</td>
                  <td className="font-mono text-xs">{row.location}</td>
                  <td><span className={`tag ${statusMap[row.status]?.tag}`}>{statusMap[row.status]?.label}</span></td>
                  <td>{row.qty}</td>
                  <td>
                    <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setDrawerOpen(true)}>更多 ▼</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 3. 个人装备分配 */}
        {activeTab === 'personal-alloc' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox"/></th>
                <th>分配记录ID</th><th>人员信息</th><th>装备编码</th><th>装备名称</th>
                <th>分配时间</th><th>分配类型</th><th>当前状态</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {allocRecords.map((r) => (
                <tr key={r.id}>
                  <td><input type="checkbox"/></td>
                  <td className="font-mono text-xs">{r.id}</td>
                  <td>
                    <div className="flex flex-col">
                      <span className="font-medium text-sm">{r.personName}</span>
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{r.personId} · {r.personUnit}</span>
                    </div>
                  </td>
                  <td className="font-mono text-xs max-w-[200px] truncate" title={r.equipCode}>{r.equipCode}</td>
                  <td>{r.equipName}</td>
                  <td className="text-xs">{r.allocTime}</td>
                  <td>
                    <span className={`tag text-xs ${r.allocType === 'assign' ? 'tag-blue' : 'tag-gray'}`}>
                      {r.allocType === 'assign' ? '发配' : '取消'}
                    </span>
                  </td>
                  <td>
                    <span className={`tag text-xs ${r.status === 'active' ? 'tag-green' : r.status === 'overdue' ? 'tag-red' : 'tag-gray'}`}>
                      {r.status === 'active' ? '使用中' : r.status === 'overdue' ? '已超期' : '已归还'}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                      {r.status === 'active' && (
                        <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => { setSelectedAlloc(r); setAllocMode('return'); setAllocModalOpen(true) }}>收回</button>
                      )}
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setSelectedAlloc(r); setDrawerOpen(true) }}>详情</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 4. 报修管理 */}
        {activeTab === 'repair-mgmt' && (
          <table className="data-table">
            <thead><tr><th>报修单号</th><th>装备名称</th><th>装备编码</th><th>故障描述</th><th>报修人</th><th>报修日期</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              {[
                { id: 'BX2024001', name: '手持终端', code: 'ZB2024005-001', desc: '屏幕碎裂', person: '张三', date: '2024-03-10', status: 'pending' },
                { id: 'BX2024002', name: '执法记录仪', code: 'ZB2024005-003', desc: '无法开机', person: '李四', date: '2024-03-08', status: 'repairing' },
                { id: 'BX2024003', name: '对讲机', code: 'ZB2024005-005', desc: '信号弱', person: '王五', date: '2024-03-05', status: 'done' },
              ].map((r, i) => (
                <tr key={i}>
                  <td className="font-mono text-xs">{r.id}</td><td>{r.name}</td><td className="font-mono text-xs">{r.code}</td>
                  <td className="max-w-[150px] truncate" title={r.desc}>{r.desc}</td><td>{r.person}</td><td>{r.date}</td>
                  <td><span className={`tag ${r.status === 'pending' ? 'tag-yellow' : r.status === 'repairing' ? 'tag-blue' : 'tag-green'}`}>{r.status === 'pending' ? '待处理' : r.status === 'repairing' ? '维修中' : '已完成'}</span></td>
                  <td><button className="text-xs" style={{ color: 'var(--primary-blue)' }}>查看</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {/* 5. 报废管理 */}
        {activeTab === 'scrap-mgmt' && (
          <table className="data-table">
            <thead><tr><th>报废单号</th><th>装备名称</th><th>装备编码</th><th>报废原因</th><th>申请人</th><th>申请日期</th><th>状态</th><th>操作</th></tr></thead>
            <tbody>
              {[
                { id: 'BF2024001', name: '手持终端', code: 'ZB2024005-002', reason: '使用年限超过5年，性能严重下降', person: '张三', date: '2024-03-01', status: 'pending' },
                { id: 'BF2024002', name: '防弹背心', code: 'ZB2024005-004', reason: '多次使用后防护性能下降', person: '赵六', date: '2024-02-25', status: 'approved' },
              ].map((r, i) => (
                <tr key={i}>
                  <td className="font-mono text-xs">{r.id}</td><td>{r.name}</td><td className="font-mono text-xs">{r.code}</td>
                  <td className="max-w-[200px] truncate" title={r.reason}>{r.reason}</td><td>{r.person}</td><td>{r.date}</td>
                  <td><span className={`tag ${r.status === 'pending' ? 'tag-yellow' : r.status === 'approved' ? 'tag-blue' : 'tag-green'}`}>{r.status === 'pending' ? '待审批' : r.status === 'approved' ? '已批准' : '已处理'}</span></td>
                  <td><button className="text-xs" style={{ color: 'var(--primary-blue)' }}>查看</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Detail Drawer */}
      {drawerOpen && (
        <div className="fixed inset-0 z-[60] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />
          <div className="relative w-[480px] bg-white shadow-2xl flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            <div className="flex items-center justify-between p-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="font-semibold text-base">装备详情</h3>
              <button className="p-1 rounded hover:bg-gray-100" onClick={() => setDrawerOpen(false)}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>
            <div className="p-6 space-y-4 overflow-y-auto flex-1">
              {[
                { label: '装备编码', value: 'ZB2024005-001' },
                { label: '装备名称', value: '手持终端' },
                { label: '规格型号', value: 'XT-2000' },
                { label: '所属库室', value: 'A栋仓库' },
                { label: '库位编号', value: 'A-102-03' },
                { label: '状态', value: '在库' },
                { label: '数量', value: '1' },
                { label: '入库时间', value: '2024-02-22' },
                { label: '供应商', value: '华为技术有限公司' },
                { label: '采购订单', value: 'CG2024001' },
                { label: '保质期', value: '2027-02-21' },
                { label: '保养周期', value: '每季度' },
              ].map(f => (
                <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                  <span className="font-medium">{f.value}</span>
                </div>
              ))}
            </div>
            <div className="p-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-primary w-full">打印标签</button>
            </div>
          </div>
        </div>
      )}
    {/* Room Config Modal */}
    {roomModalOpen && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={() => setRoomModalOpen(false)} />
        <div className="relative bg-white rounded-xl shadow-2xl w-[580px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
          <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
            <h3 className="text-lg font-semibold">
              {roomEditMode === 'add' && selectedRoom ? `添加下级机构 - ${selectedRoom?.name}` : roomEditMode === 'add' ? '新增库室' : roomEditMode === 'edit' ? `编辑库室 - ${selectedRoom?.id}` : `库室详情 - ${selectedRoom?.id}`}
            </h3>
            <button onClick={() => setRoomModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <div className="p-6 space-y-5 overflow-y-auto flex-1">
            {/* Basic Info */}
            <div>
              <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>基本信息</h4>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库室ID <span className="text-red-400">*</span></label>
                  <input className="form-input font-mono" defaultValue={selectedRoom?.id || ''} placeholder="系统自动生成" readOnly={roomEditMode === 'view'} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库室名称 <span className="text-red-400">*</span></label>
                  <input className="form-input" defaultValue={selectedRoom?.name || ''} placeholder="请输入库室名称" readOnly={roomEditMode === 'view'} />
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属上级</label>
                  <select className="form-input" defaultValue={roomEditMode === 'add' && selectedRoom ? selectedRoom.id : (selectedRoom?.parentId || '')} disabled={roomEditMode === 'view' || (roomEditMode === 'add' && selectedRoom !== null)}>
                    <option value="">无（顶级仓库）</option>
                    <option value="KS001">省厅主仓库</option>
                    <option value="KS002">市局限A分区</option>
                    <option value="KS004">区县B分区</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属单位 <span className="text-red-400">*</span></label>
                  <select className="form-input" defaultValue={selectedRoom?.unit || ''} disabled={roomEditMode === 'view'}>
                    <option value="">请选择</option>
                    <option value="XX省公安厅">XX省公安厅</option>
                    <option value="XX市公安局">XX市公安局</option>
                    <option value="XX区公安分局">XX区公安分局</option>
                    <option value="XX街道派出所">XX街道派出所</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>类型 <span className="text-red-400">*</span></label>
                  <select className="form-input" value={roomFormType} onChange={e => setRoomFormType(e.target.value)} disabled={roomEditMode === 'view'}>
                    <option value="">请选择</option>
                    <option value="warehouse">仓库</option>
                    <option value="zone">分区</option>
                    <option value="shelf">货架</option>
                  </select>
                </div>
                {/* 仓库：排序号 */}
                {roomFormType === 'warehouse' && (
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>排序号 <span className="text-red-400">*</span></label>
                    <input className="form-input" type="number" defaultValue={selectedRoom?.sortNo || ''} placeholder="请输入排序号" readOnly={roomEditMode === 'view'} />
                  </div>
                )}
                {/* 分区/货架：看板位置 */}
                {(roomFormType === 'zone' || roomFormType === 'shelf') && (
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>看板位置 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedRoom?.kanbanPos || ''} disabled={roomEditMode === 'view'}>
                      <option value="">请选择</option>
                      <option value="left">左</option>
                      <option value="right">右</option>
                      <option value="none">无</option>
                    </select>
                  </div>
                )}
              </div>
            </div>
            {/* Location Info */}
            <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
              <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>位置信息</h4>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物理地址 <span className="text-red-400">*</span></label>
                  <input className="form-input w-full" defaultValue={selectedRoom?.address || ''} placeholder="请输入详细物理地址" readOnly={roomEditMode === 'view'} />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经度</label>
                    <input className="form-input font-mono" defaultValue={selectedRoom?.longitude || ''} placeholder="如 116.3974" readOnly={roomEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>纬度</label>
                    <input className="form-input font-mono" defaultValue={selectedRoom?.latitude || ''} placeholder="如 39.9093" readOnly={roomEditMode === 'view'} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {roomEditMode !== 'view' && (
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setRoomModalOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => { setRoomModalOpen(false); alert(roomEditMode === 'add' ? '新增成功' : '保存成功') }}>{roomEditMode === 'add' ? '确认新增' : '保存'}</button>
            </div>
          )}
          {roomEditMode === 'view' && (
            <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default" onClick={() => setRoomModalOpen(false)}>关闭</button>
            </div>
          )}
        </div>
      </div>
    )}
    {/* Room Delete Confirmation */}
    {roomDeleteOpen && roomToDelete && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={() => setRoomDeleteOpen(false)} />
        <div className="relative bg-white rounded-xl shadow-2xl w-[400px] p-6 animate-in fade-in zoom-in duration-200">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
            </div>
            <h3 className="text-base font-semibold">确认删除</h3>
          </div>
          <p className="text-sm mb-5" style={{ color: 'var(--text-secondary)' }}>确定要删除库室 <strong>{roomToDelete.name}</strong>（{roomToDelete.id}）吗？删除后数据将无法恢复，请谨慎操作。</p>
          <div className="flex items-center justify-end gap-3">
            <button className="btn-default" onClick={() => setRoomDeleteOpen(false)}>取消</button>
            <button className="btn-danger" onClick={() => { setRoomDeleteOpen(false); alert('删除成功！') }}>确认删除</button>
          </div>
        </div>
      </div>
    )}

    {/* Allocation Modal */}
    {allocModalOpen && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={() => setAllocModalOpen(false)} />
        <div className="relative bg-white rounded-xl shadow-2xl w-[560px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
          <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
            <h3 className="text-lg font-semibold">{allocMode === 'assign' ? '批量分配装备' : '收回装备'}</h3>
            <button onClick={() => setAllocModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <div className="p-6 space-y-5 overflow-y-auto flex-1">
            {allocMode === 'assign' ? (
              <>
                {/* Step 1: Select Persons (multi-check) */}
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center">1</span>选择人员 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（可多选）</span></h4>
                  <div className="grid grid-cols-4 gap-3">
                    {['张三','李四','王五','赵六'].map(p => (
                      <label key={p} className={`flex items-center justify-center gap-2 p-3 rounded-lg border cursor-pointer transition-colors text-sm font-medium ${selectedPersons.includes(p) ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'}`} style={{ borderColor: selectedPersons.includes(p) ? 'var(--primary-blue)' : 'var(--border-color)' }}>
                        <input type="checkbox" className="hidden" checked={selectedPersons.includes(p)} onChange={() => setSelectedPersons(prev => prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p])} />
                        <span className={`w-4 h-4 rounded border flex items-center justify-center ${selectedPersons.includes(p) ? 'bg-blue-500 border-blue-500' : 'border-gray-300'}`}>
                          {selectedPersons.includes(p) && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
                        </span>
                        {p}
                      </label>
                    ))}
                  </div>
                  <div className="mt-3">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属仓库</label>
                    <select className="form-input w-full">
                      <option>本级单位仓库（默认）</option>
                      <option>省厅主仓库</option>
                      <option>市局限装备仓库</option>
                      <option>区县装备室</option>
                    </select>
                  </div>
                </div>
                {/* J种 Config */}
                <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-purple-500 text-white text-xs flex items-center justify-center">J</span>J种配置 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（一键勾选预设装备组合）</span></h4>
                  <div className="flex gap-3">
                    {[
                      { key: 'J种1', label: 'J种1', desc: '手持终端+执法记录仪', codes: ['1-0-1-01-P001-001-20240301-05-001XXXXXX-0001','1-0-1-01-P002-001-20240215-05-002XXXXXX-0003'] },
                      { key: 'J种2', label: 'J种2', desc: '对讲机+防弹背心', codes: ['1-0-1-01-P005-001-20240305-05-005XXXXXX-0005','1-0-1-01-P003-001-20240115-10-003XXXXXX-0002'] },
                      { key: 'J种3', label: 'J种3', desc: '全部装备', codes: ['1-0-1-01-P001-001-20240301-05-001XXXXXX-0001','1-0-1-01-P002-001-20240215-05-002XXXXXX-0003','1-0-1-01-P005-001-20240305-05-005XXXXXX-0005','1-0-1-01-P003-001-20240115-10-003XXXXXX-0002'] },
                    ].map(jz => (
                      <button key={jz.key} className="flex-1 p-3 rounded-lg border text-left hover:border-purple-400 hover:bg-purple-50 transition-colors" style={{ borderColor: 'var(--border-color)' }} onClick={() => { const cur = new Set(selectedEquip); const allIn = jz.codes.every(c => cur.has(c)); if (allIn) { setSelectedEquip(prev => prev.filter(x => !jz.codes.includes(x))); } else { setSelectedEquip(prev => Array.from(new Set([...prev, ...jz.codes]))); } }}>
                        <div className="text-sm font-semibold" style={{ color: '#722ed1' }}>{jz.label}</div>
                        <div className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{jz.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
                {/* Step 2: Select Equipment */}
                <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center">2</span>选择待分配装备 <span className="text-xs font-normal" style={{ color: 'var(--text-secondary)' }}>（已选 {selectedEquip.length} 件）</span></h4>
                  <div className="space-y-2">
                    {[
                      { code: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', name: '手持终端 XT-2000', status: '在库', remain: 15 },
                      { code: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', name: '执法记录仪 DSJ-A7', status: '在库', remain: 8 },
                      { code: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', name: '对讲机 PD780G', status: '在库', remain: 23 },
                      { code: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', name: '防弹背心 FDY-3R', status: '在库', remain: 6 },
                    ].map((eq, i) => (
                      <label key={i} className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${selectedEquip.includes(eq.code) ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'}`} style={{ borderColor: selectedEquip.includes(eq.code) ? 'var(--primary-blue)' : 'var(--border-color)' }}>
                        <input type="checkbox" checked={selectedEquip.includes(eq.code)} onChange={() => setSelectedEquip(prev => prev.includes(eq.code) ? prev.filter(x => x !== eq.code) : [...prev, eq.code])} />
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium">{eq.name}</div>
                          <div className="text-xs font-mono truncate" style={{ color: 'var(--text-secondary)' }}>{eq.code}</div>
                        </div>
                        <span className="text-xs mr-2" style={{ color: 'var(--text-secondary)' }}>剩余:{eq.remain}</span>
                        <span className="tag tag-green text-xs">{eq.status}</span>
                      </label>
                    ))}
                  </div>
                </div>
                {/* Step 3: Confirm */}
                <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-5 h-5 rounded-full bg-blue-500 text-white text-xs flex items-center justify-center">3</span>确认分配</h4>
                  <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                    <p className="text-sm" style={{ color: '#52c41a' }}>已选择 <strong>{selectedPersons.length}</strong> 位人员、<strong>{selectedEquip.length}</strong> 件装备，确认后将生成 {selectedPersons.length * selectedEquip.length} 条分配记录。</p>
                  </div>
                </div>
              </>
            ) : (
              <>
                {/* Return mode */}
                <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><span style={{ color: 'var(--text-secondary)' }}>人员：</span><strong>{selectedAlloc?.personName} ({selectedAlloc?.personId})</strong></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>单位：</span>{selectedAlloc?.personUnit}</div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>装备：</span><strong>{selectedAlloc?.equipName}</strong></div>
                    <div><span style={{ color: 'var(--text-secondary)' }}>分配时间：</span>{selectedAlloc?.allocTime}</div>
                  </div>
                  <div className="mt-3 p-2 rounded text-xs" style={{ background: '#fff7e6', color: '#fa8c16' }}>
                    收回后装备将归还至库存，该分配记录标记为"已归还"。
                  </div>
                </div>
              </>
            )}
          </div>
          <div className="sticky bottom-0 z-10 flex items-center justify-end gap-3 px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
            <button className="btn-default" onClick={() => setAllocModalOpen(false)}>取消</button>
            <button className={allocMode === 'return' ? 'btn-danger' : 'btn-primary'} onClick={() => { setAllocModalOpen(false); alert(allocMode === 'assign' ? '分配成功！已生成2条分配记录。' : '收回成功！装备已归还至库存。') }}>
              {allocMode === 'assign' ? '确认分配' : '确认收回'}
            </button>
          </div>
        </div>
      </div>
    )}

    {/* J种配置 Modal */}
    {jzConfigOpen && (
      <div className="fixed inset-0 z-[60] flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={() => { setJzConfigOpen(false); setJzEditKey(null) }} />
        <div className="relative bg-white rounded-xl shadow-2xl w-[520px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
          <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
            <h3 className="text-lg font-semibold">J种配置管理</h3>
            <button onClick={() => { setJzConfigOpen(false); setJzEditKey(null) }} className="p-1 rounded-lg hover:bg-gray-100">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
            </button>
          </div>
          <div className="p-6 space-y-5 overflow-y-auto flex-1">
            {[
              { key: 'J种1', label: 'J种1', color: '#722ed1', desc: '手持终端+执法记录仪', codes: ['1-0-1-01-P001-001-20240301-05-001XXXXXX-0001','1-0-1-01-P002-001-20240215-05-002XXXXXX-0003'] },
              { key: 'J种2', label: 'J种2', color: '#1890ff', desc: '对讲机+防弹背心', codes: ['1-0-1-01-P005-001-20240305-05-005XXXXXX-0005','1-0-1-01-P003-001-20240115-10-003XXXXXX-0002'] },
              { key: 'J种3', label: 'J种3', color: '#52c41a', desc: '全部装备', codes: ['1-0-1-01-P001-001-20240301-05-001XXXXXX-0001','1-0-1-01-P002-001-20240215-05-002XXXXXX-0003','1-0-1-01-P005-001-20240305-05-005XXXXXX-0005','1-0-1-01-P003-001-20240115-10-003XXXXXX-0002'] },
            ].map(jz => {
              const allEquip = [
                { code: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', name: '手持终端 XT-2000' },
                { code: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', name: '执法记录仪 DSJ-A7' },
                { code: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', name: '对讲机 PD780G' },
                { code: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', name: '防弹背心 FDY-3R' },
                { code: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', name: '战术头盔 MICH-2000' },
              ]
              return (
                <div key={jz.key} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <span className="w-7 h-7 rounded-md flex items-center justify-center text-white text-xs font-bold" style={{ background: jz.color }}>{jz.key.replace('J种','')}</span>
                      <div>
                        <div className="text-sm font-semibold">{jz.label}</div>
                        <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{jz.desc}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {jzEditKey === jz.key ? (
                        <>
                          <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => setJzEditKey(null)}>保存</button>
                          <button className="text-xs hover:underline" style={{ color: 'var(--text-secondary)' }} onClick={() => setJzEditKey(null)}>取消</button>
                        </>
                      ) : (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setJzEditKey(jz.key)}>编辑</button>
                      )}
                    </div>
                  </div>
                  {jzEditKey === jz.key ? (
                    <div className="space-y-2">
                      <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>勾选该J种包含的装备：</div>
                      {allEquip.map(eq => (
                        <label key={eq.code} className={`flex items-center gap-3 p-2.5 rounded-lg border cursor-pointer transition-colors ${jz.codes.includes(eq.code) ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'}`} style={{ borderColor: jz.codes.includes(eq.code) ? 'var(--primary-blue)' : 'var(--border-color)' }}>
                          <input type="checkbox" defaultChecked={jz.codes.includes(eq.code)} />
                          <span className="text-sm flex-1">{eq.name}</span>
                          <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{eq.code.slice(-12)}</span>
                        </label>
                      ))}
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {jz.codes.map(code => {
                        const eq = allEquip.find(e => e.code === code)
                        return (
                          <span key={code} className="tag tag-blue text-xs">{eq?.name || code}</span>
                        )
                      })}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
          <div className="sticky bottom-0 z-10 flex items-center justify-end px-6 py-4 border-t bg-gray-50" style={{ borderColor: 'var(--border-color)' }}>
            <button className="btn-default" onClick={() => { setJzConfigOpen(false); setJzEditKey(null) }}>关闭</button>
          </div>
        </div>
      </div>
    )}

    </div>
  )
}