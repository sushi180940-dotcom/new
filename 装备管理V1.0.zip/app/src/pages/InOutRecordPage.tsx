import { useState } from 'react'
import TagBadges, { RfidDisplay } from '../components/TagBadges'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

interface InOutRecord {
  id: string
  equipCode: string
  equipName: string
  rfidCode: string
  tags: string[]
  type: 'in' | 'out'
  time: string
  channelOrOperator: string
  channelType: 'auto' | 'manual'
  legal: boolean
  remark: string
}

const inOutRecords: InOutRecord[] = [
  { id: 'CR2024001', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', rfidCode: '10101P0010012024031505001XXXXXX0001', tags: ['品类特征/贵重仪器'], equipName: '手持终端 XT-2000', type: 'in', time: '2024-03-15 08:23:15', channelOrOperator: 'A栋主通道-01', channelType: 'auto', legal: true, remark: '正常归还入库' },
  { id: 'CR2024002', equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', rfidCode: '10101P0020012024040105003XXXXXX0003', tags: ['状态类/临期30天'], equipName: '执法记录仪 DSJ-A7', type: 'out', time: '2024-03-15 07:45:30', channelOrOperator: 'A栋主通道-01', channelType: 'auto', legal: true, remark: '正常领用出库' },
  { id: 'CR2024003', equipCode: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', rfidCode: '10101P0030012024021010004XXXXXX0004', tags: ['活动类/双11备货'], equipName: '防弹背心 FDY-3R', type: 'out', time: '2024-03-14 23:12:05', channelOrOperator: 'B栋侧门-02', channelType: 'auto', legal: false, remark: '非法出库-非工作时段' },
  { id: 'CR2024004', equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', rfidCode: '10101P0050012024031505002XXXXXX0002', tags: ['品类特征/易碎品'], equipName: '对讲机 PD780G', type: 'in', time: '2024-03-14 18:30:22', channelOrOperator: '张三', channelType: 'manual', legal: true, remark: '人工登记入库' },
  { id: 'CR2024005', equipCode: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', rfidCode: '10101P0040012024031505005XXXXXX0005', tags: ['状态类/临期30天', '品类特征/贵重仪器'], equipName: '战术头盔 MICH-2000', type: 'out', time: '2024-03-14 14:15:10', channelOrOperator: 'A栋主通道-01', channelType: 'auto', legal: true, remark: '正常领用出库' },
  { id: 'CR2024006', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', rfidCode: '10101P0010012024031505001XXXXXX0001', tags: ['品类特征/贵重仪器'], equipName: '手持终端 XT-2000', type: 'out', time: '2024-03-14 09:00:45', channelOrOperator: '李四', channelType: 'manual', legal: true, remark: '人工登记出库' },
  { id: 'CR2024007', equipCode: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', rfidCode: '10101P0020012024040105003XXXXXX0003', tags: ['状态类/临期30天'], equipName: '执法记录仪 DSJ-A7', type: 'in', time: '2024-03-13 20:45:18', channelOrOperator: 'A栋主通道-01', channelType: 'auto', legal: false, remark: '异常入库-未匹配领用记录' },
  { id: 'CR2024008', equipCode: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', rfidCode: '10101P0030012024021010004XXXXXX0004', tags: ['活动类/双11备货'], equipName: '对讲机 PD780G', type: 'out', time: '2024-03-13 16:20:33', channelOrOperator: 'B栋侧门-02', channelType: 'auto', legal: true, remark: '正常领用出库' },
  { id: 'CR2024009', equipCode: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', rfidCode: '10101P0050012024031505002XXXXXX0002', tags: ['品类特征/易碎品'], equipName: '防弹背心 FDY-3R', type: 'in', time: '2024-03-13 12:10:50', channelOrOperator: '王五', channelType: 'manual', legal: true, remark: '人工登记归还' },
  { id: 'CR2024010', equipCode: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', rfidCode: '10101P0040012024031505005XXXXXX0005', tags: ['状态类/临期30天', '品类特征/贵重仪器'], equipName: '手持终端 XT-2000', type: 'in', time: '2024-03-13 08:55:42', channelOrOperator: 'A栋主通道-01', channelType: 'auto', legal: true, remark: '正常归还入库' },
]

export default function InOutRecordPage({ onNavigate }: Props) {
  const [detailOpen, setDetailOpen] = useState(false)
  const [selectedRecord, setSelectedRecord] = useState<InOutRecord | null>(null)

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>
          返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>出入库记录</span>
      </div>

      {/* Search area */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>记录编号</label>
            <input className="form-input w-36" placeholder="请输入..." />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备编码</label>
            <input className="form-input w-48 font-mono text-xs" placeholder="请输入装备编码..." />
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>操作类型</label>
            <select className="form-input w-28">
              <option>全部</option>
              <option>入库</option>
              <option>出库</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合法性标志</label>
            <select className="form-input w-28">
              <option>全部</option>
              <option>合法</option>
              <option>非法</option>
            </select>
          </div>
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发生日期</label>
            <input className="form-input w-32" type="date" />
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Statistics cards */}
      <div className="grid grid-cols-4 gap-4">
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: '#e6f7ff' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M12 5v14M5 12l7-7 7 7"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>今日入库</div>
            <div className="text-lg font-bold" style={{ color: '#1890ff' }}>12</div>
          </div>
        </div>
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: '#fff7e6' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#faad14" strokeWidth="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>今日出库</div>
            <div className="text-lg font-bold" style={{ color: '#faad14' }}>8</div>
          </div>
        </div>
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: '#f6ffed' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>合法操作</div>
            <div className="text-lg font-bold" style={{ color: '#52c41a' }}>156</div>
          </div>
        </div>
        <div className="content-card p-4 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: '#fff2f0' }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
          </div>
          <div>
            <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>异常操作</div>
            <div className="text-lg font-bold" style={{ color: '#ff4d4f' }}>3</div>
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox"/></th>
              <th>记录编号</th>
              <th>装备编码</th>
              <th>RFID编码</th>
              <th>装备名称</th>
              <th>标签</th>
              <th>操作类型</th>
              <th>发生时间</th>
              <th>通道ID / 操作人</th>
              <th>通道类型</th>
              <th>合法性</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {inOutRecords.map((r) => (
              <tr key={r.id}>
                <td><input type="checkbox"/></td>
                <td className="font-mono text-xs font-medium">{r.id}</td>
                <td className="font-mono text-xs max-w-[180px] truncate" title={r.equipCode}>{r.equipCode}</td>
                <td className="font-mono text-xs"><RfidDisplay rfid={r.rfidCode} /></td>
                <td>{r.equipName}</td>
                <td className="text-xs"><TagBadges tags={r.tags || []} maxShow={2} /></td>
                <td>
                  <span className={`tag text-xs ${r.type === 'in' ? 'tag-green' : 'tag-yellow'}`}>
                    {r.type === 'in' ? '入库' : '出库'}
                  </span>
                </td>
                <td className="text-xs">{r.time}</td>
                <td>
                  <div className="flex items-center gap-1">
                    <span className="text-sm">{r.channelOrOperator}</span>
                    <span className={`tag text-xs ${r.channelType === 'auto' ? 'tag-blue' : 'tag-gray'}`}>
                      {r.channelType === 'auto' ? '智能通道' : '人工'}
                    </span>
                  </div>
                </td>
                <td>
                  <span className={`tag text-xs ${r.channelType === 'auto' ? 'tag-blue' : 'tag-purple'}`}>
                    {r.channelType === 'auto' ? '自动' : '人工'}
                  </span>
                </td>
                <td>
                  <span className={`tag text-xs ${r.legal ? 'tag-green' : 'tag-red'}`}>
                    {r.legal ? '合法' : '非法'}
                  </span>
                </td>
                <td>
                  <button
                    className="text-xs hover:underline"
                    style={{ color: 'var(--primary-blue)' }}
                    onClick={() => { setSelectedRecord(r); setDetailOpen(true) }}
                  >
                    详情
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Detail Modal */}
      {detailOpen && selectedRecord && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] flex flex-col animate-in fade-in zoom-in duration-200" style={{ maxWidth: '90vw', maxHeight: '85vh' }}>
            <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white rounded-t-xl" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-base font-semibold">出入库记录详情</h3>
              <button className="p-1 rounded-lg hover:bg-gray-100 transition-colors" onClick={() => setDetailOpen(false)}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-5 space-y-3">
              {[
                { label: '记录编号', value: selectedRecord.id },
                { label: '装备编码', value: selectedRecord.equipCode },
                { label: 'RFID编码', value: <RfidDisplay rfid={selectedRecord.rfidCode} showFull /> },
                { label: '装备名称', value: selectedRecord.equipName },
                { label: '标签', value: <TagBadges tags={selectedRecord.tags || []} size="md" maxShow={5} /> },
                { label: '操作类型', value: selectedRecord.type === 'in' ? '入库' : '出库' },
                { label: '发生时间', value: selectedRecord.time },
                { label: '通道ID / 操作人', value: selectedRecord.channelOrOperator },
                { label: '通道类型', value: selectedRecord.channelType === 'auto' ? '智能感知通道' : '人工操作' },
                { label: '合法性标志', value: selectedRecord.legal ? '合法' : '非法' },
                { label: '备注', value: selectedRecord.remark },
              ].map(f => (
                <div key={f.label} className="flex justify-between py-2 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <span style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                  <span className="font-medium text-sm">{f.value}</span>
                </div>
              ))}
            </div>
            <div className="sticky bottom-0 flex justify-end gap-2 px-5 py-4 border-t bg-white rounded-b-xl" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
