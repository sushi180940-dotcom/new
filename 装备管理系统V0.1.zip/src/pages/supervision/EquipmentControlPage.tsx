import { useState } from 'react'
import {
  ShieldCheck,
  AlertTriangle,
  Ban,
  Package,
  Search,
  Plus,
  Edit3,
  Eye,
  RefreshCw,
  Factory,
} from 'lucide-react'
import { cn } from '@/lib/utils'

type ControlStatus = '已下架' | '使用限制中' | '已冻结'
type TabKey = 'control' | 'supplier'

interface ControlRecord {
  id: string
  problemNo: string
  equipName: string
  equipModel: string
  problemDesc: string
  findTime: string
  batchNo: string
  measure: ControlStatus
  status: '生效中' | '已解除' | '待审核'
  operator: string
}

interface SupplierDisposal {
  id: string
  supplierName: string
  disposalType: string
  reason: string
  startTime: string
  endTime?: string
  status: '处理中' | '已完成'
  handler: string
}

const mockControls: ControlRecord[] = [
  { id: '1', problemNo: 'PC202405001', equipName: '防弹背心', equipModel: 'BV-III-A', problemDesc: '批次B202401防护板存在脱胶风险', findTime: '2024-05-20', batchNo: 'B202401', measure: '已下架', status: '生效中', operator: '张警官' },
  { id: '2', problemNo: 'PC202405002', equipName: '伸缩警棍', equipModel: 'JG-01', problemDesc: '锁定机构失灵，无法正常收棍', findTime: '2024-05-18', batchNo: 'B202403', measure: '使用限制中', status: '生效中', operator: '李警官' },
  { id: '3', problemNo: 'PC202405003', equipName: '执法记录仪', equipModel: 'ZF-01', problemDesc: '电池鼓包，存在安全隐患', findTime: '2024-05-15', batchNo: 'B202405', measure: '已冻结', status: '生效中', operator: '王警官' },
  { id: '4', problemNo: 'PC202405004', equipName: '防弹头盔', equipModel: 'MICH2000', problemDesc: '内衬老化严重，缓冲性能下降', findTime: '2024-05-10', batchNo: 'B202402', measure: '使用限制中', status: '已解除', operator: '赵警官' },
  { id: '5', problemNo: 'PC202405005', equipName: '手铐', equipModel: 'SK-01', problemDesc: '钥匙孔锈蚀，影响开锁', findTime: '2024-05-08', batchNo: 'B202404', measure: '已下架', status: '待审核', operator: '刘警官' },
  { id: '6', problemNo: 'PC202405006', equipName: '防刺服', equipModel: 'FC-01', problemDesc: '面料磨损，防刺层外露', findTime: '2024-05-05', batchNo: 'B202406', measure: '已下架', status: '生效中', operator: '陈警官' },
  { id: '7', problemNo: 'PC202405007', equipName: '对讲机', equipModel: 'DJ-01', problemDesc: '通话杂音大，电池续航不足', findTime: '2024-04-28', batchNo: 'B202407', measure: '使用限制中', status: '生效中', operator: '孙警官' },
  { id: '8', problemNo: 'PC202405008', equipName: '催泪喷射器', equipModel: 'CL-01', problemDesc: '压力不足，喷射距离不达标', findTime: '2024-04-20', batchNo: 'B202408', measure: '已冻结', status: '已解除', operator: '周警官' },
  { id: '9', problemNo: 'PC202405009', equipName: '约束带', equipModel: 'YS-01', problemDesc: '卡扣断裂，多次使用后失效', findTime: '2024-04-15', batchNo: 'B202409', measure: '已下架', status: '待审核', operator: '吴警官' },
]

const mockDisposals: SupplierDisposal[] = [
  { id: '1', supplierName: 'BB交通设施厂', disposalType: '暂停合作', reason: '产品质量不合格率超过15%', startTime: '2024-05-01', status: '处理中', handler: '张警官' },
  { id: '2', supplierName: 'YY警用装备有限公司', disposalType: '限期整改', reason: '合同履约率连续3月低于80%', startTime: '2024-04-15', endTime: '2024-07-15', status: '处理中', handler: '李警官' },
  { id: '3', supplierName: 'GG照明设备厂', disposalType: '终止合作', reason: '严重违约，拒绝履行售后服务', startTime: '2024-03-01', endTime: '2024-03-15', status: '已完成', handler: '王警官' },
  { id: '4', supplierName: 'CC检测仪器公司', disposalType: '警告', reason: '资质证书即将过期未及时续期', startTime: '2024-05-10', status: '处理中', handler: '赵警官' },
  { id: '5', supplierName: 'AA通信设备公司', disposalType: '暂停合作', reason: '产品存在安全缺陷', startTime: '2024-04-20', status: '处理中', handler: '刘警官' },
]

function MeasureBadge({ measure }: { measure: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      measure === '已下架' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      measure === '使用限制中' ? 'bg-[#FEF3C7] text-[#D97706]' :
      'bg-[#FFEDD5] text-[#EA580C]'
    )}>
      {measure}
    </span>
  )
}

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      status === '生效中' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      status === '待审核' ? 'bg-[#FEF3C7] text-[#D97706]' :
      'bg-[#D1FAE5] text-[#059669]'
    )}>
      {status}
    </span>
  )
}

export default function EquipmentControlPage() {
  const [activeTab, setActiveTab] = useState<TabKey>('control')
  const [searchText, setSearchText] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 8

  const filtered = activeTab === 'control'
    ? mockControls.filter((c) => {
        if (searchText && !c.problemNo.includes(searchText) && !c.equipName.includes(searchText)) return false
        if (statusFilter && c.status !== statusFilter) return false
        return true
      })
    : mockDisposals.filter((d) => {
        if (searchText && !d.supplierName.includes(searchText)) return false
        if (statusFilter && d.status !== statusFilter) return false
        return true
      })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const tabs = [
    { key: 'control' as const, label: '装备管控', icon: <ShieldCheck size={16} /> },
    { key: 'supplier' as const, label: '供应商处置', icon: <Factory size={16} /> },
  ]

  const controlStats = [
    { title: '已下架', value: 12, icon: <Ban size={16} />, bg: '#FEE2E2', color: '#DC2626' },
    { title: '使用限制中', value: 5, icon: <AlertTriangle size={16} />, bg: '#FEF3C7', color: '#D97706' },
    { title: '已冻结', value: 8, icon: <Package size={16} />, bg: '#FFEDD5', color: '#EA580C' },
  ]

  const disposalStats = [
    { title: '暂停合作', value: 3, icon: <Ban size={16} />, bg: '#FEE2E2', color: '#DC2626' },
    { title: '限期整改', value: 1, icon: <AlertTriangle size={16} />, bg: '#FEF3C7', color: '#D97706' },
    { title: '已完成处置', value: 1, icon: <ShieldCheck size={16} />, bg: '#D1FAE5', color: '#059669' },
  ]

  const stats = activeTab === 'control' ? controlStats : disposalStats

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">装备管控</h1>
        </div>
      </div>

      {/* Tabs */}
      <div className="mb-4 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => { setActiveTab(tab.key); setCurrentPage(1); setSearchText(''); setStatusFilter('') }}
              className={cn(
                'flex items-center gap-2 border-b-2 pb-3 pt-1 text-sm transition',
                activeTab === tab.key
                  ? 'border-[#1A56DB] font-medium text-[#1A56DB]'
                  : 'border-transparent text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="mb-6 grid grid-cols-3 gap-4">
        {stats.map((stat) => (
          <div
            key={stat.title}
            className="rounded-lg bg-white p-4 shadow-md transition hover:shadow-lg"
          >
            <div className="flex items-center gap-3">
              <div
                className="flex h-10 w-10 items-center justify-center rounded-full"
                style={{ backgroundColor: stat.bg }}
              >
                <span style={{ color: stat.color }}>{stat.icon}</span>
              </div>
              <div>
                <div className="text-[24px] font-bold text-[#1F2937]">{stat.value}</div>
                <div className="text-xs text-[#6B7280]">{stat.title}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filter + Actions */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder={activeTab === 'control' ? '搜索问题编号或装备名称' : '搜索供应商名称'}
              value={searchText}
              onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
              className="h-9 w-52 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
            />
          </div>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
          >
            <option value="">全部状态</option>
            {activeTab === 'control' ? (
              <>
                <option value="生效中">生效中</option>
                <option value="待审核">待审核</option>
                <option value="已解除">已解除</option>
              </>
            ) : (
              <>
                <option value="处理中">处理中</option>
                <option value="已完成">已完成</option>
              </>
            )}
          </select>
          <button
            onClick={() => { setSearchText(''); setStatusFilter(''); setCurrentPage(1) }}
            className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
          >
            <RefreshCw size={13} /> 重置
          </button>
        </div>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={14} /> {activeTab === 'control' ? '登记问题装备' : '新增处置'}
        </button>
      </div>

      {/* Data Table */}
      <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {activeTab === 'control' ? (
                  <>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">问题编号</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备信息</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">问题描述</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发现时间</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">涉及批次</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">管控措施</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">登记人</th>
                    <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </>
                ) : (
                  <>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商名称</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处置类型</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处置原因</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">开始时间</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">结束时间</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处理人</th>
                    <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </>
                )}
              </tr>
            </thead>
            <tbody>
              {activeTab === 'control'
                ? (pageData as ControlRecord[]).map((row: ControlRecord) => (
                    <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                      <td className="px-4 py-3 text-sm font-medium text-[#1A56DB]">{row.problemNo}</td>
                      <td className="px-4 py-3 text-sm text-[#374151]">
                        <div className="font-medium">{row.equipName}</div>
                        <div className="text-xs text-[#6B7280]">{row.equipModel}</div>
                      </td>
                      <td className="max-w-[200px] truncate px-4 py-3 text-sm text-[#374151]">{row.problemDesc}</td>
                      <td className="px-4 py-3 text-sm text-[#6B7280]">{row.findTime}</td>
                      <td className="px-4 py-3 text-sm text-[#6B7280]">{row.batchNo}</td>
                      <td className="px-4 py-3"><MeasureBadge measure={row.measure} /></td>
                      <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                      <td className="px-4 py-3 text-sm text-[#374151]">{row.operator}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                            <Eye size={13} />
                          </button>
                          <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                            <Edit3 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                : (pageData as SupplierDisposal[]).map((row: SupplierDisposal) => (
                    <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                      <td className="px-4 py-3 text-sm font-medium text-[#374151]">{row.supplierName}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
                          row.disposalType === '暂停合作' ? 'bg-[#FEE2E2] text-[#DC2626]' :
                          row.disposalType === '限期整改' ? 'bg-[#FEF3C7] text-[#D97706]' :
                          row.disposalType === '终止合作' ? 'bg-[#FEE2E2] text-[#DC2626]' :
                          'bg-[#E8F0FE] text-[#1A56DB]'
                        )}>
                          {row.disposalType}
                        </span>
                      </td>
                      <td className="max-w-[250px] truncate px-4 py-3 text-sm text-[#374151]">{row.reason}</td>
                      <td className="px-4 py-3 text-sm text-[#6B7280]">{row.startTime}</td>
                      <td className="px-4 py-3 text-sm text-[#6B7280]">{row.endTime || '-'}</td>
                      <td className="px-4 py-3">
                        <span className={cn(
                          'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
                          row.status === '处理中' ? 'bg-[#FEF3C7] text-[#D97706]' : 'bg-[#D1FAE5] text-[#059669]'
                        )}>
                          {row.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-sm text-[#374151]">{row.handler}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                            <Eye size={13} />
                          </button>
                          <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                            <Edit3 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    暂无数据
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &lt;
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &gt;
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
