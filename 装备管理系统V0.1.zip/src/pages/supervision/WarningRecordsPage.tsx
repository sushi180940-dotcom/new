import { useState } from 'react'
import {
  Bell,
  Clock,
  CheckCircle2,
  AlertTriangle,
  TrendingUp,
  Search,
  Eye,
  CheckCheck,
  XCircle,
  Share2,
} from 'lucide-react'
import { cn } from '@/lib/utils'

type WarningLevel = '紧急' | '警告' | '提醒'
type RecordStatus = '待处理' | '处理中' | '已处理' | '已忽略'

interface WarningRecord {
  id: string
  code: string
  type: string
  level: WarningLevel
  triggerTime: string
  target: string
  status: RecordStatus
  handler?: string
  description: string
  ruleName?: string
}

const mockRecords: WarningRecord[] = [
  { id: '1', code: 'W20240601001', type: '库存预警', level: '警告', triggerTime: '2024-06-01 09:15:00', target: '防弹背心 (BV-III-A)', status: '待处理', description: '库存数量(8)低于安全库存线(20)' },
  { id: '2', code: 'W20240601002', type: '寿命预警', level: '提醒', triggerTime: '2024-06-01 10:00:00', target: '执法记录仪 (ZF-01)', status: '待处理', description: '装备使用期限剩余28天' },
  { id: '3', code: 'W20240601003', type: '资质预警', level: '紧急', triggerTime: '2024-06-01 08:30:00', target: 'XX安防科技有限公司', status: '处理中', handler: '张警官', description: '供应商ISO9001资质将于7天后到期' },
  { id: '4', code: 'W20240601004', type: '库存预警', level: '紧急', triggerTime: '2024-05-31 23:45:00', target: '防刺服 (FC-01)', status: '处理中', handler: '李警官', description: '库存数量(2)严重不足，安全库存线为15' },
  { id: '5', code: 'W20240601005', type: '质量预警', level: '警告', triggerTime: '2024-05-31 16:20:00', target: '伸缩警棍 (JG-01) 批次B202403', status: '已处理', handler: '王警官', description: '该批次报修率达到12%，超过阈值10%' },
  { id: '6', code: 'W20240601006', type: '库存预警', level: '提醒', triggerTime: '2024-05-31 14:00:00', target: '手铐 (SK-01)', status: '已忽略', description: '库存数量(35)超过最大库存(30)' },
  { id: '7', code: 'W20240601007', type: '合同预警', level: '警告', triggerTime: '2024-05-31 11:30:00', target: 'YY警用装备有限公司', status: '已处理', handler: '赵警官', description: '供应商合同履约率降至82%' },
  { id: '8', code: 'W20240601008', type: '寿命预警', level: '紧急', triggerTime: '2024-06-01 07:00:00', target: '防弹头盔 (MICH2000) #2045', status: '待处理', description: '装备质保期将于5天后到期' },
  { id: '9', code: 'W20240601009', type: '库存预警', level: '提醒', triggerTime: '2024-05-30 22:00:00', target: '催泪喷射器', status: '已处理', handler: '刘警官', description: '装备超过180天未被领用' },
  { id: '10', code: 'W20240601010', type: '资质预警', level: '警告', triggerTime: '2024-05-30 15:45:00', target: 'CC检测仪器公司', status: '待处理', description: '供应商营业执照即将到期(剩余45天)' },
]

const stats = [
  { title: '总预警', value: 1234, icon: <Bell size={18} />, iconBg: '#E8F0FE', iconColor: '#1A56DB', trend: 12 },
  { title: '待处理', value: 156, icon: <Clock size={18} />, iconBg: '#FEE2E2', iconColor: '#DC2626', trendLabel: '需及时关注' },
  { title: '处理中', value: 48, icon: <AlertTriangle size={18} />, iconBg: '#FEF3C7', iconColor: '#D97706' },
  { title: '已处理', value: 1020, icon: <CheckCircle2 size={18} />, iconBg: '#D1FAE5', iconColor: '#059669' },
  { title: '已忽略', value: 10, icon: <XCircle size={18} />, iconBg: '#F3F4F6', iconColor: '#6B7280' },
]

function LevelBadge({ level }: { level: WarningLevel }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      level === '紧急' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      level === '警告' ? 'bg-[#FEF3C7] text-[#D97706]' :
      'bg-[#DBEAFE] text-[#2563EB]'
    )}>
      {level}
    </span>
  )
}

function StatusBadge({ status }: { status: RecordStatus }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      status === '待处理' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      status === '处理中' ? 'bg-[#FEF3C7] text-[#D97706]' :
      status === '已处理' ? 'bg-[#D1FAE5] text-[#059669]' :
      'bg-[#F3F4F6] text-[#6B7280]'
    )}>
      {status}
    </span>
  )
}

export default function WarningRecordsPage() {
  const [searchText, setSearchText] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [levelFilter, setLevelFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  const filtered = mockRecords.filter((r) => {
    if (searchText && !r.code.includes(searchText) && !r.target.includes(searchText)) return false
    if (typeFilter && r.type !== typeFilter) return false
    if (levelFilter && r.level !== levelFilter) return false
    if (statusFilter && r.status !== statusFilter) return false
    return true
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const getRowBg = (level: WarningLevel) => {
    switch (level) {
      case '紧急': return 'bg-[#FEE2E2]/30'
      case '警告': return 'bg-[#FEF3C7]/30'
      case '提醒': return 'bg-white'
    }
  }

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">预警记录</h1>
        </div>
      </div>

      {/* Stats Row */}
      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-5">
        {stats.map((stat) => (
          <div
            key={stat.title}
            className="rounded-lg bg-white p-4 shadow-md transition hover:shadow-lg"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div
                  className="flex h-9 w-9 items-center justify-center rounded-full"
                  style={{ backgroundColor: stat.iconBg }}
                >
                  <span style={{ color: stat.iconColor }}>{stat.icon}</span>
                </div>
                <span className="text-sm text-[#6B7280]">{stat.title}</span>
              </div>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <span className="text-[24px] font-bold text-[#1F2937]">{stat.value.toLocaleString()}</span>
              {stat.trend !== undefined && (
                <span className="flex items-center gap-0.5 text-xs text-[#EF4444]">
                  <TrendingUp size={12} />
                  +{stat.trend}
                </span>
              )}
              {stat.trendLabel && (
                <span className="text-xs text-[#EF4444]">{stat.trendLabel}</span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Filter Bar */}
      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder="搜索预警编号或关联对象"
              value={searchText}
              onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
              className="h-9 w-52 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
          >
            <option value="">全部类型</option>
            <option value="库存预警">库存预警</option>
            <option value="寿命预警">寿命预警</option>
            <option value="资质预警">资质预警</option>
            <option value="质量预警">质量预警</option>
            <option value="合同预警">合同预警</option>
          </select>
          <select
            value={levelFilter}
            onChange={(e) => { setLevelFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-24 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
          >
            <option value="">全部级别</option>
            <option value="紧急">紧急</option>
            <option value="警告">警告</option>
            <option value="提醒">提醒</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-24 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
          >
            <option value="">全部状态</option>
            <option value="待处理">待处理</option>
            <option value="处理中">处理中</option>
            <option value="已处理">已处理</option>
            <option value="已忽略">已忽略</option>
          </select>
          <button
            onClick={() => { setSearchText(''); setTypeFilter(''); setLevelFilter(''); setStatusFilter(''); setCurrentPage(1) }}
            className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
          >
            重置
          </button>
        </div>
      </div>

      {/* Data Table */}
      <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="w-10 px-3 py-3 text-center">
                  <input type="checkbox" className="rounded border-[#D1D5DB]" />
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预警编号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预警类型</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">级别</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">触发时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">关联对象</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处理人</th>
                <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((row) => (
                <>
                  <tr
                    key={row.id}
                    className={cn(
                      'cursor-pointer border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]',
                      getRowBg(row.level)
                    )}
                    onClick={() => setExpandedId(expandedId === row.id ? null : row.id)}
                  >
                    <td className="px-3 py-3 text-center" onClick={(e) => e.stopPropagation()}>
                      <input type="checkbox" className="rounded border-[#D1D5DB]" />
                    </td>
                    <td className="px-4 py-3 text-sm font-medium text-[#1A56DB]">{row.code}</td>
                    <td className="px-4 py-3 text-sm text-[#374151]">{row.type}</td>
                    <td className="px-4 py-3"><LevelBadge level={row.level} /></td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">{row.triggerTime}</td>
                    <td className="max-w-[180px] truncate px-4 py-3 text-sm text-[#374151]">{row.target}</td>
                    <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">{row.handler || '-'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="查看">
                          <Eye size={13} />
                        </button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#10B981] transition hover:bg-[#D1FAE5]" title="处理">
                          <CheckCheck size={13} />
                        </button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#D97706] transition hover:bg-[#FEF3C7]" title="转交">
                          <Share2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                  {expandedId === row.id && (
                    <tr className="border-b border-[#F3F4F6] bg-[#F9FAFB]">
                      <td colSpan={9} className="px-4 py-4">
                        <div className="rounded-lg border border-[#E5E7EB] bg-white p-4">
                          <div className="mb-2 text-sm font-medium text-[#1F2937]">预警详情</div>
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-[#6B7280]">触发规则: </span>
                              <span className="text-[#374151]">{row.ruleName}</span>
                            </div>
                            <div>
                              <span className="text-[#6B7280]">预警描述: </span>
                              <span className="text-[#374151]">{row.description}</span>
                            </div>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    暂无数据
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &lt;
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &gt;
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
