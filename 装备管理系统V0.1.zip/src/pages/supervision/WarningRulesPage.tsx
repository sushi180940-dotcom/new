import { useState } from 'react'
import { Plus, Upload, Edit3, Trash2, Bell, AlertTriangle, AlertCircle, Info } from 'lucide-react'
import { cn } from '@/lib/utils'

type WarningLevel = '紧急' | '警告' | '提醒'

interface WarningRule {
  id: string
  name: string
  description: string
  conditions: string[]
  level: WarningLevel
  frequency: string
  category: string
  enabled: boolean
}

const mockRules: WarningRule[] = [
  {
    id: '1',
    name: '库存安全线预警',
    description: '当装备库存低于安全库存时触发预警，连续触发时需重点关注补货。',
    conditions: ['库存<安全线', '连续3天'],
    level: '警告',
    frequency: '每日',
    category: '库存预警',
    enabled: true,
  },
  {
    id: '2',
    name: '装备质保到期预警',
    description: '装备质保期限前30天提醒，确保及时处理质保期内问题。',
    conditions: ['质保到期<30天'],
    level: '提醒',
    frequency: '每日',
    category: '寿命预警',
    enabled: true,
  },
  {
    id: '3',
    name: '供应商资质到期',
    description: '供应商资质证书到期前预警，避免资质过期影响采购。',
    conditions: ['资质到期<90天'],
    level: '紧急',
    frequency: '即时',
    category: '资质预警',
    enabled: true,
  },
  {
    id: '4',
    name: '装备寿命到期',
    description: '装备达到使用年限时预警，需要及时更新换代。',
    conditions: ['使用年限剩余<90天'],
    level: '警告',
    frequency: '每周',
    category: '寿命预警',
    enabled: false,
  },
  {
    id: '5',
    name: '库存超储预警',
    description: '装备库存超过最大库存时预警，避免资金占用过多。',
    conditions: ['库存>最大库存'],
    level: '提醒',
    frequency: '每日',
    category: '库存预警',
    enabled: true,
  },
  {
    id: '6',
    name: '长时间未使用预警',
    description: '装备超过180天未被领用，可能存在积压或需求变化。',
    conditions: ['未使用>180天'],
    level: '提醒',
    frequency: '每周',
    category: '库存预警',
    enabled: true,
  },
  {
    id: '7',
    name: '供应商投诉累积预警',
    description: '同一供应商累计投诉超过3次时触发预警。',
    conditions: ['投诉次数>=3', '30天内'],
    level: '警告',
    frequency: '即时',
    category: '质量预警',
    enabled: true,
  },
  {
    id: '8',
    name: '合同履约率异常',
    description: '供应商合同履约率低于85%时触发预警。',
    conditions: ['履约率<85%'],
    level: '紧急',
    frequency: '每周',
    category: '合同预警',
    enabled: true,
  },
  {
    id: '9',
    name: '装备报修率异常',
    description: '同一批次装备报修率超过10%时触发质量预警。',
    conditions: ['报修率>10%', '同批次'],
    level: '警告',
    frequency: '每周',
    category: '质量预警',
    enabled: true,
  },
]

const categoryFilters = [
  { key: '全部', count: mockRules.length },
  { key: '库存预警', count: mockRules.filter(r => r.category === '库存预警').length },
  { key: '寿命预警', count: mockRules.filter(r => r.category === '寿命预警').length },
  { key: '资质预警', count: mockRules.filter(r => r.category === '资质预警').length },
  { key: '质量预警', count: mockRules.filter(r => r.category === '质量预警').length },
  { key: '合同预警', count: mockRules.filter(r => r.category === '合同预警').length },
]

const levelConfig: Record<WarningLevel, { color: string; bg: string; border: string; icon: React.ReactNode }> = {
  '紧急': {
    color: 'text-[#DC2626]',
    bg: 'bg-[#FEE2E2]',
    border: 'border-t-[#EF4444]',
    icon: <AlertTriangle size={14} />,
  },
  '警告': {
    color: 'text-[#D97706]',
    bg: 'bg-[#FEF3C7]',
    border: 'border-t-[#F59E0B]',
    icon: <AlertCircle size={14} />,
  },
  '提醒': {
    color: 'text-[#1A56DB]',
    bg: 'bg-[#DBEAFE]',
    border: 'border-t-[#3B82F6]',
    icon: <Info size={14} />,
  },
}

function LevelBadge({ level }: { level: WarningLevel }) {
  const config = levelConfig[level]
  return (
    <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium', config.bg, config.color)}>
      {config.icon}
      {level}
    </span>
  )
}

export default function WarningRulesPage() {
  const [activeCategory, setActiveCategory] = useState('全部')
  const [rules, setRules] = useState(mockRules)
  const [hoveredId, setHoveredId] = useState<string | null>(null)

  const filtered = activeCategory === '全部'
    ? rules
    : rules.filter((r) => r.category === activeCategory)

  const toggleEnabled = (id: string) => {
    setRules((prev) => prev.map((r) => r.id === id ? { ...r, enabled: !r.enabled } : r))
  }

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">预警规则</h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 新增规则
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Upload size={14} /> 导入模板
          </button>
        </div>
      </div>

      {/* Category Filter */}
      <div className="mb-4 flex flex-wrap gap-2">
        {categoryFilters.map((cat) => (
          <button
            key={cat.key}
            onClick={() => setActiveCategory(cat.key)}
            className={cn(
              'inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm transition',
              activeCategory === cat.key
                ? 'bg-[#1A56DB] font-medium text-white'
                : 'border border-[#D1D5DB] bg-white text-[#374151] hover:bg-[#E8F0FE]'
            )}
          >
            {cat.key}
            <span className={cn(
              'flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[11px] font-bold',
              activeCategory === cat.key ? 'bg-white/20 text-white' : 'bg-[#F3F4F6] text-[#6B7280]'
            )}>
              {cat.count}
            </span>
          </button>
        ))}
      </div>

      {/* Rule Cards Grid */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {filtered.map((rule) => {
          const config = levelConfig[rule.level]
          return (
            <div
              key={rule.id}
              className={cn(
                'relative rounded-lg bg-white p-5 shadow-md transition-all duration-150 hover:shadow-lg',
                'border-t-4',
                config.border
              )}
              onMouseEnter={() => setHoveredId(rule.id)}
              onMouseLeave={() => setHoveredId(null)}
            >
              {/* Hover actions */}
              {hoveredId === rule.id && (
                <div className="absolute right-4 top-4 z-10 flex items-center gap-1 rounded-md bg-white/95 p-1 shadow-md">
                  <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                    <Edit3 size={14} />
                  </button>
                  <button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]">
                    <Trash2 size={14} />
                  </button>
                </div>
              )}

              {/* Rule name */}
              <h3 className="mb-1 text-base font-semibold text-[#1F2937]">{rule.name}</h3>

              {/* Description */}
              <p className="mb-3 line-clamp-2 text-[13px] leading-relaxed text-[#6B7280]">
                {rule.description}
              </p>

              {/* Conditions */}
              <div className="mb-3">
                <span className="mb-1 block text-xs text-[#6B7280]">触发条件:</span>
                <div className="flex flex-wrap gap-1.5">
                  {rule.conditions.map((cond, idx) => (
                    <span
                      key={idx}
                      className="rounded-full bg-[#F3F4F6] px-2.5 py-0.5 text-[11px] text-[#374151]"
                    >
                      {cond}
                    </span>
                  ))}
                </div>
              </div>

              {/* Tags row */}
              <div className="mb-4 flex items-center gap-2">
                <LevelBadge level={rule.level} />
                <span className="rounded-full bg-[#E8F0FE] px-2.5 py-0.5 text-[11px] text-[#1A56DB]">
                  {rule.frequency}
                </span>
                <span className="rounded-full bg-[#F3F4F6] px-2.5 py-0.5 text-[11px] text-[#6B7280]">
                  {rule.category}
                </span>
              </div>

              {/* Bottom: switch + actions */}
              <div className="flex items-center justify-between border-t border-[#F3F4F6] pt-3">
                <button
                  onClick={() => toggleEnabled(rule.id)}
                  className={cn(
                    'relative inline-flex h-[22px] w-10 items-center rounded-full transition-colors',
                    rule.enabled ? 'bg-[#1A56DB]' : 'bg-[#D1D5DB]'
                  )}
                >
                  <span
                    className={cn(
                      'inline-block h-[18px] w-[18px] transform rounded-full bg-white transition-transform',
                      rule.enabled ? 'translate-x-5' : 'translate-x-0.5'
                    )}
                  />
                </button>
                <span className={cn('text-xs', rule.enabled ? 'text-[#059669]' : 'text-[#9CA3AF]')}>
                  {rule.enabled ? '已启用' : '已停用'}
                </span>
              </div>
            </div>
          )
        })}
      </div>

      {filtered.length === 0 && (
        <div className="flex flex-col items-center py-16 text-[#9CA3AF]">
          <Bell size={48} className="mb-3 opacity-30" />
          <p className="text-sm">该分类暂无预警规则</p>
        </div>
      )}
    </div>
  )
}
