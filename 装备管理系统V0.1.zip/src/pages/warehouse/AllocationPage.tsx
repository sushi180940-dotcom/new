import { useState } from 'react'
import {
  Plus,
  Eye,
  Edit,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Tabs ─── */
const tabs = [
  { key: 'apply', label: '装备申请', count: 6 },
  { key: 'approve', label: '配发审批', count: 4 },
  { key: 'outbound', label: '配发出库', count: 3 },
  { key: 'confirm', label: '接收确认', count: 5 },
]

/* ─── Status badge ─── */
function AllocStatus({ status }: { status: string }) {
  switch (status) {
    case 'draft': return <Badge variant="default">草稿</Badge>
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'approved': return <Badge variant="success" dot>已通过</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    case 'picking': return <Badge variant="info" dot>拣货中</Badge>
    case 'ready': return <Badge variant="primary" dot>待出库</Badge>
    case 'outbound': return <Badge variant="info" dot>运输中</Badge>
    case 'delivered': return <Badge variant="primary" dot>已送达</Badge>
    case 'confirmed': return <Badge variant="success" dot>已确认</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock allocation data ─── */
const allocData = [
  { id: 'PF20260603001', station: '鼓楼分局巡特警大队', applicant: '王警官', items: '防弹背心x20, 防刺服x20, 头盔x20, 警棍x20', total: 80, time: '2026-06-03 09:00', status: 'pending-approve' as const },
  { id: 'PF20260603002', station: '玄武分局治安大队', applicant: '李警官', items: '执法记录仪x30, 对讲机x30', total: 60, time: '2026-06-02 14:30', status: 'approved' as const },
  { id: 'PF20260603003', station: '建邺分局刑警大队', applicant: '张警官', items: '手铐x50, 约束带x100', total: 150, time: '2026-06-02 10:00', status: 'picking' as const },
  { id: 'PF20260603004', station: '浦口分局交警大队', applicant: '赵警官', items: '反光背心x100, 警示桩x50', total: 150, time: '2026-06-01 16:00', status: 'outbound' as const },
  { id: 'PF20260603005', station: '栖霞分局派出所', applicant: '刘警官', items: '防弹背心x10, 防刺服x10, 执法记录仪x10', total: 30, time: '2026-06-01 09:00', status: 'delivered' as const },
  { id: 'PF20260603006', station: '雨花台分局特警大队', applicant: '陈警官', items: '防暴服x20, 防弹盾牌x10, 头盔x20', total: 50, time: '2026-05-31 11:30', status: 'confirmed' as const },
  { id: 'PF20260603007', station: '江宁分局指挥中心', applicant: '杨警官', items: '对讲机x20, 执法记录仪x10', total: 30, time: '2026-05-30 15:00', status: 'pending-approve' as const },
  { id: 'PF20260603008', station: '六合分局治安大队', applicant: '周警官', items: '警棍x30, 手铐x30, 防割手套x50', total: 110, time: '2026-05-29 10:00', status: 'confirmed' as const },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'allocNo', label: '配发单号', type: 'input' as const, placeholder: '请输入配发单号' },
  { key: 'station', label: '申请单位', type: 'input' as const, placeholder: '请输入申请单位' },
  { key: 'applicant', label: '申请人', type: 'input' as const, placeholder: '请输入申请人' },
  { key: 'dateStart', label: '申请时间（起）', type: 'date' as const },
  { key: 'dateEnd', label: '申请时间（止）', type: 'date' as const },
]

export default function AllocationPage() {
  const [activeTab, setActiveTab] = useState('apply')
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const filteredData = allocData.filter((row) => {
    if (activeTab === 'apply') return ['draft', 'pending-approve'].includes(row.status)
    if (activeTab === 'approve') return ['pending-approve', 'approved', 'rejected'].includes(row.status)
    if (activeTab === 'outbound') return ['picking', 'ready', 'outbound'].includes(row.status)
    if (activeTab === 'confirm') return ['delivered', 'confirmed'].includes(row.status)
    return true
  })

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">所队装备配发</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={14} /> 新建配发申请
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Allocation table */}
      <div className="mt-4">
        <DataTable
          title="配发单据列表"
          columns={[
            { key: 'id', title: '配发单号', width: '140px' },
            { key: 'station', title: '申请单位', width: '180px' },
            { key: 'applicant', title: '申请人', width: '100px' },
            { key: 'items', title: '装备清单', width: '260px', render: (row) => (
              <span className="line-clamp-2 text-[#374151]">{row.items}</span>
            )},
            { key: 'total', title: '总件数', width: '70px', render: (row) => <span className="font-medium">{row.total}</span> },
            { key: 'time', title: '申请时间', width: '130px' },
            { key: 'status', title: '状态', width: '90px', render: (row) => <AllocStatus status={row.status} /> },
          ]}
          data={filteredData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
