import { useState } from 'react'
import {
  Plus,
  Eye,
  Edit,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Tabs ─── */
const tabs = [
  { key: 'planned', label: '盘点计划', count: 3 },
  { key: 'ongoing', label: '进行中', count: 2 },
  { key: 'completed', label: '已完成', count: 0 },
]

/* ─── Method badge ─── */
function MethodBadge({ method }: { method: string }) {
  switch (method) {
    case 'manual': return <Badge variant="warning">人工</Badge>
    case 'rfid': return <Badge variant="primary">RFID</Badge>
    case 'barcode': return <Badge variant="info">条码</Badge>
    default: return <Badge variant="default">{method}</Badge>
  }
}

/* ─── Status badge ─── */
function InventoryStatus({ status }: { status: string }) {
  switch (status) {
    case 'planned': return <Badge variant="default">计划中</Badge>
    case 'ongoing': return <Badge variant="info" dot>进行中</Badge>
    case 'paused': return <Badge variant="warning" dot>已暂停</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    case 'cancelled': return <Badge variant="danger">已取消</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock inventory data ─── */
const inventoryData = [
  { id: 'PD20260603001', name: '2026年第二季度全面盘点', scope: '全部仓库（A/B/C区）', method: 'rfid', startDate: '2026-06-15', endDate: '2026-06-20', assignee: '张管理员', status: 'planned' as const, progress: 0 },
  { id: 'PD20260603002', name: 'A区防护装备专项盘点', scope: 'A区（防弹背心/防刺服/头盔）', method: 'barcode', startDate: '2026-06-10', endDate: '2026-06-12', assignee: '李管理员', status: 'planned' as const, progress: 0 },
  { id: 'PD20260603003', name: '执法装备月度抽盘', scope: 'C区（执法记录仪/对讲机）', method: 'manual', startDate: '2026-06-05', endDate: '2026-06-05', assignee: '王警官', status: 'planned' as const, progress: 0 },
  { id: 'PD20260603004', name: '2026年5月月度盘点', scope: '全部仓库', method: 'rfid', startDate: '2026-05-25', endDate: '2026-05-28', assignee: '赵管理员', status: 'ongoing' as const, progress: 68 },
  { id: 'PD20260603005', name: 'B区通信设备盘点', scope: 'B区（对讲机/执法记录仪/测速仪）', method: 'barcode', startDate: '2026-05-28', endDate: '2026-05-30', assignee: '刘警官', status: 'ongoing' as const, progress: 45 },
  { id: 'PD20260603006', name: '2026年第一季度全面盘点', scope: '全部仓库（A/B/C区）', method: 'rfid', startDate: '2026-03-15', endDate: '2026-03-22', assignee: '张管理员', status: 'completed' as const, progress: 100 },
  { id: 'PD20260603007', name: '应急装备专项盘点', scope: '应急专区', method: 'manual', startDate: '2026-04-10', endDate: '2026-04-11', assignee: '陈警官', status: 'completed' as const, progress: 100 },
  { id: 'PD20260603008', name: 'A区新增装备入库盘点', scope: 'A区新入库装备', method: 'barcode', startDate: '2026-04-20', endDate: '2026-04-21', assignee: '杨管理员', status: 'completed' as const, progress: 100 },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'planNo', label: '盘点计划编号', type: 'input' as const, placeholder: '请输入盘点计划编号' },
  { key: 'name', label: '计划名称', type: 'input' as const, placeholder: '请输入计划名称' },
  { key: 'method', label: '盘点方式', type: 'select' as const, options: [
    { label: '人工', value: 'manual' },
    { label: 'RFID', value: 'rfid' },
    { label: '条码', value: 'barcode' },
  ]},
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '计划中', value: 'planned' },
    { label: '进行中', value: 'ongoing' },
    { label: '已暂停', value: 'paused' },
    { label: '已完成', value: 'completed' },
  ]},
  { key: 'assignee', label: '负责人', type: 'input' as const, placeholder: '请输入负责人' },
]

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('planned')
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const filteredData = inventoryData.filter((row) => {
    if (activeTab === 'planned') return row.status === 'planned'
    if (activeTab === 'ongoing') return row.status === 'ongoing' || row.status === 'completed'
    if (activeTab === 'completed') return row.status === 'completed'
    return true
  })

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备盘点</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={14} /> 新建盘点计划
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Inventory table */}
      <div className="mt-4">
        <DataTable
          title="盘点计划列表"
          columns={[
            { key: 'id', title: '计划编号', width: '140px' },
            { key: 'name', title: '计划名称', width: '200px' },
            { key: 'scope', title: '盘点范围', width: '240px', render: (row) => (
              <span className="line-clamp-2 text-[#374151]">{row.scope}</span>
            )},
            { key: 'method', title: '方式', width: '70px', render: (row) => <MethodBadge method={row.method} /> },
            { key: 'dateRange', title: '盘点时间', width: '160px', render: (row) => (
              <span className="text-[#374151]">{row.startDate} ~ {row.endDate}</span>
            )},
            { key: 'assignee', title: '负责人', width: '100px' },
            { key: 'progress', title: '进度', width: '100px', render: (row) => (
              row.progress > 0 ? (
                <div className="w-full">
                  <div className="mb-1 flex justify-between text-xs">
                    <span className="text-[#1A56DB] font-medium">{row.progress}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-[#E5E7EB]">
                    <div
                      className={cn(
                        'h-2 rounded-full transition-all',
                        row.progress === 100 ? 'bg-[#10B981]' : 'bg-[#1A56DB]'
                      )}
                      style={{ width: `${row.progress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <span className="text-xs text-[#9CA3AF]">未开始</span>
              )
            )},
            { key: 'status', title: '状态', width: '90px', render: (row) => <InventoryStatus status={row.status} /> },
          ]}
          data={filteredData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
