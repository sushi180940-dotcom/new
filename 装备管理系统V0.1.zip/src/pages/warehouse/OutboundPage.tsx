import { useState } from 'react'
import {
  UserCheck,
  ArrowRightLeft,
  Truck,
  Wrench,
  Trash2,
  Eye,
  Edit,
  Printer,
} from 'lucide-react'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Quick access types ─── */
const outboundTypes = [
  { key: 'issue', label: '领用出库', icon: <UserCheck size={24} />, color: '#1A56DB', bg: '#E8F0FE', desc: '个人领用装备' },
  { key: 'transfer', label: '调拨出库', icon: <ArrowRightLeft size={24} />, color: '#8B5CF6', bg: '#EDE9FE', desc: '跨仓库调拨' },
  { key: 'allocate', label: '配发出库', icon: <Truck size={24} />, color: '#10B981', bg: '#D1FAE5', desc: '所队配发装备' },
  { key: 'repair', label: '报修出库', icon: <Wrench size={24} />, color: '#F59E0B', bg: '#FEF3C7', desc: '送修装备出库' },
  { key: 'scrap', label: '报废出库', icon: <Trash2 size={24} />, color: '#EF4444', bg: '#FEE2E2', desc: '报废装备处置' },
]

/* ─── Mock outbound data ─── */
const outboundData = [
  { id: 'CK20260603001', type: 'issue', time: '2026-06-03 09:15', operator: '王警官', qty: 5, status: 'pending' as const, items: '防弹背心x1, 手铐x2, 执法记录仪x1, 警棍x1' },
  { id: 'CK20260603002', type: 'transfer', time: '2026-06-03 08:30', operator: '李管理员', qty: 50, status: 'completed' as const, items: '防弹背心x50' },
  { id: 'CK20260603003', type: 'allocate', time: '2026-06-02 14:00', operator: '张警官', qty: 120, status: 'completed' as const, items: '防刺服x40, 头盔x40, 反光背心x40' },
  { id: 'CK20260603004', type: 'repair', time: '2026-06-02 10:20', operator: '赵管理员', qty: 12, status: 'processing' as const, items: '执法记录仪x8, 对讲机x4' },
  { id: 'CK20260603005', type: 'scrap', time: '2026-06-01 16:45', operator: '刘警官', qty: 3, status: 'completed' as const, items: '夜视仪x2, 测速仪x1' },
  { id: 'CK20260603006', type: 'issue', time: '2026-06-01 09:00', operator: '陈警官', qty: 4, status: 'completed' as const, items: '防弹背心x1, 防刺服x1, 手铐x1, 警棍x1' },
  { id: 'CK20260603007', type: 'transfer', time: '2026-05-31 15:30', operator: '李管理员', qty: 200, status: 'processing' as const, items: '手铐x200' },
  { id: 'CK20260603008', type: 'allocate', time: '2026-05-31 11:00', operator: '张警官', qty: 80, status: 'pending' as const, items: '执法记录仪x40, 对讲机x40' },
  { id: 'CK20260603009', type: 'issue', time: '2026-05-30 08:45', operator: '杨警官', qty: 3, status: 'completed' as const, items: '防弹背心x1, 头盔x1, 防割手套x1' },
  { id: 'CK20260603010', type: 'repair', time: '2026-05-30 10:15', operator: '赵管理员', qty: 6, status: 'pending' as const, items: '对讲机x6' },
]

/* ─── Type badge helper ─── */
function TypeBadge({ type }: { type: string }) {
  switch (type) {
    case 'issue': return <Badge variant="primary">领用</Badge>
    case 'transfer': return <Badge variant="info">调拨</Badge>
    case 'allocate': return <Badge variant="success">配发</Badge>
    case 'repair': return <Badge variant="warning">报修</Badge>
    case 'scrap': return <Badge variant="danger">报废</Badge>
    default: return <Badge variant="default">{type}</Badge>
  }
}

/* ─── Status badge helper ─── */
function StatusBadge2({ status }: { status: string }) {
  switch (status) {
    case 'pending': return <Badge variant="warning" dot>待出库</Badge>
    case 'processing': return <Badge variant="info" dot>出库中</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'outboundNo', label: '出库单号', type: 'input' as const, placeholder: '请输入出库单号' },
  { key: 'type', label: '出库类型', type: 'select' as const, options: [
    { label: '领用出库', value: 'issue' },
    { label: '调拨出库', value: 'transfer' },
    { label: '配发出库', value: 'allocate' },
    { label: '报修出库', value: 'repair' },
    { label: '报废出库', value: 'scrap' },
  ]},
  { key: 'dateStart', label: '时间（起）', type: 'date' as const },
  { key: 'dateEnd', label: '时间（止）', type: 'date' as const },
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '待出库', value: 'pending' },
    { label: '出库中', value: 'processing' },
    { label: '已完成', value: 'completed' },
  ]},
]

export default function OutboundPage() {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">出库管理</h1>
      </div>

      {/* Quick access type cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {outboundTypes.map((t) => (
          <button
            key={t.key}
            className="group flex items-center gap-3 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition hover:shadow-md"
          >
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full"
              style={{ backgroundColor: t.bg }}
            >
              <span style={{ color: t.color }}>{t.icon}</span>
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-[#1F2937]">{t.label}</p>
              <p className="text-xs text-[#6B7280]">{t.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Filter panel */}
      <FilterPanel
        fields={filterFields}
        values={filterValues}
        onChange={handleFilterChange}
        onSearch={handleSearch}
        onReset={handleReset}
      />

      {/* Outbound table */}
      <div className="mt-4">
        <DataTable
          title="出库单据列表"
          columns={[
            { key: 'id', title: '出库单号', width: '150px' },
            { key: 'type', title: '类型', width: '80px', render: (row) => <TypeBadge type={row.type} /> },
            { key: 'items', title: '装备清单', width: '240px' },
            { key: 'time', title: '出库时间', width: '140px' },
            { key: 'operator', title: '经办人', width: '100px' },
            { key: 'qty', title: '数量', width: '60px', render: (row) => <span className="font-medium">{row.qty}</span> },
            { key: 'status', title: '状态', width: '90px', render: (row) => <StatusBadge2 status={row.status} /> },
          ]}
          data={outboundData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Printer size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
