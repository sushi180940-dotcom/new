import { useState } from 'react'
import {
  Zap,
  ClipboardCheck,
  FilePlus,
  Eye,
  Edit,
  ArrowRight,
  Printer,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Quick action entries ─── */
const actionEntries = [
  { key: 'quick', label: '快速调拨', icon: <Zap size={22} />, color: '#DC2626', bg: '#FEE2E2', desc: '紧急场景直接调拨' },
  { key: 'approve', label: '审批调拨', icon: <ClipboardCheck size={22} />, color: '#1A56DB', bg: '#E8F0FE', desc: '常规审批流程调拨' },
  { key: 'plan', label: '调拨方案制定', icon: <FilePlus size={22} />, color: '#059669', bg: '#D1FAE5', desc: '批量调拨计划编制' },
]

/* ─── Tabs ─── */
const tabs = [
  { key: 'ongoing', label: '进行中', count: 5 },
  { key: 'completed', label: '已完成', count: 0 },
  { key: 'quick-records', label: '快速调拨记录', count: 0 },
]

/* ─── Status badge ─── */
function TransferStatus({ status }: { status: string }) {
  switch (status) {
    case 'draft': return <Badge variant="default">草稿</Badge>
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'approved': return <Badge variant="info" dot>已批准</Badge>
    case 'in-transit': return <Badge variant="primary" dot>运输中</Badge>
    case 'received': return <Badge variant="success" dot>已接收</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock transfer data ─── */
const transferData = [
  { id: 'DB20260603001', from: '市局装备仓库A区', to: '鼓楼分局装备室', qty: 50, type: 'normal', applicant: '张警官', time: '2026-06-03 08:30', status: 'in-transit' as const, items: '防弹背心x30, 防刺服x20' },
  { id: 'DB20260603002', from: '市局装备仓库B区', to: '玄武分局器材库', qty: 120, type: 'normal', applicant: '李管理员', time: '2026-06-02 14:00', status: 'pending-approve' as const, items: '手铐x100, 警棍x20' },
  { id: 'DB20260603003', from: '市局装备仓库C区', to: '建邺分局仓库', qty: 200, type: 'normal', applicant: '王警官', time: '2026-06-02 10:00', status: 'approved' as const, items: '反光背心x200' },
  { id: 'DB20260603004', from: '市局装备仓库A区', to: '浦口分局装备库', qty: 40, type: 'quick', applicant: '赵警官', time: '2026-06-01 22:15', status: 'received' as const, items: '防弹背心x20, 头盔x20' },
  { id: 'DB20260603005', from: '市局装备仓库B区', to: '栖霞分局器材室', qty: 80, type: 'normal', applicant: '刘管理员', time: '2026-06-01 16:30', status: 'completed' as const, items: '执法记录仪x40, 对讲机x40' },
  { id: 'DB20260603006', from: '市局装备仓库A区', to: '雨花台分局装备库', qty: 60, type: 'normal', applicant: '陈警官', time: '2026-05-31 09:00', status: 'in-transit' as const, items: '防刺服x40, 防割手套x20' },
  { id: 'DB20260603007', from: '市局装备仓库C区', to: '江宁分局仓库', qty: 150, type: 'normal', applicant: '杨警官', time: '2026-05-30 14:00', status: 'completed' as const, items: '警示桩x150' },
  { id: 'DB20260603008', from: '市局装备仓库B区', to: '六合分局装备室', qty: 30, type: 'quick', applicant: '周警官', time: '2026-05-29 20:00', status: 'completed' as const, items: '防弹盾牌x15, 防暴服x15' },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'transferNo', label: '调拨单号', type: 'input' as const, placeholder: '请输入调拨单号' },
  { key: 'from', label: '调出仓库', type: 'input' as const, placeholder: '请输入调出仓库' },
  { key: 'to', label: '调入仓库', type: 'input' as const, placeholder: '请输入调入仓库' },
  { key: 'type', label: '调拨类型', type: 'select' as const, options: [
    { label: '常规调拨', value: 'normal' },
    { label: '快速调拨', value: 'quick' },
  ]},
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '草稿', value: 'draft' },
    { label: '待审批', value: 'pending-approve' },
    { label: '已批准', value: 'approved' },
    { label: '运输中', value: 'in-transit' },
    { label: '已接收', value: 'received' },
    { label: '已完成', value: 'completed' },
  ]},
]

export default function TransferPage() {
  const [activeTab, setActiveTab] = useState('ongoing')
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const filteredData = transferData.filter((row) => {
    if (activeTab === 'ongoing') return ['pending-approve', 'approved', 'in-transit', 'received'].includes(row.status)
    if (activeTab === 'completed') return row.status === 'completed'
    if (activeTab === 'quick-records') return row.type === 'quick'
    return true
  })

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">调拨管理</h1>
      </div>

      {/* Quick action entries */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {actionEntries.map((entry) => (
          <button
            key={entry.key}
            className="group flex items-center gap-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition hover:shadow-md"
          >
            <div
              className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full"
              style={{ backgroundColor: entry.bg }}
            >
              <span style={{ color: entry.color }}>{entry.icon}</span>
            </div>
            <div className="text-left">
              <p className="text-base font-semibold text-[#1F2937]">{entry.label}</p>
              <p className="text-xs text-[#6B7280]">{entry.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Transfer table */}
      <div className="mt-4">
        <DataTable
          title="调拨单据列表"
          columns={[
            { key: 'id', title: '调拨单号', width: '140px' },
            { key: 'from', title: '调出仓库', width: '150px' },
            { key: 'arrow', title: '', width: '30px', render: () => <ArrowRight size={14} className="text-[#D1D5DB]" /> },
            { key: 'to', title: '调入仓库', width: '150px' },
            { key: 'items', title: '装备清单', width: '200px' },
            { key: 'qty', title: '数量', width: '60px', render: (row) => <span className="font-medium">{row.qty}</span> },
            { key: 'applicant', title: '申请人', width: '100px' },
            { key: 'time', title: '申请时间', width: '130px' },
            { key: 'status', title: '状态', width: '90px', render: (row) => <TransferStatus status={row.status} /> },
          ]}
          data={filteredData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Printer size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
