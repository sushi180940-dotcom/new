import { useState } from 'react'
import {
  Package,
  Layers,
  MapPin,
  BarChart3,
  Edit,
  Tag,
  Ban,
  ArrowRightLeft,
  AlertTriangle,
  Trash2,
  Printer,
  ChevronDown,
} from 'lucide-react'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import StatCard from '@/components/StatCard'
import FilterPanel from '@/components/FilterPanel'

/* ─── Quick stats ─── */
const stats = [
  { icon: <Package size={20} />, iconBg: '#E8F0FE', iconColor: '#1A56DB', title: '库存总件数', value: 12856, trend: 3.2, trendType: 'up' as const, trendLabel: '较上月' },
  { icon: <Layers size={20} />, iconBg: '#D1FAE5', iconColor: '#059669', title: '品种数', value: 246, trend: 1.5, trendType: 'up' as const, trendLabel: '较上月' },
  { icon: <MapPin size={20} />, iconBg: '#FEF3C7', iconColor: '#D97706', title: '库位数', value: 320, trend: 0, trendType: 'up' as const, trendLabel: '较上月' },
  { icon: <BarChart3 size={20} />, iconBg: '#DBEAFE', iconColor: '#2563EB', title: '占用率', value: 78, trend: -2.1, trendType: 'down' as const, trendLabel: '较上月' },
]

/* ─── Status badge helper ─── */
function EquipmentStatus({ status }: { status: string }) {
  switch (status) {
    case 'normal': return <Badge variant="success" dot>正常</Badge>
    case 'warning': return <Badge variant="warning" dot>预警</Badge>
    case 'expired': return <Badge variant="danger" dot>过期</Badge>
    case 'maintenance': return <Badge variant="info" dot>保养中</Badge>
    case 'disabled': return <Badge variant="default">停用</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock ledger data (15 records) ─── */
const ledgerData = [
  { id: 1, code: 'EQ-2024-001', name: '防弹背心', model: 'FDY3R-JS01', rfid: 'RFID-A001-8293', unit: '件', location: 'A-01-02', inboundDate: '2024-03-15', warranty: '2027-03-15', status: 'normal', qty: 156 },
  { id: 2, code: 'EQ-2024-002', name: '手铐', model: 'SK-200A', rfid: 'RFID-A002-4512', unit: '副', location: 'A-02-01', inboundDate: '2024-03-15', warranty: '2029-03-15', status: 'normal', qty: 320 },
  { id: 3, code: 'EQ-2024-003', name: '执法记录仪', model: 'DSJ-K8', rfid: 'RFID-A003-1029', unit: '台', location: 'A-03-03', inboundDate: '2024-01-20', warranty: '2026-01-20', status: 'warning', qty: 88 },
  { id: 4, code: 'EQ-2024-004', name: '防刺服', model: 'FCF-FA', rfid: 'RFID-A004-7741', unit: '件', location: 'A-01-04', inboundDate: '2024-05-10', warranty: '2027-05-10', status: 'normal', qty: 210 },
  { id: 5, code: 'EQ-2024-005', name: '警棍', model: 'JG-600', rfid: 'RFID-A005-3380', unit: '根', location: 'A-02-03', inboundDate: '2024-02-28', warranty: '2030-02-28', status: 'normal', qty: 450 },
  { id: 6, code: 'EQ-2024-006', name: '头盔', model: 'TK-MA', rfid: 'RFID-A006-6621', unit: '顶', location: 'A-04-01', inboundDate: '2024-04-05', warranty: '2027-04-05', status: 'normal', qty: 275 },
  { id: 7, code: 'EQ-2024-007', name: '反光背心', model: 'FG-BX01', rfid: 'RFID-A007-1190', unit: '件', location: 'A-05-02', inboundDate: '2024-06-01', warranty: '2027-06-01', status: 'normal', qty: 500 },
  { id: 8, code: 'EQ-2024-008', name: '夜视仪', model: 'YSY-NV20', rfid: 'RFID-A008-5532', unit: '台', location: 'A-06-01', inboundDate: '2023-09-10', warranty: '2025-09-10', status: 'expired', qty: 18 },
  { id: 9, code: 'EQ-2024-009', name: '对讲机', model: 'DJ-8800', rfid: 'RFID-A009-9876', unit: '台', location: 'A-03-02', inboundDate: '2024-02-15', warranty: '2027-02-15', status: 'normal', qty: 135 },
  { id: 10, code: 'EQ-2024-010', name: '防割手套', model: 'FG-ST08', rfid: 'RFID-A010-2234', unit: '双', location: 'A-07-01', inboundDate: '2024-07-20', warranty: '2027-07-20', status: 'normal', qty: 380 },
  { id: 11, code: 'EQ-2024-011', name: '警用腰带', model: 'YD-MJ01', rfid: 'RFID-A011-4450', unit: '条', location: 'A-07-03', inboundDate: '2024-03-01', warranty: '2029-03-01', status: 'normal', qty: 260 },
  { id: 12, code: 'EQ-2024-012', name: '防弹盾牌', model: 'FDP-SD02', rfid: 'RFID-A012-6712', unit: '面', location: 'A-08-01', inboundDate: '2024-05-18', warranty: '2027-05-18', status: 'normal', qty: 45 },
  { id: 13, code: 'EQ-2024-013', name: '约束带', model: 'YS-DB100', rfid: 'RFID-A013-3019', unit: '条', location: 'A-09-02', inboundDate: '2024-08-01', warranty: '2027-08-01', status: 'normal', qty: 620 },
  { id: 14, code: 'EQ-2024-014', name: '战术背心', model: 'ZS-FDY02', rfid: 'RFID-A014-1188', unit: '件', location: 'A-10-01', inboundDate: '2023-11-20', warranty: '2026-11-20', status: 'maintenance', qty: 62 },
  { id: 15, code: 'EQ-2024-015', name: '测速仪', model: 'CS-LS30', rfid: 'RFID-A015-7740', unit: '台', location: 'A-06-03', inboundDate: '2024-01-10', warranty: '2026-01-10', status: 'normal', qty: 22 },
  { id: 16, code: 'EQ-2024-016', name: '防暴服', model: 'FB-FB01', rfid: 'RFID-A016-9031', unit: '套', location: 'A-11-01', inboundDate: '2024-04-22', warranty: '2027-04-22', status: 'normal', qty: 38 },
  { id: 17, code: 'EQ-2024-017', name: '执法仪支架', model: 'ZJ-DSJ01', rfid: 'RFID-A017-5572', unit: '个', location: 'A-12-02', inboundDate: '2024-09-05', warranty: '2027-09-05', status: 'normal', qty: 85 },
  { id: 18, code: 'EQ-2024-018', name: '警示桩', model: 'JZ-TS50', rfid: 'RFID-A018-6623', unit: '个', location: 'A-13-01', inboundDate: '2024-06-12', warranty: '2027-06-12', status: 'normal', qty: 180 },
  { id: 19, code: 'EQ-2024-019', name: '护肘', model: 'HZ-HU01', rfid: 'RFID-A019-4481', unit: '副', location: 'A-14-02', inboundDate: '2024-07-01', warranty: '2027-07-01', status: 'normal', qty: 95 },
  { id: 20, code: 'EQ-2024-020', name: '腿套', model: 'TT-TT01', rfid: 'RFID-A020-2209', unit: '副', location: 'A-14-03', inboundDate: '2024-07-01', warranty: '2027-07-01', status: 'disabled', qty: 0 },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'keyword', label: '关键词搜索', type: 'input' as const, placeholder: '装备编码/名称/型号/RFID' },
  { key: 'category', label: '装备类别', type: 'select' as const, options: [
    { label: '防护装备', value: 'protection' },
    { label: '执法装备', value: 'enforcement' },
    { label: '通信装备', value: 'communication' },
    { label: '交通管理', value: 'traffic' },
    { label: '特种装备', value: 'special' },
  ]},
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '正常', value: 'normal' },
    { label: '预警', value: 'warning' },
    { label: '过期', value: 'expired' },
    { label: '保养中', value: 'maintenance' },
    { label: '停用', value: 'disabled' },
  ]},
  { key: 'location', label: '库位', type: 'select' as const, options: [
    { label: 'A区', value: 'A' },
    { label: 'B区', value: 'B' },
    { label: 'C区', value: 'C' },
  ]},
  { key: 'dateStart', label: '入库时间（起）', type: 'date' as const },
  { key: 'dateEnd', label: '入库时间（止）', type: 'date' as const },
]

export default function LedgerPage() {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [selectedRows, setSelectedRows] = useState<number[]>([])

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const toggleRow = (id: number) => {
    setSelectedRows((prev) =>
      prev.includes(id) ? prev.filter((v) => v !== id) : [...prev, id]
    )
  }
  const toggleAll = () => {
    setSelectedRows((prev) =>
      prev.length === ledgerData.length ? [] : ledgerData.map((d) => d.id)
    )
  }
  void toggleAll

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">仓库台账</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Printer size={14} /> 打印标签
        </button>
      </div>

      {/* Quick stats */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s, i) => (
          <StatCard key={i} {...s} delay={i * 100} />
        ))}
      </div>

      {/* Filter panel */}
      <FilterPanel
        fields={filterFields}
        values={filterValues}
        onChange={handleFilterChange}
        onSearch={handleSearch}
        onReset={handleReset}
      />

      {/* Batch toolbar */}
      {selectedRows.length > 0 && (
        <div className="mb-4 flex items-center gap-2 rounded-lg border border-[#E8F0FE] bg-[#E8F0FE]/30 p-3">
          <span className="mr-2 text-sm text-[#374151]">已选 <strong>{selectedRows.length}</strong> 条</span>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Edit size={14} /> 修改
          </button>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Tag size={14} /> 标签打印
          </button>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Ban size={14} /> 停用
          </button>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <ArrowRightLeft size={14} /> 调库
          </button>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <AlertTriangle size={14} /> 报损
          </button>
          <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#FEE2E2] bg-white px-3 text-sm text-[#EF4444] transition hover:bg-[#FEE2E2]">
            <Trash2 size={14} /> 报废
          </button>
        </div>
      )}

      {/* Ledger table */}
      <DataTable
        title="装备台账"
        columns={[
          {
            key: 'checkbox',
            title: '',
            width: '40px',
            render: (row) => (
              <input
                type="checkbox"
                checked={selectedRows.includes(row.id)}
                onChange={() => toggleRow(row.id)}
                className="h-4 w-4 rounded border-[#D1D5DB]"
              />
            ),
          },
          { key: 'code', title: '装备编码', width: '120px' },
          { key: 'name', title: '装备名称', width: '120px' },
          { key: 'model', title: '型号规格', width: '120px' },
          { key: 'rfid', title: 'RFID标签号', width: '140px' },
          { key: 'unit', title: '单位', width: '50px' },
          { key: 'location', title: '库位', width: '80px' },
          { key: 'inboundDate', title: '入库时间', width: '100px' },
          { key: 'warranty', title: '质保期限', width: '100px' },
          { key: 'status', title: '状态', width: '80px', render: (row) => <EquipmentStatus status={row.status} /> },
          { key: 'qty', title: '数量', width: '60px', render: (row) => <span className="font-medium">{row.qty}</span> },
        ]}
        data={ledgerData}
        pageSize={10}
        onAdd={() => {}}
        onDelete={() => {}}
        onExport={() => {}}
        rowActions={() => (
          <div className="flex items-center justify-center gap-1">
            <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
              <Edit size={14} />
            </button>
            <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
              <ChevronDown size={14} />
            </button>
          </div>
        )}
      />
    </div>
  )
}
