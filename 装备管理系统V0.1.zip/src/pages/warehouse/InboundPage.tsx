import { useState } from 'react'
import {
  Plus,
  Upload,
  Check,
  ChevronRight,
  Eye,
  Printer,
  PackageCheck,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Steps indicator ─── */
const steps = ['供应商发货', '生成收货单', '到货验收', '入库上架']

function ProcessSteps({ currentStep }: { currentStep: number }) {
  return (
    <div className="mb-6 flex items-center justify-center gap-2">
      {steps.map((label, idx) => {
        const isCompleted = idx < currentStep
        const isCurrent = idx === currentStep
        const isPending = idx > currentStep
        return (
          <div key={label} className="flex items-center gap-2">
            <div className="flex flex-col items-center gap-1">
              <div
                className={cn(
                  'flex h-7 w-7 items-center justify-center rounded-full text-xs font-bold transition',
                  isCompleted && 'bg-[#1A56DB] text-white',
                  isCurrent && 'bg-[#1A56DB] text-white ring-4 ring-[#1A56DB]/20',
                  isPending && 'border-2 border-[#D1D5DB] text-[#9CA3AF]'
                )}
              >
                {isCompleted ? <Check size={14} /> : idx + 1}
              </div>
              <span
                className={cn(
                  'text-xs',
                  isCompleted && 'font-medium text-[#1A56DB]',
                  isCurrent && 'font-bold text-[#1A56DB]',
                  isPending && 'text-[#9CA3AF]'
                )}
              >
                {label}
              </span>
            </div>
            {idx < steps.length - 1 && (
              <ChevronRight
                size={16}
                className={cn(
                  'mx-1',
                  isCompleted ? 'text-[#1A56DB]' : 'text-[#D1D5DB]'
                )}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ─── Tabs ─── */
const tabs = [
  { key: 'pending-receipt', label: '待收货', badge: 8, badgeVariant: 'danger' as const },
  { key: 'pending-inspection', label: '待验收', badge: 12, badgeVariant: 'warning' as const },
  { key: 'stored', label: '已入库', badge: 0, badgeVariant: 'default' as const },
  { key: 'return', label: '退货处理', badge: 2, badgeVariant: 'default' as const },
]

/* ─── Mock data ─── */
const inboundData = [
  { id: 'RK20260603001', relatedId: 'FH20260601002', supplier: '江苏安防科技有限公司', items: '防弹背心x50, 手铐x100, 执法记录仪x30', eta: '2026-06-03', status: 'pending' as const },
  { id: 'RK20260603002', relatedId: 'FH20260601005', supplier: '北京警用装备厂', items: '防刺服x80, 警棍x200', eta: '2026-06-03', status: 'confirmed' as const },
  { id: 'RK20260603003', relatedId: 'FH20260601008', supplier: '上海防护科技集团', items: '头盔x120, 反光背心x300', eta: '2026-06-04', status: 'pending' as const },
  { id: 'RK20260603004', relatedId: 'FH20260601012', supplier: '广州智能装备有限公司', items: '执法记录仪x50, 对讲机x80', eta: '2026-06-02', status: 'overdue' as const },
  { id: 'RK20260603005', relatedId: 'FH20260601015', supplier: '深圳视讯安防股份', items: '夜视仪x20, 测速仪x15', eta: '2026-06-05', status: 'pending' as const },
  { id: 'RK20260603006', relatedId: 'FH20260601018', supplier: '浙江警用器材厂', items: '约束带x500, 警示桩x200', eta: '2026-06-04', status: 'confirmed' as const },
  { id: 'RK20260603007', relatedId: 'FH20260601020', supplier: '重庆安防设备公司', items: '防弹盾牌x30, 防暴服x40', eta: '2026-06-06', status: 'pending' as const },
  { id: 'RK20260603008', relatedId: 'FH20260601022', supplier: '天津防护用品有限公司', items: '防割手套x300, 警用腰带x250', eta: '2026-06-02', status: 'overdue' as const },
  { id: 'RK20260603009', relatedId: 'FH20260601025', supplier: '福建光电科技公司', items: '执法记录仪x60, 执法仪支架x60', eta: '2026-06-05', status: 'pending' as const },
  { id: 'RK20260603010', relatedId: 'FH20260601028', supplier: '山东铁鹰安防集团', items: '战术背心x70, 腿套x70, 护肘x70', eta: '2026-06-07', status: 'pending' as const },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'receiptNo', label: '收货单号', type: 'input' as const, placeholder: '请输入收货单号' },
  { key: 'supplier', label: '供应商', type: 'select' as const, options: [
    { label: '江苏安防科技有限公司', value: '江苏安防' },
    { label: '北京警用装备厂', value: '北京警用' },
    { label: '上海防护科技集团', value: '上海防护' },
    { label: '广州智能装备有限公司', value: '广州智能' },
  ]},
  { key: 'etaStart', label: '预计到达（起）', type: 'date' as const },
  { key: 'etaEnd', label: '预计到达（止）', type: 'date' as const },
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '待确认', value: 'pending' },
    { label: '已确认', value: 'confirmed' },
    { label: '已取消', value: 'cancelled' },
    { label: '已逾期', value: 'overdue' },
  ]},
]

/* ─── Status badge helper ─── */
function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'pending': return <Badge variant="warning" dot>待确认</Badge>
    case 'confirmed': return <Badge variant="success" dot>已确认</Badge>
    case 'cancelled': return <Badge variant="default">已取消</Badge>
    case 'overdue': return <Badge variant="danger" dot>已逾期</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

export default function InboundPage() {
  const [activeTab, setActiveTab] = useState('pending-receipt')
  const [currentStep] = useState(2) // 到货验收 = step 2
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }

  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">入库管理</h1>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 手工入库
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Upload size={14} /> 导入
          </button>
        </div>
      </div>

      {/* Process steps */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <ProcessSteps currentStep={currentStep} />
      </div>

      {/* Tabs */}
      <div className="mt-6 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.badge > 0 && (
                <span
                  className={cn(
                    'flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-bold text-white',
                    tab.badgeVariant === 'danger' && 'bg-[#EF4444]',
                    tab.badgeVariant === 'warning' && 'bg-[#F59E0B]',
                    tab.badgeVariant === 'default' && 'bg-[#9CA3AF]',
                  )}
                >
                  {tab.badge}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Data table */}
      <div className="mt-4">
        <DataTable
          title="入库单据列表"
          columns={[
            { key: 'id', title: '收货单号', width: '160px' },
            { key: 'relatedId', title: '关联发货单', width: '160px' },
            { key: 'supplier', title: '供应商', width: '180px' },
            { key: 'items', title: '装备清单摘要', width: '220px' },
            { key: 'eta', title: '预计到达', width: '120px', render: (row) => (
              <span className={cn(row.status === 'overdue' && 'text-[#EF4444] font-medium')}>{row.eta}</span>
            )},
            { key: 'status', title: '状态', width: '100px', render: (row) => <StatusBadge status={row.status} /> },
          ]}
          data={inboundData.filter((row) => {
            if (activeTab === 'pending-receipt') return row.status === 'pending' || row.status === 'overdue'
            if (activeTab === 'pending-inspection') return row.status === 'confirmed'
            if (activeTab === 'stored') return false
            if (activeTab === 'return') return false
            return true
          })}
          onAdd={undefined}
          onDelete={() => {}}
          onImport={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#10B981] transition hover:bg-[#D1FAE5]">
                <PackageCheck size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Printer size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
