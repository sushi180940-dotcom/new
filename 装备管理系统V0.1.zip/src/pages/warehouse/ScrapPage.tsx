import { useState } from 'react'
import {
  Plus,
  Eye,
  Edit,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Tabs ─── */
const tabs = [
  { key: 'pending-approve', label: '待审批', count: 4 },
  { key: 'approving', label: '审批中', count: 2 },
  { key: 'pending-dispose', label: '待处置', count: 3 },
  { key: 'completed', label: '已完成', count: 0 },
]

/* ─── Scrap type badge ─── */
function ScrapTypeBadge({ type }: { type: string }) {
  switch (type) {
    case 'expire': return <Badge variant="warning">超期服役</Badge>
    case 'damage': return <Badge variant="danger">损坏无法修复</Badge>
    case 'obsolete': return <Badge variant="info">技术淘汰</Badge>
    case 'accident': return <Badge variant="danger">事故损毁</Badge>
    default: return <Badge variant="default">{type}</Badge>
  }
}

/* ─── Scrap status badge ─── */
function ScrapStatus({ status }: { status: string }) {
  switch (status) {
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'approving': return <Badge variant="info" dot>审批中</Badge>
    case 'pending-dispose': return <Badge variant="primary" dot>待处置</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock scrap data ─── */
const scrapData = [
  { id: 'BF20260603001', equipment: '夜视仪 YSY-NV20', code: 'EQ-2024-008', rfid: 'RFID-A008-5532', reason: '红外功能完全失效，核心部件停产无法维修，已超期服役3年', type: 'expire', applicant: '赵管理员', dept: '装备管理处', time: '2026-06-03 09:00', status: 'pending-approve' as const },
  { id: 'BF20260603002', equipment: '测速仪 CS-LS30', code: 'EQ-2024-015', rfid: 'RFID-A015-7740', reason: '多次维修仍读数不准，主板老化，维修成本超过新品价格70%', type: 'damage', applicant: '刘警官', dept: '交警大队', time: '2026-06-02 14:30', status: 'approving' as const },
  { id: 'BF20260603003', equipment: '对讲机 DJ-8800', code: 'EQ-2024-009', rfid: 'RFID-A009-9876', reason: '型号已停产，配件无法采购，通讯协议与现有系统不兼容', type: 'obsolete', applicant: '李管理员', dept: '通信科', time: '2026-06-02 10:00', status: 'pending-dispose' as const },
  { id: 'BF20260603004', equipment: '战术背心 ZS-FDY02', code: 'EQ-2024-014', rfid: 'RFID-A014-1188', reason: '训练中使用磨损严重，防护等级已不符合现行标准', type: 'expire', applicant: '张警官', dept: '特警支队', time: '2026-06-01 16:00', status: 'pending-approve' as const },
  { id: 'BF20260603005', equipment: '执法记录仪 DSJ-K8', code: 'EQ-2024-003', rfid: 'RFID-A003-1029', reason: '进水导致主板腐蚀，屏幕和存储均无法修复', type: 'damage', applicant: '王警官', dept: '刑侦支队', time: '2026-06-01 09:30', status: 'approving' as const },
  { id: 'BF20260603006', equipment: '防暴服 FB-FB01', code: 'EQ-2024-016', rfid: 'RFID-A016-9031', reason: '在一次处突行动中被利器割破，防护层受损无法修复', type: 'accident', applicant: '吴警官', dept: '防暴大队', time: '2026-05-31 11:00', status: 'pending-dispose' as const },
  { id: 'BF20260603007', equipment: '腿套 TT-TT01', code: 'EQ-2024-020', rfid: 'RFID-A020-2209', reason: '库存超过有效期，材质老化变脆，防护性能下降', type: 'expire', applicant: '钱管理员', dept: '装备仓库', time: '2026-05-30 15:00', status: 'pending-approve' as const },
  { id: 'BF20260603008', equipment: '测速仪 CS-LS30', code: 'EQ-2024-015', rfid: 'RFID-A015-7741', reason: '被车辆碾压损毁，外壳和内部元件全部损坏', type: 'accident', applicant: '孙警官', dept: '交警大队', time: '2026-05-29 10:00', status: 'completed' as const },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'scrapNo', label: '报废单号', type: 'input' as const, placeholder: '请输入报废单号' },
  { key: 'equipment', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
  { key: 'type', label: '报废类型', type: 'select' as const, options: [
    { label: '超期服役', value: 'expire' },
    { label: '损坏无法修复', value: 'damage' },
    { label: '技术淘汰', value: 'obsolete' },
    { label: '事故损毁', value: 'accident' },
  ]},
  { key: 'applicant', label: '申请人', type: 'input' as const, placeholder: '请输入申请人' },
  { key: 'dateStart', label: '申请时间（起）', type: 'date' as const },
  { key: 'dateEnd', label: '申请时间（止）', type: 'date' as const },
]

export default function ScrapPage() {
  const [activeTab, setActiveTab] = useState('pending-approve')
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const filteredData = scrapData.filter((row) => {
    if (activeTab === 'all') return true
    return row.status === activeTab
  })

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">报废管理</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={14} /> 新建报废申请
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#9CA3AF] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Scrap table */}
      <div className="mt-4">
        <DataTable
          title="报废申请列表"
          columns={[
            { key: 'id', title: '报废单号', width: '140px' },
            { key: 'equipment', title: '装备信息', width: '150px', render: (row) => (
              <div>
                <p className="font-medium text-[#1F2937]">{row.equipment}</p>
                <p className="text-xs text-[#6B7280]">{row.code}</p>
              </div>
            )},
            { key: 'reason', title: '报废原因', width: '260px', render: (row) => (
              <span className="line-clamp-2 text-[#374151]">{row.reason}</span>
            )},
            { key: 'type', title: '类型', width: '110px', render: (row) => <ScrapTypeBadge type={row.type} /> },
            { key: 'applicant', title: '申请人', width: '120px', render: (row) => (
              <div>
                <p>{row.applicant}</p>
                <p className="text-xs text-[#6B7280]">{row.dept}</p>
              </div>
            )},
            { key: 'time', title: '申请时间', width: '130px' },
            { key: 'status', title: '状态', width: '90px', render: (row) => <ScrapStatus status={row.status} /> },
          ]}
          data={filteredData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
