import { useState } from 'react'
import {
  Check,
  ChevronRight,
  Eye,
  Edit,
  FileText,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Process flow steps ─── */
const flowSteps = [
  { key: 'register', label: '报修登记' },
  { key: 'approve', label: '领导审批' },
  { key: 'repair', label: '维修处置' },
  { key: 'verify', label: '验收确认' },
  { key: 'archive', label: '归档' },
]

function RepairFlow({ currentStep }: { currentStep: number }) {
  return (
    <div className="mb-6 flex flex-wrap items-center justify-center gap-1 sm:gap-2">
      {flowSteps.map((step, idx) => {
        const isCompleted = idx < currentStep
        const isCurrent = idx === currentStep
        const isPending = idx > currentStep
        return (
          <div key={step.key} className="flex items-center gap-1 sm:gap-2">
            <div className="flex flex-col items-center gap-1">
              <div
                className={cn(
                  'flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold transition',
                  isCompleted && 'bg-[#10B981] text-white',
                  isCurrent && 'bg-[#1A56DB] text-white ring-4 ring-[#1A56DB]/20',
                  isPending && 'border-2 border-[#D1D5DB] text-[#9CA3AF]'
                )}
              >
                {isCompleted ? <Check size={14} /> : idx + 1}
              </div>
              <span
                className={cn(
                  'text-[11px]',
                  isCompleted && 'font-medium text-[#10B981]',
                  isCurrent && 'font-bold text-[#1A56DB]',
                  isPending && 'text-[#9CA3AF]'
                )}
              >
                {step.label}
              </span>
            </div>
            {idx < flowSteps.length - 1 && (
              <div className="flex items-center">
                <ChevronRight size={14} className={cn('mx-0.5', isCompleted ? 'text-[#10B981]' : 'text-[#D1D5DB]')} />
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ─── Tabs ─── */
const tabs = [
  { key: 'pending-approve', label: '待审批', count: 5 },
  { key: 'repairing', label: '维修中', count: 8 },
  { key: 'pending-verify', label: '待验收', count: 3 },
  { key: 'completed', label: '已完成', count: 0 },
  { key: 'all', label: '全部', count: 0 },
]

/* ─── Impact level badge ─── */
function ImpactBadge({ level }: { level: string }) {
  switch (level) {
    case 'high': return <Badge variant="danger" dot>安全隐患</Badge>
    case 'medium': return <Badge variant="warning" dot>无法使用</Badge>
    case 'low': return <Badge variant="warning">影响使用</Badge>
    case 'none': return <Badge variant="success">不影响</Badge>
    default: return <Badge variant="default">{level}</Badge>
  }
}

/* ─── Repair status badge ─── */
function RepairStatus({ status }: { status: string }) {
  switch (status) {
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'repairing': return <Badge variant="info" dot>维修中</Badge>
    case 'pending-verify': return <Badge variant="primary" dot>待验收</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock repair data ─── */
const repairData = [
  { id: 'BX20260603001', equipment: '执法记录仪 DSJ-K8', code: 'EQ-2024-003', rfid: 'RFID-A003-1029', fault: '电池无法充电，续航不足1小时', reporter: '王警官', dept: '刑侦支队', time: '2026-06-03 08:30', impact: 'medium', status: 'pending-approve' as const },
  { id: 'BX20260603002', equipment: '对讲机 DJ-8800', code: 'EQ-2024-009', rfid: 'RFID-A009-9876', fault: '信号不稳定，通话有杂音', reporter: '李警官', dept: '巡逻大队', time: '2026-06-02 14:20', impact: 'low', status: 'repairing' as const },
  { id: 'BX20260603003', equipment: '防弹背心 FDY3R-JS01', code: 'EQ-2024-001', rfid: 'RFID-A001-8293', fault: '魔术贴老化脱落，无法正常固定', reporter: '张警官', dept: '特警支队', time: '2026-06-02 10:15', impact: 'high', status: 'pending-approve' as const },
  { id: 'BX20260603004', equipment: '夜视仪 YSY-NV20', code: 'EQ-2024-008', rfid: 'RFID-A008-5532', fault: '成像模糊，红外功能失效', reporter: '赵警官', dept: '特警支队', time: '2026-06-01 16:00', impact: 'high', status: 'repairing' as const },
  { id: 'BX20260603005', equipment: '测速仪 CS-LS30', code: 'EQ-2024-015', rfid: 'RFID-A015-7740', fault: '显示屏出现条纹，读数不准确', reporter: '刘警官', dept: '交警大队', time: '2026-06-01 09:45', impact: 'low', status: 'pending-verify' as const },
  { id: 'BX20260603006', equipment: '执法记录仪 DSJ-K8', code: 'EQ-2024-003', rfid: 'RFID-A003-1029', fault: '摄像头进水起雾，无法录像', reporter: '陈警官', dept: '治安大队', time: '2026-05-31 15:30', impact: 'medium', status: 'repairing' as const },
  { id: 'BX20260603007', equipment: '手铐 SK-200A', code: 'EQ-2024-002', rfid: 'RFID-A002-4512', fault: '锁芯卡滞，钥匙无法顺利开启', reporter: '杨警官', dept: '看守所', time: '2026-05-31 11:00', impact: 'medium', status: 'pending-approve' as const },
  { id: 'BX20260603008', equipment: '防刺服 FCF-FA', code: 'EQ-2024-004', rfid: 'RFID-A004-7741', fault: '肩部织带断裂，穿戴松动', reporter: '周警官', dept: '巡警支队', time: '2026-05-30 14:20', impact: 'low', status: 'repairing' as const },
  { id: 'BX20260603009', equipment: '防弹盾牌 FDP-SD02', code: 'EQ-2024-012', rfid: 'RFID-A012-6712', fault: '观察窗出现裂纹，影响视线', reporter: '吴警官', dept: '防暴大队', time: '2026-05-30 09:00', impact: 'high', status: 'pending-verify' as const },
  { id: 'BX20260603010', equipment: '对讲机 DJ-8800', code: 'EQ-2024-009', rfid: 'RFID-A009-9876', fault: '电源按键失灵，无法正常开关机', reporter: '郑警官', dept: '指挥中心', time: '2026-05-29 16:30', impact: 'low', status: 'completed' as const },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'repairNo', label: '报修单号', type: 'input' as const, placeholder: '请输入报修单号' },
  { key: 'equipment', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
  { key: 'impact', label: '影响等级', type: 'select' as const, options: [
    { label: '安全隐患', value: 'high' },
    { label: '无法使用', value: 'medium' },
    { label: '影响使用', value: 'low' },
    { label: '不影响', value: 'none' },
  ]},
  { key: 'reporter', label: '报修人', type: 'input' as const, placeholder: '请输入报修人' },
  { key: 'dateStart', label: '报修时间（起）', type: 'date' as const },
  { key: 'dateEnd', label: '报修时间（止）', type: 'date' as const },
]

export default function RepairPage() {
  const [activeTab, setActiveTab] = useState('pending-approve')
  const [currentStep] = useState(2) // repair step active
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const filteredData = repairData.filter((row) => {
    if (activeTab === 'all') return true
    return row.status === activeTab
  })

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">报修管理</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <FileText size={14} /> 新建报修
        </button>
      </div>

      {/* Process flow */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <RepairFlow currentStep={currentStep} />
      </div>

      {/* Tabs */}
      <div className="mt-6 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#F59E0B] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Repair table */}
      <div className="mt-4">
        <DataTable
          title="报修单据列表"
          columns={[
            { key: 'id', title: '报修单号', width: '140px' },
            { key: 'equipment', title: '装备信息', width: '160px', render: (row) => (
              <div>
                <p className="font-medium text-[#1F2937]">{row.equipment}</p>
                <p className="text-xs text-[#6B7280]">{row.code}</p>
              </div>
            )},
            { key: 'fault', title: '故障摘要', width: '220px' },
            { key: 'reporter', title: '报修人', width: '120px', render: (row) => (
              <div>
                <p>{row.reporter}</p>
                <p className="text-xs text-[#6B7280]">{row.dept}</p>
              </div>
            )},
            { key: 'time', title: '报修时间', width: '130px' },
            { key: 'impact', title: '影响等级', width: '100px', render: (row) => <ImpactBadge level={row.impact} /> },
            { key: 'status', title: '状态', width: '90px', render: (row) => <RepairStatus status={row.status} /> },
          ]}
          data={filteredData}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
                <Edit size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
