import { useState } from 'react'
import { Plus, Upload, Download, Search, Edit3, Eye, Trash2 } from 'lucide-react'
import { cn } from '@/lib/utils'

interface StandardItem {
  id: string
  projectName: string
  configUnit: string
  quantity: number
  useYears: number
  unitPrice: number
  equipType: '必配' | '选配' | '特配'
  targetObj: string
  legalBasis: string
  status: '启用' | '停用'
}

const mockStandards: StandardItem[] = [
  { id: '1', projectName: '防弹背心', configUnit: '人', quantity: 1, useYears: 5, unitPrice: 3200, equipType: '必配', targetObj: '一线执勤民警', legalBasis: 'GA141-2010《警用防弹衣》', status: '启用' },
  { id: '2', projectName: '防弹头盔', configUnit: '人', quantity: 1, useYears: 3, unitPrice: 1800, equipType: '必配', targetObj: '特警队员', legalBasis: 'GA293-2012《警用防弹头盔》', status: '启用' },
  { id: '3', projectName: '防刺服', configUnit: '人', quantity: 1, useYears: 5, unitPrice: 950, equipType: '必配', targetObj: '巡逻民警', legalBasis: 'GA68-2018《警用防刺服》', status: '启用' },
  { id: '4', projectName: '执法记录仪', configUnit: '人', quantity: 1, useYears: 3, unitPrice: 2200, equipType: '必配', targetObj: '全体民警', legalBasis: '《公安机关现场执法视音频记录工作规定》', status: '启用' },
  { id: '5', projectName: '伸缩警棍', configUnit: '人', quantity: 1, useYears: 5, unitPrice: 280, equipType: '必配', targetObj: '一线执勤民警', legalBasis: 'GA886-2018《警用伸缩警棍》', status: '启用' },
  { id: '6', projectName: '手铐', configUnit: '人', quantity: 2, useYears: 10, unitPrice: 85, equipType: '必配', targetObj: '全体民警', legalBasis: 'GA172-2014《金属手铐》', status: '启用' },
  { id: '7', projectName: '对讲机', configUnit: '人', quantity: 1, useYears: 4, unitPrice: 1500, equipType: '必配', targetObj: '指挥调度岗位', legalBasis: 'GA17691-1999《警用无线通信设备》', status: '启用' },
  { id: '8', projectName: '战术背心', configUnit: '人', quantity: 1, useYears: 4, unitPrice: 1200, equipType: '选配', targetObj: '特警/ SWAT', legalBasis: 'GA141-2010', status: '启用' },
  { id: '9', projectName: '防暴盾牌', configUnit: '组', quantity: 4, useYears: 5, unitPrice: 450, equipType: '选配', targetObj: '防暴处置组', legalBasis: 'GA422-2019《警用防暴盾牌》', status: '启用' },
  { id: '10', projectName: '催泪喷射器', configUnit: '人', quantity: 2, useYears: 3, unitPrice: 120, equipType: '必配', targetObj: '一线执勤民警', legalBasis: 'GA884-2018《警用催泪喷射器》', status: '启用' },
  { id: '11', projectName: '防弹盾牌', configUnit: '组', quantity: 2, useYears: 5, unitPrice: 5600, equipType: '特配', targetObj: '反恐特警', legalBasis: 'GA423-2015《警用防弹盾牌》', status: '启用' },
  { id: '12', projectName: '排爆服', configUnit: '组', quantity: 1, useYears: 5, unitPrice: 28000, equipType: '特配', targetObj: '排爆组', legalBasis: 'GA950-2011《警用排爆服》', status: '启用' },
  { id: '13', projectName: '防毒面具', configUnit: '人', quantity: 1, useYears: 5, unitPrice: 680, equipType: '选配', targetObj: '生化处置组', legalBasis: 'GB2890-2009《呼吸防护》', status: '停用' },
  { id: '14', projectName: '警用强光手电', configUnit: '人', quantity: 1, useYears: 3, unitPrice: 220, equipType: '选配', targetObj: '夜间巡逻民警', legalBasis: 'GA883-2018《警用强光手电》', status: '启用' },
  { id: '15', projectName: '约束带', configUnit: '组', quantity: 10, useYears: 2, unitPrice: 35, equipType: '必配', targetObj: '办案区', legalBasis: 'GA814-2009《警用约束带》', status: '启用' },
]

function TypeBadge({ type }: { type: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      type === '必配' ? 'bg-[#E8F0FE] text-[#1A56DB]' :
      type === '选配' ? 'bg-[#D1FAE5] text-[#059669]' :
      'bg-[#FEF3C7] text-[#D97706]'
    )}>
      {type}
    </span>
  )
}

export default function StandardPage() {
  const [searchText, setSearchText] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  const filtered = mockStandards.filter((s) => {
    if (searchText && !s.projectName.includes(searchText) && !s.legalBasis.includes(searchText)) return false
    if (typeFilter && s.equipType !== typeFilter) return false
    if (statusFilter && s.status !== statusFilter) return false
    return true
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">配备标准管理</h1>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 新增标准
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Upload size={14} /> 导入
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Download size={14} /> 导出
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder="搜索项目名称或法规依据"
              value={searchText}
              onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
              className="h-9 w-60 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
            />
          </div>
          <select
            value={typeFilter}
            onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          >
            <option value="">全部类型</option>
            <option value="必配">必配</option>
            <option value="选配">选配</option>
            <option value="特配">特配</option>
          </select>
          <select
            value={statusFilter}
            onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          >
            <option value="">全部状态</option>
            <option value="启用">启用</option>
            <option value="停用">停用</option>
          </select>
          <button
            onClick={() => { setSearchText(''); setTypeFilter(''); setStatusFilter(''); setCurrentPage(1) }}
            className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
          >
            重置
          </button>
        </div>
      </div>

      {/* Data Table */}
      <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">项目名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">配置单元</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">数量</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">使用年限</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">参考单价(元)</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">配备类型</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">配备对象</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">法规依据</th>
                <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
                <th className="w-28 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((row, idx) => (
                <tr
                  key={row.id}
                  className={cn(
                    'border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]',
                    idx % 2 === 1 ? 'bg-[#FAFBFC]' : 'bg-white'
                  )}
                >
                  <td className="px-4 py-3 text-sm font-medium text-[#1F2937]">{row.projectName}</td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{row.configUnit}</td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{row.quantity}</td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{row.useYears}年</td>
                  <td className="px-4 py-3 text-sm font-number text-[#374151]">¥{row.unitPrice.toLocaleString()}</td>
                  <td className="px-4 py-3"><TypeBadge type={row.equipType} /></td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{row.targetObj}</td>
                  <td className="max-w-[200px] truncate px-4 py-3 text-xs text-[#6B7280]">{row.legalBasis}</td>
                  <td className="px-4 py-3">
                    <span className={cn(
                      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
                      row.status === '启用' ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#F3F4F6] text-[#6B7280]'
                    )}>
                      {row.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                        <Edit3 size={13} />
                      </button>
                      <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                        <Eye size={13} />
                      </button>
                      <button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={10} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    暂无数据
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <div className="flex items-center gap-3 text-sm text-[#6B7280]">
              <span>共 {filtered.length} 条</span>
              <select
                value={pageSize}
                onChange={() => {}}
                className="h-7 rounded border border-[#D1D5DB] px-2 text-xs outline-none"
              >
                <option>每页 {pageSize} 条</option>
              </select>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &lt;
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === currentPage
                      ? 'border-[#1A56DB] bg-[#1A56DB] text-white'
                      : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &gt;
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
