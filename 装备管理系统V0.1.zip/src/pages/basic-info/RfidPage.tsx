import { useEffect, useRef, useState } from 'react'
import {
  Plus,
  Upload,
  Download,
  Tag,
  Search,
  Edit3,
  Trash2,
  Cpu,
  Hash,
  Layers,
} from 'lucide-react'
import * as echarts from 'echarts'
import { cn } from '@/lib/utils'

interface RfidRule {
  id: string
  name: string
  prefix: string
  totalBits: number
  segments: { name: string; bits: number; color: string }[]
  description: string
}

interface RfidCode {
  id: string
  code: string
  ruleId: string
  equipName: string
  equipModel: string
  batchNo: string
  status: '已绑定' | '未绑定' | '已注销'
  bindTime?: string
  createTime: string
}

const mockRules: RfidRule[] = [
  {
    id: 'r1',
    name: '警用装备32位编码规则',
    prefix: 'PE',
    totalBits: 32,
    segments: [
      { name: '前缀', bits: 4, color: '#1A56DB' },
      { name: '大类', bits: 4, color: '#10B981' },
      { name: '品种', bits: 6, color: '#F59E0B' },
      { name: '型号', bits: 6, color: '#8B5CF6' },
      { name: '批次', bits: 6, color: '#EC4899' },
      { name: '序号', bits: 6, color: '#06B6D4' },
    ],
    description: '用于警用装备全生命周期管理的标准RFID编码，32位结构支持262,144种型号标识。',
  },
  {
    id: 'r2',
    name: '应急物资24位编码规则',
    prefix: 'EM',
    totalBits: 24,
    segments: [
      { name: '前缀', bits: 4, color: '#DC2626' },
      { name: '类别', bits: 4, color: '#F59E0B' },
      { name: '物资', bits: 6, color: '#10B981' },
      { name: '批次', bits: 4, color: '#8B5CF6' },
      { name: '序号', bits: 6, color: '#1A56DB' },
    ],
    description: '应急仓库物资专用编码规则，24位紧凑结构满足快速识别需求。',
  },
  {
    id: 'r3',
    name: '警械装备28位编码规则',
    prefix: 'WE',
    totalBits: 28,
    segments: [
      { name: '前缀', bits: 4, color: '#153E7E' },
      { name: '大类', bits: 4, color: '#1A56DB' },
      { name: '品种', bits: 6, color: '#10B981' },
      { name: '产地', bits: 4, color: '#F59E0B' },
      { name: '年份', bits: 4, color: '#8B5CF6' },
      { name: '序号', bits: 6, color: '#EC4899' },
    ],
    description: '武器警械专用编码规则，包含产地和年份信息，用于溯源追踪。',
  },
]

const mockCodes: RfidCode[] = [
  { id: 'c1', code: 'PE0101001001001001', ruleId: 'r1', equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:30:00', createTime: '2024-01-10' },
  { id: 'c2', code: 'PE0101001001001002', ruleId: 'r1', equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:32:00', createTime: '2024-01-10' },
  { id: 'c3', code: 'PE0101001001001003', ruleId: 'r1', equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:35:00', createTime: '2024-01-10' },
  { id: 'c4', code: 'PE0102001001001004', ruleId: 'r1', equipName: '防弹头盔', equipModel: 'MICH2000', batchNo: 'B202402', status: '已绑定', bindTime: '2024-02-01 14:20:00', createTime: '2024-01-20' },
  { id: 'c5', code: 'PE0102001001001005', ruleId: 'r1', equipName: '防弹头盔', equipModel: 'MICH2000', batchNo: 'B202402', status: '未绑定', createTime: '2024-01-20' },
  { id: 'c6', code: 'PE0201001001001006', ruleId: 'r1', equipName: '伸缩警棍', equipModel: 'JG-01', batchNo: 'B202403', status: '已绑定', bindTime: '2024-03-10 10:00:00', createTime: '2024-03-01' },
  { id: 'c7', code: 'PE0301001001001007', ruleId: 'r1', equipName: '手铐', equipModel: 'SK-01', batchNo: 'B202404', status: '已绑定', bindTime: '2024-03-15 11:30:00', createTime: '2024-03-05' },
  { id: 'c8', code: 'PE0301001001001008', ruleId: 'r1', equipName: '手铐', equipModel: 'SK-01', batchNo: 'B202404', status: '已注销', bindTime: '2024-03-15 11:35:00', createTime: '2024-03-05' },
  { id: 'c9', code: 'PE0401001001001009', ruleId: 'r1', equipName: '执法记录仪', equipModel: 'ZF-01', batchNo: 'B202405', status: '已绑定', bindTime: '2024-04-01 08:45:00', createTime: '2024-03-20' },
  { id: 'c10', code: 'PE0401001001001010', ruleId: 'r1', equipName: '执法记录仪', equipModel: 'ZF-01', batchNo: 'B202405', status: '未绑定', createTime: '2024-03-20' },
]

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      status === '已绑定' ? 'bg-[#D1FAE5] text-[#059669]' :
      status === '未绑定' ? 'bg-[#E8F0FE] text-[#1A56DB]' :
      'bg-[#F3F4F6] text-[#6B7280]'
    )}>
      {status}
    </span>
  )
}

export default function RfidPage() {
  const chartRef = useRef<HTMLDivElement>(null)
  const chartInstanceRef = useRef<echarts.ECharts | null>(null)
  const [searchText, setSearchText] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    if (!chartRef.current) return

    const instance = echarts.init(chartRef.current)
    chartInstanceRef.current = instance

    const statusCounts = [
      { value: mockCodes.filter(c => c.status === '已绑定').length, name: '已绑定' },
      { value: mockCodes.filter(c => c.status === '未绑定').length, name: '未绑定' },
      { value: mockCodes.filter(c => c.status === '已注销').length, name: '已注销' },
    ]

    instance.setOption({
      tooltip: {
        trigger: 'item',
        formatter: '{b}: {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        right: 10,
        top: 'center',
        textStyle: { color: '#374151', fontSize: 12 },
      },
      series: [
        {
          name: '编码状态',
          type: 'pie',
          radius: ['40%', '70%'],
          center: ['35%', '50%'],
          avoidLabelOverlap: true,
          itemStyle: {
            borderRadius: 6,
            borderColor: '#fff',
            borderWidth: 2,
          },
          label: {
            show: false,
          },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: 'bold',
            },
          },
          data: statusCounts.map((s) => ({
            ...s,
            itemStyle: {
              color: s.name === '已绑定' ? '#10B981' : s.name === '未绑定' ? '#1A56DB' : '#9CA3AF',
            },
          })),
        },
      ],
    })

    const handleResize = () => instance.resize()
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
      instance.dispose()
    }
  }, [])

  const filtered = mockCodes.filter((c) => {
    if (searchText && !c.code.includes(searchText) && !c.equipName.includes(searchText)) return false
    if (statusFilter && c.status !== statusFilter) return false
    return true
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Tag size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">RFID编码管理</h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 新增规则
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Upload size={14} /> 导入
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Download size={14} /> 导出
          </button>
        </div>
      </div>

      {/* Rule Overview Cards */}
      <div className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        {mockRules.map((rule) => (
          <div key={rule.id} className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm transition hover:shadow-md">
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#E8F0FE]">
                  <Hash size={16} className="text-[#1A56DB]" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-[#1F2937]">{rule.name}</h3>
                  <p className="text-xs text-[#6B7280]">{rule.prefix} | {rule.totalBits}位</p>
                </div>
              </div>
              <Layers size={14} className="text-[#9CA3AF]" />
            </div>

            {/* Encoding structure visualization */}
            <div className="mb-3">
              <div className="flex h-8 overflow-hidden rounded-md">
                {rule.segments.map((seg, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-center text-[11px] font-medium text-white"
                    style={{
                      width: `${(seg.bits / rule.totalBits) * 100}%`,
                      backgroundColor: seg.color,
                    }}
                    title={`${seg.name}: ${seg.bits}位`}
                  >
                    {seg.bits >= 6 ? `${seg.name}` : ''}
                  </div>
                ))}
              </div>
              <div className="mt-1 flex flex-wrap gap-2">
                {rule.segments.map((seg, idx) => (
                  <span key={idx} className="flex items-center gap-1 text-[11px] text-[#6B7280]">
                    <span className="h-2 w-2 rounded-full" style={{ backgroundColor: seg.color }} />
                    {seg.name}({seg.bits}位)
                  </span>
                ))}
              </div>
            </div>

            <p className="text-xs leading-relaxed text-[#6B7280]">{rule.description}</p>
          </div>
        ))}
      </div>

      {/* Pie Chart + Summary */}
      <div className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm lg:col-span-1">
          <h3 className="mb-3 text-sm font-semibold text-[#1F2937]">编码状态分布</h3>
          <div ref={chartRef} style={{ width: '100%', height: 220 }} />
        </div>
        <div className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold text-[#1F2937]">编码统计概览</h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="rounded-lg bg-[#E8F0FE] p-4 text-center">
              <div className="text-2xl font-bold text-[#1A56DB]">{mockCodes.length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">编码总数</div>
            </div>
            <div className="rounded-lg bg-[#D1FAE5] p-4 text-center">
              <div className="text-2xl font-bold text-[#059669]">{mockCodes.filter(c => c.status === '已绑定').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">已绑定</div>
            </div>
            <div className="rounded-lg bg-[#DBEAFE] p-4 text-center">
              <div className="text-2xl font-bold text-[#2563EB]">{mockCodes.filter(c => c.status === '未绑定').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">未绑定</div>
            </div>
            <div className="rounded-lg bg-[#F3F4F6] p-4 text-center">
              <div className="text-2xl font-bold text-[#6B7280]">{mockCodes.filter(c => c.status === '已注销').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">已注销</div>
            </div>
          </div>
          <div className="mt-4">
            <h4 className="mb-2 text-xs font-medium text-[#6B7280]">编码生成方式</h4>
            <div className="flex gap-3">
              <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#E8F0FE]">
                <Cpu size={14} /> 批量生成
              </button>
              <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#E8F0FE]">
                <Tag size={14} /> 按需生成
              </button>
              <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#E8F0FE]">
                <Hash size={14} /> 自动编号
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] px-4 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">编码数据</h3>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              <input
                type="text"
                placeholder="搜索编码或装备名称"
                value={searchText}
                onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="h-8 w-52 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
              className="h-8 w-28 rounded-md border border-[#D1D5DB] px-2 text-sm outline-none transition focus:border-[#1A56DB]"
            >
              <option value="">全部状态</option>
              <option value="已绑定">已绑定</option>
              <option value="未绑定">未绑定</option>
              <option value="已注销">已注销</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">编码</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">型号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">批次号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">绑定时间</th>
                <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 font-mono text-sm font-medium text-[#1A56DB]">{row.code}</td>
                  <td className="px-4 py-3 text-sm text-[#374151]">{row.equipName}</td>
                  <td className="px-4 py-3 text-sm text-[#6B7280]">{row.equipModel}</td>
                  <td className="px-4 py-3 text-sm text-[#6B7280]">{row.batchNo}</td>
                  <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                  <td className="px-4 py-3 text-sm text-[#6B7280]">{row.bindTime || '-'}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                        <Edit3 size={13} />
                      </button>
                      <button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]">
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    暂无数据
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &lt;
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &gt;
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
