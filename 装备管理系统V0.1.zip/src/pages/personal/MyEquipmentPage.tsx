import { useState, useEffect, useRef } from 'react'
import {
  Package,
  CheckCircle,
  Clock,
  Wrench,
  Trash2,
  Eye,
  AlertTriangle,
  Shield,
  Radio,
  Link,
  Sun,
  SprayCan,
  HeartPulse,
  Camera,
  FileText,
  Search,
  Download,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── count-up helper ── */
function useCountUp(target: number, duration = 600, delay = 0) {
  const [count, setCount] = useState(0)
  const rafRef = useRef<number>(0)
  const startRef = useRef<number>(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      startRef.current = 0
      const step = (ts: number) => {
        if (!startRef.current) startRef.current = ts
        const p = Math.min((ts - startRef.current) / duration, 1)
        const eased = 1 - Math.pow(1 - p, 3)
        setCount(Math.floor(eased * target))
        if (p < 1) rafRef.current = requestAnimationFrame(step)
      }
      rafRef.current = requestAnimationFrame(step)
    }, delay)
    return () => {
      clearTimeout(timer)
      cancelAnimationFrame(rafRef.current)
    }
  }, [target, duration, delay])

  return count
}

/* ── types ── */
interface Equipment {
  id: number
  name: string
  model: string
  code: string
  rfid: string
  status: '正常' | '待保养' | '报修中' | '待报废'
  nextMaintain: string | null
  icon: React.ReactNode
  iconBg: string
  iconColor: string
}

/* ── status badge ── */
function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; text: string }> = {
    '正常': { bg: 'bg-[#D1FAE5]', text: 'text-[#059669]' },
    '待保养': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
    '报修中': { bg: 'bg-[#DBEAFE]', text: 'text-[#2563EB]' },
    '待报废': { bg: 'bg-[#FEE2E2]', text: 'text-[#DC2626]' },
  }
  const c = configs[status] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span className={cn('inline-block rounded-full px-2.5 py-0.5 text-xs font-medium', c.bg, c.text)}>
      {status}
    </span>
  )
}

/* ── card border by status ── */
function cardBorderClass(status: string): string {
  switch (status) {
    case '待保养': return 'border border-[#F59E0B]'
    case '报修中': return 'border border-[#3B82F6]'
    case '待报废': return 'border border-[#EF4444]'
    default: return 'border border-transparent'
  }
}

/* ── mock data ── */
const equipmentList: Equipment[] = [
  { id: 1, name: '防弹背心', model: 'FDY-2R-01', code: 'EQ2024001', rfid: 'RFID001', status: '正常', nextMaintain: '2026-08', icon: <Shield size={32} />, iconBg: '#FEE2E2', iconColor: '#DC2626' },
  { id: 2, name: '执法记录仪', model: 'DSJ-A7', code: 'EQ2024002', rfid: 'RFID002', status: '正常', nextMaintain: '2026-09', icon: <Camera size={32} />, iconBg: '#DBEAFE', iconColor: '#3B82F6' },
  { id: 3, name: '手铐', model: 'SK-01', code: 'EQ2024003', rfid: 'RFID003', status: '正常', nextMaintain: null, icon: <Link size={32} />, iconBg: '#E8F0FE', iconColor: '#1A56DB' },
  { id: 4, name: '防刺服', model: 'FCF-J-AH01', code: 'EQ2024004', rfid: 'RFID004', status: '待保养', nextMaintain: '2026-06-15', icon: <Shield size={32} />, iconBg: '#FEF3C7', iconColor: '#D97706' },
  { id: 5, name: '对讲机', model: 'GP3688', code: 'EQ2024005', rfid: 'RFID005', status: '报修中', nextMaintain: null, icon: <Radio size={32} />, iconBg: '#DBEAFE', iconColor: '#3B82F6' },
  { id: 6, name: '强光手电', model: 'SD-01', code: 'EQ2024006', rfid: 'RFID006', status: '正常', nextMaintain: '2026-10', icon: <Sun size={32} />, iconBg: '#FEF3C7', iconColor: '#F59E0B' },
  { id: 7, name: '催泪喷射器', model: 'OC-500', code: 'EQ2024007', rfid: 'RFID007', status: '待报废', nextMaintain: null, icon: <SprayCan size={32} />, iconBg: '#FEE2E2', iconColor: '#EF4444' },
  { id: 8, name: '急救包', model: 'JJ-01', code: 'EQ2024008', rfid: 'RFID008', status: '正常', nextMaintain: '2026-07', icon: <HeartPulse size={32} />, iconBg: '#D1FAE5', iconColor: '#10B981' },
  { id: 9, name: '防割手套', model: 'FG-ST01', code: 'EQ2024009', rfid: 'RFID009', status: '正常', nextMaintain: '2026-11', icon: <Shield size={32} />, iconBg: '#D1FAE5', iconColor: '#10B981' },
  { id: 10, name: '警务通', model: 'JW-T800', code: 'EQ2024010', rfid: 'RFID010', status: '正常', nextMaintain: '2026-08', icon: <FileText size={32} />, iconBg: '#E8F0FE', iconColor: '#1A56DB' },
  { id: 11, name: '伸缩警棍', model: 'SG-01', code: 'EQ2024011', rfid: 'RFID011', status: '待保养', nextMaintain: '2026-06-20', icon: <Shield size={32} />, iconBg: '#FEF3C7', iconColor: '#D97706' },
  { id: 12, name: '反光背心', model: 'FG-BX01', code: 'EQ2024012', rfid: 'RFID012', status: '正常', nextMaintain: '2026-12', icon: <Shield size={32} />, iconBg: '#FEF3C7', iconColor: '#F59E0B' },
]

/* ── stat card (compact) ── */
function CompactStatCard({
  icon, color, label, value, delay = 0,
}: {
  icon: React.ReactNode; color: string; label: string; value: number; delay?: number
}) {
  const count = useCountUp(value, 600, delay)
  return (
    <div className="rounded-lg bg-white p-4 shadow-sm transition hover:shadow-md">
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-full" style={{ backgroundColor: `${color}18` }}>
          <span style={{ color }}>{icon}</span>
        </div>
        <div>
          <div className="text-xs text-[#6B7280]">{label}</div>
          <div className="text-xl font-bold" style={{ color }}>{count}</div>
        </div>
      </div>
    </div>
  )
}

/* ── maintenance warning ── */
function MaintainWarning({ dateStr }: { dateStr: string | null }) {
  if (!dateStr) return <span className="text-xs text-[#9CA3AF]">无保养要求</span>
  const daysLeft = Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000)
  if (daysLeft < 0) return <span className="text-xs font-medium text-[#DC2626]"><AlertTriangle size={11} className="inline" /> 已过期</span>
  if (daysLeft < 30) return <span className="text-xs font-medium text-[#D97706]"><Clock size={11} className="inline" /> 剩{daysLeft}天</span>
  return <span className="text-xs text-[#6B7280]">下次保养：{dateStr}</span>
}

/* ── main component ── */
export default function MyEquipmentPage() {
  const total = equipmentList.length
  const normalCount = equipmentList.filter((e) => e.status === '正常').length
  const maintainCount = equipmentList.filter((e) => e.status === '待保养').length
  const repairCount = equipmentList.filter((e) => e.status === '报修中').length
  const scrapCount = equipmentList.filter((e) => e.status === '待报废').length

  const [searchText, setSearchText] = useState('')

  const filteredList = equipmentList.filter(
    (e) =>
      !searchText ||
      e.name.includes(searchText) ||
      e.model.includes(searchText) ||
      e.code.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">我的装备</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
          <Download size={14} />
          导出装备卡(PDF)
        </button>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <CompactStatCard icon={<Package size={18} />} color="#1A56DB" label="持有总数" value={total} delay={0} />
        <CompactStatCard icon={<CheckCircle size={18} />} color="#10B981" label="正常" value={normalCount} delay={80} />
        <CompactStatCard icon={<Clock size={18} />} color="#F59E0B" label="待保养" value={maintainCount} delay={160} />
        <CompactStatCard icon={<Wrench size={18} />} color="#3B82F6" label="报修中" value={repairCount} delay={240} />
        <CompactStatCard icon={<Trash2 size={18} />} color="#EF4444" label="待报废" value={scrapCount} delay={320} />
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索装备名称、型号、编码..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Equipment Card Grid ── */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filteredList.map((eq, idx) => (
          <div
            key={eq.id}
            className={cn(
              'group overflow-hidden rounded-lg bg-white shadow-md transition-all duration-150 hover:-translate-y-0.5 hover:shadow-lg',
              cardBorderClass(eq.status)
            )}
            style={{ animation: `fadeSlideIn 0.3s ease-out ${idx * 60}ms both` }}
          >
            {/* Image / Icon Area */}
            <div className="flex h-[100px] items-center justify-center bg-[#F3F4F6] transition-all duration-200 group-hover:brightness-95">
              <div
                className="flex h-14 w-14 items-center justify-center rounded-full transition-transform duration-200 group-hover:scale-105"
                style={{ backgroundColor: eq.iconBg, color: eq.iconColor }}
              >
                {eq.icon}
              </div>
            </div>

            {/* Info Area */}
            <div className="p-3">
              <h3 className="truncate text-base font-semibold text-[#1F2937]">{eq.name}</h3>
              <div className="mt-1 space-y-0.5 text-[13px] text-[#6B7280]">
                <div className="truncate">型号：{eq.model}</div>
                <div className="truncate">编码：{eq.code}</div>
                <div className="truncate">RFID：{eq.rfid}</div>
              </div>

              {/* Status */}
              <div className="mt-2 flex items-center justify-between">
                <StatusBadge status={eq.status} />
                <MaintainWarning dateStr={eq.nextMaintain} />
              </div>

              {/* Actions */}
              <div className="mt-3 flex items-center gap-2 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
                <button className="inline-flex h-7 flex-1 items-center justify-center gap-1 rounded-md border border-[#1A56DB] text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                  <Eye size={12} /> 查看
                </button>
                <button className="inline-flex h-7 flex-1 items-center justify-center gap-1 rounded-md bg-[#1A56DB] text-xs text-white transition hover:bg-[#153E7E]">
                  <Wrench size={12} /> 报修
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Empty state */}
      {filteredList.length === 0 && (
        <div className="py-12 text-center text-[#9CA3AF]">
          <Package size={48} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">未找到匹配的装备</p>
        </div>
      )}

      {/* ── Animation styles ── */}
      <style>{`
        @keyframes fadeSlideIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  )
}
