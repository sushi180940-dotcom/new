import { useState } from 'react'
import { FileText, Play, Star, Eye, Download, Upload, FolderPlus, Grid3X3, List } from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
type MaterialType = '全部' | '操作手册' | '视频教程' | '课件' | '其他'

interface Material {
  id: number
  title: string
  type: MaterialType
  fileType: string
  size: string
  views: number
  downloads: number
  rating: number
  duration?: string
  color: string
  icon: 'pdf' | 'word' | 'ppt' | 'video' | 'image'
}

/* ── mock data ── */
const materials: Material[] = [
  { id: 1, title: '操作手册-防弹背心', type: '操作手册', fileType: 'PDF', size: '2.5MB', views: 1234, downloads: 567, rating: 4.8, color: '#EF4444', icon: 'pdf' },
  { id: 2, title: '执法记录仪操作教程', type: '视频教程', fileType: 'MP4', size: '156MB', views: 3456, downloads: 234, rating: 4.9, duration: '05:32', color: '#8B5CF6', icon: 'video' },
  { id: 3, title: '新警装备培训课程', type: '课件', fileType: 'PPT', size: '12MB', views: 890, downloads: 123, rating: 4.5, color: '#F59E0B', icon: 'ppt' },
  { id: 4, title: '急救包使用指南', type: '操作手册', fileType: 'PDF', size: '1.8MB', views: 2100, downloads: 890, rating: 4.7, color: '#EF4444', icon: 'pdf' },
  { id: 5, title: '手铐规范操作视频', type: '视频教程', fileType: 'MP4', size: '89MB', views: 4567, downloads: 345, rating: 4.6, duration: '08:15', color: '#8B5CF6', icon: 'video' },
  { id: 6, title: '防刺服保养与维护', type: '操作手册', fileType: 'PDF', size: '3.2MB', views: 780, downloads: 234, rating: 4.3, color: '#EF4444', icon: 'pdf' },
  { id: 7, title: '装备管理制度解读', type: '课件', fileType: 'PPT', size: '8MB', views: 1567, downloads: 178, rating: 4.4, color: '#F59E0B', icon: 'ppt' },
  { id: 8, title: '催泪喷射器使用规范', type: '视频教程', fileType: 'MP4', size: '67MB', views: 5678, downloads: 456, rating: 4.8, duration: '06:48', color: '#8B5CF6', icon: 'video' },
  { id: 9, title: '对讲机操作与维护手册', type: '操作手册', fileType: 'PDF', size: '4.5MB', views: 980, downloads: 312, rating: 4.2, color: '#EF4444', icon: 'pdf' },
  { id: 10, title: '防弹头盔佩戴教程', type: '视频教程', fileType: 'MP4', size: '45MB', views: 2345, downloads: 189, rating: 4.5, duration: '04:22', color: '#8B5CF6', icon: 'video' },
  { id: 11, title: '警用装备采购规范', type: '课件', fileType: 'PPT', size: '15MB', views: 670, downloads: 98, rating: 4.1, color: '#F59E0B', icon: 'ppt' },
  { id: 12, title: '强光手电使用说明', type: '操作手册', fileType: 'PDF', size: '1.2MB', views: 1890, downloads: 678, rating: 4.6, color: '#3B82F6', icon: 'word' },
]

const typeCounts: Record<string, number> = {
  '全部': materials.length,
  '操作手册': materials.filter((m) => m.type === '操作手册').length,
  '视频教程': materials.filter((m) => m.type === '视频教程').length,
  '课件': materials.filter((m) => m.type === '课件').length,
  '其他': materials.filter((m) => m.type === '其他').length,
}

const typeColors: Record<string, string> = {
  '操作手册': '#1A56DB',
  '视频教程': '#8B5CF6',
  '课件': '#F59E0B',
  '其他': '#6B7280',
}

function FileIcon({ icon, color, size = 48 }: { icon: string; color: string; size?: number }) {
  const s = size
  if (icon === 'pdf') return <div className="flex h-16 w-16 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={s} style={{ color }} /></div>
  if (icon === 'video') return <div className="flex h-16 w-16 items-center justify-center rounded-lg" style={{ background: color + '15' }}><Play size={s} style={{ color }} /></div>
  if (icon === 'ppt') return <div className="flex h-16 w-16 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={s} style={{ color }} /></div>
  return <div className="flex h-16 w-16 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={s} style={{ color }} /></div>
}

export default function MaterialsPage() {
  const [activeType, setActiveType] = useState<MaterialType>('全部')
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid')

  const filtered = activeType === '全部' ? materials : materials.filter((m) => m.type === activeType)

  const types: MaterialType[] = ['全部', '操作手册', '视频教程', '课件', '其他']

  return (
    <div>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">培训资料库</h1>
          <p className="mt-1 text-sm text-[#6B7280]">培训资料管理、预览与下载</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 rounded-md bg-[#1A56DB] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#153E7E]">
            <Upload size={16} /> 上传资料
          </button>
          <button className="flex items-center gap-2 rounded-md border border-[#D1D5DB] bg-white px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <FolderPlus size={16} /> 新建文件夹
          </button>
        </div>
      </div>

      {/* Category Filter */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setActiveType(t)}
              className={cn(
                'flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm font-medium transition',
                activeType === t
                  ? 'bg-[#1A56DB] text-white'
                  : 'border border-[#D1D5DB] bg-white text-[#374151] hover:bg-[#F3F4F6]'
              )}
            >
              {t}
              <span className={cn('rounded-full px-1.5 py-0 text-[10px]', activeType === t ? 'bg-white/20 text-white' : 'bg-[#F3F4F6] text-[#6B7280]')}>{typeCounts[t]}</span>
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 rounded-md border border-[#D1D5DB] bg-white p-0.5">
          <button onClick={() => setViewMode('grid')} className={cn('flex h-7 w-7 items-center justify-center rounded transition', viewMode === 'grid' ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#6B7280] hover:bg-[#F3F4F6]')}>
            <Grid3X3 size={14} />
          </button>
          <button onClick={() => setViewMode('list')} className={cn('flex h-7 w-7 items-center justify-center rounded transition', viewMode === 'list' ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#6B7280] hover:bg-[#F3F4F6]')}>
            <List size={14} />
          </button>
        </div>
      </div>

      {/* Cards Grid */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-4 gap-4">
          {filtered.map((m) => (
            <div
              key={m.id}
              className="group cursor-pointer rounded-lg bg-white p-4 shadow-md transition hover:-translate-y-0.5 hover:shadow-lg"
            >
              {/* Icon/Thumbnail area */}
              <div className="flex h-24 items-center justify-center rounded-lg bg-[#F9FAFB]">
                {m.icon === 'video' ? (
                  <div className="relative flex h-full w-full items-center justify-center rounded-lg bg-[#1F2937]">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/90 shadow-lg transition group-hover:scale-110">
                      <Play size={18} className="ml-0.5 text-[#1F2937]" />
                    </div>
                    {m.duration && (
                      <span className="absolute bottom-1 right-1 rounded bg-black/70 px-1.5 py-0.5 text-[10px] text-white">{m.duration}</span>
                    )}
                  </div>
                ) : (
                  <FileIcon icon={m.icon} color={m.color} />
                )}
              </div>

              {/* Info */}
              <div className="mt-3">
                <h3 className="line-clamp-2 text-sm font-semibold text-[#1F2937] transition group-hover:text-[#1A56DB]">{m.title}</h3>
                <div className="mt-1 flex items-center gap-2 text-xs text-[#6B7280]">
                  <span className="rounded px-1.5 py-0.5 text-[10px]" style={{ background: (typeColors[m.type] || '#6B7280') + '15', color: typeColors[m.type] || '#6B7280' }}>{m.type}</span>
                  <span>{m.fileType} · {m.size}</span>
                </div>
                <div className="mt-2 flex items-center gap-3 text-xs text-[#6B7280]">
                  <span className="flex items-center gap-1"><Eye size={12} /> {m.views.toLocaleString()}</span>
                  <span className="flex items-center gap-1"><Download size={12} /> {m.downloads.toLocaleString()}</span>
                  <span className="flex items-center gap-0.5"><Star size={12} className="fill-[#F59E0B] text-[#F59E0B]" /> {m.rating}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        /* List view */
        <div className="rounded-lg bg-white shadow-md">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['资料名称', '类型', '格式', '大小', '浏览量', '下载量', '评分', '操作'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((m, i) => (
                <tr key={m.id} className={cn('cursor-pointer border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <FileIcon icon={m.icon} color={m.color} size={20} />
                      <span className="font-medium text-[#1F2937]">{m.title}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3"><span className="rounded-full px-2 py-0.5 text-[10px]" style={{ background: (typeColors[m.type] || '#6B7280') + '15', color: typeColors[m.type] || '#6B7280' }}>{m.type}</span></td>
                  <td className="px-4 py-3 text-[#374151]">{m.fileType}</td>
                  <td className="px-4 py-3 text-[#374151]">{m.size}</td>
                  <td className="px-4 py-3 text-[#374151]">{m.views.toLocaleString()}</td>
                  <td className="px-4 py-3 text-[#374151]">{m.downloads.toLocaleString()}</td>
                  <td className="px-4 py-3"><span className="flex items-center gap-1"><Star size={12} className="fill-[#F59E0B] text-[#F59E0B]" /> {m.rating}</span></td>
                  <td className="px-4 py-3"><button className="text-xs text-[#1A56DB] hover:underline">下载</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      <div className="mt-4 flex items-center justify-between text-sm text-[#6B7280]">
        <span>共 {filtered.length} 条记录</span>
        <div className="flex items-center gap-1">
          <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6]">&lt;</button>
          <button className="flex h-8 w-8 items-center justify-center rounded-md bg-[#1A56DB] text-white">1</button>
          <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6]">&gt;</button>
        </div>
      </div>
    </div>
  )
}
