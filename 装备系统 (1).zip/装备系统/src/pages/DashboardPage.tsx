import { useState, useEffect } from 'react'
import ReactECharts from 'echarts-for-react'

interface DashboardProps {
  onNavigate?: (module: string, subTab?: string) => void
}

function AnimatedNumber({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      setDisplay(Math.floor((1 - Math.pow(1 - progress, 3)) * value))
      if (progress < 1) requestAnimationFrame(animate)
    }
    requestAnimationFrame(animate)
  }, [value, duration])
  return <span>{display.toLocaleString()}</span>
}

/* ================================================================
   业务流水数据
   ================================================================ */
type BizType = '调拨' | '领用' | '报修' | '报废' | '所队配发'

const bizColors: Record<BizType, string> = {
  '调拨': '#1890ff', '领用': '#722ed1', '报修': '#faad14', '报废': '#ff4d4f', '所队配发': '#52c41a',
}

/* 调拨：调拨单号，调拨单位，装备清单，申请时间 */
interface TransferRecord { type: '调拨'; no: string; unit: string; equipList: string; time: string }
/* 领用：申请单位/人，类型（借用/领用），装备清单，申请时间 */
interface BorrowRecord { type: '领用'; applicant: string; borrowType: string; equipList: string; time: string }
/* 报修：申请单位/人，装备清单，申请时间 */
interface RepairRecord { type: '报修'; applicant: string; equipList: string; time: string }
/* 报废：申请单位/人，装备清单，申请时间 */
interface ScrapRecord { type: '报废'; applicant: string; equipList: string; time: string }
/* 所队配发：配发单位，装备清单，申请时间 */
interface DistributeRecord { type: '所队配发'; unit: string; equipList: string; time: string }

type BizRecord = TransferRecord | BorrowRecord | RepairRecord | ScrapRecord | DistributeRecord

const bizRecords: Record<BizType, BizRecord[]> = {
  '调拨': [
    { type: '调拨', no: 'DB2024001', unit: '省厅主仓库 → 市局限装备仓库', equipList: '手持终端 XT-2000 x5', time: '2024-03-15 09:30' },
    { type: '调拨', no: 'DB2024002', unit: '市局限装备仓库 → 区县装备室', equipList: '防弹背心 FDY-3R x3', time: '2024-03-15 10:15' },
    { type: '调拨', no: 'DB2024003', unit: '省厅主仓库 → 交警总队', equipList: '执法记录仪 DSJ-A7 x10', time: '2024-03-15 11:00' },
    { type: '调拨', no: 'DB2024004', unit: '区县装备室 → 派出所', equipList: '对讲机 PD780G x8', time: '2024-03-15 14:20' },
    { type: '调拨', no: 'DB2024005', unit: '省厅主仓库 → 特警支队', equipList: '战术头盔 MICH-2000 x6', time: '2024-03-15 08:00' },
    { type: '调拨', no: 'DB2024006', unit: '市局限装备仓库 → 刑警支队', equipList: '防暴盾牌 FB-P x4', time: '2024-03-14 16:30' },
  ],
  '领用': [
    { type: '领用', applicant: '王志强/特警支队', borrowType: '领用', equipList: '手持终端 XT-2000 x2', time: '2024-03-15 08:30' },
    { type: '领用', applicant: '赵明华/交警大队', borrowType: '借用', equipList: '执法记录仪 DSJ-A7 x3', time: '2024-03-15 09:45' },
    { type: '领用', applicant: '陈晓东/网安支队', borrowType: '领用', equipList: '对讲机 PD780G x5', time: '2024-03-15 13:20' },
    { type: '领用', applicant: '刘建华/巡警支队', borrowType: '借用', equipList: '防弹背心 FDY-3R x2', time: '2024-03-15 15:00' },
    { type: '领用', applicant: '孙德胜/审计处', borrowType: '领用', equipList: '战术头盔 MICH-2000 x1', time: '2024-03-15 16:30' },
    { type: '领用', applicant: '周文博/仓库管理组', borrowType: '领用', equipList: '应急照明灯 YD-100 x4', time: '2024-03-14 10:00' },
  ],
  '报修': [
    { type: '报修', applicant: '郑国强/设备维护组', equipList: '手持终端 XT-2000（屏幕故障）', time: '2024-03-15 08:15' },
    { type: '报修', applicant: '孙德胜/技术保障组', equipList: '对讲机 PD780G（无法开机）', time: '2024-03-15 09:30' },
    { type: '报修', applicant: '马为民/资产管理组', equipList: '执法记录仪 DSJ-A7（摄像头模糊）', time: '2024-03-15 11:00' },
    { type: '报修', applicant: '黄志勇/指挥中心', equipList: '应急照明灯 YD-100（电池损坏）', time: '2024-03-15 13:45' },
    { type: '报修', applicant: '周丽华/审计处', equipList: '防弹背心 FDY-3R（ strap断裂）', time: '2024-03-15 15:20' },
    { type: '报修', applicant: '吴天明/督查室', equipList: '战术头盔 MICH-2000（面罩松动）', time: '2024-03-14 14:00' },
  ],
  '报废': [
    { type: '报废', applicant: '马为民/资产管理组', equipList: '手持终端 XT-2000（使用年限到期）', time: '2024-03-14 10:00' },
    { type: '报废', applicant: '黄志勇/指挥中心', equipList: '对讲机 PD780G（无法修复）', time: '2024-03-14 11:30' },
    { type: '报废', applicant: '赵明华/交警大队', equipList: '执法记录仪 DSJ-A7（主板烧毁）', time: '2024-03-14 14:00' },
    { type: '报废', applicant: '周丽华/审计处', equipList: '防弹背心 FDY-3R（防护等级不达标）', time: '2024-03-14 16:30' },
    { type: '报废', applicant: '吴天明/督查室', equipList: '应急照明灯 YD-100（灯管老化）', time: '2024-03-15 09:15' },
    { type: '报废', applicant: '王建国/刑警支队', equipList: '战术头盔 MICH-2000（外壳破裂）', time: '2024-03-15 11:00' },
  ],
  '所队配发': [
    { type: '所队配发', unit: '刑警支队', equipList: '手持终端 XT-2000 x10, 对讲机 x5', time: '2024-03-15 09:00' },
    { type: '所队配发', unit: '交警大队', equipList: '执法记录仪 DSJ-A7 x15, 防弹背心 x8', time: '2024-03-15 10:30' },
    { type: '所队配发', unit: '特警支队', equipList: '战术头盔 MICH-2000 x12, 防暴盾牌 x6', time: '2024-03-15 13:00' },
    { type: '所队配发', unit: '巡警支队', equipList: '对讲机 PD780G x10, 应急照明灯 x5', time: '2024-03-15 14:30' },
    { type: '所队配发', unit: '网安支队', equipList: '手持终端 XT-2000 x8, 执法记录仪 x6', time: '2024-03-14 11:00' },
    { type: '所队配发', unit: '派出所', equipList: '对讲机 PD780G x6, 防弹背心 x4', time: '2024-03-14 15:00' },
  ],
}

/* ================================================================
   预警记录数据
   ================================================================ */
const warningRecords = [
  { name: '手持终端 XT-2000', detail: '库存低于安全线（当前15件，安全库存25件）', time: '10:30', level: 'warning' },
  { name: '防弹背心 FDY-3R', detail: '库存即将耗尽（当前3件，安全库存10件）', time: '09:45', level: 'danger' },
  { name: '对讲机 PD780G', detail: '库存低于预设值（当前8件，安全库存20件）', time: '09:15', level: 'warning' },
  { name: '应急照明灯 YD-100', detail: '库存补充提醒（当前12件，安全库存15件）', time: '08:50', level: 'remind' },
  { name: '执法记录仪 DSJ-A7', detail: '即将过质保期（剩余30天）', time: '11:00', level: 'warning' },
  { name: '手持终端 XT-2000', detail: '连续超期未归还（已超期15天）', time: '10:15', level: 'danger' },
  { name: '战术头盔 MICH-2000', detail: '保养周期到期（剩余7天）', time: '08:20', level: 'remind' },
  { name: '防暴盾牌 FB-P', detail: '检测到异常出库（昨日出库10件）', time: '09:30', level: 'warning' },
]

const levelMap: Record<string, { label: string; color: string; bg: string }> = {
  warning: { label: '警告', color: '#d4880f', bg: '#f5efe6' },
  danger: { label: '紧急', color: '#c0392b', bg: '#f5e6e6' },
  remind: { label: '提醒', color: '#1a4b8c', bg: '#e8eef5' },
}

/* ================
   主组件
   ================ */
export default function DashboardPage({ onNavigate }: DashboardProps) {
  const commonFunctions = [
    { label: '采购及售后管理', icon: 'M3 3h18v18H3V3zm16 16V5H5v14h14zM7 7h4v4H7V7zm0 6h4v4H7v-4zm6-6h4v4h-4V7zm0 6h4v4h-4v-4z', color: '#1a4b8c', onClick: () => onNavigate?.('procurement') },
    { label: '仓库管理', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z', color: '#1a4b8c', onClick: () => onNavigate?.('warehouse-mgmt') },
    { label: '装备领用', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', color: '#1a4b8c', onClick: () => onNavigate?.('equip-borrow') },
    { label: '报修管理', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z', color: '#1a4b8c', onClick: () => onNavigate?.('repair') },
    { label: '装备研判分析', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 002 2h2a2 2 0 002-2v-6', color: '#1a4b8c', onClick: () => onNavigate?.('analysis') },
    { label: '系统管理', icon: 'M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm0-14a4 4 0 100 8 4 4 0 000-8z', color: '#1a4b8c', onClick: () => onNavigate?.('system') },
  ]

  // 实时数据
  const statCards = [
    { label: '全省装备数量', value: 156230, unit: '件', color: '#1a4b8c', bg: '#e8eef5', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
    { label: '全省应急装备数量', value: 28356, unit: '件', color: '#1a4b8c', bg: '#e8eef5', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z' },
    { label: '供应商数量', value: 156, unit: '家', color: '#1a4b8c', bg: '#e8eef5', icon: 'M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z' },
    { label: '商品数量', value: 3680, unit: '种', color: '#1a4b8c', bg: '#e8eef5', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
  ]

  /* ================================================================
     待办业务数据
     ================================================================ */
  type TodoType = '待验收' | '调拨审批' | '待审核装备' | '待审核供应商'

  const todoTypeMap: Record<TodoType, { color: string; bg: string; module: string; subTab: string }> = {
    '待验收':       { color: '#d4880f', bg: '#f5efe6', module: 'procurement', subTab: 'order' },
    '调拨审批':     { color: '#c0392b', bg: '#f5e6e6', module: 'emergency',   subTab: 'transfer' },
    '待审核装备':   { color: '#1a4b8c', bg: '#e8eef5', module: 'supplier',    subTab: 'product' },
    '待审核供应商': { color: '#52c41a', bg: '#f6ffed', module: 'supplier',    subTab: 'enterprise' },
  }

  const todoRecords = [
    { type: '待验收' as TodoType,       title: '执法记录仪 DSJ-A7 x 2', desc: '等待入库验收',                        time: '10:30' },
    { type: '调拨审批' as TodoType,     title: '防弹背心 FDY-3R x 3',   desc: '市局限装备仓库 → 区县装备室',         time: '09:45' },
    { type: '待审核装备' as TodoType,   title: '防暴盾牌 FB-P',         desc: '大华安防提交装备基础信息与审核',      time: '09:15' },
    { type: '待审核供应商' as TodoType, title: '大华安防科技有限公司',   desc: '供应商资质审核',                      time: '08:30' },
  ]

  // 业务记录
  const bizTabs: BizType[] = ['调拨', '领用', '报修', '报废', '所队配发']
  const [activeBizTab, setActiveBizTab] = useState<BizType>('调拨')

  const statusTagMap: Record<string, string> = {
    '已出库': 'tag-green', '已入库': 'tag-green', '已领用': 'tag-green', '已完成': 'tag-green', '已报废': 'tag-green',
    '出库中': 'tag-orange', '入库中': 'tag-orange', '维修中': 'tag-orange', '审批中': 'tag-purple',
    '待出库': 'tag-yellow', '待验收': 'tag-yellow', '待审批': 'tag-yellow', '待盘点': 'tag-yellow', '待处理': 'tag-yellow',
  }

  return (
    <div className="p-4 space-y-4">
      {/* ============ 常用功能 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>常用功能</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {commonFunctions.map(item => (
            <button
              key={item.label}
              onClick={item.onClick || (() => alert('功能开发中...'))}
              className="content-card p-4 flex flex-col items-center gap-3 hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110" style={{ background: `${item.color}15` }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={item.icon} /></svg>
              </div>
              <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ============ 实时数据展示 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>实时数据展示</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map(card => (
            <div key={card.label} className="content-card p-5 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: card.bg }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="1.5"><path d={card.icon} /></svg>
              </div>
              <div>
                <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                <div className="text-2xl font-bold" style={{ color: card.color }}><AnimatedNumber value={card.value} /></div>
                <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{card.unit}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============ 待办事项/已办事项 + 预警记录（同一行） ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>待办事项/已办事项</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 业务记录 */}
          <div className="content-card p-4">
            <div className="flex gap-1 border-b mb-3 overflow-x-auto" style={{ borderColor: 'var(--border-color)' }}>
              {bizTabs.map(tab => (
                <button
                  key={tab}
                  className={activeBizTab === tab
                    ? 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--primary-blue)] whitespace-nowrap'
                    : 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)] whitespace-nowrap'
                  }
                  onClick={() => setActiveBizTab(tab)}
                >
                  {tab}
                  {activeBizTab === tab && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: 'var(--primary-blue)' }} />
                  )}
                </button>
              ))}
            </div>
            <div className="space-y-2 max-h-[360px] overflow-y-auto">
              {bizRecords[activeBizTab].map((r, i) => (
                <div key={i} className="p-2.5 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-1.5 min-w-0">
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: bizColors[r.type] }} />
                      <span className="text-xs font-medium" style={{ color: 'var(--primary-blue)' }}>
                        {r.type === '调拨' ? r.no : r.type === '领用' ? r.applicant : r.type === '报修' ? r.applicant : r.type === '报废' ? r.applicant : r.unit}
                      </span>
                    </div>
                    <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>{r.time}</span>
                  </div>
                  {'borrowType' in r && (
                    <div className="text-[11px] mb-0.5" style={{ color: 'var(--text-secondary)' }}>
                      类型：{r.borrowType}
                    </div>
                  )}
                  <div className="text-[11px]" style={{ color: 'var(--text-secondary)' }}>
                    {r.type === '调拨' ? `调拨单位：${r.unit}` : r.type === '所队配发' ? `配发单位：${r.unit}` : `申请人：${r.applicant}`}
                  </div>
                  <div className="text-[11px] mt-0.5 truncate" style={{ color: 'var(--text-secondary)' }}>
                    装备清单：{r.equipList}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 待办业务 */}
          <div className="content-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">待办业务</h3>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#f5e6e6', color: '#c0392b' }}>{todoRecords.length} 条待处理</span>
            </div>
            <div className="space-y-2">
              {todoRecords.map((item, idx) => {
                const t = todoTypeMap[item.type]
                return (
                  <div
                    key={idx}
                    onClick={() => onNavigate?.(t.module, t.subTab)}
                    className="p-3 rounded-lg border cursor-pointer hover:border-blue-300 hover:shadow-sm transition-all"
                    style={{ borderColor: 'var(--border-color)' }}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-medium truncate flex-1 mr-2">{item.title}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded flex-shrink-0" style={{ background: t.bg, color: t.color }}>{item.type}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs truncate flex-1 mr-2" style={{ color: 'var(--text-secondary)' }}>{item.desc}</span>
                      <span className="text-[10px] flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>{item.time}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>

          {/* 预警记录 */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-3">预警记录</h3>
            <div className="space-y-2">
              {warningRecords.map((item, i) => {
                const l = levelMap[item.level]
                return (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg" style={{ background: l.bg }}>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.detail}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                      <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{item.time}</span>
                      <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: '#fff', color: l.color, border: `1px solid ${l.color}` }}>{l.label}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>

    </div>
  )
}
