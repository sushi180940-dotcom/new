import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

const tabList = [
  { key: 'alert', label: '预警查询' },
  { key: 'rule-cfg', label: '装备监督' },
  { key: 'subscribe', label: '监督订阅' },
  { key: 'control', label: '装备管控' },
]

interface TimeReminderConfig {
  beforeStart: boolean
  beforeStartDays: number
  beforeExpire: boolean
  beforeExpireDays: number
  afterOverdue: boolean
}

interface StockReminderConfig {
  equipName: string
  equipCode: string
  thresholdType: 'quantity' | 'percentage'
  thresholdValue: number
}

interface WarningRule {
  id: string
  name: string
  description: string
  warningType: 'overdue' | 'maintenance' | 'warranty' | 'stock' | 'abnormal_io'
  triggerConfig: TimeReminderConfig | StockReminderConfig[] | null
  level: 'high' | 'medium' | 'low'
  status: 'active' | 'disabled'
}

interface AlertRecord {
  id: string
  type: string
  time: string
  content: string
  status: 'pending' | 'confirmed' | 'resolved' | 'ignored'
  handler?: string
  handleTime?: string
  handleResult?: string
  ignoreReason?: string
}

interface ControlRecord {
  id: string
  target: string
  reason: string
  startTime: string
  endTime: string
  owner: string
  status: 'active' | 'released'
}

// ========== 提醒订阅 ==========
interface Subscription {
  id: string
  subscriber: string
  subscriberId: string
  isSelf: boolean
  warningTypes: string[]
  notifyMethod: ('site' | 'sms')[]
  dailyCount: number
  intervalMinutes: number
  maxReminderDays: number
  status: 'active' | 'paused'
  createTime: string
  upgradeConfig: {
    enabled: boolean
    timeValue: number
    timeUnit: 'hour' | 'day'
    notifySuperior: boolean
  }
}

export default function SupervisionPage({ activeSubTab, onNavigate }: Props) {
  const validTabKeys = [...tabList.map(t => t.key), 'control']
  const [activeTab, setActiveTab] = useState(activeSubTab && validTabKeys.includes(activeSubTab) ? activeSubTab : 'alert')
  useEffect(() => {
    if (activeSubTab && validTabKeys.includes(activeSubTab)) setActiveTab(activeSubTab)
  }, [activeSubTab])

  // ===== 预警规则 states =====
  const [rules, setRules] = useState<WarningRule[]>([
    {
      id: 'SYS001', name: '质保到期提醒', description: '装备质保期即将到期，提醒相关人员及时处理',
      warningType: 'warranty', level: 'high', status: 'active',
      triggerConfig: { beforeStart: false, beforeStartDays: 0, beforeExpire: true, beforeExpireDays: 30, afterOverdue: true }
    },
    {
      id: 'SYS002', name: '安全库存提醒', description: '手持终端库存低于安全阈值时自动预警',
      warningType: 'stock', level: 'high', status: 'active',
      triggerConfig: [{ equipName: '手持终端', equipCode: 'P001', thresholdType: 'quantity', thresholdValue: 20 }]
    },
    {
      id: 'SYS003', name: '超期预警', description: '装备借用超期未归还提醒',
      warningType: 'overdue', level: 'medium', status: 'active',
      triggerConfig: { beforeStart: false, beforeStartDays: 0, beforeExpire: false, beforeExpireDays: 0, afterOverdue: true }
    },
    {
      id: 'SYS004', name: '保养提醒', description: '定期保养时间节点提醒',
      warningType: 'maintenance', level: 'medium', status: 'active',
      triggerConfig: { beforeStart: true, beforeStartDays: 3, beforeExpire: false, beforeExpireDays: 0, afterOverdue: true }
    },
    {
      id: 'SYS005', name: '异常出入库提醒', description: '门禁检测到未经系统的出入库操作',
      warningType: 'abnormal_io', level: 'high', status: 'active',
      triggerConfig: null
    },
  ])
  const [ruleModalOpen, setRuleModalOpen] = useState(false)
  const [ruleModalMode, setRuleModalMode] = useState<'add' | 'edit' | 'view'>('add')
  const [editingRule, setEditingRule] = useState<WarningRule | null>(null)
  const [ruleForm, setRuleForm] = useState({
    name: '', description: '', warningType: 'overdue' as WarningRule['warningType'],
    level: 'high' as 'high' | 'medium' | 'low',
    timeConfig: { beforeStart: false, beforeStartDays: 0, beforeExpire: false, beforeExpireDays: 0, afterOverdue: false } as TimeReminderConfig,
    stockConfig: [{ equipName: '', equipCode: '', thresholdType: 'quantity' as 'quantity' | 'percentage', thresholdValue: 0 }] as StockReminderConfig[],
  })
  const [ruleDeleteConfirm, setRuleDeleteConfirm] = useState<string | null>(null)

  // ===== 预警查询 states =====
  const [alerts, setAlerts] = useState<AlertRecord[]>([
    { id: 'YJ000001', type: '库存过低', time: '2024-06-15 10:23:15', content: 'A栋仓库-手持终端库存15<25', status: 'pending' },
    { id: 'YJ000002', type: '质保到期', time: '2024-06-15 09:00:00', content: 'ZB001质保将于3天后到期', status: 'confirmed', handler: '张三', handleTime: '2024-06-15 09:30', handleResult: '已通知相关责任人处理' },
    { id: 'YJ000003', type: '超期未保养', time: '2024-06-14 14:35:22', content: '执法记录仪ZB002超过保养周期30天', status: 'pending' },
    { id: 'YJ000004', type: '异常出库', time: '2024-06-14 08:15:06', content: 'C栋仓库-对讲机单日出库量超过阈值50台', status: 'ignored', handler: '李四', handleTime: '2024-06-14 09:00', handleResult: '节假日集中调拨，属正常业务', ignoreReason: '节假日集中调拨，属正常业务' },
  ])
  const [alertDetailOpen, setAlertDetailOpen] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<AlertRecord | null>(null)
  const [alertHandleOpen, setAlertHandleOpen] = useState(false)
  const [handleResult, setHandleResult] = useState('')
  const [alertIgnoreOpen, setAlertIgnoreOpen] = useState(false)
  const [ignoreReason, setIgnoreReason] = useState('')

  // ===== 装备管控 states =====
  const [controls, setControls] = useState<ControlRecord[]>([
    { id: 'GK000001', target: '华为技术', reason: '质量问题批次', startTime: '2024-01-10', endTime: '2024-07-10', owner: '张三', status: 'active' },
    { id: 'GK000002', target: 'ZB005批次', reason: '安全隐患', startTime: '2024-02-01', endTime: '-', owner: '李四', status: 'active' },
    { id: 'GK000003', target: 'XX电子', reason: '资质过期', startTime: '2023-12-01', endTime: '2024-01-15', owner: '王五', status: 'released' },
  ])
  const [controlModalOpen, setControlModalOpen] = useState(false)
  const [controlModalMode, setControlModalMode] = useState<'add' | 'view'>('add')
  const [selectedControl, setSelectedControl] = useState<ControlRecord | null>(null)
  const [controlForm, setControlForm] = useState({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
  const [controlTargetSearch, setControlTargetSearch] = useState('')
  const [showTargetDropdown, setShowTargetDropdown] = useState(false)
  const [showOwnerTree, setShowOwnerTree] = useState(false)
  const systemTargets = ['华为技术有限公司', '中兴通讯股份有限公司', '海康威视数字技术', '大疆创新科技有限公司', '海能达通信股份有限公司', '紫光电子集团有限公司']
  const controlOwnerTree = [
    { id: 'D001', name: '一部', members: [{ id: 'U101', name: '张三' }, { id: 'U102', name: '李四' }] },
    { id: 'D002', name: '二部', members: [{ id: 'U201', name: '王五' }, { id: 'U202', name: '赵六' }] },
    { id: 'D003', name: '三部', members: [{ id: 'U301', name: '孙七' }, { id: 'U302', name: '周八' }] },
  ]
  const [releaseConfirmOpen, setReleaseConfirmOpen] = useState(false)
  const [releasingControlId, setReleasingControlId] = useState<string | null>(null)
  // ===== 提醒订阅 states =====
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([
    {
      id: 'SUB001', subscriber: '本人（管理员）', subscriberId: 'U001', isSelf: true,
      warningTypes: ['warranty', 'overdue'], notifyMethod: ['site', 'sms'],
      dailyCount: 3, intervalMinutes: 30, maxReminderDays: 7,
      status: 'active', createTime: '2024-03-01',
      upgradeConfig: { enabled: false, timeValue: 24, timeUnit: 'hour' as const, notifySuperior: false },
    },
    {
      id: 'SUB002', subscriber: '李四（下级）', subscriberId: 'U002', isSelf: false,
      warningTypes: ['stock', 'abnormal_io'], notifyMethod: ['site'],
      dailyCount: 2, intervalMinutes: 60, maxReminderDays: 3,
      status: 'active', createTime: '2024-03-05',
      upgradeConfig: { enabled: false, timeValue: 24, timeUnit: 'hour' as const, notifySuperior: false },
    },
    {
      id: 'SUB003', subscriber: '王五（下级）', subscriberId: 'U003', isSelf: false,
      warningTypes: ['maintenance'], notifyMethod: ['sms'],
      dailyCount: 1, intervalMinutes: 0, maxReminderDays: 5,
      status: 'paused', createTime: '2024-03-10',
      upgradeConfig: { enabled: false, timeValue: 24, timeUnit: 'hour' as const, notifySuperior: false },
    },
  ])
  const [subSearch, setSubSearch] = useState('')
  const [subModalOpen, setSubModalOpen] = useState(false)
  const [subMode, setSubMode] = useState<'add' | 'edit' | 'view'>('add')
  const [editingSub, setEditingSub] = useState<Subscription | null>(null)
  const [subForm, setSubForm] = useState({
    subscriber: '', isSelf: true as boolean, subDept: '', warningTypes: [] as string[], notifyMethod: [] as ('site' | 'sms')[], dailyCount: 3, intervalMinutes: 30, maxReminderDays: 7,
    upgradeEnabled: false, upgradeTimeValue: 24, upgradeTimeUnit: 'hour' as 'hour' | 'day', upgradeNotifySuperior: false,
  })
  const [showSubTree, setShowSubTree] = useState(false)
  const orgTree = [
    { id: 'D001', name: '一部', members: [{ id: 'U101', name: '赵六' }, { id: 'U102', name: '钱七' }] },
    { id: 'D002', name: '二部', members: [{ id: 'U201', name: '孙八' }, { id: 'U202', name: '周九' }] },
    { id: 'D003', name: '三部', members: [{ id: 'U301', name: '吴十' }, { id: 'U302', name: '郑一' }] },
  ]
  const [subDeleteConfirm, setSubDeleteConfirm] = useState<string | null>(null)


  // ===== helpers =====
  const levelConfig = {
    high: { label: '高', color: '#ff4d4f', bg: '#fff2f0' },
    medium: { label: '中', color: '#faad14', bg: '#fffbe6' },
    low: { label: '低', color: '#52c41a', bg: '#f6ffed' },
  }

  const alertStatusConfig: Record<string, { label: string; color: string; bg: string }> = {
    pending: { label: '待处理', color: '#ff4d4f', bg: '#fff2f0' },
    confirmed: { label: '已确认', color: '#faad14', bg: '#fffbe6' },
    resolved: { label: '已处理', color: '#52c41a', bg: '#f6ffed' },
    ignored: { label: '已忽略', color: '#8c8c8c', bg: '#f5f5f5' },
  }

  // ===== 预警规则操作 =====
  const openRuleModal = (mode: 'add' | 'edit' | 'view', rule?: WarningRule) => {
    setRuleModalMode(mode)
    if (rule) {
      setEditingRule(rule)
      const isStock = rule.warningType === 'stock'
      setRuleForm({
        name: rule.name, description: rule.description,
        warningType: rule.warningType, level: rule.level,
        timeConfig: isStock ? { beforeStart: false, beforeStartDays: 0, beforeExpire: false, beforeExpireDays: 0, afterOverdue: false } : (rule.triggerConfig as TimeReminderConfig) || { beforeStart: false, beforeStartDays: 0, beforeExpire: false, beforeExpireDays: 0, afterOverdue: false },
        stockConfig: isStock ? (rule.triggerConfig as StockReminderConfig[]) || [{ equipName: '', equipCode: '', thresholdType: 'quantity', thresholdValue: 0 }] : [{ equipName: '', equipCode: '', thresholdType: 'quantity', thresholdValue: 0 }],
      })
    } else {
      setEditingRule(null)
      setRuleForm({
        name: '', description: '', warningType: 'overdue', level: 'high',
        timeConfig: { beforeStart: false, beforeStartDays: 0, beforeExpire: false, beforeExpireDays: 0, afterOverdue: false },
        stockConfig: [{ equipName: '', equipCode: '', thresholdType: 'quantity', thresholdValue: 0 }],
      })
    }
    setRuleModalOpen(true)
  }

  const saveRule = () => {
    if (!ruleForm.name) return
    const isStockType = ruleForm.warningType === 'stock'
    const triggerConfig = ruleForm.warningType === 'abnormal_io' ? null : (isStockType ? ruleForm.stockConfig : ruleForm.timeConfig)
    if (ruleModalMode === 'add') {
      const newRule: WarningRule = {
        id: `CUS${String(Date.now()).slice(-4)}`,
        name: ruleForm.name, description: ruleForm.description,
        warningType: ruleForm.warningType, level: ruleForm.level,
        status: 'active', triggerConfig,
      }
      setRules(prev => [newRule, ...prev])
    } else if (ruleModalMode === 'edit' && editingRule) {
      setRules(prev => prev.map(r => r.id === editingRule.id ? {
        ...r, name: ruleForm.name, description: ruleForm.description,
        warningType: ruleForm.warningType, level: ruleForm.level, triggerConfig
      } : r))
    }
    setRuleModalOpen(false)
  }

  const toggleRuleStatus = (id: string) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, status: r.status === 'active' ? 'disabled' as const : 'active' as const } : r))
  }

  const deleteRule = (id: string) => {
    setRules(prev => prev.filter(r => r.id !== id))
    setRuleDeleteConfirm(null)
  }

  // ===== 预警查询操作 =====
  const openAlertDetail = (alert: AlertRecord, mode: 'view' | 'handle') => {
    setSelectedAlert(alert)
    if (mode === 'handle') {
      setHandleResult('')
      setAlertHandleOpen(true)
    } else {
      setAlertDetailOpen(true)
    }
  }

  const submitHandle = () => {
    if (!selectedAlert || !handleResult) return
    setAlerts(prev => prev.map(a => a.id === selectedAlert.id ? { ...a, status: 'resolved' as const, handler: '当前用户', handleTime: new Date().toISOString().slice(0, 16).replace('T', ' '), handleResult } : a))
    setAlertHandleOpen(false)
    setSelectedAlert(null)
    setHandleResult('')
  }

  const openIgnoreModal = (alert: AlertRecord) => {
    setSelectedAlert(alert)
    setIgnoreReason('')
    setAlertIgnoreOpen(true)
  }

  const submitIgnore = () => {
    if (!selectedAlert || !ignoreReason) return
    setAlerts(prev => prev.map(a => a.id === selectedAlert.id ? {
      ...a,
      status: 'ignored' as const,
      handler: '当前用户',
      handleTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
      handleResult: ignoreReason,
      ignoreReason,
    } : a))
    setAlertIgnoreOpen(false)
    setSelectedAlert(null)
    setIgnoreReason('')
  }

  // ===== 装备管控操作 =====
  const openControlModal = (mode: 'add' | 'view', control?: ControlRecord) => {
    setControlModalMode(mode)
    if (control) {
      setSelectedControl(control)
    } else {
      setSelectedControl(null)
      setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
      setControlTargetSearch('')
      setShowTargetDropdown(false)
      setShowOwnerTree(false)
    }
    setControlModalOpen(true)
  }

  const saveControl = () => {
    if (!controlForm.target || !controlForm.reason) return
    const newControl: ControlRecord = {
      id: `GK${String(Date.now()).slice(-6)}`,
      target: controlForm.target, reason: controlForm.reason,
      startTime: controlForm.startTime || new Date().toISOString().slice(0, 10),
      endTime: controlForm.endTime || '-', owner: controlForm.owner || '当前用户',
      status: 'active',
    }
    setControls(prev => [newControl, ...prev])
    setControlModalOpen(false)
    setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
    setControlTargetSearch('')
    setShowTargetDropdown(false)
    setShowOwnerTree(false)
  }
  const toggleNotifyMethod = (method: 'site' | 'sms') => {
    setSubForm(prev => ({
      ...prev,
      notifyMethod: prev.notifyMethod.includes(method)
        ? prev.notifyMethod.filter(m => m !== method)
        : [...prev.notifyMethod, method],
    }))
  }

  const toggleWarningType = (type: string) => {
    setSubForm(prev => ({
      ...prev,
      warningTypes: prev.warningTypes.includes(type)
        ? prev.warningTypes.filter(t => t !== type)
        : [...prev.warningTypes, type],
    }))
  }

  const openSubModal = (mode: 'add' | 'edit' | 'view', sub?: Subscription) => {
    setSubMode(mode)
    if (sub) {
      setEditingSub(sub)
      setSubForm({ subscriber: sub.subscriber, isSelf: sub.isSelf, subDept: '', warningTypes: [...sub.warningTypes], notifyMethod: [...sub.notifyMethod], dailyCount: sub.dailyCount, intervalMinutes: sub.intervalMinutes, maxReminderDays: sub.maxReminderDays, upgradeEnabled: sub.upgradeConfig.enabled, upgradeTimeValue: sub.upgradeConfig.timeValue, upgradeTimeUnit: sub.upgradeConfig.timeUnit, upgradeNotifySuperior: sub.upgradeConfig.notifySuperior })
    } else {
      setEditingSub(null)
      setSubForm({ subscriber: '本人（管理员）', isSelf: true, subDept: '', warningTypes: [], notifyMethod: ['site'], dailyCount: 3, intervalMinutes: 30, maxReminderDays: 7, upgradeEnabled: false, upgradeTimeValue: 24, upgradeTimeUnit: 'hour', upgradeNotifySuperior: false })
    }
    setShowSubTree(false)
    setSubModalOpen(true)
  }

  const saveSub = () => {
    if (!subForm.subscriber || subForm.warningTypes.length === 0 || subForm.notifyMethod.length === 0) return
    if (subMode === 'add') {
      setSubscriptions(prev => [{
        id: `SUB${String(Date.now()).slice(-4)}`,
        subscriber: subForm.subscriber, subscriberId: `U${String(Date.now()).slice(-4)}`,
        isSelf: subForm.isSelf, warningTypes: subForm.warningTypes, notifyMethod: subForm.notifyMethod,
        dailyCount: subForm.dailyCount, intervalMinutes: subForm.intervalMinutes, maxReminderDays: subForm.maxReminderDays,
        status: 'active', createTime: new Date().toISOString().slice(0, 10),
        upgradeConfig: { enabled: subForm.upgradeEnabled, timeValue: subForm.upgradeTimeValue, timeUnit: subForm.upgradeTimeUnit, notifySuperior: subForm.upgradeNotifySuperior },
      }, ...prev])
    } else if (subMode === 'edit' && editingSub) {
      setSubscriptions(prev => prev.map(s => s.id === editingSub.id ? { ...s, subscriber: subForm.subscriber, isSelf: subForm.isSelf, warningTypes: subForm.warningTypes, notifyMethod: subForm.notifyMethod, dailyCount: subForm.dailyCount, intervalMinutes: subForm.intervalMinutes, maxReminderDays: subForm.maxReminderDays, upgradeConfig: { enabled: subForm.upgradeEnabled, timeValue: subForm.upgradeTimeValue, timeUnit: subForm.upgradeTimeUnit, notifySuperior: subForm.upgradeNotifySuperior } } : s))
    }
    setSubModalOpen(false)
  }

  const toggleSubStatus = (id: string) => {
    setSubscriptions(prev => prev.map(s => s.id === id ? { ...s, status: s.status === 'active' ? 'paused' as const : 'active' as const } : s))
  }

  const deleteSub = (id: string) => {
    setSubscriptions(prev => prev.filter(s => s.id !== id))
    setSubDeleteConfirm(null)
  }


  const releaseControl = (id: string) => {
    setControls(prev => prev.map(c => c.id === id ? { ...c, status: 'released' as const, endTime: new Date().toISOString().slice(0, 10) } : c))
    setReleaseConfirmOpen(false)
    setReleasingControlId(null)
  }

  return (
    <div className="p-6 space-y-4">
      {/* 统计卡片 — 所有页面共享 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: '预警规则', value: `${rules.length} 条`, color: '#1890ff', icon: 'M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zm0-15v5h5' },
          { label: '启用规则', value: `${rules.filter(r => r.status === 'active').length} 条`, color: '#52c41a', icon: 'M22 11.08V12a10 10 0 11-5.93-9.14' },
          { label: '待处理预警', value: `${alerts.filter(a => a.status === 'pending').length} 条`, color: '#ff4d4f', icon: 'M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
          { label: '管控中装备', value: `${controls.filter(c => c.status === 'active').length} 件`, color: '#722ed1', icon: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z' },
          { label: '监督订阅', value: `${subscriptions.length} 条`, color: '#faad14', icon: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-lg font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 快捷入口 — 所有页面共享 */}
      <div className="content-card p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {[
            { key: 'alert', label: '预警查询', desc: '预警记录查询', color: '#52c41a', icon: 'M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z' },
            { key: 'rule-cfg', label: '装备监督', desc: '预警规则配置', color: '#1890ff', icon: 'M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10zm0-15v5h5' },
            { key: 'subscribe', label: '监督订阅', desc: '提醒订阅管理', color: '#faad14', icon: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9' },
            { key: 'control', label: '装备管控', desc: '装备管控管理', color: '#ff4d4f', icon: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': item.color } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                  <path d={item.icon}/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{item.label}</div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* ==================== 装备监督 ==================== */}
      {activeTab === 'rule-cfg' && (
        <>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button className="btn-primary flex items-center gap-1" onClick={() => openRuleModal('add')}>
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增预警规则</button>
            </div>
            <div className="flex gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border">系统预设 {rules.filter(r => r.id.startsWith('SYS')).length}</span>
              <span className="px-3 py-1 rounded-full border">自定义 {rules.filter(r => !r.id.startsWith('SYS')).length}</span>
            </div>
          </div>
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>预警类型ID</th><th>规则名称</th><th>预警类型</th><th>预警描述</th><th>严重程度</th><th>启用状态</th><th>操作</th></tr>
              </thead>
              <tbody>
                {rules.map(r => {
                  const typeLabels: Record<string, string> = { overdue: '超期预警', maintenance: '保养提醒', warranty: '质保提醒', stock: '安全库存提醒', abnormal_io: '异常出入库提醒' }
                  const typeColors: Record<string, string> = { overdue: '#ff4d4f', maintenance: '#1890ff', warranty: '#faad14', stock: '#52c41a', abnormal_io: '#722ed1' }
                  return (
                  <tr key={r.id} style={{ opacity: r.status === 'disabled' ? 0.5 : 1 }}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{r.id}</td>
                    <td className="font-medium">{r.name}</td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: `${typeColors[r.warningType]}15`, color: typeColors[r.warningType], border: `1px solid ${typeColors[r.warningType]}30` }}>{typeLabels[r.warningType]}</span></td>
                    <td className="text-xs max-w-xs truncate" style={{ color: 'var(--text-secondary)' }}>{r.description}</td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: levelConfig[r.level].bg, color: levelConfig[r.level].color, border: `1px solid ${levelConfig[r.level].color}30` }}>{levelConfig[r.level].label}</span></td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: r.status === 'active' ? '#f6ffed' : '#f5f5f5', color: r.status === 'active' ? '#52c41a' : '#8c8c8c', border: `1px solid ${r.status === 'active' ? '#b7eb8f' : '#d9d9d9'}` }}>{r.status === 'active' ? '启用' : '禁用'}</span></td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openRuleModal('view', r)}>查看</button>
                        <button className="text-xs" style={{ color: '#faad14' }} onClick={() => openRuleModal('edit', r)}>编辑</button>
                        <button className="text-xs" style={{ color: r.status === 'active' ? '#ff4d4f' : '#52c41a' }} onClick={() => toggleRuleStatus(r.id)}>
                          {r.status === 'active' ? '禁用' : '启用'}
                        </button>
                        <button className="text-xs" style={{ color: '#ff4d4f' }} onClick={() => setRuleDeleteConfirm(r.id)}>删除</button>
                      </div>
                    </td>
                  </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {/* Rule Modal */}
          {ruleModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setRuleModalOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[600px] max-h-[85vh] flex flex-col">
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h3 className="text-lg font-semibold">{ruleModalMode === 'add' ? '新增预警规则' : ruleModalMode === 'edit' ? '编辑预警规则' : '查看预警规则'}</h3>
                  <button onClick={() => setRuleModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                <div className="flex-1 overflow-auto p-6 space-y-4">
                  {/* Rule Name */}
                  <div><label className="block text-xs mb-1">规则名称 {ruleModalMode !== 'view' && <span className="text-red-400">*</span>}</label><input className="form-input w-full" value={ruleForm.name} onChange={e => setRuleForm({ ...ruleForm, name: e.target.value })} placeholder="请输入规则名称" readOnly={ruleModalMode === 'view'} /></div>
                  {/* Description */}
                  <div><label className="block text-xs mb-1">预警描述</label><textarea className="form-input w-full text-sm" rows={2} value={ruleForm.description} onChange={e => setRuleForm({ ...ruleForm, description: e.target.value })} placeholder="请输入预警描述..." readOnly={ruleModalMode === 'view'} /></div>
                  {/* Warning Type */}
                  <div><label className="block text-xs mb-1">预警类型 {ruleModalMode !== 'view' && <span className="text-red-400">*</span>}</label>
                    <select className="form-input w-full" value={ruleForm.warningType} onChange={e => {
                      const newType = e.target.value as WarningRule['warningType']
                      setRuleForm({ ...ruleForm, warningType: newType })
                    }} disabled={ruleModalMode === 'view'}>
                      <option value="overdue">超期预警</option>
                      <option value="maintenance">保养提醒</option>
                      <option value="warranty">质保提醒</option>
                      <option value="stock">安全库存提醒</option>
                      <option value="abnormal_io">异常出入库提醒</option>
                    </select>
                  </div>

                  {/* Trigger Condition — Dynamic by warningType */}
                  <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>触发条件</h4>

                    {/* Type 1~3: Time reminder (overdue/maintenance/warranty) */}
                    {(ruleForm.warningType === 'overdue' || ruleForm.warningType === 'maintenance' || ruleForm.warningType === 'warranty') && (
                      <div className="space-y-3">
                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>请勾选需要的提醒时间点：</p>
                        <label className="flex items-center gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <input type="checkbox" checked={ruleForm.timeConfig.beforeStart} onChange={e => setRuleForm({ ...ruleForm, timeConfig: { ...ruleForm.timeConfig, beforeStart: e.target.checked } })} disabled={ruleModalMode === 'view'} />
                          <div className="flex items-center gap-2">
                            <span className="text-sm">节点开始前</span>
                            <input className="form-input text-xs py-1 w-16" type="number" min={0} value={ruleForm.timeConfig.beforeStartDays} onChange={e => setRuleForm({ ...ruleForm, timeConfig: { ...ruleForm.timeConfig, beforeStartDays: parseInt(e.target.value) || 0 } })} readOnly={ruleModalMode === 'view' || !ruleForm.timeConfig.beforeStart} />
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>天提醒</span>
                          </div>
                        </label>
                        <label className="flex items-center gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <input type="checkbox" checked={ruleForm.timeConfig.beforeExpire} onChange={e => setRuleForm({ ...ruleForm, timeConfig: { ...ruleForm.timeConfig, beforeExpire: e.target.checked } })} disabled={ruleModalMode === 'view'} />
                          <div className="flex items-center gap-2">
                            <span className="text-sm">节点到期前</span>
                            <input className="form-input text-xs py-1 w-16" type="number" min={0} value={ruleForm.timeConfig.beforeExpireDays} onChange={e => setRuleForm({ ...ruleForm, timeConfig: { ...ruleForm.timeConfig, beforeExpireDays: parseInt(e.target.value) || 0 } })} readOnly={ruleModalMode === 'view' || !ruleForm.timeConfig.beforeExpire} />
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>天提醒</span>
                          </div>
                        </label>
                        <label className="flex items-center gap-3 p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <input type="checkbox" checked={ruleForm.timeConfig.afterOverdue} onChange={e => setRuleForm({ ...ruleForm, timeConfig: { ...ruleForm.timeConfig, afterOverdue: e.target.checked } })} disabled={ruleModalMode === 'view'} />
                          <span className="text-sm">节点超期后持续提醒</span>
                        </label>
                      </div>
                    )}

                    {/* Type 4: Stock reminder */}
                    {ruleForm.warningType === 'stock' && (
                      <div className="space-y-3">
                        {ruleForm.stockConfig.map((item, idx) => (
                          <div key={idx} className="p-3 rounded-lg border space-y-2" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-medium">规则 {idx + 1}</span>
                              {ruleModalMode !== 'view' && ruleForm.stockConfig.length > 1 && (
                                <button className="text-xs" style={{ color: '#ff4d4f' }} onClick={() => setRuleForm({ ...ruleForm, stockConfig: ruleForm.stockConfig.filter((_, i) => i !== idx) })}>删除</button>
                              )}
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                              <input className="form-input text-xs py-1.5" placeholder="装备名称" value={item.equipName} onChange={e => { const newC = [...ruleForm.stockConfig]; newC[idx] = { ...newC[idx], equipName: e.target.value }; setRuleForm({ ...ruleForm, stockConfig: newC }) }} readOnly={ruleModalMode === 'view'} />
                              <input className="form-input text-xs py-1.5 font-mono" placeholder="装备编码" value={item.equipCode} onChange={e => { const newC = [...ruleForm.stockConfig]; newC[idx] = { ...newC[idx], equipCode: e.target.value }; setRuleForm({ ...ruleForm, stockConfig: newC }) }} readOnly={ruleModalMode === 'view'} />
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs">当</span>
                              <select className="form-input text-xs py-1.5 w-24" value={item.thresholdType} onChange={e => { const newC = [...ruleForm.stockConfig]; newC[idx] = { ...newC[idx], thresholdType: e.target.value as 'quantity' | 'percentage' }; setRuleForm({ ...ruleForm, stockConfig: newC }) }} disabled={ruleModalMode === 'view'}>
                                <option value="quantity">数量</option>
                                <option value="percentage">百分比</option>
                              </select>
                              <span className="text-xs">小于</span>
                              <input className="form-input text-xs py-1.5 w-16 font-mono" type="number" min={0} value={item.thresholdValue} onChange={e => { const newC = [...ruleForm.stockConfig]; newC[idx] = { ...newC[idx], thresholdValue: parseInt(e.target.value) || 0 }; setRuleForm({ ...ruleForm, stockConfig: newC }) }} readOnly={ruleModalMode === 'view'} />
                              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.thresholdType === 'quantity' ? '件' : '%'} 时提醒</span>
                            </div>
                          </div>
                        ))}
                        {ruleModalMode !== 'view' && (
                          <button className="btn-default text-xs w-full py-1.5" onClick={() => setRuleForm({ ...ruleForm, stockConfig: [...ruleForm.stockConfig, { equipName: '', equipCode: '', thresholdType: 'quantity', thresholdValue: 0 }] })}>
                            + 添加规则
                          </button>
                        )}
                      </div>
                    )}

                    {/* Type 5: Abnormal I/O */}
                    {ruleForm.warningType === 'abnormal_io' && (
                      <div className="p-3 rounded-lg border" style={{ borderColor: '#e6f7ff', background: '#f0f8ff' }}>
                        <p className="text-xs flex items-center gap-1" style={{ color: 'var(--primary-blue)' }}>
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                          该预警类型将自动监测门禁系统检测到的未经系统出入库操作，无需额外配置触发条件。
                        </p>
                      </div>
                    )}
                  </div>

                  {/* Severity */}
                  <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                    <label className="block text-xs mb-2">严重程度</label>
                    <div className="flex gap-2">
                      {([['high', '高', '#ff4d4f'], ['medium', '中', '#faad14'], ['low', '低', '#52c41a']] as const).map(([k, l, color]) => (
                        <button key={k} className="px-4 py-2 rounded-lg text-xs border transition-all"
                          style={{ borderColor: ruleForm.level === k ? color : 'var(--border-color)', background: ruleForm.level === k ? `${color}10` : 'transparent', color: ruleForm.level === k ? color : '#8c8c8c' }}
                          onClick={() => ruleModalMode !== 'view' && setRuleForm({ ...ruleForm, level: k })}>
                          {l}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-end gap-3 px-6 py-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setRuleModalOpen(false)}>关闭</button>
                  {ruleModalMode !== 'view' && <button className="btn-primary" onClick={saveRule}>保存</button>}
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirm */}
          {ruleDeleteConfirm && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setRuleDeleteConfirm(null)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#fff2f0' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认删除</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>删除后不可恢复，是否确认删除该预警规则？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setRuleDeleteConfirm(null)}>取消</button>
                  <button className="btn-danger" onClick={() => deleteRule(ruleDeleteConfirm)}>确认删除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 预警查询 ==================== */}
      {activeTab === 'alert' && (
        <>
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3 mb-4">
              <div><label className="block text-xs mb-1">预警类型</label><select className="form-input w-32"><option>全部</option><option>库存过低</option><option>质保到期</option></select></div>
              <div><label className="block text-xs mb-1">处理状态</label><select className="form-input w-28"><option>全部</option><option>待处理</option><option>已确认</option></select></div>
              <div><label className="block text-xs mb-1">严重程度</label><select className="form-input w-28"><option>全部</option><option>高</option><option>中</option><option>低</option></select></div>
              <div className="flex gap-2 ml-auto"><button className="btn-default">重置</button><button className="btn-primary">查询</button></div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {[
              { label: '待处理', count: alerts.filter(a => a.status === 'pending').length, color: '#ff4d4f' },
              { label: '已确认', count: alerts.filter(a => a.status === 'confirmed').length, color: '#faad14' },
              { label: '已处理', count: alerts.filter(a => a.status === 'resolved').length, color: '#52c41a' },
              { label: '已忽略', count: alerts.filter(a => a.status === 'ignored').length, color: '#8c8c8c' },
            ].map(s => (
              <span key={s.label} className="px-3 py-1.5 rounded-full text-xs font-medium" style={{ color: s.color, border: `1px solid ${s.color}40`, background: `${s.color}10` }}>{s.label} {s.count}</span>
            ))}
          </div>
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>预警记录ID</th><th>预警类型</th><th>触发时间</th><th>预警内容</th><th>状态</th><th>处理人</th><th>操作</th></tr>
              </thead>
              <tbody>
                {alerts.map(a => (
                  <tr key={a.id}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{a.id}</td>
                    <td>{a.type}</td>
                    <td className="font-mono text-xs">{a.time}</td>
                    <td className="text-sm">{a.content}</td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: alertStatusConfig[a.status].bg, color: alertStatusConfig[a.status].color, border: `1px solid ${alertStatusConfig[a.status].color}30` }}>{alertStatusConfig[a.status].label}</span></td>
                    <td>{a.handler || '-'}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        {a.status === 'pending' && (
                          <>
                            <button className="text-xs" style={{ color: '#52c41a' }} onClick={() => openAlertDetail(a, 'handle')}>处理</button>
                            <button className="text-xs" style={{ color: '#8c8c8c' }} onClick={() => openIgnoreModal(a)}>忽略</button>
                          </>
                        )}
                        <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openAlertDetail(a, 'view')}>查看</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Alert Detail Modal */}
          {alertDetailOpen && selectedAlert && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setAlertDetailOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">预警详情</h3>
                  <button onClick={() => setAlertDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>预警记录ID</span><span className="font-mono text-xs">{selectedAlert.id}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>预警类型</span><span className="text-sm">{selectedAlert.type}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>触发时间</span><span className="text-xs">{selectedAlert.time}</span>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>状态</span>
                      <span className="tag text-xs px-2 py-0.5" style={{ background: alertStatusConfig[selectedAlert.status].bg, color: alertStatusConfig[selectedAlert.status].color }}>{alertStatusConfig[selectedAlert.status].label}</span>
                    </div>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>预警内容</span><p className="text-sm">{selectedAlert.content}</p>
                  </div>
                  {selectedAlert.handleResult && (
                    <div className="p-3 rounded-lg border" style={{ borderColor: selectedAlert.status === 'ignored' ? '#d9d9d9' : 'var(--border-color)', background: selectedAlert.status === 'ignored' ? '#fafafa' : 'var(--content-bg)' }}>
                      <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>{selectedAlert.status === 'ignored' ? '忽略原因' : '处理结果'}</span>
                      <p className="text-sm" style={{ color: selectedAlert.status === 'ignored' ? '#8c8c8c' : 'inherit' }}>{selectedAlert.handleResult}</p>
                      <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{selectedAlert.status === 'ignored' ? '忽略' : '处理'}人：{selectedAlert.handler} · {selectedAlert.handleTime}</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setAlertDetailOpen(false)}>关闭</button>
                </div>
              </div>
            </div>
          )}

          {/* Alert Ignore Modal */}
          {alertIgnoreOpen && selectedAlert && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setAlertIgnoreOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">忽略预警 — {selectedAlert.id}</h3>
                  <button onClick={() => setAlertIgnoreOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                <div className="space-y-3">
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>预警内容</span><p className="text-sm">{selectedAlert.content}</p>
                  </div>
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>触发时间</span><span className="text-xs">{selectedAlert.time}</span>
                  </div>
                  <div><label className="block text-xs mb-1">忽略原因 <span className="text-red-400">*</span></label><textarea className="form-input w-full text-sm" rows={4} value={ignoreReason} onChange={e => setIgnoreReason(e.target.value)} placeholder="请输入忽略原因..." /></div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setAlertIgnoreOpen(false)}>取消</button>
                  <button className="btn-primary" style={{ background: '#8c8c8c' }} onClick={submitIgnore}>确认忽略</button>
                </div>
              </div>
            </div>
          )}

          {/* Alert Handle Modal */}
          {alertHandleOpen && selectedAlert && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setAlertHandleOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">处理预警 — {selectedAlert.id}</h3>
                  <button onClick={() => setAlertHandleOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                <div className="space-y-3">
                  <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                    <span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>预警内容</span><p className="text-sm">{selectedAlert.content}</p>
                  </div>
                  <div><label className="block text-xs mb-1">处理结果 <span className="text-red-400">*</span></label><textarea className="form-input w-full text-sm" rows={4} value={handleResult} onChange={e => setHandleResult(e.target.value)} placeholder="请输入处理措施和结果..." /></div>
                </div>
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => setAlertHandleOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={submitHandle}>提交处理</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 装备管控 ==================== */}
      {activeTab === 'control' && (
        <>
          <div className="flex items-center justify-between">
            <button className="btn-primary flex items-center gap-1" onClick={() => openControlModal('add')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增管控</button>
            <div className="flex gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border">管控中 {controls.filter(c => c.status === 'active').length}</span>
              <span className="px-3 py-1 rounded-full border">已解除 {controls.filter(c => c.status === 'released').length}</span>
            </div>
          </div>
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>管控单号</th><th>被管控对象</th><th>管控原因</th><th>开始时间</th><th>结束时间</th><th>责任人</th><th>状态</th><th>操作</th></tr>
              </thead>
              <tbody>
                {controls.map(c => (
                  <tr key={c.id}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{c.id}</td>
                    <td>{c.target}</td>
                    <td className="text-sm">{c.reason}</td>
                    <td className="text-xs">{c.startTime}</td>
                    <td className="text-xs">{c.endTime}</td>
                    <td>{c.owner}</td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: c.status === 'active' ? '#fffbe6' : '#f6ffed', color: c.status === 'active' ? '#faad14' : '#52c41a', border: `1px solid ${c.status === 'active' ? '#ffe58f' : '#b7eb8f'}` }}>{c.status === 'active' ? '管控中' : '已解除'}</span></td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openControlModal('view', c)}>查看</button>
                        {c.status === 'active' && (
                          <button className="text-xs" style={{ color: '#52c41a' }} onClick={() => { setReleasingControlId(c.id); setReleaseConfirmOpen(true) }}>解除</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Control Add / View Modal */}
          {controlModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">{controlModalMode === 'add' ? '新增管控' : '查看管控'}</h3>
                  <button onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                {controlModalMode === 'view' && selectedControl ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>管控单号</span><span className="font-mono text-xs">{selectedControl.id}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>状态</span><span className="tag text-xs px-2 py-0.5" style={{ background: selectedControl.status === 'active' ? '#fffbe6' : '#f6ffed', color: selectedControl.status === 'active' ? '#faad14' : '#52c41a' }}>{selectedControl.status === 'active' ? '管控中' : '已解除'}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>被管控对象</span><span className="text-sm">{selectedControl.target}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>责任人</span><span className="text-sm">{selectedControl.owner}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>开始时间</span><span className="text-xs">{selectedControl.startTime}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>结束时间</span><span className="text-xs">{selectedControl.endTime}</span></div>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>管控原因</span><p className="text-sm">{selectedControl.reason}</p></div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* 被管控对象 - 模糊匹配 */}
                    <div className="relative">
                      <label className="block text-xs mb-1">被管控对象 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full" value={controlTargetSearch || controlForm.target} onChange={e => { setControlTargetSearch(e.target.value); setShowTargetDropdown(true); setControlForm({ ...controlForm, target: e.target.value }) }} onFocus={() => setShowTargetDropdown(true)} placeholder="输入企业名称/批次号/装备编号自动匹配" />
                      {showTargetDropdown && (
                        <div className="absolute top-full left-0 right-0 mt-1 p-2 rounded-lg border z-10 max-h-48 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'white' }}>
                          {systemTargets.filter(t => t.toLowerCase().includes(controlTargetSearch.toLowerCase()) || !controlTargetSearch).map(t => (
                            <div key={t} className="flex items-center gap-2 px-3 py-2 rounded cursor-pointer hover:bg-blue-50 text-xs" onClick={() => { setControlForm({ ...controlForm, target: t }); setControlTargetSearch(t); setShowTargetDropdown(false) }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                              <span>{t}</span>
                            </div>
                          ))}
                          {controlTargetSearch && !systemTargets.some(t => t.toLowerCase().includes(controlTargetSearch.toLowerCase())) && (
                            <div className="px-3 py-2 text-xs" style={{ color: 'var(--text-disabled)' }}>无匹配数据，将使用自定义值</div>
                          )}
                        </div>
                      )}
                    </div>
                    <div><label className="block text-xs mb-1">管控原因 <span className="text-red-400">*</span></label><input className="form-input w-full" value={controlForm.reason} onChange={e => setControlForm({ ...controlForm, reason: e.target.value })} placeholder="管控原因" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs mb-1">开始时间</label><input className="form-input w-full" type="date" value={controlForm.startTime} onChange={e => setControlForm({ ...controlForm, startTime: e.target.value })} /></div>
                      <div><label className="block text-xs mb-1">预计结束时间</label><input className="form-input w-full" type="date" value={controlForm.endTime} onChange={e => setControlForm({ ...controlForm, endTime: e.target.value })} /></div>
                    </div>
                    {/* 责任人 - 组织架构 */}
                    <div className="relative">
                      <label className="block text-xs mb-1">责任人</label>
                      <input className="form-input w-full" value={controlForm.owner} placeholder="点击选择责任人" readOnly onClick={() => setShowOwnerTree(!showOwnerTree)} />
                      {showOwnerTree && (
                        <div className="absolute top-full left-0 right-0 mt-1 p-3 rounded-lg border z-10 max-h-60 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'white' }}>
                          {controlOwnerTree.map(dept => (
                            <div key={dept.id} className="mb-2">
                              <div className="text-xs font-medium px-2 py-1" style={{ color: 'var(--text-secondary)' }}>{dept.name}</div>
                              {dept.members.map(m => (
                                <div key={m.id} className="flex items-center gap-2 px-3 py-1.5 rounded cursor-pointer hover:bg-blue-50 text-xs" onClick={() => { setControlForm({ ...controlForm, owner: `${m.name}（${dept.name}）` }); setShowOwnerTree(false) }}>
                                  <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs text-white" style={{ background: '#52c41a' }}>{m.name[0]}</div>
                                  <span>{m.name}</span>
                                </div>
                              ))}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }}>关闭</button>
                  {controlModalMode === 'add' && <button className="btn-primary" onClick={saveControl}>保存</button>}
                </div>
              </div>
            </div>
          )}

          {/* Release Confirm Modal */}
          {releaseConfirmOpen && releasingControlId && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setReleaseConfirmOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#f6ffed' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认解除管控</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>解除后该对象将恢复正常状态，是否确认？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setReleaseConfirmOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => releaseControl(releasingControlId)}>确认解除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ==================== 提醒订阅 ==================== */}
      {activeTab === 'subscribe' && (
        <>
          <div className="flex items-center justify-between">
            <button className="btn-primary flex items-center gap-1" onClick={() => openSubModal('add')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增订阅</button>
            <div className="flex gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#52c41a40', background: '#f6ffed', color: '#52c41a' }}>生效中 {subscriptions.filter(s => s.status === 'active').length}</span>
              <span className="px-3 py-1 rounded-full border" style={{ borderColor: '#8c8c8c40', background: '#f5f5f5', color: '#8c8c8c' }}>已暂停 {subscriptions.filter(s => s.status === 'paused').length}</span>
            </div>
          </div>
          <div className="content-card p-4">
            <div className="flex items-end gap-3 mb-4">
              <div><label className="block text-xs mb-1">订阅人</label><input className="form-input w-40" placeholder="请输入..." value={subSearch} onChange={e => setSubSearch(e.target.value)} /></div>
              <div className="flex gap-2 ml-auto"><button className="btn-default" onClick={() => setSubSearch('')}>重置</button><button className="btn-primary">查询</button></div>
            </div>
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>订阅ID</th><th>订阅人</th><th>订阅预警类型</th><th>通知方式</th><th>频率配置</th><th>升级机制</th><th>状态</th><th>创建时间</th><th>操作</th></tr>
              </thead>
              <tbody>
                {subscriptions
                  .filter(s => !subSearch || s.subscriber.includes(subSearch))
                  .map(s => {
                    const typeLabels: Record<string, string> = { overdue: '超期预警', maintenance: '保养提醒', warranty: '质保提醒', stock: '安全库存提醒', abnormal_io: '异常出入库提醒' }
                    const typeColors: Record<string, string> = { overdue: '#ff4d4f', maintenance: '#1890ff', warranty: '#faad14', stock: '#52c41a', abnormal_io: '#722ed1' }
                    return (
                      <tr key={s.id}>
                        <td><input type="checkbox"/></td>
                        <td className="font-mono text-xs">{s.id}</td>
                        <td className="font-medium">
                          {s.subscriber}
                          {s.isSelf && <span className="tag text-xs px-1.5 py-0 ml-1" style={{ background: '#e6f7ff', color: '#1890ff' }}>本人</span>}
                        </td>
                        <td>
                          <div className="flex flex-wrap gap-1">
                            {s.warningTypes.map(t => (
                              <span key={t} className="tag text-xs px-1.5 py-0.5" style={{ background: `${typeColors[t]}15`, color: typeColors[t], border: `1px solid ${typeColors[t]}30` }}>{typeLabels[t]}</span>
                            ))}
                          </div>
                        </td>
                        <td>
                          <div className="flex gap-1">
                            {s.notifyMethod.includes('site') && <span className="tag text-xs px-1.5 py-0.5" style={{ background: '#e6f7ff', color: '#1890ff' }}>站内信</span>}
                            {s.notifyMethod.includes('sms') && <span className="tag text-xs px-1.5 py-0.5" style={{ background: '#f6ffed', color: '#52c41a' }}>短信</span>}
                          </div>
                        </td>
                        <td className="text-xs">
                          <span style={{ color: 'var(--text-secondary)' }}>每天{s.dailyCount}次 / 间隔{s.intervalMinutes}分 / 最长{s.maxReminderDays}天</span>
                        </td>
                        <td className="text-xs">
                          {s.upgradeConfig?.enabled ? (
                            <span style={{ color: '#fa8c16' }}>{s.upgradeConfig.timeValue}{s.upgradeConfig.timeUnit === 'hour' ? '小时' : '天'}未处理{s.upgradeConfig.notifySuperior ? '·通知上级' : ''}</span>
                          ) : (
                            <span style={{ color: 'var(--text-disabled)' }}>-</span>
                          )}
                        </td>
                        <td><span className="tag text-xs px-2 py-0.5" style={{ background: s.status === 'active' ? '#f6ffed' : '#f5f5f5', color: s.status === 'active' ? '#52c41a' : '#8c8c8c', border: `1px solid ${s.status === 'active' ? '#b7eb8f' : '#d9d9d9'}` }}>{s.status === 'active' ? '生效中' : '已暂停'}</span></td>
                        <td className="text-xs">{s.createTime}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openSubModal('view', s)}>查看</button>
                            <button className="text-xs" style={{ color: '#faad14' }} onClick={() => openSubModal('edit', s)}>修改</button>
                            <button className="text-xs" style={{ color: s.status === 'active' ? '#ff4d4f' : '#52c41a' }} onClick={() => toggleSubStatus(s.id)}>
                              {s.status === 'active' ? '暂停' : '启用'}
                            </button>
                            <button className="text-xs" style={{ color: '#ff4d4f' }} onClick={() => setSubDeleteConfirm(s.id)}>删除</button>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
              </tbody>
            </table>
          </div>

          {/* Subscribe Modal */}
          {subModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setSubModalOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[600px] max-h-[85vh] flex flex-col">
                <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h3 className="text-lg font-semibold">{subMode === 'add' ? '新增订阅' : subMode === 'edit' ? '修改订阅' : '查看订阅'}</h3>
                  <button onClick={() => setSubModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                <div className="flex-1 overflow-auto p-6 space-y-4">
                  {/* Subscriber Selection */}
                  <div>
                    <label className="block text-xs mb-2">订阅人 {subMode !== 'view' && <span className="text-red-400">*</span>}</label>
                    <div className="flex gap-2 mb-2">
                      <button className="px-4 py-2 rounded-lg text-xs border transition-all"
                        style={{ borderColor: subForm.isSelf ? '#1890ff' : 'var(--border-color)', background: subForm.isSelf ? '#e6f7ff' : 'transparent', color: subForm.isSelf ? '#1890ff' : '#8c8c8c' }}
                        onClick={() => subMode !== 'view' && setSubForm({ ...subForm, isSelf: true, subscriber: '本人（管理员）' })}>
                        本人
                      </button>
                      <button className="px-4 py-2 rounded-lg text-xs border transition-all"
                        style={{ borderColor: !subForm.isSelf ? '#1890ff' : 'var(--border-color)', background: !subForm.isSelf ? '#e6f7ff' : 'transparent', color: !subForm.isSelf ? '#1890ff' : '#8c8c8c' }}
                        onClick={() => subMode !== 'view' && setSubForm({ ...subForm, isSelf: false, subscriber: '' })}>
                        为下级设置
                      </button>
                    </div>
                    {subForm.isSelf ? (
                      <input className="form-input w-full" value="本人（管理员）" readOnly />
                    ) : (
                      <div className="relative">
                        <input className="form-input w-full" value={subForm.subscriber} placeholder="请选择下级人员" readOnly onClick={() => subMode !== 'view' && setShowSubTree(!showSubTree)} />
                        {showSubTree && subMode !== 'view' && (
                          <div className="absolute top-full left-0 right-0 mt-1 p-3 rounded-lg border z-10 max-h-60 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'white' }}>
                            {orgTree.map(dept => (
                              <div key={dept.id} className="mb-2">
                                <div className="text-xs font-medium px-2 py-1" style={{ color: 'var(--text-secondary)' }}>{dept.name}</div>
                                {dept.members.map(m => (
                                  <div key={m.id} className="flex items-center gap-2 px-3 py-1.5 rounded cursor-pointer hover:bg-blue-50 text-xs" onClick={() => { setSubForm({ ...subForm, subscriber: `${m.name}（${dept.name}）`, subDept: dept.name }); setShowSubTree(false) }}>
                                    <div className="w-5 h-5 rounded-full flex items-center justify-center text-xs text-white" style={{ background: '#1890ff' }}>{m.name[0]}</div>
                                    <span>{m.name}</span>
                                  </div>
                                ))}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Warning Types */}
                  <div>
                    <label className="block text-xs mb-2">订阅预警类型 {subMode !== 'view' && <span className="text-red-400">*</span>}</label>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { key: 'overdue', label: '超期预警', color: '#ff4d4f' },
                        { key: 'maintenance', label: '保养提醒', color: '#1890ff' },
                        { key: 'warranty', label: '质保提醒', color: '#faad14' },
                        { key: 'stock', label: '安全库存提醒', color: '#52c41a' },
                        { key: 'abnormal_io', label: '异常出入库提醒', color: '#722ed1' },
                      ].map(t => (
                        <label key={t.key} className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer" style={{ borderColor: subForm.warningTypes.includes(t.key) ? t.color : 'var(--border-color)', background: subForm.warningTypes.includes(t.key) ? `${t.color}10` : 'transparent' }}>
                          <input type="checkbox" checked={subForm.warningTypes.includes(t.key)} onChange={() => toggleWarningType(t.key)} disabled={subMode === 'view'} />
                          <span className="text-xs">{t.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>

                  {/* Notification Method */}
                  <div>
                    <label className="block text-xs mb-2">通知方式 {subMode !== 'view' && <span className="text-red-400">*</span>}</label>
                    <div className="flex gap-3">
                      <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer" style={{ borderColor: subForm.notifyMethod.includes('site') ? '#1890ff' : 'var(--border-color)', background: subForm.notifyMethod.includes('site') ? '#e6f7ff' : 'transparent' }}>
                        <input type="checkbox" checked={subForm.notifyMethod.includes('site')} onChange={() => toggleNotifyMethod('site')} disabled={subMode === 'view'} />
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
                        <span className="text-xs">站内信</span>
                      </label>
                      <label className="flex items-center gap-2 p-2 rounded-lg border cursor-pointer" style={{ borderColor: subForm.notifyMethod.includes('sms') ? '#52c41a' : 'var(--border-color)', background: subForm.notifyMethod.includes('sms') ? '#f6ffed' : 'transparent' }}>
                        <input type="checkbox" checked={subForm.notifyMethod.includes('sms')} onChange={() => toggleNotifyMethod('sms')} disabled={subMode === 'view'} />
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 11.5a8.38 8.38 0 01-.9 3.8 8.5 8.5 0 01-7.6 4.7 8.38 8.38 0 01-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 01-.9-3.8 8.5 8.5 0 014.7-7.6 8.38 8.38 0 013.8-.9h.5a8.48 8.48 0 018 8v.5z"/></svg>
                        <span className="text-xs">短信</span>
                      </label>
                    </div>
                  </div>

                  {/* Frequency Config */}
                  <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>频率频次配置</h4>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs mb-1">每天提醒次数</label>
                        <input className="form-input font-mono text-sm w-full" type="number" min={1} max={24} value={subForm.dailyCount} onChange={e => setSubForm({ ...subForm, dailyCount: parseInt(e.target.value) || 1 })} readOnly={subMode === 'view'} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1">每次间隔（分钟）</label>
                        <input className="form-input font-mono text-sm w-full" type="number" min={0} step={5} value={subForm.intervalMinutes} onChange={e => setSubForm({ ...subForm, intervalMinutes: parseInt(e.target.value) || 0 })} readOnly={subMode === 'view'} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1">最长提醒时长（天）</label>
                        <input className="form-input font-mono text-sm w-full" type="number" min={1} value={subForm.maxReminderDays} onChange={e => setSubForm({ ...subForm, maxReminderDays: parseInt(e.target.value) || 1 })} readOnly={subMode === 'view'} />
                      </div>
                    </div>
                    <p className="text-xs mt-2" style={{ color: 'var(--text-secondary)' }}>
                      配置说明：每天最多提醒 <span style={{ color: '#1890ff' }}>{subForm.dailyCount}</span> 次，每次间隔 <span style={{ color: '#1890ff' }}>{subForm.intervalMinutes}</span> 分钟，最长连续提醒 <span style={{ color: '#1890ff' }}>{subForm.maxReminderDays}</span> 天
                    </p>
                  </div>
                </div>

                {/* 升级机制 */}
                <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm">
                    <span className="w-1 h-4 rounded-full" style={{ background: '#fa8c16' }} />升级机制
                  </h4>
                  <div className="space-y-3">
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input type="checkbox" checked={subForm.upgradeEnabled} onChange={e => setSubForm({ ...subForm, upgradeEnabled: e.target.checked })} disabled={subMode === 'view'} />
                      <span className="text-xs">启用升级机制</span>
                    </label>
                    <div className={`space-y-3 transition-opacity ${subForm.upgradeEnabled ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
                      <div>
                        <label className="block text-xs mb-1.5" style={{ color: 'var(--text-secondary)' }}>超时未处理时间</label>
                        <div className="flex gap-4">
                          {[
                            { label: '24小时', value: 24, unit: 'hour' },
                            { label: '48小时', value: 48, unit: 'hour' },
                            { label: '自定义', value: -1, unit: 'hour' },
                          ].map(opt => (
                            <label key={opt.label} className="flex items-center gap-1.5 text-xs cursor-pointer">
                              <input type="radio" checked={subForm.upgradeTimeValue === opt.value && opt.value !== -1 || (opt.value === -1 && subForm.upgradeTimeValue !== 24 && subForm.upgradeTimeValue !== 48)} onChange={() => setSubForm({ ...subForm, upgradeTimeValue: opt.value === -1 ? 12 : opt.value, upgradeTimeUnit: opt.unit as 'hour' | 'day' })} disabled={subMode === 'view'} />
                              <span>{opt.label}</span>
                            </label>
                          ))}
                        </div>
                        {subForm.upgradeTimeValue !== 24 && subForm.upgradeTimeValue !== 48 && (
                          <div className="flex gap-2 mt-2">
                            <input className="form-input w-20 text-xs font-mono" type="number" min={1} value={subForm.upgradeTimeValue} onChange={e => setSubForm({ ...subForm, upgradeTimeValue: parseInt(e.target.value) || 1 })} readOnly={subMode === 'view'} />
                            <select className="form-input w-20 text-xs" value={subForm.upgradeTimeUnit} onChange={e => setSubForm({ ...subForm, upgradeTimeUnit: e.target.value as 'hour' | 'day' })} disabled={subMode === 'view'}>
                              <option value="hour">小时</option>
                              <option value="day">天</option>
                            </select>
                          </div>
                        )}
                      </div>
                      <label className="flex items-center gap-2 text-sm cursor-pointer">
                        <input type="checkbox" checked={subForm.upgradeNotifySuperior} onChange={e => setSubForm({ ...subForm, upgradeNotifySuperior: e.target.checked })} disabled={subMode === 'view'} />
                        <span className="text-xs">通知上级</span>
                      </label>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 px-6 py-4 border-t" style={{ borderColor: 'var(--border-color)' }}>
                  <button className="btn-default" onClick={() => setSubModalOpen(false)}>关闭</button>
                  {subMode !== 'view' && <button className="btn-primary" onClick={saveSub}>保存</button>}
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirm */}
          {subDeleteConfirm && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setSubDeleteConfirm(null)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#fff2f0' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认删除</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>删除后不可恢复，是否确认删除该订阅？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setSubDeleteConfirm(null)}>取消</button>
                  <button className="btn-danger" onClick={() => deleteSub(subDeleteConfirm)}>确认删除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  )
}
