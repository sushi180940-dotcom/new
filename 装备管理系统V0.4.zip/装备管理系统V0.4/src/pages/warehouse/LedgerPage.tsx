import { useState } from 'react'
import {
  Database, CheckCircle2, AlertTriangle, Wrench, Trash2, ArrowLeftRight,
  ClipboardList, Hand, X, Printer, Warehouse, Package, Users, Eye,
  ChevronDown, ChevronUp,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface LedgerItem {
  id: number
  rfid: string
  category: string
  name: string
  model: string
  quantity: number
  unit: string
  storageLocation: string
  productionDate: string
  expiryDate: string
  maintenancePeriod: string
  price: number
  totalPrice: number
  supplier: string
  status: string
  lastOperationTime: string
}

interface LifeCycleEvent {
  id: string
  type: '入库' | '出库' | '领用' | '报修' | '盘点' | '调拨' | '报废'
  date: string
  operator: string
  dept: string
  title: string
  desc: string
}

/* ═══════════════════════════════════════════
   Mock 数据：台账
   ═══════════════════════════════════════════ */

const ledgerData: LedgerItem[] = [
  { id: 1, rfid: '0101P00100', category: '通信设备', name: '手持终端 XT-2000', model: 'XT-2000/黑色/128G', quantity: 50, unit: '台', storageLocation: '省厅仓库1层 A区-01-03', productionDate: '2024-01-15', expiryDate: '2027-01-15', maintenancePeriod: '3个月', price: 3200, totalPrice: 160000, supplier: '华为技术有限公司', status: '在库', lastOperationTime: '2024-03-15 09:30:00' },
  { id: 2, rfid: '0101P00200', category: '执法设备', name: '执法记录仪 DSJ-A7', model: 'DSJ-A7/64G/防水', quantity: 30, unit: '台', storageLocation: '省厅仓库1层 A区-02-01', productionDate: '2024-02-20', expiryDate: '2027-02-20', maintenancePeriod: '6个月', price: 1800, totalPrice: 54000, supplier: '海康威视数字技术股份有限公司', status: '领用', lastOperationTime: '2024-03-14 16:45:00' },
  { id: 3, rfid: '0101P00500', category: '通信设备', name: '对讲机 PD780G', model: 'PD780G/U段/数字', quantity: 100, unit: '台', storageLocation: '省厅仓库1层 B区-01-05', productionDate: '2024-01-20', expiryDate: '2027-01-20', maintenancePeriod: '3个月', price: 1200, totalPrice: 120000, supplier: '烽火通信科技股份有限公司', status: '在库', lastOperationTime: '2024-03-14 10:20:00' },
  { id: 4, rfid: '0101P00300', category: '防护装备', name: '防弹背心 FDY-3R', model: 'FDY-3R/三级/均码', quantity: 20, unit: '件', storageLocation: '省厅仓库2层 C区-01-02', productionDate: '2023-11-10', expiryDate: '2028-11-10', maintenancePeriod: '12个月', price: 2800, totalPrice: 56000, supplier: '华为技术有限公司', status: '维修', lastOperationTime: '2024-03-13 08:00:00' },
  { id: 5, rfid: '0101P00400', category: '防护装备', name: '战术头盔 MICH-2000', model: 'MICH-2000/L号/凯夫拉', quantity: 40, unit: '顶', storageLocation: '省厅仓库2层 C区-02-01', productionDate: '2023-12-05', expiryDate: '2028-12-05', maintenancePeriod: '12个月', price: 1500, totalPrice: 60000, supplier: '中兴通讯股份有限公司', status: '在库', lastOperationTime: '2024-03-12 14:10:00' },
  { id: 6, rfid: '0101P00600', category: '照明设备', name: '应急照明灯 YD-100', model: 'YD-100/LED/充电', quantity: 60, unit: '台', storageLocation: '省厅仓库2层 A区-03-04', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenancePeriod: '6个月', price: 680, totalPrice: 40800, supplier: '海康威视数字技术股份有限公司', status: '在库', lastOperationTime: '2024-03-09 15:00:00' },
  { id: 7, rfid: '0101P00700', category: '防护装备', name: '防弹盾牌 FDP-3S', model: 'FDP-3S/三级/透明', quantity: 15, unit: '面', storageLocation: '省厅仓库3层 D区-01-01', productionDate: '2024-03-01', expiryDate: '2029-03-01', maintenancePeriod: '12个月', price: 2200, totalPrice: 33000, supplier: '华为技术有限公司', status: '领用', lastOperationTime: '2024-03-08 09:45:00' },
  { id: 8, rfid: '0101P00800', category: '警械设备', name: '催泪喷射器 CL-200', model: 'CL-200/200ml/手持', quantity: 100, unit: '支', storageLocation: '省厅仓库3层 A区-04-01', productionDate: '2024-01-10', expiryDate: '2026-01-10', maintenancePeriod: '3个月', price: 150, totalPrice: 15000, supplier: '大华技术股份有限公司', status: '在库', lastOperationTime: '2024-03-07 16:20:00' },
  { id: 9, rfid: '0101P00900', category: '通信设备', name: '手持终端 XT-2000', model: 'XT-2000/黑色/128G', quantity: 30, unit: '台', storageLocation: '省厅仓库6层 B区-02-04', productionDate: '2024-02-01', expiryDate: '2027-02-01', maintenancePeriod: '3个月', price: 3200, totalPrice: 96000, supplier: '华为技术有限公司', status: '在库', lastOperationTime: '2024-03-06 11:00:00' },
  { id: 10, rfid: '0101P01000', category: '照明设备', name: '强光手电 QG-500', model: 'QG-500/充电款', quantity: 200, unit: '支', storageLocation: '省厅仓库6层 B区-03-01', productionDate: '2024-02-15', expiryDate: '2027-02-15', maintenancePeriod: '3个月', price: 280, totalPrice: 56000, supplier: '烽火通信科技股份有限公司', status: '在库', lastOperationTime: '2024-03-05 14:30:00' },
]

const warehouseFloors = ['全部', '省厅仓库1层', '省厅仓库2层', '省厅仓库3层', '省厅仓库6层']

const filterFields = [
  { key: 'keyword', label: '关键词搜索', type: 'input' as const, placeholder: '装备编码/名称/型号/RFID' },
  { key: 'category', label: '物资类别', type: 'select' as const, options: [{ label: '通信设备', value: '通信设备' }, { label: '执法设备', value: '执法设备' }, { label: '防护装备', value: '防护装备' }, { label: '照明设备', value: '照明设备' }, { label: '警械设备', value: '警械设备' }] },
  { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '在库', value: '在库' }, { label: '领用', value: '领用' }, { label: '维修', value: '维修' }, { label: '报废', value: '报废' }, { label: '调拨中', value: '调拨中' }] },
]

/* ═══════════════════════════════════════════
   Mock 数据：全生命周期记录
   ═══════════════════════════════════════════ */

const lifeCycleData: LifeCycleEvent[] = [
  { id: '1', type: '入库', date: '2024-03-15 09:30:00', operator: '张建国', dept: '省厅装备处', title: '采购入库', desc: '入库数量: 50 台, 存放位置: 省厅主仓库 A区-01-03, 供应商: 华为技术有限公司' },
  { id: '2', type: '出库', date: '2024-03-16 10:15:00', operator: '李卫国', dept: '市局装备科', title: '调拨出库', desc: '出库数量: 5 台, 调拨方向: 市局限装备仓库, 审批单号: CK20240316001' },
  { id: '3', type: '领用', date: '2024-03-18 14:20:00', operator: '王志强', dept: '刑警支队', title: '任务领用', desc: '领用数量: 3 台, 领用事由: 专项行动保障, 预计归还: 2024-04-18' },
  { id: '4', type: '报修', date: '2024-03-20 09:00:00', operator: '赵明华', dept: '设备维护组', title: '故障报修', desc: '故障描述: 无法正常开机, 报修人: 王志强, 维修方式: 返厂维修' },
  { id: '5', type: '盘点', date: '2024-03-25 16:45:00', operator: '陈晓东', dept: '仓库管理组', title: '月度盘点', desc: '盘点结果: 账实相符, 盘点方式: 人工+RFID扫描, 备注: 设备状态良好' },
  { id: '6', type: '调拨', date: '2024-03-28 11:30:00', operator: '刘建华', dept: '装备调配中心', title: '跨区调拨', desc: '调拨数量: 2 台, 调出仓库: 省厅主仓库 A区-01-03, 调入仓库: 市局限装备仓库 B区-02-04' },
  { id: '7', type: '报废', date: '2025-12-01 09:00:00', operator: '陈晓东', dept: '仓库管理组', title: '到期报废', desc: '报废原因: 超过有效期, 报废数量: 1 台, 处置方式: 环保回收' },
]

/* ═══════════════════════════════════════════
   状态标签
   ═══════════════════════════════════════════ */

function EquipmentStatus({ status }: { status: string }) {
  switch (status) {
    case '在库': return <span className="rounded-full bg-[#D1FAE5] px-2.5 py-1 text-xs text-[#059669]">在库</span>
    case '领用': return <span className="rounded-full bg-[#DBEAFE] px-2.5 py-1 text-xs text-[#1A56DB]">领用</span>
    case '维修': return <span className="rounded-full bg-[#FEF3C7] px-2.5 py-1 text-xs text-[#D97706]">维修</span>
    case '报废': return <span className="rounded-full bg-[#E5E7EB] px-2.5 py-1 text-xs text-[#6B7280]">报废</span>
    case '调拨中': return <span className="rounded-full bg-[#EDE9FE] px-2.5 py-1 text-xs text-[#7C3AED]">调拨中</span>
    default: return <span className="rounded-full bg-[#E5E7EB] px-2.5 py-1 text-xs text-[#6B7280]">{status}</span>
  }
}

/* ═══════════════════════════════════════════
   生命周期事件标签
   ═══════════════════════════════════════════ */

function LifeCycleTypeBadge({ type }: { type: string }) {
  const colors: Record<string, string> = {
    '入库': 'bg-[#D1FAE5] text-[#059669]',
    '出库': 'bg-[#DBEAFE] text-[#1A56DB]',
    '领用': 'bg-[#E8F0FE] text-[#2563EB]',
    '报修': 'bg-[#FEF3C7] text-[#D97706]',
    '盘点': 'bg-[#F3E8FF] text-[#9333EA]',
    '调拨': 'bg-[#DBEAFE] text-[#1D4ED8]',
    '报废': 'bg-[#FEE2E2] text-[#DC2626]',
  }
  return <span className={`rounded px-2 py-0.5 text-xs font-medium ${colors[type] || 'bg-[#E5E7EB] text-[#6B7280]'}`}>{type}</span>
}

/* ═══════════════════════════════════════════
   装备详情弹窗
   ═══════════════════════════════════════════ */

function EquipmentDetailModal({ item, open, onClose }: { item: LedgerItem | null; open: boolean; onClose: () => void }) {
  const [showRfid, setShowRfid] = useState(false)
  if (!open || !item) return null

  const rfidList = Array.from({ length: Math.min(item.quantity, 50) }, (_, i) => ({
    seq: i + 1,
    code: `${item.rfid.slice(0, 8)}...${String(i + 1).padStart(4, '0')}`,
  }))

  const timelineColors: Record<string, string> = {
    '入库': '#059669', '出库': '#1A56DB', '领用': '#2563EB', '报修': '#D97706',
    '盘点': '#9333EA', '调拨': '#1D4ED8', '报废': '#DC2626',
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">装备详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto px-6 py-4">
          {/* 基本信息 */}
          <div className="mb-5">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <div className="h-4 w-1 rounded-full bg-[#1A56DB]" />
              基本信息
            </div>
            <div className="grid grid-cols-3 gap-x-6 gap-y-3 text-sm">
              <div>
                <div className="text-xs text-[#6B7280]">装备编码</div>
                <div className="mt-0.5 font-mono text-[#1F2937]">{item.rfid}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">装备名称</div>
                <div className="mt-0.5 font-medium text-[#1F2937]">{item.name}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">物资类别</div>
                <div className="mt-0.5 text-[#1F2937]">{item.category}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">规格型号</div>
                <div className="mt-0.5 text-[#1F2937]">{item.model}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">数量</div>
                <div className="mt-0.5 font-medium text-[#1A56DB]">{item.quantity} {item.unit}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">剩余数量</div>
                <div className="mt-0.5 font-medium text-[#059669]">{Math.max(0, item.quantity - 5)}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">单位</div>
                <div className="mt-0.5 text-[#1F2937]">{item.unit}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">存储位置</div>
                <div className="mt-0.5 text-[#1F2937]">{item.storageLocation}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">生产日期</div>
                <div className="mt-0.5 text-[#1F2937]">{item.productionDate}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">有效期</div>
                <div className="mt-0.5 text-[#1F2937]">{item.expiryDate}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">保养期</div>
                <div className="mt-0.5 text-[#1F2937]">{item.maintenancePeriod}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">单价</div>
                <div className="mt-0.5 text-[#1F2937]">&yen;{item.price.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">总价</div>
                <div className="mt-0.5 font-medium text-[#1A56DB]">&yen;{item.totalPrice.toLocaleString()}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">供应商</div>
                <div className="mt-0.5 text-[#1F2937]">{item.supplier}</div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">状态</div>
                <div className="mt-0.5"><EquipmentStatus status={item.status} /></div>
              </div>
              <div>
                <div className="text-xs text-[#6B7280]">最后操作时间</div>
                <div className="mt-0.5 text-[#1F2937]">{item.lastOperationTime}</div>
              </div>
            </div>
          </div>

          {/* RFID编码列表 */}
          <div className="mb-5 rounded-lg border border-[#E5E7EB]">
            <button
              onClick={() => setShowRfid(!showRfid)}
              className="flex w-full items-center justify-between px-4 py-3 text-left"
            >
              <div className="flex items-center gap-2">
                <Database size={16} className="text-[#1A56DB]" />
                <span className="text-sm font-medium text-[#374151]">RFID编码列表</span>
                <span className="rounded bg-[#E8F0FE] px-2 py-0.5 text-xs text-[#1A56DB]">{item.quantity} 件</span>
              </div>
              {showRfid ? <ChevronUp size={16} className="text-[#6B7280]" /> : <ChevronDown size={16} className="text-[#6B7280]" />}
            </button>
            {showRfid && (
              <div className="border-t border-[#E5E7EB] px-4 py-2">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#F3F4F6]">
                      <th className="w-10 py-2 text-left text-[11px] font-semibold text-[#6B7280]">选择</th>
                      <th className="w-12 py-2 text-left text-[11px] font-semibold text-[#6B7280]">序号</th>
                      <th className="py-2 text-left text-[11px] font-semibold text-[#6B7280]">RFID编码</th>
                    </tr>
                  </thead>
                  <tbody className="max-h-[200px] overflow-auto">
                    {rfidList.map((r) => (
                      <tr key={r.seq} className="border-b border-[#F3F4F6]">
                        <td className="py-1.5"><input type="radio" name="rfid-select" className="h-3.5 w-3.5" defaultChecked={r.seq === 1} /></td>
                        <td className="py-1.5 text-[#374151]">{r.seq}</td>
                        <td className="py-1.5 font-mono text-[12px] text-[#374151]">{r.code}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* 全生命周期记录 */}
          <div>
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <div className="h-4 w-1 rounded-full bg-[#1A56DB]" />
              全生命周期记录
            </div>
            <div className="relative pl-6">
              {/* 时间轴竖线 */}
              <div className="absolute left-[7px] top-2 bottom-2 w-[2px] bg-[#E5E7EB]" />
              {lifeCycleData.map((event) => (
                <div key={event.id} className="relative mb-4">
                  {/* 时间节点圆点 */}
                  <div
                    className="absolute -left-6 top-1 h-3.5 w-3.5 rounded-full border-2 border-white"
                    style={{ backgroundColor: timelineColors[event.type] || '#6B7280' }}
                  />
                  <div className="flex items-center gap-2 text-sm">
                    <LifeCycleTypeBadge type={event.type} />
                    <span className="text-[#374151]">{event.date}</span>
                    <span className="text-[#6B7280]">·</span>
                    <span className="text-[#374151]">{event.operator}</span>
                    <span className="text-[#6B7280]">·</span>
                    <span className="text-[#6B7280]">{event.dept}</span>
                  </div>
                  <div className="mt-1 text-sm font-medium text-[#1F2937]">{event.title}</div>
                  <div className="mt-0.5 text-xs text-[#6B7280]">{event.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 justify-end border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   安全库存弹窗
   ═══════════════════════════════════════════ */

function SafetyStockModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null
  const safetyData = [
    { id: '1', equipName: '防弹背心', category: '防护装备', currentStock: 180, threshold: 200, diff: -20, status: '低于安全线' as const },
    { id: '2', equipName: '防刺服', category: '防护装备', currentStock: 480, threshold: 300, diff: 180, status: '正常' as const },
    { id: '3', equipName: '执法记录仪', category: '通信装备', currentStock: 145, threshold: 150, diff: -5, status: '低于安全线' as const },
    { id: '4', equipName: '对讲机', category: '通信装备', currentStock: 95, threshold: 100, diff: -5, status: '低于安全线' as const },
    { id: '5', equipName: '警用头盔', category: '防护装备', currentStock: 280, threshold: 250, diff: 30, status: '正常' as const },
    { id: '6', equipName: '催泪喷射器', category: '警械装备', currentStock: 320, threshold: 200, diff: 120, status: '正常' as const },
    { id: '7', equipName: '手铐', category: '警械装备', currentStock: 500, threshold: 400, diff: 100, status: '正常' as const },
    { id: '8', equipName: '强光手电', category: '照明装备', currentStock: 88, threshold: 120, diff: -32, status: '低于安全线' as const },
    { id: '9', equipName: '防割手套', category: '防护装备', currentStock: 260, threshold: 200, diff: 60, status: '正常' as const },
    { id: '10', equipName: '警棍', category: '警械装备', currentStock: 420, threshold: 350, diff: 70, status: '正常' as const },
    { id: '11', equipName: '反光背心', category: '交通装备', currentStock: 150, threshold: 180, diff: -30, status: '低于安全线' as const },
    { id: '12', equipName: '急救包', category: '医疗装备', currentStock: 95, threshold: 100, diff: -5, status: '低于安全线' as const },
  ]
  const lowCount = safetyData.filter(d => d.status === '低于安全线').length
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[800px] max-w-[95vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div><h2 className="text-lg font-semibold text-[#1F2937]">安全库存监控</h2><p className="mt-1 text-xs text-[#6B7280]">共 {safetyData.length} 个品种 · {lowCount} 个低于安全线</p></div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="mx-6 mt-4 flex items-center gap-2 rounded-lg border border-[#FEE2E2] bg-[#FEF2F2] px-4 py-2.5 text-sm text-[#DC2626]">
          <AlertTriangle size={16} /><span>有 <strong>{lowCount}</strong> 个品种库存低于安全线，请及时补货</span>
        </div>
        <div className="mx-6 my-4 max-h-[480px] overflow-auto rounded-lg border border-[#E5E7EB]">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资类别</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">当前总库存</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">安全库存阈值</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">差额</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
              </tr>
            </thead>
            <tbody>
              {safetyData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 font-medium text-[#1F2937]">{row.equipName}</td>
                  <td className="px-4 py-3 text-[#374151]">{row.category}</td>
                  <td className="px-4 py-3 text-right font-medium text-[#1A56DB]">{row.currentStock}</td>
                  <td className="px-4 py-3 text-right text-[#374151]">{row.threshold}</td>
                  <td className={cn('px-4 py-3 text-right font-medium', row.diff < 0 ? 'text-[#DC2626]' : 'text-[#059669]')}>{row.diff > 0 ? '+' : ''}{row.diff}</td>
                  <td className="px-4 py-3">{row.status === '正常' ? <span className="rounded-full bg-[#D1FAE5] px-2.5 py-1 text-xs text-[#059669]">正常</span> : <span className="rounded-full bg-[#FEE2E2] px-2.5 py-1 text-xs text-[#DC2626]">低于安全线</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-end border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   统计卡片
   ═══════════════════════════════════════════ */

function StatCardMini({ icon, value, label, color, bgColor, onClick }: { icon: React.ReactNode; value: number; label: string; color: string; bgColor: string; onClick?: () => void }) {
  return (
    <button onClick={onClick} className={cn('flex flex-col items-center gap-2 rounded-xl border p-5 transition', onClick ? 'cursor-pointer hover:shadow-md' : 'cursor-default')} style={{ borderColor: bgColor, backgroundColor: bgColor + '20' }}>
      <div className="flex h-10 w-10 items-center justify-center rounded-full" style={{ backgroundColor: bgColor }}>{icon}</div>
      <div className="text-2xl font-bold" style={{ color }}>{value}</div>
      <div className="text-sm text-[#6B7280]">{label}</div>
    </button>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function LedgerPage() {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [selectedRows, setSelectedRows] = useState<number[]>([])
  const [showSafetyModal, setShowSafetyModal] = useState(false)
  const [activeFloor, setActiveFloor] = useState('全部')
  const [detailItem, setDetailItem] = useState<LedgerItem | null>(null)
  const [showDetail, setShowDetail] = useState(false)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => { setFilterValues({}); setActiveFloor('全部') }
  const toggleRow = (id: number) => { setSelectedRows(p => p.includes(id) ? p.filter(v => v !== id) : [...p, id]) }

  const floorFilteredData = activeFloor === '全部' ? ledgerData : ledgerData.filter(d => d.storageLocation.startsWith(activeFloor))

  const totalCount = floorFilteredData.reduce((sum, d) => sum + d.quantity, 0)
  const inStockCount = floorFilteredData.filter(d => d.status === '在库').reduce((sum, d) => sum + d.quantity, 0)
  const inUseCount = floorFilteredData.filter(d => d.status === '领用').reduce((sum, d) => sum + d.quantity, 0)

  const safetyDataList = [
    { id: '1', status: '正常' as const }, { id: '2', status: '正常' as const }, { id: '3', status: '低于安全线' as const },
    { id: '4', status: '低于安全线' as const }, { id: '5', status: '正常' as const }, { id: '6', status: '正常' as const },
    { id: '7', status: '正常' as const }, { id: '8', status: '低于安全线' as const }, { id: '9', status: '正常' as const },
    { id: '10', status: '正常' as const }, { id: '11', status: '低于安全线' as const }, { id: '12', status: '低于安全线' as const },
  ]
  const normalCount = safetyDataList.filter(d => d.status === '正常').length
  const lowCount = safetyDataList.filter(d => d.status === '低于安全线').length

  const stats = [
    { icon: <Database size={18} />, value: totalCount, label: '装备总数', color: '#1A56DB', bgColor: '#E8F0FE' },
    { icon: <Package size={18} />, value: inStockCount, label: '在库数量', color: '#059669', bgColor: '#D1FAE5' },
    { icon: <Users size={18} />, value: inUseCount, label: '在用数量', color: '#2563EB', bgColor: '#DBEAFE' },
    { icon: <CheckCircle2 size={18} />, value: normalCount, label: '库存正常', color: '#059669', bgColor: '#D1FAE5' },
    { icon: <AlertTriangle size={18} />, value: lowCount, label: '低于安全线', color: '#DC2626', bgColor: '#FEE2E2', onClick: () => setShowSafetyModal(true) },
  ]

  const openDetail = (item: LedgerItem) => { setDetailItem(item); setShowDetail(true) }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">仓库台账</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Printer size={14} /> 打印标签</button>
      </div>

      <div className="mb-4 grid grid-cols-5 gap-4">
        {stats.map((s, i) => <StatCardMini key={i} {...s} />)}
      </div>

      <div className="mb-4 flex items-center gap-2">
        <Warehouse size={16} className="text-[#6B7280]" />
        <div className="flex gap-1">
          {warehouseFloors.map((f) => (
            <button key={f} onClick={() => setActiveFloor(f)} className={cn('rounded-md px-3 py-1.5 text-sm transition', activeFloor === f ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]')}>{f}</button>
          ))}
        </div>
      </div>

      <div className="mb-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Wrench size={14} /> 装备报修</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Trash2 size={14} /> 装备报废</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><ArrowLeftRight size={14} /> 装备调拨</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><ClipboardList size={14} /> 库存盘点</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Hand size={14} /> 装备配发</button>
      </div>

      <FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} />

      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="w-10 px-2 py-3"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">RFID编码</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">物资类别</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                <th className="px-3 py-3 text-right text-xs font-semibold text-[#6B7280]">数量</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">单位</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">生产日期</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">有效期</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">保养期</th>
                <th className="px-3 py-3 text-right text-xs font-semibold text-[#6B7280]">单价</th>
                <th className="px-3 py-3 text-right text-xs font-semibold text-[#6B7280]">总价</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">最后操作时间</th>
                <th className="w-24 px-3 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {floorFilteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB] cursor-pointer" onClick={() => openDetail(row)}>
                  <td className="px-2 py-3 text-center" onClick={e => e.stopPropagation()}><input type="checkbox" checked={selectedRows.includes(row.id)} onChange={() => toggleRow(row.id)} className="h-4 w-4 rounded border-[#D1D5DB]" /></td>
                  <td className="px-3 py-3 font-mono text-[12px] text-[#374151]">{row.rfid}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.category}</td>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.name}</td>
                  <td className="px-3 py-3 text-[12px] text-[#6B7280]">{row.model}</td>
                  <td className="px-3 py-3 text-right font-medium text-[#1A56DB]">{row.quantity}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.unit}</td>
                  <td className="px-3 py-3 text-[12px] text-[#374151]">{row.storageLocation}</td>
                  <td className="px-3 py-3 text-[12px] text-[#374151]">{row.productionDate}</td>
                  <td className="px-3 py-3 text-[12px] text-[#374151]">{row.expiryDate}</td>
                  <td className="px-3 py-3 text-[12px] text-[#374151]">{row.maintenancePeriod}</td>
                  <td className="px-3 py-3 text-right text-[12px] text-[#374151]">{row.price.toLocaleString()}</td>
                  <td className="px-3 py-3 text-right text-[12px] font-medium text-[#1A56DB]">{row.totalPrice.toLocaleString()}</td>
                  <td className="px-3 py-3 text-[12px] text-[#374151]">{row.supplier}</td>
                  <td className="px-3 py-3"><EquipmentStatus status={row.status} /></td>
                  <td className="px-3 py-3 text-[12px] text-[#6B7280]">{row.lastOperationTime}</td>
                  <td className="px-3 py-3 text-center" onClick={e => e.stopPropagation()}>
                    <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="查看详情">
                      <Eye size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {floorFilteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      <SafetyStockModal open={showSafetyModal} onClose={() => setShowSafetyModal(false)} />
      <EquipmentDetailModal item={detailItem} open={showDetail} onClose={() => setShowDetail(false)} />
    </div>
  )
}
