import { useState, useEffect } from 'react'
import {
  Plus, X, Eye, Edit3, Trash2, ChevronLeft,
  ChevronRight as ChevronRightIcon, Package, Clock,
  User, Building2, RotateCcw,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

type PickupType = '领用' | '借用'
type PickupStatus = '草稿' | '已提交' | '审批中' | '待出库' | '已出库' | '已归还'
type ApplicantType = '申请人' | '申请单位'

interface PickupItem {
  equipName: string
  spec: string
  quantity: number
  unit: string
  code: string
}

/* ═══════════════════════════════════════════
   库存装备类型（用于选择弹窗）
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
}

interface SelectedStockEquip {
  equip: StockEquipment
  qty: number
}

interface PickupRecord {
  id: string
  orderNo: string
  applicantType: ApplicantType
  applicantName?: string
  applicantUnit?: string
  warehouse: string
  type: PickupType
  items: PickupItem[]
  returnDate?: string
  status: PickupStatus
  createTime: string
  submitTime?: string
  remark?: string
}

/* ═══════════════════════════════════════════
   Mock 数据
   ═══════════════════════════════════════════ */

const mockData: PickupRecord[] = [
  {
    id: '1', orderNo: 'LY-2024-001', applicantType: '申请人', applicantName: '张警官', applicantUnit: undefined,
    warehouse: '省厅主装备仓库', type: '借用', items: [
      { equipName: '防弹背心', spec: 'BV-III-A', quantity: 1, unit: '件', code: 'ZB-001-001' },
      { equipName: '防弹头盔', spec: 'MICH2000', quantity: 1, unit: '顶', code: 'ZB-005-001' },
    ],
    returnDate: '2024-08-15', status: '草稿', createTime: '2024-07-01 09:30', remark: '执行任务需要',
  },
  {
    id: '2', orderNo: 'LY-2024-002', applicantType: '申请单位', applicantName: undefined, applicantUnit: 'YYY市公安局',
    warehouse: 'YYY市局装备仓库', type: '领用', items: [
      { equipName: '执法记录仪', spec: 'DSJ-A7', quantity: 10, unit: '台', code: 'ZB-003-001' },
      { equipName: '对讲机', spec: 'DJ-8800', quantity: 5, unit: '台', code: 'ZB-004-001' },
    ],
    status: '已提交', createTime: '2024-07-02 10:15', submitTime: '2024-07-02 14:30', remark: '新警配发',
  },
  {
    id: '3', orderNo: 'LY-2024-003', applicantType: '申请人', applicantName: '王警官', applicantUnit: undefined,
    warehouse: '省厅主装备仓库', type: '借用', items: [
      { equipName: '防刺服', spec: 'FCF-II', quantity: 2, unit: '件', code: 'ZB-001-002' },
    ],
    returnDate: '2024-08-30', status: '审批中', createTime: '2024-07-03 11:00', submitTime: '2024-07-03 16:20', remark: '专项巡逻',
  },
  {
    id: '4', orderNo: 'LY-2024-004', applicantType: '申请单位', applicantName: undefined, applicantUnit: 'YYY市公安局',
    warehouse: 'YYY市局装备仓库', type: '领用', items: [
      { equipName: '手铐', spec: 'SK-STD', quantity: 50, unit: '副', code: 'ZB-002-001' },
      { equipName: '警棍', spec: 'JG-TELE', quantity: 30, unit: '根', code: 'ZB-002-002' },
    ],
    status: '待出库', createTime: '2024-07-05 08:45', submitTime: '2024-07-05 09:10',
  },
  {
    id: '5', orderNo: 'LY-2024-005', applicantType: '申请人', applicantName: '李警官', applicantUnit: undefined,
    warehouse: '省厅主装备仓库', type: '借用', items: [
      { equipName: '执法记录仪', spec: 'DSJ-A7', quantity: 1, unit: '台', code: 'ZB-003-001' },
    ],
    returnDate: '2024-07-20', status: '已出库', createTime: '2024-07-08 14:20', submitTime: '2024-07-08 15:00',
  },
  {
    id: '6', orderNo: 'LY-2024-006', applicantType: '申请单位', applicantName: undefined, applicantUnit: 'YYY市公安局',
    warehouse: 'YYY市局装备仓库', type: '领用', items: [
      { equipName: '防割手套', spec: 'FG-ST5', quantity: 20, unit: '双', code: 'ZB-001-005' },
    ],
    status: '已归还', createTime: '2024-06-15 10:00', submitTime: '2024-06-15 11:30',
  },
  {
    id: '7', orderNo: 'LY-2024-007', applicantType: '申请人', applicantName: '赵警官', applicantUnit: undefined,
    warehouse: 'YYY市局装备仓库', type: '领用', items: [
      { equipName: '强光手电', spec: 'QG-LED', quantity: 3, unit: '支', code: 'ZB-006-001' },
    ],
    status: '草稿', createTime: '2024-07-10 16:00', remark: '夜间执勤',
  },
]

const warehouseOptions = [
  '省厅主装备仓库', '省厅应急物资仓库', 'YYY市局装备仓库',
  'YYY市局城南分库', 'YYY市局装备仓库', 'YYY市局装备仓库',
  'YYY市局装备仓库', 'YYY市局装备仓库',
]

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '防弹背心', category: '防护装备', model: 'FDY-3R/三级', productionDate: '2024-01-15', expiryDate: '2029-01-14', remaining: 180, unit: '件', price: 1200, code: 'ZB-001-001', supplier: '某安防科技有限公司' },
  { id: '2', name: '手铐', category: '警械装备', model: 'SK-STD', productionDate: '2024-02-20', expiryDate: '2029-02-19', remaining: 500, unit: '副', price: 85, code: 'ZB-002-001', supplier: '某警用装备有限公司' },
  { id: '3', name: '执法记录仪', category: '通信装备', model: 'DSJ-A7/64G', productionDate: '2024-03-01', expiryDate: '2029-03-01', remaining: 145, unit: '台', price: 2800, code: 'ZB-003-001', supplier: '某警用装备有限公司' },
  { id: '4', name: '对讲机', category: '通信装备', model: 'DJ-8800', productionDate: '2024-01-20', expiryDate: '2029-01-19', remaining: 95, unit: '台', price: 680, code: 'ZB-004-001', supplier: '某通信设备公司' },
  { id: '5', name: '警用头盔', category: '防护装备', model: 'MICH2000/L号', productionDate: '2024-01-10', expiryDate: '2029-01-09', remaining: 280, unit: '顶', price: 450, code: 'ZB-005-001', supplier: '某警用装备有限公司' },
  { id: '6', name: '防刺服', category: '防护装备', model: 'FCF-II', productionDate: '2024-04-05', expiryDate: '2029-04-04', remaining: 78, unit: '件', price: 380, code: 'ZB-001-002', supplier: '某防护用品厂' },
  { id: '7', name: '警棍', category: '警械装备', model: 'JG-TELE', productionDate: '2024-02-15', expiryDate: '2029-02-14', remaining: 200, unit: '根', price: 120, code: 'ZB-002-002', supplier: '某交通设施厂' },
  { id: '8', name: '防割手套', category: '防护装备', model: 'FG-ST5', productionDate: '2024-05-01', expiryDate: '2029-04-30', remaining: 150, unit: '双', price: 35, code: 'ZB-001-005', supplier: '某防护用品厂' },
]

/* ═══════════════════════════════════════════
   状态徽章
   ═══════════════════════════════════════════ */

function statusBadge(status: PickupStatus) {
  const map: Record<PickupStatus, { variant: string; label: string }> = {
    '草稿': { variant: 'warning', label: '草稿' },
    '已提交': { variant: 'primary', label: '已提交' },
    '审批中': { variant: 'info', label: '审批中' },
    '待出库': { variant: 'warning', label: '待出库' },
    '已出库': { variant: 'success', label: '已出库' },
    '已归还': { variant: 'success', label: '已归还' },
  }
  const s = map[status]
  return <Badge variant={s.variant as any}>{s.label}</Badge>
}

/* ═══════════════════════════════════════════
   表单弹窗
   ═══════════════════════════════════════════ */

/* ═══════════════════════════════════════════
   库存装备选择弹窗（参照报修-添加物资）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open, onClose, onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedStockEquip[]) => void
}) {
  const [selected, setSelected] = useState<SelectedStockEquip[]>([])
  const [searchName, setSearchName] = useState('')

  if (!open) return null

  const filteredStock = stockEquipments.filter(e =>
    searchName ? e.name.includes(searchName) || e.code.includes(searchName) : true
  )

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, qty: 1 }]
    })
  }

  const updateQty = (id: string, qty: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, qty: Math.max(1, Math.min(qty, s.equip.remaining)) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 筛选 */}
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部位置</option>
            <option>省厅仓库1层</option>
            <option>省厅仓库2层</option>
            <option>省厅仓库3层</option>
          </select>
          <input type="text" value={searchName} onChange={e => setSearchName(e.target.value)} placeholder="物资名称..." className="h-8 w-40 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部类别</option>
            <option>防护装备</option>
            <option>警械装备</option>
            <option>通信装备</option>
            <option>照明设备</option>
          </select>
          <button className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">查询</button>
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：库存装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map(equip => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input type="checkbox" checked={isChecked(equip.id)} onChange={() => toggleEquip(equip)} className="h-4 w-4 rounded border-[#D1D5DB]" />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.productionDate}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.expiryDate}</td>
                    <td className="px-3 py-2 text-right font-medium text-[#059669]">{equip.remaining}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.unit}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{equip.price.toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{equip.code}</td>
                    <td className="px-3 py-2 text-[11px] text-[#374151]">{equip.supplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">已选择装备 ({selected.length})</div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map(s => (
              <div key={s.equip.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span>
                  <button onClick={() => removeSelected(s.equip.id)} className="text-xs text-[#EF4444] hover:underline">删除</button>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-[#6B7280]">
                  <span>类别: {s.equip.category}</span>
                  <span>规格: {s.equip.model}</span>
                  <span>编码: {s.equip.code}</span>
                  <span>余量: {s.equip.remaining}</span>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-[#6B7280]">数量:</span>
                  <input type="number" min={1} max={s.equip.remaining} value={s.qty} onChange={e => updateQty(s.equip.id, parseInt(e.target.value) || 1)} className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-center text-sm outline-none focus:border-[#1A56DB]" />
                  <span className="text-[11px] text-[#6B7280]">单价: ¥{s.equip.price.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={() => { onConfirm(selected); setSelected([]); setSearchName('') }} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">确认添加</button>
        </div>
      </div>
    </div>
  )
}

function PickupForm({
  open, record, onClose, onSave,
}: {
  open: boolean
  record: PickupRecord | null
  onClose: () => void
  onSave: (r: PickupRecord) => void
}) {
  const [applicantType, setApplicantType] = useState<ApplicantType>('申请人')
  const [applicantName, setApplicantName] = useState('')
  const [applicantUnit, setApplicantUnit] = useState('')
  const [warehouse, setWarehouse] = useState('')
  const [type, setType] = useState<PickupType>('领用')
  const [returnDate, setReturnDate] = useState('')
  const [items, setItems] = useState<PickupItem[]>([])
  const [remark, setRemark] = useState('')
  const [errors, setErrors] = useState<Record<string, boolean>>({})
  const [showEquipSelect, setShowEquipSelect] = useState(false)

  useEffect(() => {
    if (record) {
      setApplicantType(record.applicantType)
      setApplicantName(record.applicantName || '')
      setApplicantUnit(record.applicantUnit || '')
      setWarehouse(record.warehouse)
      setType(record.type)
      setReturnDate(record.returnDate || '')
      setItems([...record.items])
      setRemark(record.remark || '')
    } else {
      setApplicantType('申请人')
      setApplicantName('')
      setApplicantUnit('')
      setWarehouse('')
      setType('领用')
      setReturnDate('')
      setItems([])
      setRemark('')
    }
    setErrors({})
  }, [record])

  const handleConfirmEquip = (selected: SelectedStockEquip[]) => {
    const newItems = selected.map(s => ({
      equipName: s.equip.name,
      spec: s.equip.model,
      quantity: s.qty,
      unit: s.equip.unit,
      code: s.equip.code,
    }))
    setItems(prev => [...prev, ...newItems])
    setShowEquipSelect(false)
  }
  const handleRemoveItem = (idx: number) => {
    setItems(prev => prev.filter((_, i) => i !== idx))
  }

  const validate = () => {
    const newErrors: Record<string, boolean> = {}
    if (applicantType === '申请人' && !applicantName.trim()) newErrors.applicantName = true
    if (applicantType === '申请单位' && !applicantUnit.trim()) newErrors.applicantUnit = true
    if (!warehouse) newErrors.warehouse = true
    if (items.length === 0 || items.some(i => !i.equipName.trim())) newErrors.items = true
    if (type === '借用' && !returnDate) newErrors.returnDate = true
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = () => {
    if (!validate()) { alert('请填写必填项'); return }
    const newRecord: PickupRecord = {
      id: record?.id || Date.now().toString(),
      orderNo: record?.orderNo || `LY-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 900) + 100)}`,
      applicantType,
      applicantName: applicantType === '申请人' ? applicantName.trim() : undefined,
      applicantUnit: applicantType === '申请单位' ? applicantUnit.trim() : undefined,
      warehouse,
      type,
      items: items.map(i => ({ ...i })),
      returnDate: type === '借用' ? returnDate : undefined,
      status: record?.status || '草稿',
      createTime: record?.createTime || new Date().toLocaleString('zh-CN', { hour12: false }),
      submitTime: record?.submitTime,
      remark: remark.trim() || undefined,
    }
    onSave(newRecord)
    onClose()
  }

  const fieldClass = (key: string) => cn(
    'w-full rounded-md border px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]',
    errors[key] ? 'border-[#EF4444] bg-[#FFF5F5]' : 'border-[#D1D5DB]'
  )

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">{record ? '编辑领用单' : '新增领用单'}</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-auto px-6 py-5">
          <div className="space-y-4">
            {/* 申请人/申请单位 - 二选一 */}
            <div>
              <label className="mb-2 block text-sm font-medium text-[#374151]">申请对象 <span className="text-[#EF4444]">*</span></label>
              <div className="flex items-center gap-3 mb-2">
                {(['申请人', '申请单位'] as ApplicantType[]).map(t => (
                  <button key={t} onClick={() => setApplicantType(t)} className={cn(
                    'flex h-9 items-center gap-1.5 rounded-md border px-4 text-sm transition',
                    applicantType === t ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]'
                  )}>
                    {t === '申请人' ? <User size={14} /> : <Building2 size={14} />}{t}
                  </button>
                ))}
              </div>
              {applicantType === '申请人' ? (
                <input type="text" value={applicantName} onChange={e => setApplicantName(e.target.value)} placeholder="请输入申请人姓名" className={fieldClass('applicantName')} />
              ) : (
                <input type="text" value={applicantUnit} onChange={e => setApplicantUnit(e.target.value)} placeholder="请输入申请单位名称" className={fieldClass('applicantUnit')} />
              )}
            </div>

            {/* 调出仓库 */}
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">调出仓库 <span className="text-[#EF4444]">*</span></label>
              <select value={warehouse} onChange={e => setWarehouse(e.target.value)} className={fieldClass('warehouse')}>
                <option value="">请选择仓库</option>
                {warehouseOptions.map(w => <option key={w} value={w}>{w}</option>)}
              </select>
            </div>

            {/* 类型 */}
            <div>
              <label className="mb-2 block text-sm text-[#374151]">类型 <span className="text-[#EF4444]">*</span></label>
              <div className="flex items-center gap-3">
                {(['领用', '借用'] as PickupType[]).map(t => (
                  <button key={t} onClick={() => setType(t)} className={cn(
                    'flex h-9 items-center gap-1.5 rounded-md border px-4 text-sm transition',
                    type === t ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]'
                  )}>
                    <Package size={14} />{t}
                  </button>
                ))}
              </div>
            </div>

            {/* 借用类型才显示预计归还 */}
            {type === '借用' && (
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]">预计归还日期 <span className="text-[#EF4444]">*</span></label>
                <input type="date" value={returnDate} onChange={e => setReturnDate(e.target.value)} className={fieldClass('returnDate')} />
              </div>
            )}

            {/* 物资清单 - 参照报修添加物资模式 */}
            <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-medium text-[#374151]">
                  <Package size={14} className="text-[#D97706]" />
                  物资明细 <span className="text-[#EF4444]">*</span>
                  <span className="text-xs font-normal text-[#6B7280]">({items.length} 种)</span>
                </div>
                <button onClick={() => setShowEquipSelect(true)} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
                  <Plus size={14} /> 添加装备
                </button>
              </div>

              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-10 text-[#9CA3AF]">
                  <Package size={36} className="mb-2 opacity-40" />
                  <p className="text-sm">暂无装备，请点击上方按钮添加</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {items.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-white px-3 py-2">
                      <div className="flex-1">
                        <div className="text-sm font-medium text-[#1F2937]">{item.equipName}</div>
                        <div className="text-[11px] text-[#6B7280]">{item.code} · {item.spec} · 数量: {item.quantity}{item.unit}</div>
                      </div>
                      <button onClick={() => handleRemoveItem(idx)} className="text-xs text-[#EF4444] hover:underline">删除</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 备注 */}
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">备注</label>
              <textarea value={remark} onChange={e => setRemark(e.target.value)} placeholder="请输入备注信息..." rows={2} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] resize-none" />
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSubmit} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white hover:bg-[#153E7E]">保存</button>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </div>
  )
}

/* ═══════════════════════════════════════════
   详情弹窗
   ═══════════════════════════════════════════ */

function PickupDetail({ record, onClose }: { record: PickupRecord | null; onClose: () => void }) {
  if (!record) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[640px] max-w-[95vw] rounded-xl bg-white shadow-2xl max-h-[90vh] flex flex-col">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">领用单详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-auto px-6 py-5 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">领用单号</label><div className="text-sm font-medium text-[#1A56DB]">{record.orderNo}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">类型</label><div className="text-sm"><Badge variant={record.type === '借用' ? 'info' : 'primary'}>{record.type}</Badge></div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">状态</label><div className="text-sm">{statusBadge(record.status)}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">申请对象</label><div className="text-sm font-medium text-[#1F2937]">{record.applicantType === '申请人' ? record.applicantName : record.applicantUnit}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">调出仓库</label><div className="text-sm font-medium text-[#374151]">{record.warehouse}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">创建时间</label><div className="text-sm text-[#374151]">{record.createTime}</div></div>
          </div>

          {record.returnDate && (
            <div className="rounded-lg border border-[#E5E7EB] p-3">
              <label className="flex items-center gap-1 text-xs text-[#6B7280]"><Clock size={11} />预计归还日期</label>
              <div className="text-sm font-medium text-[#D97706]">{record.returnDate}</div>
            </div>
          )}

          <div className="rounded-lg border border-[#E5E7EB]">
            <div className="border-b border-[#E5E7EB] px-4 py-2 text-sm font-medium text-[#374151]">物资清单（{record.items.length}项）</div>
            <table className="w-full text-sm">
              <thead><tr className="border-b border-[#F3F4F6] bg-[#F9FAFB]"><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">装备名称</th><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">规格型号</th><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">装备编码</th><th className="px-3 py-2 text-right text-[11px] text-[#6B7280]">数量</th></tr></thead>
              <tbody>{record.items.map((item, idx) => (
                <tr key={idx} className="border-b border-[#F3F4F6]"><td className="px-3 py-2 font-medium text-[#1F2937]">{item.equipName}</td><td className="px-3 py-2 text-[#6B7280] text-[11px]">{item.spec}</td><td className="px-3 py-2 text-[#6B7280] text-[11px] font-mono">{item.code}</td><td className="px-3 py-2 text-right font-medium text-[#1A56DB]">{item.quantity} {item.unit}</td></tr>
              ))}</tbody>
            </table>
          </div>

          {record.remark && (
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">备注</label><div className="text-sm text-[#374151]">{record.remark}</div></div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

// 流程页签
 type FlowTabKey = '待审批' | '审批中' | '待出库' | '待归还'

 // 状态 → 页签映射
 function mapStatusToTab(status: PickupStatus): FlowTabKey {
   switch (status) {
     case '草稿':
     case '已提交': return '待审批'
     case '审批中': return '审批中'
     case '待出库': return '待出库'
     case '已出库':
     case '已归还': return '待归还'
   }
 }

 export default function EquipmentPickupPage() {
  const [records, setRecords] = useState<PickupRecord[]>(mockData)
  const [showForm, setShowForm] = useState(false)
  const [editingRecord, setEditingRecord] = useState<PickupRecord | null>(null)
  const [detailRecord, setDetailRecord] = useState<PickupRecord | null>(null)
  const [searchText, setSearchText] = useState('')
  const [filterStatus, setFilterStatus] = useState<FlowTabKey>('待审批')
  const [filterType, setFilterType] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  const pageSize = 10

  // 流程页签计数（基于搜索和类型筛选后的数据）
  let baseFiltered = records
  if (searchText) {
    baseFiltered = baseFiltered.filter(r =>
      r.orderNo.includes(searchText) ||
      (r.applicantName?.includes(searchText)) ||
      (r.applicantUnit?.includes(searchText)) ||
      r.warehouse.includes(searchText)
    )
  }
  if (filterType) baseFiltered = baseFiltered.filter(r => r.type === filterType)

  // 按流程页签过滤
  let filtered = baseFiltered
  filtered = filtered.filter(r => mapStatusToTab(r.status) === filterStatus)

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  // 4个流程页签：待审批、审批中、待出库、待归还
  const flowTabs: { key: FlowTabKey; label: string }[] = [
    { key: '待审批', label: '待审批' },
    { key: '审批中', label: '审批中' },
    { key: '待出库', label: '待出库' },
    { key: '待归还', label: '待归还' },
  ]
  const getTabCount = (tabKey: FlowTabKey) => baseFiltered.filter(r => mapStatusToTab(r.status) === tabKey).length

  const handleSave = (r: PickupRecord) => {
    if (editingRecord) {
      setRecords(prev => prev.map(item => item.id === r.id ? r : item))
    } else {
      setRecords(prev => [r, ...prev])
    }
  }

  const handleDelete = (id: string) => {
    if (!confirm('确定删除该领用单？')) return
    setRecords(prev => prev.filter(r => r.id !== id))
  }

  const handleWithdraw = (id: string) => {
    if (!confirm('确定撤回该领用单？撤回后将变为草稿状态。')) return
    setRecords(prev => prev.map(r => r.id === id ? { ...r, status: '草稿' as PickupStatus, submitTime: undefined } : r))
  }

  const canEdit = (r: PickupRecord) => r.status === '草稿'
  const canDelete = (r: PickupRecord) => r.status === '草稿'
  const canWithdraw = (r: PickupRecord) => r.status === '已提交'

  return (
    <div>
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备领用</h1>
        <button onClick={() => { setEditingRecord(null); setShowForm(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">
          <Plus size={14} /> 新增领用单
        </button>
      </div>

      {/* 流程页签 + 筛选 */}
      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        {/* 流程页签导航 */}
        <div className="flex items-center gap-0 border-b border-[#E5E7EB] px-4">
          {flowTabs.map(tab => {
            const count = getTabCount(tab.key)
            const isActive = filterStatus === tab.key
            return (
              <button
                key={tab.key}
                onClick={() => { setFilterStatus(tab.key); setCurrentPage(1) }}
                className={cn(
                  'relative flex items-center gap-1.5 px-5 py-3 text-sm font-medium transition',
                  isActive ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
                )}
              >
                {tab.label}
                <span className={cn(
                  'flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-medium',
                  isActive ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280]'
                )}>
                  {count}
                </span>
                {isActive && <div className="absolute inset-x-0 bottom-0 h-0.5 bg-[#1A56DB]" />}
              </button>
            )
          })}
        </div>
        {/* 搜索和类型筛选 */}
        <div className="flex flex-wrap items-center gap-3 p-4">
          <input type="text" placeholder="搜索单号/申请人/仓库" value={searchText} onChange={e => { setSearchText(e.target.value); setCurrentPage(1) }} className="h-9 w-64 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
          <select value={filterType} onChange={e => { setFilterType(e.target.value); setCurrentPage(1) }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none">
            <option value="">全部类型</option>
            <option value="领用">领用</option>
            <option value="借用">借用</option>
          </select>
          <span className="text-xs text-[#6B7280]">共 {filtered.length} 条</span>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">领用单号</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">申请对象</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">调出仓库</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">类型</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">物资清单</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">预计归还</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">状态</th>
              <th className="px-3 py-3 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {pageData.map(r => (
              <tr key={r.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                <td className="px-3 py-3 font-medium text-[#1A56DB] text-[11px]">{r.orderNo}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1 text-[#374151]">
                    {r.applicantType === '申请人' ? <User size={11} className="text-[#1A56DB]" /> : <Building2 size={11} className="text-[#10B981]" />}
                    <span className="text-[11px]">{r.applicantName || r.applicantUnit}</span>
                  </div>
                </td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.warehouse}</td>
                <td className="px-3 py-3"><Badge variant={r.type === '借用' ? 'info' : 'primary'}>{r.type}</Badge></td>
                <td className="px-3 py-3">
                  <div className="max-w-[200px] text-[11px] text-[#6B7280] truncate">
                    {r.items.map(i => `${i.equipName}x${i.quantity}`).join('、')}
                  </div>
                </td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.returnDate || '-'}</td>
                <td className="px-3 py-3">{statusBadge(r.status)}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => setDetailRecord(r)} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#1A56DB]" title="详情"><Eye size={14} /></button>
                    {canEdit(r) && (
                      <button onClick={() => { setEditingRecord(r); setShowForm(true) }} className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] hover:bg-[#E8F0FE]" title="编辑"><Edit3 size={14} /></button>
                    )}
                    {canWithdraw(r) && (
                      <button onClick={() => handleWithdraw(r.id)} className="flex h-7 w-7 items-center justify-center rounded text-[#D97706] hover:bg-[#FEF3C7]" title="撤回"><RotateCcw size={14} /></button>
                    )}
                    {canDelete(r) && (
                      <button onClick={() => handleDelete(r.id)} className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {pageData.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无数据</div>}
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between">
          <div className="text-xs text-[#6B7280]">第 {currentPage} / {totalPages} 页，共 {filtered.length} 条</div>
          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage <= 1} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronLeft size={14} /></button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-8 min-w-8 items-center justify-center rounded border text-xs transition', currentPage === p ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
            ))}
            <button onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage >= totalPages} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronRightIcon size={14} /></button>
          </div>
        </div>
      )}

      {/* PickupForm */}
      <PickupForm open={showForm} record={editingRecord} onClose={() => { setShowForm(false); setEditingRecord(null) }} onSave={handleSave} />

      {/* Detail */}
      <PickupDetail record={detailRecord} onClose={() => setDetailRecord(null)} />
    </div>
  )
}
