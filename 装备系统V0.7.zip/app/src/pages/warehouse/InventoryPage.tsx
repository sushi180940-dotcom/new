import { useState } from 'react'
import {
  Plus, Eye, Edit, Trash2, X, Play, RotateCcw, ClipboardCheck,
  Package, ScanLine, FileSpreadsheet, Upload, CheckCircle2, XCircle, MinusCircle
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface InventoryEquipment {
  id: string
  code: string
  name: string
  category1: string
  category2: string
  category3: string
  model: string
  unit: string
  stockQty: number
  rfidCodes: string[]
  warehouse: string
}

interface InventoryItem {
  equip: InventoryEquipment
  checkQty: number | null
  remark: string
}

interface InventoryTask {
  id: string
  name: string
  warehouse: string
  cycle: '期初盘点' | '存货盘点' | '期末盘点'
  startDate: string
  endDate: string
  assignee: string
  assignUnit: string
  status: 'planned' | 'ongoing' | 'completed'
  items: InventoryItem[]
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备（含完整分类和RFID）
   ═══════════════════════════════════════════ */

const allEquipments: InventoryEquipment[] = [
  { id: '1', code: 'ZB-2024-001', name: '手持终端 XT-2000', category1: '通信设备', category2: '移动终端', category3: '手持式', model: 'XT-2000/黑色/128G', unit: '台', stockQty: 50, rfidCodes: ['RFID001001', 'RFID001002', 'RFID001003'], warehouse: '省厅主仓库' },
  { id: '2', code: 'ZB-2024-002', name: '执法记录仪 DSJ-A7', category1: '记录设备', category2: '视频记录', category3: '便携式', model: 'DSJ-A7/64G/高清', unit: '台', stockQty: 30, rfidCodes: ['RFID002001', 'RFID002002'], warehouse: '省厅主仓库' },
  { id: '3', code: 'ZB-2024-003', name: '防弹背心 FDY-3R', category1: '防护装备', category2: '身体防护', category3: '背心式', model: 'FDY-3R/三级/L', unit: '件', stockQty: 35, rfidCodes: ['RFID003001', 'RFID003002', 'RFID003003'], warehouse: 'A区仓库' },
  { id: '4', code: 'ZB-2024-004', name: '对讲机 PD780G', category1: '通信设备', category2: '无线对讲', category3: '手持式', model: 'PD780G/U段', unit: '台', stockQty: 52, rfidCodes: ['RFID004001', 'RFID004002'], warehouse: 'B区仓库' },
  { id: '5', code: 'ZB-2024-005', name: '强光手电 QG-500', category1: '照明设备', category2: '手持照明', category3: '充电式', model: 'QG-500/充电款', unit: '支', stockQty: 86, rfidCodes: ['RFID005001', 'RFID005002', 'RFID005003', 'RFID005004'], warehouse: 'C区仓库' },
  { id: '6', code: 'ZB-2024-006', name: '应急照明灯 YD-100', category1: '照明设备', category2: '应急照明', category3: '固定式', model: 'YD-100/LED', unit: '台', stockQty: 60, rfidCodes: ['RFID006001', 'RFID006002'], warehouse: 'A区仓库' },
  { id: '7', code: 'ZB-2024-007', name: '战术头盔 MICH-2000', category1: '防护装备', category2: '头部防护', category3: '头盔式', model: 'MICH-2000/L号', unit: '顶', stockQty: 40, rfidCodes: ['RFID007001', 'RFID007002'], warehouse: 'B区仓库' },
  { id: '8', code: 'ZB-2024-008', name: '防弹盾牌 FDP-3S', category1: '防护装备', category2: '身体防护', category3: '手持式', model: 'FDP-3S/手持型', unit: '面', stockQty: 15, rfidCodes: ['RFID008001', 'RFID008002'], warehouse: '省厅主仓库' },
  { id: '9', code: 'ZB-2024-009', name: '警用伸缩棍 ZG-600', category1: '警械装备', category2: '约束制服', category3: '伸缩式', model: 'ZG-600/钛合金', unit: '根', stockQty: 100, rfidCodes: ['RFID009001'], warehouse: 'C区仓库' },
  { id: '10', code: 'ZB-2024-010', name: '防刺手套 FC-800', category1: '防护装备', category2: '手部防护', category3: '手套式', model: 'FC-800/凯夫拉', unit: '副', stockQty: 45, rfidCodes: ['RFID010001', 'RFID010002'], warehouse: 'A区仓库' },
]

/* ═══════════════════════════════════════════
   Mock 数据：盘点任务
   ═══════════════════════════════════════════ */

const initialTasks: InventoryTask[] = [
  { id: 'PD20260603001', name: '2026年第二季度全面盘点', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-06-15', endDate: '2026-06-20', assignee: '张管理员', assignUnit: '装备管理处', status: 'planned', items: [] },
  { id: 'PD20260603002', name: 'A区防护装备专项盘点', warehouse: 'A区仓库', cycle: '期初盘点', startDate: '2026-06-10', endDate: '2026-06-12', assignee: '李管理员', assignUnit: '装备管理处', status: 'planned', items: [] },
  { id: 'PD20260603003', name: '执法装备月度抽盘', warehouse: 'C区仓库', cycle: '期末盘点', startDate: '2026-06-05', endDate: '2026-06-05', assignee: '王警官', assignUnit: '刑警支队', status: 'planned', items: [] },
  { id: 'PD20260603004', name: '2026年5月月度盘点', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-05-25', endDate: '2026-05-28', assignee: '赵管理员', assignUnit: '装备管理处', status: 'ongoing', items: allEquipments.filter(e => e.warehouse === '省厅主仓库').map(e => ({ equip: e, checkQty: null, remark: '' })) },
  { id: 'PD20260603005', name: 'B区通信设备盘点', warehouse: 'B区仓库', cycle: '期初盘点', startDate: '2026-05-28', endDate: '2026-05-30', assignee: '刘警官', assignUnit: '通信科', status: 'ongoing', items: allEquipments.filter(e => e.warehouse === 'B区仓库').map(e => ({ equip: e, checkQty: null, remark: '' })) },
  { id: 'PD20260603006', name: '2026年第一季度全面盘点', warehouse: '省厅主仓库', cycle: '期末盘点', startDate: '2026-03-15', endDate: '2026-03-22', assignee: '张管理员', assignUnit: '装备管理处', status: 'completed', items: allEquipments.slice(0, 4).map(e => ({ equip: e, checkQty: e.stockQty, remark: '' })) },
]

const warehouseOptions = ['请选择', '省厅主仓库', 'A区仓库', 'B区仓库', 'C区仓库']

/* ═══════════════════════════════════════════
   分类数据（一级 → 二级 → 三级）
   ═══════════════════════════════════════════ */

const categoryTree: Record<string, Record<string, string[]>> = {
  '通信设备': {
    '移动终端': ['手持式', '车载式'],
    '无线对讲': ['手持式', '基地式'],
  },
  '记录设备': {
    '视频记录': ['便携式', '固定式'],
    '音频记录': ['便携式', '固定式'],
  },
  '防护装备': {
    '身体防护': ['背心式', '手持式'],
    '头部防护': ['头盔式', '帽式'],
    '手部防护': ['手套式', '护腕式'],
  },
  '照明设备': {
    '手持照明': ['充电式', '电池式'],
    '应急照明': ['固定式', '便携式'],
  },
  '警械装备': {
    '约束制服': ['伸缩式', '固定式'],
  },
}

/* ═══════════════════════════════════════════
   辅助函数
   ═══════════════════════════════════════════ */

function generateTaskNo() {
  return `PD${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`
}

function getEquipmentsByWarehouse(warehouse: string): InventoryEquipment[] {
  if (!warehouse || warehouse === '请选择') return []
  return allEquipments.filter(e => e.warehouse === warehouse)
}

function getCategory1Options() {
  return Object.keys(categoryTree)
}

function getCategory2Options(c1: string) {
  if (!c1) return []
  return Object.keys(categoryTree[c1] || {})
}

function getCategory3Options(c1: string, c2: string) {
  if (!c1 || !c2) return []
  return (categoryTree[c1]?.[c2]) || []
}

function filterEquipmentsByCategory(c1: string, c2: string, c3: string): InventoryEquipment[] {
  return allEquipments.filter(e => {
    if (c1 && e.category1 !== c1) return false
    if (c2 && e.category2 !== c2) return false
    if (c3 && e.category3 !== c3) return false
    return true
  })
}

/* ═══════════════════════════════════════════
   盘点统计
   ═══════════════════════════════════════════ */

function calcInventoryStats(items: InventoryItem[]) {
  const total = items.length
  const noDiff = items.filter(i => i.checkQty !== null && i.checkQty === i.equip.stockQty).length
  const loss = items.filter(i => i.checkQty !== null && i.checkQty < i.equip.stockQty).length
  const gain = items.filter(i => i.checkQty !== null && i.checkQty > i.equip.stockQty).length
  return { total, noDiff, loss, gain }
}

/* ═══════════════════════════════════════════
   状态标签
   ═══════════════════════════════════════════ */

function InventoryStatus({ status }: { status: string }) {
  switch (status) {
    case 'planned': return <Badge variant="default">计划中</Badge>
    case 'ongoing': return <Badge variant="info" dot>进行中</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function CycleBadge({ cycle }: { cycle: string }) {
  switch (cycle) {
    case '期初盘点': return <Badge variant="info">期初盘点</Badge>
    case '存货盘点': return <Badge variant="primary">存货盘点</Badge>
    case '期末盘点': return <Badge variant="warning">期末盘点</Badge>
    default: return <Badge variant="default">{cycle}</Badge>
  }
}

/* ═══════════════════════════════════════════
   差异计算
   ═══════════════════════════════════════════ */

function calcVarianceSummary(items: InventoryItem[]) {
  let hasVariance = false
  let totalDiff = 0
  items.forEach(i => {
    if (i.checkQty !== null) {
      const diff = i.checkQty - i.equip.stockQty
      if (diff !== 0) hasVariance = true
      totalDiff += Math.abs(diff)
    }
  })
  if (!hasVariance) return '无差异'
  return `差异${totalDiff}件`
}

function calcItemDiff(item: InventoryItem): number | null {
  if (item.checkQty === null) return null
  return item.checkQty - item.equip.stockQty
}

/* ═══════════════════════════════════════════
   导出CSV辅助函数
   ═══════════════════════════════════════════ */

function exportToCSV(items: InventoryItem[], taskName: string) {
  const headers = ['装备编码', '装备名称', '一级分类', '二级分类', '三级分类', '规格型号', '单位', 'RFID编号', '库存数量', '盘点数量', '盈亏', '备注']
  const rows = items.map(i => [
    i.equip.code,
    i.equip.name,
    i.equip.category1,
    i.equip.category2,
    i.equip.category3,
    i.equip.model,
    i.equip.unit,
    i.equip.rfidCodes.join(';'),
    String(i.equip.stockQty),
    i.checkQty !== null ? String(i.checkQty) : '',
    i.checkQty !== null ? String(i.checkQty - i.equip.stockQty) : '',
    i.remark,
  ])
  const csv = [headers.join(','), ...rows.map(r => r.map(c => `"${c}"`).join(','))].join('\n')
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${taskName}_盘点明细.csv`
  link.click()
  URL.revokeObjectURL(link.href)
}

/* ═══════════════════════════════════════════
   装备选择弹窗（支持仓库选择和分类选择两种模式）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: InventoryEquipment[]) => void
}) {
  const [mode, setMode] = useState<'warehouse' | 'category'>('warehouse')
  const [selWarehouse, setSelWarehouse] = useState('')
  const [c1, setC1] = useState('')
  const [c2, setC2] = useState('')
  const [c3, setC3] = useState('')
  const [selected, setSelected] = useState<InventoryEquipment[]>([])

  if (!open) return null

  const displayedEquips = mode === 'warehouse'
    ? getEquipmentsByWarehouse(selWarehouse)
    : filterEquipmentsByCategory(c1, c2, c3)

  const isChecked = (id: string) => selected.some(s => s.id === id)

  const toggleEquip = (equip: InventoryEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.id === equip.id)
      if (exists) return prev.filter(s => s.id !== equip.id)
      return [...prev, equip]
    })
  }

  const handleConfirm = () => {
    onConfirm(selected)
    setSelected([])
    setSelWarehouse('')
    setC1(''); setC2(''); setC3('')
    setMode('warehouse')
  }

  const handleClose = () => {
    setSelected([])
    setSelWarehouse('')
    setC1(''); setC2(''); setC3('')
    setMode('warehouse')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">选择装备</h2>
          <button onClick={handleClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 模式切换 + 筛选 */}
        <div className="shrink-0 border-b border-[#E5E7EB] px-6 py-3">
          <div className="mb-3 flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="selectMode"
                checked={mode === 'warehouse'}
                onChange={() => { setMode('warehouse'); setC1(''); setC2(''); setC3('') }}
                className="h-4 w-4"
              />
              按仓库选择
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="selectMode"
                checked={mode === 'category'}
                onChange={() => { setMode('category'); setSelWarehouse('') }}
                className="h-4 w-4"
              />
              按分类选择
            </label>
          </div>

          {mode === 'warehouse' ? (
            <select
              value={selWarehouse}
              onChange={e => setSelWarehouse(e.target.value)}
              className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
            >
              {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
            </select>
          ) : (
            <div className="flex items-center gap-3">
              <select value={c1} onChange={e => { setC1(e.target.value); setC2(''); setC3('') }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">一级分类</option>
                {getCategory1Options().map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={c2} onChange={e => { setC2(e.target.value); setC3('') }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">二级分类</option>
                {getCategory2Options(c1).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={c3} onChange={e => setC3(e.target.value)} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">三级分类</option>
                {getCategory3Options(c1, c2).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          )}
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">一级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">二级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">三级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">库存数量</th>
                </tr>
              </thead>
              <tbody>
                {displayedEquips.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-3 py-8 text-center text-sm text-[#9CA3AF]">
                      {mode === 'warehouse' ? '请选择仓库' : '请选择分类'}
                    </td>
                  </tr>
                )}
                {displayedEquips.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input type="checkbox" checked={isChecked(equip.id)} onChange={() => toggleEquip(equip)} className="h-4 w-4 rounded border-[#D1D5DB]" />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{equip.code}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category1}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category2}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category3}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-right text-[#1A56DB]">{equip.stockQty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[260px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">已选择装备 ({selected.length})</div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.name}</span>
                  <button onClick={() => setSelected(prev => prev.filter(p => p.id !== s.id))} className="text-[#EF4444] hover:text-[#DC2626]">
                    <X size={14} />
                  </button>
                </div>
                <div className="text-[11px] text-[#6B7280]">编码：{s.code}</div>
                <div className="text-[11px] text-[#6B7280]">库存：{s.stockQty} {s.unit}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={handleClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
          <button onClick={handleConfirm} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">确定</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   创建盘点任务弹窗
   ═══════════════════════════════════════════ */

function CreateInventoryModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (task: InventoryTask) => void
}) {
  const [taskName, setTaskName] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [cycle, setCycle] = useState<'期初盘点' | '存货盘点' | '期末盘点'>('存货盘点')
  const [assignee, setAssignee] = useState('')
  const [assignUnit, setAssignUnit] = useState('')
  const [warehouse, setWarehouse] = useState('')
  const [items, setItems] = useState<InventoryItem[]>([])
  const [showEquipSelect, setShowEquipSelect] = useState(false)

  if (!open) return null

  const taskNo = generateTaskNo()

  // 选择仓库后自动加载该仓库装备
  const handleWarehouseChange = (value: string) => {
    setWarehouse(value)
    if (value && value !== '请选择') {
      const equips = getEquipmentsByWarehouse(value)
      setItems(equips.map(e => ({ equip: e, checkQty: null, remark: '' })))
    } else {
      setItems([])
    }
  }

  const handleConfirmEquip = (selected: InventoryEquipment[]) => {
    setItems(prev => {
      const merged = [...prev]
      selected.forEach(equip => {
        if (!merged.some(m => m.equip.id === equip.id)) {
          merged.push({ equip, checkQty: null, remark: '' })
        }
      })
      return merged
    })
    setShowEquipSelect(false)
  }

  const handleExport = () => {
    if (items.length === 0) { alert('暂无装备可导出'); return }
    exportToCSV(items, taskName || taskNo)
  }

  const handleLoadToRFID = () => {
    if (items.length === 0) { alert('暂无装备可加载'); return }
    alert(`已将 ${items.length} 条装备数据加载到RFID盘点设备`)
  }

  const handleSave = () => {
    if (!taskName.trim()) { alert('请输入盘点单号'); return }
    if (!startDate) { alert('请选择盘点时间'); return }
    if (!assignee.trim()) { alert('请输入经办人'); return }
    if (!warehouse) { alert('请选择仓库'); return }

    onSave({
      id: taskNo,
      name: taskName,
      warehouse,
      cycle,
      startDate,
      endDate: endDate || startDate,
      assignee,
      assignUnit: assignUnit || '装备管理处',
      status: 'planned',
      items,
    })
    // Reset
    setTaskName('')
    setStartDate('')
    setEndDate('')
    setCycle('存货盘点')
    setAssignee('')
    setAssignUnit('')
    setWarehouse('')
    setItems([])
    onClose()
  }

  const handleClose = () => {
    setTaskName('')
    setStartDate('')
    setEndDate('')
    setCycle('存货盘点')
    setAssignee('')
    setAssignUnit('')
    setWarehouse('')
    setItems([])
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[1000px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">创建盘点任务</h2>
            <button onClick={handleClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 grid grid-cols-3 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点单号 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={taskNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点时间 <span className="text-[#EF4444]">*</span></label>
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点类型 <span className="text-[#EF4444]">*</span></label>
                <select value={cycle} onChange={e => setCycle(e.target.value as any)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  <option value="期初盘点">期初盘点</option>
                  <option value="存货盘点">存货盘点</option>
                  <option value="期末盘点">期末盘点</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">经办人 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={assignee} onChange={e => setAssignee(e.target.value)} placeholder="请输入经办人姓名" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">经办单位 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={assignUnit} onChange={e => setAssignUnit(e.target.value)} placeholder="请输入经办单位" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">仓库 <span className="text-[#EF4444]">*</span></label>
                <select
                  value={warehouse}
                  onChange={e => handleWarehouseChange(e.target.value)}
                  className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
                >
                  {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* 装备盘点明细 */}
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="text-sm font-semibold text-[#374151]">
                  盘点明细 <span className="text-xs font-normal text-[#6B7280]">（共 {items.length} 件）</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExport}
                    className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"
                  >
                    <FileSpreadsheet size={13} /> 导出Excel
                  </button>
                  <button
                    onClick={handleLoadToRFID}
                    className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"
                  >
                    <ScanLine size={13} /> 加载到RFID设备
                  </button>
                  <button
                    onClick={() => setShowEquipSelect(true)}
                    className="inline-flex h-8 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-sm text-white hover:bg-[#153E7E]"
                  >
                    <Plus size={13} /> 新增装备
                  </button>
                </div>
              </div>

              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-8 text-[#9CA3AF]">
                  <p className="text-sm">暂无装备明细</p>
                  <p className="mt-1 text-xs">选择仓库后自动加载装备数据，或点击「新增装备」手动添加</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                        <th className="w-8 px-2 py-2"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">序号</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备类别</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">库存数量</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">RFID编号</th>
                        <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {items.map((s, idx) => (
                        <tr key={s.equip.id} className="border-b border-[#F3F4F6]">
                          <td className="px-2 py-2 text-center"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></td>
                          <td className="px-3 py-2 text-[#6B7280]">{idx + 1}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{s.equip.code}</td>
                          <td className="px-3 py-2 font-medium text-[#1F2937]">{s.equip.name}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.category1}/{s.equip.category2}</td>
                          <td className="px-3 py-2 text-[12px] text-[#6B7280]">{s.equip.model}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.unit}</td>
                          <td className="px-3 py-2 text-right text-[#1A56DB]">{s.equip.stockQty}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{s.equip.rfidCodes.join(', ')}</td>
                          <td className="px-3 py-2 text-center">
                            <button onClick={() => setItems(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={handleClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">创建盘点任务</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   录入盘点结果弹窗（参考截图）
   ═══════════════════════════════════════════ */

function EnterResultModal({
  open,
  onClose,
  task,
  onSave,
}: {
  open: boolean
  onClose: () => void
  task: InventoryTask | null
  onSave: (task: InventoryTask) => void
}) {
  const [items, setItems] = useState<InventoryItem[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)

  if (!open || !task) return null

  const currentItems = items.length > 0 ? items : task.items
  const stats = calcInventoryStats(currentItems)

  const handleUpdateQty = (id: string, qty: number) => {
    setItems(prev => {
      const base = prev.length > 0 ? prev : task.items
      return base.map(e => e.equip.id === id ? { ...e, checkQty: qty } : e)
    })
  }

  const handleUpdateRemark = (id: string, remark: string) => {
    setItems(prev => {
      const base = prev.length > 0 ? prev : task.items
      return base.map(e => e.equip.id === id ? { ...e, remark } : e)
    })
  }

  const handleRFIDScan = () => {
    // 模拟RFID扫描：随机设置一些装备的盘点数量
    setItems(prev => {
      const base = prev.length > 0 ? prev : [...task.items]
      return base.map(item => {
        const random = Math.random()
        if (random > 0.7) {
          // 30% 概率盘亏
          return { ...item, checkQty: Math.max(0, item.equip.stockQty - Math.floor(Math.random() * 3)) }
        } else if (random > 0.9) {
          // 10% 概率盘盈
          return { ...item, checkQty: item.equip.stockQty + Math.floor(Math.random() * 3) + 1 }
        }
        // 60% 概率无差异
        return { ...item, checkQty: item.equip.stockQty }
      })
    })
    alert('RFID扫描完成，已自动填充盘点数量')
  }

  const handleImportExcel = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.csv,.xlsx,.xls'
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        alert(`已选择文件：${file.name}，将解析并填充盘点数据`)
        // 模拟导入：随机填充一些数据
        setItems(prev => {
          const base = prev.length > 0 ? prev : [...task.items]
          return base.map(item => ({
            ...item,
            checkQty: item.equip.stockQty + Math.floor(Math.random() * 5) - 2
          }))
        })
      }
    }
    input.click()
  }

  const handleSave = (asDraft: boolean) => {
    const updatedTask: InventoryTask = {
      ...task,
      items: currentItems,
      status: asDraft ? 'ongoing' : 'completed',
    }
    onSave(updatedTask)
    setItems([])
    onClose()
  }

  const getDiffBadge = (diff: number | null) => {
    if (diff === null) return <span className="text-[#9CA3AF]">-</span>
    if (diff === 0) return <span className="inline-flex items-center gap-1 text-[#059669]"><CheckCircle2 size={12} /> 无差异</span>
    if (diff > 0) return <span className="inline-flex items-center gap-1 text-[#1A56DB]"><Plus size={12} /> 盘盈 {diff}</span>
    return <span className="inline-flex items-center gap-1 text-[#DC2626]"><MinusCircle size={12} /> 盘亏 {Math.abs(diff)}</span>
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[94vh] w-[1100px] max-w-[96vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">盘点录入 - {task.name}</h2>
            <div className="mt-1 flex items-center gap-4 text-xs text-[#6B7280]">
              <span>盘点编号：{task.id}</span>
              <span>盘点人：{task.assignee}</span>
              <span>仓库：{task.warehouse}</span>
            </div>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 统计卡片 */}
        <div className="shrink-0 grid grid-cols-4 gap-4 border-b border-[#E5E7EB] px-6 py-4">
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#1A56DB]/10">
              <Package size={18} className="text-[#1A56DB]" />
            </div>
            <div>
              <div className="text-lg font-bold text-[#1F2937]">{stats.total}<span className="ml-1 text-xs font-normal text-[#6B7280]">件</span></div>
              <div className="text-xs text-[#6B7280]">装备总数</div>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#059669]/10">
              <CheckCircle2 size={18} className="text-[#059669]" />
            </div>
            <div>
              <div className="text-lg font-bold text-[#059669]">{stats.noDiff}<span className="ml-1 text-xs font-normal text-[#6B7280]">件</span></div>
              <div className="text-xs text-[#6B7280]">无差异</div>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DC2626]/10">
              <XCircle size={18} className="text-[#DC2626]" />
            </div>
            <div>
              <div className="text-lg font-bold text-[#DC2626]">{stats.loss}<span className="ml-1 text-xs font-normal text-[#6B7280]">件</span></div>
              <div className="text-xs text-[#6B7280]">盘亏</div>
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#1A56DB]/10">
              <Plus size={18} className="text-[#1A56DB]" />
            </div>
            <div>
              <div className="text-lg font-bold text-[#1A56DB]">{stats.gain}<span className="ml-1 text-xs font-normal text-[#6B7280]">件</span></div>
              <div className="text-xs text-[#6B7280]">盘盈</div>
            </div>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="shrink-0 flex items-center justify-end gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <button
            onClick={handleRFIDScan}
            className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"
          >
            <ScanLine size={14} /> RFID扫描
          </button>
          <button
            onClick={handleImportExcel}
            className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"
          >
            <Upload size={14} /> 导入Excel
          </button>
        </div>

        {/* 盘点表格 */}
        <div className="flex-1 overflow-auto px-6 py-4">
          <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">序号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">RFID编号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">库存数量</th>
                  <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">盘点数量(录入)</th>
                  <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">盈亏</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">备注</th>
                </tr>
              </thead>
              <tbody>
                {currentItems.map((item, idx) => {
                  const diff = calcItemDiff(item)
                  return (
                    <tr key={item.equip.id} className="border-b border-[#F3F4F6]">
                      <td className="px-3 py-2 text-center text-[#6B7280]">{idx + 1}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{item.equip.code}</td>
                      <td className="px-3 py-2 font-medium text-[#1F2937]">{item.equip.name}</td>
                      <td className="px-3 py-2 text-[#374151]">{item.equip.category1}/{item.equip.category2}</td>
                      <td className="px-3 py-2 text-[#374151]">{item.equip.unit}</td>
                      <td className="px-3 py-2 text-[12px] text-[#6B7280]">{item.equip.model}</td>
                      <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{item.equip.rfidCodes.join(', ')}</td>
                      <td className="px-3 py-2 text-right text-[#374151]">{item.equip.stockQty}</td>
                      <td className="px-3 py-2 text-center">
                        {editingId === item.equip.id ? (
                          <input
                            type="number"
                            autoFocus
                            defaultValue={item.checkQty ?? ''}
                            onBlur={(e) => {
                              handleUpdateQty(item.equip.id, parseInt(e.target.value) || 0)
                              setEditingId(null)
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                handleUpdateQty(item.equip.id, parseInt((e.target as HTMLInputElement).value) || 0)
                                setEditingId(null)
                              }
                            }}
                            className="h-7 w-20 rounded-md border border-[#1A56DB] px-2 text-center text-sm outline-none"
                          />
                        ) : (
                          <button
                            onClick={() => setEditingId(item.equip.id)}
                            className={cn(
                              'h-7 w-20 rounded-md border px-2 text-sm',
                              item.checkQty !== null
                                ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB]'
                                : 'border-[#D1D5DB] text-[#6B7280] hover:border-[#1A56DB]'
                            )}
                          >
                            {item.checkQty !== null ? item.checkQty : '录入'}
                          </button>
                        )}
                      </td>
                      <td className="px-3 py-2 text-center">{getDiffBadge(diff)}</td>
                      <td className="px-3 py-2">
                        <input
                          type="text"
                          defaultValue={item.remark}
                          onChange={e => handleUpdateRemark(item.equip.id, e.target.value)}
                          placeholder="备注"
                          className="h-7 w-24 rounded-md border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]"
                        />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={() => { setItems([]); onClose() }} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={() => handleSave(true)} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">暂存</button>
          <button onClick={() => handleSave(false)} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">提交盘点结果</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('planned')
  const [tasks, setTasks] = useState<InventoryTask[]>(initialTasks)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showResultModal, setShowResultModal] = useState(false)
  const [currentTask, setCurrentTask] = useState<InventoryTask | null>(null)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleSaveTask = (task: InventoryTask) => { setTasks(prev => [task, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该盘点任务？')) setTasks(prev => prev.filter(d => d.id !== id)) }
  const handleStart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleRestart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleSaveResult = (task: InventoryTask) => { setTasks(prev => prev.map(t => t.id === task.id ? task : t)) }

  const filteredData = tasks.filter((row) => {
    if (activeTab === 'planned') return row.status === 'planned'
    if (activeTab === 'ongoing') return row.status === 'ongoing'
    if (activeTab === 'completed') return row.status === 'completed'
    return true
  })

  const tabs = [
    { key: 'planned', label: '计划中', count: tasks.filter(t => t.status === 'planned').length },
    { key: 'ongoing', label: '进行中', count: tasks.filter(t => t.status === 'ongoing').length },
    { key: 'completed', label: '已完成', count: tasks.filter(t => t.status === 'completed').length },
  ]

  const filterFields = [
    { key: 'planNo', label: '盘点计划编号', type: 'input' as const, placeholder: '请输入盘点计划编号' },
    { key: 'name', label: '计划名称', type: 'input' as const, placeholder: '请输入计划名称' },
    { key: 'cycle', label: '盘点周期', type: 'select' as const, options: [
      { label: '期初盘点', value: '期初盘点' },
      { label: '存货盘点', value: '存货盘点' },
      { label: '期末盘点', value: '期末盘点' },
    ]},
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '计划中', value: 'planned' },
      { label: '进行中', value: 'ongoing' },
      { label: '已完成', value: 'completed' },
    ]},
    { key: 'assignee', label: '负责人', type: 'input' as const, placeholder: '请输入负责人' },
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备盘点</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
        >
          <Plus size={14} /> 新建盘点计划
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Inventory table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划编号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点仓库</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点周期</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">负责人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点差异</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-48 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#1F2937]">{row.name}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.warehouse}</td>
                  <td className="px-4 py-3"><CycleBadge cycle={row.cycle} /></td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.startDate} ~ {row.endDate}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.assignee}</td>
                  <td className="px-4 py-3 text-[13px]">
                    <span className={cn(row.status === 'completed' ? 'text-[#059669]' : 'text-[#9CA3AF]')}>
                      {row.status === 'completed' ? calcVarianceSummary(row.items) : '待盘点'}
                    </span>
                  </td>
                  <td className="px-4 py-3"><InventoryStatus status={row.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      {row.status === 'planned' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n周期：${row.cycle}\n时间：${row.startDate} ~ ${row.endDate}\n负责人：${row.assignee}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><Edit size={12} /> 修改</button>
                          <button onClick={() => handleDelete(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={12} /> 删除</button>
                          <button onClick={() => handleStart(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white transition hover:bg-[#059669]"><Play size={12} /> 开始盘点</button>
                        </>
                      )}
                      {row.status === 'ongoing' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n已盘点：${row.items.length}种装备`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button onClick={() => { setCurrentTask(row); setShowResultModal(true) }} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white transition hover:bg-[#153E7E]"><ClipboardCheck size={12} /> 录入结果</button>
                          <button onClick={() => handleRestart(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><RotateCcw size={12} /> 重新盘点</button>
                        </>
                      )}
                      {row.status === 'completed' && (
                        <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n差异：${calcVarianceSummary(row.items)}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 创建盘点任务弹窗 */}
      <CreateInventoryModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveTask} />

      {/* 录入结果弹窗 */}
      <EnterResultModal open={showResultModal} onClose={() => setShowResultModal(false)} task={currentTask} onSave={handleSaveResult} />
    </div>
  )
}
