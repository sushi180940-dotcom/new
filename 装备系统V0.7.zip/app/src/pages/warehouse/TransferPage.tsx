import { useState } from 'react'
import { Zap, ClipboardCheck, Eye, ArrowRight, Trash2, X, Plus, Package } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
}

interface SelectedEquipment {
  equip: StockEquipment
  qty: number
}

interface TransferRecord {
  id: string
  transferType: 'quick' | 'normal'
  description: string
  fromWarehouse: string
  toWarehouse: string
  fromUnit: string
  toUnit: string
  materialList: string
  qty: number
  applicant: string
  time: string
  status: 'draft' | 'submitted' | 'approving' | 'pending-outbound' | 'outbound' | 'received' | 'completed'
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '手持终端 XT-2000', category: '通信装备', model: 'XT-2000/黑色', productionDate: '2024-01-15', expiryDate: '2029-01-14', remaining: 50, unit: '台', price: 3200, code: '0101P00100', supplier: '华为技术有限公司' },
  { id: '2', name: '执法记录仪 DSJ-A7', category: '执法设备', model: 'DSJ-A7/64G', productionDate: '2024-02-20', expiryDate: '2029-02-19', remaining: 30, unit: '台', price: 1800, code: '0101P00200', supplier: '海康威视数字技术股份有限公司' },
  { id: '3', name: '对讲机 PD780G', category: '通信装备', model: 'PD780G/U段', productionDate: '2024-01-20', expiryDate: '2029-01-19', remaining: 100, unit: '台', price: 1200, code: '0101P00500', supplier: '烽火通信科技股份有限公司' },
  { id: '4', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级', productionDate: '2023-11-10', expiryDate: '2033-11-09', remaining: 20, unit: '件', price: 2800, code: '0101P00300', supplier: '华为技术有限公司' },
  { id: '5', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', productionDate: '2023-12-05', expiryDate: '2033-12-04', remaining: 40, unit: '顶', price: 1500, code: '0101P00400', supplier: '中兴通讯股份有限公司' },
  { id: '6', name: '应急照明灯 YD-100', category: '照明设备', model: 'YD-100/LED', productionDate: '2024-01-25', expiryDate: '2029-01-24', remaining: 60, unit: '台', price: 680, code: '0101P00600', supplier: '海康威视数字技术股份有限公司' },
  { id: '7', name: '防弹盾牌 FDP-3S', category: '防护装备', model: 'FDP-3S/三级', productionDate: '2024-03-01', expiryDate: '2034-02-29', remaining: 15, unit: '面', price: 2200, code: '0101P00700', supplier: '华为技术有限公司' },
  { id: '8', name: '催泪喷射器 CL-200', category: '警械装备', model: 'CL-200/200ml', productionDate: '2024-01-10', expiryDate: '2029-01-09', remaining: 100, unit: '支', price: 150, code: '0101P00800', supplier: '大华技术股份有限公司' },
]

/* ═══════════════════════════════════════════
   Mock 数据：调拨记录
   ═══════════════════════════════════════════ */

const initialTransferData: TransferRecord[] = [
  { id: 'DB20260603001', transferType: 'normal', description: '夏季装备补充调拨', fromWarehouse: '市局装备仓库A区', toWarehouse: 'ZZZ分局装备室', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '防弹背心x30, 防刺服x20', qty: 50, applicant: '张警官', time: '2026-06-03 08:30', status: 'pending-outbound' },
  { id: 'DB20260603002', transferType: 'normal', description: '新警入职装备配发', fromWarehouse: '市局装备仓库B区', toWarehouse: 'ZZZ分局器材库', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '手铐x100, 警棍x20', qty: 120, applicant: '李管理员', time: '2026-06-02 14:00', status: 'approving' },
  { id: 'DB20260603003', transferType: 'quick', description: '紧急处突装备支援', fromWarehouse: '市局装备仓库A区', toWarehouse: 'ZZZ分局仓库', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '防弹背心x20, 头盔x20', qty: 40, applicant: '赵警官', time: '2026-06-01 22:15', status: 'received' },
  { id: 'DB20260603004', transferType: 'normal', description: '常规季度调拨', fromWarehouse: '市局装备仓库B区', toWarehouse: '栖霞分局器材室', fromUnit: '市局装备处', toUnit: '栖霞分局', materialList: '执法记录仪x40, 对讲机x40', qty: 80, applicant: '刘管理员', time: '2026-06-01 16:30', status: 'outbound' },
  { id: 'DB20260603005', transferType: 'normal', description: '防暴装备补充', fromWarehouse: '市局装备仓库A区', toWarehouse: 'ZZZ分局装备库', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '防刺服x40, 防割手套x20', qty: 60, applicant: '陈警官', time: '2026-05-31 09:00', status: 'submitted' },
  { id: 'DB20260603006', transferType: 'quick', description: '突发事件快速支援', fromWarehouse: '市局装备仓库B区', toWarehouse: 'ZZZ分局装备室', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '防弹盾牌x15, 防暴服x15', qty: 30, applicant: '周警官', time: '2026-05-29 20:00', status: 'received' },
  { id: 'DB20260603007', transferType: 'normal', description: '年度装备轮换调拨', fromWarehouse: '市局装备仓库C区', toWarehouse: 'ZZZ分局仓库', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '应急照明灯x30, 强光手电x50', qty: 80, applicant: '杨警官', time: '2026-05-28 10:00', status: 'completed' },
  { id: 'DB20260603008', transferType: 'quick', description: '跨区紧急增援', fromWarehouse: '市局装备仓库A区', toWarehouse: 'ZZZ分局装备库', fromUnit: '市局装备处', toUnit: 'ZZZ分局', materialList: '防弹背心x10, 战术头盔x10', qty: 20, applicant: '吴警官', time: '2026-05-27 18:30', status: 'completed' },
]

/* ═══════════════════════════════════════════
   Status badge
   ═══════════════════════════════════════════ */

function TransferStatus({ status }: { status: string }) {
  switch (status) {
    case 'draft': return <Badge variant="default">草稿</Badge>
    case 'submitted': return <Badge variant="info" dot>已提交</Badge>
    case 'approving': return <Badge variant="warning" dot>审批中</Badge>
    case 'pending-outbound': return <Badge variant="primary" dot>待出库</Badge>
    case 'outbound': return <Badge variant="primary" dot>已出库</Badge>
    case 'received': return <Badge variant="success" dot>已接收</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function TransferTypeBadge({ type }: { type: string }) {
  switch (type) {
    case 'quick': return <Badge variant="danger">快速调拨</Badge>
    case 'normal': return <Badge variant="primary">审批调拨</Badge>
    default: return <Badge variant="default">{type}</Badge>
  }
}

/* ═══════════════════════════════════════════
   库存装备选择弹窗（与报修管理一致）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedEquipment[]) => void
}) {
  const [selected, setSelected] = useState<SelectedEquipment[]>([])
  const [searchName, setSearchName] = useState('')

  if (!open) return null

  const filteredStock = stockEquipments.filter(e =>
    searchName ? e.name.includes(searchName) || e.code.includes(searchName) : true
  )

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, qty: 1 }]
    })
  }

  const updateQty = (id: string, qty: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, qty: Math.max(1, Math.min(qty, s.equip.remaining)) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 筛选 */}
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部位置</option>
            <option>省厅仓库1层</option>
            <option>省厅仓库2层</option>
            <option>省厅仓库3层</option>
          </select>
          <input
            type="text"
            value={searchName}
            onChange={e => setSearchName(e.target.value)}
            placeholder="物资名称..."
            className="h-8 w-40 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
          />
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部类别</option>
            <option>通信装备</option>
            <option>执法设备</option>
            <option>防护装备</option>
            <option>照明设备</option>
            <option>警械装备</option>
          </select>
          <button className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">查询</button>
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：库存装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input
                        type="checkbox"
                        checked={isChecked(equip.id)}
                        onChange={() => toggleEquip(equip)}
                        className="h-4 w-4 rounded border-[#D1D5DB]"
                      />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.productionDate}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.expiryDate}</td>
                    <td className="px-3 py-2 text-right font-medium text-[#059669]">{equip.remaining}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.unit}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{equip.price.toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{equip.code}</td>
                    <td className="px-3 py-2 text-[11px] text-[#374151]">{equip.supplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">
              已选择装备 ({selected.length})
            </div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.equip.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span>
                  <button onClick={() => removeSelected(s.equip.id)} className="text-xs text-[#EF4444] hover:underline">删除</button>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-[#6B7280]">
                  <span>类别: {s.equip.category}</span>
                  <span>规格: {s.equip.model}</span>
                  <span>编码: {s.equip.code}</span>
                  <span>余量: {s.equip.remaining}</span>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-[#6B7280]">数量:</span>
                  <input
                    type="number"
                    min={1}
                    max={s.equip.remaining}
                    value={s.qty}
                    onChange={(e) => updateQty(s.equip.id, parseInt(e.target.value) || 1)}
                    className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-center text-sm outline-none focus:border-[#1A56DB]"
                  />
                  <span className="text-[11px] text-[#6B7280]">单价: &yen;{s.equip.price.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button
            onClick={() => { onConfirm(selected); setSelected([]); setSearchName('') }}
            className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]"
          >
            确认添加
          </button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   发起调拨弹窗（参考截图）
   ═══════════════════════════════════════════ */

function CreateTransferModal({
  open,
  onClose,
  onSave,
  transferType,
}: {
  open: boolean
  onClose: () => void
  onSave: (record: TransferRecord) => void
  transferType: 'quick' | 'normal'
}) {
  const [showEquipSelect, setShowEquipSelect] = useState(false)
  const [selectedEquipments, setSelectedEquipments] = useState<SelectedEquipment[]>([])
  const [description, setDescription] = useState('')
  const [fromWarehouse, setFromWarehouse] = useState('')
  const [toWarehouse, setToWarehouse] = useState('')
  const [fromUnit, setFromUnit] = useState('')
  const [toUnit, setToUnit] = useState('')

  if (!open) return null

  const transferNo = `DB${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const materialList = selectedEquipments.map(s => `${s.equip.name} x${s.qty}`).join(', ')
  const totalQty = selectedEquipments.reduce((sum, s) => sum + s.qty, 0)

  const handleConfirmEquip = (selected: SelectedEquipment[]) => {
    setSelectedEquipments(selected)
    setShowEquipSelect(false)
  }

  const handleSave = (saveStatus: 'draft' | 'submitted') => {
    if (!description.trim()) { alert('请填写调拨性质说明'); return }
    if (!fromWarehouse) { alert('请选择调出仓库'); return }
    if (!toWarehouse) { alert('请选择调入仓库'); return }
    if (selectedEquipments.length === 0) { alert('请添加物资'); return }

    onSave({
      id: transferNo,
      transferType,
      description,
      fromWarehouse,
      toWarehouse,
      fromUnit: fromUnit || '自动带出',
      toUnit: toUnit || '自动带出',
      materialList,
      qty: totalQty,
      applicant: '张警官',
      time: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status: saveStatus === 'submitted' ? 'submitted' : 'draft',
    })
    // 重置
    setSelectedEquipments([])
    setDescription('')
    setFromWarehouse('')
    setToWarehouse('')
    setFromUnit('')
    setToUnit('')
    onClose()
  }

  const warehouseOptions = ['请选择', '市局装备仓库A区', '市局装备仓库B区', '市局装备仓库C区', 'ZZZ分局装备室', 'ZZZ分局器材库', 'ZZZ分局仓库']

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[900px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">
              {transferType === 'quick' ? '快速调拨' : '审批调拨'}
            </h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]">
                <div className="h-4 w-1 rounded-full bg-[#059669]" />
                基本信息
              </div>
              {/* 调拨性质说明 */}
              <div className="mb-4">
                <label className="mb-1 block text-xs text-[#6B7280]">调拨性质说明</label>
                <input
                  type="text"
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="请输入调拨性质说明..."
                  className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
                />
              </div>
              {/* 调出仓库 / 调入仓库 */}
              <div className="mb-4 grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">调出仓库 <span className="text-[#EF4444]">*</span></label>
                  <select
                    value={fromWarehouse}
                    onChange={e => setFromWarehouse(e.target.value)}
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
                  >
                    {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">调入仓库 <span className="text-[#EF4444]">*</span></label>
                  <select
                    value={toWarehouse}
                    onChange={e => setToWarehouse(e.target.value)}
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"
                  >
                    {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
                  </select>
                </div>
              </div>
              {/* 发物单位 / 收物单位 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">发物单位</label>
                  <input
                    type="text"
                    value={fromUnit}
                    onChange={e => setFromUnit(e.target.value)}
                    placeholder="自动带出"
                    className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280] outline-none transition focus:border-[#1A56DB]"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">收物单位</label>
                  <input
                    type="text"
                    value={toUnit}
                    onChange={e => setToUnit(e.target.value)}
                    placeholder="自动带出"
                    className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280] outline-none transition focus:border-[#1A56DB]"
                  />
                </div>
              </div>
            </div>

            {/* 物资明细 */}
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#D97706]">
                  <div className="h-4 w-1 rounded-full bg-[#D97706]" />
                  物资明细 <span className="text-[#EF4444]">*</span>
                  <span className="text-xs font-normal text-[#6B7280]">({selectedEquipments.length} 种)</span>
                </div>
                <button
                  onClick={() => setShowEquipSelect(true)}
                  className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
                >
                  <Plus size={14} /> 添加物资
                </button>
              </div>

              {selectedEquipments.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-10 text-[#9CA3AF]">
                  <Package size={36} className="mb-2 opacity-40" />
                  <p className="text-sm">请点击「添加物资」按钮添加装备</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">数量</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余数量</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">总价</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                        <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedEquipments.map((s) => (
                        <tr key={s.equip.id} className="border-b border-[#F3F4F6]">
                          <td className="px-3 py-2 font-medium text-[#1F2937]">{s.equip.name}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.category}</td>
                          <td className="px-3 py-2 text-[12px] text-[#6B7280]">{s.equip.model}</td>
                          <td className="px-3 py-2 text-right font-medium text-[#1A56DB]">{s.qty}</td>
                          <td className="px-3 py-2 text-right text-[#059669]">{s.equip.remaining}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.unit}</td>
                          <td className="px-3 py-2 text-right text-[#374151]">&yen;{s.equip.price.toLocaleString()}</td>
                          <td className="px-3 py-2 text-right font-medium text-[#1A56DB]">&yen;{(s.qty * s.equip.price).toLocaleString()}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{s.equip.code}</td>
                          <td className="px-3 py-2 text-[11px] text-[#374151]">{s.equip.supplier}</td>
                          <td className="px-3 py-2 text-center">
                            <button
                              onClick={() => setSelectedEquipments(prev => prev.filter(p => p.equip.id !== s.equip.id))}
                              className="text-xs text-[#EF4444] hover:underline"
                            >
                              删除
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={() => handleSave('draft')} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">保存草稿</button>
            <button onClick={() => handleSave('submitted')} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">提交申请</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function TransferPage() {
  const [activeTab, setActiveTab] = useState('ongoing')
  const [data, setData] = useState<TransferRecord[]>(initialTransferData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [createType, setCreateType] = useState<'quick' | 'normal'>('normal')

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleSaveTransfer = (record: TransferRecord) => { setData(prev => [record, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该调拨单？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filteredData = data.filter((row) => {
    if (activeTab === 'ongoing') return ['draft', 'submitted', 'approving', 'pending-outbound', 'outbound', 'received'].includes(row.status)
    if (activeTab === 'completed') return row.status === 'completed'
    if (activeTab === 'quick-records') return row.transferType === 'quick'
    return true
  })

  const openCreate = (type: 'quick' | 'normal') => {
    setCreateType(type)
    setShowCreateModal(true)
  }

  /* ─── Quick action entries ─── */
  const actionEntries = [
    { key: 'quick', label: '快速调拨', icon: <Zap size={22} />, color: '#DC2626', bg: '#FEE2E2', desc: '紧急场景直接调拨' },
    { key: 'normal', label: '审批调拨', icon: <ClipboardCheck size={22} />, color: '#1A56DB', bg: '#E8F0FE', desc: '常规审批流程调拨' },
  ]

  const tabs = [
    { key: 'ongoing', label: '进行中', count: data.filter(d => ['draft', 'submitted', 'approving', 'pending-outbound', 'outbound', 'received'].includes(d.status)).length },
    { key: 'completed', label: '已完成', count: data.filter(d => d.status === 'completed').length },
    { key: 'quick-records', label: '快速调拨记录', count: data.filter(d => d.transferType === 'quick').length },
  ]

  const filterFields = [
    { key: 'transferNo', label: '调拨单号', type: 'input' as const, placeholder: '请输入调拨单号' },
    { key: 'from', label: '调出仓库', type: 'input' as const, placeholder: '请输入调出仓库' },
    { key: 'to', label: '调入仓库', type: 'input' as const, placeholder: '请输入调入仓库' },
    { key: 'type', label: '调拨类型', type: 'select' as const, options: [
      { label: '快速调拨', value: 'quick' },
      { label: '审批调拨', value: 'normal' },
    ]},
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '草稿', value: 'draft' },
      { label: '已提交', value: 'submitted' },
      { label: '审批中', value: 'approving' },
      { label: '待出库', value: 'pending-outbound' },
      { label: '已出库', value: 'outbound' },
      { label: '已接收', value: 'received' },
      { label: '已完成', value: 'completed' },
    ]},
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">调拨管理</h1>
      </div>

      {/* Quick action entries */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2">
        {actionEntries.map((entry) => (
          <button
            key={entry.key}
            onClick={() => openCreate(entry.key as 'quick' | 'normal')}
            className="group flex items-center gap-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition hover:shadow-md"
          >
            <div
              className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full"
              style={{ backgroundColor: entry.bg }}
            >
              <span style={{ color: entry.color }}>{entry.icon}</span>
            </div>
            <div className="text-left">
              <p className="text-base font-semibold text-[#1F2937]">{entry.label}</p>
              <p className="text-xs text-[#6B7280]">{entry.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Transfer table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调拨单号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调拨类型</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调出仓库</th>
                <th className="w-8 px-2 py-3"></th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调入仓库</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资清单</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">数量</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={11} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3"><TransferTypeBadge type={row.transferType} /></td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.fromWarehouse}</td>
                  <td className="px-2 py-3 text-center"><ArrowRight size={14} className="text-[#D1D5DB]" /></td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.toWarehouse}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[200px] truncate" title={row.materialList}>{row.materialList}</td>
                  <td className="px-4 py-3 text-right text-[13px] font-medium text-[#1A56DB]">{row.qty}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.applicant}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.time}</td>
                  <td className="px-4 py-3"><TransferStatus status={row.status} /></td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => alert(`调拨单详情：${row.id}\n\n调拨类型：${row.transferType === 'quick' ? '快速调拨' : '审批调拨'}\n调出仓库：${row.fromWarehouse}\n调入仓库：${row.toWarehouse}\n物资清单：${row.materialList}\n数量：${row.qty}\n申请人：${row.applicant}\n申请时间：${row.time}\n状态：${row.status}`)}
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]"
                        title="详情"
                      >
                        <Eye size={14} />
                      </button>
                      <button
                        onClick={() => handleDelete(row.id)}
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] transition hover:bg-[#FEE2E2]"
                        title="删除"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 发起调拨弹窗 */}
      <CreateTransferModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveTransfer} transferType={createType} />
    </div>
  )
}