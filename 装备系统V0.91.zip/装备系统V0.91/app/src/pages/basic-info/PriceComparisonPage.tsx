import { useState, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import {
  ArrowLeft, Search, BarChart3, Calendar, Tag,
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle2, Filter,
} from 'lucide-react'
import Badge from '@/components/Badge'

/* ─── Types ─── */
interface PriceRecord {
  id: string
  date: string
  supplierId: string
  supplierName: string
  supplierRating: number
  equipId: string
  equipName: string
  spec: string
  category: string
  tags: string[]
  unitPrice: number
  quantity: number
  totalPrice: number
  orderNo: string
  unit: string
  ownerUnit: string
  isCurrentUnit: boolean
  deliveryDays: number
}

/* ─── Mock Data ─── */
const priceRecords: PriceRecord[] = [
  { id: 'r001', date: '2025-01-15', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 28000, quantity: 5, totalPrice: 140000, orderNo: 'HT-2026-001', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 15 },
  { id: 'r002', date: '2025-03-20', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 26500, quantity: 8, totalPrice: 212000, orderNo: 'HT-2026-002', unit: '套', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 12 },
  { id: 'r003', date: '2025-07-08', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 27000, quantity: 3, totalPrice: 81000, orderNo: 'HT-2026-003', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r004', date: '2025-10-15', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 25800, quantity: 6, totalPrice: 154800, orderNo: 'HT-2026-004', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  { id: 'r005', date: '2026-02-10', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 26200, quantity: 4, totalPrice: 104800, orderNo: 'HT-2026-005', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r006', date: '2025-05-10', supplierId: '2', supplierName: '某警用装备有限公司', supplierRating: 4.0, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14500, quantity: 15, totalPrice: 217500, orderNo: 'HT-2026-006', unit: '台', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 20 },
  { id: 'r007', date: '2025-09-01', supplierId: '2', supplierName: '某警用装备有限公司', supplierRating: 4.0, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 13800, quantity: 10, totalPrice: 138000, orderNo: 'HT-2026-007', unit: '台', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 18 },
  { id: 'r008', date: '2025-08-20', supplierId: '3', supplierName: '某防护用品厂', supplierRating: 3.8, equipId: 'e2103001', equipName: '血痕发现仪', spec: '血痕发现', category: '发现提取', tags: ['勘查', '光源', 'LED'], unitPrice: 18500, quantity: 6, totalPrice: 111000, orderNo: 'HT-2026-008', unit: '台', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 30 },
  { id: 'r009', date: '2026-05-15', supplierId: '3', supplierName: '某防护用品厂', supplierRating: 3.8, equipId: 'e2103001', equipName: '血痕发现仪', spec: '血痕发现', category: '发现提取', tags: ['勘查', '光源', 'LED'], unitPrice: 17200, quantity: 8, totalPrice: 137600, orderNo: 'HT-2026-009', unit: '台', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 25 },
  { id: 'r010', date: '2025-02-10', supplierId: '4', supplierName: '某通信设备公司', supplierRating: 4.2, equipId: 'e2301001', equipName: '智能物证保全管理系统', spec: '智能版/RFID追踪', category: '管理系统', tags: ['RFID', '智能', '物证管理'], unitPrice: 45000, quantity: 2, totalPrice: 90000, orderNo: 'HT-2026-010', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 7 },
  { id: 'r011', date: '2025-06-15', supplierId: '4', supplierName: '某通信设备公司', supplierRating: 4.2, equipId: 'e2301001', equipName: '智能物证保全管理系统', spec: '智能版/RFID追踪', category: '管理系统', tags: ['RFID', '智能', '物证管理'], unitPrice: 42000, quantity: 3, totalPrice: 126000, orderNo: 'HT-2026-011', unit: '套', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 5 },
  { id: 'r012', date: '2026-03-08', supplierId: '4', supplierName: '某通信设备公司', supplierRating: 4.2, equipId: 'e2301001', equipName: '智能物证保全管理系统', spec: '智能版/RFID追踪', category: '管理系统', tags: ['RFID', '智能', '物证管理'], unitPrice: 43500, quantity: 2, totalPrice: 87000, orderNo: 'HT-2026-012', unit: '套', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 10 },
  { id: 'r013', date: '2025-04-20', supplierId: '4', supplierName: '某通信设备公司', supplierRating: 4.2, equipId: 'e2301001', equipName: '智能物证保全管理系统', spec: '智能版/RFID追踪', category: '管理系统', tags: ['RFID', '智能', '物证管理'], unitPrice: 41000, quantity: 4, totalPrice: 164000, orderNo: 'HT-2026-013', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r014', date: '2025-04-22', supplierId: '5', supplierName: 'FF智能装备科技', supplierRating: 4.6, equipId: 'e2201001', equipName: '气味鉴别犬', spec: '气味鉴别型', category: '警犬', tags: [], unitPrice: 8500, quantity: 5, totalPrice: 42500, orderNo: 'HT-2026-014', unit: '头', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 45 },
  { id: 'r015', date: '2025-08-15', supplierId: '5', supplierName: 'FF智能装备科技', supplierRating: 4.6, equipId: 'e2201001', equipName: '气味鉴别犬', spec: '气味鉴别型', category: '警犬', tags: [], unitPrice: 9200, quantity: 3, totalPrice: 27600, orderNo: 'HT-2026-015', unit: '头', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 40 },
  { id: 'r016', date: '2026-01-10', supplierId: '5', supplierName: 'FF智能装备科技', supplierRating: 4.6, equipId: 'e2201001', equipName: '气味鉴别犬', spec: '气味鉴别型', category: '警犬', tags: [], unitPrice: 8800, quantity: 6, totalPrice: 52800, orderNo: 'HT-2026-016', unit: '头', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 50 },
  { id: 'r017', date: '2026-05-20', supplierId: '5', supplierName: 'FF智能装备科技', supplierRating: 4.6, equipId: 'e2201001', equipName: '气味鉴别犬', spec: '气味鉴别型', category: '警犬', tags: [], unitPrice: 9000, quantity: 4, totalPrice: 36000, orderNo: 'HT-2026-017', unit: '头', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 35 },
  { id: 'r018', date: '2025-06-10', supplierId: '6', supplierName: 'CC检测仪器公司', supplierRating: 4.3, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 15200, quantity: 12, totalPrice: 182400, orderNo: 'HT-2026-018', unit: '台', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 20 },
  { id: 'r019', date: '2025-10-25', supplierId: '6', supplierName: 'CC检测仪器公司', supplierRating: 4.3, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14800, quantity: 8, totalPrice: 118400, orderNo: 'HT-2026-019', unit: '台', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 25 },
  { id: 'r020', date: '2026-03-05', supplierId: '6', supplierName: 'CC检测仪器公司', supplierRating: 4.3, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14300, quantity: 15, totalPrice: 214500, orderNo: 'HT-2026-020', unit: '台', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 30 },
  { id: 'r021', date: '2025-07-22', supplierId: '6', supplierName: 'CC检测仪器公司', supplierRating: 4.3, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14600, quantity: 10, totalPrice: 146000, orderNo: 'HT-2026-021', unit: '台', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 22 },
  { id: 'r022', date: '2026-04-15', supplierId: '6', supplierName: 'CC检测仪器公司', supplierRating: 4.3, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14000, quantity: 20, totalPrice: 280000, orderNo: 'HT-2026-022', unit: '台', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 18 },
  // 防弹衣
  { id: 'r023', date: '2025-01-20', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3200, quantity: 100, totalPrice: 320000, orderNo: 'HT-2026-023', unit: '件', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 15 },
  { id: 'r024', date: '2025-04-18', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3100, quantity: 80, totalPrice: 248000, orderNo: 'HT-2026-024', unit: '件', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 12 },
  { id: 'r025', date: '2025-08-12', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3050, quantity: 120, totalPrice: 366000, orderNo: 'HT-2026-025', unit: '件', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r026', date: '2025-11-05', supplierId: '8', supplierName: 'DD警用防护装备厂', supplierRating: 4.4, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 2800, quantity: 60, totalPrice: 168000, orderNo: 'HT-2026-026', unit: '件', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 20 },
  { id: 'r027', date: '2026-02-28', supplierId: '8', supplierName: 'DD警用防护装备厂', supplierRating: 4.4, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 2750, quantity: 150, totalPrice: 412500, orderNo: 'HT-2026-027', unit: '件', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 18 },
  { id: 'r028', date: '2026-05-08', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3150, quantity: 50, totalPrice: 157500, orderNo: 'HT-2026-028', unit: '件', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  // 防弹盾牌
  { id: 'r029', date: '2025-02-14', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1850, quantity: 40, totalPrice: 74000, orderNo: 'HT-2026-029', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 15 },
  { id: 'r030', date: '2025-06-22', supplierId: '8', supplierName: 'DD警用防护装备厂', supplierRating: 4.4, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1600, quantity: 30, totalPrice: 48000, orderNo: 'HT-2026-030', unit: '面', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 22 },
  { id: 'r031', date: '2025-09-10', supplierId: '9', supplierName: 'EE安防装备制造', supplierRating: 4.1, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1520, quantity: 25, totalPrice: 38000, orderNo: 'HT-2026-031', unit: '面', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 28 },
  { id: 'r032', date: '2025-12-18', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1780, quantity: 50, totalPrice: 89000, orderNo: 'HT-2026-032', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r033', date: '2026-03-25', supplierId: '8', supplierName: 'DD警用防护装备厂', supplierRating: 4.4, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1550, quantity: 35, totalPrice: 54250, orderNo: 'HT-2026-033', unit: '面', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 18 },
  { id: 'r034', date: '2026-05-30', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001002', equipName: '防弹盾牌 FDP-4H', spec: '四级/手持式/钢制/观察窗', category: '防护装备', tags: ['四级防弹', '手持式', '钢制', '观察窗'], unitPrice: 1820, quantity: 20, totalPrice: 36400, orderNo: 'HT-2026-034', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 12 },
  // 防爆头盔
  { id: 'r035', date: '2025-01-08', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 1200, quantity: 200, totalPrice: 240000, orderNo: 'HT-2026-035', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r036', date: '2025-05-16', supplierId: '9', supplierName: 'EE安防装备制造', supplierRating: 4.1, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 980, quantity: 150, totalPrice: 147000, orderNo: 'HT-2026-036', unit: '顶', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 18 },
  { id: 'r037', date: '2025-08-28', supplierId: '10', supplierName: 'FF战术装备科技', supplierRating: 4.5, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 1350, quantity: 80, totalPrice: 108000, orderNo: 'HT-2026-037', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  { id: 'r038', date: '2025-11-12', supplierId: '9', supplierName: 'EE安防装备制造', supplierRating: 4.1, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 950, quantity: 100, totalPrice: 95000, orderNo: 'HT-2026-038', unit: '顶', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 25 },
  { id: 'r039', date: '2026-02-05', supplierId: '10', supplierName: 'FF战术装备科技', supplierRating: 4.5, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 1280, quantity: 120, totalPrice: 153600, orderNo: 'HT-2026-039', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r040', date: '2026-04-20', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 1180, quantity: 60, totalPrice: 70800, orderNo: 'HT-2026-040', unit: '顶', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 15 },
  { id: 'r041', date: '2026-05-15', supplierId: '10', supplierName: 'FF战术装备科技', supplierRating: 4.5, equipId: 'e3001003', equipName: '防爆头盔 FKB-M2', spec: '二级/凯夫拉/导轨式/含面罩', category: '防护装备', tags: ['二级防弹', '凯夫拉', '导轨式', '含面罩'], unitPrice: 1320, quantity: 90, totalPrice: 118800, orderNo: 'HT-2026-041', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
]

const INSIGHT_RULES = [
  { id: 1, title: '本单位价格趋势', desc: '对比本单位历史采购价格变化趋势，识别涨价或降价', type: 'trend' },
  { id: 2, title: '其他单位价格参考', desc: '参考其他单位同类装备采购价格，作为议价依据', type: 'trend' },
  { id: 3, title: '全部均价对比', desc: '本单位采购价与全部单位平均价对比，判断价格合理性', type: 'compare' },
  { id: 4, title: '供应商集中度分析', desc: '分析供应商集中度，避免过度依赖单一供应商', type: 'risk' },
  { id: 5, title: '交货周期对比', desc: '不同供应商交货周期对比，评估交付能力', type: 'compare' },
  { id: 6, title: '最高单价预警', desc: '当采购价高于历史最高价时自动预警提醒', type: 'risk' },
]

/* ─── Main Component ─── */
export default function PriceComparisonPage() {
  const [searchParams] = useSearchParams()
  const urlEquipName = searchParams.get('equipName') || ''
  const urlEquipSpec = searchParams.get('spec') || ''
  const urlEquipTags = searchParams.get('tags') || ''

  const [equipNameKeyword, setEquipNameKeyword] = useState(urlEquipName)
  const [specKeywords, setSpecKeywords] = useState<string[]>(urlEquipSpec ? [urlEquipSpec] : [])
  const [selectedTags, setSelectedTags] = useState<string[]>(urlEquipTags ? urlEquipTags.split(',') : [])
  const [tagMatchMode, setTagMatchMode] = useState<'and' | 'or'>('and')
  const [dateRange, setDateRange] = useState<[string, string]>(['2025-01-01', '2026-12-31'])
  const [unitFilter, setUnitFilter] = useState<'all' | 'current' | 'other'>('all')
  const [pageSize, setPageSize] = useState(10)
  const [currentPage, setCurrentPage] = useState(1)
  const [showInsights, setShowInsights] = useState(true)

  const filteredRecords = useMemo(() => {
    let result = [...priceRecords]
    if (equipNameKeyword.trim()) {
      const kw = equipNameKeyword.toLowerCase()
      result = result.filter(r => r.equipName.toLowerCase().includes(kw))
    }
    if (specKeywords.length > 0) {
      result = result.filter(r => specKeywords.some(kw => r.spec.toLowerCase().includes(kw.toLowerCase())))
    }
    if (selectedTags.length > 0) {
      result = result.filter(r => tagMatchMode === 'or'
        ? selectedTags.some(tag => r.tags.includes(tag))
        : selectedTags.every(tag => r.tags.includes(tag))
      )
    }
    if (dateRange[0]) result = result.filter(r => r.date >= dateRange[0])
    if (dateRange[1]) result = result.filter(r => r.date <= dateRange[1])
    if (unitFilter === 'current') result = result.filter(r => r.isCurrentUnit)
    if (unitFilter === 'other') result = result.filter(r => !r.isCurrentUnit)
    return result
  }, [equipNameKeyword, specKeywords, selectedTags, tagMatchMode, dateRange, unitFilter])

  const pagedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return filteredRecords.slice(start, start + pageSize)
  }, [filteredRecords, currentPage, pageSize])

  const totalPages = Math.ceil(filteredRecords.length / pageSize)

  const stats = useMemo(() => {
    if (filteredRecords.length === 0) return null
    const prices = filteredRecords.map(r => r.unitPrice)
    const currentPrices = filteredRecords.filter(r => r.isCurrentUnit).map(r => r.unitPrice)
    const otherPrices = filteredRecords.filter(r => !r.isCurrentUnit).map(r => r.unitPrice)
    return {
      count: filteredRecords.length,
      avgPrice: Math.round(prices.reduce((a, b) => a + b, 0) / prices.length),
      minPrice: Math.min(...prices),
      maxPrice: Math.max(...prices),
      currentAvg: currentPrices.length ? Math.round(currentPrices.reduce((a, b) => a + b, 0) / currentPrices.length) : 0,
      otherAvg: otherPrices.length ? Math.round(otherPrices.reduce((a, b) => a + b, 0) / otherPrices.length) : 0,
    }
  }, [filteredRecords])

  const uniqueEquipNames = [...new Set(priceRecords.map(r => r.equipName))]
  const allTags = [...new Set(priceRecords.flatMap(r => r.tags))]

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => window.history.back()} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <ArrowLeft size={18} />
          </button>
          <h1 className="text-xl font-semibold text-[#1F2937]">历史比价</h1>
        </div>
      </div>

      {/* Equipment Info Cards */}
      {equipNameKeyword && stats && (
        <div className="grid grid-cols-4 gap-3">
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-3">
            <div className="text-xs text-[#6B7280]">匹配记录数</div>
            <div className="text-lg font-semibold text-[#1F2937]">{stats.count}条</div>
          </div>
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-3">
            <div className="text-xs text-[#6B7280]">全部均价</div>
            <div className="text-lg font-semibold text-[#1A56DB]">¥{stats.avgPrice.toLocaleString()}</div>
          </div>
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-3">
            <div className="text-xs text-[#6B7280]">本单位均价</div>
            <div className="text-lg font-semibold text-[#10B981]">¥{stats.currentAvg.toLocaleString()}</div>
          </div>
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-3">
            <div className="text-xs text-[#6B7280]">其他单位均价</div>
            <div className="text-lg font-semibold text-[#F59E0B]">¥{stats.otherAvg.toLocaleString()}</div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 space-y-3">
        {/* Name */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#374151] w-20">装备名称</span>
          <input value={equipNameKeyword} onChange={e => setEquipNameKeyword(e.target.value)} placeholder="搜索装备名称..." className="h-8 flex-1 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
          {equipNameKeyword && <button onClick={() => setEquipNameKeyword('')} className="text-xs text-[#6B7280]">清除</button>}
        </div>
        {/* Spec */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#374151] w-20">规格型号</span>
          <div className="flex flex-wrap gap-1 flex-1">
            {specKeywords.map((kw, i) => (
              <span key={i} className="inline-flex items-center gap-1 rounded-full bg-[#EFF6FF] px-2 py-0.5 text-xs text-[#1A56DB]">
                {kw} <button onClick={() => setSpecKeywords(specKeywords.filter((_, idx) => idx !== i))} className="text-[#6B7280] hover:text-[#EF4444]">x</button>
              </span>
            ))}
            <input onKeyDown={e => {
              if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                setSpecKeywords([...specKeywords, e.currentTarget.value.trim()])
                e.currentTarget.value = ''
              }
            }} placeholder="输入后回车添加..." className="h-7 min-w-[120px] rounded border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]" />
          </div>
        </div>
        {/* Tags */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#374151] w-20">标签</span>
          <div className="flex flex-wrap gap-1 flex-1">
            {allTags.map(tag => (
              <button key={tag} onClick={() => setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag])}
                className={`rounded-full px-2 py-0.5 text-xs transition ${selectedTags.includes(tag) ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]'}`}>
                {tag}
              </button>
            ))}
            {selectedTags.length > 0 && <button onClick={() => setSelectedTags([])} className="text-xs text-[#6B7280] ml-2">清除</button>}
          </div>
          <select value={tagMatchMode} onChange={e => setTagMatchMode(e.target.value as 'and' | 'or')} className="h-7 rounded border border-[#D1D5DB] px-2 text-xs">
            <option value="and">全部匹配</option>
            <option value="or">任一匹配</option>
          </select>
        </div>
        {/* Date & Unit */}
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-[#374151] w-20">日期范围</span>
          <input type="date" value={dateRange[0]} onChange={e => setDateRange([e.target.value, dateRange[1]])} className="h-8 rounded border border-[#D1D5DB] px-2 text-sm" />
          <span className="text-[#6B7280]">~</span>
          <input type="date" value={dateRange[1]} onChange={e => setDateRange([dateRange[0], e.target.value])} className="h-8 rounded border border-[#D1D5DB] px-2 text-sm" />
          <span className="text-sm font-medium text-[#374151] ml-4">单位</span>
          <select value={unitFilter} onChange={e => setUnitFilter(e.target.value as 'all' | 'current' | 'other')} className="h-8 rounded border border-[#D1D5DB] px-2 text-sm">
            <option value="all">全部单位</option>
            <option value="current">本单位</option>
            <option value="other">其他单位</option>
          </select>
        </div>
      </div>

      {/* Insights */}
      {showInsights && (
        <div className="rounded-lg border border-[#E5E7EB] bg-white p-4">
          <div className="mb-3 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-[#374151]">智能洞察</h3>
            <button onClick={() => setShowInsights(false)} className="text-xs text-[#6B7280]">收起</button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {INSIGHT_RULES.map(rule => (
              <div key={rule.id} className="flex items-start gap-2 rounded-md bg-[#F9FAFB] p-3">
                {rule.type === 'trend' && <TrendingUp size={16} className="mt-0.5 text-[#10B981] shrink-0" />}
                {rule.type === 'compare' && <CheckCircle2 size={16} className="mt-0.5 text-[#1A56DB] shrink-0" />}
                {rule.type === 'risk' && <AlertTriangle size={16} className="mt-0.5 text-[#F59E0B] shrink-0" />}
                <div>
                  <div className="text-sm font-medium text-[#374151]">{rule.title}</div>
                  <div className="text-xs text-[#6B7280]">{rule.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
          <div className="text-sm font-medium text-[#374151]">比价结果 <span className="text-[#6B7280]">({filteredRecords.length}条)</span></div>
          <div className="flex items-center gap-2">
            <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setCurrentPage(1); }} className="h-7 rounded border border-[#D1D5DB] px-2 text-xs">
              <option value={10}>10条/页</option>
              <option value={20}>20条/页</option>
              <option value={50}>50条/页</option>
            </select>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">日期</th>
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
              <th className="px-3 py-2 text-right text-xs font-semibold text-[#6B7280]">单价</th>
              <th className="px-3 py-2 text-right text-xs font-semibold text-[#6B7280]">数量</th>
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">供应商</th>
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">采购单位</th>
              <th className="px-3 py-2 text-left text-xs font-semibold text-[#6B7280]">合同号</th>
            </tr>
          </thead>
          <tbody>
            {pagedRecords.map(r => (
              <tr key={r.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                <td className="px-3 py-2 text-xs text-[#6B7280]">{r.date}</td>
                <td className="px-3 py-2 font-medium text-[#1F2937]">{r.equipName}</td>
                <td className="px-3 py-2 text-xs text-[#6B7280]">{r.spec}</td>
                <td className="px-3 py-2 text-right font-medium text-[#1A56DB]">¥{r.unitPrice.toLocaleString()}</td>
                <td className="px-3 py-2 text-right text-[#374151]">{r.quantity}{r.unit}</td>
                <td className="px-3 py-2 text-xs text-[#374151]">{r.supplierName} <span className="text-[#F59E0B]">★{r.supplierRating}</span></td>
                <td className="px-3 py-2">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${r.isCurrentUnit ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#F3F4F6] text-[#6B7280]'}`}>
                    {r.isCurrentUnit ? '本单位' : '其他单位'}
                  </span>
                </td>
                <td className="px-3 py-2 font-mono text-xs text-[#6B7280]">{r.isCurrentUnit ? r.orderNo : r.orderNo.slice(0, 4) + '****'}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <BarChart3 size={48} className="mx-auto mb-3 opacity-30" />
            暂无匹配数据，请调整筛选条件
          </div>
        )}
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-1 border-t border-[#E5E7EB] px-4 py-3">
            <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">上一页</button>
            {Array.from({ length: totalPages }, (_, i) => (
              <button key={i} onClick={() => setCurrentPage(i + 1)} className={`h-7 w-7 rounded text-xs ${currentPage === i + 1 ? 'bg-[#1A56DB] text-white' : 'border border-[#D1D5DB] text-[#374151]'}`}>{i + 1}</button>
            ))}
            <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">下一页</button>
          </div>
        )}
      </div>
    </div>
  )
}
