import { useState, useRef, useEffect } from 'react'
import {
  ArrowLeft, Plus, Search, ChevronRight, ChevronDown,
  Tag, Edit2, Trash2, MoreHorizontal, Check, X, Settings,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─── Types ─── */
interface TagItem {
  id: string
  name: string
  color: string
  status: 'enabled' | 'disabled'
  description: string
  scope: 'global' | 'category' | 'equip'
  parentId: string | null
  level: number
  children?: TagItem[]
}

interface AutoTagRule {
  id: string
  field: string
  operator: string
  value: string
  value2?: string
}

/* ─── Mock Data ─── */
const TAG_COLORS = ['#1A56DB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16']

const initialTags: TagItem[] = [
  {
    id: 't1', name: '状态类', color: '#1A56DB', status: 'enabled', description: '装备状态标签', scope: 'global', parentId: null, level: 0,
    children: [
      {
        id: 't1-1', name: '临期30天', color: '#F59E0B', status: 'enabled', description: '距离有效期30天内', scope: 'global', parentId: 't1', level: 1,
        children: [
          { id: 't1-1-1', name: '临期7天', color: '#EF4444', status: 'enabled', description: '距离有效期7天内，紧急处理', scope: 'global', parentId: 't1-1', level: 2 },
          { id: 't1-1-2', name: '临期15天', color: '#F59E0B', status: 'enabled', description: '距离有效期15天内', scope: 'global', parentId: 't1-1', level: 2 },
        ]
      },
      { id: 't1-2', name: '库存紧张', color: '#EF4444', status: 'enabled', description: '库存低于安全线', scope: 'global', parentId: 't1', level: 1 },
      { id: 't1-3', name: '已停用', color: '#6B7280', status: 'enabled', description: '装备已停用', scope: 'global', parentId: 't1', level: 1 },
    ]
  },
  {
    id: 't2', name: '属性类', color: '#10B981', status: 'enabled', description: '装备固有属性', scope: 'global', parentId: null, level: 0,
    children: [
      { id: 't2-1', name: '电子类', color: '#10B981', status: 'enabled', description: '含电子元件的装备', scope: 'global', parentId: 't2', level: 1 },
      { id: 't2-2', name: '易耗品', color: '#F59E0B', status: 'enabled', description: '消耗性装备', scope: 'global', parentId: 't2', level: 1 },
      { id: 't2-3', name: '贵重仪器', color: '#8B5CF6', status: 'enabled', description: '高价值精密仪器', scope: 'global', parentId: 't2', level: 1 },
    ]
  },
  {
    id: 't3', name: '管理类', color: '#8B5CF6', status: 'enabled', description: '管理维度标签', scope: 'global', parentId: null, level: 0,
    children: [
      { id: 't3-1', name: '进口装备', color: '#EC4899', status: 'enabled', description: '进口来源装备', scope: 'global', parentId: 't3', level: 1 },
      { id: 't3-2', name: '涉密装备', color: '#EF4444', status: 'enabled', description: '涉及保密要求的装备', scope: 'global', parentId: 't3', level: 1 },
    ]
  },
]

const FIELDS = ['装备名称', '装备类别', '规格型号', '生产厂家', '单价', '有效期', '库存数量', '入库时间']
const OPERATORS = ['等于', '不等于', '包含', '不包含', '大于', '小于', '介于']

const mockTaggedEquipments = [
  { id: 'e1', code: '2101001', name: '现场测记录综合系统', category: '现场检测', model: 'SJ-V2', tags: ['电子类', '贵重仪器'], status: '在用' },
  { id: 'e2', code: '2102006', name: '多波段光源', category: '辅助观测', model: 'DB-PRO', tags: ['电子类', '临期30天'], status: '在用' },
  { id: 'e3', code: '2201001', name: '气味鉴别犬', category: '警犬', model: 'QW-001', tags: ['易耗品'], status: '在用' },
]

/* ─── TagNode Component ─── */
function TagNode({
  tag, expanded, onToggle, onEdit, onDelete, onAddChild, onHover,
}: {
  tag: TagItem
  expanded: boolean
  onToggle: () => void
  onEdit: (t: TagItem) => void
  onDelete: (id: string) => void
  onAddChild: (parentId: string) => void
  onHover: (tag: TagItem | null, el: HTMLElement | null) => void
}) {
  const hasChildren = tag.children && tag.children.length > 0
  const ref = useRef<HTMLDivElement>(null)

  return (
    <div className="select-none">
      <div
        ref={ref}
        className="group flex items-center gap-1.5 rounded-md px-2 py-1.5 transition hover:bg-[#F3F4F6]"
        style={{ paddingLeft: `${tag.level * 20 + 8}px` }}
        onMouseEnter={() => onHover(tag, ref.current)}
        onMouseLeave={() => onHover(null, null)}
      >
        {hasChildren ? (
          <button onClick={onToggle} className="flex h-4 w-4 items-center justify-center text-[#9CA3AF] hover:text-[#374151]">
            {expanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
          </button>
        ) : (
          <span className="w-4" />
        )}
        <span className="h-2.5 w-2.5 rounded-full shrink-0" style={{ backgroundColor: tag.color }} />
        <span className={cn('text-sm', tag.status === 'disabled' && 'text-[#9CA3AF] line-through')}>{tag.name}</span>
        {tag.status === 'disabled' && <span className="text-[10px] text-[#9CA3AF] ml-1">(已停用)</span>}
      </div>
      {hasChildren && expanded && (
        <div>
          {tag.children!.map(child => (
            <TagNode key={child.id} tag={child} expanded={expanded} onToggle={onToggle} onEdit={onEdit} onDelete={onDelete} onAddChild={onAddChild} onHover={onHover} />
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── HoverMenu Component ─── */
function HoverMenu({ tag, position, onEdit, onDelete, onAddChild }: {
  tag: TagItem
  position: { x: number; y: number }
  onEdit: () => void
  onDelete: () => void
  onAddChild: () => void
}) {
  return (
    <div
      className="fixed z-[70] w-32 rounded-lg border border-[#E5E7EB] bg-white py-1 shadow-lg"
      style={{ left: position.x, top: position.y }}
    >
      <button onClick={onEdit} className="flex w-full items-center gap-2 px-3 py-1.5 text-sm text-[#374151] hover:bg-[#F3F4F6]">
        <Edit2 size={12} /> 编辑
      </button>
      <button onClick={onAddChild} className="flex w-full items-center gap-2 px-3 py-1.5 text-sm text-[#374151] hover:bg-[#F3F4F6]">
        <Plus size={12} /> 添加子级
      </button>
      <div className="my-0.5 border-t border-[#E5E7EB]" />
      <button onClick={onDelete} className="flex w-full items-center gap-2 px-3 py-1.5 text-sm text-[#EF4444] hover:bg-[#FEF2F2]">
        <Trash2 size={12} /> 删除
      </button>
    </div>
  )
}

/* ─── Main Page ─── */
export default function TagManagementPage() {
  const [tags, setTags] = useState<TagItem[]>(initialTags)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['t1', 't2', 't3']))
  const [searchText, setSearchText] = useState('')
  const [editTag, setEditTag] = useState<TagItem | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState<Partial<TagItem>>({})
  const [parentId, setParentId] = useState<string | null>(null)
  const [hoveredTag, setHoveredTag] = useState<{ tag: TagItem; el: HTMLElement } | null>(null)
  const [menuPos, setMenuPos] = useState({ x: 0, y: 0 })
  const [autoRules, setAutoRules] = useState<AutoTagRule[]>([])
  const [activeTab, setActiveTab] = useState<'tree' | 'equip'>('tree')

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleHover = (tag: TagItem | null, el: HTMLElement | null) => {
    if (tag && el) {
      const rect = el.getBoundingClientRect()
      setMenuPos({ x: rect.right + 4, y: rect.top })
      setHoveredTag({ tag, el })
    } else {
      setHoveredTag(null)
    }
  }

  const openAddForm = (parent: string | null = null) => {
    setParentId(parent)
    setFormData({ name: '', color: TAG_COLORS[0], status: 'enabled', description: '', scope: 'global' })
    setAutoRules([])
    setShowForm(true)
    setEditTag(null)
  }

  const openEditForm = (tag: TagItem) => {
    setEditTag(tag)
    setFormData({ ...tag })
    setAutoRules([])
    setShowForm(true)
    setParentId(null)
  }

  const saveTag = () => {
    if (!formData.name) return
    if (editTag) {
      setTags(prev => updateTagInTree(prev, editTag.id, formData as TagItem))
    } else {
      const newTag: TagItem = {
        id: `t${Date.now()}`,
        name: formData.name || '',
        color: formData.color || TAG_COLORS[0],
        status: (formData.status as 'enabled' | 'disabled') || 'enabled',
        description: formData.description || '',
        scope: (formData.scope as 'global' | 'category' | 'equip') || 'global',
        parentId: parentId,
        level: parentId ? (findTagById(tags, parentId)?.level ?? 0) + 1 : 0,
      }
      if (parentId) {
        setTags(prev => addChildToTree(prev, parentId, newTag))
      } else {
        setTags(prev => [...prev, newTag])
      }
    }
    setShowForm(false)
  }

  const deleteTag = (id: string) => {
    setTags(prev => removeTagFromTree(prev, id))
    setHoveredTag(null)
  }

  const addRule = () => {
    setAutoRules(prev => [...prev, { id: `r${Date.now()}`, field: FIELDS[0], operator: OPERATORS[0], value: '' }])
  }

  const updateRule = (id: string, patch: Partial<AutoTagRule>) => {
    setAutoRules(prev => prev.map(r => r.id === id ? { ...r, ...patch } : r))
  }

  const removeRule = (id: string) => {
    setAutoRules(prev => prev.filter(r => r.id !== id))
  }

  const filteredTags = searchText
    ? flattenTags(tags).filter(t => t.name.includes(searchText) || t.description.includes(searchText))
    : flattenTags(tags)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <ArrowLeft size={18} />
          </button>
          <h1 className="text-xl font-semibold text-[#1F2937]">标签管理</h1>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => openAddForm(null)} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">
            <Plus size={14} /> 新增标签
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          <button onClick={() => setActiveTab('tree')} className={cn('relative pb-3 text-sm font-medium', activeTab === 'tree' ? 'text-[#1A56DB]' : 'text-[#6B7280]')}>
            标签树
            {activeTab === 'tree' && <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
          </button>
          <button onClick={() => setActiveTab('equip')} className={cn('relative pb-3 text-sm font-medium', activeTab === 'equip' ? 'text-[#1A56DB]' : 'text-[#6B7280]')}>
            已标记装备
            {activeTab === 'equip' && <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
          </button>
        </div>
      </div>

      {activeTab === 'tree' ? (
        <div className="flex gap-4">
          {/* Left: Tag Tree */}
          <div className="w-80 rounded-lg border border-[#E5E7EB] bg-white p-4">
            <div className="mb-3 flex items-center gap-2">
              <div className="relative flex-1">
                <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                <input value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索标签..." className="h-8 w-full rounded-md border border-[#D1D5DB] pl-7 pr-2 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
            <div className="space-y-0.5">
              {tags.map(tag => (
                <TagNode key={tag.id} tag={tag} expanded={expandedIds.has(tag.id)} onToggle={() => toggleExpand(tag.id)} onEdit={openEditForm} onDelete={deleteTag} onAddChild={openAddForm} onHover={handleHover} />
              ))}
            </div>
          </div>

          {/* Right: Form or Detail */}
          <div className="flex-1 rounded-lg border border-[#E5E7EB] bg-white p-6">
            {showForm ? (
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-[#1F2937]">{editTag ? '编辑标签' : '新增标签'}{parentId && ` (子标签)`}</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1 block text-sm font-medium text-[#374151]">标签名称 <span className="text-[#EF4444]">*</span></label>
                    <input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" placeholder="输入标签名称" />
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-[#374151]">标签颜色</label>
                    <div className="flex flex-wrap gap-2">
                      {TAG_COLORS.map(c => (
                        <button key={c} onClick={() => setFormData({ ...formData, color: c })} className={cn('h-6 w-6 rounded-full border-2 transition', formData.color === c ? 'border-[#1F2937] scale-110' : 'border-transparent hover:scale-105')}
                          style={{ backgroundColor: c }} />
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-[#374151]">状态</label>
                    <select value={formData.status} onChange={e => setFormData({ ...formData, status: e.target.value as 'enabled' | 'disabled' })} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                      <option value="enabled">启用</option>
                      <option value="disabled">停用</option>
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-sm font-medium text-[#374151]">适用范围</label>
                    <select value={formData.scope} onChange={e => setFormData({ ...formData, scope: e.target.value as 'global' | 'category' | 'equip' })} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                      <option value="global">全局</option>
                      <option value="category">按分类</option>
                      <option value="equip">按装备</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <label className="mb-1 block text-sm font-medium text-[#374151]">描述</label>
                    <textarea value={formData.description || ''} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB] resize-none" placeholder="标签描述说明..." />
                  </div>
                </div>

                {/* Auto-tag Rules */}
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <label className="text-sm font-medium text-[#374151]">自动打标规则</label>
                    <button onClick={addRule} className="inline-flex items-center gap-1 rounded-md border border-[#D1D5DB] px-2 py-1 text-xs text-[#374151] hover:bg-[#F3F4F6]">
                      <Plus size={12} /> 添加规则
                    </button>
                  </div>
                  {autoRules.length === 0 && <p className="text-xs text-[#9CA3AF]">暂无规则，点击上方按钮添加</p>}
                  {autoRules.map((rule, i) => (
                    <div key={rule.id} className="mb-2 flex items-center gap-2 rounded-md bg-[#F9FAFB] p-2">
                      <span className="text-xs text-[#6B7280]">条件{i + 1}:</span>
                      <select value={rule.field} onChange={e => updateRule(rule.id, { field: e.target.value })} className="h-7 rounded border border-[#D1D5DB] px-2 text-xs outline-none">
                        {FIELDS.map(f => <option key={f} value={f}>{f}</option>)}
                      </select>
                      <select value={rule.operator} onChange={e => updateRule(rule.id, { operator: e.target.value })} className="h-7 rounded border border-[#D1D5DB] px-2 text-xs outline-none">
                        {OPERATORS.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                      <input value={rule.value} onChange={e => updateRule(rule.id, { value: e.target.value })} className="h-7 w-28 rounded border border-[#D1D5DB] px-2 text-xs outline-none" placeholder="值" />
                      {rule.operator === '介于' && (
                        <>
                          <span className="text-xs text-[#6B7280]">~</span>
                          <input value={rule.value2 || ''} onChange={e => updateRule(rule.id, { value2: e.target.value })} className="h-7 w-28 rounded border border-[#D1D5DB] px-2 text-xs outline-none" placeholder="结束值" />
                        </>
                      )}
                      <button onClick={() => removeRule(rule.id)} className="text-[#EF4444] hover:bg-[#FEF2F2] rounded p-1">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-end gap-2 pt-2">
                  <button onClick={() => setShowForm(false)} className="h-9 rounded-md border border-[#D1D5DB] px-5 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
                  <button onClick={saveTag} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white hover:bg-[#153E7E]">保存</button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-16 text-[#9CA3AF]">
                <Tag size={48} className="mb-3 opacity-30" />
                <p className="text-sm">选择左侧标签进行编辑，或点击"新增标签"创建</p>
                <p className="mt-1 text-xs">鼠标悬浮标签可显示操作菜单</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Tagged Equipment Tab */
        <div className="rounded-lg border border-[#E5E7EB] bg-white">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备编码</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备类别</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">标签</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
              </tr>
            </thead>
            <tbody>
              {mockTaggedEquipments.map(eq => (
                <tr key={eq.id} className="border-b border-[#F3F4F6]">
                  <td className="px-4 py-3 font-mono text-xs text-[#6B7280]">{eq.code}</td>
                  <td className="px-4 py-3 font-medium text-[#1F2937]">{eq.name}</td>
                  <td className="px-4 py-3 text-[#374151]">{eq.category}</td>
                  <td className="px-4 py-3 text-xs text-[#6B7280]">{eq.model}</td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {eq.tags.map(t => (
                        <span key={t} className="inline-flex items-center gap-1 rounded-full bg-[#EFF6FF] px-2 py-0.5 text-xs text-[#1A56DB]">
                          <Tag size={10} /> {t}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="px-4 py-3"><span className="rounded-full bg-[#ECFDF5] px-2 py-0.5 text-xs text-[#059669]">{eq.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Hover Menu */}
      {hoveredTag && (
        <HoverMenu
          tag={hoveredTag.tag}
          position={menuPos}
          onEdit={() => { openEditForm(hoveredTag.tag); setHoveredTag(null); }}
          onDelete={() => { deleteTag(hoveredTag.tag.id); setHoveredTag(null); }}
          onAddChild={() => { openAddForm(hoveredTag.tag.id); setHoveredTag(null); }}
        />
      )}
    </div>
  )
}

/* ─── Helpers ─── */
function flattenTags(tags: TagItem[]): TagItem[] {
  const result: TagItem[] = []
  const walk = (list: TagItem[]) => {
    for (const t of list) {
      result.push(t)
      if (t.children) walk(t.children)
    }
  }
  walk(tags)
  return result
}

function findTagById(tags: TagItem[], id: string): TagItem | null {
  for (const t of tags) {
    if (t.id === id) return t
    if (t.children) {
      const found = findTagById(t.children, id)
      if (found) return found
    }
  }
  return null
}

function updateTagInTree(tags: TagItem[], id: string, data: TagItem): TagItem[] {
  return tags.map(t => {
    if (t.id === id) return { ...t, ...data, children: t.children }
    if (t.children) return { ...t, children: updateTagInTree(t.children, id, data) }
    return t
  })
}

function addChildToTree(tags: TagItem[], parentId: string, child: TagItem): TagItem[] {
  return tags.map(t => {
    if (t.id === parentId) return { ...t, children: [...(t.children || []), child] }
    if (t.children) return { ...t, children: addChildToTree(t.children, parentId, child) }
    return t
  })
}

function removeTagFromTree(tags: TagItem[], id: string): TagItem[] {
  return tags.filter(t => t.id !== id).map(t => ({
    ...t,
    children: t.children ? removeTagFromTree(t.children, id) : undefined,
  }))
}
