import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'

/* ── Basic Info ── */
import SupplierPage from './pages/basic-info/SupplierPage'
import SupplierEvaluationPage from './pages/basic-info/SupplierEvaluationPage'
import WarehouseInfoPage from './pages/basic-info/WarehouseInfoPage'
import EquipmentLibPage from './pages/basic-info/EquipmentLibPage'
import StandardPage from './pages/basic-info/StandardPage'
import RfidPage from './pages/basic-info/RfidPage'
import TagManagementPage from './pages/basic-info/TagManagementPage'
import PriceComparisonPage from './pages/basic-info/PriceComparisonPage'

/* ── Supervision ── */
import WarningRulesPage from './pages/supervision/WarningRulesPage'
import WarningRecordsPage from './pages/supervision/WarningRecordsPage'
import EquipmentControlPage from './pages/supervision/EquipmentControlPage'

/* ── Warehouse ── */
import InboundPage from './pages/warehouse/InboundPage'
import LedgerPage from './pages/warehouse/LedgerPage'
import OutboundPage from './pages/warehouse/OutboundPage'
import RepairPage from './pages/warehouse/RepairPage'
import ScrapPage from './pages/warehouse/ScrapPage'
import TransferPage from './pages/warehouse/TransferPage'
import AllocationPage from './pages/warehouse/AllocationPage'
import InventoryPage from './pages/warehouse/InventoryPage'
import ChannelPage from './pages/warehouse/ChannelPage'
import EquipmentPickupPage from './pages/warehouse/EquipmentPickupPage'
import MaintenancePage from './pages/warehouse/MaintenancePage'

/* ── Emergency ── */
import EmergencyOverviewPage from './pages/emergency/EmergencyOverviewPage'
import EmergencyQuickOutboundPage from './pages/emergency/EmergencyQuickOutboundPage'
import EmergencyReadinessPage from './pages/emergency/EmergencyReadinessPage'

/* ── Personal ── */
import MyEquipmentPage from './pages/personal/MyEquipmentPage'
import BorrowPage from './pages/personal/BorrowPage'
import PersonalRepairPage from './pages/personal/PersonalRepairPage'
import PersonalScrapPage from './pages/personal/PersonalScrapPage'
import HandoverPage from './pages/personal/HandoverPage'
import ComplaintPage from './pages/personal/ComplaintPage'

/* ── Analysis ── */
import ProcurementAnalysisPage from './pages/analysis/ProcurementAnalysisPage'
import AllocationAnalysisPage from './pages/analysis/AllocationAnalysisPage'
import AftersalesAnalysisPage from './pages/analysis/AftersalesAnalysisPage'
import SupplierAnalysisPage from './pages/analysis/SupplierAnalysisPage'
import QualityAnalysisPage from './pages/analysis/QualityAnalysisPage'
import DistributionAnalysisPage from './pages/analysis/DistributionAnalysisPage'

/* ── Training ── */
import MaterialsPage from './pages/training/MaterialsPage'
import TrainingProcessPage from './pages/training/TrainingProcessPage'

/* ── Forum ── */
import ForumPage from './pages/forum/ForumPage'
import ForumPostDetailPage from './pages/forum/ForumPostDetailPage'

/* ── Workflow ── */
import WorkflowDesignPage from './pages/workflow/WorkflowDesignPage'
import WorkflowTemplatesPage from './pages/workflow/WorkflowTemplatesPage'
import WorkflowMonitorPage from './pages/workflow/WorkflowMonitorPage'

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/dashboard" element={<Home />} />

        {/* Basic Info */}
        <Route path="/basic-info/supplier" element={<SupplierPage />} />
        <Route path="/basic-info/supplier-evaluation" element={<SupplierEvaluationPage />} />
        <Route path="/basic-info/warehouse" element={<WarehouseInfoPage />} />
        <Route path="/basic-info/equipment-lib" element={<EquipmentLibPage />} />
        <Route path="/basic-info/standard" element={<StandardPage />} />
        <Route path="/basic-info/rfid" element={<RfidPage />} />
        <Route path="/basic-info/tag-management" element={<TagManagementPage />} />
        <Route path="/basic-info/price-comparison" element={<PriceComparisonPage />} />

        {/* Supervision */}
        <Route path="/supervision/warning-rules" element={<WarningRulesPage />} />
        <Route path="/supervision/warning-records" element={<WarningRecordsPage />} />
        <Route path="/supervision/equipment-control" element={<EquipmentControlPage />} />

        {/* Warehouse */}
        <Route path="/warehouse/inbound" element={<InboundPage />} />
        <Route path="/warehouse/ledger" element={<LedgerPage />} />
        <Route path="/warehouse/outbound" element={<OutboundPage />} />
        <Route path="/warehouse/maintenance" element={<MaintenancePage />} />
        <Route path="/warehouse/repair" element={<RepairPage />} />
        <Route path="/warehouse/scrap" element={<ScrapPage />} />
        <Route path="/warehouse/transfer" element={<TransferPage />} />
        <Route path="/warehouse/allocation" element={<AllocationPage />} />
        <Route path="/warehouse/inventory" element={<InventoryPage />} />
        <Route path="/warehouse/channel" element={<ChannelPage />} />
        <Route path="/warehouse/pickup" element={<EquipmentPickupPage />} />

        {/* Emergency */}
        <Route path="/emergency/overview" element={<EmergencyOverviewPage />} />
        <Route path="/emergency/quick-outbound" element={<EmergencyQuickOutboundPage />} />
        <Route path="/emergency/readiness" element={<EmergencyReadinessPage />} />

        {/* Personal */}
        <Route path="/personal/my-equipment" element={<MyEquipmentPage />} />
        <Route path="/personal/borrow" element={<BorrowPage />} />
        <Route path="/personal/repair" element={<PersonalRepairPage />} />
        <Route path="/personal/scrap" element={<PersonalScrapPage />} />
        <Route path="/personal/handover" element={<HandoverPage />} />
        <Route path="/personal/complaint" element={<ComplaintPage />} />

        {/* Analysis */}
        <Route path="/analysis/procurement" element={<ProcurementAnalysisPage />} />
        <Route path="/analysis/allocation" element={<AllocationAnalysisPage />} />
        <Route path="/analysis/aftersales" element={<AftersalesAnalysisPage />} />
        <Route path="/analysis/supplier" element={<SupplierAnalysisPage />} />
        <Route path="/analysis/quality" element={<QualityAnalysisPage />} />
        <Route path="/analysis/distribution" element={<DistributionAnalysisPage />} />

        {/* Training */}
        <Route path="/training/materials" element={<MaterialsPage />} />
        <Route path="/training/process" element={<TrainingProcessPage />} />

        {/* Forum */}
        <Route path="/forum" element={<ForumPage />} />
        <Route path="/forum/post/:id" element={<ForumPostDetailPage />} />

        {/* Workflow */}
        <Route path="/workflow/design" element={<WorkflowDesignPage />} />
        <Route path="/workflow/templates" element={<WorkflowTemplatesPage />} />
        <Route path="/workflow/monitor" element={<WorkflowMonitorPage />} />

        {/* Default redirect */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  )
}
