import { useState } from 'react'
import {
  Plus, Upload, Download, Edit3, Eye, Trash2, X,
  FileText, Package, Archive, ArrowUpCircle,
  AlertTriangle, Gavel, ShoppingCart, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, Truck, ClipboardCheck,
  User, Award, RotateCcw,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface Supplier {
  id: string; name: string; creditCode: string; regAddress: string; legalPerson: string; type: '生产商' | '协议供货商' | '供应商'; credentials: string[]; contracts: number; performance: number; rating: number; contact: string; idType: string; idNumber: string; phone: string; email: string; status: '启用' | '停用'
}

type DetailTab = 'archive' | 'contract' | 'order' | 'ledger' | 'outbound' | 'complaint' | 'punishment'

interface EquipItem { name: string; spec: string; quantity: number; unit: string }
interface ReceiveNote { code: string; quantity: number; receiveDate: string; receiver: string; status: string; equipItems: EquipItem[] }
interface DeliveryNote { code: string; quantity: number; deliveryDate: string; trackingNo: string; status: string; equipItems: EquipItem[]; receives: ReceiveNote[] }
interface BatchOrder { code: string; items: string; totalAmount: string; orderDate: string; status: string; deliveries: DeliveryNote[] }

interface Complaint {
  id: string; code: string; supplierId: string; supplierName: string
  type: string; content: string; complainant: string; complaintDate: string
  status: string; auditStatus: '待审核' | '已通过' | '已驳回'
  hasPunishment: boolean; punishmentType?: string; punishmentReason?: string; punishmentPeriod?: string
}

interface Punishment {
  id: string; code: string; supplierId: string; supplierName: string
  type: string; reason: string; decisionDate: string; effectivePeriod: string
  status: string; auditStatus: '待审核' | '已通过' | '已驳回'
  relatedComplaintCode?: string
}

/* ═══════════════════════════════════════════
   Mock 数据：供应商
   ═══════════════════════════════════════════ */

const mockSuppliers: Supplier[] = [
  { id: '1', name: 'XX安防科技有限公司', creditCode: '91410000MA1234567X', regAddress: '河南省郑州市高新区科学大道169号', legalPerson: '王建国', type: '生产商', credentials: ['营业执照', 'ISO9001', '警采入围'], contracts: 12, performance: 96, rating: 4.8, contact: '王经理', idType: '身份证', idNumber: '41010219800101XXXX', phone: '13800138001', email: 'wang@xxanfang.com', status: '启用' },
  { id: '2', name: 'YY警用装备有限公司', creditCode: '91410000MA7654321Y', regAddress: '河南省洛阳市洛龙区开元大道258号', legalPerson: '李明华', type: '协议供货商', credentials: ['营业执照', 'ISO14001'], contracts: 8, performance: 88, rating: 4.2, contact: '李经理', idType: '身份证', idNumber: '41030219850215XXXX', phone: '13800138002', email: 'li@yyjingyong.com', status: '启用' },
  { id: '3', name: 'ZZ防护用品厂', creditCode: '91410000MA1111111Z', regAddress: '河南省新乡市牧野区北环路168号', legalPerson: '赵国强', type: '生产商', credentials: ['营业执照', '警采入围'], contracts: 25, performance: 99, rating: 4.9, contact: '赵主任', idType: '身份证', idNumber: '41070319781203XXXX', phone: '13800138003', email: 'zhao@zzfanghu.com', status: '启用' },
  { id: '4', name: 'AA通信设备公司', creditCode: '91410000MA2222222A', regAddress: '河南省郑州市金水区经三路66号', legalPerson: '陈志强', type: '供应商', credentials: ['营业执照', 'ISO9001'], contracts: 5, performance: 92, rating: 4.5, contact: '陈经理', idType: '身份证', idNumber: '41010519900120XXXX', phone: '13800138004', email: 'chen@aatongxin.com', status: '启用' },
  { id: '5', name: 'BB交通设施厂', creditCode: '91410000MA3333333B', regAddress: '河南省开封市鼓楼区中山路88号', legalPerson: '刘建设', type: '生产商', credentials: ['营业执照'], contracts: 3, performance: 85, rating: 3.9, contact: '刘主任', idType: '身份证', idNumber: '41020419830708XXXX', phone: '13800138005', email: 'liu@bbjiaotong.com', status: '停用' },
  { id: '6', name: 'CC检测仪器公司', creditCode: '91410000MA4444444C', regAddress: '河南省郑州市郑东新区商务外环22号', legalPerson: '孙卫东', type: '协议供货商', credentials: ['营业执照', 'ISO9001', '警采入围'], contracts: 18, performance: 97, rating: 4.7, contact: '孙经理', idType: '身份证', idNumber: '41012219751010XXXX', phone: '13800138006', email: 'sun@ccjiance.com', status: '启用' },
  { id: '7', name: 'DD服装加工厂', creditCode: '91410000MA5555555D', regAddress: '河南省许昌市魏都区七一路99号', legalPerson: '周文明', type: '生产商', credentials: ['营业执照', 'ISO14001'], contracts: 30, performance: 94, rating: 4.6, contact: '周主任', idType: '身份证', idNumber: '41100219860922XXXX', phone: '13800138007', email: 'zhou@ddfuzhuang.com', status: '启用' },
  { id: '8', name: 'EE信息技术公司', creditCode: '91410000MA6666666E', regAddress: '河南省郑州市中原区中原西路220号', legalPerson: '吴晓明', type: '供应商', credentials: ['营业执照', 'ISO9001', '警采入围'], contracts: 7, performance: 90, rating: 4.3, contact: '吴经理', idType: '身份证', idNumber: '41010219790818XXXX', phone: '13800138008', email: 'wu@eexinxi.com', status: '启用' },
  { id: '9', name: 'FF智能装备科技', creditCode: '91410000MA7777777F', regAddress: '河南省南阳市卧龙区工业路55号', legalPerson: '郑华伟', type: '生产商', credentials: ['营业执照', 'ISO9001', 'ISO14001', '警采入围'], contracts: 15, performance: 98, rating: 4.8, contact: '郑经理', idType: '身份证', idNumber: '41130319811005XXXX', phone: '13800138009', email: 'zheng@ffzhineng.com', status: '启用' },
  { id: '10', name: 'GG照明设备厂', creditCode: '91410000MA8888888G', regAddress: '河南省商丘市睢阳区神火大道77号', legalPerson: '钱光明', type: '供应商', credentials: ['营业执照', 'ISO9001'], contracts: 6, performance: 89, rating: 4.1, contact: '钱主任', idType: '身份证', idNumber: '41140219761130XXXX', phone: '13800138010', email: 'qian@ggzhaoming.com', status: '启用' },
  { id: '11', name: 'HH警用车辆改装厂', creditCode: '91410000MA9999999H', regAddress: '河南省安阳市文峰区中华路66号', legalPerson: '冯德全', type: '生产商', credentials: ['营业执照', '警采入围'], contracts: 9, performance: 93, rating: 4.4, contact: '冯经理', idType: '身份证', idNumber: '41050219740512XXXX', phone: '13800138011', email: 'feng@hhjingyong.com', status: '启用' },
  { id: '12', name: 'II防弹材料公司', creditCode: '91410000MA0000000I', regAddress: '河南省平顶山市新华区建设路99号', legalPerson: '许志强', type: '生产商', credentials: ['营业执照', 'ISO9001', '警采入围'], contracts: 22, performance: 95, rating: 4.7, contact: '许主任', idType: '身份证', idNumber: '41040219760825XXXX', phone: '13800138012', email: 'xu@iifangtan.com', status: '启用' },
]

/* ═══════════════════════════════════════════
   Mock 数据：投诉
   ═══════════════════════════════════════════ */

const initialComplaints: Complaint[] = [
  { id: '1', code: 'TS-2024-012', supplierId: '1', supplierName: 'XX安防科技有限公司', type: '质量问题', content: '防弹背心缝线不均匀，存在开线风险', complainant: '张警官', complaintDate: '2024-05-20', status: '已处理', auditStatus: '已通过', hasPunishment: true, punishmentType: '警告', punishmentReason: '产品质量不达标', punishmentPeriod: '2024-05-20至2024-08-20' },
  { id: '2', code: 'TS-2024-018', supplierId: '2', supplierName: 'YY警用装备有限公司', type: '交货延迟', content: '执法记录仪订单延迟交货15天', complainant: '李警官', complaintDate: '2024-06-10', status: '处理中', auditStatus: '已通过', hasPunishment: false },
  { id: '3', code: 'TS-2024-025', supplierId: '3', supplierName: 'ZZ防护用品厂', type: '售后服务', content: '对讲机故障维修响应速度慢', complainant: '王警官', complaintDate: '2024-07-05', status: '待处理', auditStatus: '待审核', hasPunishment: false },
  { id: '4', code: 'TS-2024-031', supplierId: '1', supplierName: 'XX安防科技有限公司', type: '质量问题', content: '防刺服防护等级不达标，抽检不合格', complainant: '赵警官', complaintDate: '2024-07-15', status: '处理中', auditStatus: '已通过', hasPunishment: true, punishmentType: '暂停合作', punishmentReason: '产品质量严重不达标', punishmentPeriod: '2024-07-15至2024-10-15' },
  { id: '5', code: 'TS-2024-038', supplierId: '4', supplierName: 'AA通信设备公司', type: '其他', content: '发票开具不及时，影响财务结算', complainant: '刘警官', complaintDate: '2024-08-01', status: '待处理', auditStatus: '待审核', hasPunishment: false },
  { id: '6', code: 'TS-2024-042', supplierId: '5', supplierName: 'BB交通设施厂', type: '交货延迟', content: '反光背心订单延迟交货30天', complainant: '陈警官', complaintDate: '2024-08-10', status: '已处理', auditStatus: '已驳回', hasPunishment: false },
]

/* ═══════════════════════════════════════════
   Mock 数据：处罚
   ═══════════════════════════════════════════ */

const initialPunishments: Punishment[] = [
  { id: '1', code: 'CF-2024-003', supplierId: '1', supplierName: 'XX安防科技有限公司', type: '警告', reason: '合同履约率低于90%', decisionDate: '2024-03-15', effectivePeriod: '2024-03-15至2024-06-15', status: '已解除', auditStatus: '已通过', relatedComplaintCode: 'TS-2024-012' },
  { id: '2', code: 'CF-2024-007', supplierId: '1', supplierName: 'XX安防科技有限公司', type: '警告', reason: '产品质量抽检不合格', decisionDate: '2024-06-20', effectivePeriod: '2024-06-20至2024-09-20', status: '生效中', auditStatus: '已通过', relatedComplaintCode: 'TS-2024-031' },
  { id: '3', code: 'CF-2024-010', supplierId: '2', supplierName: 'YY警用装备有限公司', type: '暂停合作', reason: '多次交货延迟，影响装备保障', decisionDate: '2024-07-01', effectivePeriod: '2024-07-01至2024-10-01', status: '生效中', auditStatus: '待审核' },
  { id: '4', code: 'CF-2024-015', supplierId: '5', supplierName: 'BB交通设施厂', type: '罚款', reason: '提供虚假资质文件', decisionDate: '2024-08-05', effectivePeriod: '2024-08-05至2024-11-05', status: '生效中', auditStatus: '已通过' },
]

/* ═══════════════════════════════════════════
   Mock 数据：合同/订单/台账/出库
   ═══════════════════════════════════════════ */

const contractColumns = [{ key: 'code', title: '合同编号' }, { key: 'name', title: '合同名称' }, { key: 'amount', title: '合同金额', render: (v: string) => `¥${v}` }, { key: 'signDate', title: '签订日期' }, { key: 'expiryDate', title: '到期日期' }, { key: 'status', title: '状态', render: (v: string) => <Badge variant={v === '履行中' ? 'success' : v === '已到期' ? 'warning' : 'default'}>{v}</Badge> }]
const contractData = [{ code: 'HT-2024-001', name: '防弹背心采购合同', amount: '2,400,000', signDate: '2024-01-15', expiryDate: '2025-01-14', status: '履行中' }, { code: 'HT-2024-008', name: '执法记录仪供货协议', amount: '1,800,000', signDate: '2024-03-20', expiryDate: '2025-03-19', status: '履行中' }, { code: 'HT-2023-015', name: '警用头盔年度合同', amount: '960,000', signDate: '2023-06-01', expiryDate: '2024-05-31', status: '已到期' }, { code: 'HT-2024-022', name: '防刺服批量采购', amount: '3,200,000', signDate: '2024-05-10', expiryDate: '2025-05-09', status: '履行中' }, { code: 'HT-2024-031', name: '对讲机设备合同', amount: '720,000', signDate: '2024-07-01', expiryDate: '2025-06-30', status: '履行中' }]

const batchOrderData: BatchOrder[] = [
  { code: 'DD-2024-105', items: '防弹背心×200、防刺服×300、警用头盔×150', totalAmount: '2,280,000', orderDate: '2024-06-01', status: '已完成', deliveries: [
    { code: 'SH-2024-089', quantity: 400, deliveryDate: '2024-06-05', trackingNo: 'SF1234567890', status: '已签收', equipItems: [{ name: '防弹背心', spec: 'BV-III-A', quantity: 200, unit: '件' }, { name: '防刺服', spec: 'FC-01软质', quantity: 150, unit: '件' }, { name: '警用头盔', spec: 'MICH2000', quantity: 50, unit: '顶' }], receives: [
      { code: 'RS-2024-067', quantity: 400, receiveDate: '2024-06-08', receiver: '张警官', status: '已验收', equipItems: [{ name: '防弹背心', spec: 'BV-III-A', quantity: 200, unit: '件' }, { name: '防刺服', spec: 'FC-01软质', quantity: 150, unit: '件' }, { name: '警用头盔', spec: 'MICH2000', quantity: 50, unit: '顶' }] }
    ] },
    { code: 'SH-2024-092', quantity: 250, deliveryDate: '2024-06-18', trackingNo: 'SF1234567891', status: '已签收', equipItems: [{ name: '防弹背心', spec: 'BV-III-A', quantity: 0, unit: '件' }, { name: '防刺服', spec: 'FC-01软质', quantity: 150, unit: '件' }, { name: '警用头盔', spec: 'MICH2000', quantity: 100, unit: '顶' }], receives: [
      { code: 'RS-2024-073', quantity: 250, receiveDate: '2024-06-21', receiver: '李警官', status: '已验收', equipItems: [{ name: '防弹背心', spec: 'BV-III-A', quantity: 0, unit: '件' }, { name: '防刺服', spec: 'FC-01软质', quantity: 150, unit: '件' }, { name: '警用头盔', spec: 'MICH2000', quantity: 100, unit: '顶' }] }
    ] }
  ] },
  { code: 'DD-2024-112', items: '执法记录仪×150、对讲机×100', totalAmount: '760,000', orderDate: '2024-06-15', status: '已完成', deliveries: [
    { code: 'SH-2024-095', quantity: 150, deliveryDate: '2024-06-20', trackingNo: 'SF1234567892', status: '已签收', equipItems: [{ name: '执法记录仪', spec: 'ZF-01高清', quantity: 150, unit: '台' }], receives: [
      { code: 'RS-2024-080', quantity: 150, receiveDate: '2024-06-23', receiver: '王警官', status: '已验收', equipItems: [{ name: '执法记录仪', spec: 'ZF-01高清', quantity: 150, unit: '台' }] }
    ] },
    { code: 'SH-2024-098', quantity: 100, deliveryDate: '2024-06-25', trackingNo: 'SF1234567893', status: '已签收', equipItems: [{ name: '对讲机', spec: 'DJ-01数字', quantity: 100, unit: '台' }], receives: [
      { code: 'RS-2024-085', quantity: 100, receiveDate: '2024-06-27', receiver: '赵警官', status: '已验收', equipItems: [{ name: '对讲机', spec: 'DJ-01数字', quantity: 100, unit: '台' }] }
    ] }
  ] },
  { code: 'DD-2024-128', items: '防刺服×500、防弹背心×100、警用头盔×200', totalAmount: '2,120,000', orderDate: '2024-07-01', status: '部分发货', deliveries: [
    { code: 'SH-2024-102', quantity: 400, deliveryDate: '2024-07-08', trackingNo: 'SF1234567894', status: '已签收', equipItems: [{ name: '防刺服', spec: 'FC-01软质', quantity: 300, unit: '件' }, { name: '防弹背心', spec: 'BV-III-A', quantity: 100, unit: '件' }], receives: [
      { code: 'RS-2024-086', quantity: 400, receiveDate: '2024-07-10', receiver: '赵警官', status: '已验收', equipItems: [{ name: '防刺服', spec: 'FC-01软质', quantity: 300, unit: '件' }, { name: '防弹背心', spec: 'BV-III-A', quantity: 100, unit: '件' }] }
    ] },
    { code: 'SH-2024-110', quantity: 200, deliveryDate: '2024-07-15', trackingNo: 'SF1234567895', status: '运输中', equipItems: [{ name: '警用头盔', spec: 'MICH2000', quantity: 200, unit: '顶' }], receives: [
      { code: 'RS-2024-090', quantity: 200, receiveDate: '待收货', receiver: '-', status: '待验收', equipItems: [{ name: '警用头盔', spec: 'MICH2000', quantity: 200, unit: '顶' }] }
    ] },
    { code: 'SH-2024-115', quantity: 200, deliveryDate: '待发货', trackingNo: '-', status: '待发货', equipItems: [{ name: '防刺服', spec: 'FC-01软质', quantity: 200, unit: '件' }], receives: [] }
  ] },
  { code: 'DD-2024-135', items: '对讲机×100、执法记录仪×50、催泪喷射器×200', totalAmount: '636,000', orderDate: '2024-07-10', status: '部分发货', deliveries: [
    { code: 'SH-2024-120', quantity: 100, deliveryDate: '2024-07-18', trackingNo: 'SF1234567896', status: '已签收', equipItems: [{ name: '对讲机', spec: 'DJ-01数字', quantity: 100, unit: '台' }], receives: [
      { code: 'RS-2024-091', quantity: 100, receiveDate: '2024-07-20', receiver: '刘警官', status: '已验收', equipItems: [{ name: '对讲机', spec: 'DJ-01数字', quantity: 100, unit: '台' }] }
    ] },
    { code: 'SH-2024-125', quantity: 50, deliveryDate: '2024-07-25', trackingNo: 'SF1234567897', status: '运输中', equipItems: [{ name: '执法记录仪', spec: 'ZF-01高清', quantity: 50, unit: '台' }], receives: [
      { code: 'RS-2024-095', quantity: 50, receiveDate: '待收货', receiver: '-', status: '待验收', equipItems: [{ name: '执法记录仪', spec: 'ZF-01高清', quantity: 50, unit: '台' }] }
    ] },
    { code: 'SH-2024-130', quantity: 200, deliveryDate: '待发货', trackingNo: '-', status: '待发货', equipItems: [{ name: '催泪喷射器', spec: 'CW-01手持式', quantity: 200, unit: '支' }], receives: [] }
  ] }
]

const ledgerColumns = [{ key: 'equipCode', title: '装备编码' }, { key: 'equipName', title: '装备名称' }, { key: 'spec', title: '规格型号' }, { key: 'warehouse', title: '所在仓库' }, { key: 'location', title: '存放位置' }, { key: 'stock', title: '库存数量' }, { key: 'inboundDate', title: '入库日期' }, { key: 'status', title: '状态', render: (v: string) => <Badge variant={v === '在库' ? 'success' : v === '出库中' ? 'warning' : 'default'}>{v}</Badge> }]
const ledgerData = [{ equipCode: 'ZB-001-001', equipName: '防弹背心', spec: 'BV-III-A', warehouse: '省厅装备仓库', location: 'A区-01架-02层', stock: 180, inboundDate: '2024-06-10', status: '在库' }, { equipCode: 'ZB-002-001', equipName: '执法记录仪', spec: 'DSJ-01', warehouse: '省厅装备仓库', location: 'B区-03架-01层', stock: 145, inboundDate: '2024-06-22', status: '在库' }, { equipCode: 'ZB-003-001', equipName: '防刺服', spec: 'FC-II-B', warehouse: '省厅装备仓库', location: 'C区-02架-03层', stock: 480, inboundDate: '2024-07-09', status: '在库' }, { equipCode: 'ZB-004-001', equipName: '对讲机', spec: 'DJ-8800', warehouse: '省厅装备仓库', location: 'D区-01架-01层', stock: 95, inboundDate: '2024-07-12', status: '在库' }, { equipCode: 'ZB-005-001', equipName: '警用头盔', spec: 'MICH2000', warehouse: '省厅装备仓库', location: 'A区-02架-01层', stock: 280, inboundDate: '2024-05-15', status: '在库' }]

const outboundColumns = [{ key: 'code', title: '出库单号' }, { key: 'equipName', title: '装备名称' }, { key: 'quantity', title: '出库数量' }, { key: 'outboundDate', title: '出库日期' }, { key: 'recipient', title: '领用单位' }, { key: 'type', title: '出库类型', render: (v: string) => <Badge variant={v === '领用出库' ? 'info' : v === '调拨出库' ? 'warning' : 'default'}>{v}</Badge> }, { key: 'operator', title: '操作人' }]
const outboundData = [{ code: 'CK-2024-203', equipName: '防弹背心', quantity: 20, outboundDate: '2024-06-15', recipient: '某市公安局', type: '领用出库', operator: '赵警官' }, { code: 'CK-2024-215', equipName: '执法记录仪', quantity: 5, outboundDate: '2024-06-25', recipient: '某区分局', type: '调拨出库', operator: '钱警官' }, { code: 'CK-2024-228', equipName: '防弹背心', quantity: 15, outboundDate: '2024-07-01', recipient: '某县局', type: '领用出库', operator: '孙警官' }, { code: 'CK-2024-235', equipName: '警用头盔', quantity: 20, outboundDate: '2024-07-15', recipient: '某派出所', type: '领用出库', operator: '李警官' }]

/* ═══════════════════════════════════════════
   辅助函数
   ═══════════════════════════════════════════ */

function StatusBadge({ status }: { status: string }) { return <Badge variant={status === '启用' ? 'success' : 'default'}>{status}</Badge> }
function RatingStars({ rating }: { rating: number }) { return <div className="flex items-center gap-0.5">{[1,2,3,4,5].map((i) => <svg key={i} width="12" height="12" viewBox="0 0 24 24" fill={i <= Math.floor(rating) ? '#F59E0B' : '#E5E7EB'} stroke="none"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>)}<span className="ml-1 text-xs text-[#F59E0B] font-medium">{rating}</span></div> }
function SimpleTable({ columns, data }: { columns: any[]; data: Record<string, any>[] }) { return <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">{columns.map((c) => <th key={c.key} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{c.title}</th>)}</tr></thead><tbody>{data.map((row, idx) => <tr key={idx} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">{columns.map((c) => <td key={c.key} className="px-3 py-2.5 text-[#374151]">{c.render ? c.render(row[c.key]) : row[c.key]}</td>)}</tr>)}</tbody></table>{data.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无数据</div>}</div> }

function AuditStatusBadge({ status }: { status: string }) {
  switch (status) {
    case '待审核': return <Badge variant="warning">待审核</Badge>
    case '已通过': return <Badge variant="success">已通过</Badge>
    case '已驳回': return <Badge variant="danger">已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function EquipItemsTable({ items }: { items: EquipItem[] }) {
  if (!items || items.length === 0) return null
  return <div className="mt-2 rounded-md border border-[#E5E7EB] bg-white overflow-hidden">
    <table className="w-full text-xs">
      <thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
        <th className="px-2 py-1.5 text-left font-semibold text-[#6B7280]">装备名称</th>
        <th className="px-2 py-1.5 text-left font-semibold text-[#6B7280]">规格型号</th>
        <th className="px-2 py-1.5 text-left font-semibold text-[#6B7280]">数量</th>
        <th className="px-2 py-1.5 text-left font-semibold text-[#6B7280]">单位</th>
      </tr></thead>
      <tbody>{items.map((item, idx) => (
        <tr key={idx} className="border-b border-[#F3F4F6] last:border-0">
          <td className="px-2 py-1.5 font-medium text-[#374151]">{item.name}</td>
          <td className="px-2 py-1.5 text-[#6B7280]">{item.spec}</td>
          <td className="px-2 py-1.5 font-medium text-[#1A56DB]">{item.quantity}</td>
          <td className="px-2 py-1.5 text-[#6B7280]">{item.unit}</td>
        </tr>
      ))}</tbody>
    </table>
  </div>
}

function OrderTable({ orders }: { orders: BatchOrder[] }) {
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const oV = (s: string) => s === '已完成' ? 'success' : s === '部分发货' ? 'warning' : 'info'
  const dV = (s: string) => s === '已签收' ? 'success' : s === '运输中' ? 'info' : 'default'
  const rV = (s: string) => s === '已验收' ? 'success' : s === '待验收' ? 'warning' : 'default'
  return <div className="overflow-x-auto">
    <table className="w-full text-sm">
      <thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
        <th className="px-3 py-2.5 w-10"></th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">订单编号</th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">装备明细</th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">总金额</th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">下单日期</th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">状态</th>
        <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">发货批次</th>
      </tr></thead>
      <tbody>{orders.map((o) => <>
        <tr key={o.code} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB] cursor-pointer" onClick={() => setExpandedId(expandedId === o.code ? null : o.code)}>
          <td className="px-3 py-2.5">{expandedId === o.code ? <ChevronUp size={14} className="text-[#1A56DB]" /> : <ChevronDown size={14} className="text-[#6B7280]" />}</td>
          <td className="px-3 py-2.5 font-medium text-[#1A56DB]">{o.code}</td>
          <td className="px-3 py-2.5 text-[#374151] max-w-[300px] truncate">{o.items}</td>
          <td className="px-3 py-2.5 font-medium">¥{o.totalAmount}</td>
          <td className="px-3 py-2.5">{o.orderDate}</td>
          <td className="px-3 py-2.5"><Badge variant={oV(o.status)}>{o.status}</Badge></td>
          <td>{o.deliveries.length}批</td>
        </tr>
        {expandedId === o.code && <tr>
          <td colSpan={7} className="px-3 py-0">
            <div className="my-2 ml-8 rounded-lg border border-[#E8F0FE] bg-[#F8FAFF] p-3">
              <div className="mb-2 flex items-center gap-1.5 text-sm font-medium text-[#1A56DB]"><Truck size={14} />关联发货单</div>
              {o.deliveries.map((d) => <div key={d.code} className="mb-3 rounded-md border border-[#E5E7EB] bg-white p-3">
                <div className="flex items-center gap-3 text-xs mb-2">
                  <span className="font-medium text-[#1A56DB]">{d.code}</span>
                  <span>数量：{d.quantity}</span>
                  <span>日期：{d.deliveryDate}</span>
                  <span>物流：{d.trackingNo}</span>
                  <Badge variant={dV(d.status)}>{d.status}</Badge>
                </div>
                {d.equipItems && d.equipItems.length > 0 && <div className="mb-2">
                  <div className="mb-1 flex items-center gap-1 text-xs font-medium text-[#6B7280]"><Package size={12} />发货装备明细</div>
                  <EquipItemsTable items={d.equipItems} />
                </div>}
                {d.receives.length > 0 && <div className="mt-2 ml-4 border-t border-[#F3F4F6] pt-2">
                  <div className="mb-2 text-xs font-medium text-[#059669]"><ClipboardCheck size={12} className="mr-1 inline" />对应收货单</div>
                  {d.receives.map((r) => <div key={r.code} className="mb-3 rounded-md border border-[#E5E7EB] bg-[#F9FAFB] p-2">
                    <div className="flex items-center gap-3 text-xs mb-2">
                      <span className="font-medium text-[#1A56DB]">{r.code}</span>
                      <span>数量：{r.quantity}</span>
                      <span>日期：{r.receiveDate}</span>
                      <span>收货人：{r.receiver}</span>
                      <Badge variant={rV(r.status)}>{r.status}</Badge>
                    </div>
                    {r.equipItems && r.equipItems.length > 0 && <div>
                      <div className="mb-1 flex items-center gap-1 text-xs font-medium text-[#6B7280]"><Package size={12} />收货装备明细</div>
                      <EquipItemsTable items={r.equipItems} />
                    </div>}
                  </div>)}
                </div>}
              </div>)}
            </div>
          </td>
        </tr>}
      </>)}</tbody>
    </table>
  </div>
}


/* ═══════════════════════════════════════════
   新增投诉弹窗（含处罚选项）
   ═══════════════════════════════════════════ */

function CreateComplaintModal({
  open,
  onClose,
  onSave,
  supplier,
}: {
  open: boolean
  onClose: () => void
  onSave: (complaint: Complaint) => void
  supplier: Supplier | null
}) {
  const [type, setType] = useState('')
  const [content, setContent] = useState('')
  const [complainant, setComplainant] = useState('')
  const [hasPunishment, setHasPunishment] = useState(false)
  const [punishmentType, setPunishmentType] = useState('')
  const [punishmentReason, setPunishmentReason] = useState('')
  const [punishmentPeriod, setPunishmentPeriod] = useState('')

  if (!open || !supplier) return null

  const code = `TS${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const handleSave = () => {
    if (!type) { alert('请选择投诉类型'); return }
    if (!content.trim()) { alert('请填写投诉内容'); return }
    if (!complainant.trim()) { alert('请填写投诉人'); return }
    if (hasPunishment) {
      if (!punishmentType) { alert('请选择处罚类型'); return }
      if (!punishmentReason.trim()) { alert('请填写处罚原因'); return }
      if (!punishmentPeriod.trim()) { alert('请填写有效期限'); return }
    }

    onSave({
      id: String(Date.now()),
      code,
      supplierId: supplier.id,
      supplierName: supplier.name,
      type,
      content,
      complainant,
      complaintDate: new Date().toISOString().slice(0, 10),
      status: '待处理',
      auditStatus: '待审核',
      hasPunishment,
      ...(hasPunishment ? {
        punishmentType,
        punishmentReason,
        punishmentPeriod,
      } : {}),
    })

    // Reset
    setType('')
    setContent('')
    setComplainant('')
    setHasPunishment(false)
    setPunishmentType('')
    setPunishmentReason('')
    setPunishmentPeriod('')
    onClose()
  }

  const complaintTypes = ['质量问题', '交货延迟', '售后服务', '其他']
  const punishmentTypes = ['警告', '暂停合作', '终止合作', '罚款']

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[640px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">新增投诉</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto px-6 py-4 space-y-4">
          {/* 基本信息 */}
          <div className="rounded-lg border border-[#E5E7EB] p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]">
              <div className="h-4 w-1 rounded-full bg-[#059669]" />
              基本信息
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">投诉单号</label>
              <input type="text" value={code} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">供应商</label>
              <input type="text" value={supplier.name} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">投诉类型 <span className="text-[#EF4444]">*</span></label>
              <select
                value={type}
                onChange={e => setType(e.target.value)}
                className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
              >
                <option value="">请选择</option>
                {complaintTypes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">投诉内容 <span className="text-[#EF4444]">*</span></label>
              <textarea
                value={content}
                onChange={e => setContent(e.target.value)}
                placeholder="请输入投诉内容..."
                rows={3}
                className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-[#6B7280]">投诉人 <span className="text-[#EF4444]">*</span></label>
              <input
                type="text"
                value={complainant}
                onChange={e => setComplainant(e.target.value)}
                placeholder="请输入投诉人姓名"
                className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
              />
            </div>
          </div>

          {/* 是否处罚 */}
          <div className="rounded-lg border border-[#E5E7EB] p-4">
            <div className="mb-3 flex items-center gap-2">
              <input
                type="checkbox"
                id="hasPunishment"
                checked={hasPunishment}
                onChange={e => setHasPunishment(e.target.checked)}
                className="h-4 w-4 rounded border-[#D1D5DB]"
              />
              <label htmlFor="hasPunishment" className="text-sm font-semibold text-[#374151]">
                是否进行处罚
              </label>
            </div>

            {hasPunishment && (
              <div className="space-y-3 border-t border-[#F3F4F6] pt-3">
                <div className="text-sm font-semibold text-[#DC2626] flex items-center gap-2">
                  <div className="h-4 w-1 rounded-full bg-[#DC2626]" />
                  处罚信息
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">处罚类型 <span className="text-[#EF4444]">*</span></label>
                  <select
                    value={punishmentType}
                    onChange={e => setPunishmentType(e.target.value)}
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
                  >
                    <option value="">请选择</option>
                    {punishmentTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">处罚原因 <span className="text-[#EF4444]">*</span></label>
                  <textarea
                    value={punishmentReason}
                    onChange={e => setPunishmentReason(e.target.value)}
                    placeholder="请输入处罚原因..."
                    rows={2}
                    className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">有效期限 <span className="text-[#EF4444]">*</span></label>
                  <input
                    type="text"
                    value={punishmentPeriod}
                    onChange={e => setPunishmentPeriod(e.target.value)}
                    placeholder="如：2024-01-01至2024-06-30"
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">提交</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   新增处罚弹窗
   ═══════════════════════════════════════════ */

function CreatePunishmentModal({
  open,
  onClose,
  onSave,
  supplier,
}: {
  open: boolean
  onClose: () => void
  onSave: (punishment: Punishment) => void
  supplier: Supplier | null
}) {
  const [type, setType] = useState('')
  const [reason, setReason] = useState('')
  const [effectivePeriod, setEffectivePeriod] = useState('')
  const [relatedComplaintCode, setRelatedComplaintCode] = useState('')

  if (!open || !supplier) return null

  const code = `CF${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const handleSave = () => {
    if (!type) { alert('请选择处罚类型'); return }
    if (!reason.trim()) { alert('请填写处罚原因'); return }
    if (!effectivePeriod.trim()) { alert('请填写有效期限'); return }

    onSave({
      id: String(Date.now()),
      code,
      supplierId: supplier.id,
      supplierName: supplier.name,
      type,
      reason,
      decisionDate: new Date().toISOString().slice(0, 10),
      effectivePeriod,
      status: '生效中',
      auditStatus: '待审核',
      ...(relatedComplaintCode ? { relatedComplaintCode } : {}),
    })

    // Reset
    setType('')
    setReason('')
    setEffectivePeriod('')
    setRelatedComplaintCode('')
    onClose()
  }

  const punishmentTypes = ['警告', '暂停合作', '终止合作', '罚款']

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[640px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">新增处罚</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto px-6 py-4 space-y-4">
          {/* 基本信息 */}
          <div className="rounded-lg border border-[#E5E7EB] p-4">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]">
              <div className="h-4 w-1 rounded-full bg-[#059669]" />
              基本信息
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">处罚单号</label>
              <input type="text" value={code} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">供应商</label>
              <input type="text" value={supplier.name} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">处罚类型 <span className="text-[#EF4444]">*</span></label>
              <select
                value={type}
                onChange={e => setType(e.target.value)}
                className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
              >
                <option value="">请选择</option>
                {punishmentTypes.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">处罚原因 <span className="text-[#EF4444]">*</span></label>
              <textarea
                value={reason}
                onChange={e => setReason(e.target.value)}
                placeholder="请输入处罚原因..."
                rows={3}
                className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]"
              />
            </div>
            <div className="mb-3">
              <label className="mb-1 block text-xs text-[#6B7280]">有效期限 <span className="text-[#EF4444]">*</span></label>
              <input
                type="text"
                value={effectivePeriod}
                onChange={e => setEffectivePeriod(e.target.value)}
                placeholder="如：2024-01-01至2024-06-30"
                className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs text-[#6B7280]">关联投诉单号</label>
              <input
                type="text"
                value={relatedComplaintCode}
                onChange={e => setRelatedComplaintCode(e.target.value)}
                placeholder="请输入关联投诉单号（选填）"
                className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">提交</button>
        </div>
      </div>
    </div>
  )
}


/* ═══════════════════════════════════════════
   投诉列表（带审核状态筛选）
   ═══════════════════════════════════════════ */

function ComplaintList({
  complaints,
  supplierId,
  onAdd,
}: {
  complaints: Complaint[]
  supplierId: string
  onAdd: () => void
}) {
  const [auditFilter, setAuditFilter] = useState('全部')
  const filters = ['全部', '待审核', '已通过', '已驳回']

  const filtered = auditFilter === '全部'
    ? complaints.filter(c => c.supplierId === supplierId)
    : complaints.filter(c => c.supplierId === supplierId && c.auditStatus === auditFilter)

  const complaintColumns = [
    { key: 'code', title: '投诉编号' },
    { key: 'type', title: '投诉类型', render: (v: string) => <Badge variant={v === '质量问题' ? 'danger' : v === '交货延迟' ? 'warning' : 'info'}>{v}</Badge> },
    { key: 'content', title: '投诉内容' },
    { key: 'complainant', title: '投诉人' },
    { key: 'complaintDate', title: '投诉日期' },
    { key: 'status', title: '处理状态', render: (v: string) => <Badge variant={v === '已处理' ? 'success' : v === '处理中' ? 'warning' : 'default'}>{v}</Badge> },
    { key: 'auditStatus', title: '审核状态', render: (v: string) => <AuditStatusBadge status={v} /> },
  ]

  return (
    <div>
      {/* Filter tabs + Add button */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-1 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] p-1">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setAuditFilter(f)}
              className={cn(
                'rounded-md px-3 py-1.5 text-sm transition',
                auditFilter === f ? 'bg-[#1A56DB] text-white' : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <button
          onClick={onAdd}
          className="inline-flex h-8 items-center gap-1 rounded-md bg-[#DC2626] px-3 text-sm text-white transition hover:bg-[#B91C1C]"
        >
          <AlertTriangle size={13} /> 新增投诉
        </button>
      </div>
      <SimpleTable columns={complaintColumns} data={filtered} />
    </div>
  )
}

/* ═══════════════════════════════════════════
   处罚列表（带审核状态筛选）
   ═══════════════════════════════════════════ */

function PunishmentList({
  punishments,
  supplierId,
  onAdd,
}: {
  punishments: Punishment[]
  supplierId: string
  onAdd: () => void
}) {
  const [auditFilter, setAuditFilter] = useState('全部')
  const filters = ['全部', '待审核', '已通过', '已驳回']

  const filtered = auditFilter === '全部'
    ? punishments.filter(p => p.supplierId === supplierId)
    : punishments.filter(p => p.supplierId === supplierId && p.auditStatus === auditFilter)

  const punishmentColumns = [
    { key: 'code', title: '处罚编号' },
    { key: 'type', title: '处罚类型', render: (v: string) => <Badge variant={v === '警告' ? 'warning' : v === '暂停合作' ? 'danger' : v === '终止合作' ? 'danger' : 'default'}>{v}</Badge> },
    { key: 'reason', title: '处罚原因' },
    { key: 'decisionDate', title: '决定日期' },
    { key: 'effectivePeriod', title: '有效期限' },
    { key: 'status', title: '状态', render: (v: string) => <Badge variant={v === '生效中' ? 'danger' : v === '已解除' ? 'success' : 'default'}>{v}</Badge> },
    { key: 'auditStatus', title: '审核状态', render: (v: string) => <AuditStatusBadge status={v} /> },
  ]

  return (
    <div>
      {/* Filter tabs + Add button */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-1 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] p-1">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setAuditFilter(f)}
              className={cn(
                'rounded-md px-3 py-1.5 text-sm transition',
                auditFilter === f ? 'bg-[#1A56DB] text-white' : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {f}
            </button>
          ))}
        </div>
        <button
          onClick={onAdd}
          className="inline-flex h-8 items-center gap-1 rounded-md bg-[#DC2626] px-3 text-sm text-white transition hover:bg-[#B91C1C]"
        >
          <Gavel size={13} /> 新增处罚
        </button>
      </div>
      <SimpleTable columns={punishmentColumns} data={filtered} />
    </div>
  )
}

/* ═══════════════════════════════════════════
   供应商详情抽屉
   ═══════════════════════════════════════════ */

function SupplierDetailDrawer({
  supplier,
  onClose,
  complaints,
  punishments,
  onAddComplaint,
  onAddPunishment,
}: {
  supplier: Supplier | null
  onClose: () => void
  complaints: Complaint[]
  punishments: Punishment[]
  onAddComplaint: () => void
  onAddPunishment: () => void
}) {
  const [activeTab, setActiveTab] = useState<DetailTab>('archive')
  if (!supplier) return null

  const tabConfig = [
    { key: 'archive' as DetailTab, label: '企业档案', icon: <Archive size={14} /> },
    { key: 'contract' as DetailTab, label: '装备合同', icon: <FileText size={14} /> },
    { key: 'order' as DetailTab, label: '装备订单', icon: <ShoppingCart size={14} /> },
    { key: 'ledger' as DetailTab, label: '仓库台账', icon: <Package size={14} /> },
    { key: 'outbound' as DetailTab, label: '装备出库', icon: <ArrowUpCircle size={14} /> },
    { key: 'complaint' as DetailTab, label: '投诉信息', icon: <AlertTriangle size={14} /> },
    { key: 'punishment' as DetailTab, label: '处罚信息', icon: <Gavel size={14} /> },
  ]

  const isOrderTab = activeTab === 'order'
  const isArchiveTab = activeTab === 'archive'
  const isComplaintTab = activeTab === 'complaint'
  const isPunishmentTab = activeTab === 'punishment'

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-full w-[900px] max-w-[95vw] flex-col bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">{supplier.name}</h2>
            <p className="text-xs text-[#6B7280]">{supplier.creditCode} · {supplier.type}</p>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]">
            <X size={18} />
          </button>
        </div>

        {/* Stats cards */}
        <div className="grid grid-cols-4 gap-3 border-b border-[#E5E7EB] bg-[#F9FAFB] px-6 py-3">
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">合同数量</div>
            <div className="text-xl font-bold text-[#1A56DB]">{supplier.contracts}</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">履约率</div>
            <div className="text-xl font-bold text-[#10B981]">{supplier.performance}%</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">综合评分</div>
            <div className="mt-1"><RatingStars rating={supplier.rating} /></div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">联系人</div>
            <div className="mt-1 text-sm font-medium text-[#374151]">{supplier.contact} / {supplier.phone}</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex shrink-0 gap-0 border-b border-[#E5E7EB] bg-white px-6 overflow-x-auto">
          {tabConfig.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'flex items-center gap-1.5 whitespace-nowrap px-4 py-3 text-sm font-medium transition border-b-2',
                activeTab === tab.key ? 'border-[#1A56DB] text-[#1A56DB]' : 'border-transparent text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.icon}{tab.label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6">
          {isArchiveTab ? (
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h4 className="mb-3 flex items-center gap-1.5 text-sm font-semibold"><User size={16} className="text-[#1A56DB]" />企业基本信息</h4>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 space-y-2">
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">统一社会信用代码</span><span className="text-sm text-[#374151]">{supplier.creditCode}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">注册地址</span><span className="text-sm text-[#374151]">{supplier.regAddress}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">法定代表人</span><span className="text-sm text-[#374151]">{supplier.legalPerson}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">供应商类型</span><span className="text-sm text-[#374151]">{supplier.type}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">联系人</span><span className="text-sm text-[#374151]">{supplier.contact}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">证件类型</span><span className="text-sm text-[#374151]">{supplier.idType}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">证件号码</span><span className="text-sm text-[#374151]">{supplier.idNumber}</span></div>
                  <div className="flex justify-between py-1 border-b border-[#F3F4F6]"><span className="text-xs text-[#6B7280]">联系电话</span><span className="text-sm text-[#374151]">{supplier.phone}</span></div>
                  <div className="flex justify-between py-1"><span className="text-xs text-[#6B7280]">电子邮箱</span><span className="text-sm text-[#374151]">{supplier.email}</span></div>
                </div>
              </div>
              <div>
                <h4 className="mb-3 flex items-center gap-1.5 text-sm font-semibold"><FileText size={16} className="text-[#1A56DB]" />资质证件档案</h4>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 space-y-2">
                  {['营业执照副本', '法定代表人身份证', '相关生产经营资质许可证', '"信用中国"信用信息报告', '"中国政府采购网"信用查询截图'].map((label) => (
                    <div key={label} className="flex items-center justify-between py-2 border-b border-[#F3F4F6] last:border-0">
                      <span className="text-sm text-[#374151]">{label}</span>
                      <div className="flex items-center gap-2"><Badge variant="success">已上传</Badge><button className="text-xs text-[#1A56DB] hover:underline">预览</button></div>
                    </div>
                  ))}
                </div>
                <h4 className="mb-3 mt-4 flex items-center gap-1.5 text-sm font-semibold"><Award size={16} className="text-[#1A56DB]" />资质认证</h4>
                <div className="flex flex-wrap gap-2">{supplier.credentials.map((c) => <Badge key={c} variant="success">{c}</Badge>)}</div>
              </div>
            </div>
          ) : isOrderTab ? (
            <OrderTable orders={batchOrderData} />
          ) : isComplaintTab ? (
            <ComplaintList complaints={complaints} supplierId={supplier.id} onAdd={onAddComplaint} />
          ) : isPunishmentTab ? (
            <PunishmentList punishments={punishments} supplierId={supplier.id} onAdd={onAddPunishment} />
          ) : (
            <SimpleTable
              columns={activeTab === 'contract' ? contractColumns : activeTab === 'ledger' ? ledgerColumns : outboundColumns}
              data={activeTab === 'contract' ? contractData : activeTab === 'ledger' ? ledgerData : outboundData}
            />
          )}
        </div>
      </div>
    </div>
  )
}


/* ═══════════════════════════════════════════
   新增供应商弹窗
   ═══════════════════════════════════════════ */

function AddSupplierModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [form, setForm] = useState({ companyName: '', loginAccount: '', password: '', confirmPassword: '', contactPerson: '', contactPhone: '' })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const validate = () => { const e: Record<string, string> = {}; if (!form.companyName.trim()) e.companyName = '请输入企业名称'; if (!form.loginAccount.trim()) e.loginAccount = '请输入登录账号'; if (!form.password) e.password = '请输入密码'; else if (form.password.length < 6) e.password = '密码至少6位'; if (!form.confirmPassword) e.confirmPassword = '请确认密码'; else if (form.password !== form.confirmPassword) e.confirmPassword = '两次密码不一致'; if (!form.contactPerson.trim()) e.contactPerson = '请输入联系人'; if (!form.contactPhone.trim()) e.contactPhone = '请输入联系电话'; else if (!/^1\d{10}$/.test(form.contactPhone)) e.contactPhone = '手机号格式不正确'; setErrors(e); return Object.keys(e).length === 0 }
  const handleSubmit = () => { if (validate()) { onClose(); setForm({ companyName: '', loginAccount: '', password: '', confirmPassword: '', contactPerson: '', contactPhone: '' }); setErrors({}) } }
  const update = (field: string, value: string) => { setForm((p) => ({ ...p, [field]: value })); if (errors[field]) setErrors((p) => { const n = { ...p }; delete n[field]; return n }) }
  if (!open) return null
  const ic = (f: string) => cn('h-10 w-full rounded-md border px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10', errors[f] ? 'border-[#EF4444]' : 'border-[#D1D5DB]')
  return <div className="fixed inset-0 z-50 flex items-center justify-center"><div className="absolute inset-0 bg-black/50" onClick={onClose} /><div className="relative z-10 w-[520px] max-w-[95vw] rounded-xl bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4"><h2 className="text-base font-semibold text-[#1F2937]">新增供应商</h2><button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={16} /></button></div><div className="space-y-4 p-6"><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 企业名称</label><input type="text" placeholder="请输入企业全称" value={form.companyName} onChange={(e) => update('companyName', e.target.value)} className={ic('companyName')} />{errors.companyName && <p className="mt-1 text-xs text-[#EF4444]">{errors.companyName}</p>}</div><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 登录账号</label><input type="text" placeholder="请输入系统登录账号" value={form.loginAccount} onChange={(e) => update('loginAccount', e.target.value)} className={ic('loginAccount')} />{errors.loginAccount && <p className="mt-1 text-xs text-[#EF4444]">{errors.loginAccount}</p>}</div><div className="grid grid-cols-2 gap-4"><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 设置密码</label><input type="password" placeholder="至少6位字符" value={form.password} onChange={(e) => update('password', e.target.value)} className={ic('password')} />{errors.password && <p className="mt-1 text-xs text-[#EF4444]">{errors.password}</p>}</div><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 确认密码</label><input type="password" placeholder="再次输入密码" value={form.confirmPassword} onChange={(e) => update('confirmPassword', e.target.value)} className={ic('confirmPassword')} />{errors.confirmPassword && <p className="mt-1 text-xs text-[#EF4444]">{errors.confirmPassword}</p>}</div></div><div className="grid grid-cols-2 gap-4"><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 联系人</label><input type="text" placeholder="请输入联系人姓名" value={form.contactPerson} onChange={(e) => update('contactPerson', e.target.value)} className={ic('contactPerson')} />{errors.contactPerson && <p className="mt-1 text-xs text-[#EF4444]">{errors.contactPerson}</p>}</div><div><label className="mb-1.5 block text-sm font-medium text-[#374151]"><span className="text-[#EF4444]">*</span> 联系电话</label><input type="text" placeholder="请输入手机号" value={form.contactPhone} onChange={(e) => update('contactPhone', e.target.value)} className={ic('contactPhone')} />{errors.contactPhone && <p className="mt-1 text-xs text-[#EF4444]">{errors.contactPhone}</p>}</div></div></div><div className="flex items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4"><button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button><button onClick={handleSubmit} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">确认</button></div></div></div>
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function SupplierPage() {
  const [searchName, setSearchName] = useState('')
  const [searchCode, setSearchCode] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [detailSupplier, setDetailSupplier] = useState<Supplier | null>(null)
  const [showAddModal, setShowAddModal] = useState(false)

  // 投诉和处罚数据状态
  const [complaints, setComplaints] = useState<Complaint[]>(initialComplaints)
  const [punishments, setPunishments] = useState<Punishment[]>(initialPunishments)
  const [showComplaintModal, setShowComplaintModal] = useState(false)
  const [showPunishmentModal, setShowPunishmentModal] = useState(false)

  // 主页面直接新增投诉/处罚时选择的供应商
  const [mainPageSupplier, setMainPageSupplier] = useState<Supplier | null>(null)

  const pageSize = 10
  const filtered = mockSuppliers.filter((s) => {
    if (searchName && !s.name.includes(searchName)) return false
    if (searchCode && !s.creditCode.includes(searchCode)) return false
    if (statusFilter && s.status !== statusFilter) return false
    return true
  })
  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const handleAddComplaint = (complaint: Complaint) => {
    setComplaints(prev => [complaint, ...prev])
    // 如果投诉中包含处罚信息，也同步添加到处罚列表
    if (complaint.hasPunishment && complaint.punishmentType) {
      const punishmentCode = `CF${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`
      setPunishments(prev => [{
        id: String(Date.now() + 1),
        code: punishmentCode,
        supplierId: complaint.supplierId,
        supplierName: complaint.supplierName,
        type: complaint.punishmentType!,
        reason: complaint.punishmentReason || '',
        decisionDate: new Date().toISOString().slice(0, 10),
        effectivePeriod: complaint.punishmentPeriod || '',
        status: '生效中',
        auditStatus: '待审核',
        relatedComplaintCode: complaint.code,
      }, ...prev])
    }
  }

  const handleAddPunishment = (punishment: Punishment) => {
    setPunishments(prev => [punishment, ...prev])
  }

  return (
    <div>
      {/* Header */}
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">供应商信息</h1>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowAddModal(true)} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 新增供应商</button>
          <button onClick={() => { const firstSupplier = mockSuppliers.find(s => s.status === '启用'); setMainPageSupplier(firstSupplier || mockSuppliers[0]); setShowPunishmentModal(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#DC2626] px-3 text-sm text-white transition hover:bg-[#B91C1C]"><Gavel size={14} /> 新增处罚</button>
          <button onClick={() => { const firstSupplier = mockSuppliers.find(s => s.status === '启用'); setMainPageSupplier(firstSupplier || mockSuppliers[0]); setShowComplaintModal(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#F59E0B] px-3 text-sm text-white transition hover:bg-[#D97706]"><AlertTriangle size={14} /> 新增投诉</button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Upload size={14} /> 导入</button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Download size={14} /> 导出</button>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <input type="text" placeholder="请输入供应商名称" value={searchName} onChange={(e) => { setSearchName(e.target.value); setCurrentPage(1) }} className="h-9 w-56 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
          <input type="text" placeholder="请输入信用代码" value={searchCode} onChange={(e) => { setSearchCode(e.target.value); setCurrentPage(1) }} className="h-9 w-56 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }} className="h-9 w-32 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]"><option value="">全部状态</option><option value="启用">启用</option><option value="停用">停用</option></select>
          <button onClick={() => { setSearchName(''); setSearchCode(''); setStatusFilter(''); setCurrentPage(1) }} className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><RotateCcw size={14} /> 重置</button>
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">序号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">企业名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">统一社会信用代码</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商类型</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">法人姓名</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">联系人/电话</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">资质认证</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">合同数</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">评分</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((supplier, idx) => (
                <tr key={supplier.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[#6B7280]">{(currentPage - 1) * pageSize + idx + 1}</td>
                  <td className="px-4 py-3 font-medium text-[#1F2937]">{supplier.name}</td>
                  <td className="px-4 py-3 text-[#374151]">{supplier.creditCode}</td>
                  <td className="px-4 py-3"><Badge variant={supplier.type === '生产商' ? 'success' : supplier.type === '协议供货商' ? 'info' : 'default'}>{supplier.type}</Badge></td>
                  <td className="px-4 py-3 text-[#374151]">{supplier.legalPerson}</td>
                  <td className="px-4 py-3 text-[#374151]">{supplier.contact}<br/><span className="text-xs text-[#6B7280]">{supplier.phone}</span></td>
                  <td className="px-4 py-3"><div className="flex flex-wrap gap-1">{supplier.credentials.map(c => <Badge key={c} variant="success" className="text-[10px]">{c}</Badge>)}</div></td>
                  <td className="px-4 py-3 text-[#374151]">{supplier.contracts}</td>
                  <td className="px-4 py-3"><RatingStars rating={supplier.rating} /></td>
                  <td className="px-4 py-3"><StatusBadge status={supplier.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => setDetailSupplier(supplier)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="详情"><Eye size={14} /></button>
                      <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#D97706] transition hover:bg-[#FEF3C7]" title="编辑"><Edit3 size={14} /></button>
                      <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] transition hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条，第 {currentPage}/{totalPages} 页</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6] disabled:opacity-50"><ChevronLeft size={14} /></button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
                <button key={p} onClick={() => setCurrentPage(p)} className={cn('h-8 rounded-md px-3 text-sm', currentPage === p ? 'bg-[#1A56DB] text-white' : 'border border-[#D1D5DB] bg-white text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
              ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6] disabled:opacity-50"><ChevronRight size={14} /></button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      {detailSupplier && (
        <SupplierDetailDrawer
          supplier={detailSupplier}
          onClose={() => setDetailSupplier(null)}
          complaints={complaints}
          punishments={punishments}
          onAddComplaint={() => setShowComplaintModal(true)}
          onAddPunishment={() => setShowPunishmentModal(true)}
        />
      )}

      {/* Add Supplier Modal */}
      <AddSupplierModal open={showAddModal} onClose={() => setShowAddModal(false)} />

      {/* Create Complaint Modal */}
      <CreateComplaintModal
        open={showComplaintModal}
        onClose={() => { setShowComplaintModal(false); setMainPageSupplier(null) }}
        onSave={handleAddComplaint}
        supplier={mainPageSupplier || detailSupplier}
      />

      {/* Create Punishment Modal */}
      <CreatePunishmentModal
        open={showPunishmentModal}
        onClose={() => { setShowPunishmentModal(false); setMainPageSupplier(null) }}
        onSave={handleAddPunishment}
        supplier={mainPageSupplier || detailSupplier}
      />
    </div>
  )
}
