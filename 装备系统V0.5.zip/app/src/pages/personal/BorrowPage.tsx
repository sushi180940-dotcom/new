import { useState } from 'react'
import {
  Plus,
  Package,
  CheckCircle,
  Search,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ── types ── */
interface BorrowRecord {
  id: string
  type: string
  typeTag: 'info' | 'success' | 'warning' | 'info'
  equipment: string[]
  applyTime: string
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'default' | 'danger'
  steps: string[]
  currentStep: number
}

/* ── step progress bar ── */
function StepProgress({ steps, currentStep }: { steps: string[]; currentStep: number }) {
  return (
    <div className="flex items-center gap-1">
      {steps.map((step, i) => (
        <div key={step} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                'flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold',
                i < currentStep && 'bg-[#10B981] text-white',
                i === currentStep && 'bg-[#1A56DB] text-white',
                i > currentStep && 'border border-[#D1D5DB] text-[#9CA3AF]'
              )}
            >
              {i < currentStep ? <CheckCircle size={14} /> : i + 1}
            </div>
            <span className={cn('mt-0.5 whitespace-nowrap text-[10px]', i === currentStep ? 'font-medium text-[#1A56DB]' : 'text-[#9CA3AF]')}>
              {step}
            </span>
          </div>
          {i < steps.length - 1 && (
            <div className={cn('mb-3 ml-0.5 mr-0.5 h-0.5 w-6', i < currentStep ? 'bg-[#10B981]' : 'bg-[#E5E7EB]')} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ── mock data ── */
const ongoingRecords: BorrowRecord[] = [
  {
    id: 'LY2026001',
    type: '新警配发',
    typeTag: 'info',
    equipment: ['防弹背心 FDY-2R-01', '执法记录仪 DSJ-A7', '手铐 SK-01'],
    applyTime: '2026-05-28 10:30',
    status: '审批中',
    statusColor: 'warning',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 1,
  },
  {
    id: 'LY2026002',
    type: '装备更新',
    typeTag: 'success',
    equipment: ['对讲机 GP3688', '强光手电 SD-01'],
    applyTime: '2026-05-25 14:15',
    status: '仓库准备',
    statusColor: 'info',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 2,
  },
  {
    id: 'LY2026003',
    type: '损耗补充',
    typeTag: 'warning',
    equipment: ['防割手套 FG-ST01', '急救包 JJ-01'],
    applyTime: '2026-05-20 09:00',
    status: '待确认',
    statusColor: 'info',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 3,
  },
]

const historyRecords: BorrowRecord[] = [
  {
    id: 'LY2025105',
    type: '新警配发',
    typeTag: 'info',
    equipment: ['防弹背心 FDY-2R-01', '执法记录仪 DSJ-A7', '手铐 SK-01', '防刺服 FCF-J-AH01'],
    applyTime: '2025-08-15 10:00',
    status: '已完成',
    statusColor: 'success',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 5,
  },
  {
    id: 'LY2025098',
    type: '临时借用',
    typeTag: 'info',
    equipment: ['反光背心 FG-BX01'],
    applyTime: '2025-07-20 16:30',
    status: '已归还',
    statusColor: 'default',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '归还确认'],
    currentStep: 5,
  },
  {
    id: 'LY2025086',
    type: '专项任务',
    typeTag: 'success',
    equipment: ['对讲机 GP3688 x2', '强光手电 SD-01 x3'],
    applyTime: '2025-06-10 08:45',
    status: '已完成',
    statusColor: 'success',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 5,
  },
  {
    id: 'LY2025072',
    type: '损耗补充',
    typeTag: 'warning',
    equipment: ['急救包 JJ-01'],
    applyTime: '2025-04-22 11:20',
    status: '已驳回',
    statusColor: 'danger',
    steps: ['提交申请', '领导审批'],
    currentStep: 1,
  },
  {
    id: 'LY2025061',
    type: '装备更新',
    typeTag: 'success',
    equipment: ['执法记录仪 DSJ-A8'],
    applyTime: '2025-03-15 09:30',
    status: '已完成',
    statusColor: 'success',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'],
    currentStep: 5,
  },
]

/* ── record card ── */
function RecordCard({ record }: { record: BorrowRecord }) {
  return (
    <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-sm font-medium text-[#1A56DB]">{record.id}</span>
          <Badge variant={record.typeTag}>{record.type}</Badge>
          <Badge variant={record.statusColor === 'info' ? 'info' : record.statusColor}>{record.status}</Badge>
        </div>
        <span className="text-xs text-[#6B7280]">{record.applyTime}</span>
      </div>

      <div className="mt-3">
        <div className="text-xs font-medium text-[#6B7280]">装备清单：</div>
        <div className="mt-1 flex flex-wrap gap-1">
          {record.equipment.map((eq, i) => (
            <span key={i} className="inline-flex items-center gap-1 rounded-md bg-[#F3F4F6] px-2 py-0.5 text-xs text-[#374151]">
              <Package size={10} /> {eq}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-3">
        <StepProgress steps={record.steps} currentStep={record.currentStep} />
      </div>
    </div>
  )
}

/* ── main component ── */
export default function BorrowPage() {
  const [activeTab, setActiveTab] = useState<'ongoing' | 'history'>('ongoing')
  const [searchText, setSearchText] = useState('')

  const records = activeTab === 'ongoing' ? ongoingRecords : historyRecords
  const filteredRecords = records.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.equipment.some((e) => e.includes(searchText))
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">领用管理</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={16} />
          申请领用
        </button>
      </div>

      {/* ── Tabs ── */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('ongoing')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'ongoing' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            进行中 ({ongoingRecords.length})
            {activeTab === 'ongoing' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'history' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            历史记录 ({historyRecords.length})
            {activeTab === 'history' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
        </div>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、装备名称..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Records ── */}
      <div className="space-y-3">
        {filteredRecords.map((record) => (
          <RecordCard key={record.id} record={record} />
        ))}
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <Package size={48} className="mx-auto mb-3 opacity-30" />
            暂无记录
          </div>
        )}
      </div>
    </div>
  )
}
