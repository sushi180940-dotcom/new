import { useState } from 'react'
import {
  MessageSquareWarning,
  Search,
  Send,
  Clock,
  CheckCircle,
  AlertCircle,
  RotateCcw,
  FileCheck,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ── types ── */
interface ComplaintRecord {
  id: string
  target: string
  type: string
  typeTag: 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'default'
  summary: string
  time: string
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'danger' | 'default'
  statusIndex: number
}

/* ── timeline steps ── */
const statusSteps = ['待审核', '已受理', '处理中', '已反馈', '已结案']

function StatusTimeline({ currentIndex }: { currentIndex: number }) {
  return (
    <div className="flex items-center">
      {statusSteps.map((step, i) => (
        <div key={step} className="flex items-center">
          <div className="group relative flex flex-col items-center">
            <div
              className={cn(
                'flex h-5 w-5 items-center justify-center rounded-full border-2 text-[9px] font-bold',
                i < currentIndex && 'border-[#10B981] bg-[#10B981] text-white',
                i === currentIndex && 'border-[#1A56DB] bg-[#1A56DB] text-white',
                i > currentIndex && 'border-[#D1D5DB] bg-white text-[#9CA3AF]'
              )}
            >
              {i < currentIndex ? <CheckCircle size={10} /> : i + 1}
            </div>
            {/* Tooltip label */}
            <span className={cn(
              'mt-1 whitespace-nowrap text-[9px]',
              i === currentIndex ? 'font-medium text-[#1A56DB]' : 'text-[#9CA3AF]'
            )}>
              {step}
            </span>
          </div>
          {i < statusSteps.length - 1 && (
            <div className={cn('mb-3 ml-0.5 mr-0.5 h-0.5 w-5', i < currentIndex ? 'bg-[#10B981]' : 'bg-[#E5E7EB]')} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ── mock data ── */
const complaintRecords: ComplaintRecord[] = [
  {
    id: 'TS2026001',
    target: 'XX安防科技有限公司',
    type: '质量问题',
    typeTag: 'danger',
    summary: '采购的执法记录仪使用3个月频繁出现死机、录像丢失问题，严重影响执法工作...',
    time: '2026-05-28 09:30',
    status: '已受理',
    statusColor: 'info',
    statusIndex: 1,
  },
  {
    id: 'TS2026002',
    target: 'YY防护装备厂',
    type: '售后不及时',
    typeTag: 'warning',
    summary: '防弹背心需要保养维护，联系厂家多次无人响应，已超过约定服务时间2周...',
    time: '2026-05-20 14:00',
    status: '处理中',
    statusColor: 'warning',
    statusIndex: 2,
  },
  {
    id: 'TS2026003',
    target: 'ZZ通讯设备公司',
    type: '配件缺失',
    typeTag: 'primary',
    summary: '对讲机标配充电器与座充缺失，仅提供简易充电线，影响批量充电使用...',
    time: '2026-05-15 11:20',
    status: '已结案',
    statusColor: 'success',
    statusIndex: 4,
  },
  {
    id: 'TS2026004',
    target: 'AA防护用品厂',
    type: '性能不符',
    typeTag: 'danger',
    summary: '采购的防刺服标称防护等级二级，实际测试只能达到一级标准，存在虚假宣传...',
    time: '2026-04-28 16:45',
    status: '已反馈',
    statusColor: 'info',
    statusIndex: 3,
  },
  {
    id: 'TS2026005',
    target: 'BB科技发展有限公司',
    type: '服务态度',
    typeTag: 'default',
    summary: '售后人员态度恶劣，多次推诿责任，拒绝提供产品检测报告和质量证明文件...',
    time: '2026-04-10 10:00',
    status: '待审核',
    statusColor: 'default',
    statusIndex: 0,
  },
  {
    id: 'TS2026006',
    target: 'CC照明设备厂',
    type: '价格问题',
    typeTag: 'warning',
    summary: '同型号强光手电价格高于市场同类产品50%以上，要求退还差价或更换产品...',
    time: '2026-03-22 13:30',
    status: '已结案',
    statusColor: 'success',
    statusIndex: 4,
  },
]

/* ── main component ── */
export default function ComplaintPage() {
  const [searchText, setSearchText] = useState('')

  const filteredRecords = complaintRecords.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.target.includes(searchText) ||
      r.summary.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">我的投诉</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Send size={16} />
          提交投诉
        </button>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、投诉对象、内容..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Complaint Table ── */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">投诉单号</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">投诉对象</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">投诉类型</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">内容摘要</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">投诉时间</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">当前状态</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">进度</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.map((record) => (
              <tr
                key={record.id}
                className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]"
              >
                <td className="px-4 py-3 font-mono text-[13px] font-medium text-[#1A56DB]">
                  {record.id}
                </td>
                <td className="max-w-[140px] px-4 py-3 text-[13px] text-[#374151]">
                  <span className="line-clamp-1" title={record.target}>{record.target}</span>
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.typeTag}>{record.type}</Badge>
                </td>
                <td className="max-w-xs px-4 py-3 text-[13px] text-[#374151]">
                  <span className="line-clamp-2" title={record.summary}>
                    {record.summary}
                  </span>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-[13px] text-[#6B7280]">
                  {record.time}
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.statusColor}>{record.status}</Badge>
                </td>
                <td className="px-4 py-3">
                  <StatusTimeline currentIndex={record.statusIndex} />
                </td>
                <td className="px-4 py-3 text-center">
                  <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#1A56DB] px-2.5 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                    查看
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <MessageSquareWarning size={48} className="mx-auto mb-3 opacity-30" />
            暂无投诉记录
          </div>
        )}
      </div>

      {/* ── Legend ── */}
      <div className="flex flex-wrap items-center gap-4 text-xs text-[#6B7280]">
        <span className="font-medium">投诉流程：</span>
        <span className="inline-flex items-center gap-1"><Clock size={12} /> 待审核</span>
        <ChevronRightMini />
        <span className="inline-flex items-center gap-1"><CheckCircle size={12} /> 已受理</span>
        <ChevronRightMini />
        <span className="inline-flex items-center gap-1"><RotateCcw size={12} /> 处理中</span>
        <ChevronRightMini />
        <span className="inline-flex items-center gap-1"><AlertCircle size={12} /> 已反馈</span>
        <ChevronRightMini />
        <span className="inline-flex items-center gap-1"><FileCheck size={12} /> 已结案</span>
      </div>
    </div>
  )
}

function ChevronRightMini() {
  return <span className="text-[#D1D5DB]">&gt;</span>
}
