import { useState, useMemo } from 'react'
import {
  ShieldCheck, AlertTriangle, Ban, Search, Plus, Edit3, Eye,
  RefreshCw, Factory, X, Building2, ClipboardList, Warehouse,
  Gavel, Check, Calendar, User, Package, ChevronRight, ChevronDown, Clock,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
type TabKey = 'control' | 'supplier'
type SelectMode = 'enterprise' | 'order' | 'warehouse'

/* ─── Enterprise / Order / Equipment data ─── */
interface EquipmentItem {
  id: string
  name: string
  model: string
  qty?: number
  unit?: string
  rfid?: string
  warehouse?: string
  batchNo?: string
  storageDate?: string
}

interface OrderItem {
  id: string
  orderNo: string
  createTime: string
  supplierName: string
  totalAmount: string
  status: string
  equipments: EquipmentItem[]
}

interface EnterpriseItem {
  id: string
  name: string
  orders: OrderItem[]
}

/* ─── Warehouse tree ─── */
interface WarehouseNode {
  id: string
  name: string
  level: number
  children?: WarehouseNode[]
  equipments: EquipmentItem[]
}

/* ─── Control record (original) ─── */
interface ControlRecord {
  id: string
  problemNo: string
  equipName: string
  equipModel: string
  problemDesc: string
  findTime: string
  batchNo: string
  measure: string
  status: '生效中' | '已解除' | '待审核'
  operator: string
}

interface SupplierDisposal {
  id: string
  orderNo: string
  supplierName: string
  supplierType: string
  disposalType: string
  reason: string
  startTime: string
  endTime?: string
  scope: string
  publisher: string
  remark: string
  status: '处理中' | '已完成' | '待审核'
  handler: string
}

/* ═══════════════════════════════════════════
   Mock Data
   ═══════════════════════════════════════════ */

const mockEnterprises: EnterpriseItem[] = [
  {
    id: 'e1', name: '华东安防科技有限公司',
    orders: [
      { id: 'o1', orderNo: 'DD-2024-105', createTime: '2024-06-01', supplierName: '华东安防科技有限公司', totalAmount: '¥2,280,000', status: '已完成', equipments: [{ id: 'eq1', name: '防弹背心', model: 'BV-III-A', qty: 200, unit: '件' }, { id: 'eq2', name: '防刺服', model: 'FC-01软质', qty: 150, unit: '件' }, { id: 'eq3', name: '警用头盔', model: 'MICH2000', qty: 50, unit: '顶' }] },
      { id: 'o2', orderNo: 'DD-2024-110', createTime: '2024-08-15', supplierName: '华东安防科技有限公司', totalAmount: '¥980,000', status: '已完成', equipments: [{ id: 'eq4', name: '防弹背心', model: 'BV-III-A', qty: 100, unit: '件' }, { id: 'eq5', name: '防刺服', model: 'FC-02硬质', qty: 80, unit: '件' }] },
      { id: 'o3', orderNo: 'DD-2024-115', createTime: '2024-10-20', supplierName: '华东安防科技有限公司', totalAmount: '¥1,560,000', status: '已完成', equipments: [{ id: 'eq6', name: '警用头盔', model: 'MICH2000', qty: 200, unit: '顶' }, { id: 'eq7', name: '战术背心', model: 'TS-01', qty: 150, unit: '件' }] },
    ],
  },
  {
    id: 'e2', name: '北方装备集团有限公司',
    orders: [
      { id: 'o4', orderNo: 'DD-2024-106', createTime: '2024-06-15', supplierName: '北方装备集团有限公司', totalAmount: '¥1,560,000', status: '已完成', equipments: [{ id: 'eq8', name: '防弹头盔', model: 'MICH2000', qty: 300, unit: '顶' }, { id: 'eq9', name: '战术背心', model: 'TS-01', qty: 100, unit: '件' }] },
      { id: 'o5', orderNo: 'DD-2024-112', createTime: '2024-09-01', supplierName: '北方装备集团有限公司', totalAmount: '¥780,000', status: '已完成', equipments: [{ id: 'eq10', name: '防弹头盔', model: 'PASGT', qty: 200, unit: '顶' }] },
    ],
  },
  {
    id: 'e3', name: '中天警用器材有限公司',
    orders: [
      { id: 'o6', orderNo: 'DD-2024-107', createTime: '2024-07-01', supplierName: '中天警用器材有限公司', totalAmount: '¥890,000', status: '已完成', equipments: [{ id: 'eq11', name: '伸缩警棍', model: 'JG-600', qty: 500, unit: '根' }, { id: 'eq12', name: '手铐', model: 'SK-01', qty: 300, unit: '副' }] },
      { id: 'o7', orderNo: 'DD-2024-113', createTime: '2024-09-20', supplierName: '中天警用器材有限公司', totalAmount: '¥450,000', status: '已完成', equipments: [{ id: 'eq13', name: '约束带', model: 'YS-01', qty: 400, unit: '条' }, { id: 'eq14', name: '伸缩警棍', model: 'JG-600', qty: 200, unit: '根' }] },
      { id: 'o8', orderNo: 'DD-2024-118', createTime: '2024-11-10', supplierName: '中天警用器材有限公司', totalAmount: '¥320,000', status: '已完成', equipments: [{ id: 'eq15', name: '手铐', model: 'SK-02', qty: 250, unit: '副' }] },
      { id: 'o9', orderNo: 'DD-2024-120', createTime: '2024-12-01', supplierName: '中天警用器材有限公司', totalAmount: '¥560,000', status: '已完成', equipments: [{ id: 'eq16', name: '催泪喷射器', model: 'CL-01', qty: 300, unit: '罐' }] },
    ],
  },
  {
    id: 'e4', name: '南方防护设备有限公司',
    orders: [
      { id: 'o10', orderNo: 'DD-2024-108', createTime: '2024-07-10', supplierName: '南方防护设备有限公司', totalAmount: '¥2,100,000', status: '已完成', equipments: [{ id: 'eq17', name: '防刺服', model: 'FCF-FA', qty: 250, unit: '件' }, { id: 'eq18', name: '反光背心', model: 'FG-01', qty: 500, unit: '件' }] },
      { id: 'o11', orderNo: 'DD-2024-116', createTime: '2024-10-25', supplierName: '南方防护设备有限公司', totalAmount: '¥1,200,000', status: '已完成', equipments: [{ id: 'eq19', name: '防刺服', model: 'FCF-FB', qty: 200, unit: '件' }] },
    ],
  },
  {
    id: 'e5', name: '西部通信科技有限公司',
    orders: [
      { id: 'o12', orderNo: 'DD-2024-109', createTime: '2024-08-01', supplierName: '西部通信科技有限公司', totalAmount: '¥750,000', status: '已完成', equipments: [{ id: 'eq20', name: '对讲机', model: 'DJ-8800', qty: 150, unit: '台' }] },
      { id: 'o13', orderNo: 'DD-2024-119', createTime: '2024-11-20', supplierName: '西部通信科技有限公司', totalAmount: '¥980,000', status: '已完成', equipments: [{ id: 'eq21', name: '执法记录仪', model: 'ZF-01', qty: 200, unit: '台' }] },
    ],
  },
]

const allOrders = mockEnterprises.flatMap((e) => e.orders)

const warehouseTree: WarehouseNode[] = [
  {
    id: 'w-all', name: '全部仓库', level: 0,
    children: [
      {
        id: 'w-prov', name: '省厅仓库', level: 1,
        equipments: [
          { id: 'we1', name: '防弹背心', model: 'BV-III-A', rfid: '0410301200124122815A3B9000100000', batchNo: 'B202401', storageDate: '2024-01-20' },
          { id: 'we2', name: '防弹头盔', model: 'MICH2000', rfid: '2410301200225010210D4E5000300000', batchNo: 'B202402', storageDate: '2024-02-15' },
        ],
      },
      {
        id: 'w-nj', name: '南京市公安局仓库', level: 1,
        children: [
          {
            id: 'w-nj-a', name: 'A区仓库', level: 2,
            equipments: [
              { id: 'we3', name: '防弹背心', model: 'BV-III-A', rfid: '0410301200124122815A3B9000100000', batchNo: 'B202401', storageDate: '2024-01-20' },
              { id: 'we4', name: '防弹背心', model: 'BV-III-A', rfid: '0410301200124122815B2C8000200000', batchNo: 'B202401', storageDate: '2024-01-20' },
              { id: 'we5', name: '防弹头盔', model: 'MICH2000', rfid: '2410301200225010210D4E5000300000', batchNo: 'B202402', storageDate: '2024-02-15' },
            ],
          },
          {
            id: 'w-nj-b', name: 'B区仓库', level: 2,
            equipments: [
              { id: 'we6', name: '伸缩警棍', model: 'JG-01', rfid: '3410301200325030312F6G3000400000', batchNo: 'B202403', storageDate: '2024-03-10' },
              { id: 'we7', name: '手铐', model: 'SK-01', rfid: '4410301200425040414H8I2000500000', batchNo: 'B202404', storageDate: '2024-04-05' },
            ],
          },
          {
            id: 'w-nj-c', name: 'C区仓库', level: 2,
            equipments: [
              { id: 'we8', name: '执法记录仪', model: 'ZF-01', rfid: '5410301200525050516J0K1000600000', batchNo: 'B202405', storageDate: '2024-05-01' },
              { id: 'we9', name: '对讲机', model: 'DJ-8800', rfid: '6410301200625060618L2M1000700000', batchNo: 'B202406', storageDate: '2024-05-15' },
            ],
          },
        ],
        equipments: [],
      },
      {
        id: 'w-sz', name: '苏州市公安局仓库', level: 1,
        children: [
          { id: 'w-sz-a', name: '姑苏区仓库', level: 2, equipments: [{ id: 'we10', name: '防刺服', model: 'FC-01', rfid: '7410301200725070719N3O1000800000', batchNo: 'B202407', storageDate: '2024-06-01' }] },
          { id: 'w-sz-b', name: '工业园区仓库', level: 2, equipments: [{ id: 'we11', name: '反光背心', model: 'FG-01', rfid: '8410301200825080820P4Q1000900000', batchNo: 'B202408', storageDate: '2024-06-15' }] },
        ],
        equipments: [],
      },
      {
        id: 'w-wx', name: '无锡市公安局仓库', level: 1,
        children: [
          { id: 'w-wx-a', name: '滨湖区仓库', level: 2, equipments: [{ id: 'we12', name: '催泪喷射器', model: 'CL-01', rfid: '9410301200925090921R5S1001000000', batchNo: 'B202409', storageDate: '2024-07-01' }] },
        ],
        equipments: [],
      },
    ],
    equipments: [],
  },
]

const mockControls: ControlRecord[] = [
  { id: '1', problemNo: 'PC202405001', equipName: '防弹背心', equipModel: 'BV-III-A', problemDesc: '批次B202401防护板存在脱胶风险', findTime: '2024-05-20', batchNo: 'B202401', measure: '已下架', status: '生效中', operator: '张警官' },
  { id: '2', problemNo: 'PC202405002', equipName: '伸缩警棍', equipModel: 'JG-01', problemDesc: '锁定机构失灵，无法正常收棍', findTime: '2024-05-18', batchNo: 'B202403', measure: '使用限制中', status: '生效中', operator: '李警官' },
  { id: '3', problemNo: 'PC202405003', equipName: '执法记录仪', equipModel: 'ZF-01', problemDesc: '电池鼓包，存在安全隐患', findTime: '2024-05-15', batchNo: 'B202405', measure: '已冻结', status: '生效中', operator: '王警官' },
  { id: '4', problemNo: 'PC202405004', equipName: '防弹头盔', equipModel: 'MICH2000', problemDesc: '内衬老化严重，缓冲性能下降', findTime: '2024-05-10', batchNo: 'B202402', measure: '使用限制中', status: '已解除', operator: '赵警官' },
  { id: '5', problemNo: 'PC202405005', equipName: '手铐', equipModel: 'SK-01', problemDesc: '钥匙孔锈蚀，影响开锁', findTime: '2024-05-08', batchNo: 'B202404', measure: '已下架', status: '待审核', operator: '刘警官' },
  { id: '6', problemNo: 'PC202405006', equipName: '防刺服', equipModel: 'FC-01', problemDesc: '面料磨损，防刺层外露', findTime: '2024-05-05', batchNo: 'B202406', measure: '已下架', status: '生效中', operator: '陈警官' },
  { id: '7', problemNo: 'PC202405007', equipName: '对讲机', equipModel: 'DJ-01', problemDesc: '通话杂音大，电池续航不足', findTime: '2024-04-28', batchNo: 'B202407', measure: '使用限制中', status: '生效中', operator: '孙警官' },
  { id: '8', problemNo: 'PC202405008', equipName: '催泪喷射器', equipModel: 'CL-01', problemDesc: '压力不足，喷射距离不达标', findTime: '2024-04-20', batchNo: 'B202408', measure: '已冻结', status: '已解除', operator: '周警官' },
  { id: '9', problemNo: 'PC202405009', equipName: '约束带', equipModel: 'YS-01', problemDesc: '卡扣断裂，多次使用后失效', findTime: '2024-04-15', batchNo: 'B202409', measure: '已下架', status: '待审核', operator: '吴警官' },
]

const mockDisposals: SupplierDisposal[] = [
  { id: '1', orderNo: 'DD-2024-105', supplierName: '华东安防科技有限公司', supplierType: '装备供应商', disposalType: '暂停资格', reason: '产品质量不合格率超过15%', startTime: '2024-05-01', endTime: '2024-08-01', scope: '本市', publisher: '南京市公安局', remark: '暂停期间不得参与新的采购投标', status: '处理中', handler: '张警官' },
  { id: '2', orderNo: 'DD-2024-106', supplierName: '北方装备集团有限公司', supplierType: '装备供应商', disposalType: '警告', reason: '合同履约率连续3月低于80%', startTime: '2024-04-15', scope: '本县', publisher: '鼓楼区公安分局', remark: '', status: '处理中', handler: '李警官' },
  { id: '3', orderNo: 'DD-2024-107', supplierName: '中天警用器材有限公司', supplierType: '器材供应商', disposalType: '永久取消', reason: '严重违约，拒绝履行售后服务', startTime: '2024-03-01', scope: '全省', publisher: '省厅装备财务处', remark: '永久取消全省范围内的供货资格', status: '已完成', handler: '王警官' },
  { id: '4', orderNo: 'DD-2024-108', supplierName: '南方防护设备有限公司', supplierType: '防护供应商', disposalType: '警告', reason: '资质证书即将过期未及时续期', startTime: '2024-05-10', scope: '本县', publisher: '建邺区公安分局', remark: '', status: '处理中', handler: '赵警官' },
  { id: '5', orderNo: 'DD-2024-109', supplierName: '西部通信科技有限公司', supplierType: '通信供应商', disposalType: '暂停资格', reason: '产品存在安全缺陷', startTime: '2024-04-20', endTime: '2024-07-20', scope: '本市', publisher: '苏州市公安局', remark: '需整改完成并通过验收后方可恢复', status: '待审核', handler: '刘警官' },
]

const controlMeasuresList = [
  { label: '禁止领用', value: 'forbid_borrow' },
  { label: '禁止调拨', value: 'forbid_transfer' },
  { label: '禁止出库', value: 'forbid_outbound' },
  { label: '禁止入库', value: 'forbid_inbound' },
  { label: '禁止采购', value: 'forbid_procurement' },
]

const punishmentTypes = [
  { type: 'warning', label: '警告', desc: '对供应商进行书面警告' },
  { type: 'suspend', label: '暂停资格', desc: '暂停供应商供货资格' },
  { type: 'cancel', label: '永久取消资格', desc: '永久取消供应商资格' },
]

/* ═══════════════════════════════════════════
   Utility: highlight matched text
   ═══════════════════════════════════════════ */
function HighlightText({ text, keywords }: { text: string; keywords: string }) {
  if (!keywords.trim()) return <>{text}</>
  const keys = keywords.trim().split(/\s+/).filter(Boolean)
  if (keys.length === 0) return <>{text}</>
  const regex = new RegExp(`(${keys.map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})`, 'gi')
  const parts = text.split(regex)
  return (
    <>
      {parts.map((part, i) =>
        keys.some((k) => part.toLowerCase() === k.toLowerCase()) ? (
          <mark key={i} className="rounded bg-[#FEF3C7] px-0.5 font-semibold text-[#D97706]">{part}</mark>
        ) : (
          <span key={i}>{part}</span>
        )
      )}
    </>
  )
}

/* ═══════════════════════════════════════════
   Small components
   ═══════════════════════════════════════════ */
function MeasureBadge({ measure }: { measure: string }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      measure === '已下架' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      measure === '使用限制中' ? 'bg-[#FEF3C7] text-[#D97706]' :
      measure === '已冻结' ? 'bg-[#FFEDD5] text-[#EA580C]' :
      'bg-[#F3F4F6] text-[#6B7280]')}>
      {measure}
    </span>
  )
}

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      status === '生效中' ? 'bg-[#FEE2E2] text-[#DC2626]' :
      status === '待审核' ? 'bg-[#FEF3C7] text-[#D97706]' :
      'bg-[#D1FAE5] text-[#059669]')}>
      {status}
    </span>
  )
}

/* ═══════════════════════════════════════════
   Control Modal
   ═══════════════════════════════════════════ */
function ControlModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<'select' | 'form'>('select')
  const [selectMode, setSelectMode] = useState<SelectMode>('enterprise')

  /* ── Mode 1: enterprise ── */
  const [selEnterprise, setSelEnterprise] = useState('')
  const [selOrder, setSelOrder] = useState('')
  const [selEquipIds, setSelEquipIds] = useState<string[]>([])
  const [entSearch, setEntSearch] = useState('')

  /* ── Mode 2: order ── */
  const [orderSearch, setOrderSearch] = useState('')
  const [orderDateFrom, setOrderDateFrom] = useState('')
  const [orderDateTo, setOrderDateTo] = useState('')
  const [selOrderM2, setSelOrderM2] = useState('')
  const [selEquipM2, setSelEquipM2] = useState<string[]>([])

  /* ── Mode 3: warehouse ── */
  const [selWarehouseId, setSelWarehouseId] = useState('')
  const [expandedWids, setExpandedWids] = useState<string[]>(['w-all'])
  const [whSearch, setWhSearch] = useState('')
  const [selEquipM3, setSelEquipM3] = useState<string[]>([])

  /* ── Form fields ── */
  const [controlReason, setControlReason] = useState('')
  const [controlStartDate, setControlStartDate] = useState('')
  const [controlEndDate, setControlEndDate] = useState('')
  const [responsiblePerson, setResponsiblePerson] = useState('')
  const [selectedMeasures, setSelectedMeasures] = useState<string[]>([])
  const [hasSupplierPunishment, setHasSupplierPunishment] = useState(false)
  const [punishmentType, setPunishmentType] = useState('')
  const [punishStartDate, setPunishStartDate] = useState('')
  const [punishEndDate, setPunishEndDate] = useState('')

  /* ── Helpers ── */
  const toggleMeasure = (v: string) => setSelectedMeasures((p) => p.includes(v) ? p.filter((x) => x !== v) : [...p, v])
  const toggleEquip = (id: string, mode: 'm1' | 'm2' | 'm3') => {
    if (mode === 'm1') setSelEquipIds((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id])
    else if (mode === 'm2') setSelEquipM2((p) => p.includes(id) ? p.filter((x) => x !== x) : [...p, id])
    else setSelEquipM3((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id])
  }

  const switchMode = (m: SelectMode) => {
    setSelectMode(m)
    setSelEnterprise(''); setSelOrder(''); setSelEquipIds([])
    setSelOrderM2(''); setSelEquipM2([])
    setSelWarehouseId(''); setSelEquipM3([])
    setEntSearch(''); setOrderSearch(''); setWhSearch('')
  }

  /* Mode 1 filtered */
  const filteredEnterprises = useMemo(() => {
    if (!entSearch.trim()) return mockEnterprises
    const keys = entSearch.trim().split(/\s+/).filter(Boolean)
    return mockEnterprises.filter((e) => keys.some((k) => e.name.toLowerCase().includes(k.toLowerCase())))
  }, [entSearch])

  const selectedEnt = mockEnterprises.find((e) => e.id === selEnterprise)
  const selectedOrd = selectedEnt?.orders.find((o) => o.id === selOrder)
  const filteredOrders = useMemo(() => {
    if (!selectedEnt) return []
    if (!entSearch.trim()) return selectedEnt.orders
    const keys = entSearch.trim().split(/\s+/).filter(Boolean)
    return selectedEnt.orders.filter((o) =>
      keys.some((k) =>
        o.orderNo.toLowerCase().includes(k.toLowerCase()) ||
        o.equipments.some((eq) => eq.name.toLowerCase().includes(k.toLowerCase()) || eq.model.toLowerCase().includes(k.toLowerCase()))
      )
    )
  }, [selectedEnt, entSearch])

  /* Mode 2 filtered */
  const filteredOrdersM2 = useMemo(() => {
    let list = allOrders
    if (orderDateFrom) list = list.filter((o) => o.createTime >= orderDateFrom)
    if (orderDateTo) list = list.filter((o) => o.createTime <= orderDateTo)
    if (orderSearch.trim()) {
      const keys = orderSearch.trim().split(/\s+/).filter(Boolean)
      list = list.filter((o) =>
        keys.some((k) =>
          o.orderNo.toLowerCase().includes(k.toLowerCase()) ||
          o.supplierName.toLowerCase().includes(k.toLowerCase()) ||
          o.equipments.some((eq) => eq.name.toLowerCase().includes(k.toLowerCase()) || eq.model.toLowerCase().includes(k.toLowerCase()))
        )
      )
    }
    return list
  }, [orderSearch, orderDateFrom, orderDateTo])

  const selectedOrdM2 = allOrders.find((o) => o.id === selOrderM2)

  /* Mode 3 helpers */
  const getAllChildWarehouseIds = (node: WarehouseNode): string[] => {
    const ids = [node.id]
    if (node.children) node.children.forEach((c) => ids.push(...getAllChildWarehouseIds(c)))
    return ids
  }

  const getWarehouseEquipments = (wid: string): EquipmentItem[] => {
    if (!wid) return []
    const findNode = (nodes: WarehouseNode[]): WarehouseNode | null => {
      for (const n of nodes) {
        if (n.id === wid) return n
        if (n.children) { const found = findNode(n.children); if (found) return found }
      }
      return null
    }
    const node = findNode(warehouseTree)
    if (!node) return []
    const eqs: EquipmentItem[] = [...node.equipments]
    const collect = (n: WarehouseNode) => { n.equipments.forEach((e) => eqs.push(e)); n.children?.forEach(collect) }
    node.children?.forEach(collect)
    return eqs
  }

  const whEquips = getWarehouseEquipments(selWarehouseId)
  const filteredWhEquips = useMemo(() => {
    if (!whSearch.trim()) return whEquips
    const keys = whSearch.trim().split(/\s+/).filter(Boolean)
    return whEquips.filter((eq) =>
      keys.some((k) =>
        eq.name.toLowerCase().includes(k.toLowerCase()) ||
        (eq.model || '').toLowerCase().includes(k.toLowerCase()) ||
        (eq.rfid || '').toLowerCase().includes(k.toLowerCase()) ||
        (eq.batchNo || '').toLowerCase().includes(k.toLowerCase())
      )
    )
  }, [whEquips, whSearch])

  const toggleExpand = (id: string) => {
    setExpandedWids((p) => p.includes(id) ? p.filter((x) => x !== id) : [...p, id])
  }

  /* Can proceed? */
  const canProceed = selectMode === 'enterprise'
    ? selEnterprise !== '' && selOrder !== '' && selEquipIds.length > 0
    : selectMode === 'order'
    ? selOrderM2 !== ''
    : selWarehouseId !== '' && selEquipM3.length > 0

  const canSubmit = controlReason && controlStartDate && controlEndDate && selectedMeasures.length > 0

  /* ── Render warehouse tree ── */
  const renderWhTree = (nodes: WarehouseNode[], depth: number = 0) => {
    return nodes.map((node) => {
      const isExpanded = expandedWids.includes(node.id)
      const hasChildren = node.children && node.children.length > 0
      const isSelected = selWarehouseId === node.id
      const childIds = hasChildren ? getAllChildWarehouseIds(node) : []
      const isParentOfSelected = hasChildren && childIds.includes(selWarehouseId) && !isSelected

      return (
        <div key={node.id}>
          <button
            onClick={() => { setSelWarehouseId(node.id); setSelEquipM3([]) }}
            className={cn(
              'flex w-full items-center gap-1.5 rounded-md py-1.5 pr-2 text-left text-[13px] transition',
              isSelected ? 'bg-[#E8F0FE] font-medium text-[#1A56DB]' :
              isParentOfSelected ? 'text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]',
              depth === 0 ? 'pl-2' : depth === 1 ? 'pl-6' : 'pl-10'
            )}
          >
            {hasChildren && (
              <span onClick={(e) => { e.stopPropagation(); toggleExpand(node.id) }} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#9CA3AF]">
                {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
              </span>
            )}
            {!hasChildren && <span className="h-4 w-4 shrink-0" />}
            <Warehouse size={14} className="shrink-0 text-[#6B7280]" />
            <span className="truncate">{node.name}</span>
            {node.equipments.length > 0 && <span className="ml-auto text-[11px] text-[#9CA3AF]">{node.equipments.length}件</span>}
          </button>
          {hasChildren && isExpanded && (
            <div>{renderWhTree(node.children!, depth + 1)}</div>
          )}
        </div>
      )
    })
  }

  /* ── Get selected supplier for punishment ── */
  const selectedSupplierName = selectMode === 'enterprise'
    ? selectedEnt?.name
    : selectMode === 'order'
    ? selectedOrdM2?.supplierName
    : undefined

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="max-h-[92vh] w-[860px] overflow-y-auto rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-white px-6 py-4">
          <div className="flex items-center gap-2">
            <ShieldCheck size={20} className="text-[#1A56DB]" />
            <h2 className="text-lg font-semibold text-[#1F2937]">
              {step === 'select' ? '选择管控对象' : '填写管控信息'}
            </h2>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-[#9CA3AF] transition hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* Steps */}
        <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-6 py-3">
          <div className="flex items-center gap-4">
            <div className={cn('flex items-center gap-1.5 text-sm', step === 'select' ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280]')}>
              <span className={cn('flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold', step === 'select' ? 'bg-[#1A56DB] text-white' : 'bg-[#D1D5DB] text-white')}>1</span>
              选择对象
            </div>
            <div className="h-px w-8 bg-[#D1D5DB]" />
            <div className={cn('flex items-center gap-1.5 text-sm', step === 'form' ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280]')}>
              <span className={cn('flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold', step === 'form' ? 'bg-[#1A56DB] text-white' : 'bg-[#D1D5DB] text-white')}>2</span>
              填写管控信息
            </div>
          </div>
        </div>

        <div className="px-6 py-5">
          {step === 'select' ? (
            <div className="space-y-4">
              {/* Mode tabs */}
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">选择方式 <span className="text-[#EF4444]">*</span></label>
                <div className="flex gap-3">
                  {[
                    { key: 'enterprise' as SelectMode, label: '企业→订单→装备', icon: <Building2 size={16} /> },
                    { key: 'order' as SelectMode, label: '直接选订单', icon: <ClipboardList size={16} /> },
                    { key: 'warehouse' as SelectMode, label: '仓库→装备', icon: <Warehouse size={16} /> },
                  ].map((m) => (
                    <button key={m.key} onClick={() => switchMode(m.key)}
                      className={cn('flex items-center gap-2 rounded-lg border px-4 py-3 text-sm transition',
                        selectMode === m.key ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>
                      {m.icon} {m.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* ══════ Mode 1: Enterprise → Order → Equipment ══════ */}
              {selectMode === 'enterprise' && (
                <div>
                  {/* Search */}
                  <div className="relative mb-3">
                    <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                    <input type="text" value={entSearch} onChange={(e) => setEntSearch(e.target.value)}
                      placeholder="搜索企业、订单或装备关键词，空格分隔"
                      className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
                  </div>

                  {/* Three columns */}
                  <div className="flex gap-3">
                    {/* Enterprise column */}
                    <div className="flex-1 rounded-lg border border-[#E5E7EB]">
                      <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-xs font-medium text-[#6B7280]">选择企业</div>
                      <div className="max-h-64 overflow-y-auto p-1.5">
                        {filteredEnterprises.map((e) => (
                          <button key={e.id} onClick={() => { setSelEnterprise(e.id); setSelOrder(''); setSelEquipIds([]) }}
                            className={cn('flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm transition',
                              selEnterprise === e.id ? 'bg-[#E8F0FE] font-medium text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')}>
                            <Building2 size={14} className="shrink-0 text-[#6B7280]" />
                            <HighlightText text={e.name} keywords={entSearch} />
                          </button>
                        ))}
                        {filteredEnterprises.length === 0 && <div className="py-6 text-center text-xs text-[#9CA3AF]">无匹配企业</div>}
                      </div>
                    </div>

                    {/* Order column */}
                    <div className="flex-1 rounded-lg border border-[#E5E7EB]">
                      <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-xs font-medium text-[#6B7280]">
                        {selectedEnt ? '选择订单' : '请先选择企业'}
                      </div>
                      <div className="max-h-64 overflow-y-auto p-1.5">
                        {selectedEnt ? filteredOrders.map((o) => (
                          <button key={o.id} onClick={() => { setSelOrder(o.id); setSelEquipIds([]) }}
                            className={cn('mb-1 flex w-full flex-col rounded-md px-2.5 py-2 text-left text-sm transition',
                              selOrder === o.id ? 'bg-[#E8F0FE]' : 'hover:bg-[#F3F4F6]')}>
                            <div className={cn('font-medium', selOrder === o.id ? 'text-[#1A56DB]' : 'text-[#374151]')}>
                              <HighlightText text={o.orderNo} keywords={entSearch} />
                            </div>
                            <div className="mt-0.5 text-[11px] text-[#6B7280]">
                              <HighlightText text={o.createTime} keywords={entSearch} /> · {o.totalAmount} · {o.equipments.length}种装备
                            </div>
                          </button>
                        )) : <div className="py-6 text-center text-xs text-[#9CA3AF]">—</div>}
                        {selectedEnt && filteredOrders.length === 0 && <div className="py-6 text-center text-xs text-[#9CA3AF]">无匹配订单</div>}
                      </div>
                    </div>

                    {/* Equipment column */}
                    <div className="flex-1 rounded-lg border border-[#E5E7EB]">
                      <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-xs font-medium text-[#6B7280]">
                        {selectedOrd ? '选择装备（可多选）' : selectedEnt ? '请先选择订单' : '—'}
                      </div>
                      <div className="max-h-64 overflow-y-auto p-1.5">
                        {selectedOrd ? selectedOrd.equipments.map((eq) => (
                          <label key={eq.id}
                            className={cn('mb-1 flex cursor-pointer items-start gap-2 rounded-md px-2.5 py-2 transition',
                              selEquipIds.includes(eq.id) ? 'bg-[#E8F0FE]' : 'hover:bg-[#F3F4F6]')}>
                            <input type="checkbox" checked={selEquipIds.includes(eq.id)}
                              onChange={() => toggleEquip(eq.id, 'm1')}
                              className="mt-0.5 h-4 w-4 shrink-0 rounded border-[#D1D5DB] accent-[#1A56DB]" />
                            <div>
                              <div className={cn('text-sm font-medium', selEquipIds.includes(eq.id) ? 'text-[#1A56DB]' : 'text-[#374151]')}>
                                <HighlightText text={eq.name} keywords={entSearch} />
                              </div>
                              <div className="text-[11px] text-[#6B7280]"><HighlightText text={eq.model} keywords={entSearch} /> · {eq.qty}{eq.unit}</div>
                            </div>
                          </label>
                        )) : <div className="py-6 text-center text-xs text-[#9CA3AF]">—</div>}
                      </div>
                    </div>
                  </div>

                  {/* Selected path */}
                  {(selEnterprise || selOrder || selEquipIds.length > 0) && (
                    <div className="mt-3 flex flex-wrap items-center gap-2 rounded-md bg-[#F0F7FF] px-3 py-2 text-sm">
                      <span className="text-[#6B7280]">已选路径：</span>
                      {selEnterprise && <span className="rounded bg-[#E8F0FE] px-2 py-0.5 text-xs text-[#1A56DB]">{selectedEnt?.name}</span>}
                      {selOrder && <><ChevronRight size={12} className="text-[#9CA3AF]" /><span className="rounded bg-[#E8F0FE] px-2 py-0.5 text-xs text-[#1A56DB]">{selectedOrd?.orderNo}</span></>}
                      {selEquipIds.length > 0 && <><ChevronRight size={12} className="text-[#9CA3AF]" /><span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-xs text-[#059669]">{selEquipIds.length}件装备</span></>}
                    </div>
                  )}
                </div>
              )}

              {/* ══════ Mode 2: Direct Order ══════ */}
              {selectMode === 'order' && (
                <div>
                  {/* Filters */}
                  <div className="mb-3 flex gap-2">
                    <div className="relative flex-1">
                      <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                      <input type="date" value={orderDateFrom} onChange={(e) => setOrderDateFrom(e.target.value)}
                        className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-2 text-sm outline-none transition focus:border-[#1A56DB]" />
                    </div>
                    <span className="flex items-center text-sm text-[#6B7280]">至</span>
                    <div className="relative flex-1">
                      <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                      <input type="date" value={orderDateTo} onChange={(e) => setOrderDateTo(e.target.value)}
                        className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-2 text-sm outline-none transition focus:border-[#1A56DB]" />
                    </div>
                    <div className="relative flex-[2]">
                      <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                      <input type="text" value={orderSearch} onChange={(e) => setOrderSearch(e.target.value)}
                        placeholder="搜索订单号、供应商或装备，空格分隔"
                        className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
                    </div>
                  </div>

                  {/* Order list */}
                  <div className="max-h-56 overflow-y-auto rounded-lg border border-[#E5E7EB]">
                    {filteredOrdersM2.map((o) => (
                      <div key={o.id}
                        className={cn('cursor-pointer border-b border-[#F3F4F6] px-4 py-3 transition',
                          selOrderM2 === o.id ? 'bg-[#E8F0FE]' : 'hover:bg-[#F9FAFB]')}
                        onClick={() => { setSelOrderM2(o.id); setSelEquipM2([]) }}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className={cn('text-sm font-medium', selOrderM2 === o.id ? 'text-[#1A56DB]' : 'text-[#374151]')}>
                              <HighlightText text={o.orderNo} keywords={orderSearch} />
                            </span>
                            <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[11px] text-[#059669]">{o.status}</span>
                          </div>
                          <span className="text-xs text-[#6B7280]">{o.createTime}</span>
                        </div>
                        <div className="mt-1 flex items-center gap-3 text-xs text-[#6B7280]">
                          <span><HighlightText text={o.supplierName} keywords={orderSearch} /></span>
                          <span className="font-medium text-[#1A56DB]">{o.totalAmount}</span>
                          <span>{o.equipments.length}种装备</span>
                        </div>
                        <div className="mt-1 flex flex-wrap gap-1">
                          {o.equipments.slice(0, 4).map((eq) => (
                            <span key={eq.id} className="rounded bg-[#F3F4F6] px-1.5 py-0.5 text-[11px] text-[#374151]">
                              <HighlightText text={`${eq.name}×${eq.qty}${eq.unit}`} keywords={orderSearch} />
                            </span>
                          ))}
                          {o.equipments.length > 4 && <span className="text-[11px] text-[#9CA3AF]">+{o.equipments.length - 4}</span>}
                        </div>

                        {/* Equipment detail (expand when selected) */}
                        {selOrderM2 === o.id && (
                          <div className="mt-2 rounded-md border border-[#E5E7EB] bg-white p-2">
                            <div className="mb-1.5 text-xs font-medium text-[#6B7280]">装备明细（可多选）</div>
                            {o.equipments.map((eq) => (
                              <label key={eq.id}
                                className={cn('flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 transition',
                                  selEquipM2.includes(eq.id) ? 'bg-[#E8F0FE]' : 'hover:bg-[#F9FAFB]')}>
                                <input type="checkbox" checked={selEquipM2.includes(eq.id)}
                                  onChange={() => toggleEquip(eq.id, 'm2')}
                                  className="h-3.5 w-3.5 rounded border-[#D1D5DB] accent-[#1A56DB]" />
                                <span className={cn('text-sm', selEquipM2.includes(eq.id) ? 'text-[#1A56DB]' : 'text-[#374151]')}>{eq.name}</span>
                                <span className="text-xs text-[#6B7280]">{eq.model}</span>
                                <span className="ml-auto text-xs font-medium text-[#1A56DB]">{eq.qty}{eq.unit}</span>
                              </label>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                    {filteredOrdersM2.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">无匹配订单</div>}
                  </div>

                  {selOrderM2 && selEquipM2.length === 0 && (
                    <div className="mt-2 text-xs text-[#6B7280]">已选择订单 <strong>{selectedOrdM2?.orderNo}</strong>，管控全部装备</div>
                  )}
                  {selEquipM2.length > 0 && (
                    <div className="mt-2 text-xs text-[#059669]">已选择 {selEquipM2.length} 件装备</div>
                  )}
                </div>
              )}

              {/* ══════ Mode 3: Warehouse → Equipment ══════ */}
              {selectMode === 'warehouse' && (
                <div className="flex gap-3">
                  {/* Left: Warehouse tree */}
                  <div className="w-[260px] shrink-0 rounded-lg border border-[#E5E7EB]">
                    <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-xs font-medium text-[#6B7280]">选择仓库</div>
                    <div className="max-h-80 overflow-y-auto p-2">
                      {renderWhTree(warehouseTree)}
                    </div>
                  </div>

                  {/* Right: Equipment list */}
                  <div className="min-w-0 flex-1 rounded-lg border border-[#E5E7EB]">
                    <div className="flex items-center justify-between border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2">
                      <span className="text-xs font-medium text-[#6B7280]">
                        {selWarehouseId ? '选择装备（可多选）' : '请先选择仓库'}
                      </span>
                      {selWarehouseId && (
                        <span className="text-[11px] text-[#9CA3AF]">共 {whEquips.length} 件</span>
                      )}
                    </div>
                    <div className="p-2">
                      {selWarehouseId ? (
                        <>
                          {/* Search */}
                          <div className="relative mb-2">
                            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                            <input type="text" value={whSearch} onChange={(e) => setWhSearch(e.target.value)}
                              placeholder="搜索装备名称、型号、RFID、批次"
                              className="h-8 w-full rounded-md border border-[#D1D5DB] pl-7 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                          </div>
                          {/* Equipment list */}
                          <div className="max-h-64 overflow-y-auto">
                            {filteredWhEquips.map((eq) => (
                              <label key={eq.id}
                                className={cn('mb-1 flex cursor-pointer items-start gap-2 rounded-md px-2.5 py-2 transition',
                                  selEquipM3.includes(eq.id) ? 'bg-[#E8F0FE]' : 'hover:bg-[#F3F4F6]')}>
                                <input type="checkbox" checked={selEquipM3.includes(eq.id)}
                                  onChange={() => toggleEquip(eq.id, 'm3')}
                                  className="mt-0.5 h-4 w-4 shrink-0 rounded border-[#D1D5DB] accent-[#1A56DB]" />
                                <div className="min-w-0 flex-1">
                                  <div className="flex items-center gap-2">
                                    <span className={cn('text-sm font-medium', selEquipM3.includes(eq.id) ? 'text-[#1A56DB]' : 'text-[#374151]')}>
                                      <HighlightText text={eq.name} keywords={whSearch} />
                                    </span>
                                    <span className="text-xs text-[#6B7280]"><HighlightText text={eq.model} keywords={whSearch} /></span>
                                  </div>
                                  <div className="mt-0.5 font-mono text-[11px] text-[#9CA3AF]">
                                    <HighlightText text={eq.rfid || ''} keywords={whSearch} />
                                  </div>
                                  <div className="mt-0.5 flex gap-3 text-[11px] text-[#6B7280]">
                                    <span>批次: <HighlightText text={eq.batchNo || ''} keywords={whSearch} /></span>
                                    <span>入库: {eq.storageDate}</span>
                                  </div>
                                </div>
                              </label>
                            ))}
                            {filteredWhEquips.length === 0 && <div className="py-6 text-center text-xs text-[#9CA3AF]">无匹配装备</div>}
                          </div>
                          {selEquipM3.length > 0 && (
                            <div className="mt-2 text-xs text-[#059669]">已选择 {selEquipM3.length} 件装备</div>
                          )}
                        </>
                      ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-[#9CA3AF]">
                          <Warehouse size={32} strokeWidth={1.5} />
                          <p className="mt-2 text-sm">请先在左侧选择仓库</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-2">
                <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">取消</button>
                <button onClick={() => setStep('form')} disabled={!canProceed}
                  className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E] disabled:opacity-40">
                  下一步
                </button>
              </div>
            </div>
          ) : (
            /* ══════ Step 2: Form ══════ */
            <div className="space-y-5">
              {/* Selected info */}
              <div className="rounded-lg bg-[#F0F7FF] p-3">
                <div className="flex items-center gap-2 text-sm text-[#1A56DB]">
                  {selectMode === 'enterprise' && <Building2 size={14} />}
                  {selectMode === 'order' && <ClipboardList size={14} />}
                  {selectMode === 'warehouse' && <Warehouse size={14} />}
                  <span className="font-medium">
                    {selectMode === 'enterprise' && `${selectedEnt?.name} → ${selectedOrd?.orderNo} → ${selEquipIds.length}件装备`}
                    {selectMode === 'order' && `${selectedOrdM2?.orderNo}${selEquipM2.length > 0 ? ` → ${selEquipM2.length}件装备` : '（全部装备）'}`}
                    {selectMode === 'warehouse' && `${selEquipM3.length}件在库装备`}
                  </span>
                </div>
              </div>

              {/* Control Reason */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#374151]">管控原因 <span className="text-[#EF4444]">*</span></label>
                <textarea value={controlReason} onChange={(e) => setControlReason(e.target.value)}
                  placeholder="请填写管控原因..." rows={3}
                  className="w-full rounded-lg border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
              </div>

              {/* Duration */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#374151]">管控期限 <span className="text-[#EF4444]">*</span></label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                    <input type="date" value={controlStartDate} onChange={(e) => setControlStartDate(e.target.value)}
                      className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                  <span className="text-sm text-[#6B7280]">至</span>
                  <div className="relative flex-1">
                    <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                    <input type="date" value={controlEndDate} onChange={(e) => setControlEndDate(e.target.value)}
                      className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                </div>
              </div>

              {/* Responsible */}
              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#374151]">负责人</label>
                <div className="relative">
                  <User size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                  <input type="text" value={responsiblePerson} onChange={(e) => setResponsiblePerson(e.target.value)}
                    placeholder="请输入负责人姓名"
                    className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                </div>
              </div>

              {/* Measures */}
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">管控措施 <span className="text-[#EF4444]">*</span> <span className="text-xs font-normal text-[#9CA3AF]">（可多选）</span></label>
                <div className="flex flex-wrap gap-2">
                  {controlMeasuresList.map((m) => (
                    <button key={m.value} onClick={() => toggleMeasure(m.value)}
                      className={cn('flex items-center gap-1.5 rounded-lg border px-3 py-2 text-sm transition',
                        selectedMeasures.includes(m.value) ? 'border-[#DC2626] bg-[#FEE2E2] text-[#DC2626]' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>
                      <Ban size={13} /> {m.label} {selectedMeasures.includes(m.value) && <Check size={13} />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Supplier punishment */}
              <div className="rounded-lg border border-[#E5E7EB] p-4">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Gavel size={16} className="text-[#D97706]" />
                    <span className="text-sm font-medium text-[#374151]">供应商处罚登记</span>
                  </div>
                  <label className="flex cursor-pointer items-center gap-2">
                    <input type="checkbox" checked={hasSupplierPunishment}
                      onChange={(e) => { setHasSupplierPunishment(e.target.checked); if (!e.target.checked) { setPunishmentType(''); setPunishStartDate(''); setPunishEndDate('') } }}
                      className="h-4 w-4 rounded border-[#D1D5DB] accent-[#1A56DB]" />
                    <span className="text-sm text-[#374151]">同步登记供应商处罚</span>
                  </label>
                </div>
                {hasSupplierPunishment && (
                  <div className="space-y-2">
                    {selectedSupplierName && (
                      <div className="mb-2 rounded bg-[#F9FAFB] px-3 py-2 text-sm text-[#6B7280]">处罚供应商: <strong className="text-[#374151]">{selectedSupplierName}</strong></div>
                    )}
                    {punishmentTypes.map((p) => (
                      <button key={p.type} onClick={() => setPunishmentType(p.type)}
                        className={cn('flex w-full items-start gap-3 rounded-lg border px-4 py-3 text-left transition',
                          punishmentType === p.type ? 'border-[#1A56DB] bg-[#E8F0FE]' : 'border-[#E5E7EB] hover:bg-[#F9FAFB]')}>
                        <div className={cn('mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full border',
                          punishmentType === p.type ? 'border-[#1A56DB] bg-[#1A56DB]' : 'border-[#D1D5DB]')}>
                          {punishmentType === p.type && <Check size={12} className="text-white" />}
                        </div>
                        <div className="flex-1">
                          <div className={cn('text-sm font-medium', punishmentType === p.type ? 'text-[#1A56DB]' : 'text-[#374151]')}>{p.label}</div>
                          <div className="text-xs text-[#6B7280]">{p.desc}</div>
                        </div>
                      </button>
                    ))}
                    {punishmentType === 'suspend' && (
                      <div className="mt-2 rounded-lg bg-[#F9FAFB] p-3">
                        <label className="mb-1.5 block text-sm font-medium text-[#374151]">暂停期限 <span className="text-[#EF4444]">*</span></label>
                        <div className="flex items-center gap-2">
                          <div className="relative flex-1">
                            <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                            <input type="date" value={punishStartDate} onChange={(e) => setPunishStartDate(e.target.value)}
                              className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                          </div>
                          <span className="text-sm text-[#6B7280]">至</span>
                          <div className="relative flex-1">
                            <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                            <input type="date" value={punishEndDate} onChange={(e) => setPunishEndDate(e.target.value)}
                              className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex justify-end gap-2 pt-2">
                <button onClick={() => setStep('select')} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">上一步</button>
                <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">取消</button>
                <button onClick={() => { alert('管控登记成功！'); onClose() }}
                  disabled={!canSubmit || (hasSupplierPunishment && !punishmentType) || (punishmentType === 'suspend' && (!punishStartDate || !punishEndDate))}
                  className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E] disabled:opacity-40">
                  提交登记
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   Main Page
   ═══════════════════════════════════════════ */
export default function EquipmentControlPage() {
  const [activeTab, setActiveTab] = useState<TabKey>('control')
  const [showModal, setShowModal] = useState(false)
  const [showDisposalModal, setShowDisposalModal] = useState(false)
  const [searchText, setSearchText] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 8

  const tabs = [
    { key: 'control' as const, label: '装备管控', icon: <ShieldCheck size={16} /> },
    { key: 'supplier' as const, label: '供应商处置', icon: <Factory size={16} /> },
  ]

  const controlFiltered = mockControls.filter((c) => {
    if (searchText && !c.problemNo.includes(searchText) && !c.equipName.includes(searchText)) return false
    if (statusFilter && c.status !== statusFilter) return false
    return true
  })
  const controlTotalPages = Math.ceil(controlFiltered.length / pageSize)
  const controlPageData = controlFiltered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const supplierFiltered = mockDisposals.filter((d) => {
    if (searchText && !d.supplierName.includes(searchText)) return false
    if (statusFilter && d.status !== statusFilter) return false
    return true
  })
  const supplierTotalPages = Math.ceil(supplierFiltered.length / pageSize)
  const supplierPageData = supplierFiltered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const stats = activeTab === 'control'
    ? [
        { title: '已下架', value: 12, icon: <Ban size={16} />, bg: '#FEE2E2', color: '#DC2626' },
        { title: '使用限制中', value: 5, icon: <AlertTriangle size={16} />, bg: '#FEF3C7', color: '#D97706' },
        { title: '已冻结', value: 8, icon: <Package size={16} />, bg: '#FFEDD5', color: '#EA580C' },
      ]
    : [
        { title: '警告', value: mockDisposals.filter((d) => d.disposalType === '警告').length, icon: <AlertTriangle size={16} />, bg: '#FEF3C7', color: '#D97706' },
        { title: '暂停资格', value: mockDisposals.filter((d) => d.disposalType === '暂停资格').length, icon: <Ban size={16} />, bg: '#FEE2E2', color: '#DC2626' },
        { title: '永久取消', value: mockDisposals.filter((d) => d.disposalType === '永久取消').length, icon: <ShieldCheck size={16} />, bg: '#F3F4F6', color: '#6B7280' },
        { title: '待审核', value: mockDisposals.filter((d) => d.status === '待审核').length, icon: <Clock size={16} />, bg: '#E8F0FE', color: '#1A56DB' },
      ]

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldCheck size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">装备管控</h1>
        </div>
        {activeTab === 'control' && (
          <button onClick={() => setShowModal(true)}
            className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 登记问题装备
          </button>
        )}
        {activeTab === 'supplier' && (
          <button onClick={() => setShowDisposalModal(true)} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 新增处置
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="mb-4 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button key={tab.key}
              onClick={() => { setActiveTab(tab.key); setCurrentPage(1); setSearchText(''); setStatusFilter('') }}
              className={cn('flex items-center gap-2 border-b-2 pb-3 pt-1 text-sm transition',
                activeTab === tab.key ? 'border-[#1A56DB] font-medium text-[#1A56DB]' : 'border-transparent text-[#6B7280] hover:text-[#374151]')}>
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stats */}
      <div className={cn('mb-6 grid gap-4', activeTab === 'control' ? 'grid-cols-3' : 'grid-cols-4')}>
        {stats.map((stat) => (
          <div key={stat.title} className="rounded-lg bg-white p-4 shadow-md transition hover:shadow-lg">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full" style={{ backgroundColor: stat.bg }}>
                <span style={{ color: stat.color }}>{stat.icon}</span>
              </div>
              <div>
                <div className="text-[24px] font-bold text-[#1F2937]">{stat.value}</div>
                <div className="text-xs text-[#6B7280]">{stat.title}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Filter */}
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input type="text" placeholder={activeTab === 'control' ? '搜索问题编号或装备名称' : '搜索供应商名称'}
              value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
              className="h-9 w-60 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
          </div>
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
            className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
            <option value="">全部状态</option>
            {activeTab === 'control' ? (<><option value="生效中">生效中</option><option value="待审核">待审核</option><option value="已解除">已解除</option></>)
              : (<><option value="处理中">处理中</option><option value="已完成">已完成</option></>)}
          </select>
          <button onClick={() => { setSearchText(''); setStatusFilter(''); setCurrentPage(1) }}
            className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <RefreshCw size={13} /> 重置
          </button>
        </div>
      </div>

      {/* ─── Control Table ─── */}
      {activeTab === 'control' && (
        <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">问题编号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备信息</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">问题描述</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发现时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">涉及批次</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">管控措施</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">登记人</th>
                  <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {controlPageData.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                    <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-[#1A56DB]">{row.problemNo}</td>
                    <td className="whitespace-nowrap px-4 py-3"><div className="text-sm font-medium text-[#374151]">{row.equipName}</div><div className="text-xs text-[#6B7280]">{row.equipModel}</div></td>
                    <td className="max-w-[200px] truncate px-4 py-3 text-sm text-[#374151]">{row.problemDesc}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.findTime}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.batchNo}</td>
                    <td className="whitespace-nowrap px-4 py-3"><MeasureBadge measure={row.measure} /></td>
                    <td className="whitespace-nowrap px-4 py-3"><StatusBadge status={row.status} /></td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#374151]">{row.operator}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={13} /></button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Edit3 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
                {controlPageData.length === 0 && <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>}
              </tbody>
            </table>
          </div>
          {controlFiltered.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
              <span className="text-sm text-[#6B7280]">共 {controlFiltered.length} 条</span>
              <div className="flex items-center gap-1">
                <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&lt;</button>
                {Array.from({ length: controlTotalPages }, (_, i) => i + 1).map((p) => (
                  <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition', p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
                ))}
                <button onClick={() => setCurrentPage(Math.min(controlTotalPages, currentPage + 1))} disabled={currentPage === controlTotalPages} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&gt;</button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ─── Supplier Table ─── */}
      {activeTab === 'supplier' && (
        <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">关联订单</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商类型</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处罚类型</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处罚事由</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处罚期限</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处罚范围</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发布单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {supplierPageData.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                    <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-[#1A56DB]">{row.orderNo}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-[#374151]">{row.supplierName}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.supplierType}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
                        row.disposalType === '暂停资格' ? 'bg-[#FEE2E2] text-[#DC2626]' :
                        row.disposalType === '永久取消' ? 'bg-[#F3F4F6] text-[#6B7280]' :
                        'bg-[#FEF3C7] text-[#D97706]')}>
                        {row.disposalType}
                      </span>
                    </td>
                    <td className="max-w-[200px] truncate px-4 py-3 text-sm text-[#374151]">{row.reason}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.startTime}{row.endTime ? ` 至 ${row.endTime}` : ''}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={cn('rounded px-1.5 py-0.5 text-xs',
                        row.scope === '全省' ? 'bg-[#FEE2E2] text-[#DC2626] font-medium' :
                        row.scope === '本市' ? 'bg-[#FEF3C7] text-[#D97706]' :
                        'bg-[#D1FAE5] text-[#059669]')}>
                        {row.scope}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.publisher}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
                        row.status === '处理中' ? 'bg-[#FEF3C7] text-[#D97706]' :
                        row.status === '待审核' ? 'bg-[#E8F0FE] text-[#1A56DB]' :
                        'bg-[#D1FAE5] text-[#059669]')}>
                        {row.status}
                      </span>
                    </td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={13} /></button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Edit3 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
                {supplierPageData.length === 0 && <tr><td colSpan={10} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>}
              </tbody>
            </table>
          </div>
          {supplierFiltered.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
              <span className="text-sm text-[#6B7280]">共 {supplierFiltered.length} 条</span>
              <div className="flex items-center gap-1">
                <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&lt;</button>
                {Array.from({ length: supplierTotalPages }, (_, i) => i + 1).map((p) => (
                  <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition', p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
                ))}
                <button onClick={() => setCurrentPage(Math.min(supplierTotalPages, currentPage + 1))} disabled={currentPage === supplierTotalPages} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374141] transition hover:bg-[#F3F4F6] disabled:opacity-30">&gt;</button>
              </div>
            </div>
          )}
        </div>
      )}

      {showModal && <ControlModal onClose={() => setShowModal(false)} />}
      {showDisposalModal && <AddDisposalModal onClose={() => setShowDisposalModal(false)} />}
    </div>
  )
}

/* ─── Add Disposal Modal ─── */
const allOrderOptions = [
  { no: 'DD-2024-105', supplier: '华东安防科技有限公司', type: '装备供应商' },
  { no: 'DD-2024-106', supplier: '北方装备集团有限公司', type: '装备供应商' },
  { no: 'DD-2024-107', supplier: '中天警用器材有限公司', type: '器材供应商' },
  { no: 'DD-2024-108', supplier: '南方防护设备有限公司', type: '防护供应商' },
  { no: 'DD-2024-109', supplier: '西部通信科技有限公司', type: '通信供应商' },
  { no: 'DD-2024-110', supplier: '华东安防科技有限公司', type: '装备供应商' },
]

function AddDisposalModal({ onClose }: { onClose: () => void }) {
  const [selOrderNo, setSelOrderNo] = useState('')
  const [disposalType, setDisposalType] = useState('')
  const [reason, setReason] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [scope, setScope] = useState('')
  const [remark, setRemark] = useState('')

  const selectedOrder = allOrderOptions.find((o) => o.no === selOrderNo)
  const needAudit = scope === '本市' || scope === '全省'

  const canSubmit = selOrderNo && disposalType && reason && startDate && scope && (!needAudit || true)

  const handleSubmit = () => {
    if (needAudit) {
      alert('处罚范围高于本级，已提交上级审核！')
    } else {
      alert('新增处置成功！')
    }
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="max-h-[92vh] w-[680px] overflow-y-auto rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-white px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">新增处置</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-[#9CA3AF] transition hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {/* Order */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">关联订单 <span className="text-[#EF4444]">*</span></label>
            <select value={selOrderNo} onChange={(e) => setSelOrderNo(e.target.value)}
              className="h-9 w-full rounded-lg border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
              <option value="">请选择关联订单</option>
              {allOrderOptions.map((o) => (<option key={o.no} value={o.no}>{o.no} · {o.supplier}</option>))}
            </select>
          </div>

          {/* Auto-filled fields */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="mb-1 block text-xs font-medium text-[#6B7280]">供应商名称</label>
              <div className="flex h-9 items-center rounded-md bg-[#F3F4F6] px-3 text-sm text-[#374151]">{selectedOrder?.supplier || '—'}</div>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-[#6B7280]">供应商类型</label>
              <div className="flex h-9 items-center rounded-md bg-[#F3F4F6] px-3 text-sm text-[#374151]">{selectedOrder?.type || '—'}</div>
            </div>
          </div>

          {/* Disposal type */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#374151]">处罚类型 <span className="text-[#EF4444]">*</span></label>
            <div className="flex gap-3">
              {[{ key: '警告', label: '警告', color: 'bg-[#FEF3C7] text-[#D97706]' }, { key: '暂停资格', label: '暂停资格', color: 'bg-[#FEE2E2] text-[#DC2626]' }, { key: '永久取消', label: '永久取消', color: 'bg-[#F3F4F6] text-[#6B7280]' }].map((t) => (
                <button key={t.key} onClick={() => setDisposalType(t.key)}
                  className={cn('flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm transition',
                    disposalType === t.key ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB] font-medium' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>
                  <span className={cn('rounded px-1.5 py-0.5 text-[11px]', t.color)}>{t.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Duration - with suspend special handling */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">处罚期限 <span className="text-[#EF4444]">*</span></label>
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)}
                  className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
              </div>
              <span className="text-sm text-[#6B7280]">至</span>
              <div className="relative flex-1">
                <Calendar size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)}
                  disabled={disposalType === '永久取消'}
                  className="h-9 w-full rounded-lg border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] disabled:bg-[#F3F4F6] disabled:text-[#9CA3AF]" />
              </div>
            </div>
            {disposalType === '永久取消' && <p className="mt-1 text-xs text-[#6B7280]">永久取消无需设置结束日期</p>}
          </div>

          {/* Reason */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">处罚事由 <span className="text-[#EF4444]">*</span></label>
            <textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="请填写处罚事由..." rows={3}
              className="w-full rounded-lg border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
          </div>

          {/* Scope */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#374151]">处罚范围 <span className="text-[#EF4444]">*</span></label>
            <div className="flex gap-3">
              {['本县', '本市', '全省'].map((s) => (
                <button key={s} onClick={() => setScope(s)}
                  className={cn('rounded-lg border px-4 py-2.5 text-sm transition',
                    scope === s ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB] font-medium' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>
                  {s}
                </button>
              ))}
            </div>
            {needAudit && (
              <div className="mt-2 flex items-center gap-2 rounded-md bg-[#FEF3C7] px-3 py-2 text-sm text-[#D97706]">
                <AlertTriangle size={14} />
                <span>处罚范围高于本级，提交后需经上级审核</span>
              </div>
            )}
          </div>

          {/* Publisher (auto) */}
          <div>
            <label className="mb-1 block text-xs font-medium text-[#6B7280]">发布单位</label>
            <div className="flex h-9 items-center rounded-md bg-[#F3F4F6] px-3 text-sm text-[#374151]">南京市公安局（自动填充）</div>
          </div>

          {/* Remark */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">备注</label>
            <textarea value={remark} onChange={(e) => setRemark(e.target.value)} placeholder="请输入备注信息..." rows={2}
              className="w-full rounded-lg border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151]">取消</button>
            <button onClick={handleSubmit} disabled={!canSubmit}
              className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E] disabled:opacity-40">
              {needAudit ? '提交审核' : '提交'}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
