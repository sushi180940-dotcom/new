import { useState } from 'react'
import {
  Plus, Edit3, Trash2, Bell, AlertTriangle, AlertCircle, Info,
  X, MessageSquare, Smartphone,
  ChevronRight, ChevronDown, Check,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
type WarningLevel = '提醒' | '警告' | '紧急'
type WarningType = '质保提醒' | '安全库存提醒' | '归还超期预警' | '保养提醒' | '异常出入库提醒' | '装备管控提醒'
type ModalStep = 'rule' | 'subscribe'
type StockTriggerMode = 'count' | 'percent' | ''

interface OrgNode {
  id: string
  name: string
  children?: OrgNode[]
}

/* ═══════════════════════════════════════════
   Constants
   ═══════════════════════════════════════════ */
const WARNING_TYPES: WarningType[] = ['质保提醒', '安全库存提醒', '归还超期预警', '保养提醒', '异常出入库提醒', '装备管控提醒']

const LEVEL_CONFIG: Record<WarningLevel, { color: string; bg: string; icon: React.ReactNode }> = {
  '紧急': { color: 'text-[#DC2626]', bg: 'bg-[#FEE2E2]', icon: <AlertTriangle size={13} /> },
  '警告': { color: 'text-[#D97706]', bg: 'bg-[#FEF3C7]', icon: <AlertCircle size={13} /> },
  '提醒': { color: 'text-[#1A56DB]', bg: 'bg-[#DBEAFE]', icon: <Info size={13} /> },
}

/* ─── Organization Tree ─── */
const orgTree: OrgNode[] = [
  {
    id: 'org-all', name: '全部人员',
    children: [
      {
        id: 'org-prov', name: '省厅公安',
        children: [
          {
            id: 'org-hq', name: '省厅机关',
            children: [
              { id: 'org-p1', name: '张警官（管理员）' },
              { id: 'org-p2', name: '李警官' },
              { id: 'org-p3', name: '王警官' },
              { id: 'org-p4', name: '赵警官' },
              { id: 'org-p5', name: '刘警官' },
            ],
          },
          { id: 'org-swat', name: '特警总队', children: [{ id: 'org-p6', name: '陈警官' }, { id: 'org-p7', name: '孙警官' }] },
          { id: 'org-traffic', name: '交警总队', children: [{ id: 'org-p8', name: '周警官' }, { id: 'org-p9', name: '吴警官' }] },
        ],
      },
      {
        id: 'org-city', name: '地级市公安局',
        children: [
          { id: 'org-nj', name: '南京市公安局', children: [{ id: 'org-p10', name: '郑警官' }, { id: 'org-p11', name: '钱警官' }] },
          { id: 'org-sz', name: '苏州市公安局', children: [{ id: 'org-p12', name: '冯警官' }] },
          { id: 'org-wx', name: '无锡市公安局', children: [{ id: 'org-p13', name: '朱警官' }] },
        ],
      },
      {
        id: 'org-county', name: '区县公安局',
        children: [
          { id: 'org-gl', name: '鼓楼区公安分局', children: [{ id: 'org-p14', name: '许警官' }] },
          { id: 'org-jy', name: '建邺区公安分局', children: [{ id: 'org-p15', name: '何警官' }] },
        ],
      },
    ],
  },
]

/* ═══════════════════════════════════════════
   Mock Data
   ═══════════════════════════════════════════ */
interface WarningRule {
  id: string
  name: string
  description: string
  warningType: WarningType
  triggerCondition: string
  level: WarningLevel
  status: '启用' | '停用'
  createTime: string
}

const mockRules: WarningRule[] = [
  { id: '1', name: '防弹背心质保到期提醒', description: '防弹背心质保到期前提醒相关人员及时处理', warningType: '质保提醒', triggerCondition: '到期前30天提醒，超期后持续提醒', level: '提醒', status: '启用', createTime: '2024-01-15' },
  { id: '2', name: 'A区仓库安全库存预警', description: '库存数量低于设定阈值时触发预警', warningType: '安全库存提醒', triggerCondition: '库存数量<50件', level: '警告', status: '启用', createTime: '2024-02-20' },
  { id: '3', name: '装备借用归还超期预警', description: '借用装备超过归还期限未归还', warningType: '归还超期预警', triggerCondition: '超期前3天提醒，超期后持续提醒', level: '紧急', status: '启用', createTime: '2024-03-10' },
  { id: '4', name: '防弹背心保养周期提醒', description: '防弹背心定期保养周期到期提醒', warningType: '保养提醒', triggerCondition: '保养到期前15天提醒', level: '提醒', status: '启用', createTime: '2024-04-05' },
  { id: '5', name: 'B区仓库异常出入库监测', description: '监测门禁系统检测到的未经系统操作的出入库行为', warningType: '异常出入库提醒', triggerCondition: '自动监测门禁系统', level: '警告', status: '启用', createTime: '2024-05-01' },
  { id: '6', name: '问题装备管控生效提醒', description: '装备管控措施生效时自动提醒相关人员', warningType: '装备管控提醒', triggerCondition: '管控生效时自动提醒', level: '紧急', status: '启用', createTime: '2024-05-15' },
  { id: '7', name: '对讲机质保到期提醒', description: '对讲机质保到期前提醒', warningType: '质保提醒', triggerCondition: '到期前30天提醒，超期后持续提醒', level: '提醒', status: '停用', createTime: '2024-06-01' },
  { id: '8', name: 'C区仓库安全库存预警', description: 'C区仓库装备库存低于安全线时预警', warningType: '安全库存提醒', triggerCondition: '库存比例<20%', level: '警告', status: '启用', createTime: '2024-06-20' },
]

/* ═══════════════════════════════════════════
   Components
   ═══════════════════════════════════════════ */
function LevelBadge({ level }: { level: WarningLevel }) {
  const c = LEVEL_CONFIG[level]
  return <span className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium', c.bg, c.color)}>{c.icon}{level}</span>
}

/* ─── Org Tree Selector ─── */
function OrgTreeSelector({ selectedIds, onChange }: { selectedIds: string[]; onChange: (ids: string[]) => void }) {
  const [expandedIds, setExpandedIds] = useState<string[]>(['org-all', 'org-prov', 'org-hq'])

  const toggleExpand = (id: string) => {
    setExpandedIds((p) => p.includes(id) ? p.filter((v) => v !== id) : [...p, id])
  }

  const isLeaf = (node: OrgNode) => !node.children || node.children.length === 0

  const toggleSelect = (node: OrgNode) => {
    if (isLeaf(node)) {
      onChange(selectedIds.includes(node.id) ? selectedIds.filter((v) => v !== node.id) : [...selectedIds, node.id])
    }
  }

  const getAllLeafIds = (node: OrgNode): string[] => {
    if (isLeaf(node)) return [node.id]
    return node.children!.flatMap(getAllLeafIds)
  }

  const toggleParentSelect = (node: OrgNode) => {
    const leafIds = getAllLeafIds(node)
    const allSelected = leafIds.every((id) => selectedIds.includes(id))
    if (allSelected) {
      onChange(selectedIds.filter((id) => !leafIds.includes(id)))
    } else {
      onChange([...new Set([...selectedIds, ...leafIds])])
    }
  }

  const isParentPartial = (node: OrgNode) => {
    if (isLeaf(node)) return false
    const leafIds = getAllLeafIds(node)
    const selectedCount = leafIds.filter((id) => selectedIds.includes(id)).length
    return selectedCount > 0 && selectedCount < leafIds.length
  }

  const isParentFull = (node: OrgNode) => {
    if (isLeaf(node)) return false
    const leafIds = getAllLeafIds(node)
    return leafIds.every((id) => selectedIds.includes(id))
  }

  const renderNode = (node: OrgNode, depth: number = 0) => {
    const expanded = expandedIds.includes(node.id)
    const leaf = isLeaf(node)
    const isSelected = leaf ? selectedIds.includes(node.id) : false

    return (
      <div key={node.id}>
        <div className={cn('flex items-center gap-2 rounded-md py-1.5 transition hover:bg-[#F3F4F6]', depth === 0 ? 'pl-2' : depth === 1 ? 'pl-5' : depth === 2 ? 'pl-8' : 'pl-11')}>
          {!leaf && (
            <button onClick={() => toggleExpand(node.id)} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#9CA3AF]">
              {expanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
            </button>
          )}
          {leaf && <span className="h-4 w-4 shrink-0" />}

          {/* Checkbox */}
          <button
            onClick={() => leaf ? toggleSelect(node) : toggleParentSelect(node)}
            className={cn('flex h-4 w-4 shrink-0 items-center justify-center rounded border transition',
              isSelected || isParentFull(node) ? 'border-[#1A56DB] bg-[#1A56DB]' : isParentPartial(node) ? 'border-[#1A56DB]' : 'border-[#D1D5DB]')}>
            {(isSelected || isParentFull(node)) && <Check size={10} className="text-white" />}
            {isParentPartial(node) && <div className="h-2 w-2 rounded-sm bg-[#1A56DB]" />}
          </button>

          <span className={cn('text-[13px]', isSelected || isParentFull(node) ? 'font-medium text-[#1A56DB]' : 'text-[#374151]')}>{node.name}</span>
        </div>
        {!leaf && expanded && <div>{node.children!.map((c) => renderNode(c, depth + 1))}</div>}
      </div>
    )
  }

  const getSelectedNames = () => {
    const names: string[] = []
    const walk = (nodes: OrgNode[]) => {
      for (const n of nodes) {
        if (isLeaf(n) && selectedIds.includes(n.id)) names.push(n.name)
        if (n.children) walk(n.children)
      }
    }
    walk(orgTree)
    return names
  }

  return (
    <div className="rounded-lg border border-[#E5E7EB] bg-white p-3">
      <div className="mb-2 flex items-center justify-between">
        <span className="text-xs font-medium text-[#6B7280]">选择人员（可多选）</span>
        <span className="text-xs text-[#1A56DB]">已选 {selectedIds.length} 人</span>
      </div>
      <div className="max-h-52 overflow-y-auto rounded-md border border-[#E5E7EB] bg-[#FAFBFC] p-2">
        {orgTree.map((n) => renderNode(n))}
      </div>
      {selectedIds.length > 0 && (
        <div className="mt-2 flex flex-wrap gap-1">
          {getSelectedNames().map((name, i) => (
            <span key={i} className="inline-flex items-center gap-1 rounded bg-[#E8F0FE] px-2 py-0.5 text-[11px] text-[#1A56DB]">
              {name}
              <button onClick={() => onChange(selectedIds.filter((_, idx) => idx !== i))} className="text-[#9CA3AF] hover:text-[#EF4444]"><X size={10} /></button>
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

/* ─── Add Rule Modal ─── */
function AddRuleModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState<ModalStep>('rule')

  /* Step 1 */
  const [ruleName, setRuleName] = useState('')
  const [ruleDesc, setRuleDesc] = useState('')
  const [warningType, setWarningType] = useState<WarningType>('质保提醒')
  const [level, setLevel] = useState<WarningLevel>('提醒')
  const [beforeDays, setBeforeDays] = useState('')
  const [afterOverdue, setAfterOverdue] = useState(false)
  const [stockMode, setStockMode] = useState<StockTriggerMode>('')
  const [stockCount, setStockCount] = useState('')
  const [stockPercent, setStockPercent] = useState('')

  /* Step 2 */
  const [selectedPeople, setSelectedPeople] = useState<string[]>(['org-p1'])
  const [notifyMethods, setNotifyMethods] = useState<string[]>(['站内信'])
  const [dailyCount, setDailyCount] = useState('3')
  const [intervalMin, setIntervalMin] = useState('30')
  const [maxDays, setMaxDays] = useState('7')
  const [enableEscalation, setEnableEscalation] = useState(false)
  const [escalationTime, setEscalationTime] = useState('24')
  const [notifySuperior, setNotifySuperior] = useState(true)

  const toggleNotifyMethod = (m: string) => setNotifyMethods((p) => p.includes(m) ? p.filter((v) => v !== m) : [...p, m])

  /* Trigger condition UI */
  const renderTriggerCondition = () => {
    if (warningType === '归还超期预警' || warningType === '质保提醒' || warningType === '保养提醒') {
      return (
        <div className="space-y-3 rounded-lg bg-[#F9FAFB] p-3">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={beforeDays !== ''} onChange={(e) => setBeforeDays(e.target.checked ? '30' : '')} className="h-4 w-4 rounded accent-[#1A56DB]" />
            <span className="text-sm text-[#374151]">节点到期前</span>
            <input type="number" min={1} value={beforeDays} onChange={(e) => setBeforeDays(e.target.value)} disabled={beforeDays === ''} className="h-8 w-20 rounded border border-[#D1D5DB] px-2 text-sm disabled:bg-[#F3F4F6]" />
            <span className="text-sm text-[#374151]">天提醒</span>
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={afterOverdue} onChange={(e) => setAfterOverdue(e.target.checked)} className="h-4 w-4 rounded accent-[#1A56DB]" />
            <span className="text-sm text-[#374151]">节点超期后持续提醒</span>
          </label>
        </div>
      )
    }
    if (warningType === '异常出入库提醒') {
      return <div className="rounded-lg bg-[#F0F7FF] p-3 text-sm text-[#1A56DB]">该预警类型将自动监测门禁系统检测到的未经系统出入库操作，无需额外配置触发条件。</div>
    }
    if (warningType === '装备管控提醒') {
      return <div className="rounded-lg bg-[#F0F7FF] p-3 text-sm text-[#1A56DB]">该预警类型在管控生效时自动提醒，无需额外配置触发条件。</div>
    }
    if (warningType === '安全库存提醒') {
      return (
        <div className="space-y-3 rounded-lg bg-[#F9FAFB] p-3">
          <label className="flex items-center gap-3">
            <input type="radio" name="stockTrigger" checked={stockMode === 'count'} onChange={() => { setStockMode('count'); setStockPercent('') }} className="accent-[#1A56DB]" />
            <span className="text-sm text-[#374151]">库存数量小于</span>
            <input type="number" min={1} value={stockCount} onChange={(e) => setStockCount(e.target.value)} disabled={stockMode !== 'count'}
              placeholder="如: 50" className="h-8 w-24 rounded border border-[#D1D5DB] px-2 text-sm disabled:bg-[#F3F4F6]" />
            <span className="text-sm text-[#6B7280]">件</span>
          </label>
          <label className="flex items-center gap-3">
            <input type="radio" name="stockTrigger" checked={stockMode === 'percent'} onChange={() => { setStockMode('percent'); setStockCount('') }} className="accent-[#1A56DB]" />
            <span className="text-sm text-[#374151]">库存百分比小于</span>
            <input type="number" min={1} max={100} value={stockPercent} onChange={(e) => setStockPercent(e.target.value)} disabled={stockMode !== 'percent'}
              placeholder="如: 20" className="h-8 w-24 rounded border border-[#D1D5DB] px-2 text-sm disabled:bg-[#F3F4F6]" />
            <span className="text-sm text-[#6B7280]">%</span>
          </label>
        </div>
      )
    }
    return null
  }

  const canNext = ruleName && warningType && level

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="max-h-[92vh] w-[700px] overflow-y-auto rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-white px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">{step === 'rule' ? '新增规则' : '新增订阅'}</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-[#9CA3AF] transition hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        {/* Steps */}
        <div className="border-b border-[#E5E7EB] bg-[#F9FAFB] px-6 py-3">
          <div className="flex items-center gap-4">
            <div className={cn('flex items-center gap-1.5 text-sm', step === 'rule' ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280]')}>
              <span className={cn('flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold', step === 'rule' ? 'bg-[#1A56DB] text-white' : 'bg-[#D1D5DB] text-white')}>1</span>新增规则
            </div>
            <div className="h-px w-8 bg-[#D1D5DB]" />
            <div className={cn('flex items-center gap-1.5 text-sm', step === 'subscribe' ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280]')}>
              <span className={cn('flex h-5 w-5 items-center justify-center rounded-full text-[11px] font-bold', step === 'subscribe' ? 'bg-[#1A56DB] text-white' : 'bg-[#D1D5DB] text-white')}>2</span>新增订阅
            </div>
          </div>
        </div>

        <div className="px-6 py-5">
          {step === 'rule' ? (
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#374151]">规则名称 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={ruleName} onChange={(e) => setRuleName(e.target.value)} placeholder="请输入规则名称"
                  className="h-9 w-full rounded-lg border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium text-[#374151]">预警描述</label>
                <textarea value={ruleDesc} onChange={(e) => setRuleDesc(e.target.value)} placeholder="请输入预警描述" rows={2}
                  className="w-full rounded-lg border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">预警类型 <span className="text-[#EF4444]">*</span></label>
                <div className="grid grid-cols-3 gap-2">
                  {WARNING_TYPES.map((t) => (
                    <button key={t} onClick={() => setWarningType(t)}
                      className={cn('rounded-lg border px-3 py-2.5 text-sm transition text-left', warningType === t ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB] font-medium' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>{t}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">触发条件</label>
                {renderTriggerCondition()}
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">严重程度 <span className="text-[#EF4444]">*</span></label>
                <div className="flex gap-3">
                  {(['提醒', '警告', '紧急'] as WarningLevel[]).map((l) => (
                    <button key={l} onClick={() => setLevel(l)}
                      className={cn('flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm transition', level === l ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB] font-medium' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F9FAFB]')}>
                      {LEVEL_CONFIG[l].icon} {l}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151]">取消</button>
                <button onClick={() => setStep('subscribe')} disabled={!canNext}
                  className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E] disabled:opacity-40">下一步</button>
              </div>
            </div>
          ) : (
            <div className="space-y-5">
              {/* Rule summary */}
              <div className="rounded-lg bg-[#F0F7FF] p-3">
                <div className="flex items-center gap-2 text-sm text-[#1A56DB]">
                  <Bell size={14} /><span className="font-medium">已创建规则: {ruleName}</span><LevelBadge level={level} />
                </div>
              </div>

              {/* Subscriber - Org Tree */}
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">订阅人 <span className="text-[#EF4444]">*</span></label>
                <OrgTreeSelector selectedIds={selectedPeople} onChange={setSelectedPeople} />
              </div>

              {/* Notify methods */}
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">通知方式 <span className="text-[#EF4444]">*</span></label>
                <div className="flex gap-3">
                  {[{ key: '站内信', icon: <MessageSquare size={14} /> }, { key: '短信', icon: <Smartphone size={14} /> }].map((m) => (
                    <label key={m.key} className={cn('flex cursor-pointer items-center gap-2 rounded-lg border px-4 py-2.5 transition',
                      notifyMethods.includes(m.key) ? 'border-[#1A56DB] bg-[#E8F0FE]' : 'border-[#E5E7EB] hover:bg-[#F9FAFB]')}>
                      <input type="checkbox" checked={notifyMethods.includes(m.key)} onChange={() => toggleNotifyMethod(m.key)} className="h-4 w-4 rounded accent-[#1A56DB]" />
                      <span className={cn('flex items-center gap-1 text-sm', notifyMethods.includes(m.key) ? 'text-[#1A56DB]' : 'text-[#374151]')}>{m.icon}{m.key}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Frequency config */}
              <div className="rounded-lg border border-[#E5E7EB] p-4">
                <h4 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-[#1F2937]"><span className="h-3.5 w-1 rounded bg-[#1A56DB]" />频率频次配置</h4>
                <div className="grid grid-cols-3 gap-3">
                  <div><label className="mb-1 block text-xs text-[#6B7280]">每天提醒次数</label><input type="number" min={1} value={dailyCount} onChange={(e) => setDailyCount(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm" /></div>
                  <div><label className="mb-1 block text-xs text-[#6B7280]">每次间隔（分钟）</label><input type="number" min={1} value={intervalMin} onChange={(e) => setIntervalMin(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm" /></div>
                  <div><label className="mb-1 block text-xs text-[#6B7280]">最长提醒时长（天）</label><input type="number" min={1} value={maxDays} onChange={(e) => setMaxDays(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm" /></div>
                </div>
                <p className="mt-2 text-xs text-[#6B7280]">配置说明：每天最多提醒 {dailyCount} 次，每次间隔 {intervalMin} 分钟，最长连续提醒 {maxDays} 天</p>
              </div>

              {/* Escalation */}
              <div className="rounded-lg border border-[#E5E7EB] p-4">
                <h4 className="mb-3 text-sm font-semibold text-[#1F2937]">升级机制</h4>
                <label className="mb-3 flex items-center gap-2">
                  <input type="checkbox" checked={enableEscalation} onChange={(e) => setEnableEscalation(e.target.checked)} className="h-4 w-4 rounded accent-[#1A56DB]" />
                  <span className="text-sm text-[#374151]">启用升级机制</span>
                </label>
                {enableEscalation && (
                  <div className="mb-3">
                    <label className="mb-1.5 block text-xs text-[#6B7280]">超时未处理时间</label>
                    <div className="flex gap-4">
                      {['24', '48', 'custom'].map((v) => (
                        <label key={v} className="flex items-center gap-1.5 text-sm text-[#374151]">
                          <input type="radio" name="escalationTime" value={v} checked={escalationTime === v} onChange={() => setEscalationTime(v)} className="accent-[#1A56DB]" />
                          {v === 'custom' ? '自定义' : `${v}小时`}
                        </label>
                      ))}
                    </div>
                  </div>
                )}
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={notifySuperior} onChange={(e) => setNotifySuperior(e.target.checked)} className="h-4 w-4 rounded accent-[#1A56DB]" />
                  <span className="text-sm text-[#374151]">通知上级</span>
                  {notifySuperior && <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[11px] text-[#059669]">默认勾选</span>}
                </label>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button onClick={() => setStep('rule')} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151]">上一步</button>
                <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151]">关闭</button>
                <button onClick={() => { alert('保存成功！'); onClose() }} className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">保存</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   Main Page
   ═══════════════════════════════════════════ */
export default function WarningRulesPage() {
  const [showModal, setShowModal] = useState(false)
  const [searchText, setSearchText] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  const filtered = mockRules.filter((r) => {
    if (searchText && !r.name.includes(searchText) && !r.warningType.includes(searchText)) return false
    if (statusFilter && r.status !== statusFilter) return false
    return true
  })
  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">预警规则</h1>
        </div>
        <button onClick={() => setShowModal(true)} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Plus size={14} /> 新增规则</button>
      </div>

      <div className="mb-4 flex gap-2">
        {['全部', '启用', '停用'].map((s) => (
          <button key={s} onClick={() => { setStatusFilter(s === '全部' ? '' : s); setCurrentPage(1) }}
            className={cn('inline-flex items-center gap-2 rounded-full px-4 py-2 text-sm transition', (s === '全部' && !statusFilter) || statusFilter === s ? 'bg-[#1A56DB] font-medium text-white' : 'border border-[#D1D5DB] bg-white text-[#374151] hover:bg-[#E8F0FE]')}>
            {s}<span className={cn('flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[11px] font-bold', (s === '全部' && !statusFilter) || statusFilter === s ? 'bg-white/20 text-white' : 'bg-[#F3F4F6] text-[#6B7280]')}>{s === '全部' ? mockRules.length : s === '启用' ? mockRules.filter((r) => r.status === '启用').length : mockRules.filter((r) => r.status === '停用').length}</span>
          </button>
        ))}
      </div>

      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <svg width="14" height="14" className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" /></svg>
            <input type="text" placeholder="搜索规则名称或预警类型" value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
              className="h-9 w-60 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB]" />
          </div>
          <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }} className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
            <option value="">全部状态</option><option value="启用">启用</option><option value="停用">停用</option>
          </select>
          <button onClick={() => { setSearchText(''); setStatusFilter(''); setCurrentPage(1) }} className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">重置</button>
        </div>
      </div>

      <div className="overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规则名称</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预警类型</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">触发条件</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">严重程度</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">创建时间</th>
              <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
            </tr></thead>
            <tbody>
              {pageData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3"><div className="text-sm font-medium text-[#1F2937]">{row.name}</div><div className="text-xs text-[#6B7280]">{row.description}</div></td>
                  <td className="whitespace-nowrap px-4 py-3"><span className="rounded-full bg-[#E8F0FE] px-2.5 py-0.5 text-xs text-[#1A56DB]">{row.warningType}</span></td>
                  <td className="max-w-[250px] truncate px-4 py-3 text-sm text-[#6B7280]">{row.triggerCondition}</td>
                  <td className="whitespace-nowrap px-4 py-3"><LevelBadge level={row.level} /></td>
                  <td className="whitespace-nowrap px-4 py-3"><span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium', row.status === '启用' ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#F3F4F6] text-[#6B7280]')}>{row.status}</span></td>
                  <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.createTime}</td>
                  <td className="whitespace-nowrap px-4 py-3"><div className="flex items-center justify-center gap-1"><button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Edit3 size={13} /></button><button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={13} /></button></div></td>
                </tr>
              ))}
              {pageData.length === 0 && <tr><td colSpan={7} className="px-4 py-16 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>}
            </tbody>
          </table>
        </div>
        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&lt;</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition', p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
              ))}
              <button onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374141] transition hover:bg-[#F3F4F6] disabled:opacity-30">&gt;</button>
            </div>
          </div>
        )}
      </div>

      {showModal && <AddRuleModal onClose={() => setShowModal(false)} />}
    </div>
  )
}
