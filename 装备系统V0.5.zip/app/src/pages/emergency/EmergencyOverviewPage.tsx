import { useState, useEffect, useRef } from 'react'
import {
  Shield,
  Search,
  Wrench,
  AlertTriangle,
  Zap,
  Clock,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import DataTable from '@/components/DataTable'

/* ── count-up helper ── */
function useCountUp(target: number, duration = 800, delay = 0) {
  const [count, setCount] = useState(0)
  const rafRef = useRef<number>(0)
  const startRef = useRef<number>(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      startRef.current = 0
      const step = (ts: number) => {
        if (!startRef.current) startRef.current = ts
        const p = Math.min((ts - startRef.current) / duration, 1)
        const eased = 1 - Math.pow(1 - p, 3)
        setCount(Math.floor(eased * target))
        if (p < 1) rafRef.current = requestAnimationFrame(step)
      }
      rafRef.current = requestAnimationFrame(step)
    }, delay)
    return () => {
      clearTimeout(timer)
      cancelAnimationFrame(rafRef.current)
    }
  }, [target, duration, delay])

  return count
}

/* ── pulse dot ── */
function PulseDot({ color = '#DC2626' }: { color?: string }) {
  return (
    <span
      className="inline-block h-2.5 w-2.5 rounded-full"
      style={{
        backgroundColor: color,
        animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }}
    />
  )
}

/* ── emergency level badge ── */
function EmergencyLevelBadge({ level }: { level: string }) {
  const configs: Record<string, { bg: string; text: string; pulse?: boolean }> = {
    '一级战备': { bg: 'bg-[#DC2626]', text: 'text-white', pulse: true },
    '二级战备': { bg: 'bg-[#F59E0B]', text: 'text-white' },
    '三级战备': { bg: 'bg-[#FBBF24]', text: 'text-[#1F2937]' },
  }
  const c = configs[level] || { bg: 'bg-[#6B7280]', text: 'text-white' }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        c.bg,
        c.text
      )}
    >
      {c.pulse && <PulseDot color="#fff" />}
      {level}
    </span>
  )
}

/* ── event type tag ── */
function EventTag({ type }: { type: string }) {
  const colors: Record<string, { bg: string; text: string }> = {
    '自然灾害': { bg: 'bg-[#FEE2E2]', text: 'text-[#DC2626]' },
    '事故灾难': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
    '公共卫生': { bg: 'bg-[#D1FAE5]', text: 'text-[#059669]' },
    '社会安全': { bg: 'bg-[#DBEAFE]', text: 'text-[#2563EB]' },
    '恐怖袭击': { bg: 'bg-[#FEE2E2]', text: 'text-[#991B1B]' },
    '重大安保': { bg: 'bg-[#E8F0FE]', text: 'text-[#1A56DB]' },
  }
  const c = colors[type] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span className={cn('mr-1 inline-block rounded-full px-2 py-0.5 text-[11px]', c.bg, c.text)}>
      {type}
    </span>
  )
}

/* ── readiness status ── */
function ReadinessStatus({ status }: { status: string }) {
  const configs: Record<string, { bg: string; text: string; pulse?: boolean }> = {
    '战备在库': { bg: 'bg-[#DC2626]', text: 'text-white', pulse: true },
    '应急出动': { bg: 'bg-[#F59E0B]', text: 'text-white', pulse: true },
    '检测中': { bg: 'bg-[#3B82F6]', text: 'text-white' },
    '维护中': { bg: 'bg-[#6B7280]', text: 'text-white' },
  }
  const c = configs[status] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        c.bg,
        c.text
      )}
    >
      {c.pulse && <PulseDot color="#fff" />}
      {status}
    </span>
  )
}

/* ── mock data ── */
const equipmentData = [
  { id: 1, name: '防弹背心', model: 'FDY-2R-01', warehouse: '应急仓库A', level: '一级战备', responseTime: '15分钟', events: ['恐怖袭击', '重大安保'], lastCheck: '2026-05-01', nextCheck: '2026-07-01', status: '战备在库' },
  { id: 2, name: '防毒面具', model: 'MF-11B', warehouse: '应急仓库B', level: '一级战备', responseTime: '10分钟', events: ['公共卫生', '事故灾难'], lastCheck: '2026-04-20', nextCheck: '2026-06-18', status: '战备在库' },
  { id: 3, name: '破拆工具组', model: 'PC-200', warehouse: '应急仓库A', level: '二级战备', responseTime: '20分钟', events: ['自然灾害', '事故灾难'], lastCheck: '2026-05-10', nextCheck: '2026-06-10', status: '检测中' },
  { id: 4, name: '应急照明灯', model: 'YZM-LED500', warehouse: '应急仓库C', level: '三级战备', responseTime: '30分钟', events: ['自然灾害', '事故灾难'], lastCheck: '2026-03-15', nextCheck: '2026-06-12', status: '战备在库' },
  { id: 5, name: '救生绳索', model: 'JS-100M', warehouse: '应急仓库B', level: '二级战备', responseTime: '20分钟', events: ['自然灾害'], lastCheck: '2026-05-20', nextCheck: '2026-08-20', status: '维护中' },
  { id: 6, name: '防爆盾牌', model: 'FBDP-5', warehouse: '应急仓库A', level: '一级战备', responseTime: '10分钟', events: ['恐怖袭击', '社会安全'], lastCheck: '2026-04-10', nextCheck: '2026-06-08', status: '战备在库' },
  { id: 7, name: '急救医疗包', model: 'JJ-YL01', warehouse: '应急仓库C', level: '二级战备', responseTime: '15分钟', events: ['公共卫生', '事故灾难'], lastCheck: '2026-05-25', nextCheck: '2026-06-25', status: '检测中' },
  { id: 8, name: '对讲机(应急)', model: 'DJ-8800E', warehouse: '应急仓库A', level: '一级战备', responseTime: '5分钟', events: ['重大安保', '社会安全'], lastCheck: '2026-05-28', nextCheck: '2026-06-28', status: '战备在库' },
]

/* ── main component ── */
export default function EmergencyOverviewPage() {
  const goodCount = useCountUp(2560, 800, 0)
  const checkCount = useCountUp(45, 800, 100)
  const maintainCount = useCountUp(23, 800, 200)
  const faultCount = useCountUp(8, 800, 300)

  const columns = [
    { key: 'name', title: '装备名称' },
    { key: 'model', title: '型号' },
    { key: 'warehouse', title: '所属仓库' },
    {
      key: 'level',
      title: '应急等级',
      render: (row: typeof equipmentData[0]) => <EmergencyLevelBadge level={row.level} />,
    },
    {
      key: 'responseTime',
      title: '响应时间',
      render: (row: typeof equipmentData[0]) => (
        <span className="inline-flex items-center gap-1 text-[13px]">
          <Clock size={13} className="text-[#6B7280]" />
          {row.responseTime}
        </span>
      ),
    },
    {
      key: 'events',
      title: '适用突发事件',
      render: (row: typeof equipmentData[0]) => (
        <div className="flex flex-wrap gap-y-1">
          {row.events.map((e) => <EventTag key={e} type={e} />)}
        </div>
      ),
    },
    { key: 'lastCheck', title: '上次检测' },
    {
      key: 'nextCheck',
      title: '下次检测',
      render: (row: typeof equipmentData[0]) => {
        const daysLeft = Math.ceil((new Date(row.nextCheck).getTime() - Date.now()) / 86400000)
        return (
          <span className={cn(
            'text-[13px]',
            daysLeft < 3 ? 'font-semibold text-[#DC2626]' : daysLeft < 7 ? 'text-[#D97706]' : 'text-[#374151]'
          )}>
            {daysLeft < 3 && <AlertTriangle size={13} className="mr-1 inline text-[#DC2626]" />}
            {row.nextCheck}
          </span>
        )
      },
    },
    {
      key: 'status',
      title: '战备状态',
      render: (row: typeof equipmentData[0]) => <ReadinessStatus status={row.status} />,
    },
  ]

  return (
    <div className="space-y-6">
      {/* ── Emergency Banner ── */}
      <div
        className="relative flex h-10 items-center justify-center gap-2 overflow-hidden rounded-lg text-sm font-semibold text-white"
        style={{
          background: 'linear-gradient(90deg, #DC2626, #B91C1C)',
          backgroundSize: '200% 100%',
          animation: 'shimmer 3s linear infinite',
        }}
      >
        <Zap size={18} className="text-white" />
        <PulseDot color="#fff" />
        应急装备管理专区
      </div>

      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">应急仓库管理</h1>
        <a
          href="#/emergency/quick-outbound"
          className="inline-flex h-11 items-center gap-2 rounded-lg bg-[#DC2626] px-5 text-sm font-medium text-white shadow-lg transition hover:scale-105 hover:bg-[#B91C1C]"
          style={{ animation: 'pulse-shadow 2s infinite' }}
        >
          <Zap size={18} />
          应急一键出库
        </a>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {/* 完好待用 - with pulsing border */}
        <div
          className="rounded-lg border-2 border-[#10B981] bg-white p-5 shadow-md transition hover:shadow-lg"
          style={{ animation: 'border-pulse 2s infinite' }}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE2E2]">
              <Shield size={20} className="text-[#DC2626]" />
            </div>
            <span className="text-sm text-[#6B7280]">完好待用</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#10B981]">{goodCount.toLocaleString()}</div>
          <div className="mt-1 flex items-center gap-1.5">
            <PulseDot color="#10B981" />
            <span className="text-xs text-[#10B981]">随时可出库</span>
          </div>
        </div>

        {/* 检测中 */}
        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEF3C7]">
              <Search size={20} className="text-[#F59E0B]" />
            </div>
            <span className="text-sm text-[#6B7280]">检测中</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#F59E0B]">{checkCount}</div>
          <div className="mt-1 text-xs text-[#6B7280]">正在进行战备检测</div>
        </div>

        {/* 维护中 */}
        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DBEAFE]">
              <Wrench size={20} className="text-[#3B82F6]" />
            </div>
            <span className="text-sm text-[#6B7280]">维护中</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#3B82F6]">{maintainCount}</div>
          <div className="mt-1 text-xs text-[#6B7280]">定期维护保养</div>
        </div>

        {/* 故障待修 */}
        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE2E2]">
              <AlertTriangle size={20} className="text-[#EF4444]" />
            </div>
            <span className="text-sm text-[#6B7280]">故障待修</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#EF4444]">{faultCount}</div>
          <div className="mt-1 text-xs text-[#EF4444]">需紧急处理</div>
        </div>
      </div>

      {/* ── Equipment Table ── */}
      <DataTable
        columns={columns}
        data={equipmentData}
        title="应急装备清单"
        pageSize={10}
      />

      {/* ── Custom keyframes (scoped style) ── */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
        @keyframes pulse-shadow {
          0%, 100% { box-shadow: 0 10px 15px rgba(220, 38, 38, 0.3); }
          50% { box-shadow: 0 10px 25px rgba(220, 38, 38, 0.5); }
        }
        @keyframes border-pulse {
          0%, 100% { border-color: rgba(16, 185, 129, 0.6); }
          50% { border-color: rgba(16, 185, 129, 1); }
        }
      `}</style>
    </div>
  )
}
