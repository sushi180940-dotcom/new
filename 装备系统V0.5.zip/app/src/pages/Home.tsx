import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Package,
  Archive,
  Users,
  ArrowDownCircle,
  ArrowUpCircle,
  AlertTriangle,
  ClipboardCheck,
  ClipboardList,
  Target,
  Hand,
  Wrench,
  ArrowLeftRight,
  Settings as SettingsIcon,
  ChevronRight,
  Pin,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import StatCard from '@/components/StatCard'
import Badge from '@/components/Badge'

/* ─── Mock Data ─── */
const statCards = [
  { icon: <Package size={18} />, iconBg: '#E8F0FE', iconColor: '#1A56DB', title: '装备总数', value: 1256830, trend: 5.2, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/ledger' },
  { icon: <Archive size={18} />, iconBg: '#D1FAE5', iconColor: '#10B981', title: '在库数量', value: 486520, trend: 3.1, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/ledger' },
  { icon: <Users size={18} />, iconBg: '#E0E7FF', iconColor: '#8B5CF6', title: '在用数量', value: 698310, trend: 8.4, trendType: 'up' as const, trendColor: 'green' as const, link: '/personal/my-equipment' },
  { icon: <ArrowDownCircle size={18} />, iconBg: '#DBEAFE', iconColor: '#3B82F6', title: '本月入库', value: 12560, trend: 2.3, trendType: 'down' as const, trendColor: 'red' as const, link: '/warehouse/inbound' },
  { icon: <ArrowUpCircle size={18} />, iconBg: '#FEF3C7', iconColor: '#F59E0B', title: '本月出库', value: 9840, trend: 12.1, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/outbound' },
  { icon: <AlertTriangle size={18} />, iconBg: '#FEE2E2', iconColor: '#EF4444', title: '预警数量', value: 156, trendLabel: '含12条紧急', trendType: 'up' as const, trendColor: 'danger' as const, link: '/supervision/warning-records' },
]

const quickFunctions = [
  { icon: <ArrowDownCircle size={22} />, name: '装备入库', link: '/warehouse/inbound', color: '#1A56DB', bg: '#E8F0FE' },
  { icon: <ClipboardCheck size={22} />, name: '出库审批', link: '/warehouse/outbound', color: '#10B981', bg: '#D1FAE5' },
  { icon: <ClipboardList size={22} />, name: '盘点管理', link: '/warehouse/inventory', color: '#8B5CF6', bg: '#E0E7FF' },
  { icon: <AlertTriangle size={22} />, name: '预警查看', link: '/supervision/warning-records', color: '#EF4444', bg: '#FEE2E2' },
  { icon: <Target size={22} />, name: '配备标准', link: '/basic-info/standard', color: '#F59E0B', bg: '#FEF3C7' },
  { icon: <Hand size={22} />, name: '领用申请', link: '/personal/borrow', color: '#06B6D4', bg: '#CFFAFE' },
  { icon: <Wrench size={22} />, name: '报修登记', link: '/personal/repair', color: '#EC4899', bg: '#FCE7F3' },
  { icon: <ArrowLeftRight size={22} />, name: '调拨申请', link: '/warehouse/transfer', color: '#84CC16', bg: '#ECFCCB' },
]

interface TodoItem {
  priority: '紧急' | '较急' | '常规'
  type: string
  title: string
  submitter: string
  time: string
  result?: '通过' | '驳回'
  processTime?: string
}

const todoPending: TodoItem[] = [
  { priority: '紧急', type: '调拨审批', title: '防弹背心紧急调拨申请', submitter: '王警官', time: '10分钟前' },
  { priority: '较急', type: '报废审批', title: '防弹背心报废申请-编号EQ2024001', submitter: '李警官', time: '1小时前' },
  { priority: '常规', type: '领用审批', title: '新警装备配发申请-张警官', submitter: '张警官', time: '2小时前' },
  { priority: '常规', type: '供应商审核', title: 'XX安防科技有限公司资质审核', submitter: '赵管理员', time: '3小时前' },
  { priority: '常规', type: '装备审核', title: '执法记录仪型号变更审核', submitter: '钱管理员', time: '5小时前' },
]

const todoDone: TodoItem[] = [
  { priority: '常规', type: '调拨审批', title: '防刺服调拨申请-城南分局', submitter: '孙警官', time: '1天前', result: '通过', processTime: '耗时2小时' },
  { priority: '常规', type: '领用审批', title: '手电装备领用申请-赵警官', submitter: '赵警官', time: '1天前', result: '通过', processTime: '耗时30分钟' },
  { priority: '紧急', type: '报废审批', title: '过期防弹头盔报废申请', submitter: '周警官', time: '2天前', result: '驳回', processTime: '耗时1小时' },
  { priority: '较急', type: '装备审核', title: '执法记录仪 firmware 升级审核', submitter: '吴管理员', time: '2天前', result: '通过', processTime: '耗时4小时' },
  { priority: '常规', type: '供应商审核', title: 'XX科技供应商资质年审', submitter: '郑管理员', time: '3天前', result: '通过', processTime: '耗时1天' },
]

const priorityColor: Record<string, string> = {
  紧急: '#EF4444',
  较急: '#F59E0B',
  常规: '#9CA3AF',
}

const notices = [
  { type: '政策法规', title: '关于加强警用装备管理的通知', publisher: '省公安厅警保部', time: '2026-06-01', pinned: true, read: false },
  { type: '业务通知', title: '关于开展装备盘点工作的通知', publisher: '装备管理处', time: '2026-05-28', pinned: false, read: false },
  { type: '系统公告', title: '系统升级维护通知（6月5日）', publisher: '系统管理员', time: '2026-05-25', pinned: false, read: true },
  { type: '业务通知', title: '第二季度装备采购计划提报', publisher: '采购中心', time: '2026-05-20', pinned: false, read: true },
  { type: '政策法规', title: '警用防弹衣配备标准更新说明', publisher: '标准化办公室', time: '2026-05-18', pinned: false, read: true },
]

interface WarningItem {
  level: '提醒' | '警告' | '紧急'
  title: string
  association: string
  time: string
  status: '待处理' | '处理中' | '已处理' | '已忽略'
}

const warnings: WarningItem[] = [
  { level: '紧急', title: '防弹背心库存严重不足', association: 'A区仓库-防弹背心', time: '5分钟前', status: '待处理' },
  { level: '警告', title: '执法记录仪质保即将到期', association: 'B区仓库-执法记录仪', time: '2小时前', status: '处理中' },
  { level: '提醒', title: '装备保养周期提醒', association: 'C区仓库-防刺服', time: '1天前', status: '待处理' },
  { level: '警告', title: '某供应商资质即将到期', association: '供应商管理', time: '2天前', status: '已处理' },
  { level: '紧急', title: '手电筒电池过期预警', association: 'D区仓库-手电筒', time: '3天前', status: '已忽略' },
]

const levelDotColor: Record<string, string> = {
  提醒: '#3B82F6',
  警告: '#F59E0B',
  紧急: '#EF4444',
}

const levelBgColor: Record<string, string> = {
  提醒: '#FFFFFF',
  警告: '#FEF3C7',
  紧急: '#FEE2E2',
}

const statusBadgeVariant: Record<string, 'warning' | 'success' | 'danger' | 'default' | 'info'> = {
  待处理: 'warning',
  处理中: 'info',
  已处理: 'success',
  已忽略: 'default',
}

/* ─── Page Component ─── */
export default function Home() {
  const navigate = useNavigate()
  const [todoTab, setTodoTab] = useState<'pending' | 'done'>('pending')
  const [noticeTab, setNoticeTab] = useState('政策法规')
  const [warningFilter, setWarningFilter] = useState('全部')
  const warningLevelOptions = ['全部', '提醒', '警告', '紧急']

  const filteredWarnings = warningFilter === '全部'
    ? warnings
    : warnings.filter((w) => w.level === warningFilter)

  const noticeTypes = ['政策法规', '业务通知', '系统公告']
  const filteredNotices = notices.filter((n) => n.type === noticeTab)

  return (
    <div className="space-y-6">
      {/* ── Section 1: Stat Cards ── */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
        {statCards.map((card, i) => (
          <StatCard
            key={i}
            icon={card.icon}
            iconBg={card.iconBg}
            iconColor={card.iconColor}
            title={card.title}
            value={card.value}
            trend={card.trend}
            trendType={card.trendType}
            trendLabel={card.trend ? '较上月' : undefined}
            trendColor={card.trendColor}
            delay={i * 80}
            onClick={() => navigate(card.link)}
          />
        ))}
      </div>

      {/* ── Section 2: Quick Functions + Todo ── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
        {/* 常用功能入口 */}
        <div className="rounded-lg bg-white p-5 shadow-md lg:col-span-1">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#1F2937]">常用功能</h3>
            <button className="text-[#6B7280] transition hover:text-[#1A56DB]">
              <SettingsIcon size={16} />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {quickFunctions.map((fn, i) => (
              <button
                key={i}
                onClick={() => navigate(fn.link)}
                className="flex flex-col items-center gap-2 rounded-lg p-3 transition hover:scale-105 hover:bg-[#F9FAFB]"
              >
                <div
                  className="flex h-12 w-12 items-center justify-center rounded-full transition"
                  style={{ backgroundColor: fn.bg }}
                >
                  <span style={{ color: fn.color }}>{fn.icon}</span>
                </div>
                <span className="text-center text-[13px] text-[#374151]">{fn.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 待办/已办事项 */}
        <div className="rounded-lg bg-white p-5 shadow-md lg:col-span-3">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-base font-semibold text-[#1F2937]">待办事项</h3>
              {todoTab === 'pending' && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#EF4444] px-1.5 text-[11px] font-bold text-white">
                  {todoPending.length}
                </span>
              )}
            </div>
            <div className="flex gap-1 rounded-md bg-[#F3F4F6] p-0.5">
              <button
                onClick={() => setTodoTab('pending')}
                className={cn(
                  'rounded px-3 py-1 text-sm transition',
                  todoTab === 'pending' ? 'bg-white font-medium text-[#1A56DB] shadow-sm' : 'text-[#6B7280] hover:text-[#374151]'
                )}
              >
                待办
              </button>
              <button
                onClick={() => setTodoTab('done')}
                className={cn(
                  'rounded px-3 py-1 text-sm transition',
                  todoTab === 'done' ? 'bg-white font-medium text-[#1A56DB] shadow-sm' : 'text-[#6B7280] hover:text-[#374151]'
                )}
              >
                已办
              </button>
            </div>
          </div>

          <div className="max-h-[320px] overflow-y-auto">
            {(todoTab === 'pending' ? todoPending : todoDone).map((item, i) => (
              <div
                key={i}
                className="flex items-center gap-3 border-b border-[#F3F4F6] px-2 py-3 transition hover:bg-[#F9FAFB]"
              >
                <span
                  className="h-2 w-2 shrink-0 rounded-full"
                  style={{ backgroundColor: priorityColor[item.priority] }}
                />
                <Badge variant={item.priority === '紧急' ? 'danger' : item.priority === '较急' ? 'warning' : 'default'}>
                  {item.type}
                </Badge>
                <span className="flex-1 truncate text-sm text-[#1F2937]">{item.title}</span>
                <span className="hidden text-xs text-[#6B7280] sm:inline">{item.submitter}</span>
                <span className="text-xs text-[#9CA3AF]">{item.time}</span>
                {todoTab === 'pending' ? (
                  <button className="rounded-md bg-[#1A56DB] px-3 py-1 text-xs text-white transition hover:bg-[#153E7E]">
                    处理
                  </button>
                ) : item.result ? (
                  <Badge variant={item.result === '通过' ? 'success' : 'danger'}>{item.result}</Badge>
                ) : null}
                {item.processTime && (
                  <span className="text-xs text-[#6B7280]">{item.processTime}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Section 3: Notices + Warnings ── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* 通知公告 */}
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#1F2937]">通知公告</h3>
            <button
              onClick={() => navigate('/forum')}
              className="flex items-center gap-0.5 text-[13px] text-[#1A56DB] transition hover:underline"
            >
              更多 <ChevronRight size={14} />
            </button>
          </div>

          <div className="flex gap-4 border-b border-[#E5E7EB]">
            {noticeTypes.map((type) => (
              <button
                key={type}
                onClick={() => setNoticeTab(type)}
                className={cn(
                  'relative pb-2.5 text-sm transition',
                  noticeTab === type
                    ? 'font-medium text-[#1A56DB]'
                    : 'text-[#6B7280] hover:text-[#374151]'
                )}
              >
                {type}
                {noticeTab === type && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
                )}
              </button>
            ))}
          </div>

          <div className="mt-3 max-h-[280px] overflow-y-auto">
            {filteredNotices.map((notice, i) => (
              <div
                key={i}
                className="group flex gap-3 border-b border-[#F3F4F6] px-2 py-3 transition hover:bg-[#F9FAFB]"
              >
                <span
                  className={cn(
                    'mt-1.5 h-4 w-1 shrink-0 rounded-full',
                    notice.read ? 'bg-[#E5E7EB]' : 'bg-[#1A56DB]'
                  )}
                />
                <div className="min-w-0 flex-1">
                  <p className={cn('truncate text-sm', notice.read ? 'text-[#374151]' : 'font-medium text-[#1F2937]')}>
                    {notice.pinned && (
                      <span className="mr-1 inline-flex items-center gap-0.5 rounded-full bg-[#FEF3C7] px-1.5 py-0.5 text-[11px] font-medium text-[#D97706]">
                        <Pin size={10} /> 置顶
                      </span>
                    )}
                    {notice.title}
                  </p>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="text-xs text-[#6B7280]">{notice.publisher}</span>
                    <span className="text-xs text-[#9CA3AF]">{notice.time}</span>
                  </div>
                </div>
              </div>
            ))}
            {filteredNotices.length === 0 && (
              <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无该类公告</div>
            )}
          </div>
        </div>

        {/* 预警记录 */}
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#1F2937]">预警记录</h3>
            <div className="flex items-center gap-2">
              <select
                value={warningFilter}
                onChange={(e) => setWarningFilter(e.target.value)}
                className="h-7 rounded border border-[#D1D5DB] px-2 text-xs text-[#374151] outline-none"
              >
                {warningLevelOptions.map((o) => (
                  <option key={o} value={o}>{o}</option>
                ))}
              </select>
              <button
                onClick={() => navigate('/supervision/warning-records')}
                className="flex items-center gap-0.5 text-[13px] text-[#1A56DB] transition hover:underline"
              >
                查看全部 <ChevronRight size={14} />
              </button>
            </div>
          </div>

          <div className="max-h-[280px] overflow-y-auto">
            {filteredWarnings.map((w, i) => (
              <div
                key={i}
                className="flex items-center gap-3 border-b border-[#F3F4F6] px-2 py-3 transition hover:brightness-95"
                style={{ backgroundColor: levelBgColor[w.level] }}
              >
                <span
                  className="h-2.5 w-2.5 shrink-0 rounded-full"
                  style={{ backgroundColor: levelDotColor[w.level] }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm text-[#1F2937]">{w.title}</p>
                  <div className="mt-0.5 flex items-center gap-2">
                    <span className="text-xs text-[#6B7280]">{w.association}</span>
                    <span className="text-xs text-[#9CA3AF]">{w.time}</span>
                  </div>
                </div>
                <Badge variant={statusBadgeVariant[w.status] ?? 'default'}>{w.status}</Badge>
                <button
                  onClick={() => navigate('/supervision/warning-records')}
                  className="shrink-0 text-xs text-[#1A56DB] transition hover:underline"
                >
                  处理
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
