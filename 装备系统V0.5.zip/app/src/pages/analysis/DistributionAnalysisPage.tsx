import { useEffect, useRef, useState } from 'react'
import { BarChart2, MapPin, Layers, Activity } from 'lucide-react'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

// Register China map
import chinaJson from './china.json'

/* ── mock data ── */
const provinceData = [
  { name: '河南省', value: 45200 },
  { name: '河北省', value: 32100 },
  { name: '山东省', value: 38500 },
  { name: '山西省', value: 24800 },
  { name: '陕西省', value: 27500 },
  { name: '湖北省', value: 31200 },
  { name: '安徽省', value: 29800 },
  { name: '江苏省', value: 42100 },
  { name: '浙江省', value: 36800 },
  { name: '广东省', value: 45600 },
  { name: '四川省', value: 33400 },
  { name: '云南省', value: 21500 },
  { name: '湖南省', value: 28600 },
  { name: '江西省', value: 22800 },
  { name: '福建省', value: 25200 },
  { name: '辽宁省', value: 28900 },
  { name: '吉林省', value: 18200 },
  { name: '黑龙江省', value: 20100 },
  { name: '甘肃省', value: 15600 },
  { name: '青海省', value: 8900 },
  { name: '贵州省', value: 17200 },
  { name: '广西壮族自治区', value: 19800 },
  { name: '宁夏回族自治区', value: 7200 },
  { name: '新疆维吾尔自治区', value: 16500 },
  { name: '内蒙古自治区', value: 14200 },
  { name: '西藏自治区', value: 5200 },
  { name: '海南省', value: 9800 },
  { name: '北京市', value: 38500 },
  { name: '天津市', value: 21800 },
  { name: '上海市', value: 41200 },
  { name: '重庆市', value: 24500 },
]

const treemapData = [
  {
    name: '省厅本级', value: 8200, children: [
      { name: '刑侦总队', value: 1800 },
      { name: '治安总队', value: 1500 },
      { name: '交警总队', value: 2200 },
      { name: '特警总队', value: 1200 },
      { name: '网安总队', value: 800 },
      { name: '其他部门', value: 700 },
    ],
  },
  {
    name: '郑州市局', value: 12500, children: [
      { name: '金水分局', value: 2800 },
      { name: '二七分局', value: 2200 },
      { name: '中原分局', value: 1900 },
      { name: '管城分局', value: 1600 },
      { name: '郑东分局', value: 1800 },
      { name: '其他分局', value: 2200 },
    ],
  },
  {
    name: '洛阳市局', value: 9800, children: [
      { name: '西工分局', value: 2200 },
      { name: '老城分局', value: 1800 },
      { name: '涧西分局', value: 2000 },
      { name: '洛龙分局', value: 1700 },
      { name: '其他分局', value: 2100 },
    ],
  },
  {
    name: '新乡市局', value: 7200, children: [
      { name: '红旗分局', value: 1800 },
      { name: '卫滨分局', value: 1500 },
      { name: '其他分局', value: 3900 },
    ],
  },
  {
    name: '南阳市局', value: 8500, children: [
      { name: '宛城分局', value: 2000 },
      { name: '卧龙分局', value: 1800 },
      { name: '其他分局', value: 4700 },
    ],
  },
  {
    name: '其他地市', value: 42000, children: [
      { name: '开封', value: 5800 },
      { name: '平顶山', value: 5200 },
      { name: '安阳', value: 6100 },
      { name: '焦作', value: 4800 },
      { name: '许昌', value: 4500 },
      { name: '漯河', value: 3200 },
      { name: '三门峡', value: 3800 },
      { name: '商丘', value: 4200 },
      { name: '信阳', value: 4600 },
    ],
  },
]

const bubbleData = [
  { name: '郑州市局', value: [12500, 86, 3200, '郑州市局'] },
  { name: '洛阳市局', value: [9800, 82, 2800, '洛阳市局'] },
  { name: '新乡市局', value: [7200, 78, 2100, '新乡市局'] },
  { name: '南阳市局', value: [8500, 74, 2500, '南阳市局'] },
  { name: '开封市局', value: [5800, 76, 1800, '开封市局'] },
  { name: '安阳市局', value: [6100, 80, 1900, '安阳市局'] },
  { name: '许昌市局', value: [4500, 72, 1400, '许昌市局'] },
  { name: '商丘市局', value: [4200, 68, 1300, '商丘市局'] },
  { name: '信阳市局', value: [4600, 70, 1450, '信阳市局'] },
  { name: '周口市局', value: [3800, 65, 1200, '周口市局'] },
]

const updateMonths = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
const updateData = [320, 280, 350, 290, 380, 340, 420, 390, 360, 400, 450, 380]

export default function DistributionAnalysisPage() {
  const mapRef = useRef<HTMLDivElement>(null)
  const bubbleRef = useRef<HTMLDivElement>(null)
  const treemapRef = useRef<HTMLDivElement>(null)
  const gaugeRef = useRef<HTMLDivElement>(null)
  const updateRef = useRef<HTMLDivElement>(null)
  const [selectedRegion, setSelectedRegion] = useState('河南省')

  useEffect(() => {
    // Register map
    try {
      echarts.registerMap('china', chinaJson as any)
    } catch { /* map may already be registered */ }
  }, [])

  useEffect(() => {
    const cleanups: (() => void)[] = []

    // 地图热力图
    if (mapRef.current) {
      const chart = echarts.init(mapRef.current)
      chart.setOption({
        title: { text: '装备分布热力图', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '各省份装备保有量分布', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'item', formatter: (p: any) => `${p.name}<br/>装备数量: ${(p.value || 0).toLocaleString()}件<br/>占比: ${p.value ? (p.value / 452000 * 100).toFixed(1) : 0}%` },
        visualMap: { min: 5000, max: 50000, text: ['高', '低'], realtime: false, calculable: true, inRange: { color: ['#DBEAFE', '#93C5FD', '#3B82F6', '#1D4ED8', '#1E3A5F'] }, textStyle: { fontSize: 10 }, left: 0, bottom: 0 },
        series: [{
          type: 'map', map: 'china', roam: true,
          label: { show: false },
          emphasis: { label: { show: true, fontSize: 10 }, itemStyle: { areaColor: '#F59E0B' } },
          select: { itemStyle: { areaColor: '#F59E0B' } },
          data: provinceData,
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      chart.on('click', (params: any) => {
        if (params.name) setSelectedRegion(params.name)
      })
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(mapRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 气泡图
    if (bubbleRef.current) {
      const chart = echarts.init(bubbleRef.current)
      chart.setOption({
        title: { text: '地市装备分布气泡图', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: 'X=装备数量, Y=健康度, 气泡大小=人员规模', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { formatter: (p: any) => `${p.data[3]}<br/>装备: ${p.data[0].toLocaleString()}件<br/>健康度: ${p.data[1]}%<br/>人员: ${p.data[2]}人` },
        grid: { left: 50, right: 20, top: 60, bottom: 40 },
        xAxis: { type: 'value', name: '装备数量', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'value', name: '健康度(%)', min: 50, max: 100, axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{
          type: 'scatter', data: bubbleData.map((d) => d.value),
          symbolSize: (data: any) => Math.sqrt(data[2]) * 0.8,
          itemStyle: { color: (p: any) => { const v = p.data[1]; return v >= 80 ? '#10B981' : v >= 70 ? '#F59E0B' : '#EF4444' }, opacity: 0.7 },
          emphasis: { itemStyle: { opacity: 1, borderColor: '#1F2937', borderWidth: 1 } },
          label: { show: true, formatter: (p: any) => p.data[3], fontSize: 9, position: 'top' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(bubbleRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 矩形树图
    if (treemapRef.current) {
      const chart = echarts.init(treemapRef.current)
      chart.setOption({
        title: { text: '装备层级分布(矩形树图)', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '面积=装备数量', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { formatter: (p: any) => `${p.name}<br/>装备: ${p.value?.toLocaleString()}件` },
        series: [{
          type: 'treemap', data: treemapData,
          itemStyle: { borderColor: '#fff', borderWidth: 2, gapWidth: 2 },
          breadcrumb: { show: true, itemStyle: { color: '#1A56DB' } },
          label: { show: true, fontSize: 11, formatter: '{b}\n{c}件' },
          levels: [
            { itemStyle: { borderColor: '#fff', borderWidth: 3, gapWidth: 3 } },
            { itemStyle: { borderColor: '#fff', borderWidth: 2, gapWidth: 2 } },
          ],
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(treemapRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 健康度仪表盘
    if (gaugeRef.current) {
      const chart = echarts.init(gaugeRef.current)
      chart.setOption({
        title: { text: '全省装备健康度评分', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '综合评估(0-100分)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        series: [{
          type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100,
          splitNumber: 10,
          itemStyle: { color: '#1A56DB' },
          progress: { show: true, width: 20 },
          pointer: { show: true, length: '60%', width: 4 },
          axisLine: { lineStyle: { width: 20, color: [[0.6, '#EF4444'], [0.8, '#F59E0B'], [1, '#10B981']] } },
          axisTick: { show: true, length: 6, lineStyle: { color: 'auto' } },
          splitLine: { length: 12, lineStyle: { color: 'auto', width: 2 } },
          axisLabel: { fontSize: 10, distance: 25, formatter: '{value}' },
          title: { offsetCenter: [0, '70%'], fontSize: 14, fontWeight: 'bold' },
          detail: { fontSize: 32, offsetCenter: [0, '40%'], valueAnimation: true, formatter: '{value}分', color: '#1F2937', fontWeight: 'bold' },
          data: [{ value: 82.5, name: '健康度' }],
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(gaugeRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 更新需求预测
    if (updateRef.current) {
      const chart = echarts.init(updateRef.current)
      chart.setOption({
        title: { text: '装备更新需求预测', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '2026年月度预测(件)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        grid: { left: 50, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: updateMonths, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{
          type: 'bar', data: updateData, barWidth: '50%',
          itemStyle: { color: (p: any) => { const v = p.value; return v >= 400 ? '#EF4444' : v >= 350 ? '#F59E0B' : '#1A56DB' }, borderRadius: [4, 4, 0, 0] },
          label: { show: true, position: 'top', fontSize: 10 },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(updateRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">装备分布分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">全省装备地理分布、层级结构与健康状况分析</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">区域选择</span>
            <select value={selectedRegion} onChange={(e) => setSelectedRegion(e.target.value)} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>河南省</option><option>河北省</option><option>山东省</option><option>广东省</option><option>江苏省</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">装备类别</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部品类</option><option>防护装备</option><option>执法装备</option><option>通信装备</option>
            </select>
          </div>
          <div className="ml-auto flex items-center gap-2 text-xs text-[#6B7280]">
            <MapPin size={12} />
            当前选中: <span className="font-medium text-[#1A56DB]">{selectedRegion}</span>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {[
          { label: '全省装备总量', value: '45,200件', sub: '↑ 5.8% 同比', icon: Layers },
          { label: '装备健康度', value: '82.5分', sub: '良好', icon: Activity },
          { label: '年度更新需求', value: '4,280件', sub: '预计支出¥1,856万' },
          { label: '覆盖单位数', value: '186个', sub: '省/市/县/派出所' },
        ].map((s, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <span className="text-[13px] text-[#6B7280]">{s.label}</span>
            <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value}</div>
            <span className="mt-1 text-xs text-[#6B7280]">{s.sub}</span>
          </div>
        ))}
      </div>

      {/* Map + Gauge row */}
      <div className="mb-4 grid grid-cols-3 gap-4">
        <div className="col-span-2 rounded-lg bg-white p-5 shadow-md">
          <div ref={mapRef} style={{ width: '100%', height: 420 }} />
        </div>
        <div className="space-y-4">
          <div className="rounded-lg bg-white p-5 shadow-md">
            <div ref={gaugeRef} style={{ width: '100%', height: 200 }} />
          </div>
          <div className="rounded-lg bg-white p-5 shadow-md">
            <div ref={updateRef} style={{ width: '100%', height: 200 }} />
          </div>
        </div>
      </div>

      {/* Bubble + Treemap row */}
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={bubbleRef} style={{ width: '100%', height: 360 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={treemapRef} style={{ width: '100%', height: 360 }} />
        </div>
      </div>

      {/* Province table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-[#1F2937]">各省装备保有量排行</h3>
          <span className="text-xs text-[#6B7280]">Top 10</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['排名', '省份', '装备数量', '占全国比例', '健康度评分', '状态'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[...provinceData].sort((a, b) => b.value - a.value).slice(0, 10).map((row, i) => (
                <tr key={i} className={`border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB] ${i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]'}`}>
                  <td className="px-3 py-3"><span className={`inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold ${i < 3 ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#374151]'}`}>{i + 1}</span></td>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.name}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.value.toLocaleString()}件</td>
                  <td className="px-3 py-3 text-[#374151]">{(row.value / 850000 * 100).toFixed(1)}%</td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-20 overflow-hidden rounded-full bg-[#F3F4F6]">
                        <div className="h-full rounded-full bg-[#10B981]" style={{ width: `${75 + Math.random() * 20}%` }} />
                      </div>
                      <span>{(75 + Math.random() * 20).toFixed(0)}</span>
                    </div>
                  </td>
                  <td className="px-3 py-3"><Badge variant="success">正常</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
