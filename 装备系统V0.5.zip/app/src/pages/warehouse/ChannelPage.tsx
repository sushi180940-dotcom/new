import { useState, useEffect } from 'react'
import {
  Wifi,
  WifiOff,
  ArrowDownToLine,
  ArrowUpFromLine,
  Eye,
  RefreshCw,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Channel status card ─── */
interface ChannelInfo {
  id: string
  name: string
  location: string
  online: boolean
  todayIn: number
  todayOut: number
  lastScan: string
}

const channelList: ChannelInfo[] = [
  { id: 'CH-MAIN', name: '主通道', location: '主入口', online: true, todayIn: 312, todayOut: 301, lastScan: '2026-06-03 09:45:22' },
]

function ChannelStatusCards() {
  return (
    <div className="mb-6 grid grid-cols-1 gap-4 max-w-md mx-auto">
      {channelList.map((ch) => (
        <div
          key={ch.id}
          className={cn(
            'rounded-lg border bg-white p-4 shadow-sm transition hover:shadow-md',
            ch.online ? 'border-[#D1FAE5]' : 'border-[#FEE2E2]'
          )}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              {ch.online ? (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#D1FAE5]">
                  <Wifi size={14} className="text-[#059669]" />
                </div>
              ) : (
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FEE2E2]">
                  <WifiOff size={14} className="text-[#DC2626]" />
                </div>
              )}
              <div>
                <p className="text-sm font-semibold text-[#1F2937]">{ch.name}</p>
                <p className="text-xs text-[#6B7280]">{ch.location}</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className={cn('h-2.5 w-2.5 rounded-full', ch.online ? 'bg-[#10B981]' : 'bg-[#EF4444]')} />
              <span className={cn('text-xs', ch.online ? 'text-[#059669]' : 'text-[#DC2626]')}>
                {ch.online ? '在线' : '离线'}
              </span>
            </div>
          </div>
          <div className="mt-3 flex items-center gap-4">
            <div className="flex items-center gap-1.5">
              <ArrowDownToLine size={14} className="text-[#10B981]" />
              <span className="text-xs text-[#6B7280]">进:</span>
              <span className="text-sm font-medium text-[#1F2937]">{ch.todayIn}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ArrowUpFromLine size={14} className="text-[#F59E0B]" />
              <span className="text-xs text-[#6B7280]">出:</span>
              <span className="text-sm font-medium text-[#1F2937]">{ch.todayOut}</span>
            </div>
          </div>
          <p className="mt-2 text-[11px] text-[#9CA3AF]">最近扫描: {ch.lastScan}</p>
        </div>
      ))}
    </div>
  )
}

/* ─── Direction badge ─── */
function DirectionBadge({ direction }: { direction: string }) {
  switch (direction) {
    case 'in':
      return (
        <Badge variant="success">
          <ArrowDownToLine size={12} className="mr-0.5" />
          入库
        </Badge>
      )
    case 'out':
      return (
        <Badge variant="warning">
          <ArrowUpFromLine size={12} className="mr-0.5" />
          出库
        </Badge>
      )
    default:
      return <Badge variant="default">{direction}</Badge>
  }
}

/* ─── Record status badge ─── */
function RecordStatus({ status }: { status: string }) {
  switch (status) {
    case 'normal': return <Badge variant="success" dot>正常</Badge>
    case 'abnormal': return <Badge variant="danger" dot>异常</Badge>
    case 'unmatched': return <Badge variant="warning" dot>未匹配</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock channel records ─── */
const channelRecords = [
  { id: 'TD20260603001', equipment: '防弹背心 FDY3R-JS01', code: 'EQ-2024-001', rfid: 'RFID-A001-8293', channel: 'CH-MAIN 主通道', direction: 'in' as const, time: '2026-06-03 09:45:22', relatedDoc: 'RK20260603001', status: 'normal' as const },
  { id: 'TD20260603002', equipment: '手铐 SK-200A', code: 'EQ-2024-002', rfid: 'RFID-A002-4512', channel: 'CH-MAIN 主通道', direction: 'in' as const, time: '2026-06-03 09:44:18', relatedDoc: 'RK20260603001', status: 'normal' as const },
  { id: 'TD20260603003', equipment: '执法记录仪 DSJ-K8', code: 'EQ-2024-003', rfid: 'RFID-A003-1029', channel: 'CH-MAIN 主通道', direction: 'in' as const, time: '2026-06-03 09:43:05', relatedDoc: 'RK20260603001', status: 'normal' as const },
  { id: 'TD20260603009', equipment: '执法记录仪 DSJ-K8', code: 'EQ-2024-003', rfid: 'RFID-A003-1030', channel: 'CH-MAIN 主通道', direction: 'out' as const, time: '2026-06-03 09:30:22', relatedDoc: 'CK20260603004', status: 'normal' as const },
  { id: 'TD20260603011', equipment: '防弹背心 FDY3R-JS01', code: 'EQ-2024-001', rfid: 'RFID-A001-8293', channel: 'CH-MAIN 主通道', direction: 'out' as const, time: '2026-06-03 09:25:18', relatedDoc: 'CK20260603001', status: 'abnormal' as const },
  { id: 'TD20260603013', equipment: '防割手套 FG-ST08', code: 'EQ-2024-010', rfid: 'RFID-A010-2234', channel: 'CH-MAIN 主通道', direction: 'in' as const, time: '2026-06-03 09:20:33', relatedDoc: 'RK20260603002', status: 'normal' as const },
  { id: 'TD20260603015', equipment: '防弹盾牌 FDP-SD02', code: 'EQ-2024-012', rfid: 'RFID-A012-6712', channel: 'CH-MAIN 主通道', direction: 'out' as const, time: '2026-06-03 09:15:42', relatedDoc: 'DB20260603004', status: 'normal' as const },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'recordNo', label: '记录号', type: 'input' as const, placeholder: '请输入记录号' },
  { key: 'equipment', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
  { key: 'rfid', label: 'RFID号', type: 'input' as const, placeholder: '请输入RFID号' },
  { key: 'channel', label: '通道', type: 'select' as const, options: [
    { label: '主通道', value: 'CH-MAIN' },
  ]},
  { key: 'direction', label: '方向', type: 'select' as const, options: [
    { label: '入库', value: 'in' },
    { label: '出库', value: 'out' },
  ]},
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '正常', value: 'normal' },
    { label: '异常', value: 'abnormal' },
    { label: '未匹配', value: 'unmatched' },
  ]},
]

export default function ChannelPage() {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [stats, setStats] = useState({ online: 0, totalIn: 0, totalOut: 0 })

  useEffect(() => {
    const online = channelList.filter((c) => c.online).length
    const totalIn = channelList.reduce((sum, c) => sum + c.todayIn, 0)
    const totalOut = channelList.reduce((sum, c) => sum + c.todayOut, 0)
    setStats({ online, totalIn, totalOut })
  }, [])

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">通道进出记录</h1>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
          <RefreshCw size={14} /> 刷新
        </button>
      </div>

      {/* Real-time status bar */}
      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <div className="flex items-center gap-3 rounded-lg border border-[#D1FAE5] bg-white p-4 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#D1FAE5]">
            <Wifi size={18} className="text-[#059669]" />
          </div>
          <div>
            <p className="text-xs text-[#6B7280]">通道在线</p>
            <p className="text-lg font-bold text-[#059669]">{stats.online}/{channelList.length}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-lg border border-[#E8F0FE] bg-white p-4 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#E8F0FE]">
            <ArrowDownToLine size={18} className="text-[#1A56DB]" />
          </div>
          <div>
            <p className="text-xs text-[#6B7280]">今日入库</p>
            <p className="text-lg font-bold text-[#1A56DB]">{stats.totalIn}</p>
          </div>
        </div>
        <div className="flex items-center gap-3 rounded-lg border border-[#FEF3C7] bg-white p-4 shadow-sm">
          <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEF3C7]">
            <ArrowUpFromLine size={18} className="text-[#D97706]" />
          </div>
          <div>
            <p className="text-xs text-[#6B7280]">今日出库</p>
            <p className="text-lg font-bold text-[#D97706]">{stats.totalOut}</p>
          </div>
        </div>
      </div>

      {/* Channel status cards */}
      <ChannelStatusCards />

      {/* Filter panel */}
      <FilterPanel
        fields={filterFields}
        values={filterValues}
        onChange={handleFilterChange}
        onSearch={handleSearch}
        onReset={handleReset}
      />

      {/* Channel records table */}
      <div className="mt-4">
        <DataTable
          title="进出记录列表"
          columns={[
            { key: 'id', title: '记录号', width: '140px' },
            { key: 'equipment', title: '装备信息', width: '160px', render: (row) => (
              <div>
                <p className="font-medium text-[#1F2937]">{row.equipment}</p>
                <p className="text-xs text-[#6B7280]">{row.code}</p>
              </div>
            )},
            { key: 'rfid', title: 'RFID号', width: '140px' },
            { key: 'channel', title: '通道位置', width: '140px' },
            { key: 'direction', title: '方向', width: '80px', render: (row) => <DirectionBadge direction={row.direction} /> },
            { key: 'time', title: '识别时间', width: '140px' },
            { key: 'relatedDoc', title: '关联单据', width: '130px', render: (row) => (
              row.relatedDoc !== '-' ? (
                <span className="cursor-pointer text-[#1A56DB] hover:underline">{row.relatedDoc}</span>
              ) : (
                <span className="text-[#9CA3AF]">-</span>
              )
            )},
            { key: 'status', title: '状态', width: '80px', render: (row) => <RecordStatus status={row.status} /> },
          ]}
          data={channelRecords}
          pageSize={10}
          onAdd={() => {}}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={() => (
            <div className="flex items-center justify-center gap-1">
              <button className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                <Eye size={14} />
              </button>
            </div>
          )}
        />
      </div>
    </div>
  )
}
