import { useState } from 'react'
import { Plus, Eye, Edit, Trash2, X, Play, RotateCcw, ClipboardCheck, Package } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  remaining: number
  unit: string
  price: number
  code: string
  rfid: string
  supplier: string
}

interface SelectedEquipment {
  equip: StockEquipment
  actualQty: number
  remark: string
}

interface InventoryTask {
  id: string
  name: string
  scope: string
  warehouse: string
  cycle: '期初盘点' | '存货盘点' | '期末盘点'
  startDate: string
  endDate: string
  assignee: string
  assignUnit: string
  status: 'planned' | 'ongoing' | 'completed'
  equipments: SelectedEquipment[]
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '手持终端 XT-2000', category: '通信设备', model: 'XT-2000/黑色/128G', productionDate: '2024-01-15', expiryDate: '2027-01-15', remaining: 50, unit: '台', price: 3200, code: '1-0-1-01-P001-001-20240301-05-001XXXXXX-0001', rfid: 'RFID001001', supplier: '华为技术有限公司' },
  { id: '2', name: '执法记录仪 DSJ-A7', category: '记录设备', model: 'DSJ-A7/64G/高清', productionDate: '2024-02-20', expiryDate: '2027-02-20', remaining: 30, unit: '台', price: 1800, code: '1-0-1-01-P002-001-20240215-05-002XXXXXX-0003', rfid: 'RFID001002', supplier: '海康威视数字技术股份有限公司' },
  { id: '3', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级/L', productionDate: '2023-11-10', expiryDate: '2028-11-10', remaining: 35, unit: '件', price: 2800, code: '1-0-1-01-P003-001-20240115-10-003XXXXXX-0002', rfid: 'RFID001003', supplier: '华为技术有限公司' },
  { id: '4', name: '对讲机 PD780G', category: '通信设备', model: 'PD780G/U段', productionDate: '2024-01-20', expiryDate: '2027-01-20', remaining: 52, unit: '台', price: 1200, code: '1-0-1-01-P005-001-20240305-05-005XXXXXX-0005', rfid: 'RFID001005', supplier: '烽火通信科技股份有限公司' },
  { id: '5', name: '强光手电 QG-500', category: '照明设备', model: 'QG-500/充电款', productionDate: '2024-02-15', expiryDate: '2027-02-15', remaining: 86, unit: '支', price: 280, code: '1-0-1-01-P007-001-20240310-05-007XXXXXX-0006', rfid: 'RFID001007', supplier: '烽火通信科技股份有限公司' },
  { id: '6', name: '应急照明灯 YD-100', category: '照明设备', model: 'YD-100/LED', productionDate: '2024-01-25', expiryDate: '2026-01-25', remaining: 60, unit: '台', price: 680, code: '1-0-1-01-P008-001-20240120-10-008XXXXXX-0007', rfid: 'RFID001008', supplier: '海康威视数字技术股份有限公司' },
  { id: '7', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', productionDate: '2023-12-05', expiryDate: '2028-12-05', remaining: 40, unit: '顶', price: 1500, code: '1-0-1-01-P004-001-20240115-10-004XXXXXX-0001', rfid: 'RFID001004', supplier: '中兴通讯股份有限公司' },
  { id: '8', name: '防弹盾牌 FDP-3S', category: '防护装备', model: 'FDP-3S/手持型', productionDate: '2024-03-01', expiryDate: '2029-03-01', remaining: 15, unit: '面', price: 2200, code: '1-0-1-01-P006-001-20240220-10-006XXXXXX-0004', rfid: 'RFID001006', supplier: '华为技术有限公司' },
]

/* ═══════════════════════════════════════════
   Mock 数据：盘点任务
   ═══════════════════════════════════════════ */

const initialTasks: InventoryTask[] = [
  { id: 'PD20260603001', name: '2026年第二季度全面盘点', scope: '全部仓库（A/B/C区）', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-06-15', endDate: '2026-06-20', assignee: '张管理员', assignUnit: '装备管理处', status: 'planned', equipments: [] },
  { id: 'PD20260603002', name: 'A区防护装备专项盘点', scope: 'A区（防弹背心/防刺服/头盔）', warehouse: 'A区仓库', cycle: '期初盘点', startDate: '2026-06-10', endDate: '2026-06-12', assignee: '李管理员', assignUnit: '装备管理处', status: 'planned', equipments: [] },
  { id: 'PD20260603003', name: '执法装备月度抽盘', scope: 'C区（执法记录仪/对讲机）', warehouse: 'C区仓库', cycle: '期末盘点', startDate: '2026-06-05', endDate: '2026-06-05', assignee: '王警官', assignUnit: '刑警支队', status: 'planned', equipments: [] },
  { id: 'PD20260603004', name: '2026年5月月度盘点', scope: '全部仓库', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-05-25', endDate: '2026-05-28', assignee: '赵管理员', assignUnit: '装备管理处', status: 'ongoing', equipments: stockEquipments.slice(0, 4).map(e => ({ equip: e, actualQty: e.remaining, remark: '' })) },
  { id: 'PD20260603005', name: 'B区通信设备盘点', scope: 'B区（对讲机/执法记录仪）', warehouse: 'B区仓库', cycle: '期初盘点', startDate: '2026-05-28', endDate: '2026-05-30', assignee: '刘警官', assignUnit: '通信科', status: 'ongoing', equipments: stockEquipments.slice(4, 6).map(e => ({ equip: e, actualQty: e.remaining, remark: '' })) },
  { id: 'PD20260603006', name: '2026年第一季度全面盘点', scope: '全部仓库（A/B/C区）', warehouse: '省厅主仓库', cycle: '期末盘点', startDate: '2026-03-15', endDate: '2026-03-22', assignee: '张管理员', assignUnit: '装备管理处', status: 'completed', equipments: stockEquipments.map(e => ({ equip: e, actualQty: e.remaining, remark: '' })) },
]

/* ═══════════════════════════════════════════
   Status badge
   ═══════════════════════════════════════════ */

function InventoryStatus({ status }: { status: string }) {
  switch (status) {
    case 'planned': return <Badge variant="default">计划中</Badge>
    case 'ongoing': return <Badge variant="info" dot>进行中</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function CycleBadge({ cycle }: { cycle: string }) {
  switch (cycle) {
    case '期初盘点': return <Badge variant="info">期初盘点</Badge>
    case '存货盘点': return <Badge variant="primary">存货盘点</Badge>
    case '期末盘点': return <Badge variant="warning">期末盘点</Badge>
    default: return <Badge variant="default">{cycle}</Badge>
  }
}

/* ═══════════════════════════════════════════
   计算盘点差异
   ═══════════════════════════════════════════ */

function calcVariance(equipments: SelectedEquipment[]) {
  let hasVariance = false
  let totalDiff = 0
  equipments.forEach(e => {
    const diff = e.actualQty - e.equip.remaining
    if (diff !== 0) hasVariance = true
    totalDiff += Math.abs(diff)
  })
  if (!hasVariance) return '无差异'
  return `差异${totalDiff}件`
}

/* ═══════════════════════════════════════════
   库存装备选择弹窗（参考截图2）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedEquipment[]) => void
}) {
  const [selected, setSelected] = useState<SelectedEquipment[]>([])

  if (!open) return null

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, actualQty: equip.remaining, remark: '' }]
    })
  }

  const updateQty = (id: string, delta: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, actualQty: Math.max(1, s.actualQty + delta) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 筛选 */}
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部</option>
            <option>A区仓库</option>
            <option>B区仓库</option>
            <option>C区仓库</option>
          </select>
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部</option>
            <option>通信设备</option>
            <option>记录设备</option>
            <option>防护装备</option>
            <option>照明设备</option>
          </select>
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部</option>
          </select>
          <input type="text" placeholder="装备名称/装备编码" className="h-8 w-48 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：库存装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">一级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">二级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">三级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                </tr>
              </thead>
              <tbody>
                {stockEquipments.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input
                        type="checkbox"
                        checked={isChecked(equip.id)}
                        onChange={() => toggleEquip(equip)}
                        className="h-4 w-4 rounded border-[#D1D5DB]"
                      />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[#9CA3AF]">-</td>
                    <td className="px-3 py-2 text-[#9CA3AF]">-</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{equip.code}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">
              已选择装备 ({selected.length})
            </div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.equip.id} className="mb-3 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span>
                  <button onClick={() => removeSelected(s.equip.id)} className="text-[#EF4444] hover:text-[#DC2626]">
                    <X size={14} />
                  </button>
                </div>
                <div className="mb-2 text-[11px] text-[#6B7280]">
                  <div>数量：{s.equip.remaining}</div>
                  <div>单价：&yen;{s.equip.price.toLocaleString()}</div>
                </div>
                <div className="flex items-center gap-2">
                  <button onClick={() => updateQty(s.equip.id, -1)} className="flex h-6 w-6 items-center justify-center rounded border border-[#D1D5DB] text-[#374151] hover:bg-[#F3F4F6]">-</button>
                  <span className="w-8 text-center text-sm">{s.actualQty}</span>
                  <button onClick={() => updateQty(s.equip.id, 1)} className="flex h-6 w-6 items-center justify-center rounded border border-[#D1D5DB] text-[#374151] hover:bg-[#F3F4F6]">+</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
          <button
            onClick={() => { onConfirm(selected); setSelected([]) }}
            className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]"
          >
            确定
          </button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   创建盘点任务弹窗（参考截图1）
   ═══════════════════════════════════════════ */

function CreateInventoryModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (task: InventoryTask) => void
}) {
  const [taskName, setTaskName] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [cycle, setCycle] = useState<'期初盘点' | '存货盘点' | '期末盘点'>('存货盘点')
  const [assignee, setAssignee] = useState('')
  const [assignUnit, setAssignUnit] = useState('')
  const [warehouse, setWarehouse] = useState('')
  const [selectedEquipments, setSelectedEquipments] = useState<SelectedEquipment[]>([])
  const [showEquipSelect, setShowEquipSelect] = useState(false)

  if (!open) return null

  const taskNo = `PD${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const warehouseOptions = ['请选择', '省厅主仓库', 'A区仓库', 'B区仓库', 'C区仓库']

  const handleConfirmEquip = (selected: SelectedEquipment[]) => {
    setSelectedEquipments(prev => {
      const merged = [...prev]
      selected.forEach(s => {
        if (!merged.some(m => m.equip.id === s.equip.id)) merged.push(s)
      })
      return merged
    })
    setShowEquipSelect(false)
  }

  const handleSave = () => {
    if (!taskName.trim()) { alert('请输入盘点单号'); return }
    if (!startDate) { alert('请选择盘点时间'); return }
    if (!assignee.trim()) { alert('请输入经办人'); return }
    if (!warehouse) { alert('请选择仓库'); return }

    onSave({
      id: taskNo,
      name: taskName,
      scope: `${warehouse}${selectedEquipments.length > 0 ? `（${selectedEquipments.length}种装备）` : ''}`,
      warehouse,
      cycle,
      startDate,
      endDate: endDate || startDate,
      assignee,
      assignUnit: assignUnit || '装备管理处',
      status: 'planned',
      equipments: selectedEquipments,
    })
    // Reset
    setTaskName('')
    setStartDate('')
    setEndDate('')
    setCycle('存货盘点')
    setAssignee('')
    setAssignUnit('')
    setWarehouse('')
    setSelectedEquipments([])
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[900px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">创建盘点任务</h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 grid grid-cols-3 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点单号 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={taskNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点时间 <span className="text-[#EF4444]">*</span></label>
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点类型 <span className="text-[#EF4444]">*</span></label>
                <select value={cycle} onChange={e => setCycle(e.target.value as any)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  <option value="期初盘点">期初盘点</option>
                  <option value="存货盘点">存货盘点</option>
                  <option value="期末盘点">期末盘点</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">经办人 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={assignee} onChange={e => setAssignee(e.target.value)} placeholder="请输入经办人姓名" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">经办单位 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={assignUnit} onChange={e => setAssignUnit(e.target.value)} placeholder="请输入经办单位" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">仓库 <span className="text-[#EF4444]">*</span></label>
                <select value={warehouse} onChange={e => setWarehouse(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* 装备盘点明细 */}
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="text-sm font-semibold text-[#374151]">
                  装备盘点明细 <span className="text-xs font-normal text-[#6B7280]">（共 {selectedEquipments.length} 件）</span>
                </div>
                <div className="flex items-center gap-2">
                  <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">
                    <Package size={13} /> 导出
                  </button>
                  <button className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">
                    <Package size={13} /> 导入
                  </button>
                  <button
                    onClick={() => setShowEquipSelect(true)}
                    className="inline-flex h-8 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-sm text-white hover:bg-[#153E7E]"
                  >
                    <Plus size={13} /> 新增
                  </button>
                </div>
              </div>

              {selectedEquipments.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-8 text-[#9CA3AF]">
                  <p className="text-sm">暂无装备明细，请点击「新增」添加或「导入」批量导入</p>
                  <p className="mt-1 text-xs">导入格式：CSV文件，列顺序为「物资名称,物资类别,规格型号,数量,生产日期,有效期,保养期,单位,单价,总价,装备编码,RFID编码,供应商,备注」</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                        <th className="w-8 px-2 py-2"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">数量</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">保养期</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">总价</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">RFID编码</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">备注</th>
                        <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {selectedEquipments.map((s) => (
                        <tr key={s.equip.id} className="border-b border-[#F3F4F6]">
                          <td className="px-2 py-2 text-center"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></td>
                          <td className="px-3 py-2 font-medium text-[#1F2937]">{s.equip.name}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.category}</td>
                          <td className="px-3 py-2 text-[12px] text-[#6B7280]">{s.equip.model}</td>
                          <td className="px-3 py-2 text-right text-[#1A56DB]">{s.equip.remaining}</td>
                          <td className="px-3 py-2 text-[12px] text-[#374151]">{s.equip.productionDate}</td>
                          <td className="px-3 py-2 text-[12px] text-[#374151]">{s.equip.expiryDate}</td>
                          <td className="px-3 py-2 text-[12px] text-[#374151]">-</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.unit}</td>
                          <td className="px-3 py-2 text-right text-[#374151]">{s.equip.price.toLocaleString()}</td>
                          <td className="px-3 py-2 text-right font-medium text-[#1A56DB]">{(s.equip.remaining * s.equip.price).toLocaleString()}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{s.equip.code}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{s.equip.rfid}</td>
                          <td className="px-3 py-2 text-[11px] text-[#374151]">{s.equip.supplier}</td>
                          <td className="px-3 py-2 text-[#9CA3AF]">-</td>
                          <td className="px-3 py-2 text-center">
                            <button onClick={() => setSelectedEquipments(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">创建盘点任务</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   录入盘点结果弹窗
   ═══════════════════════════════════════════ */

function EnterResultModal({
  open,
  onClose,
  task,
  onSave,
}: {
  open: boolean
  onClose: () => void
  task: InventoryTask | null
  onSave: (task: InventoryTask) => void
}) {
  const [equipments, setEquipments] = useState<SelectedEquipment[]>([])

  if (!open || !task) return null

  const handleUpdateQty = (id: string, actualQty: number) => {
    setEquipments(prev => prev.map(e => e.equip.id === id ? { ...e, actualQty } : e))
  }

  const handleUpdateRemark = (id: string, remark: string) => {
    setEquipments(prev => prev.map(e => e.equip.id === id ? { ...e, remark } : e))
  }

  const currentEquips = equipments.length > 0 ? equipments : task.equipments

  const handleSave = () => {
    onSave({ ...task, equipments: currentEquips, status: 'completed' })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[900px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">录入盘点结果 - {task.name}</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>
        <div className="flex-1 overflow-auto px-6 py-4">
          <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">账面数量</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">实际数量</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">差异</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">备注</th>
                </tr>
              </thead>
              <tbody>
                {currentEquips.map((s) => {
                  const diff = s.actualQty - s.equip.remaining
                  return (
                    <tr key={s.equip.id} className="border-b border-[#F3F4F6]">
                      <td className="px-3 py-2 font-medium text-[#1F2937]">{s.equip.name}</td>
                      <td className="px-3 py-2 text-[12px] text-[#6B7280]">{s.equip.model}</td>
                      <td className="px-3 py-2 text-right text-[#374151]">{s.equip.remaining}</td>
                      <td className="px-3 py-2 text-right">
                        <input
                          type="number"
                          defaultValue={s.actualQty}
                          onChange={e => handleUpdateQty(s.equip.id, parseInt(e.target.value) || 0)}
                          className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-right text-sm outline-none focus:border-[#1A56DB]"
                        />
                      </td>
                      <td className={cn('px-3 py-2 text-right font-medium', diff === 0 ? 'text-[#059669]' : diff > 0 ? 'text-[#1A56DB]' : 'text-[#DC2626]')}>
                        {diff > 0 ? `+${diff}` : diff}
                      </td>
                      <td className="px-3 py-2">
                        <input
                          type="text"
                          defaultValue={s.remark}
                          onChange={e => handleUpdateRemark(s.equip.id, e.target.value)}
                          placeholder="备注"
                          className="h-7 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]"
                        />
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">保存结果</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('planned')
  const [tasks, setTasks] = useState<InventoryTask[]>(initialTasks)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showResultModal, setShowResultModal] = useState(false)
  const [currentTask, setCurrentTask] = useState<InventoryTask | null>(null)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleSaveTask = (task: InventoryTask) => { setTasks(prev => [task, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该盘点任务？')) setTasks(prev => prev.filter(d => d.id !== id)) }
  const handleStart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleRestart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleSaveResult = (task: InventoryTask) => { setTasks(prev => prev.map(t => t.id === task.id ? task : t)) }

  const filteredData = tasks.filter((row) => {
    if (activeTab === 'planned') return row.status === 'planned'
    if (activeTab === 'ongoing') return row.status === 'ongoing'
    if (activeTab === 'completed') return row.status === 'completed'
    return true
  })

  const tabs = [
    { key: 'planned', label: '计划中', count: tasks.filter(t => t.status === 'planned').length },
    { key: 'ongoing', label: '进行中', count: tasks.filter(t => t.status === 'ongoing').length },
    { key: 'completed', label: '已完成', count: tasks.filter(t => t.status === 'completed').length },
  ]

  const filterFields = [
    { key: 'planNo', label: '盘点计划编号', type: 'input' as const, placeholder: '请输入盘点计划编号' },
    { key: 'name', label: '计划名称', type: 'input' as const, placeholder: '请输入计划名称' },
    { key: 'cycle', label: '盘点周期', type: 'select' as const, options: [
      { label: '期初盘点', value: '期初盘点' },
      { label: '存货盘点', value: '存货盘点' },
      { label: '期末盘点', value: '期末盘点' },
    ]},
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '计划中', value: 'planned' },
      { label: '进行中', value: 'ongoing' },
      { label: '已完成', value: 'completed' },
    ]},
    { key: 'assignee', label: '负责人', type: 'input' as const, placeholder: '请输入负责人' },
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备盘点</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
        >
          <Plus size={14} /> 新建盘点计划
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Inventory table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划编号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点范围</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点周期</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">负责人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点差异</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-48 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#1F2937]">{row.name}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[200px] truncate" title={row.scope}>{row.scope}</td>
                  <td className="px-4 py-3"><CycleBadge cycle={row.cycle} /></td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.startDate} ~ {row.endDate}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.assignee}</td>
                  <td className="px-4 py-3 text-[13px]">
                    <span className={cn(
                      row.status === 'completed' ? 'text-[#059669]' : 'text-[#9CA3AF]'
                    )}>
                      {row.status === 'completed' ? calcVariance(row.equipments) : '待盘点'}
                    </span>
                  </td>
                  <td className="px-4 py-3"><InventoryStatus status={row.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      {/* 计划中：查看、修改、删除、开始盘点 */}
                      {row.status === 'planned' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n范围：${row.scope}\n周期：${row.cycle}\n时间：${row.startDate} ~ ${row.endDate}\n负责人：${row.assignee}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><Edit size={12} /> 修改</button>
                          <button onClick={() => handleDelete(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={12} /> 删除</button>
                          <button onClick={() => handleStart(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white transition hover:bg-[#059669]"><Play size={12} /> 开始盘点</button>
                        </>
                      )}
                      {/* 进行中：查看、录入结果、重新盘点 */}
                      {row.status === 'ongoing' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n范围：${row.scope}\n已盘点：${row.equipments.length}种装备`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button onClick={() => { setCurrentTask(row); setShowResultModal(true) }} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white transition hover:bg-[#153E7E]"><ClipboardCheck size={12} /> 录入结果</button>
                          <button onClick={() => handleRestart(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><RotateCcw size={12} /> 重新盘点</button>
                        </>
                      )}
                      {/* 已完成：查看 */}
                      {row.status === 'completed' && (
                        <button onClick={() => alert(`查看：${row.name}\n范围：${row.scope}\n差异：${calcVariance(row.equipments)}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 创建盘点任务弹窗 */}
      <CreateInventoryModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveTask} />

      {/* 录入结果弹窗 */}
      <EnterResultModal open={showResultModal} onClose={() => setShowResultModal(false)} task={currentTask} onSave={handleSaveResult} />
    </div>
  )
}
