import { useState, useRef, useEffect } from 'react'
import {
  Plus, Upload, Eye, Printer, PackageCheck, FileInput, History, ArrowLeftRight,
  RotateCcw, MoreHorizontal, ChevronDown, ChevronRight, X, AlertCircle,
  ScanLine, FileSpreadsheet, Camera, Wifi, Check, Trash2, Edit3, Warehouse,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface OrgNode { id: string; name: string; level: number; children?: OrgNode[] }

interface WarehouseItem { id: string; code: string; name: string; address: string; orgUnit: string; orgLevel: string; status: string }

interface EquipmentDetail {
  id: string
  name: string; model: string; code: string; unit: string
  isWholeBox: boolean; boxCode: string; rfidCodes: string[]
  purchaseQty: number; deliveryQty: number
  productionDate: string; validityMonths: number; expiryDate: string
  category1: string; category2: string; category3: string
  qualifiedQty: number | null; unqualifiedQty: number | null
  inspectionOpinion: string; inspectionPhotos: string[]
  inspectionStatus: 'pending' | 'qualified' | 'unqualified' | 'return' | 'exchange'
}

interface PurchaseReceipt {
  id: string; orderName: string; contractNo: string
  supplier: string; enterpriseCode: string
  equipmentSummary: string; deliveryDate: string; receiver: string
  status: 'pending-receipt' | 'inspected'
  warehouseId: string | null; warehouseName: string | null
  storageLocation: string | null
  equipments: EquipmentDetail[]
}

interface BaseInboundRecord {
  id: string
  source: string
  storageLocation: string
  equipmentName: string
  model: string
  quantity: number
  inboundDate: string
  inboundBy: string
  status: 'recorded' | 'stored'
}

interface InitialRecord extends BaseInboundRecord {
  materialSource: string
}

interface TransferRecord extends BaseInboundRecord {
  materialSource: string
  transferOrderNo: string
  senderUnit: string
}

interface ReturnRecord extends BaseInboundRecord {
  materialSource: string
  borrower: string
  borrowDate: string
  expectedReturnDate: string
  borrowOrderNo: string
}

interface OtherRecord extends BaseInboundRecord {
  materialSource: string
}

/* ═══════════════════════════════════════════
   组织架构 & 仓库数据（来自仓库信息模块）
   ═══════════════════════════════════════════ */

const orgTree: OrgNode[] = [{
  id: 'h1', name: '河南省公安厅', level: 0,
  children: [
    { id: 'c1', name: '郑州市公安局', level: 1, children: [
      { id: 'd1', name: '金水区公安分局', level: 2, children: [{ id: 's1', name: '花园路派出所', level: 3 }, { id: 's2', name: '经八路派出所', level: 3 }] },
      { id: 'd2', name: '二七区公安分局', level: 2, children: [{ id: 's3', name: '大学路派出所', level: 3 }] },
      { id: 'd3', name: '中原区公安分局', level: 2, children: [{ id: 's4', name: '建设路派出所', level: 3 }] }
    ]},
    { id: 'c2', name: '洛阳市公安局', level: 1, children: [{ id: 'd4', name: '西工区公安分局', level: 2, children: [{ id: 's5', name: '王城路派出所', level: 3 }] }] },
    { id: 'c3', name: '开封市公安局', level: 1, children: [{ id: 'd5', name: '鼓楼区公安分局', level: 2, children: [{ id: 's6', name: '相国寺派出所', level: 3 }] }] },
    { id: 'c4', name: '新乡市公安局', level: 1, children: [{ id: 'd6', name: '牧野区公安分局', level: 2, children: [{ id: 's7', name: '北干道派出所', level: 3 }] }] },
    { id: 'c5', name: '许昌市公安局', level: 1, children: [{ id: 'd7', name: '魏都区公安分局', level: 2, children: [{ id: 's8', name: '南关派出所', level: 3 }] }] }
  ]
}]

const warehouseList: WarehouseItem[] = [
  { id: '1', code: 'CK-2024-001', name: '省厅主装备仓库', address: '郑州市金水区农业路1号', orgUnit: '河南省公安厅', orgLevel: '省', status: '启用' },
  { id: '2', code: 'CK-2024-002', name: '省厅应急物资仓库', address: '郑州市郑东新区商务外环22号', orgUnit: '河南省公安厅', orgLevel: '省', status: '启用' },
  { id: '3', code: 'CK-2024-003', name: '郑州市局装备仓库', address: '郑州市二七区大学路88号', orgUnit: '郑州市公安局', orgLevel: '市', status: '启用' },
  { id: '4', code: 'CK-2024-004', name: '郑州市局城南分库', address: '郑州市管城回族区城南路45号', orgUnit: '郑州市公安局', orgLevel: '市', status: '启用' },
  { id: '5', code: 'CK-2024-005', name: '金水区分局仓库', address: '郑州市金水区花园路120号', orgUnit: '金水区公安分局', orgLevel: '县', status: '启用' },
  { id: '6', code: 'CK-2024-006', name: '二七区分局仓库', address: '郑州市二七区淮河路66号', orgUnit: '二七区公安分局', orgLevel: '县', status: '启用' },
  { id: '7', code: 'CK-2024-007', name: '洛阳市局装备仓库', address: '洛阳市洛龙区开元大道258号', orgUnit: '洛阳市公安局', orgLevel: '市', status: '启用' },
  { id: '8', code: 'CK-2024-009', name: '开封市局装备仓库', address: '开封市鼓楼区中山路88号', orgUnit: '开封市公安局', orgLevel: '市', status: '启用' },
  { id: '9', code: 'CK-2024-010', name: '新乡市局装备仓库', address: '新乡市红旗区平原路112号', orgUnit: '新乡市公安局', orgLevel: '市', status: '启用' },
]

/* ═══════════════════════════════════════════
   常量
   ═══════════════════════════════════════════ */

const inboundTypes = [
  { key: 'purchase', label: '采购入库', icon: PackageCheck },
  { key: 'initial', label: '期初入库', icon: History },
  { key: 'transfer', label: '仓库调拨入库', icon: ArrowLeftRight },
  { key: 'return', label: '归还入库', icon: RotateCcw },
  { key: 'other', label: '其他入库', icon: MoreHorizontal },
]

const purchaseTabs: { key: string; label: string; badge: number; badgeVariant: string }[] = [
  { key: 'pending-receipt', label: '待收货', badge: 5, badgeVariant: 'danger' },
  { key: 'inspected', label: '已验收', badge: 3, badgeVariant: 'warning' },
]

function InboundStatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'recorded': return <Badge variant="warning" dot>已录入</Badge>
    case 'stored': return <Badge variant="success" dot>已入库</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   Mock 数据：采购收货单
   ═══════════════════════════════════════════ */

const purchaseReceipts: PurchaseReceipt[] = [
  {
    id: 'FH20260603001', orderName: '2026年防弹背心采购订单', contractNo: 'HT-2026-001',
    supplier: '江苏安防科技有限公司', enterpriseCode: '91320000132234567X',
    equipmentSummary: '防弹背心x50, 手铐x100, 执法记录仪x30',
    deliveryDate: '2026-06-03', receiver: '河南省公安厅装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ001', category1: '防护装备', category2: '防弹装备', category3: '防弹背心', name: '防弹背心', model: 'FD-BX-III', code: 'ZB-001-001', unit: '件', isWholeBox: true, boxCode: 'BX-202606-001', rfidCodes: ['RFID001','RFID002','RFID003','RFID004','RFID005'], purchaseQty: 200, deliveryQty: 50, productionDate: '2026-03-15', validityMonths: 60, expiryDate: '2031-03-14', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
      { id: 'EQ002', category1: '警械装备', category2: '约束装备', category3: '手铐', name: '手铐', model: 'SK-STD', code: 'ZB-002-001', unit: '副', isWholeBox: true, boxCode: 'BX-202606-002', rfidCodes: ['RFID051','RFID052','RFID053','RFID054','RFID055'], purchaseQty: 500, deliveryQty: 100, productionDate: '2026-02-20', validityMonths: 120, expiryDate: '2036-02-19', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
      { id: 'EQ003', category1: '通信装备', category2: '记录装备', category3: '执法记录仪', name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-003-001', unit: '台', isWholeBox: false, boxCode: '', rfidCodes: ['RFID201','RFID202','RFID203','RFID204','RFID205'], purchaseQty: 150, deliveryQty: 30, productionDate: '2026-04-01', validityMonths: 36, expiryDate: '2029-03-31', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603002', orderName: '2026年防刺服采购订单', contractNo: 'HT-2026-002',
    supplier: '北京警用装备厂', enterpriseCode: '91110000123456789X',
    equipmentSummary: '防刺服x80, 警棍x200',
    deliveryDate: '2026-06-03', receiver: '郑州市公安局装备处',
    status: 'inspected', warehouseId: '3', warehouseName: '郑州市局装备仓库', storageLocation: '河南省公安厅/郑州市公安局',
    equipments: [
      { id: 'EQ004', category1: '防护装备', category2: '防刺装备', category3: '防刺服', name: '防刺服', model: 'FCF-II', code: 'ZB-001-002', unit: '件', isWholeBox: true, boxCode: 'BX-202606-003', rfidCodes: ['RFID301','RFID302','RFID303','RFID304','RFID305'], purchaseQty: 300, deliveryQty: 80, productionDate: '2026-01-10', validityMonths: 48, expiryDate: '2030-01-09', qualifiedQty: 78, unqualifiedQty: 2, inspectionOpinion: '2件有轻微磨损', inspectionPhotos: ['照片1'], inspectionStatus: 'unqualified' },
      { id: 'EQ005', category1: '警械装备', category2: '执勤装备', category3: '警棍', name: '警棍', model: 'JG-TELE', code: 'ZB-002-002', unit: '根', isWholeBox: true, boxCode: 'BX-202606-004', rfidCodes: ['RFID401','RFID402','RFID403','RFID404','RFID405'], purchaseQty: 500, deliveryQty: 200, productionDate: '2026-02-15', validityMonths: 72, expiryDate: '2032-02-14', qualifiedQty: 200, unqualifiedQty: 0, inspectionOpinion: '全部合格', inspectionPhotos: [], inspectionStatus: 'qualified' },
    ],
  },
  {
    id: 'FH20260603003', orderName: '2026年头盔采购订单', contractNo: 'HT-2026-003',
    supplier: '上海防护科技集团', enterpriseCode: '91310000567890123X',
    equipmentSummary: '头盔x120, 反光背心x300',
    deliveryDate: '2026-06-04', receiver: '洛阳市公安局装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ006', category1: '防护装备', category2: '头部防护', category3: '头盔', name: '头盔', model: 'TK-M1', code: 'ZB-001-003', unit: '顶', isWholeBox: true, boxCode: 'BX-202606-005', rfidCodes: ['RFID501','RFID502','RFID503','RFID504','RFID505'], purchaseQty: 400, deliveryQty: 120, productionDate: '2026-03-20', validityMonths: 60, expiryDate: '2031-03-19', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603004', orderName: '执法记录仪补货订单', contractNo: 'HT-2026-004',
    supplier: '广州智能装备有限公司', enterpriseCode: '91440000876543210X',
    equipmentSummary: '执法记录仪x50, 对讲机x80',
    deliveryDate: '2026-06-02', receiver: '开封市公安局装备处',
    status: 'inspected', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ008', category1: '通信装备', category2: '记录装备', category3: '执法记录仪', name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-003-001', unit: '台', isWholeBox: false, boxCode: '', rfidCodes: ['RFID701','RFID702','RFID703','RFID704','RFID705'], purchaseQty: 100, deliveryQty: 50, productionDate: '2026-04-01', validityMonths: 36, expiryDate: '2029-03-31', qualifiedQty: 0, unqualifiedQty: 50, inspectionOpinion: '批次存在严重质量问题', inspectionPhotos: ['照片1','照片2'], inspectionStatus: 'return' },
    ],
  },
  {
    id: 'FH20260603006', orderName: '2026年约束带采购订单', contractNo: 'HT-2026-006',
    supplier: '浙江警用器材厂', enterpriseCode: '91330000456789012X',
    equipmentSummary: '约束带x500, 警示桩x200',
    deliveryDate: '2026-06-04', receiver: '许昌市公安局装备处',
    status: 'inspected', warehouseId: '9', warehouseName: '新乡市局装备仓库', storageLocation: '河南省公安厅/新乡市公安局/牧野区公安分局',
    equipments: [
      { id: 'EQ011', category1: '警械装备', category2: '约束装备', category3: '约束带', name: '约束带', model: 'YS-D500', code: 'ZB-002-003', unit: '条', isWholeBox: true, boxCode: 'BX-202606-008', rfidCodes: ['RFID1001','RFID1002','RFID1003','RFID1004','RFID1005'], purchaseQty: 1000, deliveryQty: 500, productionDate: '2026-02-01', validityMonths: 36, expiryDate: '2029-01-31', qualifiedQty: 495, unqualifiedQty: 5, inspectionOpinion: '5条有轻微色差', inspectionPhotos: [], inspectionStatus: 'unqualified' },
    ],
  },
  {
    id: 'FH20260603007', orderName: '2026年防暴装备采购订单', contractNo: 'HT-2026-007',
    supplier: '重庆安防设备公司', enterpriseCode: '91500000345678901X',
    equipmentSummary: '防弹盾牌x30, 防暴服x40',
    deliveryDate: '2026-06-06', receiver: '河南省公安厅装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ013', category1: '防护装备', category2: '防暴装备', category3: '防弹盾牌', name: '防弹盾牌', model: 'FD-DP30', code: 'ZB-001-004', unit: '面', isWholeBox: true, boxCode: 'BX-202606-010', rfidCodes: ['RFID1201','RFID1202','RFID1203','RFID1204','RFID1205'], purchaseQty: 100, deliveryQty: 30, productionDate: '2026-04-15', validityMonths: 72, expiryDate: '2032-04-14', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603008', orderName: '2026年防护用品采购订单', contractNo: 'HT-2026-008',
    supplier: '天津防护用品有限公司', enterpriseCode: '91120000234567890X',
    equipmentSummary: '防割手套x300, 警用腰带x250',
    deliveryDate: '2026-06-02', receiver: '郑州市公安局装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ014', category1: '防护装备', category2: '手部防护', category3: '防割手套', name: '防割手套', model: 'FG-ST5', code: 'ZB-001-005', unit: '双', isWholeBox: true, boxCode: 'BX-202606-011', rfidCodes: ['RFID1301','RFID1302','RFID1303','RFID1304','RFID1305'], purchaseQty: 600, deliveryQty: 300, productionDate: '2026-03-01', validityMonths: 36, expiryDate: '2029-02-28', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
]

/* ═══════════════════════════════════════════
   Mock 数据：期初入库
   ═══════════════════════════════════════════ */

const initialData: InitialRecord[] = [
  { id: 'QC20260601001', source: '期初入库', materialSource: '历史库存导入', storageLocation: '河南省公安厅', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 200, inboundDate: '2026-06-01', inboundBy: '王管理员', status: 'stored' },
  { id: 'QC20260601002', source: '期初入库', materialSource: '历史库存导入', storageLocation: '郑州市公安局', equipmentName: '手铐', model: 'SK-STD', quantity: 500, inboundDate: '2026-06-01', inboundBy: '李管理员', status: 'stored' },
  { id: 'QC20260601003', source: '期初入库', materialSource: '手动录入', storageLocation: '洛阳市公安局', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 150, inboundDate: '2026-06-03', inboundBy: '张管理员', status: 'recorded' },
  { id: 'QC20260601004', source: '期初入库', materialSource: '历史库存导入', storageLocation: '金水区公安分局', equipmentName: '防刺服', model: 'FCF-II', quantity: 300, inboundDate: '2026-06-01', inboundBy: '赵管理员', status: 'stored' },
  { id: 'QC20260601005', source: '期初入库', materialSource: '手动录入', storageLocation: '二七区公安分局', equipmentName: '警棍', model: 'JG-TELE', quantity: 800, inboundDate: '2026-06-03', inboundBy: '刘管理员', status: 'recorded' },
  { id: 'QC20260601006', source: '期初入库', materialSource: '历史库存导入', storageLocation: '开封市公安局', equipmentName: '头盔', model: 'TK-M1', quantity: 400, inboundDate: '2026-06-02', inboundBy: '陈管理员', status: 'stored' },
]

/* ═══════════════════════════════════════════
   Mock 数据：仓库调拨入库
   ═══════════════════════════════════════════ */

const transferData: TransferRecord[] = [
  { id: 'DB20260603001', source: '仓库调拨入库', materialSource: '同步订单', transferOrderNo: 'DD20260601001', senderUnit: '北京总仓', storageLocation: '河南省公安厅', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 100, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'DB20260603002', source: '仓库调拨入库', materialSource: '手动添加', transferOrderNo: 'DD20260601002', senderUnit: '广州分仓', storageLocation: '郑州市公安局', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 50, inboundDate: '2026-06-03', inboundBy: '李管理员', status: 'recorded' },
  { id: 'DB20260603003', source: '仓库调拨入库', materialSource: '同步订单', transferOrderNo: 'DD20260601003', senderUnit: '成都分仓', storageLocation: '洛阳市公安局', equipmentName: '防刺服', model: 'FCF-II', quantity: 80, inboundDate: '2026-06-02', inboundBy: '张管理员', status: 'stored' },
  { id: 'DB20260603004', source: '仓库调拨入库', materialSource: '手动添加', transferOrderNo: '-', senderUnit: '武汉分仓', storageLocation: '新乡市公安局', equipmentName: '警棍', model: 'JG-TELE', quantity: 200, inboundDate: '2026-06-04', inboundBy: '赵管理员', status: 'recorded' },
]

/* ═══════════════════════════════════════════
   Mock 数据：归还入库
   ═══════════════════════════════════════════ */

const returnData: ReturnRecord[] = [
  { id: 'GH20260603001', source: '归还入库', materialSource: '借用归还', borrower: '张警官/刑侦支队', borrowDate: '2026-05-20', expectedReturnDate: '2026-06-20', borrowOrderNo: 'JY20260601001', storageLocation: '河南省公安厅', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 2, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'GH20260603002', source: '归还入库', materialSource: '借用归还', borrower: '李警官/交警支队', borrowDate: '2026-05-25', expectedReturnDate: '2026-06-25', borrowOrderNo: 'JY20260601002', storageLocation: '郑州市公安局', equipmentName: '对讲机', model: 'DJ-T80', quantity: 5, inboundDate: '2026-06-03', inboundBy: '李管理员', status: 'stored' },
  { id: 'GH20260603003', source: '归还入库', materialSource: '借用归还', borrower: '王警官/治安支队', borrowDate: '2026-05-28', expectedReturnDate: '2026-06-28', borrowOrderNo: 'JY20260601003', storageLocation: '洛阳市公安局', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 10, inboundDate: '2026-06-04', inboundBy: '张管理员', status: 'recorded' },
  { id: 'GH20260603004', source: '归还入库', materialSource: '借用归还', borrower: '赵警官/特警支队', borrowDate: '2026-05-30', expectedReturnDate: '2026-06-30', borrowOrderNo: 'JY20260601004', storageLocation: '开封市公安局', equipmentName: '头盔', model: 'TK-M1', quantity: 15, inboundDate: '2026-06-04', inboundBy: '赵管理员', status: 'recorded' },
]

/* ═══════════════════════════════════════════
   Mock 数据：其他入库
   ═══════════════════════════════════════════ */

const otherData: OtherRecord[] = [
  { id: 'QT20260603001', source: '其他入库', materialSource: '捐赠', storageLocation: '河南省公安厅', equipmentName: '应急照明灯', model: 'YD-ZM100', quantity: 50, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'QT20260603002', source: '其他入库', materialSource: '调配', storageLocation: '郑州市公安局', equipmentName: '急救包', model: 'JJ-B20', quantity: 100, inboundDate: '2026-06-04', inboundBy: '李管理员', status: 'recorded' },
  { id: 'QT20260603003', source: '其他入库', materialSource: '自制', storageLocation: '洛阳市公安局', equipmentName: '喊话器', model: 'HH-Q50', quantity: 30, inboundDate: '2026-06-02', inboundBy: '张管理员', status: 'stored' },
]

/* ═══════════════════════════════════════════
   组织架构树组件
   ═══════════════════════════════════════════ */

function OrgTreeNode({ node, selectedId, onSelect, expandedIds, onToggleExpand }: { node: OrgNode; selectedId: string | null; onSelect: (id: string) => void; expandedIds: Set<string>; onToggleExpand: (id: string) => void }) {
  const isExpanded = expandedIds.has(node.id), hasChildren = node.children && node.children.length > 0
  const levelNames = ['省', '市', '县', '所'], levelColors = ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6']
  return <div><div className={cn('flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition', selectedId === node.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')} style={{ paddingLeft: `${8 + node.level * 16}px` }} onClick={() => { onSelect(node.id); if (hasChildren) onToggleExpand(node.id) }}>{hasChildren ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />) : <span className="w-3.5" />}<span className="mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white" style={{ backgroundColor: levelColors[node.level] || '#6B7280' }}>{levelNames[node.level] || '?'}</span><span className="truncate">{node.name}</span></div>{hasChildren && isExpanded && <div>{node.children!.map((c) => <OrgTreeNode key={c.id} node={c} selectedId={selectedId} onSelect={onSelect} expandedIds={expandedIds} onToggleExpand={onToggleExpand} />)}</div>}</div>
}

/* ═══════════════════════════════════════════
   存储位置选择组件
   ═══════════════════════════════════════════ */

function StorageLocationSelector({ value, onChange }: { value: string | null; onChange: (loc: string) => void }) {
  const [showPicker, setShowPicker] = useState(false)
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['h1']))
  const [selectedWhId, setSelectedWhId] = useState<string | null>(null)

  const toggleExpand = (id: string) => { setExpandedIds(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n }) }

  const getOrgPath = (nodes: OrgNode[], targetId: string, path: string[] = []): string[] | null => {
    for (const n of nodes) {
      if (n.id === targetId) return [...path, n.name]
      if (n.children) {
        const result = getOrgPath(n.children, targetId, [...path, n.name])
        if (result) return result
      }
    }
    return null
  }

  const selectedOrgPath = selectedOrgId ? getOrgPath(orgTree, selectedOrgId) : null
  const displayText = value || (selectedOrgPath ? selectedOrgPath.join('/') : '') || '请选择存储位置'

  const handleConfirm = () => {
    if (selectedOrgPath) {
      const wh = selectedWhId ? warehouseList.find(w => w.id === selectedWhId) : null
      const loc = wh ? `${selectedOrgPath.join('/')}/${wh.name}` : selectedOrgPath.join('/')
      onChange(loc)
    }
    setShowPicker(false)
  }

  return (
    <div className="relative">
      <button onClick={() => setShowPicker(!showPicker)} className="flex h-9 w-full items-center gap-2 rounded-md border border-[#D1D5DB] bg-white px-3 text-left text-sm outline-none transition focus:border-[#1A56DB]">
        <Warehouse size={14} className="text-[#6B7280] shrink-0" />
        <span className={cn('truncate', !value && !selectedOrgPath && 'text-[#9CA3AF]')}>{displayText}</span>
        <ChevronDown size={14} className={cn('ml-auto text-[#6B7280] transition', showPicker && 'rotate-180')} />
      </button>
      {showPicker && (
        <div className="absolute z-50 mt-1 w-[480px] max-w-[90vw] rounded-lg border border-[#E5E7EB] bg-white shadow-lg">
          <div className="flex">
            {/* 组织树 */}
            <div className="w-48 shrink-0 border-r border-[#E5E7EB] p-2">
              <div className="mb-2 text-xs font-semibold text-[#6B7280]">组织架构</div>
              {orgTree.map(n => <OrgTreeNode key={n.id} node={n} selectedId={selectedOrgId} onSelect={setSelectedOrgId} expandedIds={expandedIds} onToggleExpand={toggleExpand} />)}
            </div>
            {/* 仓库列表 */}
            <div className="flex-1 p-2">
              <div className="mb-2 text-xs font-semibold text-[#6B7280]">所属仓库</div>
              {warehouseList.filter(w => {
                if (!selectedOrgId) return true
                const orgPath = getOrgPath(orgTree, selectedOrgId)
                if (!orgPath) return true
                return orgPath.some(p => w.orgUnit.includes(p) || p.includes(w.orgUnit))
              }).map(w => (
                <button key={w.id} onClick={() => setSelectedWhId(selectedWhId === w.id ? null : w.id)} className={cn('flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition hover:bg-[#F9FAFB]', selectedWhId === w.id && 'bg-[#EFF6FF]')}>
                  <div className={cn('flex h-4 w-4 shrink-0 items-center justify-center rounded-full border', selectedWhId === w.id ? 'border-[#1A56DB] bg-[#1A56DB]' : 'border-[#D1D5DB]')}>
                    {selectedWhId === w.id && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
                  </div>
                  <div>
                    <div className="text-[13px] text-[#374151]">{w.name}</div>
                    <div className="text-[11px] text-[#6B7280]">{w.code}</div>
                  </div>
                </button>
              ))}
              {selectedOrgId && warehouseList.filter(w => {
                const orgPath = getOrgPath(orgTree, selectedOrgId)
                if (!orgPath) return true
                return orgPath.some(p => w.orgUnit.includes(p) || p.includes(w.orgUnit))
              }).length === 0 && <div className="py-4 text-center text-xs text-[#9CA3AF]">该组织下暂无仓库</div>}
            </div>
          </div>
          <div className="flex items-center justify-end gap-2 border-t border-[#E5E7EB] px-3 py-2">
            <button onClick={() => setShowPicker(false)} className="h-7 rounded border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151]">取消</button>
            <button onClick={handleConfirm} className="h-7 rounded bg-[#1A56DB] px-3 text-xs text-white">确定</button>
          </div>
        </div>
      )}
    </div>
  )
}

/* ═══════════════════════════════════════════
   验收对话框组件
   ═══════════════════════════════════════════ */

function InspectionDialog({ receipt, open, onClose, onSave }: { receipt: PurchaseReceipt | null; open: boolean; onClose: () => void; onSave: (updated: PurchaseReceipt) => void }) {
  const [equipments, setEquipments] = useState<EquipmentDetail[]>([])
  const [expandedEqId, setExpandedEqId] = useState<string | null>(null)
  const [showRfidFor, setShowRfidFor] = useState<string | null>(null)
  const [photoText, setPhotoText] = useState('')
  const [photoFor, setPhotoFor] = useState<string | null>(null)
  const [storageLocation, setStorageLocation] = useState<string | null>(null)
  const [useUnitName, setUseUnitName] = useState('')
  const [useObject, setUseObject] = useState('')
  const [useAddress, setUseAddress] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (receipt) {
      setEquipments(receipt.equipments.map(e => ({ ...e })))
      setExpandedEqId(null)
      setStorageLocation(receipt.storageLocation)
    }
  }, [receipt])

  if (!open || !receipt) return null

  const handleQtyChange = (eqId: string, val: string) => {
    const num = val === '' ? null : Math.max(0, parseInt(val) || 0)
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      const eq = { ...e, qualifiedQty: num }
      if (num !== null) {
        eq.unqualifiedQty = e.deliveryQty - num
        if (num === 0) eq.inspectionStatus = 'return'
        else if (eq.unqualifiedQty > 0) eq.inspectionStatus = 'unqualified'
        else eq.inspectionStatus = 'qualified'
      }
      return eq
    }))
  }

  const handleOpinionChange = (eqId: string, val: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionOpinion: val } : e)) }
  const handleAddPhoto = (eqId: string, desc: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionPhotos: [...e.inspectionPhotos, desc] } : e)) }
  const handleRemovePhoto = (eqId: string, idx: number) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionPhotos: e.inspectionPhotos.filter((_, i) => i !== idx) } : e)) }
  const handleRfidScan = (eqId: string) => { const newRfid = `RFID-SCAN-${Date.now()}-${Math.floor(Math.random()*1000)}`; setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, rfidCodes: [...e.rfidCodes, newRfid] } : e)) }
  const handleSetReturn = (eqId: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, qualifiedQty: 0, unqualifiedQty: e.deliveryQty, inspectionStatus: 'return' as const } : e)) }
  const handleSetExchange = (eqId: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, qualifiedQty: 0, unqualifiedQty: e.deliveryQty, inspectionStatus: 'exchange' as const } : e)) }

  const getStatusBadge = (eq: EquipmentDetail) => {
    if (eq.qualifiedQty === null) return <Badge variant="warning">待填写</Badge>
    if (eq.inspectionStatus === 'return') return <Badge variant="danger">退货</Badge>
    if (eq.inspectionStatus === 'exchange') return <Badge variant="danger">换货</Badge>
    if (eq.inspectionStatus === 'qualified') return <Badge variant="success">全部合格</Badge>
    if (eq.inspectionStatus === 'unqualified') return <Badge variant="warning">部分合格</Badge>
    return <Badge variant="default">-</Badge>
  }

  const handleSave = () => {
    const allInspected = equipments.every(e => e.qualifiedQty !== null)
    if (!allInspected) { alert('请完成所有装备的合格数量填写'); return }
    onSave({ ...receipt, equipments: equipments.map(e => ({ ...e })), status: 'inspected', storageLocation })
    setEquipments([]); setExpandedEqId(null); setStorageLocation(null); setUseUnitName(''); setUseObject(''); setUseAddress('')
    onClose()
  }

  const handleCancel = () => { setEquipments([]); setExpandedEqId(null); setStorageLocation(null); setUseUnitName(''); setUseObject(''); setUseAddress(''); onClose() }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleCancel} />
      <div className="relative z-10 flex max-h-[90vh] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">装备验收</h2>
            <p className="mt-1 text-xs text-[#6B7280]">发货单：{receipt.id} · 供应商：{receipt.supplier} · 合同：{receipt.contractNo}</p>
          </div>
          <button onClick={handleCancel} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        <div className="flex-1 overflow-auto px-6 py-4">
          {/* 存储位置选择 */}
          <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] px-4 py-3">
            <label className="mb-2 block text-xs font-semibold text-[#374151]">存储位置 <span className="text-[#EF4444]">*</span></label>
            <StorageLocationSelector value={storageLocation} onChange={setStorageLocation} />
          </div>

          {/* 使用单位信息卡片 */}
          <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] px-4 py-3">
            <div className="mb-2 flex items-center gap-2 text-xs text-[#D97706]">
              <AlertCircle size={14} />
              <span>如需直接交付使用，请填写使用单位详情</span>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">单位名称</label>
                <input type="text" value={useUnitName} onChange={e => setUseUnitName(e.target.value)} placeholder="请输入单位名称" className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">使用对象</label>
                <input type="text" value={useObject} onChange={e => setUseObject(e.target.value)} placeholder="请输入使用对象" className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">使用地址</label>
                <input type="text" value={useAddress} onChange={e => setUseAddress(e.target.value)} placeholder="请输入使用地址" className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
          </div>

          {/* 工具栏 */}
          <div className="mb-4 flex items-center gap-2">
            <button onClick={() => fileRef.current?.click()} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileSpreadsheet size={14} /> 导入Excel批量验收</button>
            <button onClick={() => alert('RFID扫描验收：请将RFID读写器靠近装备标签进行批量扫描验收')} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={14} /> RFID扫描验收</button>
            <button onClick={() => alert('连接设备：正在搜索附近的RFID读写器设备...')} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Wifi size={14} /> 连接设备</button>
            <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={() => alert('Excel导入功能演示')} />
          </div>

          {/* 装备验收表格 */}
          <div className="rounded-lg border border-[#E5E7EB] overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-8 px-2 py-2"></th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">型号</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">整箱</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">箱体码/RFID</th>
                  <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">采购数量</th>
                  <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">本次发货</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                  <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期至</th>
                  <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">合格数量</th>
                  <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">状态</th>
                </tr>
              </thead>
              <tbody>
                {equipments.map((eq) => (
                  <>
                    <tr key={eq.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                      <td className="px-2 py-2 text-center"><button onClick={() => setExpandedEqId(expandedEqId === eq.id ? null : eq.id)} className="text-[#6B7280] hover:text-[#1A56DB]">{expandedEqId === eq.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}</button></td>
                      <td className="px-2 py-2 font-medium text-[#1F2937]">{eq.name}</td>
                      <td className="px-2 py-2 text-[#6B7280]">{eq.model}</td>
                      <td className="px-2 py-2 text-[#6B7280]">{eq.code}</td>
                      <td className="px-2 py-2 text-[#374151]">{eq.unit}</td>
                      <td className="px-2 py-2">{eq.isWholeBox ? <span className="rounded bg-[#DBEAFE] px-1.5 py-0.5 text-[11px] text-[#1A56DB]">是 {eq.boxCode}</span> : <span className="text-[#6B7280] text-[11px]">否</span>}</td>
                      <td className="px-2 py-2 text-[#6B7280] text-[11px] max-w-[100px] truncate">{eq.isWholeBox ? eq.boxCode : (eq.rfidCodes.length > 0 ? `${eq.rfidCodes[0]}${eq.rfidCodes.length > 1 ? ` 等${eq.rfidCodes.length}个` : ''}` : '-')}</td>
                      <td className="px-2 py-2 text-right text-[#374151]">{eq.purchaseQty}</td>
                      <td className="px-2 py-2 text-right font-medium text-[#1A56DB]">{eq.deliveryQty}</td>
                      <td className="px-2 py-2 text-[#374151] text-[11px]">{eq.productionDate}</td>
                      <td className="px-2 py-2 text-[#374151] text-[11px]">{eq.expiryDate} ({eq.validityMonths}月)</td>
                      <td className="px-2 py-2 text-center"><input type="number" min={0} max={eq.deliveryQty} value={eq.qualifiedQty ?? ''} onChange={(e) => handleQtyChange(eq.id, e.target.value)} className={cn('h-7 w-16 rounded-md border px-1 text-center text-sm outline-none', eq.qualifiedQty !== null && eq.qualifiedQty === 0 ? 'border-[#EF4444] bg-[#FEE2E2]' : 'border-[#D1D5DB] focus:border-[#1A56DB]')} placeholder="0" /></td>
                      <td className="px-2 py-2 text-center">{getStatusBadge(eq)}</td>
                    </tr>
                    {expandedEqId === eq.id && (
                      <tr>
                        <td colSpan={13} className="border-b border-[#E5E7EB] bg-[#FAFBFC] px-4 py-3">
                          <div className="grid grid-cols-3 gap-4">
                            <div>
                              <label className="mb-1 block text-xs font-medium text-[#374151]">验收意见</label>
                              <textarea value={eq.inspectionOpinion} onChange={(e) => handleOpinionChange(eq.id, e.target.value)} rows={3} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" placeholder="填写合格/不合格原因..." />
                            </div>
                            <div>
                              <label className="mb-1 block text-xs font-medium text-[#374151]">验收照片</label>
                              <div className="flex flex-wrap gap-1.5">
                                {eq.inspectionPhotos.map((photo, idx) => (
                                  <div key={idx} className="relative h-12 w-12 rounded border border-[#E5E7EB] bg-[#F9FAFB] overflow-hidden">
                                    <div className="flex h-full w-full items-center justify-center text-[9px] text-[#6B7280] text-center leading-tight px-0.5">{photo}</div>
                                    <button onClick={() => handleRemovePhoto(eq.id, idx)} className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#EF4444] text-white"><X size={8} /></button>
                                  </div>
                                ))}
                                <button onClick={() => setPhotoFor(eq.id)} className="flex h-12 w-12 flex-col items-center justify-center rounded border border-dashed border-[#D1D5DB] text-[#9CA3AF] hover:border-[#1A56DB] hover:text-[#1A56DB]"><Camera size={12} /><span className="text-[9px]">照片</span></button>
                              </div>
                            </div>
                            <div>
                              <label className="mb-1 block text-xs font-medium text-[#374151]">RFID编码 ({eq.rfidCodes.length}个)</label>
                              <div className="flex items-center gap-2">
                                <button onClick={() => handleRfidScan(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2 text-xs text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={11} /> 扫描</button>
                                <button onClick={() => setShowRfidFor(eq.id)} className="text-xs text-[#1A56DB] hover:underline">查看明细</button>
                              </div>
                            </div>
                          </div>
                          {(eq.qualifiedQty === 0 && eq.qualifiedQty !== null) && (
                            <div className="mt-2 flex items-center gap-2 rounded-md bg-[#FEE2E2] px-3 py-1.5 text-xs text-[#DC2626]">
                              <AlertCircle size={12} />
                              <span>合格数量为0，</span>
                              <button onClick={() => handleSetReturn(eq.id)} className={cn('font-medium underline', eq.inspectionStatus === 'return' && 'font-bold')}>退货处理</button>
                              <span>或</span>
                              <button onClick={() => handleSetExchange(eq.id)} className={cn('font-medium underline', eq.inspectionStatus === 'exchange' && 'font-bold')}>换货处理</button>
                            </div>
                          )}
                        </td>
                      </tr>
                    )}
                  </>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={handleCancel} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">确认验收</button>
        </div>
      </div>

      {/* RFID弹窗 */}
      {showRfidFor && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => setShowRfidFor(null)} />
          <div className="relative z-10 w-[500px] max-w-[90vw] rounded-xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between"><h3 className="text-base font-semibold text-[#1F2937]">RFID编码明细</h3><button onClick={() => setShowRfidFor(null)} className="text-[#6B7280] hover:text-[#EF4444]"><X size={16} /></button></div>
            <div className="max-h-[400px] overflow-auto"><div className="grid grid-cols-3 gap-2">{equipments.find(e => e.id === showRfidFor)?.rfidCodes.map((code, idx) => <div key={idx} className="rounded bg-[#F3F4F6] px-2 py-1.5 text-xs font-mono text-[#374151]">{code}</div>)}</div></div>
          </div>
        </div>
      )}

      {/* 照片弹窗 */}
      {photoFor && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => { setPhotoFor(null); setPhotoText('') }} />
          <div className="relative z-10 w-[380px] max-w-[90vw] rounded-xl bg-white p-5 shadow-2xl">
            <div className="mb-3 flex items-center justify-between"><h3 className="text-base font-semibold text-[#1F2937]">添加验收照片</h3><button onClick={() => { setPhotoFor(null); setPhotoText('') }} className="text-[#6B7280] hover:text-[#EF4444]"><X size={16} /></button></div>
            <input type="text" value={photoText} onChange={(e) => setPhotoText(e.target.value)} placeholder="输入照片描述..." className="mb-3 w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
            <div className="flex justify-end gap-2">
              <button onClick={() => { setPhotoFor(null); setPhotoText('') }} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">取消</button>
              <button onClick={() => { if (photoText.trim()) { handleAddPhoto(photoFor, photoText.trim()); setPhotoText('') } setPhotoFor(null) }} className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">添加</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ═══════════════════════════════════════════
   打印模态框组件
   ═══════════════════════════════════════════ */

function PrintModal({ receipt, open, onClose }: { receipt: PurchaseReceipt | null; open: boolean; onClose: () => void }) {
  const [printType, setPrintType] = useState<'receipt' | 'return' | 'inbound'>('receipt')
  if (!open || !receipt) return null

  const printContent = () => {
    switch (printType) {
      case 'receipt': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#1F2937]">收货单</h2><p className="text-sm text-[#6B7280]">NO. {receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">订单名称：</span>{receipt.orderName}</div><div><span className="text-[#6B7280]">关联合同：</span>{receipt.contractNo}</div><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div><div><span className="text-[#6B7280]">企业编码：</span>{receipt.enterpriseCode}</div><div><span className="text-[#6B7280]">预计送货日期：</span>{receipt.deliveryDate}</div><div><span className="text-[#6B7280]">收货对象：</span>{receipt.receiver}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#F9FAFB]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-left">装备编码</th><th className="px-3 py-2 text-right">本次发货</th></tr></thead><tbody>{receipt.equipments.map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2">{eq.code}</td><td className="px-3 py-2 text-right">{eq.deliveryQty} {eq.unit}</td></tr>)}</tbody></table></div>
      case 'return': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#DC2626]">退货单</h2><p className="text-sm text-[#6B7280]">原发货单号：{receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div><div><span className="text-[#6B7280]">合同：</span>{receipt.contractNo}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#FEE2E2]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-right">退货数量</th><th className="px-3 py-2 text-left">退货原因</th></tr></thead><tbody>{receipt.equipments.filter(e => e.inspectionStatus === 'return' || e.inspectionStatus === 'exchange').map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2 text-right">{eq.deliveryQty} {eq.unit}</td><td className="px-3 py-2">{eq.inspectionOpinion || '质量不合格'}</td></tr>)}</tbody></table></div>
      case 'inbound': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#059669]">入库单</h2><p className="text-sm text-[#6B7280]">关联发货单：{receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">入库仓库：</span>{receipt.warehouseName || '-'}</div><div><span className="text-[#6B7280]">存储位置：</span>{receipt.storageLocation || '-'}</div><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#D1FAE5]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-right">合格数量</th><th className="px-3 py-2 text-right">不合格数量</th></tr></thead><tbody>{receipt.equipments.filter(e => (e.qualifiedQty || 0) > 0).map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2 text-right">{eq.qualifiedQty} {eq.unit}</td><td className="px-3 py-2 text-right">{eq.unqualifiedQty || 0} {eq.unit}</td></tr>)}</tbody></table></div>
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[720px] max-w-[95vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">打印单据</h2>
          <button onClick={onClose} className="text-[#6B7280] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        <div className="px-6 py-4">
          <div className="mb-4 flex gap-2">
            {[{ key: 'receipt' as const, label: '收货单' }, { key: 'return' as const, label: '退货单' }, { key: 'inbound' as const, label: '入库单' }].map(t => <button key={t.key} onClick={() => setPrintType(t.key)} className={cn('rounded-md px-3 py-1.5 text-sm transition', printType === t.key ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]')}>{t.label}</button>)}
          </div>
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-6">{printContent()}</div>
        </div>
        <div className="flex justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">关闭</button>
          <button onClick={() => alert('打印功能演示')} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Printer size={14} className="mr-1 inline" /> 打印</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   通用操作按钮组件
   ═══════════════════════════════════════════ */

function RowActions({ status, onConfirm, onEdit, onDetail, onDelete }: { status: string; onConfirm?: () => void; onEdit?: () => void; onDetail: () => void; onDelete: () => void }) {
  return (
    <div className="flex items-center justify-center gap-1">
      {status === 'recorded' && onConfirm && (
        <button onClick={onConfirm} className="flex h-7 items-center gap-0.5 rounded-md bg-[#10B981] px-2 text-[11px] text-white hover:bg-[#059669]" title="确认"><Check size={11} />确认</button>
      )}
      {status === 'recorded' && onEdit && (
        <button onClick={onEdit} className="flex h-7 w-7 items-center justify-center rounded-md text-[#F59E0B] hover:bg-[#FEF3C7]" title="修改"><Edit3 size={13} /></button>
      )}
      <button onClick={onDetail} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] hover:bg-[#E8F0FE]" title="详情"><Eye size={14} /></button>
      <button onClick={onDelete} className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
    </div>
  )
}

/* ═══════════════════════════════════════════
   采购入库主模块
   ═══════════════════════════════════════════ */

function PurchaseInboundModule() {
  const [activePurchaseTab, setActivePurchaseTab] = useState('pending-receipt')
  const [receipts, setReceipts] = useState<PurchaseReceipt[]>(purchaseReceipts)
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null)
  const [inspectionReceipt, setInspectionReceipt] = useState<PurchaseReceipt | null>(null)
  const [showInspection, setShowInspection] = useState(false)
  const [printReceipt, setPrintReceipt] = useState<PurchaseReceipt | null>(null)
  const [showPrint, setShowPrint] = useState(false)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleReset = () => setFilterValues({})
  const handleInspect = (receipt: PurchaseReceipt) => { setInspectionReceipt(receipt); setShowInspection(true) }
  const handleSaveInspection = (updated: PurchaseReceipt) => { setReceipts(prev => prev.map(r => r.id === updated.id ? updated : r)) }
  const handlePrint = (receipt: PurchaseReceipt) => { setPrintReceipt(receipt); setShowPrint(true) }
  const filteredData = receipts.filter(row => row.status === activePurchaseTab)

  const pendingFilterFields = [
    { key: 'receiptNo', label: '发货单号', type: 'input' as const, placeholder: '请输入发货单号' },
    { key: 'orderName', label: '订单名称', type: 'input' as const, placeholder: '请输入订单名称' },
    { key: 'contractNo', label: '关联合同', type: 'input' as const, placeholder: '请输入合同号' },
    { key: 'supplier', label: '供应商', type: 'select' as const, options: [{ label: '江苏安防科技有限公司', value: '江苏安防' }, { label: '北京警用装备厂', value: '北京警用' }, { label: '上海防护科技集团', value: '上海防护' }, { label: '广州智能装备有限公司', value: '广州智能' }, { label: '深圳视讯安防股份', value: '深圳视讯' }, { label: '浙江警用器材厂', value: '浙江警用' }, { label: '重庆安防设备公司', value: '重庆安防' }, { label: '天津防护用品有限公司', value: '天津防护' }] },
    { key: 'receiver', label: '收货对象', type: 'select' as const, options: [{ label: '河南省公安厅装备处', value: '河南省公安厅装备处' }, { label: '郑州市公安局装备处', value: '郑州市公安局装备处' }, { label: '洛阳市公安局装备处', value: '洛阳市公安局装备处' }, { label: '开封市公安局装备处', value: '开封市公安局装备处' }, { label: '新乡市公安局装备处', value: '新乡市公安局装备处' }, { label: '许昌市公安局装备处', value: '许昌市公安局装备处' }] },
    { key: 'deliveryStart', label: '送货日期（起）', type: 'date' as const },
    { key: 'deliveryEnd', label: '送货日期（止）', type: 'date' as const },
  ]

  const inspectedFilterFields = [
    { key: 'receiptNo', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'orderName', label: '采购项目', type: 'input' as const, placeholder: '请输入采购项目' },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: '河南省公安厅', value: '河南省公安厅' }, { label: '郑州市公安局', value: '郑州市公安局' }, { label: '洛阳市公安局', value: '洛阳市公安局' }, { label: '新乡市公安局', value: '新乡市公安局' }] },
  ]

  return (
    <>
      {/* 子标签 */}
      <div className="mt-4 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {purchaseTabs.map((tab) => (
            <button key={tab.key} onClick={() => setActivePurchaseTab(tab.key)} className={cn('relative flex h-10 items-center gap-1.5 text-sm transition', activePurchaseTab === tab.key ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]')}>
              {tab.label}
              {tab.badge > 0 && <span className={`flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-bold text-white ${tab.badgeVariant === 'danger' ? 'bg-[#EF4444]' : tab.badgeVariant === 'warning' ? 'bg-[#F59E0B]' : tab.badgeVariant === 'success' ? 'bg-[#10B981]' : 'bg-[#9CA3AF]'}`}>{tab.badge}</span>}
              {activePurchaseTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
            </button>
          ))}
        </div>
      </div>

      {/* 操作按钮 */}
      {activePurchaseTab === 'pending-receipt' && (
        <div className="mt-4 flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Plus size={14} /> 手工入库</button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"><Upload size={14} /> 导入</button>
        </div>
      )}

      {/* 筛选 */}
      <div className="mt-4">
        <FilterPanel
          fields={activePurchaseTab === 'pending-receipt' ? pendingFilterFields : inspectedFilterFields}
          values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset}
        />
      </div>

      {/* 待收货表格 */}
      {activePurchaseTab === 'pending-receipt' && (
        <div className="mt-4">
          <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                    <th className="w-10 px-2 py-3"></th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发货单号</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">订单名称</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">关联合同</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">企业编码</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备清单</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预计送货日期</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">收货对象</th>
                    <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.map((row) => (
                    <>
                      <tr key={row.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', expandedRowId === row.id && 'bg-[#F9FAFB]')}>
                        <td className="px-2 py-3 text-center"><button onClick={() => setExpandedRowId(expandedRowId === row.id ? null : row.id)} className="text-[#6B7280] hover:text-[#1A56DB]">{expandedRowId === row.id ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</button></td>
                        <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.orderName}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.contractNo}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.supplier}</td>
                        <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.enterpriseCode}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentSummary}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.deliveryDate}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.receiver}</td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button onClick={() => handleInspect(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white hover:bg-[#059669]"><PackageCheck size={12} /> 验收</button>
                            <button onClick={() => handlePrint(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><Printer size={14} /></button>
                          </div>
                        </td>
                      </tr>
                      {expandedRowId === row.id && (
                        <tr>
                          <td colSpan={10} className="border-b border-[#E5E7EB] bg-[#FAFBFC] px-4 py-4">
                            <div className="mb-2 text-xs font-semibold text-[#6B7280]">装备明细</div>
                            <table className="w-full border-collapse">
                              <thead>
                                <tr className="border-y border-[#E5E7EB] bg-[#F3F4F6]">
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">一级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">二级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">三级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">型号</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">整箱</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">箱体码/RFID</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">采购数量</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">本次发货</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期至</th>
                                </tr>
                              </thead>
                              <tbody>
                                {row.equipments.map((eq) => (
                                  <tr key={eq.id} className="border-b border-[#F3F4F6]">
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category1}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category2}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category3}</td>
                                    <td className="px-3 py-2 text-[12px] font-medium text-[#1F2937]">{eq.name}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.model}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{eq.code}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.unit}</td>
                                    <td className="px-3 py-2 text-[12px]">{eq.isWholeBox ? <Badge variant="primary">是</Badge> : <span className="text-[#6B7280]">否</span>}</td>
                                    <td className="px-3 py-2 text-[12px]">{eq.isWholeBox ? <span className="text-[#1A56DB]">{eq.boxCode}</span> : <span className="text-[#6B7280]">{eq.rfidCodes.length > 0 ? `${eq.rfidCodes[0]}${eq.rfidCodes.length > 1 ? ` 等${eq.rfidCodes.length}个` : ''}` : '-'}</span>}</td>
                                    <td className="px-3 py-2 text-right text-[12px] text-[#374151]">{eq.purchaseQty}</td>
                                    <td className="px-3 py-2 text-right text-[12px] font-medium text-[#1A56DB]">{eq.deliveryQty}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.productionDate}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.validityMonths}月</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.expiryDate}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 已验收表格 */}
      {activePurchaseTab === 'inspected' && (
        <div className="mt-4">
          <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">采购项目</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">采购日期</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">入库数量</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                    <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.flatMap((row) =>
                    row.equipments.filter(e => (e.qualifiedQty || 0) > 0).map((eq, idx) => (
                      <tr key={`${row.id}-${eq.id}`} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                        <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{idx === 0 ? row.id : ''}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{idx === 0 ? row.orderName : ''}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{idx === 0 ? row.deliveryDate : ''}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation || '-'}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{eq.name}</td>
                        <td className="px-4 py-3 text-[13px] text-[#6B7280]">{eq.model}</td>
                        <td className="px-4 py-3 text-right text-[13px] font-medium text-[#1A56DB]">{eq.qualifiedQty} {eq.unit}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.deliveryDate}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">管理员</td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button onClick={() => handleInspect(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white hover:bg-[#153E7E]"><Eye size={12} /> 查看</button>
                            <button onClick={() => handlePrint(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><Printer size={14} /></button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <InspectionDialog receipt={inspectionReceipt} open={showInspection} onClose={() => { setShowInspection(false); setInspectionReceipt(null) }} onSave={handleSaveInspection} />
      <PrintModal receipt={printReceipt} open={showPrint} onClose={() => { setShowPrint(false); setPrintReceipt(null) }} />
    </>
  )
}

/* ═══════════════════════════════════════════
   期初入库模块
   ═══════════════════════════════════════════ */

function InitialInboundModule() {
  const [data, setData] = useState<InitialRecord[]>(initialData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '历史库存导入', value: '历史库存导入' }, { label: '手动录入', value: '手动录入' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: '河南省公安厅', value: '河南省公安厅' }, { label: '郑州市公安局', value: '郑州市公安局' }, { label: '洛阳市公安局', value: '洛阳市公安局' }, { label: '金水区公安分局', value: '金水区公安分局' }, { label: '二七区公安分局', value: '二七区公安分局' }, { label: '开封市公安局', value: '开封市公安局' }] },
    { key: 'equipmentName', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Upload size={14} /> 导入历史库存</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">入库数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-36 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onEdit={row.status === 'recorded' ? () => alert(`修改 ${row.id}`) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   调拨入库模块
   ═══════════════════════════════════════════ */

function TransferInboundModule() {
  const [data, setData] = useState<TransferRecord[]>(transferData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '同步订单', value: '同步订单' }, { label: '手动添加', value: '手动添加' }] },
    { key: 'transferOrderNo', label: '调拨单号', type: 'input' as const, placeholder: '请输入调拨单号' },
    { key: 'senderUnit', label: '发物单位', type: 'select' as const, options: [{ label: '北京总仓', value: '北京总仓' }, { label: '广州分仓', value: '广州分仓' }, { label: '成都分仓', value: '成都分仓' }, { label: '武汉分仓', value: '武汉分仓' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: '河南省公安厅', value: '河南省公安厅' }, { label: '郑州市公安局', value: '郑州市公安局' }, { label: '洛阳市公安局', value: '洛阳市公安局' }, { label: '新乡市公安局', value: '新乡市公安局' }] },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileInput size={14} /> 选择同步订单</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调拨单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发物单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">调拨数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.transferOrderNo}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.senderUnit}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   归还入库模块
   ═══════════════════════════════════════════ */

function ReturnInboundModule() {
  const [data, setData] = useState<ReturnRecord[]>(returnData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'borrower', label: '借用人/单位', type: 'input' as const, placeholder: '请输入借用人/单位' },
    { key: 'borrowOrderNo', label: '借用单号', type: 'input' as const, placeholder: '请输入借用单号' },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: '河南省公安厅', value: '河南省公安厅' }, { label: '郑州市公安局', value: '郑州市公安局' }, { label: '洛阳市公安局', value: '洛阳市公安局' }, { label: '开封市公安局', value: '开封市公安局' }] },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileInput size={14} /> 选择同步订单</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用人/单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预计归还</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">借用数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.borrower}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.borrowDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.expectedReturnDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.borrowOrderNo}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   其他入库模块
   ═══════════════════════════════════════════ */

function OtherInboundModule() {
  const [data, setData] = useState<OtherRecord[]>(otherData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '捐赠', value: '捐赠' }, { label: '调配', value: '调配' }, { label: '自制', value: '自制' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: '河南省公安厅', value: '河南省公安厅' }, { label: '郑州市公安局', value: '郑州市公安局' }, { label: '洛阳市公安局', value: '洛阳市公安局' }] },
    { key: 'equipmentName', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">入库数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-36 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onEdit={row.status === 'recorded' ? () => alert(`修改 ${row.id}`) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面组件
   ═══════════════════════════════════════════ */

export default function InboundPage() {
  const [activeType, setActiveType] = useState('purchase')

  const renderContent = () => {
    switch (activeType) {
      case 'purchase': return <PurchaseInboundModule />
      case 'initial': return <InitialInboundModule />
      case 'transfer': return <TransferInboundModule />
      case 'return': return <ReturnInboundModule />
      case 'other': return <OtherInboundModule />
      default: return null
    }
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">入库管理</h1>
      </div>
      <div className="grid grid-cols-5 gap-3">
        {inboundTypes.map((type) => {
          const Icon = type.icon
          const isActive = activeType === type.key
          return (
            <button key={type.key} onClick={() => setActiveType(type.key)} className={cn('flex flex-col items-center gap-2 rounded-lg border p-4 transition', isActive ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB] shadow-sm' : 'border-[#E5E7EB] bg-white text-[#6B7280] hover:border-[#D1D5DB] hover:bg-[#F9FAFB]')}>
              <Icon size={24} />
              <span className={cn('text-sm font-medium', isActive && 'text-[#1A56DB]')}>{type.label}</span>
            </button>
          )
        })}
      </div>
      {renderContent()}
    </div>
  )
}
