import { useState } from 'react'
import {
  FileText, Eye, Trash2, X, Plus, Package,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
  repairPerson: string
  repairPhone: string
}

interface SelectedEquipment {
  equip: StockEquipment
  qty: number
}

interface RepairRecord {
  id: string
  materialList: string
  description: string
  repairPerson: string
  phone: string
  handler: string
  applyTime: string
  status: 'draft' | 'submitted'
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '手持终端 XT-2000', category: '通信装备', model: 'XT-2000/黑色', productionDate: '2024-01-15', expiryDate: '2029-01-14', remaining: 50, unit: '台', price: 3200, code: '0101P00100', supplier: '华为技术有限公司', repairPerson: '王建国', repairPhone: '13800138001' },
  { id: '2', name: '执法记录仪 DSJ-A7', category: '执法设备', model: 'DSJ-A7/64G', productionDate: '2024-02-20', expiryDate: '2029-02-19', remaining: 30, unit: '台', price: 1800, code: '0101P00200', supplier: '海康威视数字技术股份有限公司', repairPerson: '李卫国', repairPhone: '13800138002' },
  { id: '3', name: '对讲机 PD780G', category: '通信装备', model: 'PD780G/U段', productionDate: '2024-01-20', expiryDate: '2029-01-19', remaining: 100, unit: '台', price: 1200, code: '0101P00500', supplier: '烽火通信科技股份有限公司', repairPerson: '王建国', repairPhone: '13800138001' },
  { id: '4', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级', productionDate: '2023-11-10', expiryDate: '2033-11-09', remaining: 20, unit: '件', price: 2800, code: '0101P00300', supplier: '华为技术有限公司', repairPerson: '赵明辉', repairPhone: '13800138003' },
  { id: '5', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', productionDate: '2023-12-05', expiryDate: '2033-12-04', remaining: 40, unit: '顶', price: 1500, code: '0101P00400', supplier: '中兴通讯股份有限公司', repairPerson: '赵明辉', repairPhone: '13800138003' },
  { id: '6', name: '应急照明灯 YD-100', category: '照明设备', model: 'YD-100/LED', productionDate: '2024-01-25', expiryDate: '2029-01-24', remaining: 60, unit: '台', price: 680, code: '0101P00600', supplier: '海康威视数字技术股份有限公司', repairPerson: '李卫国', repairPhone: '13800138002' },
  { id: '7', name: '防弹盾牌 FDP-3S', category: '防护装备', model: 'FDP-3S/三级', productionDate: '2024-03-01', expiryDate: '2034-02-29', remaining: 15, unit: '面', price: 2200, code: '0101P00700', supplier: '华为技术有限公司', repairPerson: '赵明辉', repairPhone: '13800138003' },
  { id: '8', name: '催泪喷射器 CL-200', category: '警械装备', model: 'CL-200/200ml', productionDate: '2024-01-10', expiryDate: '2029-01-09', remaining: 100, unit: '支', price: 150, code: '0101P00800', supplier: '大华技术股份有限公司', repairPerson: '陈建华', repairPhone: '13800138004' },
]

/* ═══════════════════════════════════════════
   Mock 数据：报修记录
   ═══════════════════════════════════════════ */

const initialRepairData: RepairRecord[] = [
  { id: 'BX20260603001', materialList: '手持终端 XT-2000 x2, 对讲机 PD780G x1', description: '电池无法充电，续航不足1小时；信号不稳定，通话有杂音', repairPerson: '王建国', phone: '13800138001', handler: '张警官', applyTime: '2026-06-03 08:30', status: 'draft' },
  { id: 'BX20260603002', materialList: '防弹背心 FDY-3R x3', description: '魔术贴老化脱落，无法正常固定', repairPerson: '赵明辉', phone: '13800138003', handler: '李警官', applyTime: '2026-06-02 14:20', status: 'submitted' },
  { id: 'BX20260603003', materialList: '夜视仪 YSY-NV20 x1', description: '成像模糊，红外功能失效', repairPerson: '赵明辉', phone: '13800138003', handler: '赵警官', applyTime: '2026-06-02 10:15', status: 'draft' },
  { id: 'BX20260603004', materialList: '测速仪 CS-LS30 x1, 手铐 SK-200A x2', description: '显示屏出现条纹，读数不准确；锁芯卡滞', repairPerson: '陈建华', phone: '13800138004', handler: '陈警官', applyTime: '2026-06-01 09:45', status: 'submitted' },
  { id: 'BX20260603005', materialList: '执法记录仪 DSJ-A7 x1', description: '摄像头进水起雾，无法录像', repairPerson: '李卫国', phone: '13800138002', handler: '杨警官', applyTime: '2026-05-31 15:30', status: 'draft' },
  { id: 'BX20260603006', materialList: '防弹盾牌 FDP-3S x2', description: '观察窗出现裂纹，影响视线', repairPerson: '赵明辉', phone: '13800138003', handler: '吴警官', applyTime: '2026-05-30 09:00', status: 'submitted' },
  { id: 'BX20260603007', materialList: '对讲机 DJ-8800 x3', description: '电源按键失灵，无法正常开关机', repairPerson: '王建国', phone: '13800138001', handler: '郑警官', applyTime: '2026-05-29 16:30', status: 'submitted' },
  { id: 'BX20260603008', materialList: '防刺服 FCF-FA x2', description: '肩部织带断裂，穿戴松动', repairPerson: '赵明辉', phone: '13800138003', handler: '周警官', applyTime: '2026-05-28 11:20', status: 'draft' },
]

/* ─── Status badge ─── */
function RepairStatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'draft': return <Badge variant="warning" dot>草稿</Badge>
    case 'submitted': return <Badge variant="success" dot>已提交</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   库存装备选择弹窗
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedEquipment[]) => void
}) {
  const [selected, setSelected] = useState<SelectedEquipment[]>([])
  const [searchName, setSearchName] = useState('')

  if (!open) return null

  const filteredStock = stockEquipments.filter(e =>
    searchName ? e.name.includes(searchName) || e.code.includes(searchName) : true
  )

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, qty: 1 }]
    })
  }

  const updateQty = (id: string, qty: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, qty: Math.max(1, Math.min(qty, s.equip.remaining)) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 筛选 */}
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部位置</option>
            <option>省厅仓库1层</option>
            <option>省厅仓库2层</option>
            <option>省厅仓库3层</option>
          </select>
          <input
            type="text"
            value={searchName}
            onChange={e => setSearchName(e.target.value)}
            placeholder="物资名称..."
            className="h-8 w-40 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
          />
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部类别</option>
            <option>通信装备</option>
            <option>执法设备</option>
            <option>防护装备</option>
            <option>照明设备</option>
            <option>警械装备</option>
          </select>
          <button className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">查询</button>
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：库存装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input
                        type="checkbox"
                        checked={isChecked(equip.id)}
                        onChange={() => toggleEquip(equip)}
                        className="h-4 w-4 rounded border-[#D1D5DB]"
                      />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.productionDate}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.expiryDate}</td>
                    <td className="px-3 py-2 text-right font-medium text-[#059669]">{equip.remaining}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.unit}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{equip.price.toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{equip.code}</td>
                    <td className="px-3 py-2 text-[11px] text-[#374151]">{equip.supplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">
              已选择装备 ({selected.length})
            </div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.equip.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span>
                  <button onClick={() => removeSelected(s.equip.id)} className="text-xs text-[#EF4444] hover:underline">删除</button>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-[#6B7280]">
                  <span>类别: {s.equip.category}</span>
                  <span>规格: {s.equip.model}</span>
                  <span>编码: {s.equip.code}</span>
                  <span>余量: {s.equip.remaining}</span>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-[#6B7280]">数量:</span>
                  <input
                    type="number"
                    min={1}
                    max={s.equip.remaining}
                    value={s.qty}
                    onChange={(e) => updateQty(s.equip.id, parseInt(e.target.value) || 1)}
                    className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-center text-sm outline-none focus:border-[#1A56DB]"
                  />
                  <span className="text-[11px] text-[#6B7280]">单价: ¥{s.equip.price.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button
            onClick={() => { onConfirm(selected); setSelected([]); setSearchName('') }}
            className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]"
          >
            确认添加
          </button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   发起报修弹窗
   ═══════════════════════════════════════════ */

function CreateRepairModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (record: RepairRecord) => void
}) {
  const [showEquipSelect, setShowEquipSelect] = useState(false)
  const [selectedEquipments, setSelectedEquipments] = useState<SelectedEquipment[]>([])
  const [description, setDescription] = useState('')
  const [handler, setHandler] = useState('')

  if (!open) return null

  const repairNo = `BX${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  // 自动获取维修人员和联系电话
  const repairPerson = selectedEquipments.length > 0 ? selectedEquipments[0].equip.repairPerson : ''
  const repairPhone = selectedEquipments.length > 0 ? selectedEquipments[0].equip.repairPhone : ''

  const materialList = selectedEquipments.map(s => `${s.equip.name} x${s.qty}`).join(', ')

  const handleConfirmEquip = (selected: SelectedEquipment[]) => {
    setSelectedEquipments(selected)
    setShowEquipSelect(false)
  }

  const handleSave = (status: 'draft' | 'submitted') => {
    if (!description.trim()) { alert('请填写报修说明'); return }
    if (!handler.trim()) { alert('请填写经办人'); return }
    if (selectedEquipments.length === 0) { alert('请添加物资'); return }

    onSave({
      id: repairNo,
      materialList,
      description,
      repairPerson,
      phone: repairPhone,
      handler,
      applyTime: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status,
    })
    // 重置
    setSelectedEquipments([])
    setDescription('')
    setHandler('')
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">发起报修</h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]">
                <div className="h-4 w-1 rounded-full bg-[#059669]" />
                基本信息
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">报修单号 <span className="text-[#9CA3AF]">#</span></label>
                  <input type="text" value={repairNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">报修说明 <span className="text-[#EF4444]">*</span></label>
                  <input type="text" value={description} onChange={e => setDescription(e.target.value)} placeholder="请输入报修说明" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">经办人 <span className="text-[#9CA3AF]">#</span></label>
                  <input type="text" value={handler} onChange={e => setHandler(e.target.value)} placeholder="请输入经办人" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
              </div>
            </div>

            {/* 物资明细 */}
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#D97706]">
                  <div className="h-4 w-1 rounded-full bg-[#D97706]" />
                  物资明细 <span className="text-[#EF4444]">*</span>
                  <span className="text-xs font-normal text-[#6B7280]">({selectedEquipments.length} 种)</span>
                </div>
                <button
                  onClick={() => setShowEquipSelect(true)}
                  className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
                >
                  <Plus size={14} /> 添加物资
                </button>
              </div>

              {selectedEquipments.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-10 text-[#9CA3AF]">
                  <Package size={36} className="mb-2 opacity-40" />
                  <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedEquipments.map((s) => (
                    <div key={s.equip.id} className="flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-[#FAFBFC] px-3 py-2">
                      <div className="flex-1">
                        <div className="text-sm font-medium text-[#1F2937]">{s.equip.name}</div>
                        <div className="text-[11px] text-[#6B7280]">{s.equip.code} · {s.equip.model} · 数量: {s.qty}{s.equip.unit}</div>
                      </div>
                      <button onClick={() => setSelectedEquipments(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 自动获取的维修信息 */}
            {selectedEquipments.length > 0 && (
              <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] p-4">
                <div className="mb-2 text-xs font-semibold text-[#6B7280]">维修信息（自动获取）</div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="mb-1 block text-xs text-[#6B7280]">维修人员</label>
                    <input type="text" value={repairPerson} readOnly className="h-8 w-full rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151]" />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs text-[#6B7280]">联系电话</label>
                    <input type="text" value={repairPhone} readOnly className="h-8 w-full rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151]" />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={() => handleSave('draft')} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">保存草稿</button>
            <button onClick={() => handleSave('submitted')} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">提交</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function RepairPage() {
  const [data, setData] = useState<RepairRecord[]>(initialRepairData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleDelete = (id: string) => { if (confirm('确定删除该报修单？')) setData(prev => prev.filter(d => d.id !== id)) }

  const handleSaveRepair = (record: RepairRecord) => { setData(prev => [record, ...prev]) }

  const filterFields = [
    { key: 'repairNo', label: '报修单号', type: 'input' as const, placeholder: '请输入报修单号' },
    { key: 'materialList', label: '物资清单', type: 'input' as const, placeholder: '请输入物资清单' },
    { key: 'repairPerson', label: '维修人员', type: 'input' as const, placeholder: '请输入维修人员' },
    { key: 'handler', label: '经办人', type: 'input' as const, placeholder: '请输入经办人' },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '草稿', value: 'draft' }, { label: '已提交', value: 'submitted' }] },
    { key: 'dateStart', label: '申请时间（起）', type: 'date' as const },
    { key: 'dateEnd', label: '申请时间（止）', type: 'date' as const },
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">报修管理</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
        >
          <FileText size={14} /> 新建报修
        </button>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} />
      </div>

      {/* Repair table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">报修单号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资清单</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">报修说明</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">维修人员</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">联系电话</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">经办人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {data.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {data.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[200px] truncate" title={row.materialList}>{row.materialList}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[220px] truncate" title={row.description}>{row.description}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.repairPerson}</td>
                  <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.phone}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.handler}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.applyTime}</td>
                  <td className="px-4 py-3"><RepairStatusBadge status={row.status} /></td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => alert(`报修单详情：${row.id}\n\n物资清单：${row.materialList}\n报修说明：${row.description}\n维修人员：${row.repairPerson}\n联系电话：${row.phone}\n经办人：${row.handler}\n申请时间：${row.applyTime}\n状态：${row.status === 'draft' ? '草稿' : '已提交'}`)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="详情"><Eye size={14} /></button>
                      <button onClick={() => handleDelete(row.id)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] transition hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {data.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 发起报修弹窗 */}
      <CreateRepairModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveRepair} />
    </div>
  )
}
