// 当前用户
export const currentUser = {
  name: '张伟',
  badge: '警官证：044891',
  unit: '朝阳分局装备管理科',
  avatar: '',
  role: 'admin',
  phone: '138****6789',
};

// 首页功能菜单
export const homeFeatures = [
  { id: 'in', title: '入库管理', icon: 'Archive', desc: '扫码批量入库', color: '#1565c0' },
  { id: 'out', title: '出库管理', icon: 'PackageOpen', desc: '装备出库核销', color: '#1565c0' },
  { id: 'scan', title: '装备查询', icon: 'Search', desc: '扫码一键查询', color: '#1565c0' },
  { id: 'repair', title: '快速报修', icon: 'Wrench', desc: '故障线上报修', color: '#1565c0' },
  { id: 'messages', title: '消息通知', icon: 'MessageSquare', desc: '系统消息通知', color: '#d32f2f' },
  { id: 'trace', title: '装备溯源', icon: 'GitBranch', desc: '全生命周期', color: '#1565c0' },
  { id: 'apply', title: '装备申领', icon: 'FilePlus', desc: '线上发起申请', color: '#1565c0' },
  { id: 'transfer', title: '交接管理', icon: 'Users', desc: '面对面交接', color: '#1565c0' },
  { id: 'statistics', title: '统计分析', icon: 'BarChart3', desc: '多维度报表', color: '#1565c0' },
  { id: 'users', title: '用户管理', icon: 'UserCog', desc: '账号统一管理', color: '#1565c0' },
  { id: 'warnings', title: '预警信息', icon: 'Bell', desc: '风险异常监控', color: '#ed6c02' },
];

// 审批数据
export const approvalList = [
  { id: 'SP20240520001', type: '装备申领', applicant: '王强', time: '2024-05-20 09:15', status: 'pending', content: '申领防弹背心2件、战术手电3个', items: '防弹背心x2、战术手电x3', urgency: 'high' },
  { id: 'SP20240519002', type: '装备调拨', applicant: '李明', time: '2024-05-19 16:30', status: 'pending', content: '将03号仓库5件装备调拨至东坝派出所', items: '执法记录仪x5', urgency: 'normal' },
  { id: 'SP20240518003', type: '装备交接', applicant: '赵刚', time: '2024-05-18 14:20', status: 'approved', content: '岗位轮换装备交接', items: '对讲机x1、手铐x2', urgency: 'normal' },
  { id: 'SP20240517004', type: '装备申领', applicant: '孙丽', time: '2024-05-17 11:00', status: 'rejected', content: '申领防刺服3件', items: '防刺服x3', urgency: 'low', rejectReason: '库存不足，需等待采购' },
  { id: 'SP20240516005', type: '装备报废', applicant: '周涛', time: '2024-05-16 10:30', status: 'approved', content: '报废超期防弹头盔5个', items: '防弹头盔x5', urgency: 'normal' },
  { id: 'SP20240515006', type: '装备申领', applicant: '吴芳', time: '2024-05-15 09:45', status: 'pending', content: '申领新型执法记录仪8台', items: '执法记录仪x8', urgency: 'high' },
  { id: 'SP20240514007', type: '装备调拨', applicant: '郑海', time: '2024-05-14 15:10', status: 'approved', content: '调拨反光背心至交通大队', items: '反光背心x20', urgency: 'normal' },
  { id: 'SP20240513008', type: '装备交接', applicant: '陈静', time: '2024-05-13 08:30', status: 'pending', content: '临时借调装备归还交接', items: '警用盾牌x3', urgency: 'normal' },
];

// 消息通知
export const messageList = [
  { id: 1, type: 'approval', title: '装备申领审批通知', content: '王强申请的防弹背心已审批通过', time: '10分钟前', read: false },
  { id: 2, type: 'repair', title: '报修进度更新', content: '执法记录仪#2024038已维修完成，待验收', time: '30分钟前', read: false },
  { id: 3, type: 'warning', title: '装备过期预警', content: '编号EQ20210123防弹背心将于15天后过期，请及时处置', time: '1小时前', read: false },
  { id: 4, type: 'business', title: '入库完成通知', content: '到货验收单RK20240520001已完成入库，共入库35件装备', time: '2小时前', read: true },
  { id: 5, type: 'approval', title: '装备调拨审批', content: '李明申请的5台执法记录仪调拨待您审批', time: '3小时前', read: false },
  { id: 6, type: 'repair', title: '报修派单通知', content: '手电#2024115已派单至红星维修商', time: '4小时前', read: true },
  { id: 7, type: 'warning', title: '盘点超期提醒', content: '03号仓库已超过30天未进行盘点，请尽快安排', time: '5小时前', read: false },
  { id: 8, type: 'business', title: '出库完成通知', content: '领用出库单CK20240519002已完成出库', time: '昨天', read: true },
  { id: 9, type: 'approval', title: '交接审批通知', content: '赵刚的装备交接申请已审批通过', time: '昨天', read: true },
  { id: 10, type: 'warning', title: '超期报废预警', content: '编号EQ20190817警棍已超期服役，建议报废处理', time: '昨天', read: true },
];

// 预警信息
export const warningList = [
  { id: 1, type: 'expire', level: 'urgent', title: '装备过期预警', content: '编号EQ20210123防弹背心将于15天后过期', time: '2024-05-20', handler: '李建国' },
  { id: 2, type: 'overdue', level: 'urgent', title: '超期报废预警', content: '编号EQ20190817警棍已超期服役365天', time: '2024-05-19', handler: '王建军' },
  { id: 3, type: 'check', level: 'normal', title: '盘点超期提醒', content: '03号仓库已超过30天未盘点', time: '2024-05-18', handler: '张丽' },
  { id: 4, type: 'loan', level: 'normal', title: '领用超期提醒', content: '编号EQ20230214执法记录仪借出超60天未归还', time: '2024-05-17', handler: '刘洋' },
  { id: 5, type: 'expire', level: 'warning', title: '装备即将过期', content: '编号EQ20210508防刺服将于30天后过期', time: '2024-05-16', handler: '赵敏' },
  { id: 6, type: 'check', level: 'normal', title: '盘点到期提醒', content: '05号仓库将于3天后到盘点周期', time: '2024-05-15', handler: '孙强' },
];

// 装备列表
export const equipmentList = [
  { id: 'EQ202401001', name: '执法记录仪', category: '记录设备', status: 'in_stock', warehouse: '01号装备室', rfid: 'RFID202401001A', purchaseDate: '2024-01-15', warranty: '3年', lastCheck: '2024-05-01', holder: '' },
  { id: 'EQ202301058', name: '防弹背心', category: '防护装备', status: 'in_use', warehouse: '02号装备室', rfid: 'RFID202301058B', purchaseDate: '2023-03-20', warranty: '5年', lastCheck: '2024-04-15', holder: '王强' },
  { id: 'EQ202202112', name: '战术手电', category: '照明设备', status: 'in_use', warehouse: '01号装备室', rfid: 'RFID202202112C', purchaseDate: '2022-06-10', warranty: '2年', lastCheck: '2024-05-10', holder: '李明' },
  { id: 'EQ202401089', name: '对讲机', category: '通讯设备', status: 'in_stock', warehouse: '03号装备室', rfid: 'RFID202401089D', purchaseDate: '2024-02-01', warranty: '2年', lastCheck: '2024-05-05', holder: '' },
  { id: 'EQ201908176', name: '警棍', category: '械具', status: 'overdue', warehouse: '02号装备室', rfid: 'RFID201908176E', purchaseDate: '2019-08-15', warranty: '3年', lastCheck: '2024-03-20', holder: '赵刚' },
];

// 个人装备
export const personalEquipment = [
  {
    id: 'EQ202301058', name: '防弹背心', category: '防护装备', type: 'permanent',
    model: 'FDY-2024-A', quantity: 1, unit: '件', price: 1200, total: 1200,
    equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B',
    supplier: '红星装备厂', isFixedAsset: true,
    productionDate: '2023-01-10', expiryDate: '2028-01-10',
    maintenanceValue: 3, maintenanceUnit: '年',
    issueDate: '2023-04-01', status: 'normal', checkDate: '2024-04-15',
    remark: 'III级防弹标准',
    issueRecords: [
      { event: '采购入库', operator: '李建国', time: '2023-03-20 10:30', detail: '从红星装备厂采购入库，批量50件' },
      { event: '装备领用', operator: '王强', time: '2023-04-01 09:15', detail: '王强申领防弹背心1件，审批通过' },
      { event: '定期盘点', operator: '张丽', time: '2023-06-30 16:00', detail: '03号仓库季度盘点，装备状态正常' },
      { event: '保养维护', operator: '红星维修商', time: '2024-01-15 14:30', detail: '年度保养，更换内衬，状态良好' },
      { event: '定期盘点', operator: '张丽', time: '2024-04-15 10:00', detail: '03号仓库季度盘点，装备状态正常' },
    ],
  },
  {
    id: 'EQ202202112', name: '战术手电', category: '照明设备', type: 'permanent',
    model: 'ZSD-200-X', quantity: 1, unit: '个', price: 280, total: 280,
    equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C',
    supplier: '红星装备厂', isFixedAsset: false,
    productionDate: '2022-05-20', expiryDate: '2025-05-20',
    maintenanceValue: 1, maintenanceUnit: '年',
    issueDate: '2022-07-01', status: 'normal', checkDate: '2024-05-10',
    remark: 'LED强光，200流明',
    issueRecords: [
      { event: '采购入库', operator: '李建国', time: '2022-06-10 11:00', detail: '从红星装备厂采购入库，批量100个' },
      { event: '装备领用', operator: '王强', time: '2022-07-01 10:20', detail: '王强申领战术手电1个' },
      { event: '定期盘点', operator: '张丽', time: '2024-01-10 14:00', detail: '01号装备室盘点，状态正常' },
      { event: '定期盘点', operator: '张丽', time: '2024-05-10 09:30', detail: '01号装备室盘点，状态正常' },
    ],
  },
  {
    id: 'EQ202401001', name: '执法记录仪', category: '记录设备', type: 'temporary',
    model: 'ZFY-4K-01', quantity: 1, unit: '台', price: 1800, total: 1800,
    equipmentCode: 'EQ202401001', rfidCode: 'RFID202401001A',
    supplier: '红星装备厂', isFixedAsset: true,
    productionDate: '2024-01-10', expiryDate: '2027-01-10',
    maintenanceValue: 2, maintenanceUnit: '年',
    issueDate: '2024-05-18', returnDate: '2024-05-25', status: 'normal', checkDate: '2024-05-01',
    remark: '4K高清，128G存储',
    issueRecords: [
      { event: '采购入库', operator: '李建国', time: '2024-01-20 09:00', detail: '从红星装备厂采购入库，批量20台' },
      { event: '临时领用', operator: '王强', time: '2024-05-18 08:30', detail: '王强临时领用执法记录仪1台，归还日期2024-05-25' },
    ],
  },
  {
    id: 'EQ202401089', name: '对讲机', category: '通讯设备', type: 'temporary',
    model: 'DJ-HY-800', quantity: 1, unit: '台', price: 650, total: 650,
    equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D',
    supplier: '国安器材', isFixedAsset: true,
    productionDate: '2024-01-25', expiryDate: '2026-01-25',
    maintenanceValue: 2, maintenanceUnit: '年',
    issueDate: '2024-05-19', returnDate: '2024-05-22', status: 'normal', checkDate: '2024-05-05',
    remark: '800MHz频段',
    issueRecords: [
      { event: '采购入库', operator: '李建国', time: '2024-02-01 14:00', detail: '从国安器材采购入库，批量30台' },
      { event: '临时领用', operator: '王强', time: '2024-05-19 07:15', detail: '王强临时领用对讲机1台，归还日期2024-05-22' },
    ],
  },
  {
    id: 'EQ202302145', name: '防刺手套', category: '防护装备', type: 'permanent',
    model: 'FCST-100', quantity: 1, unit: '双', price: 150, total: 150,
    equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A',
    supplier: '盾甲科技', isFixedAsset: false,
    productionDate: '2023-05-10', expiryDate: '2026-05-10',
    maintenanceValue: 2, maintenanceUnit: '年',
    issueDate: '2023-06-01', status: 'repair', checkDate: '2024-03-15',
    remark: '耐磨防滑',
    issueRecords: [
      { event: '采购入库', operator: '李建国', time: '2023-05-15 10:00', detail: '从盾甲科技采购入库，批量200双' },
      { event: '装备领用', operator: '王强', time: '2023-06-01 09:30', detail: '王强申领防刺手套1双' },
      { event: '故障报修', operator: '王强', time: '2024-03-10 16:00', detail: '手套掌心磨损严重，申请维修' },
      { event: '维修处理', operator: '盾甲维修', time: '2024-03-15 11:00', detail: '已接收维修，预计7个工作日完成' },
    ],
  },
];

// 溯源记录
export const traceRecords = [
  { id: 1, equipmentId: 'EQ202301058', event: '采购入库', operator: '李建国', time: '2023-03-20 10:30', detail: '从红星装备厂采购入库，数量50件' },
  { id: 2, equipmentId: 'EQ202301058', event: '装备领用', operator: '王强', time: '2023-04-01 09:15', detail: '王强申领防弹背心1件，审批通过' },
  { id: 3, equipmentId: 'EQ202301058', event: '定期盘点', operator: '张丽', time: '2023-06-30 16:00', detail: '03号仓库季度盘点，装备状态正常' },
  { id: 4, equipmentId: 'EQ202301058', event: '保养维护', operator: '红星维修商', time: '2024-01-15 14:30', detail: '年度保养，更换内衬，状态良好' },
  { id: 5, equipmentId: 'EQ202301058', event: '定期盘点', operator: '张丽', time: '2024-04-15 10:00', detail: '03号仓库季度盘点，装备状态正常' },
];

// 统计数据
export const statisticsData = {
  inventory: {
    inMonth: 156,
    outMonth: 89,
    totalStock: 3247,
    inTrend: [120, 135, 148, 156, 142, 168, 156],
    outTrend: [78, 82, 95, 89, 102, 88, 89],
    inYoY: 12.5,
    outYoY: 5.3,
    inMoM: 8.2,
    outMoM: -3.1,
  },
  warehouse: {
    totalWarehouses: 5,
    capacity: 5000,
    used: 3247,
    utilization: 64.9,
    warehouseStats: [
      { name: '01号装备室', used: 820, capacity: 1000 },
      { name: '02号装备室', used: 756, capacity: 1200 },
      { name: '03号装备室', used: 680, capacity: 1000 },
      { name: '04号装备室', used: 541, capacity: 800 },
      { name: '05号装备室', used: 450, capacity: 1000 },
    ],
  },
  equipment: {
    total: 4523,
    inStock: 3247,
    idle: 280,
    inUse: 987,
    repairing: 45,
    overdue: 120,
    scrapped: 244,
    scrappedThisMonth: 18,
    categoryStats: [
      { name: '防护装备', count: 1250, inUse: 420, utilization: 83.2 },
      { name: '记录设备', count: 980, inUse: 380, utilization: 92.5 },
      { name: '通讯设备', count: 756, inUse: 310, utilization: 88.1 },
      { name: '照明设备', count: 543, inUse: 195, utilization: 76.8 },
      { name: '械具', count: 432, inUse: 210, utilization: 72.4 },
      { name: '其他', count: 562, inUse: 120, utilization: 68.5 },
    ],
    statusPie: [
      { name: '在库', value: 3247 },
      { name: '闲置', value: 280 },
      { name: '在用', value: 987 },
      { name: '超期', value: 120 },
      { name: '报废', value: 244 },
      { name: '维修中', value: 45 },
    ],
  },
  check: {
    totalCheck: 45,
    passed: 38,
    abnormal: 7,
    lastCheckDate: '2024-05-18',
    checkTrend: [32, 38, 35, 42, 40, 45, 38],
    monthlyCheck: [
      { month: '1月', total: 28, passed: 24, abnormal: 4 },
      { month: '2月', total: 32, passed: 29, abnormal: 3 },
      { month: '3月', total: 38, passed: 34, abnormal: 4 },
      { month: '4月', total: 42, passed: 38, abnormal: 4 },
      { month: '5月', total: 45, passed: 38, abnormal: 7 },
    ],
    abnormalList: [
      { name: '对讲机 DJ-HY-800', code: 'EQ202401089', reason: '电池续航衰减' },
      { name: '战术手电 ZSD-200-X', code: 'EQ202202112', reason: 'LED灯泡亮度不足' },
      { name: '防弹背心 FDY-2024-A', code: 'EQ202301058', reason: '内衬磨损需更换' },
      { name: '执法记录仪 ZFY-4K-01', code: 'EQ202401002', reason: '存储卡异常' },
      { name: '防刺手套 FCST-100', code: 'EQ202302145', reason: '掌心磨损严重' },
      { name: '反光背心 FGBX-2024', code: 'EQ202413111', reason: '反光条脱落' },
      { name: '警棍 JG-2019', code: 'EQ201908176', reason: '手柄松动' },
    ],
  },
};

// 用户列表
export const userList = [
  { id: 'U001', name: '王强', badge: '044892', unit: '朝阳分局', role: 'officer', status: 'active', phone: '139****1234' },
  { id: 'U002', name: '李明', badge: '044893', unit: '东坝派出所', role: 'officer', status: 'active', phone: '138****5678' },
  { id: 'U003', name: '赵刚', badge: '044894', unit: '劲松派出所', role: 'officer', status: 'locked', phone: '137****9012' },
  { id: 'U004', name: '孙丽', badge: '044895', unit: '装备管理科', role: 'admin', status: 'active', phone: '136****3456' },
  { id: 'U005', name: '周涛', badge: '044896', unit: '呼家楼派出所', role: 'officer', status: 'active', phone: '135****7890' },
  { id: 'U006', name: '吴芳', badge: '044897', unit: '香河园派出所', role: 'officer', status: 'active', phone: '134****2345' },
  { id: 'U007', name: '郑海', badge: '044898', unit: '交通大队', role: 'officer', status: 'locked', phone: '133****6789' },
];

// 报修工单
export const repairList = [
  { id: 'WX20240520001', equipmentId: 'EQ202401001', name: '执法记录仪', status: 'pending', applyTime: '2024-05-20 09:30', desc: '无法开机，疑似电池故障', repairman: '', contact: '' },
  { id: 'WX20240519002', equipmentId: 'EQ202202112', name: '战术手电', status: 'repairing', applyTime: '2024-05-19 14:00', desc: '开关接触不良', repairman: '红星维修-张师傅', contact: '138****1111' },
  { id: 'WX20240518003', equipmentId: 'EQ202302145', name: '防刺手套', status: 'completed', applyTime: '2024-05-18 10:20', desc: '掌心部位磨损', repairman: '红星维修-李师傅', contact: '139****2222' },
  { id: 'WX20240517004', equipmentId: 'EQ202301058', name: '防弹背心', status: 'checking', applyTime: '2024-05-17 16:45', desc: '魔术贴脱落', repairman: '红星维修-王师傅', contact: '137****3333' },
];
