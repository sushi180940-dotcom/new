import { useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  ArrowRightLeft, Search, Plus, User, QrCode,
  CheckCircle2, Clock, AlertTriangle,
  Package, ArrowRight, ScanLine,
  CheckCircle, XCircle, ShieldCheck
} from 'lucide-react';

/* ─── types ─── */
export interface TransferMaterial {
  name: string; category: string; model: string;
  quantity: number; unit: string; price: number; total: number;
  equipmentCode: string; rfidCode: string;
  label: string; manufacturer: string; supplier: string; hasBattery: boolean;
  isFixedAsset: boolean; productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
  remark: string;
}

export interface TransferRecord {
  id: string; status: 'pending' | 'completed' | 'expired';
  fromUser: string; fromUnit: string; fromBadge: string;
  toUser: string; toUnit: string; toBadge: string;
  createTime: string; completeTime?: string;
  qrExpireTime: string; materials: TransferMaterial[];
}

interface UserOption {
  name: string; badge: string; unit: string;
}

/* ─── mock data ─── */
// Personal equipment (in-use status only)
const personalEquipList: TransferMaterial[] = [
  { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B', label: '防弹背心-001', manufacturer: '红星装备厂', supplier: '红星装备厂', hasBattery: false, isFixedAsset: true, productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年', remark: 'III级防弹标准' },
  { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', price: 280, total: 280, equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', label: '战术手电-002', manufacturer: '国安器材有限公司', supplier: '国安器材有限公司', hasBattery: true, isFixedAsset: false, productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年', remark: 'LED强光' },
  { name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 1, unit: '台', price: 650, total: 650, equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D', label: '对讲机-003', manufacturer: '中华安防集团', supplier: '中华安防集团', hasBattery: true, isFixedAsset: true, productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年', remark: '800MHz频段' },
  { name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', price: 1800, total: 1800, equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', label: '执法记录仪-004', manufacturer: '红星装备厂', supplier: '红星装备厂', hasBattery: true, isFixedAsset: true, productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年', remark: '4K高清' },
  { name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 1, unit: '双', price: 150, total: 150, equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A', label: '防刺手套-005', manufacturer: '盾甲科技', supplier: '盾甲科技', hasBattery: false, isFixedAsset: false, productionDate: '2023-05-10', expiryDate: '2026-05-10', maintenanceValue: 2, maintenanceUnit: '年', remark: '' },
];

export const mockRecords: TransferRecord[] = [
  { id: 'JJ20240520001', status: 'pending', fromUser: '王强', fromUnit: '朝阳分局刑侦大队', fromBadge: '010235', toUser: '李明', toUnit: '东城分局巡警支队', toBadge: '010198', createTime: '2024-05-20 10:30', qrExpireTime: '2024-05-20 10:45', materials: [personalEquipList[0], personalEquipList[2]] },
  { id: 'JJ20240519001', status: 'completed', fromUser: '赵刚', fromUnit: '西城分局特警大队', fromBadge: '010267', toUser: '孙丽', toUnit: '海淀分局治安大队', toBadge: '010312', createTime: '2024-05-19 14:00', completeTime: '2024-05-19 14:10', qrExpireTime: '2024-05-19 14:15', materials: [personalEquipList[3]] },
  { id: 'JJ20240518001', status: 'completed', fromUser: '周涛', fromUnit: '丰台分局交警大队', fromBadge: '010145', toUser: '张伟', toUnit: '昌平分局刑警大队', toBadge: '010389', createTime: '2024-05-18 09:15', completeTime: '2024-05-18 09:25', qrExpireTime: '2024-05-18 09:30', materials: [personalEquipList[1]] },
  { id: 'JJ20240515001', status: 'completed', fromUser: '李明', fromUnit: '东城分局巡警支队', fromBadge: '010198', toUser: '赵刚', toUnit: '西城分局特警大队', toBadge: '010267', createTime: '2024-05-15 16:30', completeTime: '2024-05-15 16:40', qrExpireTime: '2024-05-15 16:45', materials: [personalEquipList[0]] },
  { id: 'JJ20240510001', status: 'expired', fromUser: '张伟', fromUnit: '昌平分局刑警大队', fromBadge: '010389', toUser: '王强', toUnit: '朝阳分局刑侦大队', toBadge: '010235', createTime: '2024-05-10 08:00', qrExpireTime: '2024-05-10 08:15', materials: [personalEquipList[4], personalEquipList[2]] },
  { id: 'JJ20240505001', status: 'completed', fromUser: '孙丽', fromUnit: '海淀分局治安大队', fromBadge: '010312', toUser: '周涛', toUnit: '丰台分局交警大队', toBadge: '010145', createTime: '2024-05-05 11:20', completeTime: '2024-05-05 11:35', qrExpireTime: '2024-05-05 11:35', materials: [personalEquipList[1], personalEquipList[3]] },
];

const CURRENT_USER = { name: '王强', badge: '010235', unit: '朝阳分局刑侦大队' };

/* ─── config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType; desc: string }> = {
  pending:   { label: '待确认',  color: 'text-orange-600',  bg: 'bg-orange-50',  icon: Clock,         desc: '等待接收人扫码确认' },
  completed: { label: '已完成',  color: 'text-green-600',   bg: 'bg-green-50',   icon: CheckCircle2,  desc: '交接已成功完成' },
  expired:   { label: '已失效',  color: 'text-gray-500',    bg: 'bg-gray-100',   icon: XCircle,       desc: '二维码已过期，交接失效' },
};

/* ─── main component ─── */
export default function Transfer() {
  const navigate = useNavigate();
  const [view, setView] = useState<'list' | 'create' | 'scan' | 'success'>('list');

  /* list state */
  const [activeTab, setActiveTab] = useState('all');
  const [searchText, setSearchText] = useState('');

  /* create flow state */
  const [createStep, setCreateStep] = useState(1);
  const [selectedUser, setSelectedUser] = useState<UserOption | null>(null);
  const [selectedMaterials, setSelectedMaterials] = useState<TransferMaterial[]>([]);
  const [qrCode, setQrCode] = useState('');
  const [fromConfirmed, setFromConfirmed] = useState(false);
  const [toConfirmed, setToConfirmed] = useState(false);

  /* scan state */
  const [scanStep, setScanStep] = useState(1);
  const [scannedRecord, setScannedRecord] = useState<TransferRecord | null>(null);

  /* reset */
  const resetCreate = useCallback(() => {
    setCreateStep(1);
    setSelectedUser(null);
    setSelectedMaterials([]);
    setQrCode('');
    setFromConfirmed(false);
    setToConfirmed(false);
  }, []);

  /* filtered list */
  const filteredRecords = useMemo(() => {
    let list = [...mockRecords];
    if (activeTab !== 'all') list = list.filter(r => r.status === activeTab);
    if (searchText.trim()) {
      const kw = searchText.toLowerCase();
      list = list.filter(r => r.id.toLowerCase().includes(kw) || r.fromUser.includes(kw) || r.toUser.includes(kw));
    }
    return list.sort((a, b) => new Date(b.createTime).getTime() - new Date(a.createTime).getTime());
  }, [activeTab, searchText]);

  const stats = useMemo(() => ({
    all: mockRecords.length,
    pending: mockRecords.filter(r => r.status === 'pending').length,
    completed: mockRecords.filter(r => r.status === 'completed').length,
    expired: mockRecords.filter(r => r.status === 'expired').length,
  }), []);

  /* material toggle */
  const toggleMaterial = useCallback((m: TransferMaterial) => {
    setSelectedMaterials(prev => {
      const exists = prev.find(p => p.equipmentCode === m.equipmentCode);
      if (exists) return prev.filter(p => p.equipmentCode !== m.equipmentCode);
      return [...prev, m];
    });
  }, []);

  /* generate QR */
  const generateQR = useCallback(() => {
    const code = `JJQR${Date.now().toString(36).toUpperCase()}`;
    setQrCode(code);
    setCreateStep(2);
  }, []);

  /* scan QR */
  const handleScan = useCallback(() => {
    const pending = mockRecords.find(r => r.status === 'pending');
    if (pending) {
      setScannedRecord(pending);
      setScanStep(2);
    }
  }, []);

  /* ═══════════════════════════════════
     RENDER: Create Flow
     ═══════════════════════════════════ */
  if (view === 'create') {
    return (
      <MobileLayout
        title={`发起交接 (${createStep}/3)`}
        showBack
        onBack={() => {
          if (createStep > 1) setCreateStep(createStep - 1);
          else { resetCreate(); setView('list'); }
        }}
      >
        {/* ── Step 1: Select Equipment ── */}
        {createStep === 1 && (
          <div className="flex flex-col h-full">
            <div className="p-4">
              <div className="bg-green-50 rounded-xl px-3 py-2.5 mb-3 flex items-center gap-2">
                <ShieldCheck size={14} className="text-green-600 shrink-0" />
                <p className="text-xs text-green-700">仅展示"使用中"状态的装备，请选择要交接的装备</p>
              </div>

              {/* Receiver info */}
              {selectedUser && (
                <div className="bg-white rounded-xl p-3 mb-3 flex items-center gap-3 shadow-sm">
                  <div className="flex items-center gap-2 flex-1">
                    <User size={14} className="text-gray-400" />
                    <span className="text-xs text-gray-500">接收人：</span>
                    <span className="text-sm font-medium text-gray-800">{selectedUser.name}</span>
                    <span className="text-[10px] text-gray-400">{selectedUser.unit}</span>
                  </div>
                </div>
              )}
            </div>

            {/* Material List */}
            <div className="flex-1 overflow-y-auto px-4 pb-3 space-y-2">
              {personalEquipList.map(m => {
                const selected = selectedMaterials.some(p => p.equipmentCode === m.equipmentCode);
                return (
                  <div
                    key={m.equipmentCode}
                    onClick={() => toggleMaterial(m)}
                    className={`bg-white rounded-2xl p-4 border-2 transition-all cursor-pointer ${
                      selected ? 'border-[#1565c0]' : 'border-transparent shadow-sm'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        selected ? 'bg-blue-50' : 'bg-gray-50'
                      }`}>
                        <Package size={18} className={selected ? 'text-[#1565c0]' : 'text-gray-400'} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-gray-800">{m.name}</span>
                          {m.isFixedAsset && (
                            <span className="text-[10px] text-purple-500 bg-purple-50 px-1.5 py-0.5 rounded">固定资产</span>
                          )}
                          {selected && <CheckCircle2 size={14} className="text-[#1565c0]" />}
                        </div>
                        <p className="text-xs text-gray-500">型号：{m.model}</p>
                        <p className="text-xs text-gray-500">编号：{m.equipmentCode}</p>
                        <p className="text-xs text-gray-500">RFID：{m.rfidCode}</p>
                        <p className="text-xs text-gray-500">标签：{m.label}</p>
                        <p className="text-xs text-gray-500">供应商：{m.supplier} · 原厂商：{m.manufacturer} · {m.hasBattery ? '有电池' : '无电池'}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom bar */}
            <div className="shrink-0 p-4 bg-white border-t border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">已选 <span className="text-[#1565c0] font-bold">{selectedMaterials.length}</span> 件</span>
              </div>
              <button
                onClick={generateQR}
                disabled={selectedMaterials.length === 0}
                className={`w-full py-3 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-2 ${
                  selectedMaterials.length > 0
                    ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md'
                    : 'bg-gray-200 text-gray-400'
                }`}
              >
                <QrCode size={16} />
                生成交接二维码
              </button>
            </div>
          </div>
        )}

        {/* ── Step 3: QR Code ── */}
        {createStep === 2 && (
          <div className="p-4">
            <div className="bg-orange-50 rounded-xl px-3 py-2.5 mb-4 flex items-center gap-2">
              <AlertTriangle size={14} className="text-orange-600 shrink-0" />
              <p className="text-xs text-orange-700">请接收人扫描下方二维码，二维码15分钟内有效</p>
            </div>

            <div className="bg-white rounded-2xl p-6 shadow-sm text-center mb-4">
              <div className="w-48 h-48 bg-gray-100 rounded-2xl mx-auto mb-4 flex items-center justify-center">
                <QrCode size={80} className="text-[#1565c0]" />
              </div>
              <p className="text-sm font-mono text-gray-600 mb-2">{qrCode}</p>
              <p className="text-xs text-gray-500">15分钟后自动失效</p>
            </div>

            {/* Receiver info */}
            {selectedUser && (
              <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
                <h3 className="text-sm font-semibold text-gray-800 mb-2">交接信息</h3>
                <div className="flex items-center justify-center gap-6 py-3">
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-1">
                      <span className="text-base font-bold text-blue-600">{CURRENT_USER.name[0]}</span>
                    </div>
                    <p className="text-xs font-medium text-gray-800">{CURRENT_USER.name}</p>
                    <p className="text-[10px] text-gray-400">移交人</p>
                  </div>
                  <div className="flex flex-col items-center">
                    <ArrowRight size={24} className="text-gray-400" />
                    <span className="text-[10px] text-gray-400">交接</span>
                  </div>
                  <div className="text-center">
                    <div className="w-12 h-12 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-1">
                      <span className="text-base font-bold text-green-600">{selectedUser.name[0]}</span>
                    </div>
                    <p className="text-xs font-medium text-gray-800">{selectedUser.name}</p>
                    <p className="text-[10px] text-gray-400">接收人</p>
                  </div>
                </div>
                <p className="text-xs text-gray-500 text-center">
                  {selectedMaterials.length} 件装备待交接
                </p>
              </div>
            )}

            {/* Simulate receiver scan */}
            <button
              onClick={() => { setCreateStep(3); }}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-medium text-sm flex items-center justify-center gap-2 active:bg-green-700 transition-colors shadow-md"
            >
              <ScanLine size={16} />
              模拟接收人已扫码
            </button>
          </div>
        )}

        {/* ── Step 4: Both Confirm ── */}
        {createStep === 3 && (
          <div className="p-4">
            <div className="bg-green-50 rounded-xl px-3 py-2.5 mb-4 flex items-center gap-2">
              <CheckCircle size={14} className="text-green-600 shrink-0" />
              <p className="text-xs text-green-700">接收人已扫码，请双方分别确认完成交接</p>
            </div>

            {/* Party info */}
            <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
              <div className="flex items-center justify-center gap-6 py-3">
                <div className={`text-center p-3 rounded-xl transition-all ${fromConfirmed ? 'bg-green-50' : ''}`}>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-1 ${fromConfirmed ? 'bg-green-100' : 'bg-blue-50'}`}>
                    <span className={`text-base font-bold ${fromConfirmed ? 'text-green-600' : 'text-blue-600'}`}>
                      {CURRENT_USER.name[0]}
                    </span>
                  </div>
                  <p className="text-xs font-medium text-gray-800">{CURRENT_USER.name}</p>
                  <p className="text-[10px] text-gray-400">移交人</p>
                  {fromConfirmed && <CheckCircle2 size={14} className="text-green-600 mx-auto mt-1" />}
                </div>

                <div className="flex flex-col items-center">
                  <ArrowRight size={24} className={fromConfirmed && toConfirmed ? 'text-green-500' : 'text-gray-400'} />
                  {fromConfirmed && toConfirmed && (
                    <span className="text-[10px] text-green-600 font-medium">已完成</span>
                  )}
                </div>

                <div className={`text-center p-3 rounded-xl transition-all ${toConfirmed ? 'bg-green-50' : ''}`}>
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-1 ${toConfirmed ? 'bg-green-100' : 'bg-green-50'}`}>
                    <span className={`text-base font-bold ${toConfirmed ? 'text-green-600' : 'text-green-600'}`}>
                      {selectedUser?.name[0]}
                    </span>
                  </div>
                  <p className="text-xs font-medium text-gray-800">{selectedUser?.name}</p>
                  <p className="text-[10px] text-gray-400">接收人</p>
                  {toConfirmed && <CheckCircle2 size={14} className="text-green-600 mx-auto mt-1" />}
                </div>
              </div>
            </div>

            {/* Material list */}
            <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">装备明细 ({selectedMaterials.length})</h3>
              <div className="space-y-2">
                {selectedMaterials.map((m, i) => (
                  <div key={i} className="bg-gray-50 rounded-xl p-3 flex items-center gap-3">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-800">{m.name}</p>
                      <p className="text-xs text-gray-500">{m.equipmentCode} · RFID：{m.rfidCode}</p>
                      <p className="text-xs text-gray-500">标签：{m.label} · 供应商：{m.supplier}</p>
                      <p className="text-xs text-gray-500">原厂商：{m.manufacturer} · {m.hasBattery ? '有电池' : '无电池'}</p>
                    </div>
                    <span className="text-xs text-gray-600">x{m.quantity} {m.unit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Rules */}
            <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
              <h3 className="text-sm font-semibold text-gray-800 mb-2">交接规则</h3>
              <div className="space-y-1.5">
                {[
                  '交接完成后装备归属立即变更',
                  '原持有人自动解除装备关联',
                  '交接记录全程留痕，支持溯源',
                  '二维码单次有效，完成后自动失效',
                ].map((rule, i) => (
                  <p key={i} className="text-xs text-gray-500 flex items-start gap-1.5">
                    <span className="text-[10px] text-gray-400 shrink-0 mt-0.5">{i + 1}.</span>
                    {rule}
                  </p>
                ))}
              </div>
            </div>

            {/* Confirm buttons */}
            <div className="flex gap-3">
              <button
                onClick={() => setFromConfirmed(true)}
                disabled={fromConfirmed}
                className={`flex-1 py-3 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-1.5 ${
                  fromConfirmed
                    ? 'bg-green-50 text-green-600'
                    : 'bg-blue-500 text-white active:bg-blue-600'
                }`}
              >
                {fromConfirmed ? <><CheckCircle2 size={14} /> 已确认</> : '移交人确认'}
              </button>
              <button
                onClick={() => setToConfirmed(true)}
                disabled={toConfirmed}
                className={`flex-1 py-3 rounded-xl font-medium text-sm transition-all flex items-center justify-center gap-1.5 ${
                  toConfirmed
                    ? 'bg-green-50 text-green-600'
                    : 'bg-green-500 text-white active:bg-green-600'
                }`}
              >
                {toConfirmed ? <><CheckCircle2 size={14} /> 已确认</> : '接收人确认'}
              </button>
            </div>

            {/* Complete button */}
            {fromConfirmed && toConfirmed && (
              <button
                onClick={() => { resetCreate(); setView('success'); }}
                className="w-full mt-3 bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-md"
              >
                <CheckCircle2 size={16} />
                完成交接
              </button>
            )}
          </div>
        )}
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: Scan Flow
     ═══════════════════════════════════ */
  if (view === 'scan') {
    return (
      <MobileLayout title="扫码接收" showBack onBack={() => setView('list')}>
        {scanStep === 1 && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
            <div className="w-24 h-24 bg-blue-50 rounded-3xl flex items-center justify-center mb-6">
              <ScanLine size={48} className="text-[#1565c0]" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">扫描交接二维码</h3>
            <p className="text-sm text-gray-500 text-center mb-8">
              将摄像头对准移交人出示的<br />交接二维码进行扫描
            </p>
            <button
              onClick={handleScan}
              className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium text-sm active:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-md"
            >
              <QrCode size={18} />
              模拟扫码
            </button>
          </div>
        )}

        {scanStep === 2 && scannedRecord && (
          <div className="p-4">
            <div className="bg-green-50 rounded-xl px-3 py-2.5 mb-4 flex items-center gap-2">
              <CheckCircle size={14} className="text-green-600 shrink-0" />
              <p className="text-xs text-green-700">扫码成功，请核对装备信息</p>
            </div>

            {/* Transfer info */}
            <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
              <div className="flex items-center justify-center gap-6 py-3">
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center mx-auto mb-1">
                    <span className="text-base font-bold text-blue-600">{scannedRecord.fromUser[0]}</span>
                  </div>
                  <p className="text-xs font-medium text-gray-800">{scannedRecord.fromUser}</p>
                  <p className="text-[10px] text-gray-400">移交人</p>
                </div>
                <ArrowRight size={24} className="text-gray-400" />
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-green-50 flex items-center justify-center mx-auto mb-1">
                    <span className="text-base font-bold text-green-600">{scannedRecord.toUser[0]}</span>
                  </div>
                  <p className="text-xs font-medium text-gray-800">{scannedRecord.toUser}</p>
                  <p className="text-[10px] text-gray-400">接收人</p>
                </div>
              </div>
            </div>

            {/* Materials */}
            <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">
                交接装备 ({scannedRecord.materials.length})
              </h3>
              <div className="space-y-2">
                {scannedRecord.materials.map((m, i) => (
                  <div key={i} className="bg-gray-50 rounded-xl p-3 flex items-center gap-3">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-800">{m.name}</p>
                      <p className="text-xs text-gray-500">{m.equipmentCode} · RFID：{m.rfidCode}</p>
                      <p className="text-xs text-gray-500">标签：{m.label} · 供应商：{m.supplier}</p>
                      <p className="text-xs text-gray-500">原厂商：{m.manufacturer} · {m.hasBattery ? '有电池' : '无电池'}</p>
                    </div>
                    <span className="text-xs text-gray-600">x{m.quantity} {m.unit}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Rules */}
            <div className="bg-orange-50 rounded-xl p-3 mb-4 flex items-start gap-2">
              <AlertTriangle size={14} className="text-orange-500 shrink-0 mt-0.5" />
              <p className="text-xs text-orange-600">
                确认接收后装备归属将变更至您名下，请仔细核对
              </p>
            </div>

            <button
              onClick={() => { scannedRecord.status = 'completed'; scannedRecord.completeTime = new Date().toLocaleString('zh-CN'); setScanStep(3); }}
              className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-md"
            >
              <CheckCircle2 size={16} />
              确认接收
            </button>
          </div>
        )}

        {scanStep === 3 && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
            <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
              <CheckCircle2 size={40} className="text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">接收成功</h3>
            <p className="text-sm text-gray-500 text-center mb-6">
              装备已成功接收<br />归属人已变更
            </p>
            <button
              onClick={() => { setScanStep(1); setView('list'); }}
              className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors"
            >
              返回列表
            </button>
          </div>
        )}
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: Success (after create)
     ═══════════════════════════════════ */
  if (view === 'success') {
    return (
      <MobileLayout title="交接完成" showBack onBack={() => setView('list')}>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 size={40} className="text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">交接成功</h3>
          <p className="text-sm text-gray-500 text-center mb-6">
            装备归属已变更<br />交接记录已留存
          </p>
          <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">交接单号</span>
                <span className="text-gray-800 font-mono font-medium">JJ20240520NEW</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">移交人</span>
                <span className="text-gray-800 font-medium">{CURRENT_USER.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">接收人</span>
                <span className="text-gray-800 font-medium">{selectedUser?.name || '-'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">交接装备</span>
                <span className="text-gray-800 font-medium">{selectedMaterials.length} 件</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">完成时间</span>
                <span className="text-gray-800 font-medium">{new Date().toLocaleString('zh-CN')}</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => setView('list')}
            className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors"
          >
            返回列表
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: List (default)
     ═══════════════════════════════════ */
  return (
    <MobileLayout title="交接管理" showBack>
      {/* ── Search ── */}
      <div className="px-4 pt-3 pb-2">
        <div className="relative mb-3">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="搜索单号、转出人、接收人..."
            className="w-full bg-white rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-gray-200 focus:border-blue-300 transition-all shadow-sm"
          />
        </div>
      </div>

      {/* ── Stats ── */}
      <div className="px-4 mb-3">
        <div className="flex gap-2">
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-[#1565c0]">{stats.all}</p>
            <p className="text-[10px] text-gray-500">全部</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-orange-600">{stats.pending}</p>
            <p className="text-[10px] text-gray-500">待确认</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-green-600">{stats.completed}</p>
            <p className="text-[10px] text-gray-500">已完成</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-gray-500">{stats.expired}</p>
            <p className="text-[10px] text-gray-500">已失效</p>
          </div>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="px-4 mb-3">
        <div className="flex bg-white rounded-xl p-0.5">
          {[
            { key: 'all', label: '全部' },
            { key: 'pending', label: '待确认' },
            { key: 'completed', label: '已完成' },
            { key: 'expired', label: '已失效' },
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                activeTab === t.key
                  ? t.key === 'pending' ? 'bg-orange-500 text-white' :
                    t.key === 'completed' ? 'bg-green-500 text-white' :
                    t.key === 'expired' ? 'bg-gray-500 text-white' :
                    'bg-[#1565c0] text-white'
                  : 'text-gray-500'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── List ── */}
      <div className="px-4 pb-24 space-y-2">
        {filteredRecords.map(record => {
          const sc = statusConfig[record.status];
          const StatusIcon = sc.icon;
          const totalQty = record.materials.reduce((s, m) => s + m.quantity, 0);
          return (
            <button
              key={record.id}
              onClick={() => navigate(`/transfer/${record.id}`)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <ArrowRightLeft size={14} className="text-[#1565c0]" />
                  <span className="text-sm font-semibold text-gray-900 font-mono">{record.id}</span>
                </div>
                <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${sc.bg} ${sc.color}`}>
                  <StatusIcon size={10} /> {sc.label}
                </span>
              </div>

              {/* Users flow */}
              <div className="flex items-center gap-3 py-2 mb-2">
                <div className="flex items-center gap-2 flex-1">
                  <div className="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center shrink-0">
                    <span className="text-xs font-bold text-blue-600">{record.fromUser[0]}</span>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-800">{record.fromUser}</p>
                    <p className="text-[10px] text-gray-400">{record.fromUnit}</p>
                  </div>
                </div>
                <ArrowRight size={14} className="text-gray-300 shrink-0" />
                <div className="flex items-center gap-2 flex-1">
                  <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center shrink-0">
                    <span className="text-xs font-bold text-green-600">{record.toUser[0]}</span>
                  </div>
                  <div>
                    <p className="text-xs font-medium text-gray-800">{record.toUser}</p>
                    <p className="text-[10px] text-gray-400">{record.toUnit}</p>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="pt-2 border-t border-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Package size={10} className="text-gray-400" />
                  <span className="text-xs text-gray-500">{record.materials.length}种 · {totalQty}件</span>
                </div>
                <span className="text-[10px] text-gray-400">{record.createTime}</span>
              </div>
            </button>
          );
        })}

        {filteredRecords.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <ArrowRightLeft size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无交接记录</p>
          </div>
        )}
      </div>

      {/* ── FAB Buttons ── */}
      <div className="fixed bottom-6 right-5 flex flex-col gap-3 z-50">
        <button
          onClick={() => { setScanStep(1); setView('scan'); }}
          className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform bg-green-600"
        >
          <ScanLine size={24} className="text-white" />
        </button>
        <button
          onClick={() => { resetCreate(); setView('create'); }}
          className="w-14 h-14 rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform"
          style={{ background: 'linear-gradient(135deg, #1565c0, #0d2b5e)' }}
        >
          <Plus size={24} className="text-white" />
        </button>
      </div>
    </MobileLayout>
  );
}
