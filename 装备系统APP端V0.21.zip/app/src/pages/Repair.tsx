import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Plus, QrCode, CheckCircle2, Clock, Trash2, Edit3,
  Package, ChevronRight, RefreshCw, Shield,
  FileText, CircleDot, Star, X, AlertTriangle
} from 'lucide-react';

/* ─── types ─── */

type RepairStatus = 'draft' | 'pending_check' | 'done' | 'auto_done';

interface EquipmentArchive {
  id: string;
  name: string;
  model: string;
  code: string;
  productionDate: string;
  expiryDate: string;
  warrantyMonths: number;
  supplier: string;
  contactPerson: string;
  contactPhone: string;
  repairQty: number;
  unit: string;
  rfid: string;
  storageLocation: string;
}

interface RepairOrder {
  id: string;
  status: RepairStatus;
  applyTime: string;
  submitTime?: string;
  completeTime?: string;
  checkTime?: string;
  autoCloseTime?: string;
  reporter: string;
  description: string;
  archives: EquipmentArchive[];
  checkScore?: number;
  checkResult?: 'pass' | 'reopen';
}

/* ─── mock data ─── */
const genOrderNo = () => {
  const d = new Date();
  return `WX${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}${String(Math.floor(Math.random()*900)+100).padStart(3,'0')}`;
};

const nowStr = () => new Date().toLocaleString('zh-CN');

const mkArchive = (overrides: Partial<EquipmentArchive> = {}): EquipmentArchive => ({
  id: Date.now().toString() + Math.random().toString(36).slice(2,5),
  name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-005-001',
  productionDate: '2024-01-15', expiryDate: '2027-01-15',
  warrantyMonths: 24, supplier: '猎豹装备科技',
  contactPerson: '刘工', contactPhone: '13800138001',
  repairQty: 1, unit: '台', rfid: 'RFID202601008H',
  storageLocation: '省厅主仓库/主仓库2楼',
  ...overrides,
});

const initMockOrders: RepairOrder[] = [
  {
    id: 'WX20240520001', status: 'draft', applyTime: '2024-05-20 09:30',
    reporter: '张伟', description: '执法记录仪无法开机，疑似电池故障',
    archives: [mkArchive({name:'执法记录仪', model:'DSJ-A7', code:'ZB-005-001', productionDate:'2024-01-15', expiryDate:'2027-01-15', repairQty:2})],
  },
  {
    id: 'WX20240519002', status: 'pending_check', applyTime: '2024-05-19 14:00',
    submitTime: '2024-05-19 14:05',
    reporter: '王强', description: '战术手电开关接触不良，时亮时灭',
    archives: [mkArchive({name:'战术手电', model:'ZSD-200-X', code:'ZB-006-001', supplier:'国安器材', contactPerson:'张工', contactPhone:'13800138002', productionDate:'2022-05-20', expiryDate:'2025-05-20', rfid:'RFID202601010J', storageLocation:'省厅主仓库/主仓库3楼', warrantyMonths:24, repairQty:1})],
  },
  {
    id: 'WX20240518003', status: 'pending_check', applyTime: '2024-05-18 10:20',
    submitTime: '2024-05-18 10:25', completeTime: '2024-06-01 16:30',
    reporter: '李明', description: '防刺手套掌心部位磨损严重',
    archives: [mkArchive({name:'防刺手套', model:'FCST-100', code:'ZB-004-001', supplier:'盾甲科技', contactPerson:'陈工', contactPhone:'13800138003', productionDate:'2023-05-10', expiryDate:'2026-05-10', rfid:'RFID202601004D', storageLocation:'省厅主仓库/主仓库1楼', warrantyMonths:24, repairQty:1})],
  },
  {
    id: 'WX20240517004', status: 'done', applyTime: '2024-05-17 16:45',
    submitTime: '2024-05-17 16:50', completeTime: '2024-05-28 11:00',
    checkTime: '2024-05-28 14:30', reporter: '赵刚',
    description: '防弹背心魔术贴脱落，影响穿戴', checkScore: 5, checkResult: 'pass',
    archives: [mkArchive({name:'防弹背心', model:'FDY-3R-01', code:'ZB-001-001', supplier:'某省安防科技有限公司', contactPerson:'王工', contactPhone:'13800138004', productionDate:'2023-01-10', expiryDate:'2028-01-10', rfid:'RFID202601001A', storageLocation:'省厅主仓库/主仓库1楼', warrantyMonths:24, repairQty:1})],
  },
  {
    id: 'WX20240516005', status: 'pending_check', applyTime: '2024-05-16 11:00',
    submitTime: '2024-05-16 11:05', completeTime: '2024-05-25 09:00',
    checkTime: '2024-05-25 10:30', reporter: '孙丽',
    description: '对讲机信号不稳定，维修后问题依旧', checkScore: 2, checkResult: 'reopen',
    archives: [mkArchive({name:'对讲机', model:'DJ-HY-800', code:'ZB-004-001', supplier:'中华安防集团', contactPerson:'李工', contactPhone:'13800138005', productionDate:'2024-01-25', expiryDate:'2026-01-25', rfid:'RFID202601006F', storageLocation:'省厅主仓库/主仓库2楼', warrantyMonths:24, repairQty:3})],
  },
  {
    id: 'WX20240515006', status: 'auto_done', applyTime: '2024-05-15 08:30',
    submitTime: '2024-05-15 08:35', completeTime: '2024-05-30 10:00',
    autoCloseTime: '2024-06-06 10:00', reporter: '周涛',
    description: '警棍表面氧化生锈',
    archives: [mkArchive({name:'警棍', model:'JG-TELE', code:'ZB-007-002', supplier:'雄鹰警械公司', contactPerson:'赵工', contactPhone:'13800138006', productionDate:'2022-06-10', expiryDate:'2025-06-10', rfid:'RFID202601013M', storageLocation:'02号装备室/A区', warrantyMonths:24, repairQty:2})],
  },
];

// 可选装备列表（我的装备）
const myEquipments: EquipmentArchive[] = [
  mkArchive({id:'me1', name:'执法记录仪', model:'DSJ-A7', code:'ZB-005-001', productionDate:'2024-01-15', expiryDate:'2027-01-15', rfid:'RFID202601008H', storageLocation:'省厅主仓库/主仓库2楼'}),
  mkArchive({id:'me2', name:'战术手电', model:'ZSD-200-X', code:'ZB-006-001', supplier:'国安器材', contactPerson:'张工', contactPhone:'13800138002', productionDate:'2022-05-20', expiryDate:'2025-05-20', rfid:'RFID202601010J', storageLocation:'省厅主仓库/主仓库3楼'}),
  mkArchive({id:'me3', name:'对讲机', model:'DJ-HY-800', code:'ZB-004-001', supplier:'中华安防集团', contactPerson:'李工', contactPhone:'13800138005', productionDate:'2024-01-25', expiryDate:'2026-01-25', rfid:'RFID202601006F', storageLocation:'省厅主仓库/主仓库2楼'}),
  mkArchive({id:'me4', name:'防弹背心', model:'FDY-3R-01', code:'ZB-001-001', supplier:'某省安防科技有限公司', contactPerson:'王工', contactPhone:'13800138004', productionDate:'2023-01-10', expiryDate:'2028-01-10', rfid:'RFID202601001A', storageLocation:'省厅主仓库/主仓库1楼'}),
  mkArchive({id:'me5', name:'防弹头盔', model:'FDK-2A-01', code:'ZB-001-002', supplier:'红星装备厂', contactPerson:'刘工', contactPhone:'13800138007', productionDate:'2023-03-20', expiryDate:'2028-03-20', rfid:'RFID202601002B', storageLocation:'省厅主仓库/主仓库1楼'}),
];

const STATUS_CONFIG: Record<RepairStatus, { label: string; color: string; bg: string; icon: typeof Clock; desc: string }> = {
  draft:        { label: '草稿',     color: 'text-gray-600',  bg: 'bg-gray-100',  icon: FileText,    desc: '已保存未提交' },
  pending_check:{ label: '待验收',   color: 'text-orange-600',bg: 'bg-orange-50', icon: Star,        desc: '维修完成，等待验收' },
  done:         { label: '已完结',   color: 'text-green-600', bg: 'bg-green-50',  icon: CheckCircle2, desc: '验收通过' },
  auto_done:    { label: '自动完结', color: 'text-green-600', bg: 'bg-green-50',  icon: Clock,       desc: '超时未验收，系统自动通过' },
};

// 判断是否已过质保
function isOverWarranty(a: EquipmentArchive) {
  const prod = new Date(a.productionDate);
  const warrantyEnd = new Date(prod);
  warrantyEnd.setMonth(warrantyEnd.getMonth() + a.warrantyMonths);
  return new Date() > warrantyEnd;
}

/* ─── component ─── */
export default function Repair() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'select' | 'form' | 'success'>('list');
  const [orders, setOrders] = useState<RepairOrder[]>(initMockOrders);
  const [activeFilter, setActiveFilter] = useState('全部');
  const [selectedArchives, setSelectedArchives] = useState<EquipmentArchive[]>([]);
  const [description, setDescription] = useState('');
  const [editingOrderId, setEditingOrderId] = useState<string | null>(null);
  const [scanAnim, setScanAnim] = useState(false);
  const [scanResult, setScanResult] = useState<{msg:string;ok:boolean}|null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string|null>(null);

  const filters = ['全部', '草稿', '待验收', '已完结', '自动完结'];

  const filtered = activeFilter === '全部' ? orders
    : orders.filter(o => STATUS_CONFIG[o.status].label === activeFilter);

  /* ─── actions ─── */
  const resetForm = () => {
    setSelectedArchives([]);
    setDescription('');
    setEditingOrderId(null);
  };

  const handleStartNew = () => { resetForm(); setStep('select'); };

  const handleEditDraft = (order: RepairOrder) => {
    setEditingOrderId(order.id);
    setSelectedArchives([...order.archives]);
    setDescription(order.description);
    setStep('form');
  };

  const handleDelete = (id: string) => {
    setOrders(prev => prev.filter(o => o.id !== id));
    setShowDeleteConfirm(null);
  };

  const handleToggleEquip = (eq: EquipmentArchive) => {
    setSelectedArchives(prev => {
      const exists = prev.find(p => p.id === eq.id);
      if (exists) return prev.filter(p => p.id !== eq.id);
      return [...prev, eq];
    });
  };

  const handleScan = useCallback(() => {
    setScanAnim(true);
    setTimeout(() => {
      setScanAnim(false);
      const eq = myEquipments[Math.floor(Math.random() * myEquipments.length)];
      setSelectedArchives(prev => {
        if (prev.find(p => p.id === eq.id)) return prev;
        return [...prev, eq];
      });
      setScanResult({ msg: `已扫描：${eq.rfid} · ${eq.name}`, ok: true });
      setTimeout(() => setScanResult(null), 3000);
    }, 1500);
  }, []);

  const handleSaveDraft = () => {
    if (editingOrderId) {
      setOrders(prev => prev.map(o => o.id === editingOrderId ? { ...o, archives: [...selectedArchives], description, applyTime: nowStr() } : o));
    } else {
      setOrders(prev => [{ id: genOrderNo(), status: 'draft', applyTime: nowStr(), reporter: '张伟', description, archives: [...selectedArchives] }, ...prev]);
    }
    setStep('list');
    resetForm();
  };

  const handleSubmit = () => {
    if (!description.trim() || selectedArchives.length === 0) return;
    if (editingOrderId) {
      setOrders(prev => prev.map(o => o.id === editingOrderId ? { ...o, status: 'pending_check' as const, submitTime: nowStr(), archives: [...selectedArchives], description: description.trim() } : o));
    } else {
      setOrders(prev => [{ id: genOrderNo(), status: 'pending_check', applyTime: nowStr(), submitTime: nowStr(), reporter: '张伟', description: description.trim(), archives: [...selectedArchives] }, ...prev]);
    }
    setStep('success');
  };

  const handleCheck = (orderId: string, result: 'pass' | 'reopen', score: number) => {
    setOrders(prev => prev.map(o => {
      if (o.id !== orderId) return o;
      return {
        ...o,
        status: result === 'pass' ? ('done' as const) : ('pending_check' as const),
        checkTime: nowStr(),
        checkScore: score,
        checkResult: result,
      };
    }));
  };

  /* ═══════════ LIST ═══════════ */
  if (step === 'list') {
    return (
      <MobileLayout title="快速报修" showBack rightAction={
        <button onClick={handleStartNew} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">新建报修</button>
      }>
        {/* Stats */}
        <div className="px-4 pt-3 pb-2 flex gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { label: '草稿', value: orders.filter(o => o.status === 'draft').length, color: 'text-gray-600', bg: 'bg-gray-100' },

            { label: '待验收', value: orders.filter(o => o.status === 'pending_check').length, color: 'text-orange-600', bg: 'bg-orange-50' },
            { label: '已完结', value: orders.filter(o => o.status === 'done' || o.status === 'auto_done').length, color: 'text-green-600', bg: 'bg-green-50' },
          ].map(s => (
            <div key={s.label} className={`${s.bg} rounded-2xl p-2.5 min-w-[60px] text-center`}>
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[9px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Filter */}
        <div className="px-4 py-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {filters.map(t => (
              <button key={t} onClick={() => setActiveFilter(t)} className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${activeFilter === t ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600 shadow-sm'}`}>{t}</button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="px-4 pb-4 space-y-2">
          {filtered.map(order => {
            const sc = STATUS_CONFIG[order.status];
            return (
              <div key={order.id} className="bg-white rounded-2xl p-4 shadow-sm">
                {/* Header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-gray-800 font-mono">{order.id}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>{sc.label}</span>
                  </div>
                  <span className="text-[10px] text-gray-400">{sc.desc}</span>
                </div>

                {/* Equipments */}
                <div className="mb-2">
                  <p className="text-sm text-gray-700">
                    {order.archives.map(a => a.name).join('、')}
                    {order.archives.length > 1 && <span className="text-xs text-gray-400 ml-1">等{order.archives.length}件</span>}
                  </p>
                  <p className="text-xs text-gray-400 line-clamp-1">{order.description}</p>
                </div>

                {/* Actions by status */}
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-gray-400">{order.applyTime}</span>
                  <div className="flex gap-1.5">
                    {/* 草稿：编辑 + 删除 */}
                    {order.status === 'draft' && (<>
                      <button onClick={() => handleEditDraft(order)} className="flex items-center gap-1 px-2.5 py-1.5 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-medium active:bg-blue-100 transition-colors">
                        <Edit3 size={12} /> 编辑
                      </button>
                      <button onClick={() => setShowDeleteConfirm(order.id)} className="flex items-center gap-1 px-2.5 py-1.5 bg-red-50 text-red-600 rounded-lg text-[10px] font-medium active:bg-red-100 transition-colors">
                        <Trash2 size={12} /> 删除
                      </button>
                    </>)}
                    {/* 待验收：验收按钮 */}
                    {order.status === 'pending_check' && (
                      <CheckAction order={order} onCheck={handleCheck} />
                    )}
                    {/* 其他状态：查看详情 */}
                    {order.status !== 'draft' && order.status !== 'pending_check' && (
                      <button onClick={() => navigate(`/repair/${order.id}`)} className="flex items-center gap-1 px-2.5 py-1.5 bg-gray-50 text-gray-600 rounded-lg text-[10px] font-medium active:bg-gray-100 transition-colors">
                        查看详情 <ChevronRight size={12} />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Delete Confirm Modal */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowDeleteConfirm(null)}>
            <div className="absolute inset-0 bg-black/40" />
            <div className="relative bg-white rounded-t-3xl w-full p-6" onClick={e => e.stopPropagation()}>
              <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">删除草稿</h3>
              <p className="text-sm text-gray-500 mb-6">确认删除该报修草稿？删除后不可恢复。</p>
              <button onClick={() => handleDelete(showDeleteConfirm)} className="w-full bg-red-500 text-white py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-red-600">确认删除</button>
              <button onClick={() => setShowDeleteConfirm(null)} className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-2xl font-medium text-base">取消</button>
            </div>
          </div>
        )}

        <button onClick={handleStartNew} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors"><Plus size={24} /></button>
      </MobileLayout>
    );
  }

  /* ═══════════ SELECT EQUIPMENT (multi-select) ═══════════ */
  if (step === 'select') {
    return (
      <MobileLayout title="选择报修装备" showBack onBack={() => setStep('list')} rightAction={
        selectedArchives.length > 0 ? (
          <button onClick={() => setStep('form')} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">
            下一步({selectedArchives.length})
          </button>
        ) : undefined
      }>
        <div className="p-4">
          {/* Scan */}
          <div className="bg-white rounded-2xl p-5 shadow-sm mb-4 text-center">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-3 transition-all ${scanAnim ? 'bg-blue-100' : 'bg-blue-50'}`}>
              {scanAnim ? <RefreshCw size={36} className="text-blue-600 animate-spin" /> : <QrCode size={36} className="text-blue-600" />}
            </div>
            <h3 className="text-base font-semibold text-gray-800 mb-1">{scanAnim ? '正在扫描...' : '扫描RFID编码或者标签'}</h3>
            <p className="text-xs text-gray-500 mb-4">扫描故障装备的RFID编码</p>
            <button onClick={handleScan} disabled={scanAnim} className={`w-full py-3 rounded-xl font-medium ${scanAnim ? 'bg-gray-200 text-gray-400' : 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'}`}>
              {scanAnim ? '扫描中...' : '开始扫描'}
            </button>
            {scanResult && (
              <div className={`mt-3 border rounded-xl p-2.5 flex items-center gap-2 ${scanResult.ok ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <CheckCircle2 size={14} className={scanResult.ok ? 'text-green-600' : 'text-red-600'} />
                <span className={`text-xs ${scanResult.ok ? 'text-green-700' : 'text-red-700'}`}>{scanResult.msg}</span>
              </div>
            )}
          </div>

          {/* Selected summary */}
          {selectedArchives.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
              <span className="text-xs text-blue-700">已选择 <span className="font-bold">{selectedArchives.length}</span> 件装备</span>
              <button onClick={() => setSelectedArchives([])} className="text-[10px] text-blue-500">清空</button>
            </div>
          )}

          {/* Equipment list (multi-select) */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2"><Shield size={14} className="text-blue-600" /> 我的装备</h3>
            <div className="space-y-2">
              {myEquipments.map(eq => {
                const selected = selectedArchives.find(a => a.id === eq.id);
                return (
                  <button
                    key={eq.id}
                    onClick={() => handleToggleEquip(eq)}
                    className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-colors ${selected ? 'bg-blue-50 border-2 border-blue-300' : 'bg-gray-50 border-2 border-transparent active:bg-blue-50'}`}
                  >
                    <div className={`w-6 h-6 rounded-md border-2 flex items-center justify-center shrink-0 ${selected ? 'bg-blue-500 border-blue-500' : 'border-gray-300'}`}>
                      {selected && <CheckCircle2 size={14} className="text-white" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800">{eq.name}</p>
                      <p className="text-xs text-gray-500">{eq.code} · {eq.model}</p>
                      <p className="text-[10px] text-gray-400">{eq.storageLocation}</p>
                    </div>
                    {isOverWarranty(eq) && <span className="px-1.5 py-0.5 bg-red-50 text-red-500 rounded text-[10px] font-medium shrink-0">已过质保</span>}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ FORM ═══════════ */
  if (step === 'form') {
    return (
      <MobileLayout title={editingOrderId ? '编辑报修' : '填写报修信息'} showBack onBack={() => setStep('select')}>
        <div className="p-4">
          {/* Order Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div><p className="text-[10px] text-blue-600">{editingOrderId ? '报修单号' : '报修单号'}</p><p className="text-sm font-semibold text-blue-800 font-mono">{editingOrderId || genOrderNo()}</p></div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          {/* 设备档案（多装备） */}
          <div className="space-y-3 mb-3">
            {selectedArchives.map((a, idx) => (
              <div key={a.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
                    <Package size={14} className="text-blue-600" /> 设备档案 #{idx + 1}
                    {isOverWarranty(a) && <span className="px-1.5 py-0.5 bg-red-50 text-red-500 rounded text-[10px] font-medium">已过质保</span>}
                  </h3>
                  <button onClick={() => setSelectedArchives(prev => prev.filter((_, i) => i !== idx))} className="text-gray-400 active:text-red-500 p-1"><X size={14} /></button>
                </div>
                <div className="space-y-1.5">
                  {[
                    { label: '装备名称', value: a.name },
                    { label: '规格型号', value: a.model },
                    { label: '装备编码', value: a.code, mono: true },
                    { label: '生产日期', value: a.productionDate },
                    { label: '有效期至', value: a.expiryDate },
                    { label: '质保期', value: `${a.warrantyMonths}个月` },
                    { label: '供应商', value: a.supplier },
                    { label: '联系人', value: a.contactPerson },
                    { label: '联系电话', value: a.contactPhone },
                    { label: '报修数量', value: `${a.repairQty} ${a.unit}` },
                  ].map((f, i) => (
                    <div key={i} className="flex justify-between py-0.5 border-b border-gray-50 last:border-0">
                      <span className="text-xs text-gray-500">{f.label}</span>
                      <span className={`text-xs text-gray-800 font-medium ${f.mono ? 'font-mono' : ''}`}>{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* 故障描述 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <label className="text-sm font-semibold text-gray-800 mb-2 block flex items-center gap-2">
              <AlertTriangle size={14} className="text-orange-600" /> 故障描述 <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="请详细描述故障现象..."
              rows={3}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all resize-none"
            />
          </div>

          {/* Rules */}
          <div className="bg-gray-50 rounded-2xl p-3 mb-4">
            <p className="text-[10px] text-gray-500 leading-relaxed">1. 可同时报修多件装备，请在上一页多选</p>
            <p className="text-[10px] text-gray-500 leading-relaxed">2. 草稿可随时编辑，提交后不可撤回</p>
            <p className="text-[10px] text-gray-500 leading-relaxed">3. 维修完成后需验收确认，超时自动完结</p>
          </div>

          {/* Buttons */}
          <div className="flex gap-2 mb-6">
            <button onClick={handleSaveDraft} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">
              保存草稿
            </button>
            <button
              onClick={handleSubmit}
              disabled={!description.trim() || selectedArchives.length === 0}
              className={`flex-1 py-3 rounded-xl font-medium text-sm transition-colors ${description.trim() && selectedArchives.length > 0 ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}
            >
              提交报修申请
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ SUCCESS ═══════════ */
  return (
    <MobileLayout title="报修成功" showBack onBack={() => { setStep('list'); resetForm(); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">报修工单已提交</h3>
        <p className="text-sm text-gray-500 text-center mb-6">系统将自动推送至维修部门处理</p>
        <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6 space-y-2">
          <div className="flex justify-between"><span className="text-xs text-gray-500">报修装备</span><span className="text-sm text-gray-800">{selectedArchives.map(a => a.name).join('、')} 共{selectedArchives.length}件</span></div>
          <div className="flex justify-between"><span className="text-xs text-gray-500">当前状态</span><span className="text-sm text-blue-600 font-medium">已提交</span></div>
        </div>
        <button onClick={() => { setStep('list'); resetForm(); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">返回报修列表</button>
      </div>
    </MobileLayout>
  );
}

/* ─── Inline Check Action Component ─── */
function CheckAction({ order, onCheck }: { order: RepairOrder; onCheck: (id: string, result: 'pass'|'reopen', score: number) => void }) {
  const [showPanel, setShowPanel] = useState(false);
  const [score, setScore] = useState(5);

  if (!showPanel) {
    return (
      <button onClick={() => setShowPanel(true)} className="flex items-center gap-1 px-2.5 py-1.5 bg-orange-50 text-orange-600 rounded-lg text-[10px] font-medium active:bg-orange-100 transition-colors">
        <Star size={12} /> 验收
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowPanel(false)}>
      <div className="absolute inset-0 bg-black/40" />
      <div className="relative bg-white rounded-t-3xl w-full p-6" onClick={e => e.stopPropagation()}>
        <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-1">维修验收</h3>
        <p className="text-xs text-gray-500 mb-4">{order.id} · {order.archives[0]?.name}等{order.archives.length}件</p>

        {/* Score */}
        <div className="mb-4">
          <label className="text-sm text-gray-700 mb-2 block">维修评分</label>
          <div className="flex gap-2">
            {[1, 2, 3, 4, 5].map(s => (
              <button key={s} onClick={() => setScore(s)} className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-colors ${score >= s ? 'bg-yellow-50 text-yellow-500' : 'bg-gray-50 text-gray-300'}`}>
                <Star size={20} fill={score >= s ? 'currentColor' : 'none'} />
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-1">{score} 分 — {score >= 4 ? '维修满意' : score >= 2 ? '基本合格' : '维修不满意'}</p>
        </div>

        {/* Actions */}
        <button onClick={() => { onCheck(order.id, 'pass', score); setShowPanel(false); }} className="w-full bg-green-500 text-white py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-green-600 transition-colors">
          验收通过（完结）
        </button>
        <button onClick={() => { onCheck(order.id, 'reopen', score); setShowPanel(false); }} className="w-full bg-red-50 text-red-600 py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-red-100 transition-colors border border-red-200">
          验收不通过（重开）
        </button>
        <button onClick={() => setShowPanel(false)} className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-2xl font-medium text-base">取消</button>
      </div>
    </div>
  );
}
