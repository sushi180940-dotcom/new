import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { CheckCircle2, Package, CircleDot, ArrowLeftRight, AlertTriangle, Wrench, ClipboardList, Zap } from 'lucide-react';

const typeLabelMap: Record<string, string> = {
  distribute: '配发出库', transfer: '调拨出库',
  repair: '报修出库', scrap: '报废出库', emergency: '紧急出库',
};
const typeColorMap: Record<string, string> = {
  distribute: '#1565c0', transfer: '#7c4dff',
  repair: '#00acc1', scrap: '#e53935', emergency: '#ed6c02',
};
const typeIconMap: Record<string, React.ElementType> = {
  distribute: ClipboardList, transfer: ArrowLeftRight,
  repair: Wrench, scrap: AlertTriangle, emergency: Zap,
};

const mockDetailData: Record<string, {
  id: string; type: string; status: string;
  createTime: string; completeTime?: string; operator: string;
  basicInfo: Record<string, string>;
  materials: Array<{
    name: string; category: string; model: string;
    quantity: number; stockQty: number; remainQty: number;
    unit: string; price: number; total: number;
    equipmentCode: string; rfidCode: string;
    fromLocation: string; supplier: string;
    maintenanceValue: number; maintenanceUnit: string;
  }>;
}> = {
  CK20240520001: {
    id: 'CK20240520001',
    type: 'receive',
    status: 'completed',
    createTime: '2024-05-20 09:15',
    completeTime: '2024-05-20 09:30',
    operator: '李建国',
    basicInfo: {
      applicant: '王强', applyUnit: '朝阳分局',
      isBorrow: 'true', returnTime: '2024-06-20',
      fromLocation: '省厅主仓库/主仓库1楼',
      outDate: '2024-05-20 09:15',
      remark: '',
    },
    materials: [
      { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, stockQty: 15, remainQty: 14, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', maintenanceValue: 3, maintenanceUnit: '年' },
      { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, stockQty: 20, remainQty: 19, unit: '个', price: 280, total: 280, equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', maintenanceValue: 1, maintenanceUnit: '年' },
    ],
  },
  CK20240519003: {
    id: 'CK20240519003',
    type: 'transfer',
    status: 'completed',
    createTime: '2024-05-19 14:30',
    completeTime: '2024-05-19 14:45',
    operator: '张丽',
    basicInfo: {
      transferNo: 'DB20240517001',
      fromUnit: '省厅主仓库', toUnit: '香河园派出所',
      fromLocation: '02号装备室/A区',
      outDate: '2024-05-19 14:30',
      remark: '',
    },
    materials: [
      { name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 5, stockQty: 10, remainQty: 5, unit: '双', price: 150, total: 750, equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A~E', fromLocation: '02号装备室/A区', supplier: '盾甲科技', maintenanceValue: 2, maintenanceUnit: '年' },
    ],
  },
};

export default function OutInventoryDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const detail = mockDetailData[id || ''];

  if (!detail) {
    return (
      <MobileLayout title="出库详情" showBack onBack={() => navigate('/out')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Package size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到出库记录</p>
        </div>
      </MobileLayout>
    );
  }

  const TypeIcon = typeIconMap[detail.type] || Package;
  const totalQty = detail.materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = detail.materials.reduce((s, m) => s + m.total, 0);

  return (
    <MobileLayout title="出库详情" showBack onBack={() => navigate('/out')}>
      <div className="p-4">
        {/* Status Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${typeColorMap[detail.type]}15` }}>
              <TypeIcon size={24} style={{ color: typeColorMap[detail.type] }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{detail.id}</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white" style={{ backgroundColor: typeColorMap[detail.type] }}>
                  {typeLabelMap[detail.type]}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  detail.status === 'completed' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {detail.status === 'completed' ? '已出库' : '待出库'}
                </span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">创建时间</p>
              <p className="text-xs text-gray-800 font-medium">{detail.createTime}</p>
            </div>
            {detail.completeTime && (
              <div className="bg-gray-50 rounded-xl p-2.5">
                <p className="text-[10px] text-gray-500">完成时间</p>
                <p className="text-xs text-gray-800 font-medium">{detail.completeTime}</p>
              </div>
            )}
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">经办人</p>
              <p className="text-xs text-gray-800 font-medium">{detail.operator}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">物资总数</p>
              <p className="text-xs text-gray-800 font-medium">{totalQty} 件</p>
            </div>
          </div>
        </div>

        {/* Basic Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">基本信息</h3>
          <div className="space-y-2 text-sm">
            {Object.entries(detail.basicInfo).filter(([, v]) => v).map(([k, v]) => (
              <div key={k} className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{
                  k === 'applicant' ? '申请人/单位' : k === 'applyUnit' ? '申请单位' :
                  k === 'isBorrow' ? '是否借用' : k === 'returnTime' ? '归还时间' :
                  k === 'fromLocation' ? '调出仓库' : k === 'outDate' ? '出库日期' :
                  k === 'transferNo' ? '调拨单号' : k === 'fromUnit' ? '发物单位' :
                  k === 'toUnit' ? '收物单位' : k === 'repairNo' ? '报修单号' :
                  k === 'scrapNo' ? '报废单号' : k === 'distributeUnit' ? '配发单位' :
                  k === 'remark' ? '备注' : k}</span>
                <span className="text-xs text-gray-800 font-medium">{v}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Materials */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">物资明细 ({detail.materials.length})</h3>
          <div className="space-y-3">
            {detail.materials.map((m, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{m.name}</span>
                    <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">保养{m.maintenanceValue}{m.maintenanceUnit}</span>
                  </div>
                  <span className="text-sm font-bold text-[#1565c0]">¥{m.total.toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>编号：{m.equipmentCode}</span>
                  <span>RFID：{m.rfidCode}</span>
                  <span>型号：{m.model}</span>
                  <span>类别：{m.category}</span>
                  <span>出库：{m.quantity} {m.unit}</span>
                  <span>在库原量：{m.stockQty} {m.unit}</span>
                  <span>剩余：{m.remainQty} {m.unit}</span>
                  <span>单价：¥{m.price}</span>
                  <span>存放：{m.fromLocation}</span>
                  <span>供应商：{m.supplier}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
            <span className="text-sm text-gray-600">共 {detail.materials.length} 种，{totalQty} 件</span>
            <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toLocaleString()}</span>
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">状态流转</h3>
          <div className="space-y-0">
            {[
              { label: '创建出库单', time: detail.createTime, done: true },
              { label: '待出库', time: detail.createTime, done: true },
              ...(detail.status === 'completed' ? [{ label: '已出库', time: detail.completeTime || '', done: true }] : []),
            ].map((s, i, arr) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${s.done ? 'bg-green-500' : 'bg-gray-300'}`}>
                    {s.done ? <CheckCircle2 size={14} className="text-white" /> : <CircleDot size={14} className="text-white" />}
                  </div>
                  {i < arr.length - 1 && <div className="w-0.5 h-6 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm ${s.done ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>{s.label}</p>
                  <p className="text-[10px] text-gray-400">{s.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
