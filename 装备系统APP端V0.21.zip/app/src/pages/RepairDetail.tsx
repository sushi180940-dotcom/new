import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Wrench, CheckCircle2, Clock, Star,
  Package, FileText, CircleDot, AlertTriangle, Trash2
} from 'lucide-react';

/* ─── types ─── */
type RepairStatus = 'draft' | 'pending_check' | 'done' | 'auto_done';

interface EquipmentArchive {
  id: string; name: string; model: string; code: string;
  productionDate: string; expiryDate: string; warrantyMonths: number;
  supplier: string; contactPerson: string; contactPhone: string;
  repairQty: number; unit: string; rfid: string; storageLocation: string;
}

interface RepairOrder {
  id: string; status: RepairStatus;
  applyTime: string; submitTime?: string; completeTime?: string;
  checkTime?: string; autoCloseTime?: string;
  reporter: string; description: string;
  archives: EquipmentArchive[];
  checkScore?: number; checkResult?: 'pass' | 'reopen';
}

const STATUS_CFG: Record<RepairStatus, { label: string; color: string; bg: string; icon: typeof Clock }> = {
  draft:         { label: '草稿',     color: 'text-gray-600',  bg: 'bg-gray-100',  icon: FileText },
  pending_check: { label: '待验收',   color: 'text-orange-600',bg: 'bg-orange-50', icon: Star },
  done:          { label: '已完结',   color: 'text-green-600', bg: 'bg-green-50',  icon: CheckCircle2 },
  auto_done:     { label: '自动完结', color: 'text-green-600', bg: 'bg-green-50',  icon: Clock },
};

/* ─── mock data ─── */
const mkA = (overrides: Partial<EquipmentArchive> = {}): EquipmentArchive => ({
  id: '1', name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-005-001',
  productionDate: '2024-01-15', expiryDate: '2027-01-15', warrantyMonths: 24,
  supplier: '猎豹装备科技', contactPerson: '刘工', contactPhone: '13800138001',
  repairQty: 1, unit: '台', rfid: 'RFID202601008H', storageLocation: '省厅主仓库/主仓库2楼',
  ...overrides,
});

const initOrders: Record<string, RepairOrder> = {
  WX20240520001: { id: 'WX20240520001', status: 'draft', applyTime: '2024-05-20 09:30', reporter: '张伟', description: '执法记录仪无法开机，疑似电池故障', archives: [mkA({repairQty:2})] },
  WX20240519002: { id: 'WX20240519002', status: 'pending_check', applyTime: '2024-05-19 14:00', submitTime: '2024-05-19 14:05', reporter: '王强', description: '战术手电开关接触不良，时亮时灭', archives: [mkA({name:'战术手电',model:'ZSD-200-X',code:'ZB-006-001',supplier:'国安器材',contactPerson:'张工',contactPhone:'13800138002',productionDate:'2022-05-20',expiryDate:'2025-05-20',rfid:'RFID202601010J',storageLocation:'省厅主仓库/主仓库3楼'})] },
  WX20240518003: { id: 'WX20240518003', status: 'pending_check', applyTime: '2024-05-18 10:20', submitTime: '2024-05-18 10:25', completeTime: '2024-06-01 16:30', reporter: '李明', description: '防刺手套掌心部位磨损严重', archives: [mkA({name:'防刺手套',model:'FCST-100',code:'ZB-004-001',supplier:'盾甲科技',contactPerson:'陈工',contactPhone:'13800138003',productionDate:'2023-05-10',expiryDate:'2026-05-10',rfid:'RFID202601004D',storageLocation:'省厅主仓库/主仓库1楼'})] },
  WX20240517004: { id: 'WX20240517004', status: 'done', applyTime: '2024-05-17 16:45', submitTime: '2024-05-17 16:50', completeTime: '2024-05-28 11:00', checkTime: '2024-05-28 14:30', reporter: '赵刚', description: '防弹背心魔术贴脱落，影响穿戴', checkScore: 5, checkResult: 'pass', archives: [mkA({name:'防弹背心',model:'FDY-3R-01',code:'ZB-001-001',supplier:'某省安防科技有限公司',contactPerson:'王工',contactPhone:'13800138004',productionDate:'2023-01-10',expiryDate:'2028-01-10',rfid:'RFID202601001A',storageLocation:'省厅主仓库/主仓库1楼'})] },
  WX20240516005: { id: 'WX20240516005', status: 'pending_check', applyTime: '2024-05-16 11:00', submitTime: '2024-05-16 11:05', completeTime: '2024-05-25 09:00', checkTime: '2024-05-25 10:30', reporter: '孙丽', description: '对讲机信号不稳定，维修后问题依旧', checkScore: 2, checkResult: 'reopen', archives: [mkA({name:'对讲机',model:'DJ-HY-800',code:'ZB-004-001',supplier:'中华安防集团',contactPerson:'李工',contactPhone:'13800138005',productionDate:'2024-01-25',expiryDate:'2026-01-25',rfid:'RFID202601006F',storageLocation:'省厅主仓库/主仓库2楼',repairQty:3})] },
  WX20240515006: { id: 'WX20240515006', status: 'auto_done', applyTime: '2024-05-15 08:30', submitTime: '2024-05-15 08:35', completeTime: '2024-05-30 10:00', autoCloseTime: '2024-06-06 10:00', reporter: '周涛', description: '警棍表面氧化生锈', archives: [mkA({name:'警棍',model:'JG-TELE',code:'ZB-007-002',supplier:'雄鹰警械公司',contactPerson:'赵工',contactPhone:'13800138006',productionDate:'2022-06-10',expiryDate:'2025-06-10',rfid:'RFID202601013M',storageLocation:'02号装备室/A区',repairQty:2})] },
};

function isOverWarranty(a: EquipmentArchive) {
  const prod = new Date(a.productionDate);
  const end = new Date(prod); end.setMonth(end.getMonth() + a.warrantyMonths);
  return new Date() > end;
}

/* ─── component ─── */
export default function RepairDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order] = useState<RepairOrder | null>(initOrders[id || ''] || null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  if (!order) {
    return (
      <MobileLayout title="报修详情" showBack onBack={() => navigate('/repair')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Wrench size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到报修工单</p>
        </div>
      </MobileLayout>
    );
  }

  const sc = STATUS_CFG[order.status];
  const StatusIcon = sc.icon;

  // timeline
  const tl: { label: string; time?: string; done: boolean; highlight?: boolean }[] = [
    { label: '提交报修', time: order.applyTime, done: true },
  ];
  if (order.status === 'draft') {
    tl.push({ label: '草稿（未提交）', done: false, highlight: true });
  } else {
    tl.push({ label: '提交报修', time: order.submitTime, done: true });
    if (order.completeTime) {
      tl.push({ label: '维修完成', time: order.completeTime, done: true });
    }
    if (order.status === 'done') {
      tl.push({ label: '验收通过', time: order.checkTime, done: true });
    }
    if (order.status === 'auto_done') {
      tl.push({ label: '超时自动完结', time: order.autoCloseTime, done: true, highlight: true });
    }
    if (order.status === 'pending_check') {
      tl.push({ label: '待验收', done: false, highlight: true });
    }
  }

  return (
    <MobileLayout title="报修详情" showBack onBack={() => navigate('/repair')}>
      <div className="p-4 space-y-3 pb-6">
        {/* Header */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-xl ${sc.bg} flex items-center justify-center`}>
              <StatusIcon size={24} className={sc.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{order.id}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>{sc.label}</span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{order.archives.map(a => a.name).join('、')} 等{order.archives.length}件</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请时间</p>
              <p className="text-xs text-gray-800 font-medium">{order.applyTime}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">报修人</p>
              <p className="text-xs text-gray-800 font-medium">{order.reporter}</p>
            </div>
            {order.completeTime && (
              <div className="bg-gray-50 rounded-xl p-2.5">
                <p className="text-[10px] text-gray-500">维修完成</p>
                <p className="text-xs text-gray-800 font-medium">{order.completeTime}</p>
              </div>
            )}
            {order.checkScore !== undefined && (
              <div className="bg-gray-50 rounded-xl p-2.5">
                <p className="text-[10px] text-gray-500">验收评分</p>
                <div className="flex items-center gap-0.5">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} size={12} className={order.checkScore! >= s ? 'text-yellow-500' : 'text-gray-300'} fill={order.checkScore! >= s ? 'currentColor' : 'none'} />
                  ))}
                  <span className="text-xs text-gray-700 ml-1">{order.checkScore}分</span>
                </div>
              </div>
            )}
          </div>

          {/* 草稿删除按钮 */}
          {order.status === 'draft' && (
            <button onClick={() => setShowDeleteConfirm(true)} className="w-full mt-3 py-2.5 bg-red-50 text-red-600 rounded-xl text-sm font-medium active:bg-red-100 transition-colors flex items-center justify-center gap-2">
              <Trash2 size={14} /> 删除草稿
            </button>
          )}
        </div>

        {/* 故障描述 */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <AlertTriangle size={14} className="text-orange-600" /> 故障描述
          </h3>
          <div className="bg-orange-50 rounded-xl p-3">
            <p className="text-sm text-gray-800">{order.description}</p>
          </div>
        </div>

        {/* 设备档案（多装备） */}
        {order.archives.map((a, idx) => (
          <div key={a.id} className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Package size={14} className="text-blue-600" /> 设备档案 #{idx + 1}
              {isOverWarranty(a) && <span className="px-1.5 py-0.5 bg-red-50 text-red-500 rounded text-[10px] font-medium">已过质保</span>}
            </h3>
            <div className="space-y-1.5">
              {[
                { label: '装备名称', value: a.name },
                { label: '规格型号', value: a.model },
                { label: '装备编码', value: a.code, mono: true },
                { label: '生产日期', value: a.productionDate },
                { label: '有效期至', value: a.expiryDate },
                { label: '质保期', value: `${a.warrantyMonths}个月` },
                { label: '供应商', value: a.supplier },
                { label: '联系人', value: a.contactPerson },
                { label: '联系电话', value: a.contactPhone },
                { label: '报修数量', value: `${a.repairQty} ${a.unit}` },
                { label: 'RFID编码', value: a.rfid, mono: true },
                { label: '存储位置', value: a.storageLocation },
              ].map((f, i) => (
                <div key={i} className="flex justify-between py-0.5 border-b border-gray-50 last:border-0">
                  <span className="text-xs text-gray-500">{f.label}</span>
                  <span className={`text-xs text-gray-800 font-medium ${f.mono ? 'font-mono' : ''}`}>{f.value}</span>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* 状态流转 */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Clock size={14} className="text-blue-600" /> 状态流转
          </h3>
          <div className="space-y-0">
            {tl.map((node, i, arr) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${node.done ? (node.highlight ? 'bg-orange-500' : 'bg-green-500') : 'bg-gray-300'}`}>
                    {node.done ? <CheckCircle2 size={14} className="text-white" /> : <CircleDot size={14} className="text-white" />}
                  </div>
                  {i < arr.length - 1 && <div className="w-0.5 h-6 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm ${node.done ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>{node.label}</p>
                  {node.time && <p className="text-[10px] text-gray-400">{node.time}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Delete Confirm Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowDeleteConfirm(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative bg-white rounded-t-3xl w-full p-6" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">删除草稿</h3>
            <p className="text-sm text-gray-500 mb-6">确认删除该报修草稿？删除后不可恢复。</p>
            <button onClick={() => { setShowDeleteConfirm(false); navigate('/repair'); }} className="w-full bg-red-500 text-white py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-red-600">确认删除</button>
            <button onClick={() => setShowDeleteConfirm(false)} className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-2xl font-medium text-base">取消</button>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
