import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  PackageOpen, ChevronRight, Plus, Trash2, CheckCircle2, Clock,
  ArrowRight, Minus, UserCheck, ArrowLeftRight, AlertTriangle,
  QrCode, CircleDot, Wrench, ClipboardList, Zap,
  Building2, Truck, FileText
} from 'lucide-react';

interface OutMaterialItem {
  id: string;
  name: string;
  category: string;
  model: string;
  quantity: number;
  stockQty: number;
  remainQty: number;
  unit: string;
  price: number;
  total: number;
  equipmentCode: string;
  rfidCode: string;
  fromLocation: string;
  supplier: string;
  isFixedAsset: boolean;
  remark: string;
  productionDate: string;
  expiryDate: string;
  maintenanceValue: number;
  maintenanceUnit: string;
}

interface OutRecord {
  id: string;
  type: string;
  status: 'pending' | 'completed' | 'draft';
  createTime: string;
  materials: number;
  // 配发出库
  applicant?: string;
  distributeUnit?: string;
  fromLocation?: string;
  isBorrow?: boolean;
  remark?: string;
  // 调拨出库
  fromUnit?: string;
  toUnit?: string;
  transferNo?: string;
  // 报修出库
  repairApplicant?: string;
  // 报废出库
  scrapApplicant?: string;
}

// ── 库存装备选择弹窗数据 ──

interface StockEquipment {
  id: string;
  code: string;
  name: string;
  categoryL1: string;
  categoryL2: string;
  categoryL3: string;
  model: string;
  modelCode: string;
  unit: string;
  stockQty: number;
  hasBattery: boolean;
  maintenanceMonths: number;
  manufacturer: string;
  rfid: string;
  storageLocation: string;
}

const CATEGORIES = [
  {
    l1: '防护装备',
    children: [
      { l2: '防弹防护', l3: ['防弹背心', '防弹头盔', '防弹盾牌', '防弹插板'] },
      { l2: '防刺防护', l3: ['防刺背心', '防刺手套', '防刺护臂'] },
      { l2: '防暴防护', l3: ['防暴头盔', '防暴盾牌', '防暴服'] },
    ],
  },
  {
    l1: '通讯设备',
    children: [
      { l2: '无线通讯', l3: ['对讲机', '车载电台', '手持电台'] },
      { l2: '网络设备', l3: ['路由器', '交换机', '信号增强器'] },
    ],
  },
  {
    l1: '记录设备',
    children: [
      { l2: '视频记录', l3: ['执法记录仪', '车载记录仪', '无人机'] },
      { l2: '音频记录', l3: ['录音笔', '采访机'] },
    ],
  },
  {
    l1: '照明设备',
    children: [
      { l2: '手持照明', l3: ['战术手电', '强光手电', '搜索灯'] },
      { l2: '固定照明', l3: ['探照灯', '警示灯'] },
    ],
  },
  {
    l1: '械具',
    children: [
      { l2: '约束械具', l3: ['手铐', '脚镣', '约束带'] },
      { l2: '警械', l3: ['警棍', '催泪喷射器', '警用钢叉'] },
    ],
  },
];

const STOCK_EQUIPMENTS: StockEquipment[] = [
  { id: '1', code: 'ZB-001-001', name: '防弹背心', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹背心', model: 'FDY-3R-01', modelCode: 'MX-001', unit: '件', stockQty: 45, hasBattery: false, maintenanceMonths: 36, manufacturer: '某省安防科技有限公司', rfid: 'RFID202601001A', storageLocation: '省厅主仓库/主仓库1楼' },
  { id: '2', code: 'ZB-001-002', name: '防弹头盔', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹头盔', model: 'FDK-2A-01', modelCode: 'MX-002', unit: '顶', stockQty: 32, hasBattery: false, maintenanceMonths: 36, manufacturer: '红星装备厂', rfid: 'RFID202601002B', storageLocation: '省厅主仓库/主仓库1楼' },
  { id: '3', code: 'ZB-001-003', name: '防弹盾牌', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹盾牌', model: 'FDP-800-A', modelCode: 'MX-003', unit: '件', stockQty: 18, hasBattery: false, maintenanceMonths: 24, manufacturer: '国安器材有限公司', rfid: 'RFID202601003C', storageLocation: '省厅主仓库/主仓库1楼' },
  { id: '4', code: 'ZB-002-001', name: '防刺背心', categoryL1: '防护装备', categoryL2: '防刺防护', categoryL3: '防刺背心', model: 'FCY-01A', modelCode: 'MX-004', unit: '件', stockQty: 28, hasBattery: false, maintenanceMonths: 24, manufacturer: '盾甲科技', rfid: 'RFID202601004D', storageLocation: '省厅主仓库/主仓库1楼' },
  { id: '5', code: 'ZB-003-001', name: '防暴头盔', categoryL1: '防护装备', categoryL2: '防暴防护', categoryL3: '防暴头盔', model: 'FBK-01', modelCode: 'MX-005', unit: '顶', stockQty: 56, hasBattery: false, maintenanceMonths: 12, manufacturer: '警用装备中心', rfid: 'RFID202601005E', storageLocation: '省厅主仓库/主仓库2楼' },
  { id: '6', code: 'ZB-004-001', name: '对讲机', categoryL1: '通讯设备', categoryL2: '无线通讯', categoryL3: '对讲机', model: 'DJ-HY-800', modelCode: 'MX-006', unit: '台', stockQty: 120, hasBattery: true, maintenanceMonths: 12, manufacturer: '中华安防集团', rfid: 'RFID202601006F', storageLocation: '省厅主仓库/主仓库2楼' },
  { id: '7', code: 'ZB-004-002', name: '车载电台', categoryL1: '通讯设备', categoryL2: '无线通讯', categoryL3: '车载电台', model: 'CZ-2000', modelCode: 'MX-007', unit: '台', stockQty: 15, hasBattery: true, maintenanceMonths: 12, manufacturer: '雄鹰警械公司', rfid: 'RFID202601007G', storageLocation: '01号装备室/东侧区域' },
  { id: '8', code: 'ZB-005-001', name: '执法记录仪', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '执法记录仪', model: 'DSJ-A7', modelCode: 'MX-008', unit: '台', stockQty: 85, hasBattery: true, maintenanceMonths: 12, manufacturer: '猎豹装备科技', rfid: 'RFID202601008H', storageLocation: '省厅主仓库/主仓库2楼' },
  { id: '9', code: 'ZB-005-002', name: '车载记录仪', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '车载记录仪', model: 'CZJ-4K-02', modelCode: 'MX-009', unit: '台', stockQty: 22, hasBattery: true, maintenanceMonths: 12, manufacturer: '红星装备厂', rfid: 'RFID202601009I', storageLocation: '01号装备室/西侧区域' },
  { id: '10', code: 'ZB-006-001', name: '战术手电', categoryL1: '照明设备', categoryL2: '手持照明', categoryL3: '战术手电', model: 'ZSD-200-X', modelCode: 'MX-010', unit: '个', stockQty: 150, hasBattery: true, maintenanceMonths: 6, manufacturer: '国安器材有限公司', rfid: 'RFID202601010J', storageLocation: '省厅主仓库/主仓库3楼' },
  { id: '11', code: 'ZB-006-002', name: '强光手电', categoryL1: '照明设备', categoryL2: '手持照明', categoryL3: '强光手电', model: 'QG-500-LM', modelCode: 'MX-011', unit: '个', stockQty: 68, hasBattery: true, maintenanceMonths: 6, manufacturer: '某省安防科技有限公司', rfid: 'RFID202601011K', storageLocation: '省厅主仓库/主仓库3楼' },
  { id: '12', code: 'ZB-007-001', name: '手铐', categoryL1: '械具', categoryL2: '约束械具', categoryL3: '手铐', model: 'SK-STD', modelCode: 'MX-012', unit: '副', stockQty: 200, hasBattery: false, maintenanceMonths: 60, manufacturer: '中华安防集团', rfid: 'RFID202601012L', storageLocation: '02号装备室/A区' },
  { id: '13', code: 'ZB-007-002', name: '警棍', categoryL1: '械具', categoryL2: '警械', categoryL3: '警棍', model: 'JG-TELE', modelCode: 'MX-013', unit: '根', stockQty: 90, hasBattery: false, maintenanceMonths: 12, manufacturer: '雄鹰警械公司', rfid: 'RFID202601013M', storageLocation: '02号装备室/A区' },
  { id: '14', code: 'ZB-007-003', name: '催泪喷射器', categoryL1: '械具', categoryL2: '警械', categoryL3: '催泪喷射器', model: 'CL-OC-50', modelCode: 'MX-014', unit: '个', stockQty: 75, hasBattery: false, maintenanceMonths: 24, manufacturer: '猎豹装备科技', rfid: 'RFID202601014N', storageLocation: '02号装备室/B区' },
  { id: '15', code: 'ZB-005-003', name: '无人机', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '无人机', model: 'UAV-4K-01', modelCode: 'MX-015', unit: '架', stockQty: 8, hasBattery: true, maintenanceMonths: 6, manufacturer: '红星装备厂', rfid: 'RFID202601015O', storageLocation: '01号装备室/东侧区域' },
];

// ── 系统申请数据 ──

interface SystemApply {
  id: string;
  title: string;
  applicant?: string;
  unit?: string;
  fromLocation?: string;
  type?: string;
  fromUnit?: string;
  toUnit?: string;
  remark?: string;
  materials: { name: string; qty: number }[];
}

const distributeApplies: SystemApply[] = [
  { id: 'PF20240601001', title: '朝阳分局装备配发申请', applicant: '王强', unit: '朝阳分局', fromLocation: '省厅主仓库/主仓库1楼', type: '领用', remark: '日常执勤装备配发', materials: [{ name: '防弹背心', qty: 2 }, { name: '执法记录仪', qty: 3 }] },
  { id: 'PF20240601002', title: '东坝派出所装备配发申请', applicant: '李明', unit: '东坝派出所', fromLocation: '省厅主仓库/主仓库2楼', type: '借用', remark: '临时任务借用', materials: [{ name: '对讲机', qty: 5 }, { name: '战术手电', qty: 2 }] },
];

const transferApplies: SystemApply[] = [
  { id: 'DB20240601001', title: '省厅主仓库调至朝阳分局', fromUnit: '省厅主仓库', toUnit: '朝阳分局', fromLocation: '省厅主仓库/主仓库1楼', applicant: '张丽', remark: '分局装备补充', materials: [{ name: '防弹背心', qty: 10 }, { name: '手铐', qty: 20 }] },
  { id: 'DB20240601002', title: '01号装备室调至东坝派出所', fromUnit: '01号装备室', toUnit: '东坝派出所', fromLocation: '01号装备室/东侧区域', applicant: '赵伟', remark: '派出所装备更新', materials: [{ name: '执法记录仪', qty: 5 }] },
];

const repairApplies: SystemApply[] = [
  { id: 'BX20240601001', title: '执法记录仪报修', applicant: '王强', fromLocation: '省厅主仓库/主仓库2楼', remark: '无法开机，需返厂维修', materials: [{ name: '执法记录仪', qty: 2 }] },
  { id: 'BX20240601002', title: '对讲机报修', applicant: '李明', fromLocation: '01号装备室/西侧区域', remark: '信号不稳定', materials: [{ name: '对讲机', qty: 3 }] },
];

const scrapApplies: SystemApply[] = [
  { id: 'BF20240601001', title: '过期防弹背心报废', applicant: '张丽', fromLocation: '省厅主仓库/主仓库1楼', remark: '超过有效期5年', materials: [{ name: '防弹背心', qty: 5 }] },
  { id: 'BF20240601002', title: '损坏战术手电报废', applicant: '赵伟', fromLocation: '02号装备室/A区', remark: '外壳破裂无法使用', materials: [{ name: '战术手电', qty: 8 }] },
];

const outTypes = [
  { key: 'distribute', label: '配发出库', desc: '民警领用装备出库', icon: ClipboardList, color: '#1565c0' },
  { key: 'transfer', label: '调拨出库', desc: '仓库间调拨出库', icon: ArrowLeftRight, color: '#7c4dff' },
  { key: 'scrap', label: '报废出库', desc: '超期报废出库', icon: AlertTriangle, color: '#e53935' },
  { key: 'repair', label: '报修出库', desc: '装备维修送检出库', icon: Wrench, color: '#00acc1' },
  { key: 'emergency', label: '紧急出库', desc: '紧急情况出库', icon: Zap, color: '#ed6c02' },
];

const mockHistory: OutRecord[] = [
  { id: 'CK20240520001', type: 'distribute', status: 'completed', createTime: '2024-05-20 09:15', materials: 3, applicant: '王强', distributeUnit: '朝阳分局', fromLocation: '省厅主仓库/主仓库1楼', isBorrow: false, remark: '日常执勤装备配发' },
  { id: 'CK20240520002', type: 'emergency', status: 'draft', createTime: '2024-05-20 08:00', materials: 1 },
  { id: 'CK20240519003', type: 'transfer', status: 'completed', createTime: '2024-05-19 14:30', materials: 5, fromUnit: '省厅主仓库', toUnit: '香河园派出所', transferNo: 'DB20240517001' },
  { id: 'CK20240518004', type: 'repair', status: 'pending', createTime: '2024-05-18 10:00', materials: 1, repairApplicant: '王强' },
  { id: 'CK20240517005', type: 'scrap', status: 'completed', createTime: '2024-05-17 16:20', materials: 1, scrapApplicant: '张丽' },
  { id: 'CK20240516006', type: 'distribute', status: 'completed', createTime: '2024-05-16 11:45', materials: 4, applicant: '李明', distributeUnit: '东坝派出所', fromLocation: '省厅主仓库/主仓库2楼', isBorrow: true, remark: '临时任务借用' },
  { id: 'CK20240515007', type: 'transfer', status: 'pending', createTime: '2024-05-15 08:30', materials: 6, fromUnit: '01号装备室', toUnit: '劲松派出所', transferNo: 'DB20240515001' },
];

const typeLabelMap: Record<string, string> = {
  distribute: '配发出库', transfer: '调拨出库', scrap: '报废出库', repair: '报修出库', emergency: '紧急出库',
};
const typeColorMap: Record<string, string> = {
  distribute: '#1565c0', transfer: '#7c4dff', scrap: '#e53935', repair: '#00acc1', emergency: '#ed6c02',
};

function generateOrderNo(): string {
  const d = new Date();
  const prefix = 'CK';
  const dateStr = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const random = String(Math.floor(Math.random() * 900) + 100).padStart(3, '0');
  return `${prefix}${dateStr}${random}`;
}

export default function OutInventory() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'type-select' | 'apply-list' | 'basic-info' | 'materials' | 'review' | 'success' | 'three-step1' | 'three-step2' | 'three-step3'>('list');
  const [selectedType, setSelectedType] = useState('');
  const [orderNo, setOrderNo] = useState('');
  const [basicInfo, setBasicInfo] = useState<Record<string, string>>({});
  const [materials, setMaterials] = useState<OutMaterialItem[]>([]);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('全部');
  // 配发出库三步流程专用状态
  const [distributeStep, setDistributeStep] = useState(0); // 0:配发内容 1:选择装备 2:确认出库
  const [selectedApply, setSelectedApply] = useState<SystemApply | null>(null);
  // 库存装备选择弹窗
  const [showPicker, setShowPicker] = useState(false);
  const [pickerSearch, setPickerSearch] = useState('');
  const [pickerL1, setPickerL1] = useState('');
  const [pickerL2, setPickerL2] = useState('');
  const [pickerL3, setPickerL3] = useState('');
  const [pickerSelectedIds, setPickerSelectedIds] = useState<string[]>([]);

  const selectedTypeConfig = outTypes.find(t => t.key === selectedType);

  // 获取系统申请列表
  const getApplyList = (): SystemApply[] => {
    switch (selectedType) {
      case 'distribute': return distributeApplies;
      case 'transfer': return transferApplies;
      case 'repair': return repairApplies;
      case 'scrap': return scrapApplies;
      default: return [];
    }
  };

  const handleTypeSelect = (typeKey: string) => {
    setSelectedType(typeKey);
    setOrderNo(generateOrderNo());
    // 配发/调拨/报修/报废 → 系统申请列表；紧急 → 直接填单
    if (typeKey === 'emergency') {
      setStep('basic-info');
      setBasicInfo({ outTime: new Date().toLocaleString('zh-CN') });
    } else {
      setStep('apply-list');
    }
  };

  const handleSelectApply = (apply: SystemApply) => {
    setOrderNo(generateOrderNo());
    // 配发/调拨/报修/报废 都走三步流程
    setSelectedApply(apply);
    setDistributeStep(0);
    setMaterials([]);
    setStep('three-step1');
  };

  const handleScanRFID = useCallback(() => {
    const mockStockDB: Record<string, { name: string; category: string; model: string; stockQty: number; unit: string; price: number; equipmentCode: string; fromLocation: string; supplier: string; productionDate: string; expiryDate: string }> = {
      'RFID202301058B': { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', stockQty: 15, unit: '件', price: 1200, equipmentCode: 'EQ202301058', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', productionDate: '2023-01-15', expiryDate: '2028-01-15' },
      'RFID202401001A': { name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', stockQty: 12, unit: '台', price: 1800, equipmentCode: 'EQ202401001', fromLocation: '省厅主仓库/主仓库2楼', supplier: '红星装备厂', productionDate: '2024-01-15', expiryDate: '2027-01-15' },
      'RFID202202112C': { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', stockQty: 20, unit: '个', price: 280, equipmentCode: 'EQ202202112', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', productionDate: '2022-06-10', expiryDate: '2025-06-10' },
    };
    const keys = Object.keys(mockStockDB);
    const randomKey = keys[Math.floor(Math.random() * keys.length)];
    const info = mockStockDB[randomKey];

    setMaterials(prev => {
      const existing = prev.find(m => m.name === info.name);
      if (existing) {
        return prev.map(m => m.name === info.name
          ? { ...m, quantity: m.quantity + 1, remainQty: info.stockQty - (m.quantity + 1), rfidCode: `${m.rfidCode}, ${randomKey}`, total: (m.quantity + 1) * m.price }
          : m
        );
      }
      return [...prev, {
        id: Date.now().toString(), name: info.name, category: info.category, model: info.model,
        quantity: 1, stockQty: info.stockQty, remainQty: info.stockQty - 1,
        unit: info.unit, price: info.price, total: info.price,
        equipmentCode: info.equipmentCode, rfidCode: randomKey,
        fromLocation: info.fromLocation, supplier: info.supplier,
        isFixedAsset: false, remark: '',
        productionDate: info.productionDate, expiryDate: info.expiryDate,
        maintenanceValue: 3, maintenanceUnit: '年',
      }];
    });
    setScanResult(`已扫描：${randomKey} · ${info.name} · 库存${info.stockQty}件`);
    setTimeout(() => setScanResult(null), 3000);
  }, []);

  const updateMaterial = (id: string, field: keyof OutMaterialItem, value: unknown) => {
    setMaterials(prev => prev.map(m => {
      if (m.id !== id) return m;
      const updated = { ...m, [field]: value };
      if (field === 'quantity') {
        updated.remainQty = updated.stockQty - Number(value);
        updated.total = Number(value) * updated.price;
      }
      return updated;
    }));
  };

  const addManualMaterial = () => {
    setPickerSearch('');
    setPickerL1('');
    setPickerL2('');
    setPickerL3('');
    setPickerSelectedIds([]);
    setShowPicker(true);
  };

  const handlePickerConfirm = () => {
    const selected = STOCK_EQUIPMENTS.filter(e => pickerSelectedIds.includes(e.id));
    const newItems: OutMaterialItem[] = selected.map(e => ({
      id: Date.now().toString() + Math.random().toString(36).slice(2, 5) + e.id,
      name: e.name, category: `${e.categoryL1}/${e.categoryL2}/${e.categoryL3}`, model: e.model,
      quantity: 1, stockQty: e.stockQty, remainQty: e.stockQty - 1,
      unit: e.unit, price: 0, total: 0,
      equipmentCode: e.code, rfidCode: e.rfid,
      fromLocation: e.storageLocation, supplier: e.manufacturer,
      isFixedAsset: false, remark: '',
      productionDate: '', expiryDate: '', maintenanceValue: Math.round(e.maintenanceMonths / 12) || 1, maintenanceUnit: e.maintenanceMonths >= 12 ? '年' : '月',
    }));
    setMaterials(prev => [...prev, ...newItems]);
    setShowPicker(false);
    setPickerSelectedIds([]);
  };

  const removeMaterial = (id: string) => setMaterials(prev => prev.filter(m => m.id !== id));

  const totalQty = materials.reduce((s, m) => s + m.quantity, 0);

  const filteredRecords = activeFilter === '全部' ? mockHistory
    : activeFilter === '草稿' ? mockHistory.filter(r => r.status === 'draft')
    : mockHistory.filter(r => typeLabelMap[r.type] === activeFilter);

  // ═══════════ LIST ═══════════
  // ═══════════════════════════════════════════
  // 库存装备选择弹窗（全屏覆盖）
  // ═══════════════════════════════════════════
  if (showPicker) {
    const filtered = STOCK_EQUIPMENTS.filter(e => {
      const matchSearch = !pickerSearch || e.name.toLowerCase().includes(pickerSearch.toLowerCase()) || e.code.toLowerCase().includes(pickerSearch.toLowerCase()) || e.model.toLowerCase().includes(pickerSearch.toLowerCase()) || e.rfid.toLowerCase().includes(pickerSearch.toLowerCase());
      const matchL1 = !pickerL1 || e.categoryL1 === pickerL1;
      const matchL2 = !pickerL2 || e.categoryL2 === pickerL2;
      const matchL3 = !pickerL3 || e.categoryL3 === pickerL3;
      return matchSearch && matchL1 && matchL2 && matchL3;
    });
    const l2Options = pickerL1 ? CATEGORIES.find(c => c.l1 === pickerL1)?.children.map(c => c.l2) || [] : [];
    const l3Options = pickerL1 && pickerL2 ? CATEGORIES.find(c => c.l1 === pickerL1)?.children.find(c => c.l2 === pickerL2)?.l3 || [] : [];

    return (
      <MobileLayout title="选择库存装备" showBack onBack={() => { setShowPicker(false); setPickerSelectedIds([]); }} rightAction={
        <button onClick={handlePickerConfirm} className={`text-white text-sm font-medium px-3 py-1.5 rounded-lg transition-colors ${pickerSelectedIds.length > 0 ? 'bg-green-500 active:bg-green-600' : 'bg-white/20'}`}>
          确认({pickerSelectedIds.length})
        </button>
      }>
        <div className="flex flex-col h-[calc(100vh-56px)] bg-gray-50">
          {/* 搜索框 */}
          <div className="p-3 bg-white shadow-sm shrink-0">
            <div className="relative mb-2">
              <input
                type="text"
                value={pickerSearch}
                onChange={e => setPickerSearch(e.target.value)}
                placeholder="搜索装备编码、名称、型号、RFID..."
                className="w-full bg-gray-50 rounded-xl pl-10 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
              <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
            </div>
            {/* 三级分类 */}
            <div className="flex gap-1.5">
              <select value={pickerL1} onChange={e => { setPickerL1(e.target.value); setPickerL2(''); setPickerL3(''); }} className="flex-1 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-700 outline-none border border-gray-200">
                <option value="">一级分类</option>
                {CATEGORIES.map(c => <option key={c.l1} value={c.l1}>{c.l1}</option>)}
              </select>
              <select value={pickerL2} onChange={e => { setPickerL2(e.target.value); setPickerL3(''); }} className="flex-1 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-700 outline-none border border-gray-200" disabled={!pickerL1}>
                <option value="">二级分类</option>
                {l2Options.map(l2 => <option key={l2} value={l2}>{l2}</option>)}
              </select>
              <select value={pickerL3} onChange={e => setPickerL3(e.target.value)} className="flex-1 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-700 outline-none border border-gray-200" disabled={!pickerL2}>
                <option value="">三级分类</option>
                {l3Options.map(l3 => <option key={l3} value={l3}>{l3}</option>)}
              </select>
            </div>
            {(pickerL1 || pickerSearch) && (
              <div className="flex items-center justify-between mt-1.5">
                <span className="text-[10px] text-gray-400">共 {filtered.length} 条</span>
                {(pickerL1 || pickerL2 || pickerL3 || pickerSearch) && (
                  <button onClick={() => { setPickerL1(''); setPickerL2(''); setPickerL3(''); setPickerSearch(''); }} className="text-[10px] text-blue-500">清除筛选</button>
                )}
              </div>
            )}
          </div>

          {/* 表格头部 */}
          <div className="px-3 py-2 bg-gray-100 shrink-0">
            <div className="grid grid-cols-[28px_80px_1fr_60px_50px_40px] gap-1 text-[10px] text-gray-500 font-medium">
              <span>选</span>
              <span>编码</span>
              <span>名称/型号</span>
              <span className="text-center">库存</span>
              <span className="text-center">电池</span>
              <span className="text-center">保养</span>
            </div>
          </div>

          {/* 装备列表 */}
          <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
            {filtered.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                <PackageOpen size={32} className="mx-auto mb-2" />
                <p className="text-sm">未找到匹配装备</p>
                <p className="text-xs mt-1">请调整搜索条件或分类筛选</p>
              </div>
            )}
            {filtered.map(item => {
              const isSelected = pickerSelectedIds.includes(item.id);
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setPickerSelectedIds(prev => isSelected ? prev.filter(id => id !== item.id) : [...prev, item.id]);
                  }}
                  className={`w-full rounded-xl p-3 text-left transition-all ${isSelected ? 'bg-blue-50 border-2 border-blue-300' : 'bg-white border border-gray-100 shadow-sm'}`}
                >
                  {/* 第一行：勾选 + 编码 + 名称/型号 + 库存 + 电池 + 保养 */}
                  <div className="grid grid-cols-[28px_80px_1fr_60px_50px_40px] gap-1 items-center">
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center ${isSelected ? 'bg-blue-500 border-blue-500' : 'border-gray-300'}`}>
                      {isSelected && <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5"/></svg>}
                    </div>
                    <span className="text-[10px] text-gray-500 font-mono truncate">{item.code}</span>
                    <div className="min-w-0">
                      <span className="text-xs font-medium text-gray-800 block truncate">{item.name}</span>
                      <span className="text-[10px] text-gray-400 block truncate">{item.model}</span>
                    </div>
                    <span className="text-xs text-center font-bold text-blue-600">{item.stockQty}</span>
                    <span className={`text-[10px] text-center px-1 py-0.5 rounded ${item.hasBattery ? 'bg-green-50 text-green-600' : 'bg-gray-50 text-gray-400'}`}>{item.hasBattery ? '是' : '否'}</span>
                    <span className="text-[10px] text-center text-gray-500">{item.maintenanceMonths}月</span>
                  </div>
                  {/* 第二行：分类 + 厂商 + RFID */}
                  <div className="mt-1.5 pt-1.5 border-t border-gray-100/50 flex flex-wrap gap-x-3 gap-y-0.5 text-[10px] text-gray-400">
                    <span>{item.categoryL1}/{item.categoryL2}/{item.categoryL3}</span>
                    <span>厂商：{item.manufacturer}</span>
                    <span className="font-mono">RFID：{item.rfid}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ LIST ═══════════
  if (step === 'list') {
    return (
      <MobileLayout title="出库管理" showBack rightAction={
        <button onClick={() => setStep('type-select')} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">
          新建出库
        </button>
      }>
        <div className="px-4 pt-3 pb-2 flex gap-2">
          {[
            { label: '出库记录', value: mockHistory.length, color: 'text-[#1565c0]' },
            { label: '已出库', value: mockHistory.filter(r => r.status === 'completed').length, color: 'text-green-600' },
            { label: '草稿', value: mockHistory.filter(r => r.status === 'draft').length, color: 'text-orange-600' },
          ].map(s => (
            <div key={s.label} className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="px-4 py-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {['全部', '配发出库', '调拨出库', '报修出库', '报废出库', '紧急出库', '草稿'].map(t => (
              <button
                key={t}
                onClick={() => setActiveFilter(t)}
                className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${
                  activeFilter === t ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600 shadow-sm'
                }`}
              >{t}</button>
            ))}
          </div>
        </div>

        <div className="px-4 pb-4 space-y-2 mt-2">
          {filteredRecords.map(record => (
            <button key={record.id} onClick={() => navigate(`/out/${record.id}`)} className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{record.id}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white" style={{ backgroundColor: typeColorMap[record.type] }}>{typeLabelMap[record.type]}</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${record.status === 'completed' ? 'bg-green-50 text-green-600' : record.status === 'draft' ? 'bg-gray-100 text-gray-600' : 'bg-orange-50 text-orange-600'}`}>
                  {record.status === 'completed' ? '已出库' : record.status === 'draft' ? '草稿' : '待出库'}
                </span>
              </div>

              {/* 配发出库：申请人/配发单位、调出仓库、类型、备注 */}
              {record.type === 'distribute' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-blue-50/50 rounded-lg p-2.5">
                  <div className="flex items-center justify-between">
                    <span className="flex items-center gap-1">
                      <UserCheck size={12} className="text-blue-500 shrink-0" />
                      <span className="font-medium text-blue-700">{record.applicant || '王强'}</span>
                      <span>/ {record.distributeUnit || '朝阳分局'}</span>
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${record.isBorrow ? 'bg-orange-50 text-orange-600' : 'bg-green-50 text-green-600'}`}>
                      {record.isBorrow ? '借用' : '领用'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Building2 size={12} className="text-gray-400 shrink-0" />
                    <span>调出仓库：{record.fromLocation || '省厅主仓库/主仓库1楼'}</span>
                  </div>
                  {record.remark && (
                    <div className="flex items-center gap-1">
                      <FileText size={12} className="text-gray-400 shrink-0" />
                      <span className="truncate">{record.remark}</span>
                    </div>
                  )}
                </div>
              )}

              {/* 调拨出库：发物单位、收物单位、调出仓库、申请人、备注 */}
              {record.type === 'transfer' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-purple-50/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1">
                    <ArrowLeftRight size={12} className="text-purple-500 shrink-0" />
                    <span className="font-medium text-purple-700">{record.fromUnit || '省厅主仓库'}</span>
                    <ChevronRight size={12} className="text-gray-400" />
                    <span>{record.toUnit || '香河园派出所'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-1">
                      <Building2 size={12} className="text-gray-400 shrink-0" />
                      调出：{record.fromUnit || '省厅主仓库'}
                    </span>
                    <span className="flex items-center gap-1">
                      <Truck size={12} className="text-gray-400 shrink-0" />
                      调入：{record.toUnit || '香河园派出所'}
                    </span>
                  </div>
                </div>
              )}

              {/* 报修出库：申请人、调出仓库、备注 */}
              {record.type === 'repair' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-cyan-50/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1">
                    <Wrench size={12} className="text-cyan-500 shrink-0" />
                    <span className="font-medium text-cyan-700">报修出库</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-1">
                      <UserCheck size={12} className="text-gray-400 shrink-0" />
                      申请人：{record.repairApplicant || '王强'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Building2 size={12} className="text-gray-400 shrink-0" />
                    <span>调出仓库：{record.fromLocation || '省厅主仓库/主仓库2楼'}</span>
                  </div>
                </div>
              )}

              {/* 报废出库：申请人、调出仓库、备注 */}
              {record.type === 'scrap' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-red-50/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1">
                    <AlertTriangle size={12} className="text-red-500 shrink-0" />
                    <span className="font-medium text-red-700">报废出库</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-1">
                      <UserCheck size={12} className="text-gray-400 shrink-0" />
                      申请人：{record.scrapApplicant || '张丽'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Building2 size={12} className="text-gray-400 shrink-0" />
                    <span>调出仓库：{record.fromLocation || '省厅主仓库/主仓库1楼'}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center gap-1"><Clock size={10} /> {record.createTime}</span>
                <span>共 {record.materials} 件物资</span>
              </div>
            </button>
          ))}
        </div>

        <button onClick={() => setStep('type-select')} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors"><Plus size={24} /></button>
      </MobileLayout>
    );
  }

  // ═══════════ TYPE SELECT ═══════════
  if (step === 'type-select') {
    return (
      <MobileLayout title="选择出库类型" showBack onBack={() => setStep('list')}>
        <div className="p-4 space-y-3">
          {outTypes.map(t => {
            const Icon = t.icon;
            return (
              <button key={t.key} onClick={() => handleTypeSelect(t.key)} className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${t.color}15` }}>
                  <Icon size={24} style={{ color: t.color }} />
                </div>
                <div className="flex-1">
                  <p className="text-base font-semibold text-gray-800">{t.label}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{t.desc}</p>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            );
          })}
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ APPLY LIST（系统申请列表）═══════════
  if (step === 'apply-list') {
    const applies = getApplyList();
    const typeLabels: Record<string, string> = {
      distribute: '配发出库申请', transfer: '调拨出库申请', scrap: '报废出库申请', repair: '报修出库申请',
    };
    return (
      <MobileLayout title={typeLabels[selectedType] || '系统申请'} showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
            <p className="text-xs text-blue-700">系统自动关联申请数据，请选择要出库的申请单</p>
          </div>
          <div className="space-y-2">
            {applies.map(apply => (
              <button
                key={apply.id}
                onClick={() => handleSelectApply(apply)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{apply.id}</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600">待出库</span>
                </div>
                <p className="text-sm font-medium text-gray-800 mb-1">{apply.title}</p>
                <div className="text-xs text-gray-500 space-y-0.5">
                  {apply.applicant && <p>申请人：{apply.applicant}</p>}
                  {apply.unit && <p>申请单位：{apply.unit}</p>}
                  {apply.fromUnit && <p>发物单位：{apply.fromUnit}</p>}
                  {apply.toUnit && <p>收物单位：{apply.toUnit}</p>}
                  {apply.fromLocation && <p>调出仓库：{apply.fromLocation}</p>}
                  {apply.type && <p>类型：{apply.type}</p>}
                  {apply.remark && <p className="text-gray-400 truncate">备注：{apply.remark}</p>}
                </div>
                <div className="mt-2 pt-2 border-t border-gray-50">
                  <p className="text-[10px] text-gray-400">物资：{apply.materials.map(m => `${m.name}x${m.qty}`).join('、')}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ BASIC INFO ═══════════
  if (step === 'basic-info') {
    return (
      <MobileLayout title="基本信息" showBack onBack={() => selectedType === 'emergency' ? setStep('type-select') : setStep('apply-list')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-blue-600">出库单号</p>
              <p className="text-sm font-semibold text-blue-800 font-mono">{orderNo}</p>
            </div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          {selectedTypeConfig && (
            <div className="mb-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ backgroundColor: selectedTypeConfig.color }}>
                <selectedTypeConfig.icon size={14} /> {selectedTypeConfig.label}
              </span>
            </div>
          )}

          <div className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
            {/* 紧急出库：手动填写所有字段 */}
            {selectedType === 'emergency' && (
              <>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">出库原因 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.outReason || ''} onChange={e => setBasicInfo(p => ({ ...p, outReason: e.target.value }))} placeholder="请输入出库原因" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">调出仓库 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.fromLocation || ''} onChange={e => setBasicInfo(p => ({ ...p, fromLocation: e.target.value }))} placeholder="请输入调出仓库" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">经办人 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.operator || ''} onChange={e => setBasicInfo(p => ({ ...p, operator: e.target.value }))} placeholder="请输入经办人" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">备注</label>
                  <input type="text" value={basicInfo.remark || ''} onChange={e => setBasicInfo(p => ({ ...p, remark: e.target.value }))} placeholder="选填" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
              </>
            )}

            {/* 配发出库：系统关联数据展示+编辑 */}
            {selectedType === 'distribute' && (
              <>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">申请人</label>
                  <input type="text" value={basicInfo.applicant || ''} onChange={e => setBasicInfo(p => ({ ...p, applicant: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">配发单位</label>
                  <input type="text" value={basicInfo.distributeUnit || ''} onChange={e => setBasicInfo(p => ({ ...p, distributeUnit: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">调出仓库 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.fromLocation || ''} onChange={e => setBasicInfo(p => ({ ...p, fromLocation: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">类型</label>
                  <div className="flex gap-2">
                    {['领用', '借用'].map(opt => (
                      <button key={opt} onClick={() => setBasicInfo(p => ({ ...p, isBorrow: opt === '借用' ? 'true' : 'false' }))} className={`px-4 py-2 rounded-xl text-xs transition-all ${basicInfo.isBorrow === (opt === '借用' ? 'true' : 'false') ? 'bg-blue-50 text-blue-600 border border-blue-200' : 'bg-gray-50 text-gray-600 border border-transparent'}`}>{opt}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">备注</label>
                  <input type="text" value={basicInfo.remark || ''} onChange={e => setBasicInfo(p => ({ ...p, remark: e.target.value }))} placeholder="选填" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
              </>
            )}

            {/* 调拨出库 */}
            {selectedType === 'transfer' && (
              <>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">发物单位</label>
                  <input type="text" value={basicInfo.fromUnit || ''} onChange={e => setBasicInfo(p => ({ ...p, fromUnit: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">收物单位</label>
                  <input type="text" value={basicInfo.toUnit || ''} onChange={e => setBasicInfo(p => ({ ...p, toUnit: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">调出仓库 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.fromLocation || ''} onChange={e => setBasicInfo(p => ({ ...p, fromLocation: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">申请人</label>
                  <input type="text" value={basicInfo.applicant || ''} onChange={e => setBasicInfo(p => ({ ...p, applicant: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">备注</label>
                  <input type="text" value={basicInfo.remark || ''} onChange={e => setBasicInfo(p => ({ ...p, remark: e.target.value }))} placeholder="选填" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
              </>
            )}

            {/* 报修出库 */}
            {selectedType === 'repair' && (
              <>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">申请人 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.applicant || ''} onChange={e => setBasicInfo(p => ({ ...p, applicant: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">调出仓库 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.fromLocation || ''} onChange={e => setBasicInfo(p => ({ ...p, fromLocation: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">备注</label>
                  <input type="text" value={basicInfo.remark || ''} onChange={e => setBasicInfo(p => ({ ...p, remark: e.target.value }))} placeholder="选填" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
              </>
            )}

            {/* 报废出库 */}
            {selectedType === 'scrap' && (
              <>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">申请人 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.applicant || ''} onChange={e => setBasicInfo(p => ({ ...p, applicant: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">调出仓库 <span className="text-red-500">*</span></label>
                  <input type="text" value={basicInfo.fromLocation || ''} onChange={e => setBasicInfo(p => ({ ...p, fromLocation: e.target.value }))} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">报废原因 <span className="text-red-500">*</span></label>
                  <div className="flex flex-wrap gap-2">
                    {['超期报废', '损坏报废', '技术淘汰', '其他'].map(opt => (
                      <button key={opt} onClick={() => setBasicInfo(p => ({ ...p, scrapReason: opt }))} className={`px-3 py-2 rounded-xl text-xs transition-all ${basicInfo.scrapReason === opt ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-gray-50 text-gray-600 border border-transparent'}`}>{opt}</button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">备注</label>
                  <input type="text" value={basicInfo.remark || ''} onChange={e => setBasicInfo(p => ({ ...p, remark: e.target.value }))} placeholder="选填" className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                </div>
              </>
            )}

            <div>
              <label className="text-xs text-gray-500 mb-1 block">出库时间 <span className="text-red-500">*</span></label>
              <input type="text" value={basicInfo.outTime || ''} readOnly className="w-full bg-gray-100 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none" />
            </div>
          </div>

          <button onClick={() => setStep('materials')} className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium mt-4 active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2">
            下一步：物资明细 <ArrowRight size={16} />
          </button>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ MATERIALS ═══════════
  if (step === 'materials') {
    const hasOverStock = materials.some(m => m.quantity > m.stockQty);
    return (
      <MobileLayout title="物资明细" showBack onBack={() => setStep('basic-info')}>
        <div className="p-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">扫描RFID编码或者标签</p>
                <p className="text-xs text-gray-500">扫描RFID编码或者标签自动填充信息</p>
              </div>
              <button onClick={handleScanRFID} className="px-4 py-2 bg-[#1565c0] text-white rounded-xl text-sm font-medium active:bg-blue-700 transition-colors">扫描</button>
            </div>
            {scanResult && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-2.5 flex items-center gap-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <span className="text-xs text-green-700">{scanResult}</span>
              </div>
            )}
          </div>

          {hasOverStock && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 mb-3 flex items-center gap-2">
              <AlertTriangle size={16} className="text-red-600 shrink-0" />
              <span className="text-xs text-red-700">出库数量超过库存，请减少数量</span>
            </div>
          )}

          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800">物资清单 ({materials.length})</h3>
          </div>

          <div className="space-y-3 pb-4">
            {materials.length === 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
                <PackageOpen size={32} className="mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-400">请扫描RFID编码或者标签添加装备</p>
                <button
                  onClick={addManualMaterial}
                  className="inline-flex items-center gap-1.5 px-4 py-2 mt-4 bg-blue-50 text-blue-600 rounded-xl text-xs font-medium active:bg-blue-100 transition-colors border border-blue-200"
                >
                  <Plus size={14} /> 手动添加装备
                </button>
              </div>
            )}
            {materials.map((m, idx) => (
              <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-400">物资 #{idx + 1}</span>
                  <button onClick={() => removeMaterial(m.id)} className="text-red-400 active:text-red-600 p-1"><Trash2 size={14} /></button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500">物资名称<span className="text-red-500">*</span></label>
                    <input type="text" value={m.name} onChange={e => updateMaterial(m.id, 'name', e.target.value)} placeholder="名称" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">在库数量</label>
                    <input type="number" value={m.stockQty} readOnly className="w-full bg-gray-100 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">出库数量<span className="text-red-500">*</span></label>
                    <div className="flex items-center bg-gray-50 rounded-lg">
                      <button onClick={() => updateMaterial(m.id, 'quantity', Math.max(1, m.quantity - 1))} className="px-2 py-2 active:bg-gray-200 rounded-l-lg"><Minus size={12} /></button>
                      <input type="number" value={m.quantity} onChange={e => updateMaterial(m.id, 'quantity', Number(e.target.value))} className={`w-full text-center text-xs bg-transparent outline-none py-2 ${m.quantity > m.stockQty ? 'text-red-600 font-bold' : ''}`} />
                      <button onClick={() => updateMaterial(m.id, 'quantity', m.quantity + 1)} className="px-2 py-2 active:bg-gray-200 rounded-r-lg"><Plus size={12} /></button>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">剩余数量</label>
                    <input type="number" value={m.remainQty} readOnly className={`w-full rounded-lg px-3 py-2 text-xs outline-none ${m.remainQty < 0 ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'}`} />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">装备编码</label>
                    <input type="text" value={m.equipmentCode} onChange={e => updateMaterial(m.id, 'equipmentCode', e.target.value)} placeholder="编码" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">RFID编码</label>
                    <input type="text" value={m.rfidCode} onChange={e => updateMaterial(m.id, 'rfidCode', e.target.value)} placeholder="RFID" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">存储位置</label>
                    <input type="text" value={m.fromLocation} onChange={e => updateMaterial(m.id, 'fromLocation', e.target.value)} placeholder="仓库" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">保养期</label>
                    <div className="flex gap-1.5">
                      <input type="number" value={m.maintenanceValue} onChange={e => updateMaterial(m.id, 'maintenanceValue', Number(e.target.value))} className="flex-1 bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" min={1} />
                      <select value={m.maintenanceUnit} onChange={e => updateMaterial(m.id, 'maintenanceUnit', e.target.value)} className="w-16 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-800 outline-none">
                        <option value="日">日</option>
                        <option value="月">月</option>
                        <option value="年">年</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            {/* 手动添加装备按钮 */}
            <button
              onClick={addManualMaterial}
              className="w-full flex items-center justify-center gap-1 py-2.5 border border-dashed border-gray-300 rounded-lg text-xs font-medium text-gray-500 bg-gray-50/50 active:bg-gray-100 transition-colors"
            >
              <Plus size={14} /> 手动添加装备
            </button>
          </div>

          <button onClick={() => setStep('review')} disabled={!materials.length || hasOverStock} className={`w-full py-3.5 rounded-xl font-medium transition-colors mb-6 ${materials.length && !hasOverStock ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}>
            {hasOverStock ? '数量超过库存，请修改' : '提交出库申请'}
          </button>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ REVIEW ═══════════
  if (step === 'review') {
    return (
      <MobileLayout title="确认出库" showBack onBack={() => setStep('materials')}>
        <div className="p-4">
          <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
            <Clock size={20} className="text-orange-600" />
            <div>
              <p className="text-sm font-semibold text-orange-800">待出库状态</p>
              <p className="text-xs text-orange-600">请核对信息无误后确认出库</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">出库单信息</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">出库单号</span><span className="text-xs text-gray-800 font-mono">{orderNo}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gray-500">出库类型</span><span className="text-xs text-gray-800">{selectedTypeConfig?.label}</span></div>
              {Object.entries(basicInfo).filter(([, v]) => v).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-xs text-gray-500">{
                    k === 'applicant' ? (selectedType === 'distribute' ? '申请人' : '申请人') :
                    k === 'distributeUnit' ? '配发单位' :
                    k === 'fromLocation' ? '调出仓库' :
                    k === 'isBorrow' ? '类型' :
                    k === 'fromUnit' ? '发物单位' :
                    k === 'toUnit' ? '收物单位' :
                    k === 'outReason' ? '出库原因' :
                    k === 'operator' ? '经办人' :
                    k === 'scrapReason' ? '报废原因' :
                    k === 'remark' ? '备注' :
                    k === 'outTime' ? '出库时间' : k}</span>
                  <span className="text-xs text-gray-800">{k === 'isBorrow' ? (v === 'true' ? '借用' : '领用') : v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">物资汇总</h3>
            {materials.map((m) => (
              <div key={m.id} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-700">{m.name} <span className="text-xs text-gray-400">(库存{m.stockQty})</span></span>
                <span className="text-sm text-gray-900">x{m.quantity} {m.unit}</span>
              </div>
            ))}
            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
              <span className="text-sm text-gray-600">共 {materials.length} 种，{totalQty} 件</span>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <h3 className="text-xs font-semibold text-gray-600 mb-2">业务规则</h3>
            <ul className="space-y-1">
              <li className="text-[10px] text-gray-500">1. 出库记录将永久留存，不可删除</li>
              <li className="text-[10px] text-gray-500">2. 确认出库后将同步扣减库存数据</li>
              <li className="text-[10px] text-gray-500">3. 仅在库状态装备可执行出库操作</li>
            </ul>
          </div>

          <div className="flex gap-3 mb-6">
            <button onClick={() => setStep('materials')} className="flex-1 bg-gray-100 text-gray-700 py-3.5 rounded-xl font-medium active:bg-gray-200 transition-colors">返回修改</button>
            <button onClick={() => setStep('success')} className="flex-1 bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">确认出库</button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════════════════════════════════════
  // 配发出库三步流程
  // ═══════════════════════════════════════════

  // ─── 步骤指示器组件 ───
  const DistributeStepIndicator = ({ currentStep }: { currentStep: number }) => (
    <div className="flex items-center justify-between mb-4 bg-white rounded-2xl p-3 shadow-sm">
      {flow.steps.map((label, idx) => (
        <div key={label} className="flex items-center gap-1">
          <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
            idx === currentStep ? 'bg-[#1565c0] text-white' :
            idx < currentStep ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
          }`}>{idx < currentStep ? <CheckCircle2 size={14} /> : idx + 1}</div>
          <span className={`text-[10px] ${idx === currentStep ? 'text-[#1565c0] font-medium' : idx < currentStep ? 'text-green-600' : 'text-gray-400'}`}>{label}</span>
          {idx < 2 && <ChevronRight size={14} className="text-gray-300 mx-0.5" />}
        </div>
      ))}
    </div>
  );

  // ── 三步流程文案配置 ──
  const flowLabels: Record<string, { steps: [string, string, string]; title1: string; title2: string; title3: string; dataTitle: string }> = {
    distribute: { steps: ['配发内容', '选择装备', '确认出库'], title1: '配发内容', title2: '选择出库装备', title3: '确认出库', dataTitle: '配发单信息' },
    transfer:   { steps: ['调拨内容', '选择装备', '确认出库'], title1: '调拨内容', title2: '选择出库装备', title3: '确认出库', dataTitle: '调拨单信息' },
    repair:     { steps: ['报修内容', '选择装备', '确认出库'], title1: '报修内容', title2: '选择出库装备', title3: '确认出库', dataTitle: '报修单信息' },
    scrap:      { steps: ['报废内容', '选择装备', '确认出库'], title1: '报废内容', title2: '选择出库装备', title3: '确认出库', dataTitle: '报废单信息' },
  };
  const flow = flowLabels[selectedType] || flowLabels.distribute;

  // ═══════════ 第一步：显示数据内容 ═══════════
  if (step === 'three-step1' && selectedApply) {
    return (
      <MobileLayout title={flow.title1} showBack onBack={() => setStep('apply-list')}>
        <div className="p-4">
          <DistributeStepIndicator currentStep={distributeStep} />

          {/* 配发单信息卡片 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                  <ClipboardList size={18} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-400">{selectedType === 'distribute' ? '配发单号' : selectedType === 'transfer' ? '调拨单号' : selectedType === 'repair' ? '报修单号' : '报废单号'}</p>
                  <p className="text-sm font-semibold font-mono text-gray-800">{selectedApply.id}</p>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600">待出库</span>
            </div>

            {/* 配发出库字段 */}
            {selectedType === 'distribute' && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">调出仓库</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.fromLocation || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">配发单位</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.unit || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">配发人员</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.applicant || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">类型</p>
                  <p className={`text-xs font-medium ${selectedApply.type === '借用' ? 'text-orange-600' : 'text-green-600'}`}>{selectedApply.type || '领用'}</p>
                </div>
              </div>
            )}

            {/* 调拨出库字段 */}
            {selectedType === 'transfer' && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">发物单位</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.fromUnit || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">收物单位</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.toUnit || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">调出仓库</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.fromLocation || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">申请人</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.applicant || '—'}</p>
                </div>
              </div>
            )}

            {/* 报修出库字段 */}
            {selectedType === 'repair' && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">申请人</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.applicant || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">调出仓库</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.fromLocation || '—'}</p>
                </div>
              </div>
            )}

            {/* 报废出库字段 */}
            {selectedType === 'scrap' && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">申请人</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.applicant || '—'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-2.5">
                  <p className="text-[10px] text-gray-400">调出仓库</p>
                  <p className="text-xs text-gray-800 font-medium">{selectedApply.fromLocation || '—'}</p>
                </div>
              </div>
            )}

            {selectedApply.remark && (
              <div className="mt-2 bg-gray-50 rounded-lg p-2.5">
                <p className="text-[10px] text-gray-400">备注</p>
                <p className="text-xs text-gray-800">{selectedApply.remark}</p>
              </div>
            )}
          </div>

          {/* 装备明细 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">装备明细</h3>
            <div className="space-y-2">
              {selectedApply.materials.map((m, i) => (
                <div key={i} className="bg-gray-50 rounded-lg p-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{m.name}</span>
                  </div>
                  <span className="text-sm font-bold text-blue-600">x{m.qty}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 text-right">
              <span className="text-xs text-gray-500">合计：</span>
              <span className="text-sm font-bold text-blue-600">{selectedApply.materials.reduce((s, m) => s + m.qty, 0)} 件</span>
            </div>
          </div>

          <button
            onClick={() => { setDistributeStep(1); setStep('three-step2'); }}
            className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2"
          >
            下一步：{flow.steps[1]} <ArrowRight size={16} />
          </button>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ 第二步：选择出库装备 ═══════════
  if (step === 'three-step2') {
    const hasOverStock = materials.some(m => m.quantity > m.stockQty);
    return (
      <MobileLayout title={flow.title2} showBack onBack={() => { setDistributeStep(0); setStep('three-step1'); }}>
        <div className="p-4">
          <DistributeStepIndicator currentStep={distributeStep} />

          {/* RFID扫描 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">扫描RFID编码或者标签</p>
                <p className="text-xs text-gray-500">扫描RFID编码或者标签自动填充信息</p>
              </div>
              <button onClick={handleScanRFID} className="px-4 py-2 bg-[#1565c0] text-white rounded-xl text-sm font-medium active:bg-blue-700 transition-colors">扫描</button>
            </div>
            {scanResult && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-2.5 flex items-center gap-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <span className="text-xs text-green-700">{scanResult}</span>
              </div>
            )}
          </div>

          {/* 超库存警告 */}
          {hasOverStock && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 mb-3 flex items-center gap-2">
              <AlertTriangle size={16} className="text-red-600 shrink-0" />
              <span className="text-xs text-red-700">出库数量超过库存，请减少数量</span>
            </div>
          )}

          {/* 装备清单 */}
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800">出库装备 ({materials.length})</h3>
          </div>

          <div className="space-y-3 pb-4">
            {materials.length === 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
                <PackageOpen size={32} className="mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-400">请扫描RFID编码或者标签</p>
                <p className="text-xs text-gray-400 mt-1 mb-4">或点击下方按钮手动添加装备</p>
                <button
                  onClick={addManualMaterial}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-medium active:bg-blue-100 transition-colors border border-blue-200"
                >
                  <Plus size={14} /> 手动添加装备
                </button>
              </div>
            )}
            {materials.map((m) => (
              <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-semibold text-gray-800">{m.name}</span>
                  <button onClick={() => removeMaterial(m.id)} className="text-red-400 active:text-red-600 p-1"><Trash2 size={14} /></button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500">装备名称</label>
                    <input type="text" value={m.name} onChange={e => updateMaterial(m.id, 'name', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">规格型号</label>
                    <input type="text" value={m.model} onChange={e => updateMaterial(m.id, 'model', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">装备编码</label>
                    <input type="text" value={m.equipmentCode} onChange={e => updateMaterial(m.id, 'equipmentCode', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">RFID编码</label>
                    <input type="text" value={m.rfidCode} onChange={e => updateMaterial(m.id, 'rfidCode', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">在库数量</label>
                    <input type="number" value={m.stockQty} readOnly className="w-full bg-gray-100 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">出库数量<span className="text-red-500">*</span></label>
                    <div className="flex items-center bg-gray-50 rounded-lg">
                      <button onClick={() => updateMaterial(m.id, 'quantity', Math.max(1, m.quantity - 1))} className="px-2 py-2 active:bg-gray-200 rounded-l-lg"><Minus size={12} /></button>
                      <input type="number" value={m.quantity} onChange={e => updateMaterial(m.id, 'quantity', Number(e.target.value))} className={`w-full text-center text-xs bg-transparent outline-none py-2 ${m.quantity > m.stockQty ? 'text-red-600 font-bold' : ''}`} />
                      <button onClick={() => updateMaterial(m.id, 'quantity', m.quantity + 1)} className="px-2 py-2 active:bg-gray-200 rounded-r-lg"><Plus size={12} /></button>
                    </div>
                  </div>
                  <div className="col-span-2">
                    <label className="text-[10px] text-gray-500">存储位置</label>
                    <input type="text" value={m.fromLocation} onChange={e => updateMaterial(m.id, 'fromLocation', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                </div>
              </div>
            ))}
            {/* 手动添加装备按钮 */}
            <button
              onClick={addManualMaterial}
              className="w-full flex items-center justify-center gap-1 py-2.5 border border-dashed border-gray-300 rounded-lg text-xs font-medium text-gray-500 bg-gray-50/50 active:bg-gray-100 transition-colors"
            >
              <Plus size={14} /> 手动添加装备
            </button>
          </div>

          <div className="flex gap-2">
            <button onClick={() => { setDistributeStep(0); setStep('three-step1'); }} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">上一步</button>
            <button
              onClick={() => { setDistributeStep(2); setStep('three-step3'); }}
              disabled={!materials.length || hasOverStock}
              className={`flex-1 py-3 rounded-xl font-medium text-sm transition-colors ${materials.length && !hasOverStock ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}
            >
              {hasOverStock ? '数量超过库存' : `下一步：${flow.steps[2]}`}
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ 第三步：确认出库内容 ═══════════
  if (step === 'three-step3' && selectedApply) {
    return (
      <MobileLayout title={flow.title3} showBack onBack={() => { setDistributeStep(1); setStep('three-step2'); }}>
        <div className="p-4">
          <DistributeStepIndicator currentStep={distributeStep} />

          {/* {flow.dataTitle} */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">{flow.dataTitle}</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">{selectedType === 'distribute' ? '配发单号' : selectedType === 'transfer' ? '调拨单号' : selectedType === 'repair' ? '报修单号' : '报废单号'}</span><span className="text-xs text-gray-800 font-mono">{selectedApply.id}</span></div>

              {/* 配发出库 */}
              {selectedType === 'distribute' && (<>
                <div className="flex justify-between"><span className="text-xs text-gray-500">调出仓库</span><span className="text-xs text-gray-800">{selectedApply.fromLocation}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">配发单位</span><span className="text-xs text-gray-800">{selectedApply.unit}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">配发人员</span><span className="text-xs text-gray-800">{selectedApply.applicant}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">类型</span><span className="text-xs text-gray-800">{selectedApply.type || '领用'}</span></div>
              </>)}

              {/* 调拨出库 */}
              {selectedType === 'transfer' && (<>
                <div className="flex justify-between"><span className="text-xs text-gray-500">发物单位</span><span className="text-xs text-gray-800">{selectedApply.fromUnit}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">收物单位</span><span className="text-xs text-gray-800">{selectedApply.toUnit}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">调出仓库</span><span className="text-xs text-gray-800">{selectedApply.fromLocation}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">申请人</span><span className="text-xs text-gray-800">{selectedApply.applicant}</span></div>
              </>)}

              {/* 报修出库 */}
              {selectedType === 'repair' && (<>
                <div className="flex justify-between"><span className="text-xs text-gray-500">申请人</span><span className="text-xs text-gray-800">{selectedApply.applicant}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">调出仓库</span><span className="text-xs text-gray-800">{selectedApply.fromLocation}</span></div>
              </>)}

              {/* 报废出库 */}
              {selectedType === 'scrap' && (<>
                <div className="flex justify-between"><span className="text-xs text-gray-500">申请人</span><span className="text-xs text-gray-800">{selectedApply.applicant}</span></div>
                <div className="flex justify-between"><span className="text-xs text-gray-500">调出仓库</span><span className="text-xs text-gray-800">{selectedApply.fromLocation}</span></div>
              </>)}

              {selectedApply.remark && <div className="flex justify-between"><span className="text-xs text-gray-500">备注</span><span className="text-xs text-gray-800">{selectedApply.remark}</span></div>}
            </div>
          </div>

          {/* 出库装备汇总 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">出库装备汇总</h3>
            {materials.map((m) => (
              <div key={m.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                <div>
                  <span className="text-sm text-gray-700">{m.name}</span>
                  <span className="text-xs text-gray-400 ml-1">({m.model})</span>
                </div>
                <div className="text-right">
                  <span className="text-sm text-gray-900">x{m.quantity} {m.unit}</span>
                </div>
              </div>
            ))}
            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
              <span className="text-sm text-gray-600">共 {materials.length} 种，{totalQty} 件</span>
            </div>
          </div>

          {/* 业务规则 */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <h3 className="text-xs font-semibold text-gray-600 mb-2">业务规则</h3>
            <ul className="space-y-1">
              <li className="text-[10px] text-gray-500">1. 出库记录将永久留存，不可删除</li>
              <li className="text-[10px] text-gray-500">2. 确认出库后将同步扣减库存数据</li>
              <li className="text-[10px] text-gray-500">3. 仅在库状态装备可执行出库操作</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <button onClick={() => { setDistributeStep(1); setStep('three-step2'); }} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">返回修改</button>
            <button onClick={() => setStep('success')} className="flex-1 bg-[#1565c0] text-white py-3 rounded-xl font-medium text-sm active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">确认出库</button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ═══════════ SUCCESS ═══════════
  return (
    <MobileLayout title="出库完成" showBack onBack={() => { setStep('list'); setMaterials([]); setBasicInfo({}); setSelectedApply(null); setDistributeStep(0); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">出库成功</h3>
        <p className="text-sm text-gray-500 text-center mb-6">共出库 {totalQty} 件装备，库存已扣减</p>
        <button onClick={() => { setStep('list'); setMaterials([]); setBasicInfo({}); setSelectedApply(null); setDistributeStep(0); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">返回出库列表</button>
      </div>
    </MobileLayout>
  );
}
