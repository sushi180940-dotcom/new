import { useState, useCallback, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Package, ChevronRight, ChevronDown, Plus, Trash2, CheckCircle2, Clock,
  ArrowRight, Minus, ArrowLeftRight, RotateCcw,
  Building2, QrCode, CircleDot, Search, Save, Truck, ClipboardCheck,
  Archive, Check, AlertTriangle
} from 'lucide-react';

/* ─── types ─── */
interface MaterialItem {
  id: string; name: string; category: string; model: string;
  quantity: number; productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
  unit: string; price: number; total: number;
  equipmentCode: string; rfidCode: string;
  storageLocation: string; supplier: string;
  isFixedAsset: boolean; remark: string;
  boxCode?: string;
  wholeBox?: boolean;
  deliveryQty?: number;
  actualQty?: number;
  qualifiedQty?: number;
  unqualifiedQty?: number;
  status?: string;
  inspectionRemark?: string;
}

interface InventoryRecord {
  id: string; type: string; status: 'pending' | 'completed' | 'draft';
  createTime: string; materials: number;
  // 到货验收
  deliveryNo?: string;
  orderName?: string;
  supplier?: string;
  receiver?: string;
  contractNo?: string;
  deliveryDate?: string;
  receiveAddress?: string;
  // 调拨入库
  transferNo?: string;
  fromUnit?: string;
  toUnit?: string;
  transferCount?: number;
  // 归还入库
  borrowNo?: string;
  borrower?: string;
  borrowUnit?: string;
  borrowTime?: string;
  expectedReturn?: string;
  borrowCount?: number;
}

interface DeliveryOrder {
  id: string;
  deliveryNo: string;
  orderName: string;
  supplier: string;
  contractNo?: string;
  deliveryDate: string;
  receiveAddress?: string;
  receiver: string;
  // 调拨/归还扩展字段
  fromUnit?: string;
  toUnit?: string;
  borrower?: string;
  borrowUnit?: string;
  borrowTime?: string;
  expectedReturn?: string;
  materials: MaterialItem[];
}

// 单条处置记录（行级）
interface DisposalRow {
  id: string;
  materialId: string;
  mode: 'storage' | 'deliver' | '';
  qty: number;
  warehouse: string;
  area: string;
  useUnit: string;
  useTarget: string;
}

// 附件
interface Attachment {
  id: string;
  name: string;
  url: string;
}

/* ─── static data ─── */
const inTypes = [
  { key: 'purchase', label: '到货验收', desc: '装备到货验收入库', icon: ClipboardCheck, color: '#1565c0', editable: true },
  { key: 'transfer', label: '仓库调拨入库', desc: '仓库间调拨入库', icon: ArrowLeftRight, color: '#7c4dff', editable: true },
  { key: 'return', label: '归还入库', desc: '临时领用归还入库', icon: RotateCcw, color: '#00acc1', editable: true },
  { key: 'station', label: '其他入库', desc: '其他类型入库', icon: Building2, color: '#43a047', editable: true },
];

const SUPPLIERS = ['红星装备厂', '国安器材有限公司', '盾甲科技', '警用装备中心', '中华安防集团', '雄鹰警械公司', '猎豹装备科技', '某省安防科技有限公司'];

const WAREHOUSES = [
  { name: '省厅主仓库', areas: ['主仓库1楼', '主仓库2楼', '主仓库3楼'] },
  { name: '01号装备室', areas: ['东侧区域', '西侧区域'] },
  { name: '02号装备室', areas: ['A区', 'B区'] },
  { name: '03号装备室', areas: ['一楼', '二楼'] },
];

const MAINTENANCE_UNITS = ['日', '月', '年'];

// 使用单位 + 使用对象（交付时双选）
const USE_UNIT_TARGETS = [
  { unit: '省公安厅', targets: ['省厅装备处', '省厅指挥中心', '省厅刑侦总队', '省厅交警总队'] },
  { unit: '朝阳分局', targets: ['装备管理科', '朝外派出所', '呼家楼派出所', '三里屯派出所', '东坝派出所', '劲松派出所', '香河园派出所'] },
  { unit: '海淀分局', targets: ['装备管理科', '中关村派出所', '万寿路派出所', '清河派出所'] },
  { unit: '丰台分局', targets: ['装备管理科', '方庄派出所', '大红门派出所'] },
  { unit: '直属单位', targets: ['特警支队', '交通大队', '刑警支队', '网安支队', '治安支队'] },
];

// 到货验收 - 发货单列表
const deliveryOrders: DeliveryOrder[] = [
  {
    id: 'FH20260603001',
    deliveryNo: 'FH20260603001',
    orderName: '2026年防弹背心采购订单',
    supplier: '某省安防科技有限公司',
    contractNo: 'HT-2026-001',
    deliveryDate: '2026-06-03',
    receiveAddress: 'XXX省公安厅装备处',
    receiver: '张伟',
    materials: [
      { id: '1', name: '防弹背心', category: '防护装备', model: 'FD-BX-III', equipmentCode: 'ZB-001-001', unit: '件', wholeBox: true, boxCode: 'BX-202606-001', rfidCode: '共50个', quantity: 200, deliveryQty: 50, price: 1200, total: 60000, productionDate: '2026-03-15', expiryDate: '2031-03-14', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 50, qualifiedQty: 50, unqualifiedQty: 0, status: '全部合格' },
      { id: '2', name: '手铐', category: '械具', model: 'SK-STD', equipmentCode: 'ZB-002-001', unit: '副', wholeBox: true, boxCode: 'BX-202606-002', rfidCode: '共100个', quantity: 500, deliveryQty: 100, price: 85, total: 8500, productionDate: '2026-02-20', expiryDate: '2036-02-19', maintenanceValue: 5, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 100, qualifiedQty: 100, unqualifiedQty: 0, status: '全部合格' },
      { id: '3', name: '执法记录仪', category: '记录设备', model: 'DSJ-A7', equipmentCode: 'ZB-003-001', unit: '台', wholeBox: false, boxCode: '-', rfidCode: '共30个', quantity: 150, deliveryQty: 30, price: 2800, total: 84000, productionDate: '2026-04-01', expiryDate: '2029-03-31', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 30, qualifiedQty: 30, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
  {
    id: 'FH20260602001',
    deliveryNo: 'FH20260602001',
    orderName: '2026年通讯设备采购订单',
    supplier: '国安器材有限公司',
    contractNo: 'HT-2026-002',
    deliveryDate: '2026-06-02',
    receiveAddress: 'XXX省公安厅装备处',
    receiver: '李建国',
    materials: [
      { id: '4', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', equipmentCode: 'ZB-004-001', unit: '台', wholeBox: true, boxCode: 'BX-202606-003', rfidCode: '共20个', quantity: 100, deliveryQty: 20, price: 650, total: 13000, productionDate: '2026-03-01', expiryDate: '2028-03-01', maintenanceValue: 2, maintenanceUnit: '年', storageLocation: '', supplier: '国安器材有限公司', isFixedAsset: true, remark: '', actualQty: 20, qualifiedQty: 20, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
];

// 调拨单数据
const transferOrders: DeliveryOrder[] = [
  {
    id: 'DB20240615001',
    deliveryNo: 'DB20240615001',
    orderName: '东坝派出所调拨至省厅',
    supplier: '东坝派出所',
    deliveryDate: '2026-06-15',
    receiver: '省厅装备处',
    fromUnit: '东坝派出所',
    toUnit: '省厅主仓库',
    materials: [
      { id: 't1', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', equipmentCode: 'ZB-004-001', unit: '台', wholeBox: false, boxCode: '-', rfidCode: '共5个', quantity: 5, deliveryQty: 5, price: 650, total: 3250, productionDate: '2026-03-01', expiryDate: '2028-03-01', maintenanceValue: 2, maintenanceUnit: '年', storageLocation: '', supplier: '国安器材有限公司', isFixedAsset: true, remark: '', actualQty: 5, qualifiedQty: 5, unqualifiedQty: 0, status: '全部合格' },
      { id: 't2', name: '执法记录仪', category: '记录设备', model: 'DSJ-A7', equipmentCode: 'ZB-003-001', unit: '台', wholeBox: false, boxCode: '-', rfidCode: '共3个', quantity: 3, deliveryQty: 3, price: 2800, total: 8400, productionDate: '2026-04-01', expiryDate: '2029-03-31', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 3, qualifiedQty: 3, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
  {
    id: 'DB20240614001',
    deliveryNo: 'DB20240614001',
    orderName: '劲松派出所调拨至省厅',
    supplier: '劲松派出所',
    deliveryDate: '2026-06-14',
    receiver: '省厅装备处',
    fromUnit: '劲松派出所',
    toUnit: '省厅主仓库',
    materials: [
      { id: 't3', name: '防弹背心', category: '防护装备', model: 'FD-BX-III', equipmentCode: 'ZB-001-001', unit: '件', wholeBox: false, boxCode: '-', rfidCode: '共2个', quantity: 2, deliveryQty: 2, price: 1200, total: 2400, productionDate: '2026-03-15', expiryDate: '2031-03-14', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 2, qualifiedQty: 2, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
];

// 归还单数据
const returnOrders: DeliveryOrder[] = [
  {
    id: 'GH20240610001',
    deliveryNo: 'GH20240610001',
    orderName: '王强归还借用装备',
    supplier: '朝阳分局',
    deliveryDate: '2026-06-10',
    receiver: '省厅装备处',
    borrower: '王强',
    borrowUnit: '朝阳分局',
    borrowTime: '2026-04-15',
    expectedReturn: '2026-06-15',
    materials: [
      { id: 'r1', name: '防弹背心', category: '防护装备', model: 'FD-BX-III', equipmentCode: 'ZB-001-001', unit: '件', wholeBox: false, boxCode: '-', rfidCode: '共2个', quantity: 2, deliveryQty: 2, price: 1200, total: 2400, productionDate: '2026-03-15', expiryDate: '2031-03-14', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '某省安防科技有限公司', isFixedAsset: true, remark: '', actualQty: 2, qualifiedQty: 2, unqualifiedQty: 0, status: '全部合格' },
      { id: 'r2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', equipmentCode: 'ZB-005-001', unit: '个', wholeBox: false, boxCode: '-', rfidCode: '共1个', quantity: 1, deliveryQty: 1, price: 280, total: 280, productionDate: '2026-02-20', expiryDate: '2029-02-19', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '红星装备厂', isFixedAsset: true, remark: '', actualQty: 1, qualifiedQty: 1, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
  {
    id: 'GH20240608001',
    deliveryNo: 'GH20240608001',
    orderName: '李明归还借用装备',
    supplier: '东坝派出所',
    deliveryDate: '2026-06-08',
    receiver: '省厅装备处',
    borrower: '李明',
    borrowUnit: '东坝派出所',
    borrowTime: '2026-03-20',
    expectedReturn: '2026-06-20',
    materials: [
      { id: 'r3', name: '警用盾牌', category: '防护装备', model: 'JYP-800-B', equipmentCode: 'ZB-006-001', unit: '件', wholeBox: false, boxCode: '-', rfidCode: '共1个', quantity: 1, deliveryQty: 1, price: 450, total: 450, productionDate: '2026-01-15', expiryDate: '2031-01-14', maintenanceValue: 3, maintenanceUnit: '年', storageLocation: '', supplier: '国安器材有限公司', isFixedAsset: true, remark: '', actualQty: 1, qualifiedQty: 1, unqualifiedQty: 0, status: '全部合格' },
    ],
  },
];

const mockHistory: InventoryRecord[] = [
  { id: 'RK20240520001', type: 'purchase', status: 'completed', createTime: '2024-05-20 10:30', materials: 12, deliveryNo: 'FH20260603001', orderName: '2026年防弹背心采购订单', supplier: '某省安防科技有限公司', receiver: '张伟' },
  { id: 'RK20240520002', type: 'purchase', status: 'draft', createTime: '2024-05-20 09:00', materials: 3, deliveryNo: 'FH20260602001', orderName: '2026年通讯设备采购订单', supplier: '国安器材有限公司', receiver: '李建国' },
  { id: 'RK20240519002', type: 'transfer', status: 'completed', createTime: '2024-05-19 14:20', materials: 5, transferNo: 'DB20240519001', fromUnit: '东坝派出所', toUnit: '省厅主仓库', transferCount: 5 },
  { id: 'RK20240518003', type: 'return', status: 'pending', createTime: '2024-05-18 09:15', materials: 3, borrowNo: 'JY20240518001', borrower: '王强', borrowUnit: '朝阳分局', borrowTime: '2024-04-15', expectedReturn: '2024-05-15', borrowCount: 3 },
  { id: 'RK20240517004', type: 'station', status: 'completed', createTime: '2024-05-17 16:00', materials: 8 },
  { id: 'RK20240516005', type: 'purchase', status: 'completed', createTime: '2024-05-16 11:30', materials: 15, deliveryNo: 'FH20260515001', orderName: '2026年防护装备采购订单', supplier: '红星装备厂', receiver: '王强' },
  { id: 'RK20240515006', type: 'return', status: 'completed', createTime: '2024-05-15 08:45', materials: 2, borrowNo: 'JY20240515001', borrower: '李明', borrowUnit: '东坝派出所', borrowTime: '2024-03-20', expectedReturn: '2024-05-20', borrowCount: 2 },
];

// Auto-fetch mock data
interface AutoFetchItem {
  id: string;
  count: number;
  materials: MaterialItem[];
  [key: string]: unknown;
}

const transferList: AutoFetchItem[] = [
  { id: 'DB20240519001', fromUnit: '东坝派出所', toUnit: '省厅主仓库', count: 5, status: 'pending', createTime: '2024-05-19 10:00', materials: [{ name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 5, unit: '台', rfidCode: 'RFID202405010A~E', equipmentCode: 'EQ202405010', storageLocation: '省厅主仓库/主仓库2楼', supplier: '国安器材', price: 650, total: 3250, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
  { id: 'DB20240518002', fromUnit: '劲松派出所', toUnit: '省厅主仓库', count: 3, status: 'pending', createTime: '2024-05-18 14:30', materials: [{ name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 3, unit: '台', rfidCode: 'RFID202405011A~C', equipmentCode: 'EQ202405011', storageLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', price: 1800, total: 5400, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
];

const returnList: AutoFetchItem[] = [
  { id: 'GH20240518001', borrower: '王强', borrowUnit: '朝阳分局', borrowTime: '2024-04-15', expectedReturn: '2024-05-15', actualReturn: '2024-05-18', count: 2, materials: [{ name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', rfidCode: 'RFID202403001A', equipmentCode: 'EQ202403001', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', price: 1200, total: 1200, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }, { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', rfidCode: 'RFID202403002B', equipmentCode: 'EQ202403002', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', price: 280, total: 280, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
  { id: 'GH20240517002', borrower: '李明', borrowUnit: '东坝派出所', borrowTime: '2024-03-20', expectedReturn: '2024-05-20', actualReturn: '2024-05-17', count: 1, materials: [{ name: '警用盾牌', category: '防护装备', model: 'JYP-800-B', quantity: 1, unit: '件', rfidCode: 'RFID202403005A', equipmentCode: 'EQ202403005', storageLocation: '02号装备室/A区', supplier: '国安器材', price: 450, total: 450, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
];

const typeLabelMap: Record<string, string> = { purchase: '到货验收', transfer: '调拨入库', return: '归还入库', station: '其他入库' };
const typeColorMap: Record<string, string> = { purchase: '#1565c0', transfer: '#7c4dff', return: '#00acc1', station: '#43a047' };

function genOrderNo() {
  const d = new Date();
  return `RK${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`;
}

function emptyMaterial(storage = '', supplier = ''): MaterialItem {
  return {
    id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
    name: '', category: '', model: '', quantity: 1,
    productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年',
    unit: '件', price: 0, total: 0, equipmentCode: '', rfidCode: '',
    storageLocation: storage, supplier, isFixedAsset: false, remark: '',
  };
}

/* ─── component ─── */
export default function InInventory() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'type-select' | 'auto-fetch' | 'basic-info' | 'materials' | 'review' | 'success' | 'arrival-content' | 'arrival-inspection' | 'arrival-disposal'>('list');
  const [selectedType, setSelectedType] = useState('');
  const [orderNo, setOrderNo] = useState('');
  const [basicInfo, setBasicInfo] = useState<Record<string, string>>({});
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('全部');
  const [records, setRecords] = useState(mockHistory);
  const [savedDraft, setSavedDraft] = useState(false);

  // 到货验收专用状态
  const [selectedDelivery, setSelectedDelivery] = useState<DeliveryOrder | null>(null);
  const [inspectionStep, setInspectionStep] = useState(0); // 0:发货内容 1:到货验收 2:到货处置
  const [receiver, setReceiver] = useState('');
  const [receiveTime, setReceiveTime] = useState('');
  const [inspectionMaterials, setInspectionMaterials] = useState<MaterialItem[]>([]);
  // 处置：行级记录（每种装备可有多行）
  const [disposalRows, setDisposalRows] = useState<DisposalRow[]>([]);
  // 附件
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  // 未处置弹窗
  const [showUndisposedModal, setShowUndisposedModal] = useState(false);
  const [undisposedCount, setUndisposedCount] = useState(0);

  // Supplier search
  const [supplierQuery, setSupplierQuery] = useState('');
  const [showSupplierList, setShowSupplierList] = useState(false);
  const supplierRef = useRef<HTMLDivElement>(null);
  const filteredSuppliers = SUPPLIERS.filter(s => s.toLowerCase().includes(supplierQuery.toLowerCase()));

  // Warehouse cascade
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const [selectedArea, setSelectedArea] = useState('');

  const typeConfig = inTypes.find(t => t.key === selectedType);
  const isEditable = typeConfig?.editable ?? true;

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (supplierRef.current && !supplierRef.current.contains(e.target as Node)) {
        setShowSupplierList(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  /* ─── actions ─── */
  const handleTypeSelect = (typeKey: string) => {
    setSelectedType(typeKey);
    setStep('arrival-content');
    setInspectionStep(0);
    setSelectedDelivery(null);
    setReceiver('');
    setReceiveTime(new Date().toLocaleString('zh-CN'));
    setDisposalRows([]);
    setAttachments([]);
  };

  const handleSelectDelivery = (delivery: DeliveryOrder) => {
    setSelectedDelivery(delivery);
    setOrderNo(genOrderNo());
    setInspectionMaterials(delivery.materials.map(m => ({ ...m })));
    setBasicInfo({
      inTime: new Date().toLocaleString('zh-CN'),
      deliveryNo: delivery.deliveryNo,
      orderName: delivery.orderName,
      supplier: delivery.supplier,
      contractNo: delivery.contractNo || '',
      deliveryDate: delivery.deliveryDate,
      receiveAddress: delivery.receiveAddress || '',
      receiver: delivery.receiver,
      fromUnit: delivery.fromUnit || '',
      toUnit: delivery.toUnit || '',
      borrower: delivery.borrower || '',
      borrowUnit: delivery.borrowUnit || '',
      borrowTime: delivery.borrowTime || '',
      expectedReturn: delivery.expectedReturn || '',
    });
    setDisposalRows([]);
  };

  const handleSelectAutoItem = (item: AutoFetchItem) => {
    setOrderNo(genOrderNo());
    setMaterials(item.materials.map(m => ({
      ...emptyMaterial(m.storageLocation, m.supplier),
      ...m, id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
      maintenanceValue: 3, maintenanceUnit: '年',
    })));
    setBasicInfo({
      inTime: new Date().toLocaleString('zh-CN'),
      ...(selectedType === 'transfer' ? {
        transferNo: item.id, fromUnit: String(item.fromUnit || ''),
        storageLocation: item.materials[0]?.storageLocation || '',
        transferCount: String(item.count), operator: '',
      } : {
        borrower: String(item.borrower || ''), borrowTime: String(item.borrowTime || ''),
        expectedReturn: String(item.expectedReturn || ''),
        borrowCount: String(item.count), operator: '',
      }),
    });
    setStep('review');
  };

  // ── 三步流程文案配置 ──
  const flowLabels: Record<string, { steps: string[]; title: string; step2Title: string; receiverLabel: string; confirmLabel: string; sourceLabel: string; actualLabel: string }> = {
    purchase: { steps: ['发货内容', '到货验收', '到货处置'], title: '到货验收', step2Title: '收货信息', receiverLabel: '收货人', confirmLabel: '确认验收', sourceLabel: '本次发货', actualLabel: '实际到货' },
    transfer: { steps: ['调拨内容', '调拨验收', '调拨处置'], title: '调拨入库', step2Title: '验收信息', receiverLabel: '验收人', confirmLabel: '确认调拨', sourceLabel: '本次调拨', actualLabel: '实际到货' },
    return:   { steps: ['归还内容', '归还验收', '归还处置'], title: '归还入库', step2Title: '验收信息', receiverLabel: '验收人', confirmLabel: '确认归还', sourceLabel: '本次归还', actualLabel: '实际归还' },
  };
  const flow = flowLabels[selectedType] || flowLabels.purchase;

  // ── 数据源选择 ──
  const sourceOrders = selectedType === 'purchase' ? deliveryOrders : selectedType === 'transfer' ? transferOrders : returnOrders;

  const handleScanRFID = useCallback(() => {
    const names = ['执法记录仪', '防弹背心', '战术手电', '对讲机', '防刺手套'];
    const mockName = names[Math.floor(Math.random() * names.length)];
    const mockRFID = `RFID${Date.now().toString(36).toUpperCase()}`;

    setMaterials(prev => {
      const existing = prev.find(m => m.name === mockName);
      if (existing) {
        return prev.map(m => m.name === mockName
          ? { ...m, quantity: m.quantity + 1, rfidCode: `${m.rfidCode}, ${mockRFID}`, total: (m.quantity + 1) * m.price }
          : m
        );
      }
      const loc = selectedArea ? `${selectedWarehouse}/${selectedArea}` : basicInfo.storageLocation || '';
      return [...prev, {
        ...emptyMaterial(loc, basicInfo.supplier || ''),
        name: mockName, category: '防护装备', model: 'XZ-2024-A',
        rfidCode: mockRFID, equipmentCode: `EQ${Date.now().toString(36).toUpperCase()}`,
        storageLocation: loc, supplier: basicInfo.supplier || '',
      }];
    });
    setScanResult(`已扫描：${mockRFID} · ${mockName}`);
    setTimeout(() => setScanResult(null), 3000);
  }, [basicInfo.supplier, basicInfo.storageLocation, selectedWarehouse, selectedArea]);

  const updateMaterial = (id: string, field: keyof MaterialItem, value: unknown) => {
    setMaterials(prev => prev.map(m => {
      if (m.id !== id) return m;
      const updated = { ...m, [field]: value };
      if (field === 'quantity' || field === 'price') {
        updated.total = Number(updated.quantity) * Number(updated.price);
      }
      return updated;
    }));
  };

  // 到货验收中更新实际到货数量
  const updateInspectionMaterial = (id: string, field: keyof MaterialItem, value: unknown) => {
    setInspectionMaterials(prev => prev.map(m => {
      if (m.id !== id) return m;
      const updated = { ...m, [field]: value };
      if (field === 'actualQty') {
        const actual = Number(value) || 0;
        const delivery = m.deliveryQty || 0;
        updated.qualifiedQty = actual;
        updated.unqualifiedQty = Math.max(0, delivery - actual);
        updated.status = actual >= delivery ? '全部合格' : actual > 0 ? '部分合格' : '不合格';
      }
      if (field === 'qualifiedQty') {
        const qualified = Number(value) || 0;
        const actual = m.actualQty || 0;
        updated.unqualifiedQty = Math.max(0, actual - qualified);
        updated.status = qualified >= actual ? '全部合格' : qualified > 0 ? '部分合格' : '不合格';
      }
      return updated;
    }));
  };

  const removeMaterial = (id: string) => setMaterials(prev => prev.filter(m => m.id !== id));

  const addManualMaterial = () => {
    const loc = selectedArea ? `${selectedWarehouse}/${selectedArea}` : basicInfo.storageLocation || '';
    setMaterials(prev => [...prev, emptyMaterial(loc, basicInfo.supplier || '')]);
  };

  const handleSaveDraft = () => {
    setSavedDraft(true);
    setRecords(prev => [{ id: orderNo, type: selectedType, status: 'draft', createTime: new Date().toLocaleString('zh-CN'), materials: materials.length }, ...prev]);
    setTimeout(() => {
      setStep('list');
      setMaterials([]);
      setBasicInfo({});
      setSavedDraft(false);
    }, 1500);
  };

  // 确认到货验收
  const handleConfirmInspection = () => {
    setInspectionStep(2);
  };

  // 确认处置
  const handleConfirmDisposal = () => {
    const qualifiedMaterials = inspectionMaterials.filter(m => (m.qualifiedQty || 0) > 0);
    // 统计未处置装备数量（已入库+已交付 < 合格数）
    const undisposedTotal = qualifiedMaterials.reduce((sum, m) => {
      const materialRows = disposalRows.filter(r => r.materialId === m.id);
      const disposedQty = materialRows.reduce((s, r) => s + (r.qty || 0), 0);
      return sum + Math.max(0, (m.qualifiedQty || 0) - disposedQty);
    }, 0);

    if (undisposedTotal > 0 && !showUndisposedModal) {
      // 首次确认且存在未处置装备 → 弹窗提示
      setUndisposedCount(undisposedTotal);
      setShowUndisposedModal(true);
      return;
    }

    // 关闭弹窗标记
    setShowUndisposedModal(false);
    setUndisposedCount(0);

    setRecords(prev => [{
      id: orderNo,
      type: 'purchase',
      status: 'completed',
      createTime: new Date().toLocaleString('zh-CN'),
      materials: inspectionMaterials.length,
      deliveryNo: selectedDelivery?.deliveryNo,
      orderName: selectedDelivery?.orderName,
      supplier: selectedDelivery?.supplier,
      receiver: receiver || selectedDelivery?.receiver,
    }, ...prev]);
    setStep('success');
  };

  const totalQty = materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = materials.reduce((s, m) => s + m.total, 0);

  const filteredRecords = activeFilter === '全部' ? records : activeFilter === '草稿'
    ? records.filter(r => r.status === 'draft')
    : records.filter(r => typeLabelMap[r.type] === activeFilter || (activeFilter === '待入库' && r.status === 'pending'));

  /* ═══════════ STEP: LIST ═══════════ */
  if (step === 'list') {
    return (
      <MobileLayout title="入库管理" showBack rightAction={
        <button onClick={() => setStep('type-select')} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">
          新建入库
        </button>
      }>
        <div className="px-4 pt-3 pb-2 flex gap-2">
          {[
            { label: '入库记录', value: records.length, color: 'text-[#1565c0]' },
            { label: '已入库', value: records.filter(r => r.status === 'completed').length, color: 'text-green-600' },
            { label: '草稿', value: records.filter(r => r.status === 'draft').length, color: 'text-orange-600' },
          ].map(s => (
            <div key={s.label} className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="px-4 py-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {['全部', '到货验收', '调拨入库', '归还入库', '其他入库', '草稿'].map(t => (
              <button
                key={t}
                onClick={() => setActiveFilter(t)}
                className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${
                  activeFilter === t ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600 shadow-sm'
                }`}
              >{t}</button>
            ))}
          </div>
        </div>

        <div className="px-4 pb-4 space-y-2">
          {filteredRecords.map(r => (
            <button
              key={r.id}
              onClick={() => navigate(`/in/${r.id}`)}
              className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{r.id}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white" style={{ backgroundColor: typeColorMap[r.type] }}>
                    {typeLabelMap[r.type]}
                  </span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  r.status === 'completed' ? 'bg-green-50 text-green-600' :
                  r.status === 'draft' ? 'bg-gray-100 text-gray-600' :
                  'bg-orange-50 text-orange-600'
                }`}>
                  {r.status === 'completed' ? '已入库' : r.status === 'draft' ? '草稿' : '待入库'}
                </span>
              </div>
              {/* 到货验收：发货单号、订单名称、供应商、收货对象 */}
              {r.type === 'purchase' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-blue-50/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1">
                    <Truck size={12} className="text-blue-500 shrink-0" />
                    <span className="font-medium text-blue-700">发货单号：{r.deliveryNo || 'FH20260603001'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Package size={12} className="text-gray-400 shrink-0" />
                    <span className="truncate">{r.orderName || '2026年防弹背心采购订单'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-1">
                      <Building2 size={12} className="text-gray-400 shrink-0" />
                      {r.supplier || '某省安防科技有限公司'}
                    </span>
                    <span className="flex items-center gap-1">
                      <ClipboardCheck size={12} className="text-gray-400 shrink-0" />
                      收货：{r.receiver || '张伟'}
                    </span>
                  </div>
                </div>
              )}
              {/* 调拨入库：调拨单号、发物单位、调拨数量 */}
              {r.type === 'transfer' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-purple-50/50 rounded-lg p-2.5">
                  <div className="flex items-center gap-1">
                    <ArrowLeftRight size={12} className="text-purple-500 shrink-0" />
                    <span className="font-medium text-purple-700">调拨单号：{r.transferNo || 'DB20240519001'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Building2 size={12} className="text-gray-400 shrink-0" />
                    <span>发物单位：{r.fromUnit || '东坝派出所'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Package size={12} className="text-gray-400 shrink-0" />
                    <span>调拨数量：{r.transferCount || r.materials} 件</span>
                  </div>
                </div>
              )}
              {/* 归还入库：借用人、借用时间、预计归还、借用单号、借用数量 */}
              {r.type === 'return' && (
                <div className="text-xs text-gray-500 space-y-1 mb-2 bg-cyan-50/50 rounded-lg p-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1">
                      <RotateCcw size={12} className="text-cyan-500 shrink-0" />
                      <span className="font-medium text-cyan-700">借用单号：{r.borrowNo || 'JY20240518001'}</span>
                    </div>
                    <span className="flex items-center gap-1">
                      <Package size={12} className="text-gray-400 shrink-0" />
                      借用 {r.borrowCount || r.materials} 件
                    </span>
                  </div>
                  <div className="flex items-center gap-1">
                    <ClipboardCheck size={12} className="text-gray-400 shrink-0" />
                    <span>借用人：{r.borrower || '王强'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="flex items-center gap-1">
                      <Clock size={12} className="text-gray-400 shrink-0" />
                      借用：{r.borrowTime || '2024-04-15'}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock size={12} className="text-gray-400 shrink-0" />
                      预计归还：{r.expectedReturn || '2024-05-15'}
                    </span>
                  </div>
                </div>
              )}
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center gap-1"><Clock size={10} /> {r.createTime}</span>
                <span>共 {r.materials} 件物资</span>
              </div>
            </button>
          ))}
        </div>

        <button onClick={() => setStep('type-select')} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors">
          <Plus size={24} />
        </button>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: TYPE SELECT ═══════════ */
  if (step === 'type-select') {
    return (
      <MobileLayout title="选择入库类型" showBack onBack={() => setStep('list')}>
        <div className="p-4 space-y-3">
          {inTypes.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                onClick={() => handleTypeSelect(t.key)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${t.color}15` }}>
                  <Icon size={24} style={{ color: t.color }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-base font-semibold text-gray-800">{t.label}</p>
                    {!t.editable && <span className="px-1.5 py-0.5 bg-purple-50 text-purple-600 rounded text-[10px] font-medium">系统自动</span>}
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{t.desc}</p>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            );
          })}
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: AUTO FETCH ═══════════ */
  if (step === 'auto-fetch') {
    const isTransfer = selectedType === 'transfer';
    const list = isTransfer ? transferList : returnList;
    return (
      <MobileLayout title={isTransfer ? '选择调拨单' : '选择借用记录'} showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 mb-3">
            <p className="text-xs text-purple-700">
              {isTransfer
                ? '系统已自动获取待确认的调拨单，请选择要入库的调拨单'
                : '系统已自动获取待归还的借用记录，请选择要入库的记录'}
            </p>
          </div>
          <div className="space-y-2">
            {list.map(item => (
              <button
                key={item.id}
                onClick={() => handleSelectAutoItem(item)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{item.id}</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600">
                    待确认
                  </span>
                </div>
                {isTransfer ? (
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>发物单位：{String(item.fromUnit || '')}</p>
                    <p>调入单位：{String(item.toUnit || '')}</p>
                    <p>调拨数量：{item.count} 件</p>
                  </div>
                ) : (
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>借用人：{String(item.borrower || '')}</p>
                    <p>借用单位：{String(item.borrowUnit || '')}</p>
                    <p>借用时间：{String(item.borrowTime || '')}</p>
                    <p>归还数量：{item.count} 件</p>
                  </div>
                )}
                <div className="mt-2 pt-2 border-t border-gray-50">
                  <p className="text-[10px] text-gray-400">物资：{item.materials.map(m => `${m.name}x${m.quantity}`).join('、')}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ════════════════════ 到货验收三步流程 ════════════════════ */

  /* ─── STEP 1: 发货内容 ─── */
  if (step === 'arrival-content' && inspectionStep === 0) {
    return (
      <MobileLayout title={flow.title} showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          {/* 步骤指示器 */}
          <div className="flex items-center justify-between mb-4 bg-white rounded-2xl p-3 shadow-sm">
            {flow.steps.map((label, idx) => (
              <div key={label} className="flex items-center gap-1">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  idx === 0 ? 'bg-[#1565c0] text-white' : 'bg-gray-200 text-gray-400'
                }`}>{idx + 1}</div>
                <span className={`text-[10px] ${idx === 0 ? 'text-[#1565c0] font-medium' : 'text-gray-400'}`}>{label}</span>
                {idx < 2 && <ChevronRight size={14} className="text-gray-300 mx-0.5" />}
              </div>
            ))}
          </div>

          {!selectedDelivery ? (
            /* 发货单列表 */
            <>
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
                <p className="text-xs text-blue-700">请选择待确认的{selectedType === "purchase" ? "发货单" : selectedType === "transfer" ? "调拨单" : "归还单"}</p>
              </div>
              <div className="space-y-2">
                {sourceOrders.map(delivery => (
                  <button
                    key={delivery.id}
                    onClick={() => handleSelectDelivery(delivery)}
                    className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <Truck size={16} className="text-blue-600" />
                        <span className="text-sm font-semibold text-gray-800 font-mono">{delivery.deliveryNo}</span>
                      </div>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600">待确认</span>
                    </div>
                    <div className="text-xs text-gray-500 space-y-1.5">
                      <div className="flex items-start gap-2">
                        <span className="text-gray-400 shrink-0">{selectedType === "purchase" ? "订单名称" : "名称"}：</span>
                        <span className="font-medium text-gray-700">{delivery.orderName}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400">{selectedType === "purchase" ? "供应商" : selectedType === "transfer" ? "发物单位" : "借用单位"}：</span>
                        <span>{delivery.supplier}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-gray-400">{selectedType === "purchase" ? "收货对象" : selectedType === "transfer" ? "调入单位" : "借用人"}：</span>
                        <span>{selectedType === "return" && delivery.borrower ? delivery.borrower : delivery.receiver}</span>
                      </div>
                      {selectedType === 'purchase' && delivery.contractNo && (
                        <div className="flex items-center gap-2">
                          <span className="text-gray-400">合同号：</span>
                          <span className="font-mono text-blue-600">{delivery.contractNo}</span>
                        </div>
                      )}
                    </div>
                    <div className="mt-2 pt-2 border-t border-gray-50 flex justify-between text-[10px] text-gray-400">
                      <span>预计{selectedType === "purchase" ? "送货" : selectedType === "transfer" ? "调拨" : "归还"}：{delivery.deliveryDate}</span>
                      <span>{delivery.materials.length} 种装备</span>
                    </div>
                  </button>
                ))}
              </div>
            </>
          ) : (
            /* 发货内容详情 */
            <>
              {/* 发货单信息卡片 */}
              <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center">
                      <Truck size={18} className="text-blue-600" />
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">{selectedType === "purchase" ? "发货单号" : selectedType === "transfer" ? "调拨单号" : "归还单号"}</p>
                      <p className="text-sm font-semibold font-mono text-gray-800">{selectedDelivery.deliveryNo}</p>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-[10px] text-gray-400">{selectedType === "purchase" ? "供应商" : selectedType === "transfer" ? "发物单位" : "借用单位"}</p>
                    <p className="text-xs text-gray-800 font-medium">{selectedDelivery.supplier}</p>
                  </div>
                  {selectedType === 'purchase' && selectedDelivery?.contractNo && (
                    <div className="bg-gray-50 rounded-lg p-2.5">
                      <p className="text-[10px] text-gray-400">关联合同</p>
                      <p className="text-xs text-blue-600 font-medium font-mono">{selectedDelivery.contractNo}</p>
                    </div>
                  )}
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-[10px] text-gray-400">{selectedType === "purchase" ? "订单名称" : "名称"}</p>
                    <p className="text-xs text-gray-800 font-medium">{selectedDelivery.orderName}</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-2.5">
                    <p className="text-[10px] text-gray-400">{selectedType === "purchase" ? "预计送货日期" : "日期"}</p>
                    <p className="text-xs text-gray-800 font-medium">{selectedDelivery.deliveryDate}</p>
                  </div>
                </div>
                {selectedType === 'purchase' && selectedDelivery?.receiveAddress && (
                  <div className="mt-2 bg-blue-50/50 rounded-lg p-2.5 flex items-center gap-2">
                    <Archive size={12} className="text-blue-500" />
                    <span className="text-xs text-blue-700">收货地址：{selectedDelivery.receiveAddress}</span>
                  </div>
                )}
              </div>

              {/* 发货装备清单 */}
              <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
                <h3 className="text-sm font-semibold text-gray-800 mb-3">{selectedType === "purchase" ? "发货" : selectedType === "transfer" ? "调拨" : "归还"}装备清单</h3>
                <div className="space-y-3">
                  {selectedDelivery.materials.map((m, i) => (
                    <div key={m.id} className="bg-gray-50 rounded-xl p-3">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-gray-400">#{i + 1}</span>
                          <span className="text-sm font-medium text-gray-800">{m.name}</span>
                        </div>
                        <span className="text-sm font-bold text-[#1565c0]">¥{m.total.toLocaleString()}</span>
                      </div>
                      <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px] text-gray-500">
                        <span>型号：{m.model}</span>
                        <span>装备编码：{m.equipmentCode}</span>
                        <span>单位：{m.unit}</span>
                        <span>整箱：{m.wholeBox ? '是' : '否'}</span>
                        <span>箱体码：{m.boxCode}</span>
                        <span>发货RFID：{m.rfidCode}</span>
                        <span>采购数量：{m.quantity}</span>
                        <span>本次发货：{m.deliveryQty}</span>
                        <span>单价：¥{m.price.toLocaleString()}</span>
                        <span>金额：¥{m.total.toLocaleString()}</span>
                        <span>生产日期：{m.productionDate}</span>
                        <span>有效期至：{m.expiryDate}</span>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-3 pt-3 border-t border-gray-100 text-right">
                  <span className="text-xs text-gray-500">合计金额：</span>
                  <span className="text-lg font-bold text-[#1565c0]">¥{selectedDelivery.materials.reduce((s, m) => s + m.total, 0).toLocaleString()}</span>
                </div>
              </div>

              <button
                onClick={() => setInspectionStep(1)}
                className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2"
              >
                下一步：{flow.steps[1]} <ArrowRight size={16} />
              </button>
            </>
          )}
        </div>
      </MobileLayout>
    );
  }

  /* ─── STEP 2: 到货验收 ─── */
  if (step === 'arrival-content' && inspectionStep === 1 && selectedDelivery) {
    return (
      <MobileLayout title={flow.title} showBack onBack={() => setInspectionStep(0)}>
        <div className="p-4">
          {/* 步骤指示器 */}
          <div className="flex items-center justify-between mb-4 bg-white rounded-2xl p-3 shadow-sm">
            {flow.steps.map((label, idx) => (
              <div key={label} className="flex items-center gap-1">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  idx === 1 ? 'bg-[#1565c0] text-white' : idx < 1 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
                }`}>{idx < 1 ? <Check size={14} /> : idx + 1}</div>
                <span className={`text-[10px] ${idx === 1 ? 'text-[#1565c0] font-medium' : idx < 1 ? 'text-green-600' : 'text-gray-400'}`}>{label}</span>
                {idx < 2 && <ChevronRight size={14} className="text-gray-300 mx-0.5" />}
              </div>
            ))}
          </div>

          {/* 收货信息 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">{flow.step2Title}</h3>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">{flow.receiverLabel} <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={receiver}
                  onChange={e => setReceiver(e.target.value)}
                  placeholder="请输入收货人姓名"
                  className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">收货时间 <span className="text-red-500">*</span></label>
                <input
                  type="text"
                  value={receiveTime}
                  readOnly
                  className="w-full bg-gray-100 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none"
                />
              </div>
            </div>
          </div>

          {/* 验收附件上传 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">验收附件</h3>
            {/* 已上传附件列表 */}
            {attachments.length > 0 && (
              <div className="space-y-2 mb-3">
                {attachments.map(att => (
                  <div key={att.id} className="flex items-center gap-2 bg-gray-50 rounded-lg p-2.5">
                    <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center shrink-0">
                      <Archive size={14} className="text-blue-500" />
                    </div>
                    <span className="text-xs text-gray-700 flex-1 truncate">{att.name}</span>
                    <button
                      onClick={() => setAttachments(prev => prev.filter(a => a.id !== att.id))}
                      className="text-gray-400 active:text-red-500 p-1"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                ))}
              </div>
            )}
            {/* 上传按钮 */}
            <button
              onClick={() => {
                const mockImages = ['验收照片_外观检查.jpg', '验收照片_数量核对.jpg', '验收照片_包装标签.jpg', '验收照片_质量检测.jpg'];
                const randomImg = mockImages[Math.floor(Math.random() * mockImages.length)];
                setAttachments(prev => [...prev, {
                  id: Date.now().toString(),
                  name: randomImg,
                  url: '#',
                }]);
              }}
              className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-blue-200 rounded-xl text-xs font-medium text-blue-600 bg-blue-50/50 active:bg-blue-50 transition-colors"
            >
              <Plus size={16} /> 上传图片附件
            </button>
            <p className="text-[10px] text-gray-400 mt-1.5 text-center">支持上传验收现场照片、装备外观等图片</p>
          </div>

          {/* 验收明细 */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">验收明细</h3>
            <div className="space-y-3">
              {inspectionMaterials.map((m, i) => (
                <div key={m.id} className="border border-gray-100 rounded-xl p-3">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-400">#{i + 1}</span>
                      <span className="text-sm font-medium text-gray-800">{m.name}</span>
                      <span className="text-[10px] text-gray-400">({m.model})</span>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                      m.status === '全部合格' ? 'bg-green-50 text-green-600' :
                      m.status === '部分合格' ? 'bg-orange-50 text-orange-600' :
                      'bg-red-50 text-red-600'
                    }`}>{m.status || '待验收'}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-gray-50 rounded-lg p-2">
                      <p className="text-[10px] text-gray-400">{flow.sourceLabel}</p>
                      <p className="text-sm font-medium text-gray-800">{m.deliveryQty} {m.unit}</p>
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-500 mb-0.5 block">{flow.actualLabel} <span className="text-red-500">*</span></label>
                      <input
                        type="number"
                        value={m.actualQty || ''}
                        onChange={e => updateInspectionMaterial(m.id, 'actualQty', Number(e.target.value))}
                        className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-500 mb-0.5 block">合格数量</label>
                      <input
                        type="number"
                        value={m.qualifiedQty || ''}
                        onChange={e => updateInspectionMaterial(m.id, 'qualifiedQty', Number(e.target.value))}
                        className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent"
                      />
                    </div>
                    <div className="bg-gray-50 rounded-lg p-2">
                      <p className="text-[10px] text-gray-400">不合格</p>
                      <p className="text-sm font-medium text-red-600">{m.unqualifiedQty || 0}</p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <label className="text-[10px] text-gray-500 mb-0.5 block">验收意见</label>
                    <input
                      type="text"
                      value={m.inspectionRemark || ''}
                      onChange={e => {
                        setInspectionMaterials(prev => prev.map(pm => pm.id === m.id ? { ...pm, inspectionRemark: e.target.value } : pm));
                      }}
                      placeholder="选填"
                      className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-2">
            <button onClick={() => setInspectionStep(0)} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">
              上一步
            </button>
            <button
              onClick={handleConfirmInspection}
              disabled={!receiver}
              className={`flex-1 py-3 rounded-xl font-medium text-sm transition-colors ${
                receiver ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'
              }`}
            >
              下一步：{flow.steps[2]}
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ─── STEP 3: 到货处置 ─── */
  if (step === 'arrival-content' && inspectionStep === 2 && selectedDelivery) {
    return (
      <MobileLayout title={flow.title} showBack onBack={() => setInspectionStep(1)}>
        <div className="p-4">
          {/* 步骤指示器 */}
          <div className="flex items-center justify-between mb-4 bg-white rounded-2xl p-3 shadow-sm">
            {flow.steps.map((label, idx) => (
              <div key={label} className="flex items-center gap-1">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  idx <= 2 ? 'bg-green-500 text-white' : 'bg-gray-200 text-gray-400'
                }`}><Check size={14} /></div>
                <span className={`text-[10px] ${idx <= 2 ? 'text-green-600 font-medium' : 'text-gray-400'}`}>{label}</span>
                {idx < 2 && <ChevronRight size={14} className="text-gray-300 mx-0.5" />}
              </div>
            ))}
          </div>

          {/* 提示 */}
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 mb-3 flex items-center gap-2">
            <Archive size={16} className="text-orange-500 shrink-0" />
            <p className="text-xs text-orange-700">点击全部入库/全部交付快速分配，也可逐条混合处置</p>
          </div>

          {/* 处置明细：逐装备卡片 */}
          <div className="space-y-3 mb-4">
            {inspectionMaterials.filter(m => (m.qualifiedQty || 0) > 0).map((m) => {
              const rows = disposalRows.filter(r => r.materialId === m.id);
              const disposedQty = rows.reduce((s, r) => s + (r.qty || 0), 0);
              const remaining = (m.qualifiedQty || 0) - disposedQty;

              return (
                <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                  {/* 装备标题 */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <ChevronDown size={14} className="text-gray-400" />
                      <span className="text-sm font-semibold text-gray-800">{m.name}</span>
                      <span className="text-[10px] text-gray-400">({m.model})</span>
                      <span className="text-xs text-blue-600">合格 {m.qualifiedQty}件</span>
                    </div>
                    {remaining > 0 && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-medium bg-red-50 text-red-500">
                        待分配 {remaining}件
                      </span>
                    )}
                  </div>

                  {/* 快捷按钮 */}
                  {remaining > 0 && (
                    <div className="flex gap-2 mb-3">
                      <button
                        onClick={() => {
                          setDisposalRows(prev => [...prev, {
                            id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
                            materialId: m.id, mode: 'storage', qty: remaining,
                            warehouse: '', area: '', useUnit: '', useTarget: '',
                          }]);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-gray-200 text-gray-600 bg-white active:bg-gray-50 transition-colors"
                      >
                        <Archive size={13} className="text-blue-500" /> 全部入库
                      </button>
                      <button
                        onClick={() => {
                          setDisposalRows(prev => [...prev, {
                            id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
                            materialId: m.id, mode: 'deliver', qty: remaining,
                            warehouse: '', area: '', useUnit: '', useTarget: '',
                          }]);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border border-gray-200 text-gray-600 bg-white active:bg-gray-50 transition-colors"
                      >
                        <Truck size={13} className="text-green-500" /> 全部交付
                      </button>
                    </div>
                  )}

                  {/* 处置行列表 */}
                  <div className="space-y-2">
                    {rows.map((row) => (
                      <div key={row.id} className="bg-gray-50 rounded-lg p-2.5 space-y-2">
                        {/* 第一行：入库/交付切换 + 数量 + 仓库/使用单位 */}
                        <div className="grid grid-cols-[80px_60px_1fr_28px] gap-1.5 items-center">
                          {/* 入库/交付切换 */}
                          <div className="flex rounded-md overflow-hidden border border-gray-200">
                            <button
                              onClick={() => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, mode: 'storage', useUnit: '', useTarget: '' } : r))}
                              className={`flex-1 py-1 text-[10px] font-medium transition-colors ${
                                row.mode === 'storage' ? 'bg-blue-500 text-white' : 'bg-white text-gray-500'
                              }`}
                            >
                              入库
                            </button>
                            <button
                              onClick={() => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, mode: 'deliver', warehouse: '', area: '' } : r))}
                              className={`flex-1 py-1 text-[10px] font-medium transition-colors ${
                                row.mode === 'deliver' ? 'bg-green-500 text-white' : 'bg-white text-gray-500'
                              }`}
                            >
                              交付
                            </button>
                          </div>

                          {/* 数量 */}
                          <input
                            type="number"
                            value={row.qty || ''}
                            onChange={e => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, qty: Number(e.target.value) } : r))}
                            className="bg-white rounded-md px-2 py-1 text-[10px] text-gray-700 outline-none border border-gray-200 text-center"
                          />

                          {/* 入库：仓库/区域选择 */}
                          {row.mode === 'storage' && (
                            <div className="grid grid-cols-2 gap-1">
                              <select
                                value={row.warehouse}
                                onChange={e => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, warehouse: e.target.value, area: '' } : r))}
                                className="bg-white rounded-md px-1 py-1 text-[10px] text-gray-700 outline-none border border-gray-200"
                              >
                                <option value="">仓库</option>
                                {WAREHOUSES.map(w => <option key={w.name} value={w.name}>{w.name}</option>)}
                              </select>
                              <select
                                value={row.area}
                                onChange={e => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, area: e.target.value } : r))}
                                disabled={!row.warehouse}
                                className="bg-white rounded-md px-1 py-1 text-[10px] text-gray-700 outline-none border border-gray-200 disabled:bg-gray-100"
                              >
                                <option value="">区域</option>
                                {row.warehouse && WAREHOUSES.find(w => w.name === row.warehouse)?.areas.map(a => (
                                  <option key={a} value={a}>{a}</option>
                                ))}
                              </select>
                            </div>
                          )}

                          {/* 交付：使用单位选择 */}
                          {row.mode === 'deliver' && (
                            <select
                              value={row.useUnit}
                              onChange={e => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, useUnit: e.target.value, useTarget: '' } : r))}
                              className="bg-white rounded-md px-2 py-1 text-[10px] text-gray-700 outline-none border border-gray-200"
                            >
                              <option value="">使用单位</option>
                              {USE_UNIT_TARGETS.map(u => (
                                <option key={u.unit} value={u.unit}>{u.unit}</option>
                              ))}
                            </select>
                          )}

                          {/* 未选择时占位 */}
                          {row.mode === '' && <div className="text-[10px] text-gray-400">请先选择处置方式</div>}

                          {/* 删除 */}
                          <button
                            onClick={() => setDisposalRows(prev => prev.filter(r => r.id !== row.id))}
                            className="text-gray-400 active:text-red-500 flex items-center justify-center"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>

                        {/* 交付时第二行：使用对象 */}
                        {row.mode === 'deliver' && (
                          <div className="grid grid-cols-[80px_60px_1fr_28px] gap-1.5 items-center">
                            <div />
                            <div />
                            <select
                              value={row.useTarget}
                              onChange={e => setDisposalRows(prev => prev.map(r => r.id === row.id ? { ...r, useTarget: e.target.value } : r))}
                              className="bg-white rounded-md px-2 py-1 text-[10px] text-gray-700 outline-none border border-gray-200"
                            >
                              <option value="">使用对象</option>
                              {row.useUnit && USE_UNIT_TARGETS.find(u => u.unit === row.useUnit)?.targets.map(t => (
                                <option key={t} value={t}>{t}</option>
                              ))}
                            </select>
                            <div />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  {/* 添加处置（待分配>0时显示） */}
                  {remaining > 0 && (
                    <button
                      onClick={() => {
                        setDisposalRows(prev => [...prev, {
                          id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
                          materialId: m.id, mode: '', qty: remaining,
                          warehouse: '', area: '', useUnit: '', useTarget: '',
                        }]);
                      }}
                      className="w-full flex items-center justify-center gap-1 py-2.5 mt-2 border border-dashed border-gray-300 rounded-lg text-xs font-medium text-gray-500 bg-gray-50/50 active:bg-gray-100 transition-colors"
                    >
                      <Plus size={14} /> 添加处置
                    </button>
                  )}

                  {/* 底部分配进度 */}
                  <div className="mt-2 pt-2 border-t border-gray-100 flex items-center gap-2">
                    <span className="text-[10px] text-gray-500">
                      已分配：<span className={`font-bold ${remaining === 0 ? 'text-green-600' : 'text-orange-600'}`}>{disposedQty}</span> / {m.qualifiedQty} 件
                    </span>
                    {remaining > 0 && (
                      <span className="text-[10px] text-red-500">（还需分配 {remaining} 件）</span>
                    )}
                    {remaining === 0 && (
                      <CheckCircle2 size={12} className="text-green-500" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* 全局未处置汇总 */}
          {(() => {
            const totalQualified = inspectionMaterials.reduce((s, m) => s + (m.qualifiedQty || 0), 0);
            const totalDisposed = disposalRows.reduce((s, r) => s + (r.qty || 0), 0);
            const undisposed = totalQualified - totalDisposed;
            return undisposed > 0 ? (
              <div className="bg-orange-50 border border-orange-200 rounded-xl p-3 mb-4 flex items-center justify-between">
                <span className="text-xs text-orange-700">已处置 {totalDisposed}件 / 合格共 {totalQualified}件</span>
                <span className="text-xs font-bold text-orange-600">未处置 {undisposed}件</span>
              </div>
            ) : null;
          })()}

          <div className="flex gap-2">
            <button onClick={() => setInspectionStep(1)} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">
              上一步
            </button>
            <button
              onClick={handleConfirmDisposal}
              className="flex-1 bg-[#1565c0] text-white py-3 rounded-xl font-medium text-sm active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20"
            >
              {flow.confirmLabel}
            </button>
          </div>

          {/* 未处置装备弹窗 */}
          {showUndisposedModal && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-6" style={{ background: 'rgba(0,0,0,0.5)' }}>
              <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden">
                <div className="p-5 text-center">
                  <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-3">
                    <AlertTriangle size={24} className="text-orange-500" />
                  </div>
                  <h3 className="text-base font-semibold text-gray-900 mb-2">未处置装备提醒</h3>
                  <p className="text-sm text-gray-600 mb-1">
                    有 <span className="font-bold text-orange-600">{undisposedCount}</span> 件未处置装备
                  </p>
                  <p className="text-xs text-gray-500">
                    请确认是否先验收，后续再进行处置？
                  </p>
                </div>
                <div className="flex border-t border-gray-100">
                  <button
                    onClick={() => setShowUndisposedModal(false)}
                    className="flex-1 py-3.5 text-sm font-medium text-gray-600 active:bg-gray-50 transition-colors border-r border-gray-100"
                  >
                    返回处置
                  </button>
                  <button
                    onClick={() => {
                      setShowUndisposedModal(false);
                      setTimeout(() => handleConfirmDisposal(), 0);
                    }}
                    className="flex-1 py-3.5 text-sm font-medium text-[#1565c0] active:bg-blue-50 transition-colors"
                  >
                    先验收后处置
                  </button>
                </div>
              </div>
            </div>
          )}        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: BASIC INFO ═══════════ */
  if (step === 'basic-info') {
    return (
      <MobileLayout title="基本信息" showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-blue-600">入库单字号</p>
              <p className="text-sm font-semibold text-blue-800 font-mono">{orderNo}</p>
            </div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          {typeConfig && (
            <div className="mb-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ backgroundColor: typeConfig.color }}>
                <typeConfig.icon size={14} /> {typeConfig.label}
              </span>
            </div>
          )}

          <div className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
            {/* Purchase Date — date picker */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">采购日期 <span className="text-red-500">*</span></label>
              <input
                type="date"
                value={basicInfo.purchaseDate || ''}
                onChange={e => setBasicInfo(p => ({ ...p, purchaseDate: e.target.value }))}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>

            {/* Supplier — fuzzy search */}
            <div ref={supplierRef} className="relative">
              <label className="text-xs text-gray-500 mb-1 block">供应商 <span className="text-red-500">*</span></label>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={supplierQuery || basicInfo.supplier || ''}
                  onChange={e => { setSupplierQuery(e.target.value); setBasicInfo(p => ({ ...p, supplier: e.target.value })); setShowSupplierList(true); }}
                  onFocus={() => setShowSupplierList(true)}
                  placeholder="搜索供应商名称"
                  className="w-full bg-gray-50 rounded-xl pl-9 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                />
              </div>
              {showSupplierList && filteredSuppliers.length > 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg max-h-48 overflow-y-auto">
                  {filteredSuppliers.map(s => (
                    <button
                      key={s}
                      onClick={() => { setBasicInfo(p => ({ ...p, supplier: s })); setSupplierQuery(s); setShowSupplierList(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 first:rounded-t-xl last:rounded-b-xl transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
              {showSupplierList && supplierQuery && filteredSuppliers.length === 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg p-3 text-xs text-gray-400">
                  未找到匹配的供应商，可输入新供应商名称
                </div>
              )}
            </div>

            {/* Storage Location — warehouse cascade */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">存储位置 <span className="text-red-500">*</span></label>
              <select
                value={selectedWarehouse}
                onChange={e => { setSelectedWarehouse(e.target.value); setSelectedArea(''); }}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all mb-2"
              >
                <option value="">选择仓库</option>
                {WAREHOUSES.map(w => <option key={w.name} value={w.name}>{w.name}</option>)}
              </select>
              {selectedWarehouse && (
                <select
                  value={selectedArea}
                  onChange={e => {
                    setSelectedArea(e.target.value);
                    const fullPath = `${selectedWarehouse}/${e.target.value}`;
                    setBasicInfo(p => ({ ...p, storageLocation: fullPath }));
                  }}
                  className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                >
                  <option value="">选择区域</option>
                  {WAREHOUSES.find(w => w.name === selectedWarehouse)?.areas.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              )}
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">入库时间 <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={basicInfo.inTime || ''}
                readOnly
                className="w-full bg-gray-100 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">经办人</label>
              <input
                type="text"
                value={basicInfo.operator || ''}
                onChange={e => setBasicInfo(p => ({ ...p, operator: e.target.value }))}
                placeholder="请输入经办人姓名"
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">采购项目名称 <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={basicInfo.projectName || ''}
                onChange={e => setBasicInfo(p => ({ ...p, projectName: e.target.value }))}
                placeholder="请输入采购项目名称"
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>
          </div>

          <button
            onClick={() => setStep('materials')}
            className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium mt-4 active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2"
          >
            下一步：物资明细 <ArrowRight size={16} />
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: MATERIALS ═══════════ */
  if (step === 'materials') {
    return (
      <MobileLayout title="物资明细" showBack onBack={() => setStep('basic-info')}>
        <div className="p-4">
          {/* Scan */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">扫描RFID编码</p>
                <p className="text-xs text-gray-500">扫描装备RFID标签自动填充信息</p>
              </div>
              <button onClick={handleScanRFID} className="px-4 py-2 bg-[#1565c0] text-white rounded-xl text-sm font-medium active:bg-blue-700 transition-colors">
                扫描
              </button>
            </div>
            {scanResult && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-2.5 flex items-center gap-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <span className="text-xs text-green-700">{scanResult}</span>
              </div>
            )}
          </div>

          {/* Material List */}
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800">物资清单 ({materials.length})</h3>
            <button onClick={addManualMaterial} className="flex items-center gap-1 text-xs text-[#1565c0] font-medium px-3 py-1.5 bg-blue-50 rounded-lg active:bg-blue-100 transition-colors">
              <Plus size={14} /> 手动添加
            </button>
          </div>

          <div className="space-y-3 pb-4">
            {materials.length === 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm text-center text-gray-400">
                <Package size={32} className="mx-auto mb-2" />
                <p className="text-sm">请扫描RFID或手动添加物资</p>
              </div>
            )}
            {materials.map((m, idx) => (
              <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-400">物资 #{idx + 1}</span>
                  <button onClick={() => removeMaterial(m.id)} className="text-red-400 active:text-red-600 p-1">
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500">物资名称<span className="text-red-500">*</span></label>
                    <input type="text" value={m.name} onChange={e => updateMaterial(m.id, 'name', e.target.value)} placeholder="名称" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">物资类别</label>
                    <input type="text" value={m.category} onChange={e => updateMaterial(m.id, 'category', e.target.value)} placeholder="类别" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">规格型号</label>
                    <input type="text" value={m.model} onChange={e => updateMaterial(m.id, 'model', e.target.value)} placeholder="型号" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">数量<span className="text-red-500">*</span></label>
                    <div className="flex items-center bg-gray-50 rounded-lg">
                      <button onClick={() => updateMaterial(m.id, 'quantity', Math.max(1, m.quantity - 1))} className="px-2 py-2 active:bg-gray-200 rounded-l-lg"><Minus size={12} /></button>
                      <input type="number" value={m.quantity} onChange={e => updateMaterial(m.id, 'quantity', Number(e.target.value))} className="w-full text-center text-xs bg-transparent outline-none py-2" />
                      <button onClick={() => updateMaterial(m.id, 'quantity', m.quantity + 1)} className="px-2 py-2 active:bg-gray-200 rounded-r-lg"><Plus size={12} /></button>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">单位<span className="text-red-500">*</span></label>
                    <input type="text" value={m.unit} onChange={e => updateMaterial(m.id, 'unit', e.target.value)} placeholder="件" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">单价(¥)<span className="text-red-500">*</span></label>
                    <input type="number" value={m.price || ''} onChange={e => updateMaterial(m.id, 'price', Number(e.target.value))} placeholder="0.00" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">生产日期</label>
                    <input type="date" value={m.productionDate} onChange={e => updateMaterial(m.id, 'productionDate', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">有效期</label>
                    <input type="date" value={m.expiryDate} onChange={e => updateMaterial(m.id, 'expiryDate', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>

                  {/* Maintenance Period — quantity + unit */}
                  <div>
                    <label className="text-[10px] text-gray-500">保养期</label>
                    <div className="flex gap-1.5">
                      <input
                        type="number"
                        value={m.maintenanceValue}
                        onChange={e => updateMaterial(m.id, 'maintenanceValue', Number(e.target.value))}
                        className="flex-1 bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none"
                        min={1}
                      />
                      <select
                        value={m.maintenanceUnit}
                        onChange={e => updateMaterial(m.id, 'maintenanceUnit', e.target.value)}
                        className="w-16 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-800 outline-none"
                      >
                        {MAINTENANCE_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-gray-500">装备编码</label>
                    <input type="text" value={m.equipmentCode} onChange={e => updateMaterial(m.id, 'equipmentCode', e.target.value)} placeholder="编码" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">RFID编码</label>
                    <input type="text" value={m.rfidCode} onChange={e => updateMaterial(m.id, 'rfidCode', e.target.value)} placeholder="RFID" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">存储位置<span className="text-red-500">*</span></label>
                    <input type="text" value={m.storageLocation} onChange={e => updateMaterial(m.id, 'storageLocation', e.target.value)} placeholder="仓库/区域" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">供应商</label>
                    <input type="text" value={m.supplier} onChange={e => updateMaterial(m.id, 'supplier', e.target.value)} placeholder="供应商" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">总价(¥)</label>
                    <input type="text" value={m.total.toFixed(2)} readOnly className="w-full bg-gray-100 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none" />
                  </div>
                  <div className="col-span-2">
                    <label className="text-[10px] text-gray-500">备注</label>
                    <input type="text" value={m.remark} onChange={e => updateMaterial(m.id, 'remark', e.target.value)} placeholder="选填" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div className="col-span-2 flex items-center gap-2">
                    <input type="checkbox" checked={m.isFixedAsset} onChange={e => updateMaterial(m.id, 'isFixedAsset', e.target.checked)} className="w-4 h-4 rounded text-[#1565c0]" />
                    <label className="text-xs text-gray-600">固定资产</label>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {materials.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mt-3 mb-3">
              <div className="flex items-center justify-between">
                <div><p className="text-xs text-blue-600">合计数量</p><p className="text-lg font-bold text-blue-800">{totalQty} 件</p></div>
                <div className="text-right"><p className="text-xs text-blue-600">合计金额</p><p className="text-lg font-bold text-blue-800">¥{totalAmount.toFixed(2)}</p></div>
              </div>
            </div>
          )}

          <button onClick={() => setStep('review')} disabled={materials.length === 0} className={`w-full py-3.5 rounded-xl font-medium transition-colors mb-6 ${materials.length > 0 ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}>
            提交入库申请
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: REVIEW ═══════════ */
  if (step === 'review') {
    return (
      <MobileLayout title="确认入库" showBack onBack={() => isEditable ? setStep('materials') : setStep('list')}>
        <div className="p-4">
          {savedDraft && (
            <div className="bg-green-50 border border-green-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
              <CheckCircle2 size={20} className="text-green-600" />
              <div>
                <p className="text-sm font-semibold text-green-800">草稿已保存</p>
                <p className="text-xs text-green-600">入库单已保存为草稿，可后续继续编辑</p>
              </div>
            </div>
          )}

          {/* Status */}
          {!savedDraft && (
            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
              <Clock size={20} className="text-orange-600" />
              <div>
                <p className="text-sm font-semibold text-orange-800">待入库状态</p>
                <p className="text-xs text-orange-600">请核对信息无误后确认入库</p>
              </div>
            </div>
          )}

          {/* Order Summary */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">入库单信息</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">入库单号</span><span className="text-xs text-gray-800 font-mono">{orderNo}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gray-500">入库类型</span><span className="text-xs text-gray-800">{typeConfig?.label}</span></div>
              {Object.entries(basicInfo).filter(([, v]) => v).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-xs text-gray-500">
                    {k === 'projectName' ? '采购项目名称' : k === 'purchaseDate' ? '采购日期' : k === 'supplier' ? '供应商' : k === 'storageLocation' ? '存储位置' : k === 'inTime' ? '入库时间' : k === 'operator' ? '经办人' : k === 'transferNo' ? '调拨单号' : k === 'fromUnit' ? '发物单位' : k === 'toUnit' ? '调入单位' : k === 'transferCount' ? '调拨数量' : k === 'borrower' ? '借用人' : k === 'borrowTime' ? '借用时间' : k === 'expectedReturn' ? '预计归还' : k === 'borrowCount' ? '借用数量' : k}
                  </span>
                  <span className="text-xs text-gray-800">{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Materials */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">物资汇总</h3>
            <div className="space-y-2">
              {materials.map((m, i) => (
                <div key={m.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">#{i + 1}</span>
                    <span className="text-sm text-gray-700">{m.name}</span>
                    {m.maintenanceValue > 0 && <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">保养{m.maintenanceValue}{m.maintenanceUnit}</span>}
                  </div>
                  <div className="text-right">
                    <span className="text-sm text-gray-900">x{m.quantity}</span>
                    <span className="text-xs text-gray-500 ml-1">{m.unit}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
              <span className="text-sm text-gray-600">共 {materials.length} 种，{totalQty} 件</span>
              <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toFixed(2)}</span>
            </div>
          </div>

          {/* Rules */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <h3 className="text-xs font-semibold text-gray-600 mb-2">业务规则</h3>
            <ul className="space-y-1">
              <li className="text-[10px] text-gray-500">1. 入库记录将永久留存，不可删除</li>
              <li className="text-[10px] text-gray-500">2. 确认入库后将同步更新库存数据</li>
              <li className="text-[10px] text-gray-500">3. RFID编码唯一，同种装备将合并记录</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex gap-2 mb-6">
            <button onClick={() => isEditable ? setStep('materials') : setStep('list')} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">
              返回修改
            </button>
            <button onClick={handleSaveDraft} className="flex-1 bg-orange-50 text-orange-600 py-3 rounded-xl font-medium text-sm active:bg-orange-100 transition-colors flex items-center justify-center gap-1">
              <Save size={14} /> 保存草稿
            </button>
            <button onClick={() => setStep('success')} className="flex-1 bg-[#1565c0] text-white py-3 rounded-xl font-medium text-sm active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">
              确认入库
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: SUCCESS ═══════════ */
  return (
    <MobileLayout title="入库完成" showBack onBack={() => { setStep('list'); setMaterials([]); setBasicInfo({}); setSelectedDelivery(null); setInspectionStep(0); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">入库成功</h3>
        <p className="text-sm text-gray-500 text-center mb-1">入库单号：{orderNo}</p>
        <p className="text-sm text-gray-500 text-center mb-6">
          {selectedDelivery 
            ? `共验收 ${inspectionMaterials.reduce((s, m) => s + (m.qualifiedQty || 0), 0)} 件合格装备` 
            : `共入库 ${totalQty} 件装备，库存数据已同步更新`}
        </p>

        <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6">
          {[
            { label: '入库单号', value: orderNo },
            { label: '入库类型', value: selectedDelivery ? '到货验收' : typeConfig?.label || '' },
            { label: '物资种类', value: `${selectedDelivery ? inspectionMaterials.length : materials.length} 种` },
            { label: selectedDelivery ? '验收总数' : '入库总数', value: `${selectedDelivery ? inspectionMaterials.reduce((s, m) => s + (m.qualifiedQty || 0), 0) : totalQty} 件` },
            { label: '入库时间', value: new Date().toLocaleString('zh-CN') },
            { label: '入库状态', value: '已入库' },
          ].map(item => (
            <div key={item.label} className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{item.label}</span>
              <span className="text-sm text-gray-800">{item.value}</span>
            </div>
          ))}
        </div>

        <button onClick={() => { setStep('list'); setMaterials([]); setBasicInfo({}); setSelectedDelivery(null); setInspectionStep(0); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">
          返回入库列表
        </button>
      </div>
    </MobileLayout>
  );
}
