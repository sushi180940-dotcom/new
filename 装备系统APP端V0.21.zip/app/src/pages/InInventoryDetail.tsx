import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { CheckCircle2, Package, CircleDot, ShoppingCart, ArrowLeftRight, RotateCcw, Building2 } from 'lucide-react';

const typeLabelMap: Record<string, string> = {
  purchase: '到货验收',
  transfer: '调拨入库',
  return: '归还入库',
  station: '其他入库',
};

const typeColorMap: Record<string, string> = {
  purchase: '#1565c0',
  transfer: '#7c4dff',
  return: '#00acc1',
  station: '#43a047',
};

const typeIconMap: Record<string, React.ElementType> = {
  purchase: ShoppingCart,
  transfer: ArrowLeftRight,
  return: RotateCcw,
  station: Building2,
};

// Mock detail data
const mockDetailData: Record<string, {
  id: string;
  type: string;
  status: string;
  createTime: string;
  completeTime?: string;
  operator: string;
  basicInfo: Record<string, string>;
  materials: Array<{
    name: string;
    category: string;
    model: string;
    quantity: number;
    unit: string;
    rfidCode: string;
    equipmentCode: string;
    storageLocation: string;
    supplier: string;
    price: number;
    total: number;
  }>;
}> = {
  RK20240520001: {
    id: 'RK20240520001',
    type: 'purchase',
    status: 'completed',
    createTime: '2024-05-20 10:30',
    completeTime: '2024-05-20 11:15',
    operator: '李建国',
    basicInfo: {
      deliveryNo: 'FH20260603001',
      orderName: '2026年防弹背心采购订单',
      contractNo: 'HT-2026-001',
      supplier: '某省安防科技有限公司',
      storageLocation: '省厅主仓库/主仓库1楼',
      inTime: '2024-05-20 10:30',
      receiveAddress: 'XXX省公安厅装备处',
      receiver: '张伟',
    },
    materials: [
      { name: '防弹背心', category: '防护装备', model: 'FD-BX-III', quantity: 50, unit: '件', rfidCode: '共50个', equipmentCode: 'ZB-001-001', storageLocation: '省厅主仓库/主仓库1楼', supplier: '某省安防科技有限公司', price: 1200, total: 60000 },
      { name: '手铐', category: '械具', model: 'SK-STD', quantity: 100, unit: '副', rfidCode: '共100个', equipmentCode: 'ZB-002-001', storageLocation: '省厅主仓库/主仓库1楼', supplier: '某省安防科技有限公司', price: 85, total: 8500 },
      { name: '执法记录仪', category: '记录设备', model: 'DSJ-A7', quantity: 30, unit: '台', rfidCode: '共30个', equipmentCode: 'ZB-003-001', storageLocation: '省厅主仓库/主仓库1楼', supplier: '某省安防科技有限公司', price: 2800, total: 84000 },
    ],
  },
  RK20240519002: {
    id: 'RK20240519002',
    type: 'transfer',
    status: 'completed',
    createTime: '2024-05-19 14:20',
    completeTime: '2024-05-19 15:00',
    operator: '张丽',
    basicInfo: {
      transferNo: 'DB20240519001',
      fromUnit: '东坝派出所',
      storageLocation: '省厅主仓库/主仓库2楼',
      transferCount: '5',
      inTime: '2024-05-19 14:20',
    },
    materials: [
      { name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 5, unit: '台', rfidCode: 'RFID202405010A~E', equipmentCode: 'EQ202405010', storageLocation: '省厅主仓库/主仓库2楼', supplier: '国安器材', price: 650, total: 3250 },
    ],
  },
};

export default function InInventoryDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const detail = mockDetailData[id || ''];

  if (!detail) {
    return (
      <MobileLayout title="入库详情" showBack onBack={() => navigate('/in')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Package size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到入库记录</p>
        </div>
      </MobileLayout>
    );
  }

  const TypeIcon = typeIconMap[detail.type] || Package;
  const totalQty = detail.materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = detail.materials.reduce((s, m) => s + m.total, 0);

  return (
    <MobileLayout title="入库详情" showBack onBack={() => navigate('/in')}>
      <div className="p-4">
        {/* Status Card */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${typeColorMap[detail.type]}15` }}>
              <TypeIcon size={24} style={{ color: typeColorMap[detail.type] }} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{detail.id}</span>
                <span
                  className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white"
                  style={{ backgroundColor: typeColorMap[detail.type] }}
                >
                  {typeLabelMap[detail.type]}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  detail.status === 'completed' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {detail.status === 'completed' ? '已入库' : '待入库'}
                </span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">创建时间</p>
              <p className="text-xs text-gray-800 font-medium">{detail.createTime}</p>
            </div>
            {detail.completeTime && (
              <div className="bg-gray-50 rounded-xl p-2.5">
                <p className="text-[10px] text-gray-500">完成时间</p>
                <p className="text-xs text-gray-800 font-medium">{detail.completeTime}</p>
              </div>
            )}
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">经办人</p>
              <p className="text-xs text-gray-800 font-medium">{detail.operator}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">物资总数</p>
              <p className="text-xs text-gray-800 font-medium">{totalQty} 件</p>
            </div>
          </div>
        </div>

        {/* Basic Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">基本信息</h3>
          <div className="space-y-2 text-sm">
            {Object.entries(detail.basicInfo).map(([key, value]) => (
              <div key={key} className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">
                  {key === 'projectName' ? '采购项目名称' :
                   key === 'purchaseDate' ? '采购日期' :
                   key === 'supplier' ? '供应商' :
                   key === 'storageLocation' ? '存储位置' :
                   key === 'inTime' ? '入库时间' :
                   key === 'transferNo' ? '调拨单号' :
                   key === 'fromUnit' ? '发物单位' :
                   key === 'transferCount' ? '调拨数量' :
                   key === 'borrower' ? '借用人' :
                   key === 'borrowTime' ? '借用时间' :
                   key === 'expectedReturn' ? '预计归还' :
                   key === 'borrowCount' ? '借用数量' :
                   key === 'owner' ? '所属人员' :
                   key === 'equipmentName' ? '装备名称' :
                   key === 'model' ? '规格型号' :
                   key === 'quantity' ? '入库数量' :
                   key === 'deliveryNo' ? '发货单号' :
                   key === 'orderName' ? '订单名称' :
                   key === 'contractNo' ? '合同号' :
                   key === 'receiveAddress' ? '收货地址' :
                   key === 'receiver' ? '收货人' : key}
                </span>
                <span className="text-xs text-gray-800 font-medium">{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Materials */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">物资明细 ({detail.materials.length})</h3>
          <div className="space-y-3">
            {detail.materials.map((m, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{m.name}</span>
                  </div>
                  <span className="text-sm font-bold text-[#1565c0]">¥{m.total.toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>编号：{m.equipmentCode}</span>
                  <span>RFID：{m.rfidCode}</span>
                  <span>型号：{m.model}</span>
                  <span>数量：{m.quantity} {m.unit}</span>
                  <span>单价：¥{m.price}</span>
                  <span>存放：{m.storageLocation}</span>
                  <span>供应商：{m.supplier}</span>
                  <span>类别：{m.category}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
            <span className="text-sm text-gray-600">共 {detail.materials.length} 种，{totalQty} 件</span>
            <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toLocaleString()}</span>
          </div>
        </div>

        {/* Status Timeline */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">状态流转</h3>
          <div className="space-y-0">
            {[
              { label: '创建入库单', time: detail.createTime, done: true },
              { label: '待入库', time: detail.createTime, done: true },
              ...(detail.status === 'completed' ? [
                { label: '已入库', time: detail.completeTime || '', done: true },
              ] : []),
            ].map((step, i, arr) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                    step.done ? 'bg-green-500' : 'bg-gray-300'
                  }`}>
                    {step.done ? <CheckCircle2 size={14} className="text-white" /> : <CircleDot size={14} className="text-white" />}
                  </div>
                  {i < arr.length - 1 && <div className="w-0.5 h-6 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm ${step.done ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>{step.label}</p>
                  <p className="text-[10px] text-gray-400">{step.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
