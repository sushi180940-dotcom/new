import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import MobileLayout from '@/components/MobileLayout';
import {
  ScanLine, Search, Package, Tag, QrCode, RefreshCw,
  Database, Image, Video, FileText
} from 'lucide-react';

/* ─── types ─── */
interface EquipmentRecord {
  id: string;
  code: string;
  name: string;
  categoryL1: string;
  categoryL2: string;
  categoryL3: string;
  model: string;
  modelCode: string;
  unit: string;
  stockQty: number;
  hasBattery: boolean;
  maintenanceMonths: number;
  manufacturer: string;
  rfid: string;
  storageLocation: string;
  // 附件标记
  hasImage: boolean;
  hasVideo: boolean;
  hasDoc: boolean;
}

const EQUIPMENT_DB: EquipmentRecord[] = [
  { id: '1', code: 'ZB-001-001', name: '防弹背心', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹背心', model: 'FDY-3R-01', modelCode: 'MX-001', unit: '件', stockQty: 45, hasBattery: false, maintenanceMonths: 36, manufacturer: '某省安防科技有限公司', rfid: 'RFID202601001A', storageLocation: '省厅主仓库/主仓库1楼', hasImage: true, hasVideo: true, hasDoc: true },
  { id: '2', code: 'ZB-001-002', name: '防弹头盔', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹头盔', model: 'FDK-2A-01', modelCode: 'MX-002', unit: '顶', stockQty: 32, hasBattery: false, maintenanceMonths: 36, manufacturer: '红星装备厂', rfid: 'RFID202601002B', storageLocation: '省厅主仓库/主仓库1楼', hasImage: true, hasVideo: false, hasDoc: true },
  { id: '3', code: 'ZB-001-003', name: '防弹盾牌', categoryL1: '防护装备', categoryL2: '防弹防护', categoryL3: '防弹盾牌', model: 'FDP-800-A', modelCode: 'MX-003', unit: '件', stockQty: 18, hasBattery: false, maintenanceMonths: 24, manufacturer: '国安器材有限公司', rfid: 'RFID202601003C', storageLocation: '省厅主仓库/主仓库1楼', hasImage: true, hasVideo: false, hasDoc: false },
  { id: '4', code: 'ZB-002-001', name: '防刺背心', categoryL1: '防护装备', categoryL2: '防刺防护', categoryL3: '防刺背心', model: 'FCY-01A', modelCode: 'MX-004', unit: '件', stockQty: 28, hasBattery: false, maintenanceMonths: 24, manufacturer: '盾甲科技', rfid: 'RFID202601004D', storageLocation: '省厅主仓库/主仓库1楼', hasImage: false, hasVideo: false, hasDoc: true },
  { id: '5', code: 'ZB-003-001', name: '防暴头盔', categoryL1: '防护装备', categoryL2: '防暴防护', categoryL3: '防暴头盔', model: 'FBK-01', modelCode: 'MX-005', unit: '顶', stockQty: 56, hasBattery: false, maintenanceMonths: 12, manufacturer: '警用装备中心', rfid: 'RFID202601005E', storageLocation: '省厅主仓库/主仓库2楼', hasImage: true, hasVideo: true, hasDoc: true },
  { id: '6', code: 'ZB-004-001', name: '对讲机', categoryL1: '通讯设备', categoryL2: '无线通讯', categoryL3: '对讲机', model: 'DJ-HY-800', modelCode: 'MX-006', unit: '台', stockQty: 120, hasBattery: true, maintenanceMonths: 12, manufacturer: '中华安防集团', rfid: 'RFID202601006F', storageLocation: '省厅主仓库/主仓库2楼', hasImage: true, hasVideo: false, hasDoc: true },
  { id: '7', code: 'ZB-004-002', name: '车载电台', categoryL1: '通讯设备', categoryL2: '无线通讯', categoryL3: '车载电台', model: 'CZ-2000', modelCode: 'MX-007', unit: '台', stockQty: 15, hasBattery: true, maintenanceMonths: 12, manufacturer: '雄鹰警械公司', rfid: 'RFID202601007G', storageLocation: '01号装备室/东侧区域', hasImage: false, hasVideo: false, hasDoc: true },
  { id: '8', code: 'ZB-005-001', name: '执法记录仪', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '执法记录仪', model: 'DSJ-A7', modelCode: 'MX-008', unit: '台', stockQty: 85, hasBattery: true, maintenanceMonths: 12, manufacturer: '猎豹装备科技', rfid: 'RFID202601008H', storageLocation: '省厅主仓库/主仓库2楼', hasImage: true, hasVideo: true, hasDoc: true },
  { id: '9', code: 'ZB-005-002', name: '车载记录仪', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '车载记录仪', model: 'CZJ-4K-02', modelCode: 'MX-009', unit: '台', stockQty: 22, hasBattery: true, maintenanceMonths: 12, manufacturer: '红星装备厂', rfid: 'RFID202601009I', storageLocation: '01号装备室/西侧区域', hasImage: true, hasVideo: false, hasDoc: true },
  { id: '10', code: 'ZB-006-001', name: '战术手电', categoryL1: '照明设备', categoryL2: '手持照明', categoryL3: '战术手电', model: 'ZSD-200-X', modelCode: 'MX-010', unit: '个', stockQty: 150, hasBattery: true, maintenanceMonths: 6, manufacturer: '国安器材有限公司', rfid: 'RFID202601010J', storageLocation: '省厅主仓库/主仓库3楼', hasImage: true, hasVideo: false, hasDoc: false },
  { id: '11', code: 'ZB-006-002', name: '强光手电', categoryL1: '照明设备', categoryL2: '手持照明', categoryL3: '强光手电', model: 'QG-500-LM', modelCode: 'MX-011', unit: '个', stockQty: 68, hasBattery: true, maintenanceMonths: 6, manufacturer: '某省安防科技有限公司', rfid: 'RFID202601011K', storageLocation: '省厅主仓库/主仓库3楼', hasImage: false, hasVideo: false, hasDoc: true },
  { id: '12', code: 'ZB-007-001', name: '手铐', categoryL1: '械具', categoryL2: '约束械具', categoryL3: '手铐', model: 'SK-STD', modelCode: 'MX-012', unit: '副', stockQty: 200, hasBattery: false, maintenanceMonths: 60, manufacturer: '中华安防集团', rfid: 'RFID202601012L', storageLocation: '02号装备室/A区', hasImage: true, hasVideo: false, hasDoc: true },
  { id: '13', code: 'ZB-007-002', name: '警棍', categoryL1: '械具', categoryL2: '警械', categoryL3: '警棍', model: 'JG-TELE', modelCode: 'MX-013', unit: '根', stockQty: 90, hasBattery: false, maintenanceMonths: 12, manufacturer: '雄鹰警械公司', rfid: 'RFID202601013M', storageLocation: '02号装备室/A区', hasImage: true, hasVideo: true, hasDoc: true },
  { id: '14', code: 'ZB-007-003', name: '催泪喷射器', categoryL1: '械具', categoryL2: '警械', categoryL3: '催泪喷射器', model: 'CL-OC-50', modelCode: 'MX-014', unit: '个', stockQty: 75, hasBattery: false, maintenanceMonths: 24, manufacturer: '猎豹装备科技', rfid: 'RFID202601014N', storageLocation: '02号装备室/B区', hasImage: true, hasVideo: false, hasDoc: true },
  { id: '15', code: 'ZB-005-003', name: '无人机', categoryL1: '记录设备', categoryL2: '视频记录', categoryL3: '无人机', model: 'UAV-4K-01', modelCode: 'MX-015', unit: '架', stockQty: 8, hasBattery: true, maintenanceMonths: 6, manufacturer: '红星装备厂', rfid: 'RFID202601015O', storageLocation: '01号装备室/东侧区域', hasImage: true, hasVideo: true, hasDoc: true },
];

/* highlight matched keywords */
function HighlightText({ text, query }: { text: string; query: string }) {
  const keywords = query.toLowerCase().trim().split(/\s+/).filter(k => k.length > 0);
  if (keywords.length === 0) return <>{text}</>;
  type MatchPos = { start: number; end: number };
  const matches: MatchPos[] = [];
  const lowerText = text.toLowerCase();
  keywords.forEach(kw => {
    let idx = lowerText.indexOf(kw, 0);
    while (idx !== -1) { matches.push({ start: idx, end: idx + kw.length }); idx = lowerText.indexOf(kw, idx + 1); }
  });
  if (matches.length === 0) return <>{text}</>;
  matches.sort((a, b) => a.start - b.start);
  const merged: MatchPos[] = [];
  for (const m of matches) {
    if (merged.length === 0 || m.start > merged[merged.length - 1].end) merged.push(m);
    else merged[merged.length - 1].end = Math.max(merged[merged.length - 1].end, m.end);
  }
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  merged.forEach((m, i) => {
    if (m.start > lastIndex) parts.push(<span key={`n${i}`}>{text.slice(lastIndex, m.start)}</span>);
    parts.push(<span key={`h${i}`} className="text-[#1565c0] font-bold">{text.slice(m.start, m.end)}</span>);
    lastIndex = m.end;
  });
  if (lastIndex < text.length) parts.push(<span key="tail">{text.slice(lastIndex)}</span>);
  return <>{parts}</>;
}

export default function ScanQuery() {
  const [mode, setMode] = useState<'scan' | 'result' | 'empty'>('scan');
  const [searchText, setSearchText] = useState('');
  const [selectedItem, setSelectedItem] = useState<EquipmentRecord | null>(null);
  const [scanAnim, setScanAnim] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  /* fuzzy search */
  const dropdownResults = useMemo(() => {
    const query = searchText.trim();
    if (!query) return [];
    const keywords = query.toLowerCase().split(/\s+/).filter(k => k.length > 0);
    if (keywords.length === 0) return [];
    return EQUIPMENT_DB.filter(e => {
      const fields = [e.code, e.name, e.model, e.modelCode, e.rfid, e.categoryL1, e.categoryL2, e.categoryL3, e.manufacturer].map(f => f.toLowerCase());
      return keywords.every(kw => fields.some(f => f.includes(kw)));
    }).slice(0, 8);
  }, [searchText]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setDropdownOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelectItem = useCallback((item: EquipmentRecord) => {
    setSelectedItem(item);
    setMode('result');
    setDropdownOpen(false);
  }, []);

  const handleScan = () => {
    setScanAnim(true);
    setTimeout(() => {
      setScanAnim(false);
      const randomItem = EQUIPMENT_DB[Math.floor(Math.random() * EQUIPMENT_DB.length)];
      handleSelectItem(randomItem);
    }, 1500);
  };

  /* ═══════════ SCAN MODE ═══════════ */
  if (mode === 'scan') {
    return (
      <MobileLayout title="装备查询" showBack>
        <div className="p-5">
          <div ref={searchRef} className="relative mb-4">
            <div className="bg-white rounded-2xl shadow-sm p-3">
              <p className="text-sm text-gray-500 mb-2">输入关键词查询装备（编码/名称/型号/RFID/分类/厂商）</p>
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input ref={inputRef} type="text" value={searchText} onChange={e => { setSearchText(e.target.value); setDropdownOpen(e.target.value.trim().length > 0); }} onFocus={() => { if (searchText.trim().length > 0) setDropdownOpen(true); }} placeholder="输入关键词查询" className="w-full bg-gray-50 rounded-xl pl-9 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
              </div>
            </div>
            {dropdownOpen && (
              <div className="absolute z-50 left-0 right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden">
                {dropdownResults.length > 0 ? (
                  <div className="max-h-80 overflow-y-auto no-scrollbar">
                    <div className="px-3 py-2 bg-gray-50 text-[10px] text-gray-500">共找到 {dropdownResults.length} 种装备</div>
                    {dropdownResults.map(item => (
                      <button key={item.id} onClick={() => handleSelectItem(item)} className="w-full text-left px-4 py-3 hover:bg-blue-50 active:bg-blue-100 transition-colors border-b border-gray-50 last:border-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-semibold text-gray-800 font-mono"><HighlightText text={item.code} query={searchText} /></span>
                          <span className="text-gray-300">·</span>
                          <span className="text-sm text-gray-700"><HighlightText text={item.name} query={searchText} /></span>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-gray-400"><HighlightText text={item.model} query={searchText} /></span>
                          <span className="text-[10px] text-gray-300">|</span>
                          <span className="text-[10px] text-gray-400">{item.categoryL1}/{item.categoryL2}/{item.categoryL3}</span>
                          <span className="ml-auto text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded font-medium">库存{item.stockQty}{item.unit}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-400"><Database size={24} className="mx-auto mb-2" /><p className="text-sm">无对应装备信息</p><p className="text-xs mt-1">请尝试其他关键词</p></div>
                )}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
            <div className={`w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-4 transition-all ${scanAnim ? 'bg-blue-100 scale-95' : 'bg-blue-50'}`}>
              {scanAnim ? <RefreshCw size={40} className="text-blue-600 animate-spin" /> : <QrCode size={40} className="text-blue-600" />}
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{scanAnim ? '正在扫描...' : '扫描RFID编码或者标签'}</h3>
            <p className="text-xs text-gray-500 mb-6">{scanAnim ? '请对准装备RFID标签' : '点击按钮模拟扫描装备RFID标签'}</p>
            <button onClick={handleScan} disabled={scanAnim} className={`w-full py-3.5 rounded-xl font-medium transition-all ${scanAnim ? 'bg-gray-200 text-gray-400' : 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'}`}>{scanAnim ? '扫描中...' : '开始扫描'}</button>
          </div>

          <div className="mt-4 bg-blue-50 border border-blue-100 rounded-xl p-3">
            <p className="text-xs text-blue-600 font-medium mb-1">查询提示</p>
            <p className="text-[11px] text-blue-500">RFID编码为装备唯一识别凭证，一物一码，无重复、无失效</p>
            <p className="text-[11px] text-blue-500 mt-0.5">可尝试搜索：防弹、ZB-001、FDY、RFID2026</p>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ EMPTY ═══════════ */
  if (mode === 'empty') {
    return (
      <MobileLayout title="查询结果" showBack>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4"><Database size={36} className="text-gray-400" /></div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">无对应装备信息</h3>
          <p className="text-xs text-gray-400 text-center mb-6">请检查关键词是否正确，或重新扫描</p>
          <div className="w-full space-y-3">
            <button onClick={() => { setMode('scan'); setSearchText(''); setDropdownOpen(false); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors flex items-center justify-center gap-2"><RefreshCw size={16} /> 重新查询</button>
            <button onClick={handleScan} className="w-full bg-blue-50 text-[#1565c0] py-3 rounded-xl font-medium active:bg-blue-100 transition-colors flex items-center justify-center gap-2"><ScanLine size={16} /> 重新扫描</button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ RESULT ═══════════ */
  if (!selectedItem) return null;
  const e = selectedItem;

  return (
    <MobileLayout title="装备详情" showBack onBack={() => { setMode('scan'); setSearchText(''); setDropdownOpen(false); }}>
      <div className="p-4 space-y-3 pb-6">
        {/* 装备标题 */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center"><Package size={24} className="text-blue-600" /></div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-semibold text-gray-900">{e.name}</h3>
              <p className="text-xs text-gray-500 font-mono">{e.code}</p>
            </div>
          </div>
        </div>

        {/* 基本信息 */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2"><Tag size={14} className="text-blue-600" /> 基本信息</h3>
          <div className="space-y-2">
            {[
              { label: '装备编码', value: e.code },
              { label: '装备名称', value: e.name },
              { label: '所属分类', value: `${e.categoryL1} / ${e.categoryL2} / ${e.categoryL3}` },
              { label: '型号', value: e.model },
              { label: '型号编码', value: e.modelCode },
              { label: '计量单位', value: e.unit },
              { label: '是否电池', value: e.hasBattery ? '是' : '否', color: e.hasBattery ? 'text-green-600' : '' },
              { label: '保养周期(月)', value: `${e.maintenanceMonths} 月` },
              { label: '原厂商', value: e.manufacturer },
              { label: '标签', value: e.rfid, mono: true },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{item.label}</span>
                <span className={`text-xs font-medium text-gray-800 text-right ${item.mono ? 'font-mono' : ''} ${item.color || ''}`}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 附件资料 */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2"><FileText size={14} className="text-blue-600" /> 附件资料</h3>
          <div className="space-y-2">
            {/* 图片附件 */}
            <div className={`flex items-center justify-between py-2.5 px-3 rounded-xl ${e.hasImage ? 'bg-blue-50' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2">
                <Image size={16} className={e.hasImage ? 'text-blue-600' : 'text-gray-400'} />
                <span className={`text-xs font-medium ${e.hasImage ? 'text-blue-700' : 'text-gray-400'}`}>图片附件</span>
              </div>
              {e.hasImage ? (
                <button className="text-[10px] text-blue-600 bg-white px-2 py-1 rounded-lg border border-blue-200 active:bg-blue-50">查看</button>
              ) : (
                <span className="text-[10px] text-gray-400">暂无</span>
              )}
            </div>
            {/* 视频资料 */}
            <div className={`flex items-center justify-between py-2.5 px-3 rounded-xl ${e.hasVideo ? 'bg-green-50' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2">
                <Video size={16} className={e.hasVideo ? 'text-green-600' : 'text-gray-400'} />
                <span className={`text-xs font-medium ${e.hasVideo ? 'text-green-700' : 'text-gray-400'}`}>视频资料</span>
              </div>
              {e.hasVideo ? (
                <button className="text-[10px] text-green-600 bg-white px-2 py-1 rounded-lg border border-green-200 active:bg-green-50">查看</button>
              ) : (
                <span className="text-[10px] text-gray-400">暂无</span>
              )}
            </div>
            {/* 文档资料 */}
            <div className={`flex items-center justify-between py-2.5 px-3 rounded-xl ${e.hasDoc ? 'bg-orange-50' : 'bg-gray-50'}`}>
              <div className="flex items-center gap-2">
                <FileText size={16} className={e.hasDoc ? 'text-orange-600' : 'text-gray-400'} />
                <span className={`text-xs font-medium ${e.hasDoc ? 'text-orange-700' : 'text-gray-400'}`}>文档资料</span>
              </div>
              {e.hasDoc ? (
                <button className="text-[10px] text-orange-600 bg-white px-2 py-1 rounded-lg border border-orange-200 active:bg-orange-50">查看</button>
              ) : (
                <span className="text-[10px] text-gray-400">暂无</span>
              )}
            </div>
          </div>
        </div>

        {/* 返回按钮 */}
        <button onClick={() => { setMode('scan'); setSearchText(''); }} className="w-full bg-gray-100 text-gray-700 py-3 rounded-xl font-medium active:bg-gray-200 transition-colors">返回查询</button>
      </div>
    </MobileLayout>
  );
}
