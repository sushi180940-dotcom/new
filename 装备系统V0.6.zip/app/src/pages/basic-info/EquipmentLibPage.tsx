import { useState } from 'react'
import {
  ChevronRight, ChevronDown, Search, Plus, X, Eye,
  Image, Video, FileText, Battery, BatteryMedium,
  Pencil, Trash2, Upload, XCircle
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'

// ─── Types ───
interface CategoryNode {
  id: string
  name: string
  level: number
  children?: CategoryNode[]
}

type DetailTab = 'basic' | 'images' | 'videos' | 'docs'

interface Equipment {
  id: string
  code: string
  name: string
  category: string
  variety: string
  model: string
  modelCode: string
  unit: string
  brand: string
  spec: string
  material: string
  weight: string
  warranty: number
  hasBattery: '是' | '否'
  maintenanceMonths: number
  description: string
  images: string[]
  videos: string[]
  docs: string[]
  status: '启用' | '停用'
}

// ─── Category Tree ───
const categoryTree: CategoryNode[] = [
  { id: 'all', name: '全部装备', level: 0 },
  {
    id: 'c1', name: '防护装备', level: 0,
    children: [
      { id: 'v1', name: '防弹背心', level: 1, children: [{ id: 'm1', name: 'BV-III-A型', level: 2 }, { id: 'm2', name: 'BV-IV-B型', level: 2 }, { id: 'm3', name: '轻便型', level: 2 }] },
      { id: 'v2', name: '防弹头盔', level: 1, children: [{ id: 'm4', name: 'MICH2000', level: 2 }, { id: 'm5', name: 'PASGT', level: 2 }] },
      { id: 'v3', name: '防刺服', level: 1, children: [{ id: 'm6', name: 'FC-01软质', level: 2 }, { id: 'm7', name: 'FC-02硬质', level: 2 }] },
    ],
  },
  {
    id: 'c2', name: '警械装备', level: 0,
    children: [
      { id: 'v4', name: '手铐', level: 1, children: [{ id: 'm8', name: 'SK-01不锈钢', level: 2 }, { id: 'm9', name: 'SK-02钛合金', level: 2 }] },
      { id: 'v5', name: '警棍', level: 1, children: [{ id: 'm10', name: 'JG-01伸缩', level: 2 }, { id: 'm11', name: 'JG-02电击', level: 2 }] },
      { id: 'v6', name: '催泪喷射器', level: 1, children: [{ id: 'm12', name: 'CW-01手持式', level: 2 }, { id: 'm13', name: 'CW-02枪挂式', level: 2 }] },
    ],
  },
  {
    id: 'c3', name: '通信装备', level: 0,
    children: [
      { id: 'v7', name: '对讲机', level: 1, children: [{ id: 'm14', name: 'DJ-01数字', level: 2 }, { id: 'm15', name: 'DJ-02集群', level: 2 }] },
      { id: 'v8', name: '执法记录仪', level: 1, children: [{ id: 'm16', name: 'ZF-01高清', level: 2 }, { id: 'm17', name: 'ZF-02智能', level: 2 }] },
    ],
  },
  { id: 'c4', name: '交通装备', level: 0, children: [{ id: 'v9', name: '反光背心', level: 1, children: [{ id: 'm18', name: 'FG-01网眼', level: 2 }] }] },
  { id: 'c5', name: '侦查装备', level: 0, children: [{ id: 'v10', name: '指纹采集仪', level: 1, children: [{ id: 'm19', name: 'ZW-01便携', level: 2 }] }] },
  { id: 'c6', name: '照明装备', level: 0, children: [{ id: 'v11', name: '强光手电', level: 1, children: [{ id: 'm20', name: 'QD-01战术', level: 2 }] }] },
]

// ─── 15 Equipment Records ───
const equipmentList: Equipment[] = [
  { id: 'e1', code: 'EQ-2024-001', name: 'BV-III-A型防弹背心', category: '防护装备', variety: '防弹背心', model: 'BV-III-A', modelCode: 'MOD-BV3A-2024', unit: '件', brand: 'XX安防', spec: 'III级防护', material: '凯夫拉+碳化硼', weight: '4.2kg', warranty: 5, hasBattery: '否', maintenanceMonths: 12, description: '符合GA141-2010标准，模块化设计。', images: ['正面图','背面图','细节图','效果图'], videos: ['防弹测试','穿戴演示'], docs: ['说明书.pdf','检测报告.pdf'], status: '启用' },
  { id: 'e2', code: 'EQ-2024-002', name: 'BV-IV-B型防弹背心', category: '防护装备', variety: '防弹背心', model: 'BV-IV-B', modelCode: 'MOD-BV4B-2024', unit: '件', brand: 'XX安防', spec: 'IV级防护', material: 'UHMWPE+陶瓷', weight: '5.8kg', warranty: 5, hasBattery: '否', maintenanceMonths: 12, description: 'IV级防护，可抵御穿甲弹。', images: ['正面图','侧面图'], videos: ['测试视频'], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e3', code: 'EQ-2024-003', name: '轻便型防弹背心', category: '防护装备', variety: '防弹背心', model: '轻便型', modelCode: 'MOD-BVL-2024', unit: '件', brand: 'YY装备', spec: 'IIA级防护', material: '芳纶纤维', weight: '2.1kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '轻量化设计，适合长时间巡逻。', images: ['整体图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e4', code: 'EQ-2024-004', name: 'MICH2000防弹头盔', category: '防护装备', variety: '防弹头盔', model: 'MICH2000', modelCode: 'MOD-M2K-2024', unit: '顶', brand: 'YY装备', spec: 'IIIA级防护', material: '芳纶复合材料', weight: '1.5kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '符合GA293-2012标准，可装战术附件。', images: ['正面','侧面','内部'], videos: ['展示视频'], docs: ['说明书.pdf','检测报告.pdf'], status: '启用' },
  { id: 'e5', code: 'EQ-2024-005', name: 'PASGT防弹头盔', category: '防护装备', variety: '防弹头盔', model: 'PASGT', modelCode: 'MOD-PGT-2024', unit: '顶', brand: 'ZZ安防', spec: 'II级防护', material: '凯夫拉', weight: '1.4kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '经典款式，性价比高。', images: ['整体图'], videos: [], docs: ['说明书.pdf'], status: '停用' },
  { id: 'e6', code: 'EQ-2024-006', name: 'FC-01软质防刺服', category: '防护装备', variety: '防刺服', model: 'FC-01', modelCode: 'MOD-FC1-2024', unit: '件', brand: 'XX安防', spec: '软质防刺', material: '芳纶无纺布', weight: '1.8kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '柔软舒适，隐蔽性好。', images: ['外观图','内衬图'], videos: ['防刺测试'], docs: ['说明书.pdf','检测报告.pdf'], status: '启用' },
  { id: 'e7', code: 'EQ-2024-007', name: 'FC-02硬质防刺服', category: '防护装备', variety: '防刺服', model: 'FC-02', modelCode: 'MOD-FC2-2024', unit: '件', brand: 'XX安防', spec: '硬质防刺', material: '合金钢板+缓冲层', weight: '3.2kg', warranty: 5, hasBattery: '否', maintenanceMonths: 12, description: '防护等级更高，适合高危任务。', images: ['正面图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e8', code: 'EQ-2024-008', name: 'SK-01不锈钢手铐', category: '警械装备', variety: '手铐', model: 'SK-01', modelCode: 'MOD-SK1-2024', unit: '副', brand: 'ZZ警械', spec: '标准型', material: '304不锈钢', weight: '0.35kg', warranty: 10, hasBattery: '否', maintenanceMonths: 3, description: '双锁止设计，防拨性能优异。', images: ['整体图','锁芯图','钥匙图'], videos: ['使用方法'], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e9', code: 'EQ-2024-009', name: 'SK-02钛合金手铐', category: '警械装备', variety: '手铐', model: 'SK-02', modelCode: 'MOD-SK2-2024', unit: '副', brand: 'ZZ警械', spec: '轻型', material: '钛合金', weight: '0.22kg', warranty: 10, hasBattery: '否', maintenanceMonths: 3, description: '钛合金材质，轻量高强度。', images: ['整体图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e10', code: 'EQ-2024-010', name: 'JG-01伸缩警棍', category: '警械装备', variety: '警棍', model: 'JG-01', modelCode: 'MOD-JG1-2024', unit: '根', brand: 'ZZ警械', spec: '21寸伸缩', material: '4140合金钢', weight: '0.55kg', warranty: 5, hasBattery: '否', maintenanceMonths: 6, description: '三节伸缩，携带方便。', images: ['收缩图','伸展图'], videos: ['操作演示'], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e11', code: 'EQ-2024-011', name: 'DJ-01数字对讲机', category: '通信装备', variety: '对讲机', model: 'DJ-01', modelCode: 'MOD-DJ1-2024', unit: '台', brand: 'AA通信', spec: 'DMR数字制式', material: '工程塑料+铝合金', weight: '0.28kg', warranty: 2, hasBattery: '是', maintenanceMonths: 3, description: '数字模拟双模，IP67防水，待机72小时。', images: ['正面','侧面','配件'], videos: ['功能演示','防水测试'], docs: ['用户手册.pdf','频率配置.pdf'], status: '启用' },
  { id: 'e12', code: 'EQ-2024-012', name: 'DJ-02集群对讲机', category: '通信装备', variety: '对讲机', model: 'DJ-02', modelCode: 'MOD-DJ2-2024', unit: '台', brand: 'AA通信', spec: '集群通信', material: '铝合金机身', weight: '0.32kg', warranty: 2, hasBattery: '是', maintenanceMonths: 3, description: '支持集群调度，适合大规模行动。', images: ['正面图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e13', code: 'EQ-2024-013', name: 'ZF-01高清执法记录仪', category: '通信装备', variety: '执法记录仪', model: 'ZF-01', modelCode: 'MOD-ZF1-2024', unit: '台', brand: 'BB科技', spec: '1080P高清', material: 'ABS+PC', weight: '0.12kg', warranty: 2, hasBattery: '是', maintenanceMonths: 3, description: '140度广角，红外夜视，连续录像8小时。', images: ['主机图','佩戴图','夜视效果'], videos: ['操作视频','夜视演示'], docs: ['说明书.pdf','管理软件.pdf'], status: '启用' },
  { id: 'e14', code: 'EQ-2024-014', name: 'ZF-02智能执法记录仪', category: '通信装备', variety: '执法记录仪', model: 'ZF-02', modelCode: 'MOD-ZF2-2024', unit: '台', brand: 'BB科技', spec: '4K超清+AI', material: '镁合金', weight: '0.15kg', warranty: 2, hasBattery: '是', maintenanceMonths: 3, description: '4K录制，AI人脸识别，5G实时回传。', images: ['正面','背面','配件'], videos: ['AI功能','5G回传'], docs: ['说明书.pdf','AI配置.pdf'], status: '启用' },
  { id: 'e15', code: 'EQ-2024-015', name: 'CW-01手持式催泪喷射器', category: '警械装备', variety: '催泪喷射器', model: 'CW-01', modelCode: 'MOD-CW1-2024', unit: '支', brand: 'ZZ警械', spec: '手持式50ml', material: '铝合金罐体', weight: '0.08kg', warranty: 3, hasBattery: '否', maintenanceMonths: 12, description: '喷射距离3-5米，容量50ml。', images: ['外观图','喷嘴图'], videos: ['使用培训'], docs: ['说明书.pdf','安全规范.pdf'], status: '启用' },
]

function getCategoryFilterIds(catId: string): string[] {
  if (catId === 'all') return equipmentList.map(e => e.id)
  const node = categoryTree.find(n => n.id === catId)
  if (!node) return []
  const collect = (n: CategoryNode): string[] => {
    const names: string[] = []
    if (!n.children || n.children.length === 0) {
      names.push(n.name)
    } else {
      n.children.forEach(c => names.push(...collect(c)))
    }
    return names
  }
  const allNames = collect(node)
  return equipmentList.filter(e => allNames.some(name => e.name.includes(name) || e.variety === name || e.model === name || e.category === node.name)).map(e => e.id)
}

// ─── Tree Node ───
function TreeNode({
  node, selectedId, onSelect, expandedIds, onToggleExpand,
}: {
  node: CategoryNode
  selectedId: string | null
  onSelect: (id: string) => void
  expandedIds: Set<string>
  onToggleExpand: (id: string) => void
}) {
  const isExpanded = expandedIds.has(node.id)
  const hasChildren = node.children && node.children.length > 0
  const levelLabels = ['大类', '品种', '型号']
  return (
    <div>
      <div
        className={cn(
          'flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition',
          selectedId === node.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]'
        )}
        style={{ paddingLeft: `${8 + node.level * 16}px` }}
        onClick={() => {
          onSelect(node.id)
          if (hasChildren) onToggleExpand(node.id)
        }}
      >
        {hasChildren
          ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />)
          : <span className="w-3.5" />
        }
        <span className="mr-1 rounded bg-[#F3F4F6] px-1 text-[10px] text-[#6B7280]">{levelLabels[node.level] || ''}</span>
        <span className="truncate">{node.name}</span>
      </div>
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode key={child.id} node={child} selectedId={selectedId} onSelect={onSelect} expandedIds={expandedIds} onToggleExpand={onToggleExpand} />
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Image Tab with Upload ───
function EquipmentImageTab({ equipment }: { equipment: Equipment }) {
  const [images, setImages] = useState<{ name: string; url: string }[]>(
    equipment.images.map((name) => ({ name, url: '' }))
  )

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        setImages((prev) => [...prev, { name: file.name, url: ev.target?.result as string }])
      }
      reader.readAsDataURL(file)
    })
    e.target.value = ''
  }

  const handleRemove = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx))
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-base font-semibold text-[#1F2937]">
          <Image size={18} className="text-[#1A56DB]" />图片附件 ({images.length})
        </h3>
        <label className="inline-flex h-8 cursor-pointer items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white transition hover:bg-[#153E7E]">
          <Upload size={13} /> 上传图片
          <input type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
        </label>
      </div>
      {images.length > 0 ? (
        <div className="grid grid-cols-3 gap-4">
          {images.map((img, idx) => (
            <div key={idx} className="group relative aspect-square overflow-hidden rounded-lg border border-[#E5E7EB] bg-[#F3F4F6]">
              {img.url ? (
                <img src={img.url} alt={img.name} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center text-[#9CA3AF]"><Image size={32} /></div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-black/50 p-2">
                <p className="truncate text-xs text-white">{img.name}</p>
              </div>
              <button
                onClick={() => handleRemove(idx)}
                className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition hover:bg-[#DC2626] group-hover:opacity-100"
                title="删除"
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无图片附件</div>
      )}
    </div>
  )
}

// ─── Detail Drawer ───
function EquipmentDetailDrawer({ equipment, onClose }: { equipment: Equipment | null; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<DetailTab>('basic')
  if (!equipment) return null
  const tabs: { key: DetailTab; label: string }[] = [
    { key: 'basic', label: '基础信息' },
    { key: 'images', label: '图片附件' },
    { key: 'videos', label: '视频资料' },
    { key: 'docs', label: '文档资料' },
  ]
  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-full w-[720px] max-w-[95vw] flex-col bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">{equipment.name}</h2>
            <p className="text-xs text-[#6B7280]">{equipment.code} · {equipment.modelCode}</p>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        {/* Stats */}
        <div className="grid grid-cols-4 gap-3 border-b border-[#E5E7EB] bg-[#F9FAFB] px-6 py-3">
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">装备编码</div>
            <div className="mt-1 text-sm font-semibold text-[#1A56DB] truncate">{equipment.code}</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">是否电池</div>
            <div className="mt-1 text-sm font-semibold text-[#374151]">{equipment.hasBattery === '是'
              ? <span className="flex items-center gap-1 text-[#D97706]"><BatteryMedium size={14} />是</span>
              : <span className="flex items-center gap-1 text-[#6B7280]"><Battery size={14} />否</span>
            }</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">保养周期</div>
            <div className="mt-1 text-sm font-semibold text-[#374151]">{equipment.maintenanceMonths} 个月</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">状态</div>
            <div className="mt-1"><Badge variant={equipment.status === '启用' ? 'success' : 'default'}>{equipment.status}</Badge></div>
          </div>
        </div>
        {/* Tabs */}
        <div className="flex shrink-0 gap-0 border-b border-[#E5E7EB] bg-white px-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'px-4 py-3 text-sm font-medium transition border-b-2',
                activeTab === tab.key ? 'border-[#1A56DB] text-[#1A56DB]' : 'border-transparent text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        {/* Tab Content */}
        <div className="flex-1 overflow-auto p-6">
          {activeTab === 'basic' && (
            <div className="space-y-6">
              {/* 15 fields in 3-col grid */}
              <div className="grid grid-cols-3 gap-4">
                <div><label className="mb-1 block text-xs text-[#6B7280]">装备编码</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.code}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">装备名称</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm font-medium text-[#1F2937]">{equipment.name}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">所属分类</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.category}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">品种</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.variety}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">型号</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.model}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">型号编码</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.modelCode}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">计量单位</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.unit}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">品牌</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.brand}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">规格</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.spec}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">材质</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.material}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">重量</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.weight}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">质保期</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.warranty} 年</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">是否电池</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.hasBattery}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">保养周期(月)</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.maintenanceMonths}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">状态</label><div className="flex h-9 items-center"><Badge variant={equipment.status === '启用' ? 'success' : 'default'}>{equipment.status}</Badge></div></div>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">产品描述</label>
                <div className="rounded-md border border-[#E5E7EB] bg-[#F9FAFB] p-3 text-sm leading-relaxed text-[#374151]">{equipment.description}</div>
              </div>
            </div>
          )}
          {activeTab === 'images' && (
            <EquipmentImageTab equipment={equipment} />
          )}
          {activeTab === 'videos' && (
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-base font-semibold text-[#1F2937]"><Video size={18} className="text-[#EF4444]" />视频资料 ({equipment.videos.length})</h3>
              <div className="grid grid-cols-3 gap-4">
                {equipment.videos.map((vid, idx) => (
                  <div key={idx} className="flex flex-col items-center rounded-lg border border-[#E5E7EB] bg-[#F3F4F6] p-6">
                    <Video size={36} className="mb-3 text-[#EF4444]" />
                    <p className="text-center text-xs text-[#374151]">{vid}</p>
                  </div>
                ))}
              </div>
              {equipment.videos.length === 0 && <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无视频资料</div>}
            </div>
          )}
          {activeTab === 'docs' && (
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-base font-semibold text-[#1F2937]"><FileText size={18} className="text-[#10B981]" />文档资料 ({equipment.docs.length})</h3>
              <div className="space-y-2">
                {equipment.docs.map((doc, idx) => (
                  <div key={idx} className="flex items-center justify-between rounded-md border border-[#E5E7EB] px-4 py-3 text-sm text-[#374151] hover:bg-[#F9FAFB]">
                    <div className="flex items-center gap-2"><FileText size={16} className="text-[#10B981]" />{doc}</div>
                    <button className="text-xs text-[#1A56DB] hover:underline">预览</button>
                  </div>
                ))}
              </div>
              {equipment.docs.length === 0 && <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无文档资料</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Add Equipment Modal ───
function AddEquipmentModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [form, setForm] = useState({
    code: '', name: '', category: '防护装备', variety: '', model: '', modelCode: '',
    unit: '', brand: '', spec: '', material: '', weight: '', warranty: '',
    hasBattery: '否' as '是' | '否', maintenanceMonths: '', description: '',
  })
  const [uploadedImages, setUploadedImages] = useState<{ name: string; preview: string }[]>([])
  const [errors, setErrors] = useState<Record<string, boolean>>({})
  const fieldMeta: { key: string; label: string; type?: string; placeholder?: string }[] = [
    { key: 'code', label: '装备编码', placeholder: '如：EQ-2024-XXX' },
    { key: 'name', label: '装备名称' },
    { key: 'category', label: '所属分类' },
    { key: 'variety', label: '品种' },
    { key: 'model', label: '型号' },
    { key: 'modelCode', label: '型号编码', placeholder: '如：MOD-XXX-2024' },
    { key: 'unit', label: '计量单位', placeholder: '如：件/台/副' },
    { key: 'brand', label: '品牌' },
    { key: 'spec', label: '规格' },
    { key: 'material', label: '材质' },
    { key: 'weight', label: '重量', placeholder: '如：4.2kg' },
    { key: 'warranty', label: '质保期(年)', type: 'number' },
    { key: 'maintenanceMonths', label: '保养周期(月)', type: 'number' },
  ]
  const validate = () => {
    const required = ['code', 'name', 'category', 'variety', 'model', 'modelCode', 'unit']
    const errs: Record<string, boolean> = {}
    let ok = true
    required.forEach((k) => {
      if (!form[k as keyof typeof form]?.toString().trim()) {
        errs[k] = true; ok = false
      }
    })
    setErrors(errs)
    return ok
  }
  const handleSubmit = () => {
    if (!validate()) return
    onClose()
  }
  const handleChange = (key: string, val: string) => {
    setForm((prev) => ({ ...prev, [key]: val }))
    if (errors[key]) setErrors((prev) => { const n = { ...prev }; delete n[key]; return n })
  }
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        setUploadedImages((prev) => [...prev, { name: file.name, preview: ev.target?.result as string }])
      }
      reader.readAsDataURL(file)
    })
    e.target.value = ''
  }
  const handleRemoveImage = (idx: number) => {
    setUploadedImages((prev) => prev.filter((_, i) => i !== idx))
  }
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose() }}>
      <DialogContent className="max-h-[90vh] overflow-auto sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="text-base font-semibold text-[#1F2937]">新增装备基础信息</DialogTitle>
        </DialogHeader>
        <div className="mt-2 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            {fieldMeta.map((f) => (
              <div key={f.key}>
                <label className="mb-1 block text-xs text-[#374151]">{f.label}{['code','name','category','variety','model','modelCode','unit'].includes(f.key) && <span className="text-[#EF4444]">*</span>}</label>
                <input
                  type={f.type || 'text'}
                  placeholder={f.placeholder || ''}
                  value={form[f.key as keyof typeof form] as string}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                  className={cn(
                    'h-8 w-full rounded-md border px-2.5 text-sm outline-none transition',
                    errors[f.key] ? 'border-[#EF4444] bg-[#FEF2F2]' : 'border-[#D1D5DB] bg-white focus:border-[#1A56DB] focus:ring-1 focus:ring-[#1A56DB]'
                  )}
                />
                {errors[f.key] && <p className="mt-0.5 text-[11px] text-[#EF4444]">必填</p>}
              </div>
            ))}
            <div>
              <label className="mb-1 block text-xs text-[#374151]">是否电池</label>
              <div className="flex h-8 gap-2">
                {(['否', '是'] as const).map((v) => (
                  <button key={v} onClick={() => handleChange('hasBattery', v)} className={cn(
                    'flex-1 rounded-md border text-xs font-medium transition',
                    form.hasBattery === v ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#6B7280] hover:border-[#9CA3AF]'
                  )}>{v}</button>
                ))}
              </div>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-[#374151]">产品描述</label>
            <textarea
              rows={3}
              placeholder="请输入装备的功能描述、技术特点等信息..."
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="w-full rounded-md border border-[#D1D5DB] bg-white px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-1 focus:ring-[#1A56DB]"
            />
          </div>
          {/* 图片上传 */}
          <div>
            <label className="mb-2 block text-xs text-[#374151]">装备图片</label>
            <div className="rounded-lg border border-dashed border-[#D1D5DB] bg-[#F9FAFB] p-4">
              <label className="flex cursor-pointer flex-col items-center justify-center gap-1 rounded-md py-4 transition hover:bg-[#F3F4F6]">
                <Upload size={20} className="text-[#6B7280]" />
                <span className="text-xs text-[#6B7280]">点击上传装备图片</span>
                <span className="text-[10px] text-[#9CA3AF]">支持 JPG、PNG 格式</span>
                <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
              </label>
              {uploadedImages.length > 0 && (
                <div className="mt-3 grid grid-cols-4 gap-2">
                  {uploadedImages.map((img, idx) => (
                    <div key={idx} className="group relative aspect-square overflow-hidden rounded-md border border-[#E5E7EB] bg-white">
                      <img src={img.preview} alt={img.name} className="h-full w-full object-cover" />
                      <button
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute right-0.5 top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition hover:bg-black/80 group-hover:opacity-100"
                      >
                        <XCircle size={12} />
                      </button>
                      <p className="absolute inset-x-0 bottom-0 truncate bg-black/50 px-1 py-0.5 text-[10px] text-white">{img.name}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSubmit} className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">保存</button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ─── Main Page ───
export default function EquipmentLibPage() {
  const [selectedCatId, setSelectedCatId] = useState<string>('all')
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['c1', 'c2', 'c3', 'c4', 'c5', 'c6']))
  const [searchText, setSearchText] = useState('')
  const [detailEq, setDetailEq] = useState<Equipment | null>(null)
  const [showAdd, setShowAdd] = useState(false)

  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  }

  // Filter equipment
  const filtered = equipmentList.filter((eq) => {
    // Category filter
    if (selectedCatId !== 'all') {
      const ids = getCategoryFilterIds(selectedCatId)
      if (!ids.includes(eq.id)) return false
    }
    // Search filter
    if (searchText.trim()) {
      const s = searchText.toLowerCase()
      return eq.code.toLowerCase().includes(s) || eq.name.toLowerCase().includes(s) || eq.model.toLowerCase().includes(s) || eq.brand.toLowerCase().includes(s) || eq.category.toLowerCase().includes(s)
    }
    return true
  })

  // Pagination (simple)
  const pageSize = 10
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safePage = Math.min(currentPage, totalPages)
  const paginated = filtered.slice((safePage - 1) * pageSize, safePage * pageSize)

  const sV = (s: string) => s === '启用' ? 'success' : 'default'

  return (
    <div className="flex gap-4" style={{ minHeight: 'calc(100dvh - 200px)' }}>
      {/* Left: Category Tree */}
      <div className="w-56 flex-shrink-0 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="border-b border-[#E5E7EB] px-3 py-3">
          <h3 className="text-sm font-semibold text-[#1F2937]">装备分类</h3>
        </div>
        <div className="p-2">
          {categoryTree.map((node) => (
            <TreeNode key={node.id} node={node} selectedId={selectedCatId} onSelect={setSelectedCatId} expandedIds={expandedIds} onToggleExpand={toggleExpand} />
          ))}
        </div>
      </div>

      {/* Right: Equipment List */}
      <div className="min-w-0 flex-1 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
          <h3 className="text-sm font-semibold text-[#1F2937]">装备基础信息列表 <span className="ml-1 text-xs font-normal text-[#6B7280]">({filtered.length} 条)</span></h3>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-md border border-[#D1D5DB] px-2 py-1">
              <Search size={12} className="text-[#9CA3AF]" />
              <input
                type="text" placeholder="搜索编码/名称/型号/品牌..."
                value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="w-48 bg-transparent text-xs outline-none"
              />
            </div>
            <button onClick={() => setShowAdd(true)} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white transition hover:bg-[#153E7E]">
              <Plus size={13} /> 新增装备
            </button>
            <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> 导入
            </button>
            <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> 导出
            </button>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">序号</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备编码</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备名称</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">所属分类</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">型号</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">型号编码</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">计量单位</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">是否电池</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">保养周期(月)</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((eq, idx) => (
                <tr key={eq.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-3 py-2.5 text-[#6B7280]">{(safePage - 1) * pageSize + idx + 1}</td>
                  <td className="px-3 py-2.5 font-mono text-xs text-[#1A56DB]">{eq.code}</td>
                  <td className="px-3 py-2.5 font-medium text-[#374151]">{eq.name}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.category}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.model}</td>
                  <td className="px-3 py-2.5 font-mono text-xs text-[#6B7280]">{eq.modelCode}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.unit}</td>
                  <td className="px-3 py-2.5">
                    {eq.hasBattery === '是'
                      ? <span className="flex items-center gap-1 text-xs text-[#D97706]"><BatteryMedium size={12} />是</span>
                      : <span className="flex items-center gap-1 text-xs text-[#6B7280]"><Battery size={12} />否</span>
                    }
                  </td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.maintenanceMonths}</td>
                  <td className="px-3 py-2.5"><Badge variant={sV(eq.status)}>{eq.status}</Badge></td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setDetailEq(eq)} className="rounded p-1 text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="查看"><Eye size={14} /></button>
                      <button className="rounded p-1 text-[#F59E0B] transition hover:bg-[#FEF3C7]" title="编辑"><Pencil size={14} /></button>
                      <button className="rounded p-1 text-[#EF4444] transition hover:bg-[#FEF2F2]" title="删除"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {paginated.length === 0 && (
            <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无装备数据</div>
          )}
        </div>

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-2.5">
            <span className="text-xs text-[#6B7280]">显示 {(safePage - 1) * pageSize + 1}-{Math.min(safePage * pageSize, filtered.length)} / 共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={safePage <= 1} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">上一页</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setCurrentPage(p)} className={cn(
                  'h-7 w-7 rounded-md text-xs font-medium transition',
                  safePage === p ? 'bg-[#1A56DB] text-white' : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                )}>{p}</button>
              ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={safePage >= totalPages} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">下一页</button>
            </div>
          </div>
        )}
      </div>

      {/* Detail Drawer */}
      {detailEq && <EquipmentDetailDrawer equipment={detailEq} onClose={() => setDetailEq(null)} />}

      {/* Add Modal */}
      <AddEquipmentModal open={showAdd} onClose={() => setShowAdd(false)} />
    </div>
  )
}
