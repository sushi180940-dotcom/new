import { useState, useRef, useEffect } from 'react'
import {
  ChevronRight, ChevronDown, ChevronLeft, Warehouse, Search, Upload, Download, Plus,
  Eye, Edit3, Trash2, X, CheckCircle, Package,
  ShieldCheck, TrendingDown, Building2, MapPin, Locate, Layers, Grid3x3,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ═══════════════════════════════════════════
   类型定义 - 3层结构：仓库 → 分区 → 货架
   ═══════════════════════════════════════════ */

interface OrgNode { id: string; name: string; level: number; children?: OrgNode[] }

interface ShelfItem {
  id: string
  name: string
  code: string
  shelfType: string
  capacity: number
  sortOrder: number
  zoneName: string
}

interface ZoneItem {
  id: string
  name: string
  code: string
  zoneType: string
  sortOrder: number
  shelves: ShelfItem[]
}

interface WarehouseItem {
  id: string
  code: string
  name: string
  address: string
  longitude: string
  latitude: string
  roomType: '实体' | '虚拟'
  parentNode: string
  orgUnit: string
  orgLevel: '省' | '市' | '县'
  manager: string
  phone: string
  sortOrder: number
  remark: string
  status: '启用' | '停用'
  zones: ZoneItem[]
}

interface SafetyStockItem { id: string; equipName: string; category: string; currentStock: number; threshold: number; diff: number; status: '正常' | '低于安全线' }

const orgTree: OrgNode[] = [{
  id: 'h1', name: '河南省公安厅', level: 0,
  children: [{ id: 'c1', name: '郑州市公安局', level: 1, children: [{ id: 'd1', name: '金水区公安分局', level: 2, children: [{ id: 's1', name: '花园路派出所', level: 3 }, { id: 's2', name: '经八路派出所', level: 3 }] }, { id: 'd2', name: '二七区公安分局', level: 2, children: [{ id: 's3', name: '大学路派出所', level: 3 }] }, { id: 'd3', name: '中原区公安分局', level: 2, children: [{ id: 's4', name: '建设路派出所', level: 3 }] }] }, { id: 'c2', name: '洛阳市公安局', level: 1, children: [{ id: 'd4', name: '西工区公安分局', level: 2, children: [{ id: 's5', name: '王城路派出所', level: 3 }] }] }, { id: 'c3', name: '开封市公安局', level: 1, children: [{ id: 'd5', name: '鼓楼区公安分局', level: 2, children: [{ id: 's6', name: '相国寺派出所', level: 3 }] }] }, { id: 'c4', name: '新乡市公安局', level: 1, children: [{ id: 'd6', name: '牧野区公安分局', level: 2, children: [{ id: 's7', name: '北干道派出所', level: 3 }] }] }, { id: 'c5', name: '许昌市公安局', level: 1, children: [{ id: 'd7', name: '魏都区公安分局', level: 2, children: [{ id: 's8', name: '南关派出所', level: 3 }] }] }],
}]

/* ═══════════════════════════════════════════
   Mock 数据 - 仓库（含经纬度）
   ═══════════════════════════════════════════ */

const warehouseList: WarehouseItem[] = [
  { id: '1', code: 'CK-2024-001', name: '省厅主装备仓库', address: '郑州市金水区农业路1号', longitude: '113.6653', latitude: '34.7689', roomType: '实体', parentNode: '', orgUnit: '河南省公安厅', orgLevel: '省', manager: '王建国', phone: '0371-88880001', sortOrder: 1, remark: '一级防护，24小时值守', status: '启用', zones: [
    { id: 'z1', name: '收货区', code: 'FQ-SH-001', zoneType: '收货区', sortOrder: 1, shelves: [{ id: 's1', name: '收货货架A', code: 'HJ-SH-A01', shelfType: '中型货架', capacity: 200, sortOrder: 1, zoneName: '收货区' }, { id: 's2', name: '收货货架B', code: 'HJ-SH-B01', shelfType: '中型货架', capacity: 200, sortOrder: 2, zoneName: '收货区' }] },
    { id: 'z2', name: '存储区', code: 'FQ-CC-001', zoneType: '存储区', sortOrder: 2, shelves: [{ id: 's3', name: '存储货架A01', code: 'HJ-CC-A01', shelfType: '重型货架', capacity: 500, sortOrder: 1, zoneName: '存储区' }, { id: 's4', name: '存储货架A02', code: 'HJ-CC-A02', shelfType: '重型货架', capacity: 500, sortOrder: 2, zoneName: '存储区' }, { id: 's5', name: '存储货架B01', code: 'HJ-CC-B01', shelfType: '中型货架', capacity: 300, sortOrder: 3, zoneName: '存储区' }] },
    { id: 'z3', name: '拣货区', code: 'FQ-JH-001', zoneType: '拣货区', sortOrder: 3, shelves: [{ id: 's6', name: '拣货货架A', code: 'HJ-JH-A01', shelfType: '轻型货架', capacity: 150, sortOrder: 1, zoneName: '拣货区' }] },
  ]},
  { id: '2', code: 'CK-2024-002', name: '省厅应急物资仓库', address: '郑州市郑东新区商务外环22号', longitude: '113.7206', latitude: '34.7698', roomType: '实体', parentNode: '省厅主装备仓库', orgUnit: '河南省公安厅', orgLevel: '省', manager: '李卫国', phone: '0371-88880002', sortOrder: 2, remark: '存放应急装备', status: '启用', zones: [
    { id: 'z4', name: '存储区', code: 'FQ-CC-002', zoneType: '存储区', sortOrder: 1, shelves: [{ id: 's7', name: '应急货架A', code: 'HJ-YJ-A01', shelfType: '重型货架', capacity: 400, sortOrder: 1, zoneName: '存储区' }] },
  ]},
  { id: '3', code: 'CK-2024-003', name: '郑州市局装备仓库', address: '郑州市二七区大学路88号', longitude: '113.6485', latitude: '34.7243', roomType: '实体', parentNode: '', orgUnit: '郑州市公安局', orgLevel: '市', manager: '张志强', phone: '0371-88880033', sortOrder: 1, remark: '市局主力仓库', status: '启用', zones: [
    { id: 'z5', name: '收货区', code: 'FQ-SH-003', zoneType: '收货区', sortOrder: 1, shelves: [{ id: 's8', name: '收货货架', code: 'HJ-SH-001', shelfType: '中型货架', capacity: 200, sortOrder: 1, zoneName: '收货区' }] },
    { id: 'z6', name: '存储区', code: 'FQ-CC-003', zoneType: '存储区', sortOrder: 2, shelves: [{ id: 's9', name: '存储货架A', code: 'HJ-CC-A01', shelfType: '重型货架', capacity: 500, sortOrder: 1, zoneName: '存储区' }, { id: 's10', name: '存储货架B', code: 'HJ-CC-B01', shelfType: '重型货架', capacity: 500, sortOrder: 2, zoneName: '存储区' }] },
  ]},
  { id: '4', code: 'CK-2024-004', name: '郑州市局城南分库', address: '郑州市管城回族区城南路45号', longitude: '113.6832', latitude: '34.7387', roomType: '实体', parentNode: '郑州市局装备仓库', orgUnit: '郑州市公安局', orgLevel: '市', manager: '赵明辉', phone: '0371-88880044', sortOrder: 2, remark: '城南片区调拨', status: '启用', zones: [] },
  { id: '5', code: 'CK-2024-005', name: '金水区分局仓库', address: '郑州市金水区花园路120号', longitude: '113.6721', latitude: '34.7865', roomType: '实体', parentNode: '', orgUnit: '金水区公安分局', orgLevel: '县', manager: '陈建华', phone: '0371-88880055', sortOrder: 1, remark: '分局级装备库', status: '启用', zones: [
    { id: 'z7', name: '综合区', code: 'FQ-ZH-005', zoneType: '存储区', sortOrder: 1, shelves: [{ id: 's11', name: '综合货架', code: 'HJ-ZH-001', shelfType: '中型货架', capacity: 300, sortOrder: 1, zoneName: '综合区' }] },
  ]},
  { id: '6', code: 'CK-2024-006', name: '二七区分局仓库', address: '郑州市二七区淮河路66号', longitude: '113.6354', latitude: '34.7156', roomType: '实体', parentNode: '', orgUnit: '二七区公安分局', orgLevel: '县', manager: '刘向阳', phone: '0371-88880066', sortOrder: 1, remark: '分区管理', status: '启用', zones: [] },
  { id: '7', code: 'CK-2024-007', name: '洛阳市局装备仓库', address: '洛阳市洛龙区开元大道258号', longitude: '112.4540', latitude: '34.6187', roomType: '实体', parentNode: '', orgUnit: '洛阳市公安局', orgLevel: '市', manager: '孙卫东', phone: '0379-88880077', sortOrder: 1, remark: '副中心仓库', status: '启用', zones: [
    { id: 'z8', name: '存储区', code: 'FQ-CC-007', zoneType: '存储区', sortOrder: 1, shelves: [{ id: 's12', name: '主货架A', code: 'HJ-ZH-A01', shelfType: '重型货架', capacity: 600, sortOrder: 1, zoneName: '存储区' }] },
  ]},
  { id: '8', code: 'CK-2024-008', name: '西工区分局仓库', address: '洛阳市西工区中州中路168号', longitude: '112.4356', latitude: '34.6623', roomType: '实体', parentNode: '', orgUnit: '西工区公安分局', orgLevel: '县', manager: '周文斌', phone: '0379-88880088', sortOrder: 1, remark: '洛阳西工片区', status: '停用', zones: [] },
  { id: '9', code: 'CK-2024-009', name: '开封市局装备仓库', address: '开封市鼓楼区中山路88号', longitude: '114.3532', latitude: '34.7931', roomType: '虚拟', parentNode: '', orgUnit: '开封市公安局', orgLevel: '市', manager: '吴海涛', phone: '0378-88880099', sortOrder: 1, remark: '开封主仓库', status: '启用', zones: [] },
  { id: '10', code: 'CK-2024-010', name: '新乡市局装备仓库', address: '新乡市红旗区平原路112号', longitude: '113.9270', latitude: '35.3020', roomType: '实体', parentNode: '', orgUnit: '新乡市公安局', orgLevel: '市', manager: '郑国华', phone: '0373-88880100', sortOrder: 1, remark: '豫北片区', status: '启用', zones: [] },
  { id: '11', code: 'CK-2024-011', name: '牧野区分局仓库', address: '新乡市牧野区北环路55号', longitude: '113.9087', latitude: '35.3215', roomType: '实体', parentNode: '新乡市局装备仓库', orgUnit: '牧野区公安分局', orgLevel: '县', manager: '钱志明', phone: '0373-88880111', sortOrder: 1, remark: '牧野片区专用', status: '启用', zones: [] },
  { id: '12', code: 'CK-2024-012', name: '许昌市局装备仓库', address: '许昌市魏都区七一路77号', longitude: '113.8482', latitude: '34.0357', roomType: '实体', parentNode: '', orgUnit: '许昌市公安局', orgLevel: '市', manager: '冯德全', phone: '0374-88880122', sortOrder: 1, remark: '许昌主仓库', status: '启用', zones: [] },
]

const safetyStockData: SafetyStockItem[] = [
  { id: '1', equipName: '防弹背心', category: '防护装备', currentStock: 180, threshold: 200, diff: -20, status: '低于安全线' },
  { id: '2', equipName: '防刺服', category: '防护装备', currentStock: 480, threshold: 300, diff: 180, status: '正常' },
  { id: '3', equipName: '执法记录仪', category: '通信装备', currentStock: 145, threshold: 150, diff: -5, status: '低于安全线' },
  { id: '4', equipName: '对讲机', category: '通信装备', currentStock: 95, threshold: 100, diff: -5, status: '低于安全线' },
  { id: '5', equipName: '警用头盔', category: '防护装备', currentStock: 280, threshold: 250, diff: 30, status: '正常' },
  { id: '6', equipName: '催泪喷射器', category: '警械装备', currentStock: 320, threshold: 200, diff: 120, status: '正常' },
  { id: '7', equipName: '手铐', category: '警械装备', currentStock: 500, threshold: 400, diff: 100, status: '正常' },
  { id: '8', equipName: '强光手电', category: '照明装备', currentStock: 88, threshold: 120, diff: -32, status: '低于安全线' },
  { id: '9', equipName: '防割手套', category: '防护装备', currentStock: 260, threshold: 200, diff: 60, status: '正常' },
  { id: '10', equipName: '警棍', category: '警械装备', currentStock: 420, threshold: 350, diff: 70, status: '正常' },
  { id: '11', equipName: '反光背心', category: '交通装备', currentStock: 150, threshold: 180, diff: -30, status: '低于安全线' },
  { id: '12', equipName: '急救包', category: '医疗装备', currentStock: 95, threshold: 100, diff: -5, status: '低于安全线' },
]

function TreeNode({ node, selectedId, onSelect, expandedIds, onToggleExpand }: { node: OrgNode; selectedId: string | null; onSelect: (id: string) => void; expandedIds: Set<string>; onToggleExpand: (id: string) => void }) {
  const isExpanded = expandedIds.has(node.id), hasChildren = node.children && node.children.length > 0
  const levelNames = ['省', '市', '县', '所'], levelColors = ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6']
  return <div><div className={cn('flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition', selectedId === node.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')} style={{ paddingLeft: `${8 + node.level * 16}px` }} onClick={() => { onSelect(node.id); if (hasChildren) onToggleExpand(node.id) }}>{hasChildren ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />) : <span className="w-3.5" />}<span className="mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white" style={{ backgroundColor: levelColors[node.level] || '#6B7280' }}>{levelNames[node.level] || '?'}</span><span className="truncate">{node.name}</span></div>{hasChildren && isExpanded && <div>{node.children!.map((c) => <TreeNode key={c.id} node={c} selectedId={selectedId} onSelect={onSelect} expandedIds={expandedIds} onToggleExpand={onToggleExpand} />)}</div>}</div>
}

function SimpleTable({ columns, data }: { columns: any[]; data: Record<string, any>[] }) {
  return <div className="overflow-x-auto"><table className="w-full text-sm"><thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">{columns.map((c) => <th key={c.key} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{c.title}</th>)}</tr></thead><tbody>{data.map((row, i) => <tr key={i} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">{columns.map((c) => <td key={c.key} className="px-3 py-2.5 text-[#374151]">{c.render ? c.render(row[c.key]) : row[c.key]}</td>)}</tr>)}</tbody></table>{data.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无数据</div>}</div>
}

/* ═══════════════════════════════════════════
   3层结构树形导航：仓库 → 分区 → 货架
   ═══════════════════════════════════════════ */

function ZoneShelfTree({ zones, onSelectShelf }: { zones: ZoneItem[]; onSelectShelf?: (shelf: ShelfItem, zone: ZoneItem) => void }) {
  const [expandedZones, setExpandedZones] = useState<Set<string>>(new Set(zones.length > 0 ? [zones[0].id] : []))
  const toggleZone = (zId: string) => {
    setExpandedZones(prev => { const n = new Set(prev); if (n.has(zId)) n.delete(zId); else n.add(zId); return n })
  }
  if (zones.length === 0) {
    return <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无分区数据</div>
  }
  return (
    <div className="space-y-1">
      {zones.map(zone => {
        const isExpanded = expandedZones.has(zone.id)
        return (
          <div key={zone.id}>
            <button onClick={() => toggleZone(zone.id)} className={cn('flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-sm transition hover:bg-[#F3F4F6]', isExpanded && 'bg-[#E8F0FE] text-[#1A56DB]')}>
              {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <Layers size={13} />
              <span className="font-medium">{zone.name}</span>
              <Badge variant="info" className="ml-1 text-[10px]">{zone.zoneType}</Badge>
              <span className="ml-auto text-[11px] text-[#6B7280]">{zone.shelves.length}个货架</span>
            </button>
            {isExpanded && (
              <div className="ml-5 mt-0.5 space-y-0.5 border-l border-[#E5E7EB] pl-2">
                {zone.shelves.length > 0 ? zone.shelves.map(shelf => (
                  <button key={shelf.id} onClick={() => onSelectShelf?.(shelf, zone)} className="flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
                    <Grid3x3 size={12} className="text-[#10B981]" />
                    <span>{shelf.name}</span>
                    <span className="text-[11px] text-[#6B7280]">{shelf.code}</span>
                    <span className="ml-auto text-[11px] text-[#6B7280]">容量{shelf.capacity}</span>
                  </button>
                )) : (
                  <div className="px-2 py-1.5 text-[11px] text-[#9CA3AF]">该分区暂无货架</div>
                )}
              </div>
            )}
          </div>
        )
      })}
    </div>
  )
}

/* ═══════════════════════════════════════════
   仓库新增/编辑表单弹窗
   ═══════════════════════════════════════════ */

/* ═══════════════════════════════════════════
   仓库新增/编辑表单弹窗 - 支持分区/货架维护
   ═══════════════════════════════════════════ */

function WarehouseForm({ open, warehouse, onClose, onSave }: { open: boolean; warehouse?: WarehouseItem | null; onClose: () => void; onSave: (w: WarehouseItem) => void }) {
  const [form, setForm] = useState<Partial<WarehouseItem>>({
    code: '', name: '', address: '', longitude: '', latitude: '', roomType: '实体', parentNode: '',
    orgUnit: '', orgLevel: '县', manager: '', phone: '', sortOrder: 1, remark: '', status: '启用',
    zones: [],
  })
  const [errors, setErrors] = useState<Record<string, boolean>>({})
  const [areaTab, setAreaTab] = useState<'warehouse' | 'zone' | 'shelf'>('warehouse')
  const [selectedShelf, setSelectedShelf] = useState<{ shelf: ShelfItem; zone: ZoneItem } | null>(null)

  /* ═════ 分区/货架 维护状态 ═════ */
  const [zones, setZones] = useState<ZoneItem[]>([])
  const [zoneFormOpen, setZoneFormOpen] = useState(false)
  const [editingZone, setEditingZone] = useState<ZoneItem | null>(null)
  const [zoneName, setZoneName] = useState('')
  const [zoneCode, setZoneCode] = useState('')
  const [zoneType, setZoneType] = useState('存储区')
  const [zoneSort, setZoneSort] = useState('1')

  const [shelfFormOpen, setShelfFormOpen] = useState(false)
  const [shelfParentZoneId, setShelfParentZoneId] = useState<string | null>(null)
  const [editingShelf, setEditingShelf] = useState<{ shelf: ShelfItem; zoneId: string } | null>(null)
  const [shelfName, setShelfName] = useState('')
  const [shelfCode, setShelfCode] = useState('')
  const [shelfType, setShelfType] = useState('中型货架')
  const [shelfCapacity, setShelfCapacity] = useState('200')
  const [shelfSort, setShelfSort] = useState('1')

  useEffect(() => {
    if (warehouse) {
      const initForm = { ...warehouse }
      setForm(initForm)
      setZones(initForm.zones ? JSON.parse(JSON.stringify(initForm.zones)) : [])
    } else {
      setForm({ code: '', name: '', address: '', longitude: '', latitude: '', roomType: '实体', parentNode: '', orgUnit: '', orgLevel: '县', manager: '', phone: '', sortOrder: 1, remark: '', status: '启用', zones: [] })
      setZones([])
    }
    setErrors({})
    setSelectedShelf(null)
    resetZoneForm()
    resetShelfForm()
  }, [warehouse, open])

  const resetZoneForm = () => {
    setZoneFormOpen(false); setEditingZone(null); setZoneName(''); setZoneCode(''); setZoneType('存储区'); setZoneSort('1')
  }
  const resetShelfForm = () => {
    setShelfFormOpen(false); setEditingShelf(null); setShelfParentZoneId(null); setShelfName(''); setShelfCode(''); setShelfType('中型货架'); setShelfCapacity('200'); setShelfSort('1')
  }

  const handleChange = (key: string, val: string | number) => {
    setForm(prev => ({ ...prev, [key]: val }))
    if (errors[key]) setErrors(prev => { const n = { ...prev }; delete n[key]; return n })
  }

  if (!open) return null

  /* ═════ 分区 CRUD ═════ */
  const openAddZone = () => { resetZoneForm(); setZoneFormOpen(true) }
  const openEditZone = (z: ZoneItem) => {
    setEditingZone(z); setZoneName(z.name); setZoneCode(z.code); setZoneType(z.zoneType); setZoneSort(String(z.sortOrder))
    setZoneFormOpen(true)
  }
  const handleSaveZone = () => {
    if (!zoneName.trim()) { alert('请输入分区名称'); return }
    if (!zoneCode.trim()) { alert('请输入分区编码'); return }
    if (editingZone) {
      setZones(prev => prev.map(z => z.id === editingZone.id ? { ...z, name: zoneName.trim(), code: zoneCode.trim(), zoneType, sortOrder: parseInt(zoneSort) || 1 } : z))
    } else {
      const newZ: ZoneItem = { id: `z-${Date.now()}`, name: zoneName.trim(), code: zoneCode.trim(), zoneType, sortOrder: parseInt(zoneSort) || 1, shelves: [] }
      setZones(prev => [...prev, newZ])
    }
    resetZoneForm()
  }
  const handleDeleteZone = (zId: string) => {
    if (!confirm('确定删除该分区？其下货架也将一并删除。')) return
    setZones(prev => prev.filter(z => z.id !== zId))
    if (selectedShelf?.zone.id === zId) setSelectedShelf(null)
  }

  /* ═════ 货架 CRUD ═════ */
  const openAddShelf = (zoneId: string) => { resetShelfForm(); setShelfParentZoneId(zoneId); setShelfFormOpen(true) }
  const openEditShelf = (shelf: ShelfItem, zoneId: string) => {
    setEditingShelf({ shelf, zoneId }); setShelfName(shelf.name); setShelfCode(shelf.code); setShelfType(shelf.shelfType); setShelfCapacity(String(shelf.capacity)); setShelfSort(String(shelf.sortOrder))
    setShelfFormOpen(true)
  }
  const handleSaveShelf = () => {
    if (!shelfName.trim()) { alert('请输入货架名称'); return }
    if (!shelfCode.trim()) { alert('请输入货架编码'); return }
    if (!shelfParentZoneId && !editingShelf) { alert('请先选择所属分区'); return }
    const targetZoneId = editingShelf ? editingShelf.zoneId : shelfParentZoneId!
    if (editingShelf) {
      setZones(prev => prev.map(z => {
        if (z.id !== targetZoneId) return z
        return { ...z, shelves: z.shelves.map(s => s.id === editingShelf.shelf.id ? { ...s, name: shelfName.trim(), code: shelfCode.trim(), shelfType, capacity: parseInt(shelfCapacity) || 0, sortOrder: parseInt(shelfSort) || 1, zoneName: z.name } : s) }
      }))
    } else {
      const newS: ShelfItem = { id: `s-${Date.now()}`, name: shelfName.trim(), code: shelfCode.trim(), shelfType, capacity: parseInt(shelfCapacity) || 0, sortOrder: parseInt(shelfSort) || 1, zoneName: zones.find(z => z.id === targetZoneId)?.name || '' }
      setZones(prev => prev.map(z => z.id === targetZoneId ? { ...z, shelves: [...z.shelves, newS] } : z))
    }
    resetShelfForm()
  }
  const handleDeleteShelf = (shelfId: string, zoneId: string) => {
    if (!confirm('确定删除该货架？')) return
    setZones(prev => prev.map(z => z.id === zoneId ? { ...z, shelves: z.shelves.filter(s => s.id !== shelfId) } : z))
    if (selectedShelf?.shelf.id === shelfId) setSelectedShelf(null)
  }

  const validate = () => {
    const required: Record<string, string> = { name: '仓库名称', address: '仓库地址', orgUnit: '所属单位', manager: '负责人' }
    const newErrors: Record<string, boolean> = {}
    Object.keys(required).forEach((key) => { if (!(form as any)[key]) { newErrors[key] = true } })
    setErrors(newErrors)
    if (Object.keys(newErrors).length > 0) {
      alert(`请填写必填项：${Object.keys(newErrors).map(k => required[k]).join('、')}`)
      return false
    }
    return true
  }

  const handleSubmit = () => {
    if (!validate()) return
    const newWh: WarehouseItem = {
      id: warehouse?.id || `CK-${Date.now()}`,
      code: form.code || `CK-${Date.now()}`,
      name: form.name || '',
      address: form.address || '',
      longitude: form.longitude || '',
      latitude: form.latitude || '',
      roomType: (form.roomType as '实体' | '虚拟') || '实体',
      parentNode: form.parentNode || '',
      orgUnit: form.orgUnit || '',
      orgLevel: (form.orgLevel as '省' | '市' | '县') || '县',
      manager: form.manager || '',
      phone: form.phone || '',
      sortOrder: form.sortOrder || 1,
      remark: form.remark || '',
      status: (form.status as '启用' | '停用') || '启用',
      zones: zones,
    }
    onSave(newWh)
    onClose()
  }

  const parentOptions = warehouseList.filter(w => w.id !== warehouse?.id).map(w => ({ label: w.name, value: w.name }))
  const fieldClass = (key: string) => cn('w-full rounded-md border px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10', errors[key] ? 'border-[#EF4444] bg-[#FFF5F5]' : 'border-[#D1D5DB]')
  const zoneTypes = ['收货区', '存储区', '拣货区', '质检区', '退货区', '暂存区']
  const shelfTypes = ['重型货架', '中型货架', '轻型货架', '流利式货架', '阁楼式货架', '悬臂式货架']

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[800px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">{warehouse ? '编辑仓库' : '新增仓库'}</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button>
        </div>

        <div className="flex-1 overflow-auto px-6 py-5">
          <div className="space-y-5">
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">仓库名称 <span className="text-[#EF4444]">*</span></label>
              <input type="text" value={form.name || ''} onChange={e => handleChange('name', e.target.value)} placeholder="请输入仓库名称" className={fieldClass('name')} />
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">仓库地址 <span className="text-[#EF4444]">*</span></label>
              <input type="text" value={form.address || ''} onChange={e => handleChange('address', e.target.value)} placeholder="请输入仓库地址" className={fieldClass('address')} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]"><span className="inline-flex items-center gap-1"><Locate size={13} className="text-[#1A56DB]" />经度</span></label>
                <input type="text" value={form.longitude || ''} onChange={e => handleChange('longitude', e.target.value)} placeholder="请输入经度，如 113.6653" className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]"><span className="inline-flex items-center gap-1"><Locate size={13} className="text-[#10B981]" />纬度</span></label>
                <input type="text" value={form.latitude || ''} onChange={e => handleChange('latitude', e.target.value)} placeholder="请输入纬度，如 34.7689" className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
              </div>
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">上级节点</label>
              <select value={form.parentNode || ''} onChange={e => handleChange('parentNode', e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]">
                <option value="">无上级节点（顶级仓库）</option>
                {parentOptions.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
              </select>
            </div>
            <div>
              <label className="mb-2 block text-sm text-[#374151]">库室类型 <span className="text-[#EF4444]">*</span></label>
              <div className="flex items-center gap-3">
                {(['实体', '虚拟'] as const).map((type) => (
                  <button key={type} onClick={() => handleChange('roomType', type)} className={cn('flex h-9 items-center gap-1.5 rounded-md border px-4 text-sm transition', form.roomType === type ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]')}>
                    {type === '实体' ? <Building2 size={14} /> : <MapPin size={14} />}{type}
                  </button>
                ))}
              </div>
            </div>

            {/* ═══════ 货区货架 - 3层结构（可维护） ═══════ */}
            <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC]">
              <div className="border-b border-[#E5E7EB] px-4 py-3">
                <label className="flex items-center gap-1.5 text-sm font-medium text-[#374151]">
                  <Layers size={14} className="text-[#1A56DB]" />
                  货区货架 <span className="text-[11px] font-normal text-[#6B7280]">（仓库 → 分区 → 货架）</span>
                </label>
                <p className="mt-1 text-[11px] text-[#9CA3AF]">3层结构：仓库（一栋库房）→ 分区（功能区域）→ 货架（具体货位）</p>
              </div>
              <div className="p-4">
                {/* Tab切换 */}
                <div className="mb-3 flex items-center gap-1 rounded-lg border border-[#E5E7EB] bg-[#F3F4F6] p-1">
                  {([{ key: 'warehouse' as const, label: '仓库' }, { key: 'zone' as const, label: '分区' }, { key: 'shelf' as const, label: '货架' }]).map(t => (
                    <button key={t.key} onClick={() => { setAreaTab(t.key); setSelectedShelf(null) }} className={cn('flex-1 rounded-md py-1.5 text-sm transition', areaTab === t.key ? 'bg-white text-[#1A56DB] shadow-sm font-medium' : 'text-[#6B7280] hover:text-[#374151]')}>{t.label}</button>
                  ))}
                </div>

                {/* ─── 仓库Tab ─── */}
                {areaTab === 'warehouse' && (
                  <div>
                    <label className="mb-1.5 block text-xs text-[#6B7280]">排序号</label>
                    <input type="number" value={form.sortOrder || ''} onChange={e => handleChange('sortOrder', parseInt(e.target.value) || 0)} placeholder="请输入排序号" className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                    <p className="mt-1.5 text-[11px] text-[#9CA3AF]">当前仓库在同一层级中的排序位置</p>
                    <div className="mt-4 rounded-lg border border-[#1A56DB]/20 bg-[#F8FAFF] p-4">
                      <h4 className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-[#1A56DB]"><Warehouse size={14} />{form.name || '当前仓库'}</h4>
                      <p className="text-xs text-[#6B7280]">该仓库共有 <strong className="text-[#1F2937]">{zones.length}</strong> 个分区、<strong className="text-[#1F2937]">{zones.reduce((sum, z) => sum + z.shelves.length, 0)}</strong> 个货架</p>
                    </div>
                  </div>
                )}

                {/* ─── 分区Tab（可维护） ─── */}
                {areaTab === 'zone' && (
                  <div>
                    <div className="mb-3 flex items-center justify-between">
                      <span className="text-xs text-[#6B7280]">共 {zones.length} 个分区</span>
                      <button onClick={openAddZone} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white hover:bg-[#153E7E]"><Plus size={13} /> 添加分区</button>
                    </div>
                    {/* 分区表单 */}
                    {zoneFormOpen && (
                      <div className="mb-3 rounded-lg border border-[#1A56DB]/30 bg-[#F8FAFF] p-3">
                        <h4 className="mb-2 text-xs font-semibold text-[#1A56DB]">{editingZone ? '编辑分区' : '新增分区'}</h4>
                        <div className="grid grid-cols-2 gap-3">
                          <div><label className="mb-1 block text-[11px] text-[#374151]">分区名称 *</label><input type="text" value={zoneName} onChange={e => setZoneName(e.target.value)} placeholder="如：存储区" className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" /></div>
                          <div><label className="mb-1 block text-[11px] text-[#374151]">分区编码 *</label><input type="text" value={zoneCode} onChange={e => setZoneCode(e.target.value)} placeholder="如：FQ-CC-001" className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" /></div>
                          <div><label className="mb-1 block text-[11px] text-[#374151]">分区类型</label><select value={zoneType} onChange={e => setZoneType(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none">{zoneTypes.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
                          <div><label className="mb-1 block text-[11px] text-[#374151]">排序号</label><input type="number" value={zoneSort} onChange={e => setZoneSort(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none" /></div>
                        </div>
                        <div className="mt-2 flex justify-end gap-2">
                          <button onClick={resetZoneForm} className="h-7 rounded border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151]">取消</button>
                          <button onClick={handleSaveZone} className="h-7 rounded bg-[#1A56DB] px-3 text-xs text-white">保存</button>
                        </div>
                      </div>
                    )}
                    {zones.length > 0 ? (
                      <div className="space-y-2">
                        {zones.map((zone, idx) => (
                          <div key={zone.id} className="rounded-md border border-[#E5E7EB] bg-white">
                            <div className="flex items-center gap-2 px-3 py-2.5">
                              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#1A56DB] text-[10px] text-white font-medium">{idx + 1}</span>
                              <Layers size={13} className="shrink-0 text-[#1A56DB]" />
                              <span className="text-sm font-medium text-[#374151]">{zone.name}</span>
                              <Badge variant="info">{zone.zoneType}</Badge>
                              <span className="text-xs text-[#6B7280] font-mono">{zone.code}</span>
                              <span className="ml-auto text-xs text-[#6B7280]">含 {zone.shelves.length} 个货架</span>
                            </div>
                            {zone.shelves.length > 0 && (
                              <div className="border-t border-[#F3F4F6] px-3 py-2">
                                <div className="flex flex-wrap gap-1.5">
                                  {zone.shelves.map(s => (
                                    <span key={s.id} className="rounded bg-[#ECFDF5] px-2 py-0.5 text-[11px] text-[#059669] font-mono">{s.name}</span>
                                  ))}
                                </div>
                              </div>
                            )}
                            <div className="flex items-center gap-2 border-t border-[#F3F4F6] px-3 py-1.5">
                              <button onClick={() => openAddShelf(zone.id)} className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] text-[#1A56DB] hover:bg-[#E8F0FE]"><Plus size={10} />添加货架</button>
                              <button onClick={() => openEditZone(zone)} className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] text-[#6B7280] hover:bg-[#F3F4F6]"><Edit3 size={10} />编辑</button>
                              <button onClick={() => handleDeleteZone(zone.id)} className="inline-flex items-center gap-1 rounded px-2 py-0.5 text-[11px] text-[#EF4444] hover:bg-[#FEE2E2]"><Trash2 size={10} />删除</button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="py-6 text-center text-sm text-[#9CA3AF]">暂无分区，请点击"添加分区"创建</div>
                    )}
                  </div>
                )}

                {/* ─── 货架Tab（可维护） ─── */}
                {areaTab === 'shelf' && (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                      <h4 className="mb-2 text-xs font-semibold text-[#374151]">3层结构导航</h4>
                      <div className="mb-2 rounded bg-[#F0F5FF] px-3 py-2">
                        <div className="flex items-center gap-1 text-xs font-semibold text-[#1A56DB]"><Warehouse size={12} />{form.name || '当前仓库'}</div>
                        <div className="mt-0.5 text-[10px] text-[#6B7280]">{zones.length} 个分区 · {zones.reduce((s, z) => s + z.shelves.length, 0)} 个货架</div>
                      </div>
                      {zones.length === 0 ? (
                        <div className="py-4 text-center text-xs text-[#9CA3AF]">暂无分区，请先创建分区</div>
                      ) : (
                        <div className="space-y-1">
                          {zones.map(zone => (
                            <div key={zone.id}>
                              <div className="flex items-center gap-1.5 rounded-md px-2 py-1.5 text-sm">
                                <Layers size={13} className="text-[#1A56DB]" />
                                <span className="font-medium">{zone.name}</span>
                                <Badge variant="info" className="text-[10px]">{zone.zoneType}</Badge>
                                <button onClick={() => openAddShelf(zone.id)} className="ml-auto rounded px-1.5 py-0.5 text-[10px] text-[#1A56DB] hover:bg-[#E8F0FE]"><Plus size={10} /></button>
                              </div>
                              {zone.shelves.length > 0 ? (
                                <div className="ml-4 space-y-0.5 border-l border-[#E5E7EB] pl-2">
                                  {zone.shelves.map(shelf => (
                                    <div key={shelf.id} className="flex items-center gap-1 rounded-md px-2 py-1">
                                      <button onClick={() => setSelectedShelf({ shelf, zone })} className={cn('flex flex-1 items-center gap-1.5 text-sm transition', selectedShelf?.shelf.id === shelf.id ? 'text-[#1A56DB] font-medium' : 'text-[#374151] hover:text-[#1A56DB]')}>
                                        <Grid3x3 size={12} className="shrink-0 text-[#10B981]" />
                                        <span>{shelf.name}</span>
                                      </button>
                                      <button onClick={() => openEditShelf(shelf, zone.id)} className="rounded p-0.5 text-[#6B7280] hover:text-[#1A56DB]"><Edit3 size={11} /></button>
                                      <button onClick={() => handleDeleteShelf(shelf.id, zone.id)} className="rounded p-0.5 text-[#6B7280] hover:text-[#EF4444]"><Trash2 size={11} /></button>
                                    </div>
                                  ))}
                                </div>
                              ) : (
                                <div className="ml-4 border-l border-[#E5E7EB] pl-2"><div className="px-2 py-1 text-[11px] text-[#9CA3AF]">该分区暂无货架</div></div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                      {shelfFormOpen ? (
                        <div>
                          <h4 className="mb-2 text-xs font-semibold text-[#374151]">{editingShelf ? '编辑货架' : '新增货架'}</h4>
                          <div className="space-y-2">
                            <div><label className="mb-1 block text-[11px] text-[#374151]">所属分区</label><select value={shelfParentZoneId || editingShelf?.zoneId || ''} onChange={e => { setShelfParentZoneId(e.target.value); setEditingShelf(null) }} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none" disabled={!!editingShelf}>
                              <option value="">请选择分区</option>
                              {zones.map(z => <option key={z.id} value={z.id}>{z.name}</option>)}
                            </select></div>
                            <div><label className="mb-1 block text-[11px] text-[#374151]">货架名称 *</label><input type="text" value={shelfName} onChange={e => setShelfName(e.target.value)} placeholder="如：存储货架A01" className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" /></div>
                            <div><label className="mb-1 block text-[11px] text-[#374151]">货架编码 *</label><input type="text" value={shelfCode} onChange={e => setShelfCode(e.target.value)} placeholder="如：HJ-CC-A01" className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" /></div>
                            <div className="grid grid-cols-3 gap-2">
                              <div><label className="mb-1 block text-[11px] text-[#374151]">类型</label><select value={shelfType} onChange={e => setShelfType(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-1 py-1.5 text-xs outline-none">{shelfTypes.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
                              <div><label className="mb-1 block text-[11px] text-[#374151]">容量</label><input type="number" value={shelfCapacity} onChange={e => setShelfCapacity(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-1 py-1.5 text-xs outline-none" /></div>
                              <div><label className="mb-1 block text-[11px] text-[#374151]">排序</label><input type="number" value={shelfSort} onChange={e => setShelfSort(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-1 py-1.5 text-xs outline-none" /></div>
                            </div>
                          </div>
                          <div className="mt-3 flex justify-end gap-2">
                            <button onClick={resetShelfForm} className="h-7 rounded border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151]">取消</button>
                            <button onClick={handleSaveShelf} className="h-7 rounded bg-[#1A56DB] px-3 text-xs text-white">保存</button>
                          </div>
                        </div>
                      ) : selectedShelf ? (
                        <div className="space-y-3">
                          <div className="flex items-center gap-2">
                            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#E8F0FE]"><Grid3x3 size={16} className="text-[#1A56DB]" /></div>
                            <div><div className="text-sm font-semibold text-[#1F2937]">{selectedShelf.shelf.name}</div><div className="text-[11px] text-[#6B7280] font-mono">{selectedShelf.shelf.code}</div></div>
                          </div>
                          <div className="rounded-md bg-[#F0FDF4] px-3 py-2">
                            <div className="text-[11px] text-[#6B7280] mb-1">完整路径（3层结构）</div>
                            <div className="flex items-center gap-1 text-xs">
                              <span className="rounded bg-[#EFF6FF] px-1.5 py-0.5 text-[#1A56DB]">{form.name || '当前仓库'}</span>
                              <ChevronRight size={12} className="text-[#D1D5DB]" />
                              <span className="rounded bg-[#ECFDF5] px-1.5 py-0.5 text-[#059669]">{selectedShelf.zone.name}</span>
                              <ChevronRight size={12} className="text-[#D1D5DB]" />
                              <span className="rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[#D97706]">{selectedShelf.shelf.name}</span>
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-3">
                            <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">货架类型</label><div className="text-sm font-medium text-[#374151]">{selectedShelf.shelf.shelfType}</div></div>
                            <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">容量</label><div className="text-sm font-medium text-[#374151]">{selectedShelf.shelf.capacity}</div></div>
                            <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">所属分区</label><div className="text-sm font-medium text-[#374151]">{selectedShelf.zone.name}（{selectedShelf.zone.zoneType}）</div></div>
                            <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">排序</label><div className="text-sm font-medium text-[#374151]">{selectedShelf.shelf.sortOrder}</div></div>
                          </div>
                          <div className="flex gap-2">
                            <button onClick={() => openEditShelf(selectedShelf.shelf, selectedShelf.zone.id)} className="inline-flex h-7 items-center gap-1 rounded border border-[#E5E7EB] px-3 text-xs text-[#374151] hover:bg-[#F3F4F6]"><Edit3 size={11} />编辑货架</button>
                            <button onClick={() => handleDeleteShelf(selectedShelf.shelf.id, selectedShelf.zone.id)} className="inline-flex h-7 items-center gap-1 rounded border border-[#FEE2E2] px-3 text-xs text-[#EF4444] hover:bg-[#FEE2E2]"><Trash2 size={11} />删除货架</button>
                          </div>
                        </div>
                      ) : (
                        <div className="flex h-full flex-col items-center justify-center py-12 text-center">
                          <Layers size={32} className="mb-2 text-[#D1D5DB]" />
                          <p className="text-sm text-[#9CA3AF]">从左侧选择货架查看详情</p>
                          <p className="mt-1 text-[11px] text-[#D1D5DB]">或点击分区旁的 + 添加货架</p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]">所属单位 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={form.orgUnit || ''} onChange={e => handleChange('orgUnit', e.target.value)} placeholder="请输入所属单位" className={fieldClass('orgUnit')} />
              </div>
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]">库室层级 <span className="text-[#EF4444]">*</span></label>
                <select value={form.orgLevel || '县'} onChange={e => handleChange('orgLevel', e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]">
                  <option value="省">省级</option><option value="市">市级</option><option value="县">县级</option>
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-sm text-[#374151]">负责人 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={form.manager || ''} onChange={e => handleChange('manager', e.target.value)} placeholder="请输入负责人" className={fieldClass('manager')} />
              </div>
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">联系电话</label>
              <input type="text" value={form.phone || ''} onChange={e => handleChange('phone', e.target.value)} placeholder="请输入联系电话" className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm text-[#374151]">备注</label>
              <textarea value={form.remark || ''} onChange={e => handleChange('remark', e.target.value)} placeholder="请输入备注信息..." rows={3} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] resize-none" />
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSubmit} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white hover:bg-[#153E7E]">保存</button>
        </div>
      </div>
    </div>
  )
}

function ImportModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [fileName, setFileName] = useState(''), fileRef = useRef<HTMLInputElement>(null)
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => { const f = e.target.files?.[0]; if (f) setFileName(f.name) }
  if (!open) return null
  return <div className="fixed inset-0 z-50 flex items-center justify-center"><div className="absolute inset-0 bg-black/50" onClick={onClose} /><div className="relative z-10 w-[480px] max-w-[95vw] rounded-xl bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4"><h2 className="text-base font-semibold text-[#1F2937]">导入仓库信息</h2><button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={16} /></button></div><div className="p-6"><div className="mb-4 flex items-center justify-between rounded-lg bg-[#F0F9FF] px-4 py-3"><div className="flex items-center gap-2 text-sm text-[#0369A1]"><Package size={16} /><span>请先下载导入模板，按模板格式填写数据</span></div><button className="flex items-center gap-1 rounded-md border border-[#0369A1] bg-white px-3 py-1.5 text-xs font-medium text-[#0369A1] hover:bg-[#E0F2FE]"><Download size={12} /> 下载模板</button></div><div className={cn('cursor-pointer rounded-lg border-2 border-dashed p-8 text-center transition', fileName ? 'border-[#10B981] bg-[#ECFDF5]' : 'border-[#D1D5DB] bg-[#F9FAFB] hover:border-[#1A56DB]')} onClick={() => fileRef.current?.click()}><input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleFile} /><Upload size={32} className={cn('mx-auto mb-2', fileName ? 'text-[#10B981]' : 'text-[#9CA3AF]')} />{fileName ? <><p className="text-sm font-medium text-[#10B981]">{fileName}</p><p className="mt-1 text-xs text-[#6B7280]">点击更换文件</p></> : <><p className="text-sm font-medium text-[#374151]">点击或拖拽上传文件</p><p className="mt-1 text-xs text-[#6B7280]">支持 .xlsx / .xls / .csv 格式</p></>}</div><div className="mt-4 rounded-lg border border-[#E5E7EB] p-3"><h4 className="mb-2 text-xs font-semibold text-[#374151]">导入说明：</h4><ul className="space-y-1 text-xs text-[#6B7280]"><li>1. 文件大小不超过 10MB</li><li>2. 单次导入不超过 1000 条记录</li><li>3. 必填字段：仓库编号、仓库名称、仓库地址</li><li>4. 重复编号将自动跳过</li></ul></div></div><div className="flex justify-end gap-2 border-t border-[#E5E7EB] px-6 py-4"><button onClick={onClose} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">取消</button><button onClick={() => { setFileName(''); onClose() }} className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">确认导入</button></div></div></div>
}

/* ═══════════════════════════════════════════
   仓库详情抽屉 - 含3层货架结构 + 经纬度
   ═══════════════════════════════════════════ */

function WarehouseDetailDrawer({ warehouse, onClose }: { warehouse: WarehouseItem | null; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<'info' | 'safety'>('info')
  const [detailShelf, setDetailShelf] = useState<{ shelf: ShelfItem; zone: ZoneItem } | null>(null)
  if (!warehouse) return null
  const normalCount = safetyStockData.filter((s) => s.status === '正常').length, lowCount = safetyStockData.filter((s) => s.status === '低于安全线').length
  const safetyColumns = [{ key: 'equipName', title: '装备名称' }, { key: 'category', title: '物资类别' }, { key: 'currentStock', title: '当前总库存', render: (v: number) => <span className="font-medium text-[#1A56DB]">{v}</span> }, { key: 'threshold', title: '安全库存阈值', render: (v: number) => <span className="text-[#6B7280]">{v}</span> }, { key: 'diff', title: '差额', render: (v: number) => <span className={cn('font-medium', v >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]')}>{v >= 0 ? `+${v}` : v}</span> }, { key: 'status', title: '状态', render: (v: string) => <Badge variant={v === '正常' ? 'success' : 'danger'}>{v}</Badge> }]
  const levelColor = (l: string) => l === '省' ? 'bg-[#1A56DB] text-white' : l === '市' ? 'bg-[#10B981] text-white' : 'bg-[#F59E0B] text-white'
  return <div className="fixed inset-0 z-50 flex justify-end"><div className="absolute inset-0 bg-black/40" onClick={onClose} /><div className="relative z-10 flex h-full w-[960px] max-w-[95vw] flex-col bg-white shadow-2xl"><div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4"><div className="flex items-center gap-3"><div className="flex h-10 w-10 items-center justify-center rounded-lg bg-[#E8F0FE]"><Warehouse size={20} className="text-[#1A56DB]" /></div><div><h2 className="text-lg font-semibold text-[#1F2937]">{warehouse.name}</h2><p className="text-xs text-[#6B7280]">编号：{warehouse.code} · {warehouse.orgUnit}</p></div></div><button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button></div><div className="flex shrink-0 gap-0 border-b border-[#E5E7EB] bg-white px-6">{[{ key: 'info' as const, label: '仓库信息', icon: <Building2 size={14} /> }, { key: 'safety' as const, label: '单位安全库存', icon: <ShieldCheck size={14} /> }].map((tab) => <button key={tab.key} onClick={() => { setActiveTab(tab.key); setDetailShelf(null) }} className={cn('flex items-center gap-1.5 px-4 py-3 text-sm font-medium transition border-b-2', activeTab === tab.key ? 'border-[#1A56DB] text-[#1A56DB]' : 'border-transparent text-[#6B7280] hover:text-[#374151]')}>{tab.icon}{tab.label}{tab.key === 'safety' && <span className="ml-0.5 rounded-full bg-[#FEE2E2] px-1.5 text-[11px] text-[#DC2626]">{lowCount}</span>}</button>)}</div>

      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'info' ? (
          <div className="space-y-5">
            {/* 基础信息网格 */}
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">仓库编号</label><div className="text-sm font-medium text-[#1A56DB]">{warehouse.code}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">仓库名称</label><div className="text-sm font-medium text-[#1F2937]">{warehouse.name}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">库室类型</label><div className="text-sm"><Badge variant={warehouse.roomType === '实体' ? 'primary' : 'info'}>{warehouse.roomType}</Badge></div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">所属单位</label><div className="text-sm font-medium text-[#1F2937]">{warehouse.orgUnit}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">库室层级</label><div className="text-sm"><span className={cn('inline-flex rounded px-1.5 py-0.5 text-[11px] font-medium', levelColor(warehouse.orgLevel))}>{warehouse.orgLevel}级</span></div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">上级节点</label><div className="text-sm font-medium text-[#374151]">{warehouse.parentNode || <span className="text-[#9CA3AF]">无（顶级仓库）</span>}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">负责人</label><div className="text-sm font-medium text-[#1F2937]">{warehouse.manager}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">联系电话</label><div className="text-sm text-[#374151]">{warehouse.phone}</div></div>
              <div className="rounded-lg border border-[#E5E7EB] p-4"><label className="mb-1 block text-xs text-[#6B7280]">状态</label><div className="text-sm"><Badge variant={warehouse.status === '启用' ? 'success' : 'default'}>{warehouse.status}</Badge></div></div>
            </div>

            {/* 仓库地址 + 经纬度 */}
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-[#374151]"><MapPin size={14} className="text-[#1A56DB]" />仓库地址与坐标</h3>
              <div className="grid grid-cols-3 gap-4">
                <div><label className="mb-1 block text-xs text-[#6B7280]">仓库地址</label><div className="text-sm font-medium text-[#1F2937]">{warehouse.address}</div></div>
                <div><label className="mb-1 flex items-center gap-1 text-xs text-[#6B7280]"><Locate size={11} className="text-[#1A56DB]" />经度</label><div className="text-sm font-mono text-[#1A56DB]">{warehouse.longitude || <span className="text-[#9CA3AF]">未设置</span>}</div></div>
                <div><label className="mb-1 flex items-center gap-1 text-xs text-[#6B7280]"><Locate size={11} className="text-[#10B981]" />纬度</label><div className="text-sm font-mono text-[#10B981]">{warehouse.latitude || <span className="text-[#9CA3AF]">未设置</span>}</div></div>
              </div>
            </div>

            {/* ═══════ 货区货架 - 3层结构 ═══════ */}
            <div className="rounded-lg border border-[#E5E7EB]">
              <div className="border-b border-[#E5E7EB] px-4 py-3">
                <h3 className="flex items-center gap-1.5 text-sm font-semibold text-[#374151]"><Layers size={14} className="text-[#1A56DB]" />货区货架</h3>
                <p className="mt-0.5 text-[11px] text-[#9CA3AF]">3层结构：仓库 → 分区（功能区域）→ 货架（具体货位）</p>
              </div>
              {warehouse.zones && warehouse.zones.length > 0 ? (
                <div className="p-4 grid grid-cols-5 gap-4">
                  {/* 左侧3层导航 */}
                  <div className="col-span-2 rounded-md border border-[#E5E7EB] bg-white p-3">
                    <div className="mb-2 rounded bg-[#F0F5FF] px-3 py-2">
                      <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1A56DB]"><Warehouse size={13} />{warehouse.name}</div>
                      <div className="mt-1 text-[10px] text-[#6B7280]">{warehouse.zones.length} 个分区 · {warehouse.zones.reduce((s, z) => s + z.shelves.length, 0)} 个货架</div>
                    </div>
                    <ZoneShelfTree zones={warehouse.zones} onSelectShelf={(shelf, zone) => setDetailShelf({ shelf, zone })} />
                  </div>
                  {/* 右侧详情 */}
                  <div className="col-span-3 rounded-md border border-[#E5E7EB] bg-white p-4">
                    {detailShelf ? (
                      <div className="space-y-4">
                        <div className="flex items-center gap-2">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#E8F0FE]"><Grid3x3 size={16} className="text-[#1A56DB]" /></div>
                          <div><div className="text-sm font-semibold text-[#1F2937]">{detailShelf.shelf.name}</div><div className="text-[11px] text-[#6B7280] font-mono">{detailShelf.shelf.code}</div></div>
                        </div>
                        <div className="rounded-md bg-[#F0FDF4] px-3 py-2">
                          <div className="text-[11px] text-[#6B7280] mb-1">完整路径（3层结构）</div>
                          <div className="flex items-center gap-1 text-xs">
                            <span className="rounded bg-[#EFF6FF] px-1.5 py-0.5 text-[#1A56DB]">{warehouse.name}</span>
                            <ChevronRight size={12} className="text-[#D1D5DB]" />
                            <span className="rounded bg-[#ECFDF5] px-1.5 py-0.5 text-[#059669]">{detailShelf.zone.name}</span>
                            <ChevronRight size={12} className="text-[#D1D5DB]" />
                            <span className="rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[#D97706]">{detailShelf.shelf.name}</span>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">货架类型</label><div className="text-sm font-medium text-[#374151]">{detailShelf.shelf.shelfType}</div></div>
                          <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">容量</label><div className="text-sm font-medium text-[#374151]">{detailShelf.shelf.capacity}</div></div>
                          <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">所属分区</label><div className="text-sm font-medium text-[#374151]">{detailShelf.zone.name}（{detailShelf.zone.zoneType}）</div></div>
                          <div className="rounded border border-[#E5E7EB] p-3"><label className="text-[11px] text-[#6B7280]">排序</label><div className="text-sm font-medium text-[#374151]">{detailShelf.shelf.sortOrder}</div></div>
                        </div>
                      </div>
                    ) : (
                      <div className="flex h-full flex-col items-center justify-center py-12 text-center">
                        <Layers size={32} className="mb-2 text-[#D1D5DB]" />
                        <p className="text-sm text-[#9CA3AF]">从左侧导航选择货架查看详情</p>
                        <p className="mt-1 text-[11px] text-[#D1D5DB]">3层结构：仓库 → 分区 → 货架</p>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-8 text-center text-sm text-[#9CA3AF]">该仓库暂无分区货架数据</div>
              )}
            </div>

            {/* 统计信息 */}
            <div className="grid grid-cols-3 gap-4">
              <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] p-4"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DBEAFE]"><Package size={18} className="text-[#1A56DB]" /></div><div><p className="text-lg font-bold text-[#1F2937]">{warehouse.zones?.length || 0}</p><p className="text-xs text-[#6B7280]">分区数量</p></div></div>
              <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] p-4"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DBEAFE]"><Grid3x3 size={18} className="text-[#1A56DB]" /></div><div><p className="text-lg font-bold text-[#1F2937]">{warehouse.zones?.reduce((s, z) => s + z.shelves.length, 0) || 0}</p><p className="text-xs text-[#6B7280]">货架数量</p></div></div>
              <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] p-4"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DBEAFE]"><CheckCircle size={18} className="text-[#10B981]" /></div><div><p className="text-lg font-bold text-[#1F2937]">{normalCount}</p><p className="text-xs text-[#6B7280]">库存正常装备</p></div></div>
            </div>

            {warehouse.remark && (
              <div className="rounded-lg border border-[#E5E7EB] p-4">
                <label className="mb-1 block text-xs text-[#6B7280]">备注</label>
                <div className="text-sm text-[#374151]">{warehouse.remark}</div>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] p-4"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#D1FAE5]"><CheckCircle size={18} className="text-[#10B981]" /></div><div><p className="text-lg font-bold text-[#1F2937]">{normalCount}</p><p className="text-xs text-[#6B7280]">库存正常</p></div></div>
              <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] p-4"><div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE2E2]"><TrendingDown size={18} className="text-[#EF4444]" /></div><div><p className="text-lg font-bold text-[#EF4444]">{lowCount}</p><p className="text-xs text-[#6B7280]">低于安全线</p></div></div>
            </div>
            <div className="rounded-lg border border-[#E5E7EB] bg-white p-4"><SimpleTable columns={safetyColumns} data={safetyStockData} /></div>
          </div>
        )}
      </div>
    </div>
  </div>
}

export default function WarehouseInfoPage() {
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null), [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['h1', 'c1'])), [searchText, setSearchText] = useState(''), [filterLevel, setFilterLevel] = useState(''), [filterStatus, setFilterStatus] = useState(''), [currentPage, setCurrentPage] = useState(1), [detailWh, setDetailWh] = useState<WarehouseItem | null>(null), [showImport, setShowImport] = useState(false), [showForm, setShowForm] = useState(false), [editingWh, setEditingWh] = useState<WarehouseItem | null>(null)
  const [warehouses, setWarehouses] = useState<WarehouseItem[]>(warehouseList)
  const pageSize = 10
  const toggleExpand = (id: string) => { setExpandedIds((p) => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n }) }
  const getOrgName = (nodes: OrgNode[], id: string): string | null => { for (const n of nodes) { if (n.id === id) return n.name; if (n.children) { const f = getOrgName(n.children, id); if (f) return f } } return null }
  const selectedOrgName = selectedOrgId ? getOrgName(orgTree, selectedOrgId) : null
  let filtered = warehouses
  if (selectedOrgId && selectedOrgName) { filtered = filtered.filter((w) => w.orgUnit === selectedOrgName || w.orgUnit.includes(selectedOrgName) || selectedOrgName.includes(w.orgUnit)) }
  if (searchText) filtered = filtered.filter((w) => w.name.includes(searchText) || w.code.includes(searchText) || w.address.includes(searchText))
  if (filterLevel) filtered = filtered.filter((w) => w.orgLevel === filterLevel)
  if (filterStatus) filtered = filtered.filter((w) => w.status === filterStatus)
  const totalPages = Math.ceil(filtered.length / pageSize), pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)
  const levelBadge = (l: string) => <span className={cn('inline-flex rounded px-1.5 py-0.5 text-[11px] font-medium', l === '省' ? 'bg-[#1A56DB] text-white' : l === '市' ? 'bg-[#10B981] text-white' : 'bg-[#F59E0B] text-white')}>{l}级</span>
  const columns = [{ key: 'code', title: '仓库编号' }, { key: 'name', title: '仓库名称', render: (v: string) => <span className="font-medium text-[#1F2937]">{v}</span> }, { key: 'address', title: '仓库地址' }, { key: 'longitude', title: '经度', render: (v: string) => <span className="font-mono text-[11px] text-[#1A56DB]">{v || '-'}</span> }, { key: 'latitude', title: '纬度', render: (v: string) => <span className="font-mono text-[11px] text-[#10B981]">{v || '-'}</span> }, { key: 'roomType', title: '库室类型', render: (v: string) => <Badge variant={v === '实体' ? 'primary' : 'info'}>{v}</Badge> }, { key: 'parentNode', title: '上级节点', render: (v: string) => v ? <span className="text-[#1A56DB] text-[11px]">{v}</span> : <span className="text-[#9CA3AF] text-[11px]">-</span> }, { key: 'orgUnit', title: '所属单位' }, { key: 'orgLevel', title: '库室层级', render: (v: string) => levelBadge(v) }, { key: 'manager', title: '负责人' }, { key: 'phone', title: '联系电话' }, { key: 'remark', title: '备注', render: (v: string) => <span className="max-w-[120px] truncate text-[#6B7280]">{v}</span> }, { key: 'status', title: '状态', render: (v: string) => <Badge variant={v === '启用' ? 'success' : 'default'}>{v}</Badge> }]
  return <div className="flex gap-4" style={{ minHeight: 'calc(100dvh - 200px)' }}><div className="w-64 flex-shrink-0 rounded-lg border border-[#E5E7EB] bg-white shadow-sm"><div className="border-b border-[#E5E7EB] px-4 py-3"><h3 className="text-sm font-semibold text-[#1F2937]">组织架构</h3><div className="mt-2 flex items-center gap-1 rounded-md border border-[#D1D5DB] px-2 py-1"><Search size={12} className="text-[#9CA3AF]" /><input type="text" placeholder="搜索组织..." value={searchText} onChange={(e) => setSearchText(e.target.value)} className="flex-1 bg-transparent text-xs outline-none" /></div></div><div className="p-2">{orgTree.map((n) => <TreeNode key={n.id} node={n} selectedId={selectedOrgId} onSelect={setSelectedOrgId} expandedIds={expandedIds} onToggleExpand={toggleExpand} />)}</div></div><div className="min-w-0 flex-1"><div className="mb-4 flex items-center justify-between"><h1 className="text-2xl font-semibold text-[#1F2937]">仓库信息</h1><div className="flex items-center gap-2"><button onClick={() => { setEditingWh(null); setShowForm(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 新增仓库</button><button onClick={() => setShowImport(true)} className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Upload size={14} /> 导入</button><button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Download size={14} /> 导出</button></div></div><div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm"><div className="flex flex-wrap items-center gap-3"><input type="text" placeholder="搜索仓库编号/名称/地址" value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }} className="h-9 w-64 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" /><select value={filterLevel} onChange={(e) => { setFilterLevel(e.target.value); setCurrentPage(1) }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none"><option value="">全部层级</option><option value="省">省级</option><option value="市">市级</option><option value="县">县级</option></select><select value={filterStatus} onChange={(e) => { setFilterStatus(e.target.value); setCurrentPage(1) }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none"><option value="">全部状态</option><option value="启用">启用</option><option value="停用">停用</option></select><span className="text-xs text-[#6B7280]">共 {filtered.length} 条</span></div></div><div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm"><table className="w-full text-sm"><thead><tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">{columns.map((c) => <th key={c.key} className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">{c.title}</th>)}<th className="px-3 py-3 text-center text-[11px] font-semibold text-[#6B7280]">操作</th></tr></thead><tbody>{pageData.map((w) => <tr key={w.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">{columns.map((c) => <td key={c.key} className="px-3 py-3">{c.render ? c.render(String(w[c.key as keyof WarehouseItem] ?? '')) : String(w[c.key as keyof WarehouseItem] ?? '')}</td>)}<td className="px-3 py-3"><div className="flex items-center justify-center gap-1"><button onClick={() => setDetailWh(w)} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#1A56DB]" title="详情"><Eye size={14} /></button><button onClick={() => { setEditingWh(w); setShowForm(true) }} className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] hover:bg-[#E8F0FE]" title="编辑"><Edit3 size={14} /></button><button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button></div></td></tr>)}</tbody></table>{pageData.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无数据</div>}</div>{totalPages > 1 && <div className="mt-4 flex items-center justify-between"><div className="text-xs text-[#6B7280]">第 {currentPage} / {totalPages} 页，共 {filtered.length} 条</div><div className="flex items-center gap-1"><button onClick={() => setCurrentPage(1)} disabled={currentPage <= 1} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronLeft size={14} /></button>{Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1).map((p) => <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-8 min-w-8 items-center justify-center rounded border text-xs transition', currentPage === p ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>)}<button onClick={() => setCurrentPage(totalPages)} disabled={currentPage >= totalPages} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronRight size={14} /></button></div></div>}</div>

      {detailWh && <WarehouseDetailDrawer warehouse={detailWh} onClose={() => setDetailWh(null)} />}
      <ImportModal open={showImport} onClose={() => setShowImport(false)} />
      <WarehouseForm open={showForm} warehouse={editingWh} onClose={() => { setShowForm(false); setEditingWh(null) }} onSave={(w) => { if (editingWh) { setWarehouses(prev => prev.map(item => item.id === w.id ? w : item)) } else { setWarehouses(prev => [...prev, w]) } }} />
    </div>
}
