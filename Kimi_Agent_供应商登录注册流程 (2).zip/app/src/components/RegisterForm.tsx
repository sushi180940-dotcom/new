import { useState, useCallback } from 'react';
import { Loader2, ArrowRight, ArrowLeft, Upload, Check, X, AlertCircle, Building2, User, Lock, Eye, EyeOff, FileCheck, Factory, Handshake, Truck, CheckCircle2, Shield, Plus } from 'lucide-react';
import { type RegisterStep, type RegisterData, type FormErrors } from '@/types/auth';
import TreeSelect from './TreeSelect';

interface RegisterFormProps {
  registerStep: RegisterStep;
  registerData: RegisterData;
  errors: FormErrors;
  isLoading: boolean;
  agreedNotice: boolean;
  updateCompanyInfo: (field: string, value: string) => void;
  updateQualificationFiles: (field: string, value: File | null) => void;
  updateAccountSecurity: (field: string, value: string) => void;
  setAgreedNotice: (v: boolean) => void;
  onNextStep: () => void;
  onPrevStep: () => void;
  onStepClick: (step: RegisterStep) => void;
  onSubmit: () => void;
  onGoLogin: () => void;
}

const supplierTypes = [
  { value: '生产商', label: '生产商', icon: <Factory className="w-4 h-4" /> },
  { value: '协议供货商', label: '协议供货商', icon: <Handshake className="w-4 h-4" /> },
  { value: '供应商', label: '供应商', icon: <Truck className="w-4 h-4" /> },
];

const provinces = ['北京', '天津', '河北', '山西', '内蒙古', '辽宁', '吉林', '黑龙江', '上海', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东', '广西', '海南', '重庆', '四川', '贵州', '云南', '西藏', '陕西', '甘肃', '青海', '宁夏', '新疆'];

// 资质字段配置
const requiredFields = [
  { key: 'businessLicense', label: '营业执照副本', desc: '原件扫描 / 加盖公章' },
  { key: 'legalPersonId', label: '法定代表人身份证', desc: '正反面' },
  { key: 'industryLicense', label: '相关生产经营资质许可证', desc: '如行业强制资质，非通用资质' },
  { key: 'creditChina', label: '"信用中国"信用信息报告', desc: '' },
  { key: 'creditGov', label: '"中国政府采购网"信用查询截图', desc: '' },
];
const optionalFields = [
  { key: 'bankPermit', label: '开户许可证或基本存款账户信息', desc: '' },
  { key: 'taxProof', label: '近半年内任一月份完税证明', desc: '' },
  { key: 'taxRating', label: '上一年度税务评级截图', desc: '' },
  { key: 'companyIntro', label: '公司及产品简介', desc: '图文 / PPT均可' },
  { key: 'supplyRecord', label: '供货业绩', desc: '可隐去敏感信息的合同 / 中标通知书' },
];

export default function RegisterForm({
  registerStep, registerData, errors, isLoading, agreedNotice,
  updateCompanyInfo, updateQualificationFiles, updateAccountSecurity,
  setAgreedNotice, onNextStep, onPrevStep, onStepClick, onGoLogin,
}: RegisterFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [companySuggestions, setCompanySuggestions] = useState<string[]>([]);
  const [codeCountdown, setCodeCountdown] = useState(0);

  const selectedSupplierTypes = registerData.companyInfo.supplierType ? registerData.companyInfo.supplierType.split(',') : [];
  const toggleSupplierType = (typeValue: string) => {
    const current = selectedSupplierTypes;
    const next = current.includes(typeValue) ? current.filter(t => t !== typeValue) : [...current, typeValue];
    updateCompanyInfo('supplierType', next.join(','));
  };

  const handleCompanyNameChange = useCallback((value: string) => {
    updateCompanyInfo('companyName', value);
    if (value.length >= 2) {
      const mockCompanies = ['华为技术有限公司', '华为终端有限公司', '华为云计算技术有限公司', '阿里巴巴（中国）有限公司', '腾讯科技有限公司'];
      const matches = mockCompanies.filter(c => c.includes(value) && c !== value);
      setCompanySuggestions(matches.slice(0, 3));
    } else { setCompanySuggestions([]); }
  }, [updateCompanyInfo]);

  const sendCode = useCallback(() => {
    const phone = registerData.companyInfo.contactPhone;
    if (!phone || codeCountdown > 0) return;
    setCodeCountdown(60);
    const timer = setInterval(() => {
      setCodeCountdown(prev => { if (prev <= 1) clearInterval(timer); return prev - 1; });
    }, 1000);
  }, [registerData.companyInfo.contactPhone, codeCountdown]);

  const stepLabels = ['注册须知', '基础信息', '资质上传', '账户安全'];

  // 文件上传组件
  const FileUploadBox = ({ fieldKey, label, desc, value }: { fieldKey: string; label: string; desc: string; value: File | null }) => (
    <div>
      <div className="flex items-center gap-2 mb-1.5">
        <span className="text-sm font-medium text-slate-700">{label}</span>
        {desc && <span className="text-xs text-slate-400">({desc})</span>}
      </div>
      <div
        onClick={() => { const el = document.getElementById(`file-${fieldKey}`) as HTMLInputElement; el?.click(); }}
        className={`relative border-2 border-dashed rounded-xl p-4 cursor-pointer transition-all text-center ${
          value ? 'border-green-400 bg-green-50/50' : errors[fieldKey] ? 'border-red-300 bg-red-50/30' : 'border-slate-300 bg-slate-50/50 hover:border-blue-400 hover:bg-blue-50/30'
        }`}
      >
        <input id={`file-${fieldKey}`} type="file" accept=".jpg,.jpeg,.png,.pdf" className="hidden"
          onChange={e => { if (e.target.files?.[0]) updateQualificationFiles(fieldKey, e.target.files[0]); }} />
        {value ? (
          <div className="flex items-center justify-center gap-2">
            <FileCheck className="w-5 h-5 text-green-600" />
            <span className="text-sm text-slate-700 font-medium">{value.name}</span>
            <button onClick={e => { e.stopPropagation(); updateQualificationFiles(fieldKey, null); }}
              className="ml-auto p-1 hover:bg-red-100 rounded"><X className="w-4 h-4 text-red-500" /></button>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-1">
            <Upload className="w-6 h-6 text-slate-400" />
            <span className="text-xs text-slate-500">点击上传</span>
          </div>
        )}
      </div>
      {errors[fieldKey] && <p className="mt-1 text-red-500 text-xs">{errors[fieldKey]}</p>}
    </div>
  );

  // 步骤1：基础信息
  const Step1CompanyInfo = () => (
    <div className="space-y-4 animate-slide-up">
      {/* 企业名称 */}
      <div className="relative">
        <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5">
          <span className="text-red-500">*</span> 企业名称
        </label>
        <input type="text" placeholder="请输入企业名称" value={registerData.companyInfo.companyName}
          onChange={e => handleCompanyNameChange(e.target.value)}
          className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.companyName ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
        {companySuggestions.length > 0 && (
          <div className="mt-1 bg-blue-50 border border-blue-200 rounded-lg overflow-hidden">
            <p className="px-3 py-1.5 text-xs text-blue-600 font-medium bg-blue-100/50">匹配到以下企业：</p>
            {companySuggestions.map((name, i) => (
              <button key={i} onClick={() => { updateCompanyInfo('companyName', name); setCompanySuggestions([]); }}
                className="w-full text-left px-3 py-2 text-sm text-slate-700 hover:bg-blue-100/50 flex items-center gap-2"><Building2 className="w-3.5 h-3.5 text-blue-500" />{name}</button>
            ))}
          </div>
        )}
        {errors.companyName && <p className="mt-1 text-red-500 text-xs">{errors.companyName}</p>}
      </div>

      {/* 单位简称 */}
      <div>
        <label className="block text-sm font-medium text-slate-700 mb-1.5">单位简称</label>
        <input type="text" placeholder="请输入单位简称" value={registerData.companyInfo.shortName}
          onChange={e => updateCompanyInfo('shortName', e.target.value)}
          className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" />
      </div>

      {/* 统一社会信用代码 */}
      <div>
        <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5">
          <span className="text-red-500">*</span> 统一社会信用代码
        </label>
        <div className="flex gap-2">
          <input type="text" placeholder="请输入统一社会信用代码" maxLength={18} value={registerData.companyInfo.creditCode}
            onChange={e => updateCompanyInfo('creditCode', e.target.value.toUpperCase())}
            className={`flex-1 px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 tracking-wider ${errors.creditCode ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          <button className="px-4 py-3 bg-blue-50 text-blue-700 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors whitespace-nowrap">注册信息验证</button>
        </div>
        {errors.creditCode && <p className="mt-1 text-red-500 text-xs">{errors.creditCode}</p>}
      </div>

      {/* 注册地 + 法定代表人 */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 注册地</label>
          <input type="text" placeholder="请输入注册地" value={registerData.companyInfo.registerAddress}
            onChange={e => updateCompanyInfo('registerAddress', e.target.value)}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.registerAddress ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          {errors.registerAddress && <p className="mt-1 text-red-500 text-xs">{errors.registerAddress}</p>}
        </div>
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 法定代表人/注册人</label>
          <input type="text" placeholder="请输入法定代表人" value={registerData.companyInfo.legalPerson}
            onChange={e => updateCompanyInfo('legalPerson', e.target.value)}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.legalPerson ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          {errors.legalPerson && <p className="mt-1 text-red-500 text-xs">{errors.legalPerson}</p>}
        </div>
      </div>

      {/* 注册资金 + 注册地省（市） */}
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 注册资金</label>
          <input type="text" placeholder="请输入注册资金" value={registerData.companyInfo.registeredCapital}
            onChange={e => updateCompanyInfo('registeredCapital', e.target.value)}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.registeredCapital ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          {errors.registeredCapital && <p className="mt-1 text-red-500 text-xs">{errors.registeredCapital}</p>}
        </div>
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 注册地-省（市）</label>
          <select value={registerData.companyInfo.registerProvince} onChange={e => updateCompanyInfo('registerProvince', e.target.value)}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.registerProvince ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`}>
            <option value="">请选择</option>
            {provinces.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
          {errors.registerProvince && <p className="mt-1 text-red-500 text-xs">{errors.registerProvince}</p>}
        </div>
      </div>

      {/* 营业执照 */}
      <div>
        <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 营业执照</label>
        <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-blue-400 cursor-pointer transition-colors bg-slate-50/50">
          <div className="w-12 h-12 rounded-lg bg-white flex items-center justify-center mx-auto mb-2 border border-slate-200">
            <Plus className="w-6 h-6 text-slate-400" />
          </div>
          <p className="text-xs text-slate-500">图片上传，最多可上传5个文件，每个文件不超过10M</p>
        </div>
      </div>

      {/* 供应商类型（多选） */}
      <div>
        <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-2"><span className="text-red-500">*</span> 供应商类型 <span className="text-slate-400 font-normal">（可多选）</span></label>
        <div className="grid grid-cols-3 gap-3">
          {supplierTypes.map(type => {
            const isSelected = selectedSupplierTypes.includes(type.value);
            return (
              <button key={type.value} onClick={() => toggleSupplierType(type.value)}
                className={`flex flex-col items-center gap-1.5 py-3 px-2 rounded-lg border-2 text-sm transition-all ${isSelected ? 'border-blue-700 bg-blue-50 text-blue-700' : 'border-slate-200 bg-white text-slate-600 hover:border-blue-300'}`}>
                <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-blue-700 border-blue-700' : 'border-slate-300'}`}>
                  {isSelected && <Check className="w-3 h-3 text-white" />}
                </div>
                <span className="text-xs font-medium">{type.label}</span>
              </button>
            );
          })}
        </div>
        {errors.supplierType && <p className="mt-1 text-red-500 text-xs">{errors.supplierType}</p>}
      </div>

      {/* 合作单位 */}
      <div>
        <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 合作单位</label>
        <TreeSelect value={registerData.companyInfo.cooperationUnit}
          onChange={(v) => updateCompanyInfo('cooperationUnit', v)}
          error={errors.cooperationUnit} />
        {errors.cooperationUnit && <p className="mt-1 text-red-500 text-xs">{errors.cooperationUnit}</p>}
      </div>

      {/* ====== 联系人信息 ====== */}
      <div className="pt-4 border-t border-slate-200">
        <h3 className="text-base font-bold text-slate-800 mb-4 flex items-center gap-2"><User className="w-5 h-5 text-blue-600" /> 联系人信息</h3>
        
        <div className="space-y-4">
          {/* 联系人 + 证件类型 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 联系人</label>
              <input type="text" placeholder="请输入联系人" value={registerData.companyInfo.contactName}
                onChange={e => updateCompanyInfo('contactName', e.target.value)}
                className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.contactName ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
              {errors.contactName && <p className="mt-1 text-red-500 text-xs">{errors.contactName}</p>}
            </div>
            <div>
              <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 证件类型</label>
              <select value={registerData.companyInfo.idType} onChange={e => updateCompanyInfo('idType', e.target.value)}
                className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.idType ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`}>
                <option value="">请选择</option>
                <option value="身份证">身份证</option>
                <option value="护照">护照</option>
                <option value="军官证">军官证</option>
              </select>
              {errors.idType && <p className="mt-1 text-red-500 text-xs">{errors.idType}</p>}
            </div>
          </div>

          {/* 证件号码 + 联系电话 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 证件号码</label>
              <input type="text" placeholder="请输入证件号码" value={registerData.companyInfo.idNumber}
                onChange={e => updateCompanyInfo('idNumber', e.target.value)}
                className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.idNumber ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
              {errors.idNumber && <p className="mt-1 text-red-500 text-xs">{errors.idNumber}</p>}
            </div>
            <div>
              <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 联系电话</label>
              <input type="tel" placeholder="请输入联系电话" maxLength={11} value={registerData.companyInfo.contactPhone}
                onChange={e => updateCompanyInfo('contactPhone', e.target.value.replace(/\D/g, ''))}
                className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.contactPhone ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
              {errors.contactPhone && <p className="mt-1 text-red-500 text-xs">{errors.contactPhone}</p>}
            </div>
          </div>

          {/* 验证码 + 电子邮箱 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 验证码</label>
              <div className="flex gap-2">
                <input type="text" placeholder="请输入验证码" maxLength={6} value={registerData.companyInfo.loginPhone}
                  onChange={e => updateCompanyInfo('loginPhone', e.target.value.replace(/\D/g, ''))}
                  className="flex-1 px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 tracking-widest text-center" />
                <button onClick={sendCode} disabled={!registerData.companyInfo.contactPhone || codeCountdown > 0}
                  className={`px-4 py-3 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${codeCountdown > 0 || !registerData.companyInfo.contactPhone ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-blue-50 text-blue-700 hover:bg-blue-100'}`}>
                  {codeCountdown > 0 ? `${codeCountdown}s` : '发送验证码'}
                </button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">电子邮箱</label>
              <input type="email" placeholder="请输入电子邮箱" value={registerData.companyInfo.email}
                onChange={e => updateCompanyInfo('email', e.target.value)}
                className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" />
            </div>
          </div>

          {/* 负责人 */}
          <div>
            <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 负责人</label>
            <input type="text" placeholder="请输入负责人" value={registerData.companyInfo.responsiblePerson}
              onChange={e => updateCompanyInfo('responsiblePerson', e.target.value)}
              className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.responsiblePerson ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
            {errors.responsiblePerson && <p className="mt-1 text-red-500 text-xs">{errors.responsiblePerson}</p>}
          </div>

          {/* 身份证正反面 */}
          <div>
            <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 身份证正反面</label>
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-blue-400 cursor-pointer transition-colors bg-slate-50/50">
              <div className="w-12 h-12 rounded-lg bg-white flex items-center justify-center mx-auto mb-2 border border-slate-200">
                <Plus className="w-6 h-6 text-slate-400" />
              </div>
              <p className="text-xs text-slate-500">请上传清晰的身份证照片，支持JPG、PNG格式，每个文件不超过10M</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // 步骤2：资质上传
  const Step2Qualification = () => (
    <div className="space-y-6 animate-slide-up">
      {/* 一、必填 */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Shield className="w-5 h-5 text-red-500" />
          <h3 className="text-sm font-bold text-slate-800">一、必填</h3>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {requiredFields.map(f => (
            <FileUploadBox key={f.key} fieldKey={f.key} label={f.label} desc={f.desc}
              value={registerData.qualificationFiles[f.key as keyof typeof registerData.qualificationFiles] as File | null} />
          ))}
        </div>
      </div>

      {/* 二、选填 */}
      <div>
        <div className="flex items-center gap-2 mb-3">
          <CheckCircle2 className="w-5 h-5 text-green-500" />
          <h3 className="text-sm font-bold text-slate-800">二、选填</h3>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {optionalFields.map(f => (
            <FileUploadBox key={f.key} fieldKey={f.key} label={f.label} desc={f.desc}
              value={registerData.qualificationFiles[f.key as keyof typeof registerData.qualificationFiles] as File | null} />
          ))}
        </div>
      </div>
    </div>
  );

  // 步骤3：账户安全
  const Step3Security = () => {
    const [codeCountdown3, setCodeCountdown3] = useState(0);
    const sendCode3 = () => {
      const phone = registerData.accountSecurity.bindPhone;
      if (!phone || codeCountdown3 > 0) return;
      setCodeCountdown3(60);
      const timer = setInterval(() => {
        setCodeCountdown3(prev => { if (prev <= 1) clearInterval(timer); return prev - 1; });
      }, 1000);
    };

    return (
      <div className="space-y-4 animate-slide-up">
        {/* 登录账号 */}
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 登录账号</label>
          <input type="text" placeholder="请输入登录账号" value={registerData.accountSecurity.loginAccount}
            onChange={e => updateAccountSecurity('loginAccount', e.target.value)}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.loginAccount ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          {errors.loginAccount && <p className="mt-1 text-red-500 text-xs">{errors.loginAccount}</p>}
        </div>

        {/* 设置密码 */}
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 设置密码</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type={showPassword ? 'text' : 'password'} placeholder="至少8位，包含大小写字母和数字"
              value={registerData.accountSecurity.password}
              onChange={e => updateAccountSecurity('password', e.target.value)}
              className={`w-full pl-10 pr-10 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.password ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
            <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
          </div>
          {errors.password && <p className="mt-1 text-red-500 text-xs">{errors.password}</p>}
          {registerData.accountSecurity.password && (
            <div className="mt-2">
              <div className="flex gap-1 mb-1">
                {[1,2,3,4].map(i => {
                  const s = getPwStrength(registerData.accountSecurity.password);
                  return <div key={i} className={`flex-1 h-1 rounded-full ${i <= s ? (s <= 2 ? 'bg-red-400' : s === 3 ? 'bg-amber-400' : 'bg-green-500') : 'bg-slate-200'}`} />;
                })}
              </div>
              <p className={`text-xs ${getPwLabel(registerData.accountSecurity.password).color}`}>密码强度：{getPwLabel(registerData.accountSecurity.password).label}</p>
            </div>
          )}
        </div>

        {/* 确认密码 */}
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 确认密码</label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type={showConfirmPassword ? 'text' : 'password'} placeholder="请再次输入密码"
              value={registerData.accountSecurity.confirmPassword}
              onChange={e => updateAccountSecurity('confirmPassword', e.target.value)}
              className={`w-full pl-10 pr-10 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.confirmPassword ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
            <button onClick={() => setShowConfirmPassword(!showConfirmPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
          </div>
          {errors.confirmPassword && <p className="mt-1 text-red-500 text-xs">{errors.confirmPassword}</p>}
        </div>

        {/* 绑定手机号 */}
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 绑定手机号</label>
          <input type="tel" placeholder="请输入绑定手机号" maxLength={11}
            value={registerData.accountSecurity.bindPhone}
            onChange={e => updateAccountSecurity('bindPhone', e.target.value.replace(/\D/g, ''))}
            className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.bindPhone ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
          {errors.bindPhone && <p className="mt-1 text-red-500 text-xs">{errors.bindPhone}</p>}
          <p className="mt-1 text-xs text-blue-600">输入手机号后才能发送验证码</p>
        </div>

        {/* 验证码 */}
        <div>
          <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 验证码</label>
          <div className="flex gap-3">
            <input type="text" placeholder="请输入6位验证码" maxLength={6}
              value={registerData.accountSecurity.verificationCode}
              onChange={e => updateAccountSecurity('verificationCode', e.target.value.replace(/\D/g, ''))}
              className={`flex-1 px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 tracking-widest text-center ${errors.verificationCode ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />
            <button onClick={sendCode3} disabled={!registerData.accountSecurity.bindPhone || codeCountdown3 > 0}
              className={`px-4 py-3 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${codeCountdown3 > 0 || !registerData.accountSecurity.bindPhone ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-gradient-police text-white'}`}>
              {codeCountdown3 > 0 ? `${codeCountdown3}s` : '获取验证码'}
            </button>
          </div>
          {errors.verificationCode && <p className="mt-1 text-red-500 text-xs">{errors.verificationCode}</p>}
        </div>
      </div>
    );
  };

  // 注册须知
  const Step1Notice = () => (
    <div className="space-y-5 animate-slide-up">
      <div className="bg-blue-50 border border-blue-200 rounded-xl p-5">
        <h3 className="text-base font-bold text-blue-900 mb-4 flex items-center gap-2"><AlertCircle className="w-5 h-5" /> 供应商注册须知</h3>
        <div className="space-y-3 text-sm text-slate-700 max-h-64 overflow-y-auto pr-2">
          <div><h4 className="font-semibold text-slate-800 mb-1">一、准入条件</h4><p className="text-slate-600 leading-relaxed">申请入驻平台的供应商须为依法设立并有效存续的独立法人企业，具备完整的营业执照及相关行业许可资质，经营状况良好，无重大违法失信记录。</p></div>
          <div><h4 className="font-semibold text-slate-800 mb-1">二、资料真实性</h4><p className="text-slate-600 leading-relaxed">您提交的所有注册信息及资质文件必须真实、准确、完整。平台将对提交的资料进行审核，如发现虚假信息，平台有权拒绝入驻或终止合作。</p></div>
          <div><h4 className="font-semibold text-slate-800 mb-1">三、审核流程</h4><p className="text-slate-600 leading-relaxed">资料提交后，平台将在1-3个工作日内完成审核。审核通过后，您将收到短信和邮件通知，可使用注册账号登录平台。</p></div>
          <div><h4 className="font-semibold text-slate-800 mb-1">四、信息推送</h4><p className="text-slate-600 leading-relaxed">您选择的合作单位将收到您的注册资料推送。请确保所填信息真实有效，以免影响审核结果和后续合作。</p></div>
          <div><h4 className="font-semibold text-slate-800 mb-1">五、数据安全</h4><p className="text-slate-600 leading-relaxed">平台承诺严格保护您的企业信息和商业数据，未经授权不向第三方披露。</p></div>
        </div>
      </div>
      <div className={`p-4 rounded-lg border ${errors.notice ? 'border-red-300 bg-red-50' : 'border-blue-200 bg-blue-50/50'}`}>
        <div className="flex items-start gap-3">
          <input type="checkbox" id="agreeNotice" checked={agreedNotice} onChange={e => setAgreedNotice(e.target.checked)}
            className="w-4 h-4 mt-0.5 rounded border-slate-300 text-blue-700 focus:ring-blue-500/20" />
          <label htmlFor="agreeNotice" className="text-sm text-slate-700 leading-relaxed cursor-pointer">我已阅读并同意以上<strong>注册须知</strong>及<span className="text-blue-700 hover:underline">《供应商服务协议》</span>、<span className="text-blue-700 hover:underline">《隐私政策》</span></label>
        </div>
        {errors.notice && <p className="mt-2 text-red-500 text-xs">{errors.notice}</p>}
      </div>
    </div>
  );

  // 步骤条
  const StepIndicator = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between relative">
        <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -translate-y-1/2" />
        <div className="absolute top-1/2 left-0 h-0.5 bg-blue-700 -translate-y-1/2 transition-all duration-500" style={{ width: `${((registerStep - 1) / 3) * 100}%` }} />
        {[1, 2, 3, 4].map(step => {
          const isCompleted = step < registerStep;
          const isCurrent = step === registerStep;
          return (
            <button key={step} onClick={() => onStepClick(step as RegisterStep)}
              className={`relative z-10 w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all duration-300 cursor-pointer hover:scale-110 ${isCompleted ? 'bg-blue-700 text-white hover:bg-blue-800' : isCurrent ? 'bg-blue-700 text-white ring-4 ring-blue-100' : 'bg-white text-slate-500 border-2 border-slate-300 hover:border-blue-500 hover:text-blue-700'}`}>
              {isCompleted ? <Check className="w-4 h-4" /> : step}
            </button>
          );
        })}
      </div>
      <div className="flex justify-between mt-2">
        {stepLabels.map((label, i) => (
          <button key={i} onClick={() => onStepClick((i + 1) as RegisterStep)}
            className={`text-xs transition-colors cursor-pointer hover:underline ${registerStep === i + 1 ? 'text-blue-700 font-bold' : registerStep > i + 1 ? 'text-blue-600 font-medium' : 'text-slate-500 hover:text-blue-700'}`}>{label}</button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="animate-fade-in">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">供应商注册</h2>
        <p className="text-slate-500 text-sm">填写企业信息，成为平台认证供应商</p>
      </div>
      <StepIndicator />
      {registerStep === 1 && <Step1Notice />}
      {registerStep === 2 && <Step1CompanyInfo />}
      {registerStep === 3 && <Step2Qualification />}
      {registerStep === 4 && <Step3Security />}

      <div className="flex gap-3 mt-6">
        {registerStep > 1 && (
          <button onClick={onPrevStep} className="px-6 py-3 border border-slate-200 text-slate-600 rounded-lg font-medium text-sm hover:bg-slate-50 active:scale-[0.98] transition-all flex items-center gap-2">
            <ArrowLeft className="w-4 h-4" /> 上一步
          </button>
        )}
        {registerStep < 4 ? (
          <button onClick={onNextStep} className="flex-1 py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg">
            下一步 <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button onClick={onNextStep} disabled={isLoading}
            className="flex-1 py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg disabled:opacity-60">
            {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> 提交审核中...</> : <>提交审核 <Check className="w-4 h-4" /></>}
          </button>
        )}
      </div>
      <p className="text-center text-sm text-slate-500 mt-6">已有账号？<button onClick={onGoLogin} className="text-blue-700 font-medium hover:underline ml-1">立即登录</button></p>
    </div>
  );
}

function getPwStrength(pw: string): number {
  let s = 0;
  if (pw.length >= 8) s++;
  if (pw.length >= 12) s++;
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) s++;
  if (/\d/.test(pw) && /[^a-zA-Z0-9]/.test(pw)) s++;
  return Math.min(Math.max(s, 1), 4);
}
function getPwLabel(pw: string): { label: string; color: string } {
  const s = getPwStrength(pw);
  if (s <= 1) return { label: '弱', color: 'text-red-500' };
  if (s === 2) return { label: '偏弱', color: 'text-orange-500' };
  if (s === 3) return { label: '中', color: 'text-amber-600' };
  return { label: '强', color: 'text-green-600' };
}
