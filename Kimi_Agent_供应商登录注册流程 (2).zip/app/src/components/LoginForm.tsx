import { useState, useCallback } from 'react';
import { Eye, EyeOff, Loader2, ArrowRight, User, Lock, KeyRound, Clock, AlertTriangle } from 'lucide-react';
import { type LoginMethod, type LoginFormData, type FormErrors } from '@/types/auth';

interface LoginFormProps {
  loginMethod: LoginMethod;
  loginData: LoginFormData;
  errors: FormErrors;
  isLoading: boolean;
  isFrozen: boolean;
  loginAttempts: number;
  pendingReview: { companyName: string; phone: string; email: string } | null;
  setLoginMethod: (m: LoginMethod) => void;
  setLoginData: React.Dispatch<React.SetStateAction<LoginFormData>>;
  setErrors: React.Dispatch<React.SetStateAction<FormErrors>>;
  onLogin: () => void;
  onGoRegister: () => void;
  onGoForgotPassword: () => void;
}

export default function LoginForm({
  loginMethod, loginData, errors, isLoading, isFrozen, loginAttempts, pendingReview,
  setLoginMethod, setLoginData, setErrors, onLogin, onGoRegister, onGoForgotPassword,
}: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [codeCountdown, setCodeCountdown] = useState(0);

  const sendCode = useCallback(() => {
    if (!loginData.account || codeCountdown > 0) return;
    setCodeCountdown(60);
    const timer = setInterval(() => {
      setCodeCountdown(prev => { if (prev <= 1) clearInterval(timer); return prev - 1; });
    }, 1000);
  }, [loginData.account, codeCountdown]);

  const clearPending = useCallback(() => {
    localStorage.removeItem('pending_review');
    window.location.reload();
  }, []);

  return (
    <div className="animate-fade-in">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-800 mb-2">供应商登录</h2>
        <p className="text-slate-500 text-sm">欢迎回到供应商协同平台</p>
      </div>

      <div className="flex bg-slate-100 rounded-lg p-1 mb-6">
        <button onClick={() => { setLoginMethod('password'); setErrors({}); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ${loginMethod === 'password' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
          <Lock className="w-4 h-4" /> 密码登录
        </button>
        <button onClick={() => { setLoginMethod('verificationCode'); setErrors({}); }}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-md text-sm font-medium transition-all ${loginMethod === 'verificationCode' ? 'bg-white text-blue-900 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
          <KeyRound className="w-4 h-4" /> 验证码登录
        </button>
      </div>

      {pendingReview && (
        <div className="mb-4 p-4 bg-amber-50 border border-amber-300 rounded-lg">
          <div className="flex items-start gap-3">
            <div className="w-6 h-6 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0 mt-0.5"><Clock className="w-3.5 h-3.5 text-amber-600" /></div>
            <div className="flex-1">
              <p className="text-amber-800 text-sm font-medium">您的企业信息正在审核中</p>
              <p className="text-amber-700 text-xs mt-1">企业名称：{pendingReview.companyName}</p>
              <p className="text-amber-600 text-xs mt-1.5">请联系合作单位了解审核进度，或切换其他账号登录</p>
              <button onClick={clearPending} className="mt-2 text-xs text-blue-600 hover:text-blue-800 underline">清除</button>
            </div>
          </div>
        </div>
      )}

      {isFrozen && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
          <div className="w-5 h-5 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 mt-0.5"><span className="text-red-600 text-xs font-bold">!</span></div>
          <p className="text-red-700 text-sm">账户已临时冻结，请使用验证码登录或联系管理员</p>
        </div>
      )}

      {!isFrozen && loginAttempts > 0 && loginMethod === 'password' && (
        <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-amber-700 text-sm">已连续错误 {loginAttempts} 次，{5 - loginAttempts} 次后将临时冻结</p>
        </div>
      )}

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1.5">登录账号</label>
          <div className="relative">
            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type="text" placeholder="请输入登录账号" value={loginData.account}
              onChange={e => setLoginData(prev => ({ ...prev, account: e.target.value }))}
              className={`w-full pl-10 pr-4 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.account ? 'border-red-300 focus:border-red-500' : 'border-slate-200 focus:border-blue-500'}`} />
          </div>
          {errors.account && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.account}</p>}
        </div>

        {loginMethod === 'password' && (
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-sm font-medium text-slate-700">密码</label>
              <button onClick={onGoForgotPassword} className="text-xs text-blue-600 hover:text-blue-700 transition-colors">忘记密码？</button>
            </div>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type={showPassword ? 'text' : 'password'} placeholder="请输入密码" value={loginData.password}
                onChange={e => setLoginData(prev => ({ ...prev, password: e.target.value }))} disabled={isFrozen}
                className={`w-full pl-10 pr-10 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.password ? 'border-red-300 focus:border-red-500' : 'border-slate-200 focus:border-blue-500'} ${isFrozen ? 'opacity-50 cursor-not-allowed' : ''}`} />
              <button onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}</button>
            </div>
            {errors.password && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.password}</p>}
          </div>
        )}

        {loginMethod === 'verificationCode' && (
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">验证码</label>
            <div className="flex gap-3">
              <input type="text" placeholder="请输入6位验证码" maxLength={6} value={loginData.verificationCode}
                onChange={e => setLoginData(prev => ({ ...prev, verificationCode: e.target.value.replace(/\D/g, '') }))}
                className={`flex-1 px-4 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 tracking-widest text-center ${errors.verificationCode ? 'border-red-300 focus:border-red-500' : 'border-slate-200 focus:border-blue-500'}`} />
              <button onClick={sendCode} disabled={codeCountdown > 0 || !loginData.account}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${codeCountdown > 0 || !loginData.account ? 'bg-slate-100 text-slate-400 cursor-not-allowed' : 'bg-blue-50 text-blue-700 hover:bg-blue-100'}`}>
                {codeCountdown > 0 ? `${codeCountdown}s` : '获取验证码'}</button>
            </div>
            {errors.verificationCode && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.verificationCode}</p>}
          </div>
        )}

        <div className="flex items-center">
          <input type="checkbox" id="rememberMe" checked={loginData.rememberMe}
            onChange={e => setLoginData(prev => ({ ...prev, rememberMe: e.target.checked }))}
            className="w-4 h-4 rounded border-slate-300 text-blue-700 focus:ring-blue-500/20" />
          <label htmlFor="rememberMe" className="ml-2 text-sm text-slate-600">记住我（7天有效）</label>
        </div>

        {errors.general && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg"><p className="text-red-600 text-sm">{errors.general}</p></div>
        )}

        <button onClick={onLogin} disabled={isLoading}
          className="w-full py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg disabled:opacity-60">
          {isLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> 登录中...</> : <>立即登录 <ArrowRight className="w-4 h-4" /></>}
        </button>
      </div>

      <div className="flex items-center gap-4 my-6">
        <div className="flex-1 h-px bg-slate-200" /><span className="text-xs text-slate-400">还没有账号？</span><div className="flex-1 h-px bg-slate-200" />
      </div>

      <button onClick={onGoRegister}
        className="w-full py-3 border-2 border-blue-200 text-blue-700 rounded-lg font-medium text-sm hover:bg-blue-50 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
        注册成为供应商 <ArrowRight className="w-4 h-4" />
      </button>

      <div className="mt-6 p-4 bg-slate-50 border border-slate-200 rounded-lg">
        <div className="flex items-center gap-2 mb-2"><AlertTriangle className="w-4 h-4 text-amber-500" /><p className="text-xs font-medium text-slate-600">演示模式</p></div>
        <p className="text-xs text-slate-500 mb-3">密码登录输入 &quot;password&quot; 即可成功</p>
        <button onClick={() => { const mockData = { companyName: '演示科技有限公司', phone: loginData.account || '13800138000', email: '' }; localStorage.setItem('pending_review', JSON.stringify(mockData)); window.location.reload(); }}
          className="w-full py-2 bg-amber-50 border border-amber-200 text-amber-700 rounded-md text-xs font-medium hover:bg-amber-100 transition-colors">模拟：已提交未审核状态</button>
      </div>
    </div>
  );
}
