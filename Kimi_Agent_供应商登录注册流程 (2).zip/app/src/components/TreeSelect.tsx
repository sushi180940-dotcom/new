import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Search, ChevronDown, ChevronRight, X, Building2 } from 'lucide-react';

export interface TreeNode {
  id: string;
  label: string;
  children?: TreeNode[];
}

// 树形数据：省厅 → 具体单位（直属部门/地市公安局）
export const defaultTreeData: TreeNode[] = [
  {
    id: ' Provincial',
    label: '省公安厅',
    children: [
      { id: 'dept-kx', label: '科信处' },
      { id: 'dept-wa', label: '网安总队' },
      { id: 'dept-xz', label: '刑侦总队' },
      { id: 'dept-za', label: '治安总队' },
      { id: 'dept-jj', label: '交警总队' },
      { id: 'dept-jc', label: '经侦总队' },
      { id: 'dept-zd', label: '禁毒总队' },
      { id: 'city-a', label: '市公安局A' },
      { id: 'city-b', label: '市公安局B' },
      { id: 'city-c', label: '市公安局C' },
      { id: 'city-d', label: '市公安局D' },
      { id: 'city-e', label: '市公安局E' },
      { id: 'city-f', label: '市公安局F' },
      { id: 'city-g', label: '市公安局G' },
      { id: 'city-h', label: '市公安局H' },
      { id: 'city-i', label: '市公安局I' },
      { id: 'city-j', label: '市公安局J' },
      { id: 'city-k', label: '市公安局K' },
      { id: 'city-l', label: '市公安局L' },
    ],
  },
];

interface TreeSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
}

export default function TreeSelect({ value, onChange, placeholder = '请选择意向供货单位', error }: TreeSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set([' Provincial']));
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  // 点击外部关闭
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // 打开时聚焦搜索框
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => searchRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // 扁平化获取所有叶子节点标签
  const leafMap = useMemo(() => {
    const map = new Map<string, string>();
    const traverse = (nodes: TreeNode[]) => {
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          traverse(node.children);
        }
        map.set(node.id, node.label);
      });
    };
    traverse(defaultTreeData);
    return map;
  }, []);

  // 搜索过滤
  const filteredTree = useMemo(() => {
    if (!search.trim()) return defaultTreeData;
    const lower = search.toLowerCase();

    const filterNodes = (nodes: TreeNode[]): TreeNode[] => {
      return nodes.reduce<TreeNode[]>((acc, node) => {
        const matchSelf = node.label.toLowerCase().includes(lower);
        const filteredChildren = node.children ? filterNodes(node.children) : [];

        if (matchSelf) {
          acc.push({ ...node, children: node.children });
        } else if (filteredChildren.length > 0) {
          acc.push({ ...node, children: filteredChildren });
        }
        return acc;
      }, []);
    };

    return filterNodes(defaultTreeData);
  }, [search]);

  // 自动展开搜索结果的父节点
  useEffect(() => {
    if (search.trim()) {
      const newExpanded = new Set<string>();
      const collectParent = (nodes: TreeNode[]) => {
        nodes.forEach(n => {
          newExpanded.add(n.id);
          if (n.children) collectParent(n.children);
        });
      };
      collectParent(filteredTree);
      setExpanded(newExpanded);
    } else {
      setExpanded(new Set([' Provincial']));
    }
  }, [search, filteredTree]);

  const toggleExpanded = useCallback((id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const selectedLabel = value ? leafMap.get(value) || value : '';

  // 判断节点是否有子节点
  const hasChildren = (node: TreeNode) => node.children && node.children.length > 0;

  // 渲染树节点
  const renderNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expanded.has(node.id);
    const isSelected = value === node.id;
    const children = node.children || [];
    const nodeHasChildren = hasChildren(node);

    return (
      <div key={node.id}>
        <div
          className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md transition-colors cursor-pointer hover:bg-blue-50 ${depth > 0 ? 'ml-4' : ''}`}
          onClick={() => {
            if (nodeHasChildren) {
              toggleExpanded(node.id);
            } else {
              onChange(node.id);
              setIsOpen(false);
              setSearch('');
            }
          }}
        >
          {nodeHasChildren ? (
            <button
              onClick={e => { e.stopPropagation(); toggleExpanded(node.id); }}
              className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-blue-600 transition-colors flex-shrink-0"
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          {/* 单选圆点（仅叶子节点） */}
          {!nodeHasChildren ? (
            <div
              className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 transition-colors ${
                isSelected ? 'border-blue-700' : 'border-slate-300 hover:border-blue-500'
              }`}
              onClick={e => { e.stopPropagation(); onChange(node.id); setIsOpen(false); setSearch(''); }}
            >
              {isSelected && <div className="w-2 h-2 rounded-full bg-blue-700" />}
            </div>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          <span className={`text-sm flex-1 truncate ${nodeHasChildren ? 'font-medium text-slate-700' : 'text-slate-600'}`}>
            {node.label}
          </span>
        </div>

        {/* 子节点 */}
        {nodeHasChildren && isExpanded && (
          <div className="mt-0.5">
            {children.map(child => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div ref={containerRef} className="relative">
      {/* 输入框 */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full min-h-[46px] px-3 py-2 bg-white border rounded-lg text-sm transition-all outline-none cursor-pointer flex items-center gap-2 ${
          isOpen ? 'ring-2 ring-blue-500/20 border-blue-500' : error ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        {!selectedLabel ? (
          <span className="text-slate-400">{placeholder}</span>
        ) : (
          <>
            <Building2 className="w-4 h-4 text-blue-600 flex-shrink-0" />
            <span className="text-slate-700 font-medium flex-1 truncate">{selectedLabel}</span>
            <button
              onClick={e => { e.stopPropagation(); onChange(''); }}
              className="p-0.5 hover:bg-red-100 rounded transition-colors flex-shrink-0"
            >
              <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
            </button>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-slate-400 ml-auto transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </div>

      {/* 下拉面板 */}
      {isOpen && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          {/* 搜索框 */}
          <div className="p-2 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                ref={searchRef}
                type="text"
                placeholder="搜索单位名称..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              />
            </div>
          </div>

          {/* 树形列表 */}
          <div className="max-h-72 overflow-y-auto p-2">
            {filteredTree.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                未找到匹配的单位
              </div>
            ) : (
              filteredTree.map(node => renderNode(node))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
