import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { ArrowLeft, User, Phone, Mail, Shield, CreditCard, Factory, Landmark, FileCheck, Edit3, Check, X, MapPin, UserCircle, Hash, DollarSign } from 'lucide-react';

// 从 localStorage 读取注册数据，回退到演示数据
function getStoredData() {
  try {
    const draft = localStorage.getItem('supplier_register_draft');
    if (draft) {
      const parsed = JSON.parse(draft);
      return { company: parsed.companyInfo || {}, hasRealData: true };
    }
  } catch { /* ignore */ }
  // 演示数据
  return {
    company: {
      companyName: '华为技术有限公司',
      shortName: '华为',
      creditCode: '91110000123456789X',
      registerAddress: '广东省深圳市龙岗区',
      legalPerson: '任正非',
      registeredCapital: '10000万元',
      registerProvince: '广东',
      supplierType: '生产商,协议供货商',
      cooperationUnit: 'dept-kx',
      contactName: '张三',
      idType: '身份证',
      idNumber: '110101199001011234',
      contactPhone: '13800138000',
      email: 'zhangsan@huawei.com',
      responsiblePerson: '李四',
      loginPhone: '13900139000',
    },
    hasRealData: false,
  };
}

// 树形数据中 code 转 label
const unitMap: Record<string, string> = {
  'dept-kx': '科信处', 'dept-wa': '网安总队', 'dept-xz': '刑侦总队', 'dept-za': '治安总队',
  'dept-jj': '交警总队', 'dept-jc': '经侦总队', 'dept-zd': '禁毒总队',
  'city-a': '市公安局A', 'city-b': '市公安局B', 'city-c': '市公安局C', 'city-d': '市公安局D',
  'city-e': '市公安局E', 'city-f': '市公安局F', 'city-g': '市公安局G', 'city-h': '市公安局H',
  'city-i': '市公安局I', 'city-j': '市公安局J', 'city-k': '市公安局K', 'city-l': '市公安局L',
};

export default function Profile() {
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [data, setData] = useState(getStoredData);

  // 可编辑的联系信息
  const [editContact, setEditContact] = useState({
    contactName: data.company.contactName || '',
    contactPhone: data.company.contactPhone || '',
    email: data.company.email || '',
    loginPhone: data.company.loginPhone || '',
    responsiblePerson: data.company.responsiblePerson || '',
  });

  useEffect(() => {
    const d = getStoredData();
    setData(d);
    setEditContact({
      contactName: d.company.contactName || '',
      contactPhone: d.company.contactPhone || '',
      email: d.company.email || '',
      loginPhone: d.company.loginPhone || '',
      responsiblePerson: d.company.responsiblePerson || '',
    });
  }, []);

  const c = data.company;
  const supplierTypes = c.supplierType ? c.supplierType.split(',').filter(Boolean) : [];
  const cooperationUnitLabel = unitMap[c.cooperationUnit] || c.cooperationUnit || '-';

  const handleSave = () => {
    // 更新 localStorage 中的草稿数据
    const draft = localStorage.getItem('supplier_register_draft');
    if (draft) {
      try {
        const parsed = JSON.parse(draft);
        parsed.companyInfo = { ...parsed.companyInfo, ...editContact };
        localStorage.setItem('supplier_register_draft', JSON.stringify(parsed));
      } catch { /* ignore */ }
    }
    setIsEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const editableField = (label: string, value: string, field: string, icon: React.ReactNode) => (
    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
      <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 border border-slate-200">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-slate-500">{label}</p>
        {isEditing ? (
          <input type="text" value={value}
            onChange={e => setEditContact(prev => ({ ...prev, [field]: e.target.value }))}
            className="w-full mt-1 px-3 py-1.5 bg-white border border-slate-200 rounded text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" />
        ) : (
          <p className="text-sm font-medium text-slate-800 truncate">{value || '-'}</p>
        )}
      </div>
    </div>
  );

  const readonlyField = (label: string, value: string, icon: React.ReactNode) => (
    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
      <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center text-slate-400 border border-slate-200">{icon}</div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-sm font-medium text-slate-800 truncate">{value || '-'}</p>
      </div>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-5">
      <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-sm text-slate-600 hover:text-blue-700 transition-colors">
        <ArrowLeft className="w-4 h-4" /> 返回装备采购管理
      </button>

      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold text-slate-800">企业个人中心</h1>
        {!isEditing ? (
          <button onClick={() => setIsEditing(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
            <Edit3 className="w-4 h-4" /> 编辑联系信息
          </button>
        ) : (
          <div className="flex items-center gap-2">
            <button onClick={() => setIsEditing(false)}
              className="flex items-center gap-2 px-4 py-2 border border-slate-200 text-slate-600 rounded-lg text-sm hover:bg-slate-50"><X className="w-4 h-4" /> 取消</button>
            <button onClick={handleSave}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"><Check className="w-4 h-4" /> 保存</button>
          </div>
        )}
      </div>

      {saved && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2 animate-fade-in">
          <Check className="w-4 h-4 text-green-600" /><p className="text-sm text-green-700">保存成功！</p>
        </div>
      )}

      {!data.hasRealData && (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-center gap-2">
          <Shield className="w-4 h-4 text-blue-600" /><p className="text-sm text-blue-700">当前展示演示数据。完成供应商注册后将显示您的真实企业信息。</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* 企业信息卡片 */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 p-5">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-12 h-12 rounded-xl bg-gradient-police flex items-center justify-center text-white text-lg font-bold">
              {(c.companyName || '?').charAt(0)}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-800">{c.companyName || '未填写企业名称'}</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium"><Shield className="w-3 h-3" />已认证</span>
                {c.shortName && <span className="text-xs text-slate-400">简称：{c.shortName}</span>}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="grid grid-cols-2 gap-2">
              {readonlyField('统一社会信用代码', c.creditCode, <CreditCard className="w-4 h-4" />)}
              {readonlyField('法定代表人', c.legalPerson, <UserCircle className="w-4 h-4" />)}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {readonlyField('注册地', c.registerAddress, <MapPin className="w-4 h-4" />)}
              {readonlyField('注册地省（市）', c.registerProvince, <MapPin className="w-4 h-4" />)}
            </div>
            <div className="grid grid-cols-2 gap-2">
              {readonlyField('注册资金', c.registeredCapital, <DollarSign className="w-4 h-4" />)}
              {readonlyField('合作单位', cooperationUnitLabel, <Landmark className="w-4 h-4" />)}
            </div>
            <div className="p-3 bg-slate-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Factory className="w-4 h-4 text-slate-400" /><p className="text-xs text-slate-500">供应商类型</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {supplierTypes.length > 0 ? supplierTypes.map((t: string, i: number) => (
                  <span key={i} className="px-2 py-1 bg-blue-50 text-blue-700 rounded-md text-xs font-medium border border-blue-200">{t}</span>
                )) : <span className="text-sm text-slate-400">未选择</span>}
              </div>
            </div>
            {readonlyField('营业执照', '已上传', <FileCheck className="w-4 h-4" />)}
          </div>
        </div>

        {/* 联系信息卡片 */}
        <div className="bg-white rounded-xl border border-slate-200 p-5">
          <h2 className="text-base font-bold text-slate-800 mb-5 flex items-center gap-2">
            <User className="w-5 h-5 text-blue-600" /> 联系信息
            {isEditing && <span className="text-xs font-normal text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">编辑中</span>}
          </h2>

          <div className="space-y-2">
            {editableField('联系人', editContact.contactName, 'contactName', <User className="w-4 h-4" />)}
            {editableField('联系电话', editContact.contactPhone, 'contactPhone', <Phone className="w-4 h-4" />)}
            {editableField('邮箱', editContact.email, 'email', <Mail className="w-4 h-4" />)}
            {editableField('负责人', editContact.responsiblePerson, 'responsiblePerson', <UserCircle className="w-4 h-4" />)}
            {editableField('登录手机号', editContact.loginPhone, 'loginPhone', <Phone className="w-4 h-4" />)}
            {readonlyField('证件类型', c.idType, <FileCheck className="w-4 h-4" />)}
            {readonlyField('证件号码', c.idNumber, <Hash className="w-4 h-4" />)}
          </div>

          {!isEditing && <p className="mt-4 text-xs text-slate-400 text-center">点击右上角"编辑联系信息"可修改联系信息</p>}
        </div>
      </div>
    </div>
  );
}
