import AuthLayout from '@/components/AuthLayout';
import LoginForm from '@/components/LoginForm';
import RegisterForm from '@/components/RegisterForm';
import ForgotPassword from '@/components/ForgotPassword';
import ReviewStatus from '@/components/ReviewStatus';
import { useAuth } from '@/hooks/useAuth';

export default function AuthPage() {
  const auth = useAuth();

  return (
    <AuthLayout>
      {auth.currentView === 'login' && (
        <LoginForm
          loginMethod={auth.loginMethod}
          loginData={auth.loginData}
          errors={auth.errors}
          isLoading={auth.isLoading}
          isFrozen={auth.isFrozen}
          loginAttempts={auth.loginAttempts}
          pendingReview={auth.pendingReview}
          setLoginMethod={auth.setLoginMethod}
          setLoginData={auth.setLoginData}
          setErrors={auth.setErrors}
          onLogin={auth.handleLogin}
          onGoRegister={auth.goToRegister}
          onGoForgotPassword={auth.goToForgotPassword}
        />
      )}

      {auth.currentView === 'register' && (
        <RegisterForm
          registerStep={auth.registerStep}
          registerData={auth.registerData}
          errors={auth.errors}
          isLoading={auth.isLoading}
          agreedNotice={auth.agreedNotice}
          updateCompanyInfo={auth.updateCompanyInfo}
          updateQualificationFiles={auth.updateQualificationFiles}
          updateAccountSecurity={auth.updateAccountSecurity}
          setAgreedNotice={auth.setAgreedNotice}
          onNextStep={auth.nextStep}
          onPrevStep={auth.prevStep}
          onStepClick={auth.goToStep}
          onSubmit={auth.handleRegister}
          onGoLogin={auth.goToLogin}
        />
      )}

      {auth.currentView === 'forgotPassword' && (
        <ForgotPassword
          forgotData={auth.forgotData}
          errors={auth.errors}
          isLoading={auth.isLoading}
          setForgotData={auth.setForgotData}
          onSubmit={auth.handleForgotPassword}
          onGoLogin={auth.goToLogin}
        />
      )}

      {auth.currentView === 'reviewStatus' && (
        <ReviewStatus
          reviewInfo={auth.reviewInfo}
          onGoLogin={auth.goToLogin}
        />
      )}
    </AuthLayout>
  );
}
