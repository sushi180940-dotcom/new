import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  FileText, CreditCard, Package, Clock, ClipboardList,
  FileCheck, ShoppingBag, Search, RotateCcw, Plus,
  X, Trash2, Eye, Pencil, SearchIcon, AlertTriangle, Upload, Minus, ArrowLeft
} from 'lucide-react';
import TreeSelect, { defaultTreeData } from '@/components/TreeSelect';

// ==================== 分类级联数据 ====================
const categoryTree: Record<string, Record<string, string[]>> = {
  '通信设备': {
    '手持终端': ['警用级', '民用级'],
    '卫星通信': ['便携型', '车载型'],
    '对讲设备': ['数字型', '模拟型'],
    '基站设备': ['应急型', '固定型'],
  },
  '监控设备': {
    '执法记录': ['高清型', '标准型'],
    '摄像头': ['红外型', '普通型'],
  },
  '防护装备': {
    '防弹装备': ['三级防护', '二级防护'],
    '头部防护': ['战术级', '标准级'],
    '防护服装': ['战术级', '防暴级'],
  },
  '救援装备': {
    '无人机': ['侦察型', '救援型', '专业型'],
    '破拆工具': ['液压型', '电动型'],
  },
  '照明设备': {
    '应急照明': ['便携型', '移动型'],
    '信号照明': ['手持型', '固定型'],
  },
};

// ==================== 合作单位label映射 ====================
const unitLabelMap: Record<string, string> = {};
function buildUnitLabelMap(nodes: typeof defaultTreeData, prefix = '') {
  nodes.forEach(n => {
    const label = prefix ? `${prefix} / ${n.label}` : n.label;
    unitLabelMap[n.id] = label;
    if (n.children) buildUnitLabelMap(n.children, label);
  });
}
buildUnitLabelMap(defaultTreeData);

// 获取所有叶子节点ID列表
const unitLeafIds: string[] = [];
function collectLeafIds(nodes: typeof defaultTreeData) {
  nodes.forEach(n => {
    if (n.children && n.children.length > 0) collectLeafIds(n.children);
    else unitLeafIds.push(n.id);
  });
}
collectLeafIds(defaultTreeData);

// ==================== 通用工具函数 ====================
function multiKeywordMatch(text: string, keywords: string[]): boolean {
  if (keywords.length === 0) return true;
  const lowerText = text.toLowerCase();
  return keywords.every(k => lowerText.includes(k.toLowerCase()));
}

function parseKeywords(query: string): string[] {
  return query.trim().split(/\s+/).filter(k => k.length > 0);
}

function HighlightText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;
  const keywords = parseKeywords(query);
  if (keywords.length === 0) return <>{text}</>;
  let html = text;
  keywords.forEach(k => {
    const re = new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    html = html.replace(re, '<mark style="background:#fef3c7;color:#92400e;padding:1px 2px;border-radius:2px">$&</mark>');
  });
  return <span dangerouslySetInnerHTML={{ __html: html }} />;
}

function isDateInRange(dateStr: string, startStr: string, endStr: string): boolean {
  if (!startStr && !endStr) return true;
  const d = new Date(dateStr);
  if (startStr && d < new Date(startStr)) return false;
  if (endStr && d > new Date(endStr + 'T23:59:59')) return false;
  return true;
}

// ==================== 类型定义 ====================
interface RfidTag {
  id: string; orderId: string; itemIndex: number; code: string;
  tagType: '0' | '1'; productDate: string; expireMonths: number;
  serialNo: string; status: 'unprinted' | 'printed' | 'shipped' | 'void';
  printCount: number; createdAt: string;
}

interface OrderItem {
  cat1: string; cat2: string; cat3: string; name: string; model: string;
  unit: string; quantity: number; price: number; code: string; tags: RfidTag[];
}

interface Order {
  id: string; name: string; contractId: string;
  supplier: string; supplierCode: string; deliveryDate: string;
  receiver: string; items: OrderItem[];
  shipStatus: 'pending' | 'partial' | 'shipped';
  shippedAt?: string;
}

interface Contract {
  id: string; partyA: string; partyB: string; name: string;
  amount: string; signDate: string; deliveryDate: string;
  note: string; attachment: string;
  status: '草稿' | '履行中' | '已发货' | '已验收' | '终止';
  orderIds: string[];
}

interface Product {
  id: string; cat1: string; cat2: string; cat3: string;
  name: string; model: string; code: string; unit: string;
  price: string; hasBattery: boolean; batteryCycle: number;
  note: string; image: string; status: string;
}

// ==================== RFID编码工具函数 ====================
function generateRfidCode(tagType: '0' | '1', equipCode: string, model: string, productDate: string, expireMonths: number, supplierCode: string, serialNo: number): string {
  const modelShort = model.slice(-3).padStart(3, '0');
  const expireStr = String(expireMonths).padStart(2, '0');
  const serialStr = String(serialNo).padStart(4, '0');
  return `${tagType}-${equipCode}-${modelShort}-${productDate}-${expireStr}-${supplierCode}-${serialStr}`;
}

function formatDateToYYMMDD(dateStr: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const yy = String(d.getFullYear()).slice(-2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

function getNextSerialNo(existingTags: RfidTag[]): number {
  if (existingTags.length === 0) return 1;
  const maxSerial = Math.max(...existingTags.map(t => parseInt(t.serialNo, 10)));
  return maxSerial + 1;
}

function countItemTags(item: OrderItem, tagType?: '0' | '1'): number {
  if (!tagType) return item.tags.length;
  return item.tags.filter(t => t.tagType === tagType).length;
}

function isItemFullyTagged(item: OrderItem): boolean {
  const equipTags = item.tags.filter(t => t.tagType === '0' && t.status !== 'void').length;
  return equipTags >= item.quantity;
}

type ModuleType = 'contract' | 'order' | 'product';

const MY_COMPANY = '华为技术有限公司';
const MY_CREDIT_CODE = '91110000123456789X';
const MY_SUPPLIER_CODE = MY_CREDIT_CODE.slice(8, 17);
const unitOptions = ['台', '套', '件', '顶', '面', '把', '架', '个', '支', '块', '条', '只', '组', '对'];

// ==================== 演示数据 ====================
const initialContracts: Contract[] = [
  { id: 'HT2024001', partyA: 'dept-kx', partyB: '华为技术有限公司', name: '指挥调度系统建设合同', amount: '680000', signDate: '2024-03-10', deliveryDate: '2024-06-10', note: '包含硬件设备和软件系统', attachment: '合同附件-HT2024001.pdf', status: '草稿', orderIds: [] },
  { id: 'HT2024002', partyA: 'dept-wa', partyB: '华为技术有限公司', name: '网络安全设备采购合同', amount: '360000', signDate: '2024-03-15', deliveryDate: '2024-05-15', note: '防火墙、入侵检测等安全设备', attachment: '', status: '履行中', orderIds: ['DD2024001'] },
  { id: 'HT2024003', partyA: 'dept-xz', partyB: '华为技术有限公司', name: '通信保障设备采购合同', amount: '500000', signDate: '2024-03-20', deliveryDate: '2024-07-20', note: '', attachment: '', status: '已验收', orderIds: ['DD2024002'] },
  { id: 'HT2024004', partyA: 'dept-za', partyB: '华为技术有限公司', name: '应急救援装备采购合同', amount: '510000', signDate: '2024-03-25', deliveryDate: '2024-06-25', note: '无人机、破拆工具等', attachment: '', status: '草稿', orderIds: [] },
  { id: 'HT2024005', partyA: 'dept-jj', partyB: '华为技术有限公司', name: '智能交通系统升级合同', amount: '680000', signDate: '2024-03-10', deliveryDate: '2024-09-10', note: '', attachment: '', status: '终止', orderIds: [] },
  { id: 'HT2024006', partyA: 'dept-kx', partyB: '华为技术有限公司', name: '数据中心建设合同', amount: '360000', signDate: '2024-04-01', deliveryDate: '2024-08-01', note: '服务器、存储设备等', attachment: '', status: '已发货', orderIds: ['DD2024003'] },
];

const initialOrders: Order[] = [
  { id: 'DD2024001', name: '网络安全设备首批订单', contractId: 'HT2024002', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-04-15', receiver: 'dept-wa', shipStatus: 'pending', items: [
    { cat1: '通信设备', cat2: '手持终端', cat3: '警用级', name: '手持终端', model: 'XT-2000', unit: '台', quantity: 20, price: 2500, code: '1000001', tags: [] },
    { cat1: '通信设备', cat2: '对讲设备', cat3: '数字型', name: '对讲机', model: 'PD780G', unit: '台', quantity: 50, price: 1800, code: '1000002', tags: [] },
  ]},
  { id: 'DD2024002', name: '通信保障设备订单', contractId: 'HT2024003', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-04-20', receiver: 'dept-xz', shipStatus: 'partial', items: [
    { cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', unit: '台', quantity: 50, price: 1200, code: '1000003', tags: [
      { id: 'rfid-001', orderId: 'DD2024002', itemIndex: 0, code: '0-1000003-7A7-250401-12-123456789-0001', tagType: '0', productDate: '250401', expireMonths: 12, serialNo: '0001', status: 'printed', printCount: 1, createdAt: '2025-04-01' },
    ] },
  ]},
  { id: 'DD2024003', name: '数据中心设备订单', contractId: 'HT2024006', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-05-10', receiver: 'dept-kx', shipStatus: 'pending', items: [
    { cat1: '通信设备', cat2: '基站设备', cat3: '应急型', name: '应急通信基站', model: 'EBS-100', unit: '套', quantity: 5, price: 35000, code: '1000004', tags: [] },
  ]},
];

const initialProducts: Product[] = [
  { id: '1', cat1: '通信设备', cat2: '手持终端', cat3: '警用级', name: '手持终端', model: 'XT-2000', code: '1000001', unit: '台', price: '¥2,500', hasBattery: true, batteryCycle: 12, note: '警用手持通信终端', image: '', status: '已上架' },
  { id: '2', cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', code: '1000002', unit: '台', price: '¥1,200', hasBattery: true, batteryCycle: 6, note: '高清执法记录', image: '', status: '已上架' },
  { id: '3', cat1: '救援装备', cat2: '无人机', cat3: '专业型', name: '无人机', model: 'M300-RTK', code: '1000003', unit: '架', price: '¥45,000', hasBattery: true, batteryCycle: 3, note: '专业救援无人机', image: '', status: '待审' },
  { id: '4', cat1: '照明设备', cat2: '应急照明', cat3: '便携型', name: '应急照明灯', model: 'YD-100', code: '1000004', unit: '台', price: '¥350', hasBattery: true, batteryCycle: 6, note: '应急照明设备', image: '', status: '已下架' },
  { id: '5', cat1: '通信设备', cat2: '对讲设备', cat3: '数字型', name: '对讲机', model: 'PD780G', code: '1000005', unit: '台', price: '¥1,800', hasBattery: true, batteryCycle: 12, note: '数字对讲机', image: '', status: '待审' },
  { id: '6', cat1: '防护装备', cat2: '防弹装备', cat3: '三级防护', name: '防弹背心', model: 'FDY-3R', code: '1000006', unit: '件', price: '¥3,200', hasBattery: false, batteryCycle: 0, note: '三级防弹背心', image: '', status: '已上架' },
  { id: '7', cat1: '防护装备', cat2: '头部防护', cat3: '战术级', name: '战术头盔', model: 'MICH-2000', code: '1000007', unit: '顶', price: '¥1,800', hasBattery: false, batteryCycle: 0, note: '战术防护头盔', image: '', status: '草稿' },
  { id: '8', cat1: '通信设备', cat2: '卫星通信', cat3: '便携型', name: '便携式卫星通信终端', model: 'SAT-100', code: '1000008', unit: '台', price: '¥85,000', hasBattery: true, batteryCycle: 24, note: '卫星通信设备', image: '', status: '审核未通过' },
];

// ==================== 主组件 ====================
export default function Dashboard() {
  const [activeModule, setActiveModule] = useState<ModuleType>('contract');
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [contracts, setContracts] = useState<Contract[]>(initialContracts);
  const [orders, setOrders] = useState<Order[]>(initialOrders);

  // 弹窗状态
  const [showRegister, setShowRegister] = useState(false);
  const [showNewProduct, setShowNewProduct] = useState(false);
  const [showDetail, setShowDetail] = useState<Product | null>(null);
  const [showContractModal, setShowContractModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ open: boolean; message: string; onConfirm: () => void }>({ open: false, message: '', onConfirm: () => {} });
  const [orderPrefill, setOrderPrefill] = useState<{ contractId?: string; receiver?: string } | null>(null);
  const [viewContract, setViewContract] = useState<Contract | null>(null);
  const [viewOrder, setViewOrder] = useState<Order | null>(null);
  const [transferKeyword, setTransferKeyword] = useState('');
  const [showCreateShipment, setShowCreateShipment] = useState(false);
  const [shipmentPrefillOrder, setShipmentPrefillOrder] = useState<Order | null>(null);

  // ===== 合同管理搜索状态 =====
  const [contractSearch, setContractSearch] = useState({ keywords: '', startDate: '', endDate: '' });

  // ===== 订单管理搜索状态 =====
  const [orderSearch, setOrderSearch] = useState({ keywords: '', contractId: '', receiver: '' });

  // ===== 商品管理搜索状态 =====
  const [productSearch, setProductSearch] = useState({
    keywords: '', cat1: '', cat2: '', cat3: '', status: ''
  });

  // ===== 过滤逻辑 =====
  const contractKeywords = parseKeywords(contractSearch.keywords);
  const filteredContracts = contracts.filter(d => {
    // 时间区间
    if (!isDateInRange(d.signDate, contractSearch.startDate, contractSearch.endDate)) return false;
    // 多关键词匹配（甲方/乙方/合同名称）
    if (contractKeywords.length === 0) return true;
    const searchText = `${unitLabelMap[d.partyA] || d.partyA} ${d.partyB} ${d.name}`;
    return multiKeywordMatch(searchText, contractKeywords);
  });

  const orderKeywords = parseKeywords(orderSearch.keywords);
  const filteredOrders = orders.filter(d => {
    // 关联合同筛选
    if (orderSearch.contractId && d.contractId !== orderSearch.contractId) return false;
    // 收货对象筛选
    if (orderSearch.receiver && d.receiver !== orderSearch.receiver) return false;
    // 多关键词匹配（订单名称）
    if (orderKeywords.length === 0) return true;
    return multiKeywordMatch(d.name, orderKeywords);
  });

  const productKeywords = parseKeywords(productSearch.keywords);
  const filteredProducts = products.filter(d => {
    // 分类筛选
    if (productSearch.cat1 && d.cat1 !== productSearch.cat1) return false;
    if (productSearch.cat2 && d.cat2 !== productSearch.cat2) return false;
    if (productSearch.cat3 && d.cat3 !== productSearch.cat3) return false;
    // 状态筛选
    if (productSearch.status && d.status !== productSearch.status) return false;
    // 多关键词匹配（装备名称/型号）
    if (productKeywords.length === 0) return true;
    const searchText = `${d.name} ${d.model}`;
    return multiKeywordMatch(searchText, productKeywords);
  });

  const stats = [
    { label: '总合同数', value: `${contracts.length}个`, icon: <FileText className="w-5 h-5 text-purple-600" />, bg: 'bg-purple-50' },
    { label: '总合同额', value: `¥${contracts.reduce((s, c) => s + (Number(c.amount) || 0), 0).toLocaleString()}`, icon: <CreditCard className="w-5 h-5 text-pink-600" />, bg: 'bg-pink-50' },
    { label: '订单数量', value: `${orders.length}个`, icon: <ClipboardList className="w-5 h-5 text-blue-600" />, bg: 'bg-blue-50' },
    { label: '已上架商品', value: `${products.filter(p => p.status === '已上架').length}件`, icon: <Package className="w-5 h-5 text-green-600" />, bg: 'bg-green-50' },
    { label: '待审核商品', value: `${products.filter(p => p.status === '待审').length}件`, icon: <Clock className="w-5 h-5 text-amber-600" />, bg: 'bg-amber-50' },
  ];

  const modules = [
    { key: 'contract' as ModuleType, label: '合同管理', desc: '合同签订与执行', icon: <FileCheck className="w-6 h-6 text-blue-600" />, count: contracts.length, color: 'border-blue-500 ring-2 ring-blue-100' },
    { key: 'order' as ModuleType, label: '订单管理', desc: '订单验收与管理', icon: <ClipboardList className="w-6 h-6 text-amber-600" />, count: orders.length, color: 'border-amber-500 ring-2 ring-amber-100' },
    { key: 'product' as ModuleType, label: '商品管理', desc: '商品报备与审核', icon: <ShoppingBag className="w-6 h-6 text-green-600" />, count: products.length, color: 'border-green-500 ring-2 ring-green-100' },
  ];

  const statusTag = (s: string) => {
    const m: Record<string, string> = {
      '草稿': 'bg-slate-100 text-slate-600', '履行中': 'bg-blue-100 text-blue-700', '已发货': 'bg-purple-100 text-purple-700', '已验收': 'bg-green-100 text-green-700',
      '终止': 'bg-red-100 text-red-700', '已上架': 'bg-green-100 text-green-700', '待审': 'bg-amber-100 text-amber-700',
      '已下架': 'bg-slate-100 text-slate-500', '审核未通过': 'bg-red-100 text-red-700',
    };
    return m[s] || 'bg-slate-100 text-slate-600';
  };

  const goToNewProduct = (keyword: string) => {
    setShowRegister(false); setTransferKeyword(keyword); setShowNewProduct(true);
  };

  const handleFillOrder = (contract: Contract) => {
    setActiveModule('order');
    setOrderPrefill({ contractId: contract.id, receiver: contract.partyA });
    setTimeout(() => setShowOrderModal(true), 100);
  };

  const handleDeleteContract = (id: string) => {
    setConfirmModal({ open: true, message: '确定删除该合同吗？删除后不可恢复。', onConfirm: () => { setContracts(prev => prev.filter(c => c.id !== id)); setConfirmModal(prev => ({ ...prev, open: false })); } });
  };

  const handlePriceEdit = (id: string, newPrice: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, price: `¥${newPrice}` } : p));
  };

  const getContractName = useCallback((contractId: string) => contracts.find(c => c.id === contractId)?.name || contractId, [contracts]);

  const contractActions = (c: Contract) => {
    const btns: React.ReactNode[] = [<button key="view" onClick={() => setViewContract(c)} className="text-blue-600 hover:underline text-xs">查看</button>];
    if (c.status === '草稿') {
      btns.push(<button key="edit" onClick={() => setViewContract(c)} className="text-amber-600 hover:underline text-xs">编辑</button>);
      btns.push(<button key="del" onClick={() => handleDeleteContract(c.id)} className="text-red-500 hover:underline text-xs">删除</button>);
    }
    if (c.status === '履行中') {
      btns.push(<button key="order" onClick={() => handleFillOrder(c)} className="text-blue-600 hover:underline text-xs">填写订单</button>);
    }
    return <div className="flex items-center gap-2">{btns}</div>;
  };

  // 商品搜索二级/三级分类选项
  const productCat2Options = productSearch.cat1 ? Object.keys(categoryTree[productSearch.cat1] || {}) : [];
  const productCat3Options = productSearch.cat1 && productSearch.cat2 ? (categoryTree[productSearch.cat1]?.[productSearch.cat2] || []) : [];

  return (
    <div className="space-y-5">
      <h1 className="text-lg font-bold text-slate-800">装备采购管理</h1>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-white rounded-xl p-4 border border-slate-200 shadow-police">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ background: s.bg === 'bg-purple-50' ? '#f3e8ff' : s.bg === 'bg-pink-50' ? '#fce7f3' : s.bg === 'bg-blue-50' ? '#dbeafe' : s.bg === 'bg-green-50' ? '#dcfce7' : '#fef9c3' }}>
              {s.icon}
            </div>
            <p className="text-xs text-slate-500">{s.label}</p>
            <p className="text-base font-bold text-slate-800 mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* 功能模块 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {modules.map(m => (
          <button key={m.key} onClick={() => setActiveModule(m.key)}
            className={`flex items-center gap-4 p-5 bg-white rounded-xl border-2 transition-all text-left hover:shadow-md ${activeModule === m.key ? m.color : 'border-slate-200 hover:border-slate-300'}`}>
            <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center flex-shrink-0">{m.icon}</div>
            <div className="flex-1">
              <div className="flex items-center gap-2"><h3 className="text-base font-bold text-slate-800">{m.label}</h3><span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">{m.count}</span></div>
              <p className="text-xs text-slate-500 mt-0.5">{m.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* ====== 合同管理 ====== */}
      {activeModule === 'contract' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => setShowContractModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"><Plus className="w-4 h-4" /> 新增合同</button>
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600 whitespace-nowrap">签订时间:</span>
                <input type="date" value={contractSearch.startDate} onChange={e => setContractSearch(p => ({ ...p, startDate: e.target.value }))}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" />
                <span className="text-sm text-slate-400">~</span>
                <input type="date" value={contractSearch.endDate} onChange={e => setContractSearch(p => ({ ...p, endDate: e.target.value }))}
                  className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <div className="flex-1 min-w-[200px] relative">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="搜索甲方/乙方/合同名称（空格分隔多关键词）"
                  value={contractSearch.keywords} onChange={e => setContractSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setContractSearch({ keywords: '', startDate: '', endDate: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 w-10"><input type="checkbox" className="rounded" /></th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">甲方</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">乙方</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">合同名称</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">合同金额</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">签订日期</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">最终交货日期</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">备注</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">操作</th>
                </tr></thead>
                <tbody>{filteredContracts.map((c, i) => (
                  <tr key={i} className="border-b border-slate-100 hover:bg-blue-50/30 transition-colors">
                    <td className="px-4 py-3"><input type="checkbox" className="rounded" /></td>
                    <td className="px-4 py-3 text-slate-600">
                      <HighlightText text={unitLabelMap[c.partyA] || c.partyA} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      <HighlightText text={c.partyB} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-800">
                      <HighlightText text={c.name} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 text-slate-800 font-medium">¥{Number(c.amount).toLocaleString()}</td>
                    <td className="px-4 py-3 text-slate-500">{c.signDate}</td>
                    <td className="px-4 py-3 text-slate-500">{c.deliveryDate}</td>
                    <td className="px-4 py-3 text-slate-500 max-w-[150px] truncate" title={c.note}>{c.note || '-'}</td>
                    <td className="px-4 py-3">{contractActions(c)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <Pagination total={filteredContracts.length} />
          </div>
        </div>
      )}

      {/* ====== 订单管理 ====== */}
      {activeModule === 'order' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => { setOrderPrefill(null); setShowOrderModal(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"><Plus className="w-4 h-4" /> 新增订单</button>
            <button onClick={() => { setShipmentPrefillOrder(null); setShowCreateShipment(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"><Plus className="w-4 h-4" /> 新建发货单</button>
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-3">
              <select value={orderSearch.contractId} onChange={e => setOrderSearch(p => ({ ...p, contractId: e.target.value }))}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none min-w-[140px]">
                <option value="">关联合同</option>
                {contracts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <select value={orderSearch.receiver} onChange={e => setOrderSearch(p => ({ ...p, receiver: e.target.value }))}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none min-w-[140px]">
                <option value="">收货对象</option>
                {unitLeafIds.map(id => <option key={id} value={id}>{unitLabelMap[id]}</option>)}
              </select>
              <div className="relative flex-1 min-w-[200px]">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="搜索订单名称（空格分隔多关键词）"
                  value={orderSearch.keywords} onChange={e => setOrderSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setOrderSearch({ keywords: '', contractId: '', receiver: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 w-10"><input type="checkbox" className="rounded" /></th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">订单名称</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">关联合同</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">供应商</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">企业编码</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">预计送货日期</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">收货对象</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">状态</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">操作</th>
                </tr></thead>
                <tbody>{filteredOrders.map((o, i) => {
                  const totalItems = o.items.reduce((s, it) => s + it.quantity, 0);
                  const shippedItems = o.items.reduce((s, it) => s + it.tags.filter(t => t.status === 'shipped').length, 0);
                  const statusMap: Record<string, string> = {
                    pending: `待发货 0/${totalItems}`,
                    partial: `已发货 ${shippedItems}/${totalItems}`,
                    shipped: `已发货 ${shippedItems}/${totalItems}`,
                  };
                  return (
                    <tr key={i} className="border-b border-slate-100 hover:bg-blue-50/30 transition-colors">
                      <td className="px-4 py-3"><input type="checkbox" className="rounded" /></td>
                      <td className="px-4 py-3 font-medium text-slate-800">
                        <HighlightText text={o.name} query={orderSearch.keywords} />
                      </td>
                      <td className="px-4 py-3 text-slate-600">{getContractName(o.contractId)}</td>
                      <td className="px-4 py-3 text-slate-600">{o.supplier}</td>
                      <td className="px-4 py-3 text-slate-500">{o.supplierCode}</td>
                      <td className="px-4 py-3 text-slate-500">{o.deliveryDate}</td>
                      <td className="px-4 py-3 text-slate-600">{unitLabelMap[o.receiver] || o.receiver}</td>
                      <td className="px-4 py-3 text-xs text-slate-700">{statusMap[o.shipStatus]}</td>
                      <td className="px-4 py-3">
                        <button onClick={() => setViewOrder(o)} className="text-blue-600 hover:underline text-xs">查看</button>
                      </td>
                    </tr>
                  );
                })}</tbody>
              </table>
            </div>
            <Pagination total={filteredOrders.length} />
          </div>
        </div>
      )}

      {/* ====== 商品管理 ====== */}
      {activeModule === 'product' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => { setTransferKeyword(''); setShowRegister(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700"><Plus className="w-4 h-4" /> 商品信息登记</button>
            <button onClick={() => { setTransferKeyword(''); setShowNewProduct(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"><Plus className="w-4 h-4" /> 新品申报</button>
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-3">
              <select value={productSearch.cat1} onChange={e => setProductSearch(p => ({ ...p, cat1: e.target.value, cat2: '', cat3: '' }))}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none">
                <option value="">一级分类</option>
                {Object.keys(categoryTree).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={productSearch.cat2} onChange={e => setProductSearch(p => ({ ...p, cat2: e.target.value, cat3: '' }))}
                disabled={!productSearch.cat1}
                className={`px-3 py-2 border rounded-lg text-sm outline-none ${!productSearch.cat1 ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-slate-50 border-slate-200'}`}>
                <option value="">{productSearch.cat1 ? '二级分类' : '请先选一级'}</option>
                {productCat2Options.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={productSearch.cat3} onChange={e => setProductSearch(p => ({ ...p, cat3: e.target.value }))}
                disabled={!productSearch.cat2}
                className={`px-3 py-2 border rounded-lg text-sm outline-none ${!productSearch.cat2 ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-slate-50 border-slate-200'}`}>
                <option value="">{productSearch.cat2 ? '三级分类' : '请先选二级'}</option>
                {productCat3Options.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={productSearch.status} onChange={e => setProductSearch(p => ({ ...p, status: e.target.value }))}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none">
                <option value="">全部状态</option>
                <option value="已上架">已上架</option>
                <option value="待审">待审</option>
                <option value="已下架">已下架</option>
                <option value="草稿">草稿</option>
                <option value="审核未通过">审核未通过</option>
              </select>
              <div className="relative flex-1 min-w-[200px]">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="搜索装备名称/型号（空格分隔多关键词）"
                  value={productSearch.keywords} onChange={e => setProductSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setProductSearch({ keywords: '', cat1: '', cat2: '', cat3: '', status: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">一级分类</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">二级分类</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">三级分类</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">装备名称</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">型号</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">装备编码</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">计量单位</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">参考单价 *</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">是否电池</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">保养周期</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">备注</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">状态</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">操作</th>
                </tr></thead>
                <tbody>{filteredProducts.map(p => (
                  <tr key={p.id} className="border-b border-slate-100 hover:bg-blue-50/30 transition-colors">
                    <td className="px-3 py-3 text-slate-600">{p.cat1}</td>
                    <td className="px-3 py-3 text-slate-600">{p.cat2}</td>
                    <td className="px-3 py-3 text-slate-600">{p.cat3}</td>
                    <td className="px-3 py-3 font-medium text-slate-800">
                      <HighlightText text={p.name} query={productSearch.keywords} />
                    </td>
                    <td className="px-3 py-3 text-slate-600">
                      <HighlightText text={p.model} query={productSearch.keywords} />
                    </td>
                    <td className="px-3 py-3 text-slate-500">{p.code}</td>
                    <td className="px-3 py-3 text-slate-600">{p.unit}</td>
                    <td className="px-3 py-3">
                      <EditablePrice value={p.price} onChange={(v) => handlePriceEdit(p.id, v)} />
                    </td>
                    <td className="px-3 py-3"><span className={`inline-block px-2 py-0.5 rounded text-xs ${p.hasBattery ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500'}`}>{p.hasBattery ? '是' : '否'}</span></td>
                    <td className="px-3 py-3 text-slate-600">{p.hasBattery ? `${p.batteryCycle}个月` : '-'}</td>
                    <td className="px-3 py-3 text-slate-500 max-w-[100px] truncate">{p.note}</td>
                    <td className="px-3 py-3"><span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium ${statusTag(p.status)}`}>{p.status}</span></td>
                    <td className="px-3 py-3"><div className="flex items-center gap-2">
                      <button onClick={() => setShowDetail(p)} className="text-blue-600 hover:text-blue-800"><Eye className="w-4 h-4" /></button>
                      {p.status !== '已上架' && p.status !== '待审' && <button className="text-amber-600 hover:text-amber-800"><Pencil className="w-4 h-4" /></button>}
                      <button onClick={() => setProducts(prev => prev.filter(x => x.id !== p.id))} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                    </div></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <Pagination total={filteredProducts.length} />
          </div>
        </div>
      )}

      {/* ==================== 弹窗 ==================== */}
      {showRegister && <RegisterModal onClose={() => setShowRegister(false)} onAdd={setProducts} onGoNewProduct={goToNewProduct} />}
      {showNewProduct && <NewProductModal onClose={() => setShowNewProduct(false)} onAdd={setProducts} transferKeyword={transferKeyword} />}
      {showDetail && <DetailModal product={showDetail} onClose={() => setShowDetail(null)} />}
      {showContractModal && <ContractModal onClose={() => setShowContractModal(false)} onAdd={setContracts} setConfirm={setConfirmModal} />}
      {viewContract && <ContractDetailModal contract={viewContract} orders={orders.filter(o => viewContract.orderIds.includes(o.id))} onClose={() => setViewContract(null)} onJumpToOrder={(_orderId) => { setActiveModule('order'); setViewContract(null); }} />}
      {viewOrder && (
        <OrderDetailModal
          order={viewOrder}
          onClose={() => setViewOrder(null)}
          getContractName={getContractName}
          onShip={(order) => {
            setViewOrder(null);
            setShipmentPrefillOrder(order);
            setShowCreateShipment(true);
          }}
        />
      )}
      {showOrderModal && <OrderModal onClose={() => { setShowOrderModal(false); setOrderPrefill(null); }} onAdd={setOrders} contracts={contracts} prefill={orderPrefill} setConfirm={setConfirmModal} />}
      {confirmModal.open && <ConfirmModal message={confirmModal.message} onConfirm={confirmModal.onConfirm} onCancel={() => setConfirmModal(prev => ({ ...prev, open: false }))} />}
      {showCreateShipment && (
        <CreateShipmentModal
          orders={orders}
          contracts={contracts}
          prefillOrder={shipmentPrefillOrder}
          onClose={() => { setShowCreateShipment(false); setShipmentPrefillOrder(null); }}
        />
      )}
    </div>
  );
}

// ==================== 可编辑单价组件 ====================
function EditablePrice({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value.replace('¥', '').replace(/,/g, ''));
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setVal(value.replace('¥', '').replace(/,/g, '')); }, [value]);
  useEffect(() => { if (editing && inputRef.current) inputRef.current.focus(); }, [editing]);

  const handleBlur = () => { setEditing(false); if (val && !isNaN(Number(val)) && Number(val) > 0) onChange(val); };
  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter') handleBlur(); };

  if (editing) {
    return (
      <div className="flex items-center gap-1">
        <span className="text-xs text-slate-400">¥</span>
        <input ref={inputRef} type="number" value={val} onChange={e => setVal(e.target.value)}
          onBlur={handleBlur} onKeyDown={handleKeyDown}
          className="w-20 px-1.5 py-1 bg-white border border-blue-400 rounded text-xs outline-none focus:ring-1 focus:ring-blue-500/20" />
      </div>
    );
  }
  return (
    <button onClick={() => setEditing(true)} className="text-slate-800 font-medium hover:text-blue-700 hover:underline transition-colors text-left">{value}</button>
  );
}

// ==================== 分页 ====================
function Pagination({ total }: { total: number }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200">
      <p className="text-xs text-slate-500">共 {total} 条</p>
      <div className="flex items-center gap-1">
        <button className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 text-slate-400 hover:bg-slate-50 text-xs">&lt;</button>
        <button className="w-8 h-8 flex items-center justify-center rounded bg-blue-600 text-white text-xs font-medium">1</button>
        <button className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-slate-50 text-xs">&gt;</button>
      </div>
    </div>
  );
}

// ==================== 装备选择弹窗 ====================
function EquipmentPicker({ onClose, onConfirm }: { onClose: () => void; onConfirm: (items: OrderItem[]) => void; }) {
  const [cat1, setCat1] = useState(''); const [cat2, setCat2] = useState(''); const [cat3, setCat3] = useState('');
  const [searchName, setSearchName] = useState(''); const [selected, setSelected] = useState<typeof productLibrary>([]);
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const cat2Options = cat1 ? Object.keys(categoryTree[cat1] || {}) : [];
  const cat3Options = cat1 && cat2 ? (categoryTree[cat1]?.[cat2] || []) : [];
  const results = useMemo(() => {
    let list = [...productLibrary];
    if (cat1) list = list.filter(p => p.cat1 === cat1); if (cat2) list = list.filter(p => p.cat2 === cat2); if (cat3) list = list.filter(p => p.cat3 === cat3);
    const query = searchName.trim(); if (query) { const keywords = query.split(/\s+/).filter(k => k); list = list.filter(p => { const fullPath = `${p.cat1}>${p.cat2}>${p.cat3}>${p.name}>${p.code}`; return keywords.every(k => fullPath.toLowerCase().includes(k.toLowerCase())); }); }
    return list;
  }, [cat1, cat2, cat3, searchName]);
  const toggleSelect = (item: typeof productLibrary[0]) => {
    setSelected(prev => { const exists = prev.find(s => s.code === item.code); if (exists) { setQuantities(q => { const n = { ...q }; delete n[item.code]; return n; }); return prev.filter(s => s.code !== item.code); } else { setQuantities(q => ({ ...q, [item.code]: 1 })); return [...prev, item]; } });
  };
  const isSelected = (item: typeof productLibrary[0]) => selected.some(s => s.code === item.code);
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">选择装备</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 p-4 overflow-y-auto border-r border-slate-200">
            <div className="grid grid-cols-4 gap-2 mb-3">
              <select value={cat1} onChange={e => { setCat1(e.target.value); setCat2(''); setCat3(''); }} className="px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none"><option value="">一级分类</option>{Object.keys(categoryTree).map(c => <option key={c} value={c}>{c}</option>)}</select>
              <select value={cat2} onChange={e => { setCat2(e.target.value); setCat3(''); }} disabled={!cat1} className={`px-3 py-2 border rounded-lg text-sm outline-none ${!cat1 ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white border-slate-200'}`}><option value="">{cat1 ? '二级分类' : '请先选一级'}</option>{cat2Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
              <select value={cat3} onChange={e => setCat3(e.target.value)} disabled={!cat2} className={`px-3 py-2 border rounded-lg text-sm outline-none ${!cat2 ? 'bg-slate-100 text-slate-400 border-slate-200' : 'bg-white border-slate-200'}`}><option value="">{cat2 ? '三级分类' : '请先选二级'}</option>{cat3Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
              <div className="relative"><SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input type="text" placeholder="装备名称/编码" value={searchName} onChange={e => setSearchName(e.target.value)} className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none" /></div>
            </div>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-xs"><thead><tr className="bg-slate-50 border-b border-slate-200"><th className="px-3 py-2 text-left font-medium text-slate-600 w-8"></th><th className="px-3 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-3 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">规格型号</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备编码</th></tr></thead>
                <tbody>{results.map((item) => { const sel = isSelected(item); return (<tr key={item.code} onClick={() => toggleSelect(item)} className={`border-b border-slate-100 last:border-0 cursor-pointer transition-colors ${sel ? 'bg-blue-50' : 'hover:bg-slate-50'}`}><td className="px-3 py-2.5"><div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 transition-colors ${sel ? 'bg-blue-600 border-blue-600' : 'border-slate-300'}`}>{sel && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}</div></td><td className="px-3 py-2.5 font-medium text-slate-800">{item.name}</td><td className="px-3 py-2.5 text-slate-600">{item.cat1}</td><td className="px-3 py-2.5 text-slate-600">{item.cat2}</td><td className="px-3 py-2.5 text-slate-600">{item.cat3}</td><td className="px-3 py-2.5 text-slate-500">{item.model}</td><td className="px-3 py-2.5 text-slate-500 font-mono">{item.code}</td></tr>); })}</tbody>
              </table>
              {results.length === 0 && <div className="p-8 text-center text-sm text-slate-400">暂无匹配数据</div>}
            </div>
          </div>
          <div className="w-[280px] p-4 overflow-y-auto bg-slate-50/50">
            <h4 className="text-sm font-bold text-slate-800 mb-3">已选择装备 ({selected.length})</h4>
            {selected.length === 0 ? <p className="text-xs text-slate-400 text-center py-8">请从左侧选择装备</p> : (
              <div className="space-y-3">
                {selected.map(s => (<div key={s.code} className="bg-white rounded-lg p-3 border border-slate-200 shadow-sm"><div className="flex items-center justify-between mb-1"><span className="text-sm font-medium text-slate-800">{s.name} {s.model}</span><button onClick={(e) => { e.stopPropagation(); toggleSelect(s); }} className="text-red-400 hover:text-red-600"><X className="w-3.5 h-3.5" /></button></div><p className="text-xs text-slate-500 mb-2">数量：{s.unit} / 单价：¥{s.price.toLocaleString()}</p><div className="flex items-center gap-2"><button onClick={() => setQuantities(q => ({ ...q, [s.code]: Math.max(1, (q[s.code] || 1) - 1) }))} className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 hover:bg-slate-100"><Minus className="w-3 h-3" /></button><span className="text-sm font-medium w-6 text-center">{quantities[s.code] || 1}</span><button onClick={() => setQuantities(q => ({ ...q, [s.code]: (q[s.code] || 1) + 1 }))} className="w-6 h-6 flex items-center justify-center rounded border border-slate-200 hover:bg-slate-100"><Plus className="w-3 h-3" /></button></div></div>))}
              </div>
            )}
          </div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-slate-50 flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">关闭</button><button onClick={() => onConfirm(selected.map(s => ({ cat1: s.cat1, cat2: s.cat2, cat3: s.cat3, name: s.name, model: s.model, unit: s.unit, quantity: quantities[s.code] || 1, price: s.price, code: s.code, tags: [] })))} disabled={selected.length === 0} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">确定</button></div>
      </div>
    </div>
  );
}

// ==================== 新增合同弹窗 ====================
function ContractModal({ onClose, onAdd, setConfirm }: { onClose: () => void; onAdd: React.Dispatch<React.SetStateAction<Contract[]>>; setConfirm: React.Dispatch<React.SetStateAction<{ open: boolean; message: string; onConfirm: () => void }>>; }) {
  const [form, setForm] = useState({ partyA: '', name: '', amount: '', signDate: '', deliveryDate: '', note: '', attachment: '' as string | File });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const update = (field: string, value: string) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const validate = () => { const e: Record<string, string> = {}; if (!form.partyA) e.partyA = '请选择甲方'; if (!form.name.trim()) e.name = '请输入合同名称'; if (!form.amount || isNaN(Number(form.amount)) || Number(form.amount) <= 0) e.amount = '请输入有效的合同金额'; if (!form.signDate) e.signDate = '请选择签订日期'; if (!form.deliveryDate) e.deliveryDate = '请选择最终交货日期'; setErrors(e); return Object.keys(e).length === 0; };
  const handleSubmit = () => { if (!validate()) return; setConfirm({ open: true, message: '提交后不可修改，请确认内容是否无误，如需修改请联系甲方', onConfirm: () => { const newContract: Contract = { id: `HT${Date.now().toString().slice(-8)}`, partyA: form.partyA, partyB: MY_COMPANY, name: form.name.trim(), amount: form.amount, signDate: form.signDate, deliveryDate: form.deliveryDate, note: form.note.trim(), attachment: typeof form.attachment === 'string' ? form.attachment : form.attachment.name || '', status: '草稿', orderIds: [] }; onAdd(prev => [newContract, ...prev]); setConfirm(prev => ({ ...prev, open: false })); onClose(); } }); };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">新增合同</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 甲方</label><TreeSelect value={form.partyA} onChange={(v) => update('partyA', v)} error={errors.partyA} />{errors.partyA && <p className="mt-1 text-red-500 text-xs">{errors.partyA}</p>}</div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 乙方</label><input type="text" value={MY_COMPANY} disabled className="w-full px-4 py-3 bg-slate-100 border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 合同名称</label><input type="text" placeholder="请输入合同名称" value={form.name} onChange={e => update('name', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.name ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />{errors.name && <p className="mt-1 text-red-500 text-xs">{errors.name}</p>}</div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 合同金额</label><div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">¥</span><input type="number" placeholder="请输入合同金额" value={form.amount} onChange={e => update('amount', e.target.value)} className={`w-full pl-8 pr-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.amount ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} /></div>{errors.amount && <p className="mt-1 text-red-500 text-xs">{errors.amount}</p>}</div>
          <div className="grid grid-cols-2 gap-3"><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 签订日期</label><input type="date" value={form.signDate} onChange={e => update('signDate', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.signDate ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />{errors.signDate && <p className="mt-1 text-red-500 text-xs">{errors.signDate}</p>}</div><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 最终交货日期</label><input type="date" value={form.deliveryDate} onChange={e => update('deliveryDate', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 ${errors.deliveryDate ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'}`} />{errors.deliveryDate && <p className="mt-1 text-red-500 text-xs">{errors.deliveryDate}</p>}</div></div>
          <div><label className="block text-sm font-medium text-slate-700 mb-1.5">备注</label><textarea placeholder="请输入备注..." value={form.note} onChange={e => update('note', e.target.value)} rows={3} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none" /></div>
          <div><label className="block text-sm font-medium text-slate-700 mb-1.5">合同附件</label><div onClick={() => { const el = document.getElementById('contract-attach') as HTMLInputElement; el?.click(); }} className="relative border-2 border-dashed rounded-xl p-4 cursor-pointer transition-all text-center border-slate-300 bg-slate-50/50 hover:border-blue-400 hover:bg-blue-50/30"><input id="contract-attach" type="file" accept=".pdf,.doc,.docx,.jpg,.png" className="hidden" onChange={e => { if (e.target.files?.[0]) update('attachment', e.target.files[0].name); }} />{form.attachment ? (<div className="flex items-center justify-center gap-2"><FileText className="w-5 h-5 text-green-600" /><span className="text-sm text-slate-700 font-medium">{typeof form.attachment === 'string' ? form.attachment : ''}</span><button onClick={e => { e.stopPropagation(); update('attachment', ''); }} className="ml-auto p-1 hover:bg-red-100 rounded"><X className="w-4 h-4 text-red-500" /></button></div>) : (<div className="flex flex-col items-center gap-1"><Upload className="w-6 h-6 text-slate-400" /><span className="text-xs text-slate-500">点击上传合同附件（PDF/Word/图片）</span></div>)}</div></div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-slate-50 flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button><button onClick={handleSubmit} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">提交</button></div>
      </div>
    </div>
  );
}

// ==================== 合同详情弹窗 ====================
function ContractDetailModal({ contract, orders, onClose, onJumpToOrder }: { contract: Contract; orders: Order[]; onClose: () => void; onJumpToOrder: (_orderId: string) => void; }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">合同详情</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><FileText className="w-4 h-4 text-blue-600" /> 基本信息</h4><div className="grid grid-cols-2 gap-3"><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">甲方</p><p className="text-sm font-medium text-slate-800">{unitLabelMap[contract.partyA] || contract.partyA}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">乙方</p><p className="text-sm font-medium text-slate-800">{contract.partyB}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">合同名称</p><p className="text-sm font-medium text-slate-800">{contract.name}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">合同金额</p><p className="text-sm font-medium text-blue-700">¥{Number(contract.amount).toLocaleString()}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">签订日期</p><p className="text-sm font-medium text-slate-800">{contract.signDate}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">最终交货日期</p><p className="text-sm font-medium text-slate-800">{contract.deliveryDate}</p></div>{contract.attachment && (<div className="p-3 bg-slate-50 rounded-lg col-span-2 flex items-center gap-2"><FileText className="w-4 h-4 text-green-600" /><p className="text-xs text-slate-500">合同附件</p><p className="text-sm font-medium text-slate-800">{contract.attachment}</p></div>)}{contract.note && <div className="p-3 bg-slate-50 rounded-lg col-span-2"><p className="text-xs text-slate-500">备注</p><p className="text-sm text-slate-800">{contract.note}</p></div>}</div></div>
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><ClipboardList className="w-4 h-4 text-amber-600" /> 关联订单</h4>{orders.length === 0 ? (<div className="p-6 bg-slate-50 border border-slate-200 rounded-xl text-center"><p className="text-sm text-slate-400">暂无关联订单</p></div>) : (<div className="space-y-2">{orders.map(o => (<div key={o.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"><div className="grid grid-cols-3 gap-4 flex-1"><div><p className="text-xs text-slate-500">订单名称</p><p className="text-sm font-medium text-slate-800">{o.name}</p></div><div><p className="text-xs text-slate-500">预计送货日期</p><p className="text-sm text-slate-800">{o.deliveryDate}</p></div><div><p className="text-xs text-slate-500">收货对象</p><p className="text-sm text-slate-800">{unitLabelMap[o.receiver] || o.receiver}</p></div></div><button onClick={() => onJumpToOrder(o.id)} className="ml-4 px-3 py-1.5 text-xs text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors">查看</button></div>))}</div>)}</div>
        </div>
      </div>
    </div>
  );
}

// ==================== 新增/填写订单弹窗 ====================
function OrderModal({ onClose, onAdd, contracts, prefill, setConfirm }: { onClose: () => void; onAdd: React.Dispatch<React.SetStateAction<Order[]>>; contracts: Contract[]; prefill: { contractId?: string; receiver?: string } | null; setConfirm: React.Dispatch<React.SetStateAction<{ open: boolean; message: string; onConfirm: () => void }>>; }) {
  const [form, setForm] = useState({ name: '', contractId: prefill?.contractId || '', supplier: MY_COMPANY, supplierCode: MY_SUPPLIER_CODE, deliveryDate: '', receiver: prefill?.receiver || '' });
  const [items, setItems] = useState<OrderItem[]>([]); const [errors, setErrors] = useState<Record<string, string>>({}); const [showPicker, setShowPicker] = useState(false);
  useEffect(() => { if (prefill?.contractId) { const c = contracts.find(ct => ct.id === prefill.contractId); setForm(prev => ({ ...prev, contractId: prefill.contractId || '', receiver: prefill.receiver || c?.partyA || '' })); } }, [prefill, contracts]);
  const update = (field: string, value: string) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const handleContractChange = (contractId: string) => { const c = contracts.find(ct => ct.id === contractId); setForm(prev => ({ ...prev, contractId, receiver: c?.partyA || prev.receiver })); };
  const handleAddFromPicker = (picked: OrderItem[]) => { setItems(prev => [...prev, ...picked]); setShowPicker(false); };
  const removeItem = (idx: number) => setItems(prev => prev.filter((_, i) => i !== idx));
  const updateItemField = (idx: number, field: 'price' | 'quantity', value: number) => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, [field]: value } : it)); };
  const totalAmount = items.reduce((s, it) => s + (it.price || 0) * it.quantity, 0);
  const validate = () => { const e: Record<string, string> = {}; if (!form.receiver) e.receiver = '请选择收货对象'; if (items.length === 0) e.items = '请至少添加一条装备信息'; setErrors(e); return Object.keys(e).length === 0; };
  const handleSubmit = () => { if (!validate()) return; setConfirm({ open: true, message: '提交后不可修改，请确认内容是否无误，如需修改请联系甲方', onConfirm: () => { const newOrder: Order = { id: `DD${Date.now().toString().slice(-8)}`, name: form.name.trim() || `订单-${Date.now().toString().slice(-4)}`, contractId: form.contractId, supplier: form.supplier, supplierCode: form.supplierCode, deliveryDate: form.deliveryDate, receiver: form.receiver, items, shipStatus: 'pending' }; onAdd(prev => [newOrder, ...prev]); setConfirm(prev => ({ ...prev, open: false })); onClose(); } }); };
  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
        <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
          <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">{prefill?.contractId ? '填写订单' : '新增订单'}</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
          <div className="p-5 space-y-4 overflow-y-auto flex-1">
            <div><h4 className="text-xs font-medium text-slate-500 mb-2">基本信息</h4><div className="grid grid-cols-2 gap-3"><div><label className="block text-sm font-medium text-slate-700 mb-1.5">订单名称</label><input type="text" placeholder="请输入订单名称" value={form.name} onChange={e => update('name', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">关联合同</label><select value={form.contractId} onChange={e => handleContractChange(e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"><option value="">请选择关联合同</option>{contracts.map(c => <option key={c.id} value={c.id}>{c.id} - {c.name}</option>)}</select></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">供应商 <span className="text-slate-400 font-normal">（自动填入）</span></label><input type="text" value={form.supplier} disabled className="w-full px-4 py-3 bg-slate-100 border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">供应商企业编码 <span className="text-slate-400 font-normal">（自动填入）</span></label><input type="text" value={form.supplierCode} disabled className="w-full px-4 py-3 bg-slate-100 border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">预计送货日期</label><input type="date" value={form.deliveryDate} onChange={e => update('deliveryDate', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500" /></div><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 收货对象</label><TreeSelect value={form.receiver} onChange={(v) => update('receiver', v)} error={errors.receiver} />{errors.receiver && <p className="mt-1 text-red-500 text-xs">{errors.receiver}</p>}</div></div></div>
            <div><div className="flex items-center justify-between mb-2"><h4 className="text-xs font-medium text-slate-500">装备信息</h4><button onClick={() => setShowPicker(true)} className="flex items-center gap-1 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-md text-xs font-medium hover:bg-blue-100 transition-colors"><Plus className="w-3 h-3" /> 添加装备</button></div>{errors.items && <p className="text-xs text-red-500 mb-2">{errors.items}</p>}{items.length === 0 ? (<div className="p-6 bg-slate-50 border border-slate-200 rounded-xl text-center"><p className="text-sm text-slate-400">暂无装备信息，点击"添加装备"按钮添加</p></div>) : (<div className="border border-slate-200 rounded-lg overflow-hidden"><table className="w-full text-xs"><thead><tr className="bg-slate-50 border-b border-slate-200"><th className="px-2 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-2 py-2 text-left font-medium text-slate-600">型号</th><th className="px-2 py-2 text-left font-medium text-slate-600">装备编码</th><th className="px-2 py-2 text-left font-medium text-slate-600">计量单位</th><th className="px-2 py-2 text-left font-medium text-slate-600">单价</th><th className="px-2 py-2 text-left font-medium text-slate-600">数量</th><th className="px-2 py-2 text-left font-medium text-slate-600">金额</th><th className="px-2 py-2 text-left font-medium text-slate-600 w-12">操作</th></tr></thead><tbody>{items.map((item, idx) => { const amount = (item.price || 0) * item.quantity; return (<tr key={idx} className="border-b border-slate-100 last:border-0"><td className="px-2 py-2 text-slate-600">{item.cat1}</td><td className="px-2 py-2 text-slate-600">{item.cat2}</td><td className="px-2 py-2 text-slate-600">{item.cat3}</td><td className="px-2 py-2 font-medium text-slate-800">{item.name}</td><td className="px-2 py-2 text-slate-500">{item.model}</td><td className="px-2 py-2 text-slate-500 font-mono">{item.code}</td><td className="px-2 py-2 text-slate-600">{item.unit}</td><td className="px-2 py-2"><div className="flex items-center gap-0.5"><span className="text-xs text-slate-400">¥</span><input type="number" min={0} value={item.price || 0} onChange={e => updateItemField(idx, 'price', Number(e.target.value))} className="w-16 px-1 py-0.5 bg-white border border-slate-200 rounded text-xs outline-none focus:ring-1 focus:ring-blue-500/20 focus:border-blue-500" /></div></td><td className="px-2 py-2"><input type="number" min={1} value={item.quantity} onChange={e => updateItemField(idx, 'quantity', Number(e.target.value))} className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-xs outline-none focus:ring-1 focus:ring-blue-500/20 focus:border-blue-500 text-center" /></td><td className="px-2 py-2 text-blue-700 font-medium">¥{amount.toLocaleString()}</td><td className="px-2 py-2"><button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700"><Trash2 className="w-3.5 h-3.5" /></button></td></tr>); })}</tbody></table>{items.length > 0 && (<div className="px-3 py-2 bg-slate-50 border-t border-slate-200 text-right"><span className="text-xs text-slate-500">合计金额：</span><span className="text-sm font-bold text-blue-700">¥{totalAmount.toLocaleString()}</span></div>)}</div>)}</div>
          </div>
          <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-slate-50 flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button><button onClick={handleSubmit} disabled={items.length === 0} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">提交</button></div>
        </div>
      </div>
      {showPicker && <EquipmentPicker onClose={() => setShowPicker(false)} onConfirm={handleAddFromPicker} />}
    </>
  );
}

// ==================== 订单详情弹窗 ====================
function OrderDetailModal({ order, onClose, getContractName, onShip }: { order: Order; onClose: () => void; getContractName: (id: string) => string; onShip?: (order: Order) => void; }) {
  const totalAmount = order.items.reduce((s, it) => s + (it.price || 0) * it.quantity, 0);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">订单详情</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><ClipboardList className="w-4 h-4 text-blue-600" /> 基本信息</h4><div className="grid grid-cols-3 gap-3"><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">订单名称</p><p className="text-sm font-medium text-slate-800">{order.name}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">关联合同</p><p className="text-sm font-medium text-slate-800">{order.contractId} {getContractName(order.contractId) ? `- ${getContractName(order.contractId)}` : ''}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">供应商</p><p className="text-sm font-medium text-slate-800">{order.supplier}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">企业编码</p><p className="text-sm font-medium text-slate-800">{order.supplierCode}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">预计送货日期</p><p className="text-sm font-medium text-slate-800">{order.deliveryDate || '-'}</p></div><div className="p-3 bg-slate-50 rounded-lg"><p className="text-xs text-slate-500">收货对象</p><p className="text-sm font-medium text-slate-800">{unitLabelMap[order.receiver] || order.receiver}</p></div></div></div>
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><Package className="w-4 h-4 text-green-600" /> 装备信息</h4><div className="border border-slate-200 rounded-lg overflow-hidden"><table className="w-full text-xs"><thead><tr className="bg-slate-50 border-b border-slate-200"><th className="px-3 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-3 py-2 text-left font-medium text-slate-600">型号</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备编码</th><th className="px-3 py-2 text-left font-medium text-slate-600">计量单位</th><th className="px-3 py-2 text-left font-medium text-slate-600">单价</th><th className="px-3 py-2 text-left font-medium text-slate-600">数量</th><th className="px-3 py-2 text-left font-medium text-slate-600">金额</th></tr></thead><tbody>{order.items.map((item, idx) => { const amount = (item.price || 0) * item.quantity; return (<tr key={idx} className="border-b border-slate-100 last:border-0 hover:bg-blue-50/30"><td className="px-3 py-2.5 text-slate-600">{item.cat1}</td><td className="px-3 py-2.5 text-slate-600">{item.cat2}</td><td className="px-3 py-2.5 text-slate-600">{item.cat3}</td><td className="px-3 py-2.5 font-medium text-slate-800">{item.name}</td><td className="px-3 py-2.5 text-slate-500">{item.model}</td><td className="px-3 py-2.5 text-slate-500 font-mono">{item.code}</td><td className="px-3 py-2.5 text-slate-600">{item.unit}</td><td className="px-3 py-2.5 text-slate-700">¥{(item.price || 0).toLocaleString()}</td><td className="px-3 py-2.5 text-slate-700 font-medium">{item.quantity}</td><td className="px-3 py-2.5 text-blue-700 font-medium">¥{amount.toLocaleString()}</td></tr>); })}</tbody></table></div><div className="mt-2 text-right"><span className="text-xs text-slate-500">合计金额：</span><span className="text-base font-bold text-blue-700">¥{totalAmount.toLocaleString()}</span></div></div>
        </div>
        {onShip && order.shipStatus !== 'shipped' && (<div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-slate-50 flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">关闭</button><button onClick={() => { onClose(); onShip(order); }} className="px-5 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">发货</button></div>)}
      </div>
    </div>
  );
}

// ==================== 二次确认弹窗 ====================
function ConfirmModal({ message, onConfirm, onCancel }: { message: string; onConfirm: () => void; onCancel: () => void; }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50" onClick={onCancel}>
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md animate-fade-in p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-start gap-3 mb-4"><div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0"><AlertTriangle className="w-5 h-5 text-amber-600" /></div><div><h3 className="text-base font-bold text-slate-800 mb-1">确认提交</h3><p className="text-sm text-slate-600">{message}</p></div></div>
        <div className="flex justify-end gap-3"><button onClick={onCancel} className="px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-slate-50 transition-colors">取消</button><button onClick={onConfirm} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">确认</button></div>
      </div>
    </div>
  );
}
