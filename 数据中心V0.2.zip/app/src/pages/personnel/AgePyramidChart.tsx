import { memo, useCallback } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import type { EChartOption } from 'echarts';
import { ageBrackets, getAgePyramidData } from './dataHelpers';

interface AgePyramidChartProps {
  unitId?: string;
  onBracketClick?: (index: number) => void;
}

export const AgePyramidChart = memo(function AgePyramidChart({ unitId, onBracketClick }: AgePyramidChartProps) {
  const { male, female, total } = getAgePyramidData(unitId);

  const getOption = useCallback((): EChartOption => {
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: { color: '#d8dce6', fontSize: 12 },
        formatter: (params: unknown) => {
          const p = params as Array<{ name: string; seriesName: string; value: number }>;
          let html = `<div style="font-weight:600;margin-bottom:4px">${p[0]?.name}</div>`;
          p.forEach(item => {
            const pct = total ? (Math.abs(item.value) / total * 100).toFixed(1) : '0';
            const color = item.seriesName === '男性' ? '#2151f5' : '#00e5ff';
            html += `<div style="display:flex;align-items:center;gap:6px;margin:2px 0">
              <span style="width:8px;height:8px;border-radius:50%;background:${color};display:inline-block"></span>
              <span>${item.seriesName}: ${Math.abs(item.value)}人 (${pct}%)</span>
            </div>`;
          });
          return html;
        },
      },
      grid: {
        left: 50, right: 50, top: 10, bottom: 10,
      },
      xAxis: [
        {
          type: 'value',
          axisLabel: {
            formatter: (v: number) => Math.abs(v).toString(),
            color: '#3d4f70', fontSize: 10,
          },
          axisLine: { show: false },
          splitLine: { lineStyle: { color: '#1e2a45', type: 'dashed' } },
          axisTick: { show: false },
        },
        {
          type: 'value',
          gridIndex: 0,
          axisLabel: {
            formatter: (v: number) => Math.abs(v).toString(),
            color: '#3d4f70', fontSize: 10,
          },
          axisLine: { show: false },
          splitLine: { show: false },
          axisTick: { show: false },
        },
      ],
      yAxis: {
        type: 'category',
        data: [...ageBrackets],
        axisLabel: { color: '#6b7fa3', fontSize: 11 },
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisTick: { show: false },
      },
      series: [
        {
          name: '男性',
          type: 'bar',
          stack: 'Total',
          data: male.map(v => -v),
          itemStyle: { color: '#2151f5', borderRadius: [4, 0, 0, 4] },
          barWidth: 20,
          animationDuration: 600,
          animationDelay: (idx: number) => Math.abs(3 - (idx as number)) * 50,
        },
        {
          name: '女性',
          type: 'bar',
          stack: 'Total',
          data: female,
          itemStyle: { color: '#00e5ff', borderRadius: [0, 4, 4, 0] },
          barWidth: 20,
          animationDuration: 600,
          animationDelay: (idx: number) => Math.abs(3 - (idx as number)) * 50,
        },
      ],
    };
  }, [male, female, total]);

  const onChartClick = useCallback((params: { componentType: string; dataIndex: number }) => {
    if (params.componentType === 'series' && onBracketClick) {
      onBracketClick(params.dataIndex);
    }
  }, [onBracketClick]);

  const events: Record<string, Function> = { click: onChartClick };

  return (
    <div className="bg-abyss border border-border-dim rounded-xl p-5 flex-1">
      <h3 className="text-h3 text-text-primary mb-4">
        {unitId ? '年龄结构' : '全厅年龄结构'}
      </h3>
      <ReactEChartsCore
        option={getOption()}
        style={{ height: 240, width: '100%' }}
        opts={{ renderer: 'canvas' }}
        onEvents={events}
      />
    </div>
  );
});
