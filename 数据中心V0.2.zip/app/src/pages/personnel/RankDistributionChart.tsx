import { memo, useCallback } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import type { EChartOption } from 'echarts';
import { rankNames, getRankDistribution } from './dataHelpers';

export const RankDistributionChart = memo(function RankDistributionChart({ unitId }: { unitId?: string }) {
  const data = getRankDistribution(unitId);
  const total = data.reduce((a, b) => a + b, 0);

  const getOption = useCallback((): EChartOption => {
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: { color: '#d8dce6', fontSize: 12 },
        formatter: (params: unknown) => {
          const p = (params as Array<{ name: string; value: number }>)[0];
          if (!p) return '';
          const pct = total ? (p.value / total * 100).toFixed(1) : '0';
          return `<div style="font-weight:600">${p.name}</div><div>${p.value}人 (${pct}%)</div>`;
        },
      },
      grid: { left: 70, right: 30, top: 10, bottom: 10 },
      xAxis: {
        type: 'value',
        axisLabel: { color: '#3d4f70', fontSize: 10 },
        axisLine: { show: false },
        splitLine: { lineStyle: { color: '#1e2a45', type: 'dashed' } },
        axisTick: { show: false },
      },
      yAxis: {
        type: 'category',
        data: [...rankNames].reverse(),
        axisLabel: { color: '#6b7fa3', fontSize: 10 },
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisTick: { show: false },
      },
      series: [{
        type: 'bar',
        data: [...data].reverse().map((v, i) => ({
          value: v,
          itemStyle: {
            color: `rgba(33, 81, 245, ${0.4 + (i / rankNames.length) * 0.6})`,
            borderRadius: [0, 4, 4, 0],
          },
        })),
        barWidth: 16,
        label: {
          show: true,
          position: 'right',
          color: '#6b7fa3',
          fontSize: 10,
          formatter: (p: unknown) => `${(p as { value: number }).value}`,
        },
        animationDuration: 400,
        animationDelay: (idx: number) => (idx as number) * 40,
      }],
    };
  }, [data, total]);

  return (
    <div className="bg-abyss border border-border-dim rounded-xl p-5 flex-1">
      <h3 className="text-h3 text-text-primary mb-4">职级分布</h3>
      <ReactEChartsCore
        option={getOption()}
        style={{ height: 240, width: '100%' }}
        opts={{ renderer: 'canvas' }}
      />
    </div>
  );
});
