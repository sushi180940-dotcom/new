import { useState, useCallback, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plus,
  Minus,
  ChevronRight,
  AlertTriangle,
  Car,
  Gauge,
  Navigation,
  Clock,
} from 'lucide-react';
import ProvinceMap from '@/components/ProvinceMap';
import SidePanel from '@/components/SidePanel';
import { units, assetData } from '@/data/mockData';
import type { Unit, AssetData } from '@/data/mockData';
import RightPanel from './asset/RightPanel';
import { EquipmentTab, SuppliesTab, ClothingTab, OfficeTab, DisposalTab } from './asset/tabContents';

// Inline VehicleTab to avoid potential module loading issues
function VehicleTab({ data }: { data: AssetData; unitName: string }) {
  const totalVehicles = data.assetCategories.vehicles;
  const utilizationRate = data.utilizationRate;
  const gpsOnlineRate = 92.5;

  const vehicleTypeData = [
    { name: '警车', value: Math.round(totalVehicles * 0.40), color: '#2151f5' },
    { name: '囚车/特种', value: Math.round(totalVehicles * 0.22), color: '#00e5ff' },
    { name: '摩托车', value: Math.round(totalVehicles * 0.12), color: '#00f5a0' },
    { name: '运兵车', value: Math.round(totalVehicles * 0.14), color: '#ffd166' },
    { name: '无人机', value: Math.round(totalVehicles * 0.08), color: '#a855f7' },
    { name: '其他', value: Math.round(totalVehicles * 0.04), color: '#6b7fa3' },
  ];

  const vehicleList = [
    { name: '警车', count: 32, value: 640, status: '正常' as const, gps: true },
    { name: '囚车', count: 6, value: 360, status: '正常' as const, gps: true },
    { name: '摩托车', count: 18, value: 108, status: '正常' as const, gps: false },
    { name: '运兵车', count: 4, value: 280, status: '维修' as const, gps: true },
    { name: '救护车', count: 2, value: 120, status: '正常' as const, gps: true },
    { name: '无人机', count: 12, value: 180, status: '正常' as const, gps: false },
  ];

  return (
    <div className="flex flex-col gap-5">
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <div className="flex items-center gap-1.5 mb-1">
              <Car className="w-3.5 h-3.5" style={{ color: '#5eead4' }} />
              <span className="text-small text-text-secondary">车辆总值</span>
            </div>
            <div className="text-data-md font-mono" style={{ color: '#5eead4' }}>{Math.round(totalVehicles / 100)}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <div className="flex items-center gap-1.5 mb-1">
              <Gauge className="w-3.5 h-3.5" style={{ color: '#2151f5' }} />
              <span className="text-small text-text-secondary">资产利用率</span>
            </div>
            <div className="text-data-md font-mono" style={{ color: utilizationRate >= 85 ? '#00f5a0' : '#ffd166' }}>{utilizationRate}%</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <div className="flex items-center gap-1.5 mb-1">
              <Navigation className="w-3.5 h-3.5" style={{ color: '#00f5a0' }} />
              <span className="text-small text-text-secondary">GPS在线率</span>
            </div>
            <div className="text-data-md font-mono" style={{ color: '#00f5a0' }}>{gpsOnlineRate}%</div>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
        <h4 className="text-h4 text-text-primary mb-2">车辆类型分布</h4>
        <div className="rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          {vehicleTypeData.map((d) => (
            <div key={d.name} className="flex items-center justify-between py-1.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="text-small text-text-secondary">{d.name}</span>
              </div>
              <span className="text-small font-mono text-text-primary">{d.value}万</span>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
        <h4 className="text-h4 text-text-primary mb-2">车辆清单</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-3 py-2">类型</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">数量</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">价值(万)</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">GPS</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
            </tr></thead>
            <tbody>
              {vehicleList.map((v) => (
                <tr key={v.name} className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-3 py-2 text-text-primary">{v.name}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{v.count}辆</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{v.value}</td>
                  <td className="px-2 py-2">
                    <span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: v.gps ? 'rgba(0,245,160,0.15)' : 'rgba(107,127,163,0.15)', color: v.gps ? '#00f5a0' : '#6b7fa3' }}>{v.gps ? '在线' : '—'}</span>
                  </td>
                  <td className="px-2 py-2">
                    <span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: v.status === '正常' ? 'rgba(0,245,160,0.15)' : 'rgba(255,209,102,0.15)', color: v.status === '正常' ? '#00f5a0' : '#ffd166' }}>{v.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3 }}>
        <h4 className="text-h4 text-text-primary mb-2">GPS实时位置</h4>
        <div className="rounded-lg border p-4 flex flex-col gap-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#00f5a0' }} /><span className="text-small text-text-secondary">行驶中 12辆</span></div>
              <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#2151f5' }} /><span className="text-small text-text-secondary">静止 42辆</span></div>
              <div className="flex items-center gap-1"><span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#6b7fa3' }} /><span className="text-small text-text-secondary">离线 4辆</span></div>
            </div>
            <div className="flex items-center gap-1"><Clock className="w-3 h-3 text-text-tertiary" /><span className="text-small text-text-tertiary">更新于 2分钟前</span></div>
          </div>
          <div className="h-[120px] rounded-md border relative overflow-hidden" style={{ backgroundColor: '#0a0e1a', borderColor: '#1e2a45' }}>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <Navigation className="w-6 h-6 mx-auto mb-1" style={{ color: '#5eead4' }} />
                <span className="text-small text-text-secondary">GPS实时地图</span>
                <p className="text-[10px] text-text-tertiary">58辆车在线 / 4辆离线</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 rounded-md border p-2 text-center" style={{ backgroundColor: '#0a0e1a', borderColor: '#1e2a45' }}>
              <div className="text-[10px] text-text-tertiary mb-0.5">今日总里程</div><div className="text-data-sm font-mono text-text-primary">2,847km</div>
            </div>
            <div className="flex-1 rounded-md border p-2 text-center" style={{ backgroundColor: '#0a0e1a', borderColor: '#1e2a45' }}>
              <div className="text-[10px] text-text-tertiary mb-0.5">平均车速</div><div className="text-data-sm font-mono text-text-primary">42km/h</div>
            </div>
            <div className="flex-1 rounded-md border p-2 text-center" style={{ backgroundColor: '#0a0e1a', borderColor: '#1e2a45' }}>
              <div className="text-[10px] text-text-tertiary mb-0.5">使用率</div><div className="text-data-sm font-mono" style={{ color: '#00f5a0' }}>78.3%</div>
            </div>
          </div>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.35 }}>
        <h4 className="text-h4 text-text-primary mb-2">行驶轨迹记录</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-3 py-2">车牌号</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">驾驶员</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">出发</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">到达</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">里程</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
            </tr></thead>
            <tbody>
              {[
                { plate: '警A·12345', driver: '王建国', from: '总队A', to: '支队C', dist: '186km', status: '行驶中' },
                { plate: '警A·12348', driver: '李明', from: '总队A', to: '支队B', dist: '92km', status: '已到达' },
                { plate: '警A·12352', driver: '张伟', from: '支队C', to: '大队J', dist: '45km', status: '行驶中' },
                { plate: '警A·12356', driver: '刘洋', from: '总队B', to: '支队D', dist: '128km', status: '已到达' },
              ].map((r) => (
                <tr key={r.plate} className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-3 py-2 text-text-primary font-mono">{r.plate}</td>
                  <td className="px-2 py-2 text-text-primary">{r.driver}</td>
                  <td className="px-2 py-2 text-text-secondary">{r.from}</td>
                  <td className="px-2 py-2 text-text-secondary">{r.to}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{r.dist}</td>
                  <td className="px-2 py-2">
                    <span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: r.status === '行驶中' ? 'rgba(0,229,255,0.15)' : 'rgba(0,245,160,0.15)', color: r.status === '行驶中' ? '#00e5ff' : '#00f5a0' }}>{r.status}</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
import { COLORS } from './asset/chartUtils';

// ── Heatmap layer modes ──
type HeatmapLayer = 'all' | 'equipment' | 'emergencySupplies' | 'clothingSupplies' | 'officeDevices' | 'vehicles';

const layerLabels: Record<HeatmapLayer, string> = {
  all: '全部',
  equipment: '装备',
  emergencySupplies: '应急物资',
  clothingSupplies: '被装物资',
  officeDevices: '办公设备',
  vehicles: '车辆',
};

const layerKeys: HeatmapLayer[] = ['all', 'equipment', 'emergencySupplies', 'clothingSupplies', 'officeDevices', 'vehicles'];

// ── Get value for a unit based on heatmap layer ──
function getUnitValue(data: AssetData | undefined, layer: HeatmapLayer): number {
  if (!data) return 0;
  switch (layer) {
    case 'equipment': return data.assetCategories.equipment;
    case 'emergencySupplies': return data.assetCategories.emergencySupplies;
    case 'clothingSupplies': return data.assetCategories.clothingSupplies ?? data.assetCategories.officeDevices;
    case 'officeDevices': return data.assetCategories.officeDevices;
    case 'vehicles': return data.assetCategories.vehicles;
    default: return data.totalAssetValue;
  }
}

// ── Dot color based on value ──
function getDotColor(value: number): string {
  if (value < 5000000) return '#2151f5'; // deep blue
  if (value < 10000000) return '#3b6ef5'; // blue
  if (value < 20000000) return '#00e5ff'; // cyan
  return '#5eead4'; // bright cyan
}

// ── Dot radius based on value ──
function getDotRadius(value: number): number {
  const minR = 6;
  const maxR = 14;
  const minV = 3000000;
  const maxV = 40000000;
  const t = Math.max(0, Math.min(1, (value - minV) / (maxV - minV)));
  return minR + t * (maxR - minR);
}

// ── Toast component ──
function Toast({ message, visible }: { message: string; visible: boolean }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ duration: 0.2 }}
          className="absolute top-4 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-lg text-small font-medium shadow-lg pointer-events-none"
          style={{
            backgroundColor: '#151d32',
            color: '#4f8af7',
            border: '1px solid #2a3a5c',
          }}
        >
          {message}
        </motion.div>
      )}
    </AnimatePresence>
  );
}

// ═══════════════════════════════════════════════════════════════
// Main Component
// ═══════════════════════════════════════════════════════════════

export default function AssetPanorama() {
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('equipment');
  const [hoveredUnit, setHoveredUnit] = useState<Unit | null>(null);
  const [heatmapLayer, setHeatmapLayer] = useState<HeatmapLayer>('all');
  const [toast, setToast] = useState({ message: '', visible: false });
  const [svgZoom, setSvgZoom] = useState(1);
  const [svgPan, setSvgPan] = useState({ x: 0, y: 0 });
  const svgContainerRef = useRef<HTMLDivElement>(null);
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });

  // Derived data
  const selectedUnit = useMemo(
    () => units.find((u) => u.id === selectedUnitId) || null,
    [selectedUnitId]
  );

  const selectedUnitAsset = selectedUnitId ? assetData[selectedUnitId] : undefined;

  // Compute shortage count for each unit
  const unitShortageCounts = useMemo(() => {
    const map: Record<string, number> = {};
    Object.entries(assetData).forEach(([uid, data]) => {
      map[uid] = data.emergencySupplyTypes.filter((s) => s.status !== 'normal').length;
    });
    return map;
  }, []);

  // Heatmap overlay circles
  const heatmapCircles = useMemo(() => {
    return units.map((unit) => {
      const data = assetData[unit.id];
      const value = getUnitValue(data, heatmapLayer);
      const maxVal = heatmapLayer === 'all' ? 40000000 : 15000000;
      const intensity = Math.max(0.05, Math.min(0.35, value / maxVal));
      const color = heatmapLayer === 'all'
        ? `rgba(33,81,245,${intensity})`
        : heatmapLayer === 'equipment'
          ? `rgba(33,81,245,${intensity})`
          : heatmapLayer === 'emergencySupplies'
            ? `rgba(0,229,255,${intensity})`
            : heatmapLayer === 'clothingSupplies'
              ? `rgba(168,85,247,${intensity})`
              : heatmapLayer === 'officeDevices'
                ? `rgba(249,115,22,${intensity})`
                : `rgba(94,234,212,${intensity})`;
      return { unit, color, intensity, value };
    });
  }, [heatmapLayer]);

  // ── Handlers ──

  const handleUnitClick = useCallback((unit: Unit) => {
    setSelectedUnitId(unit.id);
    setHoveredUnit(null);
  }, []);

  const handleUnitHover = useCallback((unit: Unit | null) => {
    setHoveredUnit(unit);
  }, []);

  const handleClosePanel = useCallback(() => {
    setSelectedUnitId(null);
  }, []);

  const handlePieCategoryClick = useCallback((category: string | null) => {
    if (category) {
      setHeatmapLayer(category as HeatmapLayer);
      const catNames: Record<string, string> = {
        equipment: '装备',
        emergencySupplies: '应急物资',
        clothingSupplies: '被装物资',
        officeDevices: '办公设备',
        vehicles: '车辆',
      };
      setToast({ message: `热力图已切换至${catNames[category] || category}资产分布`, visible: true });
      setTimeout(() => setToast((t) => ({ ...t, visible: false })), 2000);
    }
  }, []);

  const handleRightPanelUnitClick = useCallback((unitId: string) => {
    setSelectedUnitId(unitId);
  }, []);

  // SVG mouse handlers for panning
  const handleSvgMouseDown = useCallback((e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('.unit-dot')) return;
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX - svgPan.x, y: e.clientY - svgPan.y };
  }, [svgPan]);

  const handleSvgMouseMove = useCallback((e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    setSvgPan({ x: e.clientX - dragStartRef.current.x, y: e.clientY - dragStartRef.current.y });
  }, []);

  const handleSvgMouseUp = useCallback(() => {
    isDraggingRef.current = false;
  }, []);

  const handleZoomIn = useCallback(() => setSvgZoom((z) => Math.min(z * 1.2, 4)), []);
  const handleZoomOut = useCallback(() => setSvgZoom((z) => Math.max(z / 1.2, 0.5)), []);
  const handleResetView = useCallback(() => {
    setSvgZoom(1);
    setSvgPan({ x: 0, y: 0 });
  }, []);

  // ── Side panel tabs ──
  const sidePanelTabs = useMemo(() => {
    if (!selectedUnit || !selectedUnitAsset) return [];
    return [
      { id: 'equipment', label: '装备', content: <EquipmentTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
      { id: 'supplies', label: '应急物资', content: <SuppliesTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
      { id: 'clothing', label: '被装物资', content: <ClothingTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
      { id: 'office', label: '办公设备', content: <OfficeTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
      { id: 'vehicles', label: '车辆资产', content: <VehicleTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
      { id: 'disposal', label: '资产处置', content: <DisposalTab data={selectedUnitAsset} unitName={selectedUnit.name} /> },
    ];
  }, [selectedUnit, selectedUnitAsset]);

  // ── Map overlay dot positions ──
  const mapWidth = 400;
  const mapHeight = 460;

  return (
    <div className="w-full h-[calc(100dvh-74px)] flex relative overflow-hidden" style={{ marginTop: 74 }}>
      {/* Toast */}
      <Toast message={toast.message} visible={toast.visible} />

      {/* ════════ Right: Map (~40%) ════════ */}
      <div className="w-[40%] h-full relative border-l order-2" style={{ borderColor: '#1e2a45', backgroundColor: '#0a0e1a' }}>
        {/* Grid overlay background */}
        <div className="absolute inset-0 grid-overlay pointer-events-none" />

        {/* Vignette */}
        <div className="absolute inset-0 vignette pointer-events-none z-10" />

        {/* SVG Map Container */}
        <div
          ref={svgContainerRef}
          className="absolute inset-0 z-0 overflow-hidden"
          onMouseDown={handleSvgMouseDown}
          onMouseMove={handleSvgMouseMove}
          onMouseUp={handleSvgMouseUp}
          onMouseLeave={handleSvgMouseUp}
          style={{ cursor: isDraggingRef.current ? 'grabbing' : 'default' }}
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            style={{
              transform: `translate(${svgPan.x}px, ${svgPan.y}px) scale(${svgZoom})`,
              transformOrigin: 'center center',
              width: '100%',
              height: '100%',
              transition: isDraggingRef.current ? 'none' : 'transform 0.3s ease',
            }}
          >
            {/* Base Province Map */}
            <ProvinceMap
              units={units}
              selectedUnitId={selectedUnitId}
              onUnitClick={handleUnitClick}
              onUnitHover={handleUnitHover}
              className="absolute inset-0"
            />

            {/* Asset value overlay SVG */}
            <svg
              viewBox={`0 0 ${mapWidth} ${mapHeight}`}
              className="absolute inset-0 pointer-events-none"
              style={{ width: '100%', height: '100%' }}
            >
              {/* Heatmap circles */}
              <motion.g
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                {heatmapCircles.map(({ unit, color }) => {
                  const x = (unit.x / 100) * mapWidth;
                  const y = (unit.y / 100) * mapHeight;
                  return (
                    <circle
                      key={`heat-${unit.id}`}
                      cx={x}
                      cy={y}
                      r={35}
                      fill={color}
                      style={{ mixBlendMode: 'screen' }}
                    />
                  );
                })}
              </motion.g>

              {/* Unit dots with asset-value coloring */}
              {units.map((unit, i) => {
                const data = assetData[unit.id];
                const value = getUnitValue(data, heatmapLayer);
                const color = getDotColor(value);
                const radius = getDotRadius(value);
                const x = (unit.x / 100) * mapWidth;
                const y = (unit.y / 100) * mapHeight;
                const shortageCount = unitShortageCounts[unit.id] || 0;
                const isSelected = selectedUnitId === unit.id;
                const isHovered = hoveredUnit?.id === unit.id;

                return (
                  <motion.g
                    key={`dot-${unit.id}`}
                    className="unit-dot pointer-events-auto"
                    style={{ cursor: 'pointer' }}
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{
                      type: 'spring',
                      stiffness: 300,
                      damping: 20,
                      delay: 0.6 + i * 0.03,
                    }}
                    onClick={() => handleUnitClick(unit)}
                    onMouseEnter={() => handleUnitHover(unit)}
                    onMouseLeave={() => handleUnitHover(null)}
                  >
                    {/* Pulse ring for selected */}
                    {isSelected && (
                      <circle
                        cx={x}
                        cy={y}
                        r={radius + 8}
                        fill="none"
                        stroke={COLORS.cyan}
                        strokeWidth="1.5"
                        opacity={0.6}
                      >
                        <animate attributeName="r" from={radius + 2} to={radius + 20} dur="2s" repeatCount="indefinite" />
                        <animate attributeName="opacity" from="0.6" to="0" dur="2s" repeatCount="indefinite" />
                      </circle>
                    )}

                    {/* Hover glow */}
                    {isHovered && (
                      <circle
                        cx={x}
                        cy={y}
                        r={radius + 6}
                        fill={color}
                        opacity={0.2}
                      />
                    )}

                    {/* Main dot */}
                    <circle
                      cx={x}
                      cy={y}
                      r={isHovered ? radius + 2 : radius}
                      fill={color}
                      stroke={isSelected ? '#ffffff' : '#02040a'}
                      strokeWidth={isSelected ? 2.5 : 1.5}
                      style={{ transition: 'all 0.2s ease' }}
                    />

                    {/* Red shortage badge */}
                    {shortageCount > 0 && (
                      <>
                        <circle
                          cx={x + radius - 2}
                          cy={y - radius + 2}
                          r={7}
                          fill={COLORS.red}
                          stroke="#02040a"
                          strokeWidth="1.5"
                        />
                        <text
                          x={x + radius - 2}
                          y={y - radius + 5}
                          textAnchor="middle"
                          fill="#ffffff"
                          fontSize="8"
                          fontWeight="700"
                          fontFamily="JetBrains Mono"
                        >
                          {shortageCount}
                        </text>
                      </>
                    )}

                    {/* Unit name label */}
                    <text
                      x={x}
                      y={y + radius + 12}
                      textAnchor="middle"
                      fill="#6b7fa3"
                      fontSize="9"
                      fontFamily="Inter"
                      fontWeight="500"
                    >
                      {unit.name}
                    </text>
                  </motion.g>
                );
              })}
            </svg>
          </motion.div>
        </div>

        {/* ── Map Controls (top-right) ── */}
        <motion.div
          initial={{ opacity: 0, x: 10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.4, delay: 1.0 }}
          className="absolute top-3 right-3 z-20 flex flex-col gap-2"
        >
          {/* Zoom buttons */}
          <div className="flex flex-col rounded-lg overflow-hidden border" style={{ backgroundColor: '#101628', borderColor: '#1e2a45' }}>
            <button onClick={handleZoomIn} className="p-1.5 hover:bg-surface transition-colors" title="放大">
              <Plus className="w-4 h-4 text-text-secondary" />
            </button>
            <button onClick={handleZoomOut} className="p-1.5 hover:bg-surface transition-colors border-t" style={{ borderColor: '#1e2a45' }} title="缩小">
              <Minus className="w-4 h-4 text-text-secondary" />
            </button>
          </div>
          <button
            onClick={handleResetView}
            className="px-2 py-1.5 rounded-lg border text-small text-text-secondary hover:text-text-primary hover:bg-surface transition-colors"
            style={{ backgroundColor: '#101628', borderColor: '#1e2a45' }}
          >
            重置视图
          </button>

          {/* Heatmap layer toggle */}
          <div
            className="flex rounded-lg overflow-hidden border"
            style={{ backgroundColor: '#101628', borderColor: '#1e2a45' }}
          >
            {layerKeys.map((key) => (
              <button
                key={key}
                onClick={() => setHeatmapLayer(key)}
                className="text-small px-2 py-1.5 transition-all"
                style={{
                  backgroundColor: heatmapLayer === key ? COLORS.blue : 'transparent',
                  color: heatmapLayer === key ? '#ffffff' : '#6b7fa3',
                }}
              >
                {layerLabels[key]}
              </button>
            ))}
          </div>
        </motion.div>

        {/* ── Floating Legend (bottom-left) ── */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 1.1 }}
          className="absolute bottom-4 left-4 z-20 rounded-lg border p-3"
          style={{
            backgroundColor: 'rgba(5,8,16,0.9)',
            borderColor: '#1e2a45',
          }}
        >
          <div className="text-small text-text-secondary mb-1.5">热力图</div>
          <div className="flex items-center gap-2">
            <span className="text-small text-text-tertiary">低</span>
            <div
              className="w-[120px] h-[12px] rounded-full"
              style={{
                background: `linear-gradient(to right, rgba(33,81,245,0.05), rgba(33,81,245,0.12), rgba(0,229,255,0.2), rgba(0,229,255,0.35))`,
              }}
            />
            <span className="text-small text-text-tertiary">高</span>
          </div>
          <div className="flex items-center gap-3 mt-2">
            <div className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: '#2151f5' }} />
              <span className="text-small text-text-tertiary">正常</span>
            </div>
            <div className="flex items-center gap-1">
              <AlertTriangle className="w-3 h-3 text-accent-red" />
              <span className="text-small text-text-tertiary">预警</span>
            </div>
          </div>
        </motion.div>

        {/* ── Map Tooltip (hover unit dot) ── */}
        <AnimatePresence>
          {hoveredUnit && (
            <motion.div
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 5 }}
              transition={{ duration: 0.15 }}
              className="absolute z-30 rounded-lg border p-3 pointer-events-none"
              style={{
                backgroundColor: '#0a0e1a',
                borderColor: '#2a3a5c',
                boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                left: `${(hoveredUnit.x / 100) * mapWidth * svgZoom + svgPan.x + 20}px`,
                top: `${(hoveredUnit.y / 100) * mapHeight * svgZoom + svgPan.y - 20}px`,
              }}
            >
              <div className="text-h4 text-text-primary font-medium mb-1.5">{hoveredUnit.name}</div>
              <div className="w-full h-px mb-1.5" style={{ backgroundColor: '#1e2a45' }} />
              {(() => {
                const data = assetData[hoveredUnit.id];
                if (!data) return null;
                return (
                  <div className="flex flex-col gap-0.5">
                    <span className="text-mono-sm text-text-primary">
                      装备总值: <span className="font-medium">{Math.round(data.assetCategories.equipment / 10000)}万</span>
                    </span>
                    <span className="text-mono-sm text-text-primary">
                      应急物资总值: <span className="font-medium">{Math.round(data.assetCategories.emergencySupplies / 10000)}万</span>
                    </span>
                    <span className="text-mono-sm text-text-primary">
                      被装物资金额: <span className="font-medium">{Math.round((data.assetCategories.clothingSupplies ?? 0) / 10000)}万</span>
                    </span>
                    <span className="text-mono-sm text-text-primary">
                      办公设备金额: <span className="font-medium">{Math.round(data.assetCategories.officeDevices / 10000)}万</span>
                    </span>
                  </div>
                );
              })()}
              <div className="flex items-center gap-1 mt-1.5 text-text-link">
                <span className="text-small">展开资产详情</span>
                <ChevronRight className="w-3 h-3" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ════════ Left: Right Panel (~60%) ════════ */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
        className="w-[60%] h-full overflow-hidden order-1"
      >
        <RightPanel
          onUnitClick={handleRightPanelUnitClick}
          onPieCategoryClick={handlePieCategoryClick}
        />
      </motion.div>

      {/* ════════ Side Panel (unit detail) ════════ */}
      <SidePanel
        isOpen={!!selectedUnitId}
        unit={selectedUnit}
        tabs={sidePanelTabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onClose={handleClosePanel}
      />
    </div>
  );
}
