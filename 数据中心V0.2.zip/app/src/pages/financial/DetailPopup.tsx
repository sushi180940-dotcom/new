import { memo, useRef, useEffect, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ChevronDown, ChevronUp } from 'lucide-react';
import * as echarts from 'echarts';
import type { EChartOption } from 'echarts';
import type { Unit, FinancialData } from '@/data/mockData';

// Formula definitions
const formulas: Record<string, { name: string; formula: string; color: string }> = {
  debtToAssetRatio: {
    name: '资产负债率',
    formula: '资产负债率 = 负债总额 / 资产总额 x 100%',
    color: '#2151f5',
  },
  currentRatio: {
    name: '流动比率',
    formula: '流动比率 = 流动资产 / 流动负债',
    color: '#a855f7',
  },
  incomeExpenseRatio: {
    name: '收入费用率',
    formula: '收入费用率 = 费用总额 / 收入总额 x 100%',
    color: '#f97316',
  },
  fixedAssetRenewal: {
    name: '固定资产成新率',
    formula: '固定资产成新率 = 固定资产净值 / 固定资产原值 x 100%',
    color: '#00e5ff',
  },
};

interface DetailPopupProps {
  isOpen: boolean;
  unit: Unit | null;
  financialData: FinancialData | null;
  incomeExpenseRatio: number;
  fixedAssetRenewal: number;
  avgValues: {
    debtToAsset: number;
    currentRatio: number;
    incomeExpense: number;
    renewalRate: number;
  };
  onClose: () => void;
}

// Generate 5-year history from current value
function generateHistory(current: number, variance: number = 0.08): number[] {
  const history: number[] = [];
  let val = current;
  for (let i = 0; i < 5; i++) {
    history.unshift(val);
    const change = (Math.sin(i * 1.7 + current) * variance * 2);
    val = Math.max(0.1, val * (1 - change));
  }
  return history;
}

// Mini sparkline SVG
const MiniSparkline = memo(function MiniSparkline({
  data,
  color,
  height = 48,
}: {
  data: number[];
  color: string;
  height?: number;
}) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const w = 280;
  const h = height;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / range) * h * 0.8 - h * 0.1;
    return `${x},${y}`;
  });
  const pathD = `M ${points.join(' L ')}`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full" style={{ height }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`sparkGrad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path
        d={`${pathD} L ${w},${h} L 0,${h} Z`}
        fill={`url(#sparkGrad-${color.replace('#', '')})`}
      />
      <path
        d={pathD}
        fill="none"
        stroke={color}
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
});

// Mini card with sparkline and expandable formula
const MiniIndicatorCard = memo(function MiniIndicatorCard({
  indicatorKey,
  value,
  expanded,
  onToggle,
}: {
  indicatorKey: string;
  value: number;
  expanded: boolean;
  onToggle: () => void;
}) {
  const info = formulas[indicatorKey];
  const history = useMemo(() => generateHistory(value, indicatorKey === 'currentRatio' ? 0.06 : 0.08), [value, indicatorKey]);
  const suffix = indicatorKey === 'currentRatio' ? '' : '%';
  const decimals = indicatorKey === 'currentRatio' ? 2 : 1;

  // Color-code the value
  let valueColor = '#00f5a0';
  if (indicatorKey === 'debtToAssetRatio') {
    valueColor = value < 40 ? '#00f5a0' : value < 55 ? '#ffd166' : '#ff4757';
  } else if (indicatorKey === 'currentRatio') {
    valueColor = value > 1.5 ? '#00f5a0' : value > 1.0 ? '#ffd166' : '#ff4757';
  } else if (indicatorKey === 'incomeExpenseRatio') {
    valueColor = value < 15 ? '#00f5a0' : value < 25 ? '#ffd166' : '#ff4757';
  } else if (indicatorKey === 'fixedAssetRenewal') {
    valueColor = value > 70 ? '#00f5a0' : value > 50 ? '#ffd166' : '#ff4757';
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="bg-deep border border-border-dim rounded-xl p-4"
    >
      <div className="flex items-center justify-between mb-2">
        <span className="text-h4 text-text-secondary">{info.name}</span>
        <span
          className="font-mono text-data-md"
          style={{ color: valueColor }}
        >
          {value.toFixed(decimals)}{suffix}
        </span>
      </div>

      <MiniSparkline data={history} color={info.color} />

      <button
        onClick={onToggle}
        className="flex items-center gap-1 mt-3 text-small text-text-link hover:text-text-primary transition-colors"
      >
        <span>查看计算公式</span>
        {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
            className="overflow-hidden"
          >
            <div className="mt-3 bg-surface rounded-lg px-3 py-3 text-small text-text-secondary">
              <p className="text-text-primary font-medium mb-1">{info.formula}</p>
              <p className="text-text-tertiary mt-2">数据来源：财务管理系统</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
});

// Radar chart component
const RadarChart = memo(function RadarChart({
  unitValues,
  avgValues,
}: {
  unitValues: number[];
  avgValues: number[];
}) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    const instance = echarts.init(chartRef.current);
    chartInstance.current = instance;

    const option: EChartOption = {
      backgroundColor: 'transparent',
      animation: true,
      animationDuration: 800,
      animationEasing: 'cubicOut',
      tooltip: {
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: { color: '#d8dce6', fontSize: 12 },
      },
      radar: {
        indicator: [
          { name: '资产负债率', max: 80 },
          { name: '流动比率', max: 3 },
          { name: '收入费用率', max: 30 },
          { name: '成新率', max: 100 },
          { name: '综合评分', max: 100 },
        ],
        shape: 'polygon',
        splitNumber: 4,
        axisName: {
          color: '#6b7fa3',
          fontSize: 11,
          fontFamily: 'Inter',
        },
        splitLine: {
          lineStyle: { color: '#1e2a45' },
        },
        splitArea: {
          areaStyle: { color: ['transparent', 'rgba(10,14,26,0.5)'] },
        },
        axisLine: {
          lineStyle: { color: '#1e2a45' },
        },
      },
      series: [
        {
          type: 'radar',
          data: [
            {
              value: unitValues,
              name: '本单位',
              symbol: 'circle',
              symbolSize: 6,
              lineStyle: {
                color: '#2151f5',
                width: 2,
              },
              areaStyle: {
                color: 'rgba(33,81,245,0.2)',
              },
              itemStyle: {
                color: '#2151f5',
                borderWidth: 2,
                borderColor: '#050810',
              },
            },
            {
              value: avgValues,
              name: '全厅平均',
              symbol: 'none',
              lineStyle: {
                color: '#3d4f70',
                width: 1,
                type: 'dashed',
              },
              areaStyle: { color: 'transparent' },
              itemStyle: { color: 'transparent' },
            },
          ],
        },
      ],
      legend: {
        bottom: 0,
        textStyle: {
          color: '#6b7fa3',
          fontSize: 11,
        },
        data: ['本单位', '全厅平均'],
      },
    };

    instance.setOption(option);

    const handleResize = () => instance.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      instance.dispose();
    };
  }, [unitValues, avgValues]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
      className="bg-deep border border-border-dim rounded-xl p-4 mt-4"
    >
      <h4 className="text-h4 text-text-secondary mb-4">单位 vs 全厅平均 — 综合对比</h4>
      <div ref={chartRef} style={{ width: '100%', height: 300 }} />
    </motion.div>
  );
});

const DetailPopup = memo(function DetailPopup({
  isOpen,
  unit,
  financialData,
  incomeExpenseRatio,
  fixedAssetRenewal,
  avgValues,
  onClose,
}: DetailPopupProps) {
  const [expandedFormulas, setExpandedFormulas] = useState<Record<string, boolean>>({});

  // Close on Escape
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isOpen, onClose]);

  if (!unit || !financialData) return null;

  const toggleFormula = (key: string) => {
    setExpandedFormulas(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // Compute composite score (0-100, higher = better)
  const unitComposite = (
    (1 - financialData.debtToAssetRatio / 80) * 25 +
    (Math.min(financialData.currentRatio, 3) / 3) * 25 +
    (1 - incomeExpenseRatio / 30) * 25 +
    (fixedAssetRenewal / 100) * 25
  );

  const avgComposite = (
    (1 - avgValues.debtToAsset / 80) * 25 +
    (Math.min(avgValues.currentRatio, 3) / 3) * 25 +
    (1 - avgValues.incomeExpense / 30) * 25 +
    (avgValues.renewalRate / 100) * 25
  );

  const radarUnitValues = [
    financialData.debtToAssetRatio,
    Math.min(financialData.currentRatio, 3),
    incomeExpenseRatio,
    fixedAssetRenewal,
    Math.round(unitComposite),
  ];

  const radarAvgValues = [
    avgValues.debtToAsset,
    Math.min(avgValues.currentRatio, 3),
    avgValues.incomeExpense,
    avgValues.renewalRate,
    Math.round(avgComposite),
  ];

  // Risk badge
  let riskLabel = '低';
  let riskColor = '#00f5a0';
  const redCount = [
    financialData.debtToAssetRatio >= 55,
    financialData.currentRatio < 1.0,
    incomeExpenseRatio > 25,
    fixedAssetRenewal < 50,
  ].filter(Boolean).length;
  const yellowCount = [
    financialData.debtToAssetRatio >= 40 && financialData.debtToAssetRatio < 55,
    financialData.currentRatio >= 1.0 && financialData.currentRatio < 1.5,
    incomeExpenseRatio >= 15 && incomeExpenseRatio <= 25,
    fixedAssetRenewal >= 50 && fixedAssetRenewal <= 70,
  ].filter(Boolean).length;

  if (redCount >= 2 || (redCount >= 1 && yellowCount >= 2)) {
    riskLabel = '高';
    riskColor = '#ff4757';
  } else if (redCount === 1 || yellowCount >= 2) {
    riskLabel = '中';
    riskColor = '#ffd166';
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-50 flex items-center justify-center"
          style={{ backgroundColor: 'rgba(5,8,16,0.85)', backdropFilter: 'blur(8px)' }}
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 25,
            }}
            className="w-full max-w-[720px] max-h-[80vh] overflow-y-auto rounded-2xl border border-border p-6 relative"
            style={{
              backgroundColor: '#050810',
              boxShadow: '0 24px 80px rgba(0,0,0,0.6)',
              margin: '24px',
            }}
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div>
                <div className="flex items-center gap-3 mb-1">
                  <h2 className="text-h2 text-text-primary">{unit.name}</h2>
                  <span
                    className="px-2 py-0.5 rounded-sm text-small font-medium"
                    style={{
                      backgroundColor: 'rgba(33,81,245,0.15)',
                      color: '#4f8af7',
                    }}
                  >
                    {unit.type}
                  </span>
                </div>
                <p className="text-body text-text-secondary">财务指标详情</p>
                <div
                  className="inline-flex items-center gap-1.5 mt-2 px-3 py-1 rounded text-small font-semibold"
                  style={{
                    backgroundColor: `${riskColor}20`,
                    color: riskColor,
                  }}
                >
                  <span>综合风险: {riskLabel}</span>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 rounded-lg hover:bg-surface transition-colors text-text-secondary hover:text-text-primary"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 2x2 Grid of mini indicator cards */}
            <div className="grid grid-cols-2 gap-4">
              <MiniIndicatorCard
                indicatorKey="debtToAssetRatio"
                value={financialData.debtToAssetRatio}
                expanded={!!expandedFormulas['debtToAssetRatio']}
                onToggle={() => toggleFormula('debtToAssetRatio')}
              />
              <MiniIndicatorCard
                indicatorKey="currentRatio"
                value={financialData.currentRatio}
                expanded={!!expandedFormulas['currentRatio']}
                onToggle={() => toggleFormula('currentRatio')}
              />
              <MiniIndicatorCard
                indicatorKey="incomeExpenseRatio"
                value={incomeExpenseRatio}
                expanded={!!expandedFormulas['incomeExpenseRatio']}
                onToggle={() => toggleFormula('incomeExpenseRatio')}
              />
              <MiniIndicatorCard
                indicatorKey="fixedAssetRenewal"
                value={fixedAssetRenewal}
                expanded={!!expandedFormulas['fixedAssetRenewal']}
                onToggle={() => toggleFormula('fixedAssetRenewal')}
              />
            </div>

            {/* Radar chart */}
            <RadarChart unitValues={radarUnitValues} avgValues={radarAvgValues} />
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
});

export default DetailPopup;
