import { memo, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import { Shield, Package, Shirt, Monitor, Car, ChevronRight } from 'lucide-react';
import { assetData, units, type AssetData } from '@/data/mockData';
import { assetCategoryPieOption, assetTrendOption, COLORS } from './chartUtils';

interface RightPanelProps {
  onUnitClick: (unitId: string) => void;
  onPieCategoryClick?: (category: string | null) => void;
}

const springEase = [0.16, 1, 0.3, 1] as [number, number, number, number];

// ── aggregate totals ──
function computeAggregates(allAssetData: Record<string, AssetData>) {
  let equipment = 0, emergencySupplies = 0, clothingSupplies = 0, officeDevices = 0, vehicles = 0, total = 0;
  Object.values(allAssetData).forEach((d) => {
    equipment += d.assetCategories.equipment;
    emergencySupplies += d.assetCategories.emergencySupplies;
    clothingSupplies += d.assetCategories.clothingSupplies ?? 0;
    officeDevices += d.assetCategories.officeDevices;
    vehicles += d.assetCategories.vehicles;
    total += d.totalAssetValue;
  });
  return { equipment, emergencySupplies, clothingSupplies, officeDevices, vehicles, total };
}

const MONTHS = ['1月', '2月', '3月', '4月', '5月', '6月'];

function generateTrend(base: number) {
  const arr: number[] = [];
  let v = base;
  for (let i = 0; i < 6; i++) { v = v * (1 + (Math.random() * 0.04 - 0.015)); arr.push(Math.round(v)); }
  return arr;
}

const RightPanel = memo(function RightPanel({ onUnitClick, onPieCategoryClick }: RightPanelProps) {
  const { equipment, emergencySupplies, clothingSupplies, officeDevices, vehicles, total } = useMemo(
    () => computeAggregates(assetData), []
  );

  // ── L1: Unit ranking data ──
  const unitRanking = useMemo(() => {
    return Object.entries(assetData)
      .map(([uid, d]) => {
        const unit = units.find((u) => u.id === uid);
        return { name: unit?.name || uid, value: d.totalAssetValue, util: d.utilizationRate };
      })
      .sort((a, b) => b.value - a.value);
  }, []);

  // Trend data
  const eqTrend = useMemo(() => generateTrend(equipment), [equipment]);
  const emTrend = useMemo(() => generateTrend(emergencySupplies), [emergencySupplies]);
  const clTrend = useMemo(() => generateTrend(clothingSupplies), [clothingSupplies]);
  const ofTrend = useMemo(() => generateTrend(officeDevices), [officeDevices]);
  const veTrend = useMemo(() => generateTrend(vehicles), [vehicles]);
  const [activeTrendLines, setActiveTrendLines] = useState({ equipment: true, emergency: true, clothing: true, office: true, vehicles: true });

  // Pie data
  const pieData = useMemo(
    () => [
      { name: '武器装备', value: Math.round(equipment * 0.35), color: COLORS.blue },
      { name: '防护装备', value: Math.round(equipment * 0.20), color: COLORS.cyan },
      { name: '安检装备', value: Math.round(equipment * 0.15), color: COLORS.purple },
      { name: '通信及其他', value: Math.round(equipment * 0.12) + Math.round(equipment * 0.06), color: COLORS.teal },
      { name: '应急物资', value: emergencySupplies, color: COLORS.yellow },
      { name: '被装物资', value: clothingSupplies, color: COLORS.purple },
      { name: '办公设备', value: officeDevices, color: COLORS.orange },
      { name: '车辆资产', value: vehicles, color: COLORS.green },
    ],
    [equipment, emergencySupplies, clothingSupplies, officeDevices, vehicles]
  );

  const handlePieClick = (params: { name: string }) => {
    const catMap: Record<string, string> = {
      '武器装备': 'equipment', '防护装备': 'equipment', '安检装备': 'equipment', '通信及其他': 'equipment',
      '应急物资': 'emergencySupplies', '被装物资': 'clothingSupplies', '办公设备': 'officeDevices', '车辆资产': 'vehicles',
    };
    onPieCategoryClick?.(catMap[params.name] || null);
    setTimeout(() => onPieCategoryClick?.(null), 2000);
  };

  const kpiCards = [
    { icon: Shield, label: '装备总值', value: equipment, color: COLORS.blue, pct: '↑2.3%' },
    { icon: Package, label: '应急物资', value: emergencySupplies, color: COLORS.cyan, pct: '缺储7' },
    { icon: Shirt, label: '被装物资', value: clothingSupplies, color: COLORS.purple, pct: '↑1.8%' },
    { icon: Monitor, label: '办公设备', value: officeDevices, color: COLORS.orange, pct: '↑0.8%' },
    { icon: Car, label: '车辆资产', value: vehicles, color: COLORS.teal, pct: '↑0.5%' },
  ];

  return (
    <div className="w-full h-full flex flex-col gap-2 p-3 overflow-hidden" style={{ backgroundColor: '#02040a' }}>

      {/* ════════ Row 1: KPI (~28%) ════════ */}
      <div className="h-[28%] flex gap-2 flex-shrink-0">
        {/* Asset Total - Highlighted Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
          className="w-[30%] h-full rounded-xl border p-2.5 flex flex-col justify-center relative overflow-hidden"
          style={{ background: 'linear-gradient(135deg, rgba(33,81,245,0.25) 0%, rgba(0,229,255,0.1) 100%)', borderColor: 'rgba(33,81,245,0.5)' }}
        >
          <div className="absolute inset-0 pointer-events-none" style={{ boxShadow: 'inset 0 0 40px rgba(33,81,245,0.15)' }} />
          <span className="text-[10px] font-medium relative z-10" style={{ color: '#6b9fff' }}>资产总额</span>
          <span className="font-mono font-bold relative z-10 leading-tight mt-0.5" style={{ fontSize: 'clamp(1.3rem, 2vw, 2rem)', color: '#d8dce6', textShadow: '0 0 20px rgba(33,81,245,0.5), 0 0 40px rgba(33,81,245,0.2)' }}>
            {(total / 10000).toFixed(1)}<span className="text-sm font-medium ml-1">亿</span>
          </span>
          <span className="text-[9px] relative z-10 mt-0.5" style={{ color: '#6b7fa3' }}>全厅12个单位合计</span>
        </motion.div>

        {/* 5 Category Cards */}
        <div className="flex-1 grid grid-cols-3 grid-rows-2 gap-1.5">
          {kpiCards.map((c, i) => (
            <motion.div key={c.label} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.35, delay: 0.1 + i * 0.05, ease: springEase }}
              whileHover={{ borderColor: c.color + '88' }}
              className="rounded-lg border p-1.5 flex flex-col justify-center gap-0.5 cursor-default transition-colors"
              style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
              <div className="flex items-center gap-1"><c.icon className="w-3 h-3" style={{ color: c.color }} /><span className="text-[10px] text-text-secondary">{c.label}</span></div>
              <span className="font-mono text-sm font-semibold" style={{ color: c.color }}>{(c.value / 10000).toFixed(1)}亿</span>
              <span className="text-[9px] font-medium" style={{ color: c.pct.startsWith('↑') ? COLORS.green : COLORS.yellow }}>{c.pct}</span>
            </motion.div>
          ))}
          <div className="rounded-lg border p-1.5 flex flex-col justify-center" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-[10px] text-text-secondary">资产种类</span>
            <span className="font-mono text-sm font-semibold text-text-primary">5大类</span>
            <span className="text-[9px] text-text-tertiary">覆盖全厅</span>
          </div>
        </div>
      </div>

      {/* ════════ Row 2: Rose Pie + Unit Ranking (~40%) ════════ */}
      <div className="h-[40%] flex gap-2 flex-shrink-0">
        {/* Rose Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.35 }}
          className="w-[55%] h-full rounded-xl border p-2 flex flex-col"
          style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
        >
          <h3 className="text-[11px] font-semibold text-text-primary px-1">资产分类占比</h3>
          <div className="flex-1 min-h-0">
            <ReactEChartsCore echarts={echarts} option={assetCategoryPieOption(pieData, total)}
              style={{ height: '100%', width: '100%' }}
              onEvents={{ click: (params: unknown) => handlePieClick(params as { name: string }) }}
            />
          </div>
        </motion.div>

        {/* Unit Ranking */}
        <motion.div
          initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.4 }}
          className="flex-1 h-full rounded-xl border p-2.5 flex flex-col"
          style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
        >
          <div className="flex items-center justify-between mb-1.5 px-1">
            <h3 className="text-[11px] font-semibold text-text-primary">单位资产排名</h3>
            <div className="flex items-center gap-2">
              <span className="text-[9px]" style={{ color: COLORS.textTertiary }}>利用率</span>
              <div className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: COLORS.green }} /><span className="text-[8px]" style={{ color: COLORS.textTertiary }}>≥85</span>
                <span className="w-1.5 h-1.5 rounded-full ml-1" style={{ backgroundColor: COLORS.yellow }} /><span className="text-[8px]" style={{ color: COLORS.textTertiary }}>75</span>
                <span className="w-1.5 h-1.5 rounded-full ml-1" style={{ backgroundColor: COLORS.red }} /><span className="text-[8px]" style={{ color: COLORS.textTertiary }}>&lt;75</span>
              </div>
            </div>
          </div>
          {/* Column headers */}
          <div className="flex items-center gap-2 px-1.5 py-0.5 mb-0.5" style={{ borderBottom: '1px solid #1e2a45' }}>
            <span className="text-[9px] w-4 text-center" style={{ color: COLORS.textTertiary }}>#</span>
            <span className="text-[9px] flex-1" style={{ color: COLORS.textTertiary }}>单位</span>
            <span className="text-[9px] w-10 text-right" style={{ color: COLORS.textTertiary }}>资产</span>
            <span className="text-[9px] w-12 text-right" style={{ color: COLORS.textTertiary }}>利用率</span>
          </div>
          <div className="flex-1 min-h-0 overflow-y-auto flex flex-col gap-0.5">
            {unitRanking.map((u, i) => (
              <motion.div key={u.name} initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.45 + i * 0.03, duration: 0.25 }}
                className="flex items-center gap-2 py-1 px-1.5 rounded cursor-pointer hover:bg-white/5 transition-colors"
                onClick={() => onUnitClick(units.find(un => un.name === u.name)?.id || '')}>
                <span className="text-[10px] font-mono w-4 text-center" style={{ color: i < 3 ? COLORS.blue : COLORS.textTertiary }}>{i + 1}</span>
                <span className="text-[11px] text-text-primary flex-1 truncate">{u.name}</span>
                <span className="text-[10px] font-mono w-10 text-right" style={{ color: COLORS.textSecondary }}>{(u.value / 10000).toFixed(1)}亿</span>
                {/* Utilization bar */}
                <div className="w-12 flex items-center gap-1">
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: '#1e2a45' }}>
                    <div className="h-full rounded-full" style={{
                      width: `${Math.min(u.util, 100)}%`,
                      backgroundColor: u.util >= 85 ? COLORS.green : u.util >= 75 ? COLORS.yellow : COLORS.red,
                    }} />
                  </div>
                  <span className="text-[9px] font-mono" style={{
                    color: u.util >= 85 ? COLORS.green : u.util >= 75 ? COLORS.yellow : COLORS.red,
                  }}>{u.util}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* ════════ Row 3: Trend (~32%) ════════ */}
      <motion.div
        initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.5 }}
        className="h-[32%] rounded-xl border p-2 flex flex-col flex-shrink-0"
        style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
      >
        <h3 className="text-[11px] font-semibold text-text-primary mb-1 px-1">近6个月资产总值变动</h3>
        <div className="flex flex-wrap gap-1 mb-1 px-1">
          {[
            { key: 'equipment', label: '装备', color: COLORS.blue },
            { key: 'emergency', label: '应急', color: COLORS.cyan },
            { key: 'clothing', label: '被装', color: COLORS.purple },
            { key: 'office', label: '办公', color: COLORS.orange },
            { key: 'vehicles', label: '车辆', color: COLORS.teal },
          ].map((pill) => (
            <button key={pill.key} onClick={() => setActiveTrendLines((prev) => ({ ...prev, [pill.key]: !prev[pill.key as keyof typeof prev] }))}
              className="text-[10px] px-2 py-0.5 rounded transition-all"
              style={{
                backgroundColor: activeTrendLines[pill.key as keyof typeof activeTrendLines] ? `${pill.color}22` : 'rgba(16,22,40,0.5)',
                color: activeTrendLines[pill.key as keyof typeof activeTrendLines] ? pill.color : '#3d4f70',
                border: `1px solid ${activeTrendLines[pill.key as keyof typeof activeTrendLines] ? `${pill.color}44` : '#1e2a45'}`,
              }}>{pill.label}</button>
          ))}
        </div>
        <div className="flex-1 min-h-0">
          <ReactEChartsCore echarts={echarts}
            option={assetTrendOption(MONTHS, eqTrend, emTrend, clTrend, ofTrend, veTrend, activeTrendLines, {
              '装备': equipment, '应急物资': emergencySupplies, '被装物资': clothingSupplies, '办公设备': officeDevices, '车辆': vehicles,
            })}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

    </div>
  );
});

export default RightPanel;
