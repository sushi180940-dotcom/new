// ECharts option builders for Asset Panorama
// Uses echarts directly - options passed to ReactEChartsCore

export const COLORS = {
  blue: '#2151f5',
  cyan: '#00e5ff',
  green: '#00f5a0',
  yellow: '#ffd166',
  red: '#ff4757',
  purple: '#a855f7',
  teal: '#5eead4',
  orange: '#f97316',
  textPrimary: '#d8dce6',
  textSecondary: '#6b7fa3',
  textTertiary: '#3d4f70',
  borderDim: '#1e2a45',
  border: '#2a3a5c',
  borderBright: '#3d5296',
  deep: '#0a0e1a',
  abyss: '#050810',
};

const tooltipBase = {
  backgroundColor: '#0a0e1a',
  borderColor: '#2a3a5c',
  borderWidth: 1,
  textStyle: { color: '#d8dce6', fontSize: 12, fontFamily: 'Inter' },
  padding: [10, 14],
};

// ── Right Panel: Asset Category Pie (Nightingale Rose) ──
export function assetCategoryPieOption(
  data: { name: string; value: number; color: string }[],
  total: number
) {
  return {
    animationDuration: 800,
    animationEasing: 'cubicOut' as const,
    tooltip: {
      ...tooltipBase,
      trigger: 'item' as const,
      formatter: (p: Record<string, unknown>) =>
        `<div style="text-align:center;font-weight:700;font-size:14px;margin-bottom:4px">${p.name}</div>` +
        `<div style="text-align:center;font-size:16px;font-family:'JetBrains Mono'">${p.value}万</div>` +
        `<div style="text-align:center;font-size:12px;color:#6b7fa3">占比 ${p.percent}%</div>`,
    },
    series: [
      {
        type: 'pie',
        radius: ['32%', '72%'],
        center: ['38%', '50%'],
        roseType: 'radius' as const,
        avoidLabelOverlap: true,
        itemStyle: {
          borderRadius: 6,
          borderColor: '#0a0e1a',
          borderWidth: 3,
        },
        label: { show: false },
        emphasis: {
          scaleSize: 10,
          itemStyle: {
            shadowBlur: 24,
            shadowColor: 'rgba(33,81,245,0.4)',
          },
        },
        data: data.map((d) => ({
          name: d.name,
          value: d.value,
          itemStyle: { color: d.color },
        })),
      },
    ],
    legend: {
      orient: 'vertical' as const,
      right: '2%',
      top: 'center',
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 12,
      formatter: (name: string) => {
        const item = data.find((d) => d.name === name);
        const pct = item ? ((item.value / data.reduce((s, d) => s + d.value, 0)) * 100).toFixed(0) : '0';
        return `{name|${name}}  {pct|${pct}%}`;
      },
      textStyle: {
        rich: {
          name: { color: '#6b7fa3', fontSize: 11 },
          pct: { color: '#d8dce6', fontSize: 11, fontFamily: 'JetBrains Mono', fontWeight: 600 },
        },
      },
    },
  };
}

// ── Right Panel: Asset Trend Line (indexed to first month = 100) ──
export function assetTrendOption(
  months: string[],
  equipment: number[],
  emergency: number[],
  clothing: number[],
  office: number[],
  vehicles: number[],
  activeLines: { equipment: boolean; emergency: boolean; clothing: boolean; office: boolean; vehicles: boolean },
  baseValues: Record<string, number>
) {
  const series: Array<Record<string, unknown>> = [];
  const addSeries = (key: string, name: string, color: string, data: number[]) => {
    const indexed = data.map((v, i) => i === 0 ? 100 : Math.round((v / data[0]) * 100));
    series.push({
      name, type: 'line', smooth: true,
      symbol: 'circle', symbolSize: 6,
      emphasis: { focus: 'series' as const, scale: true, itemStyle: { borderWidth: 3, borderColor: '#fff', shadowBlur: 10, shadowColor: color + '66' } },
      lineStyle: { width: 2.5, color, shadowBlur: 6, shadowColor: color + '33' },
      itemStyle: { color, borderWidth: 1.5, borderColor: '#0a0e1a' },
      areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: color + '25' }, { offset: 0.6, color: color + '10' }, { offset: 1, color: color + '00' }] } },
      data: indexed,
    });
  };
  if (activeLines.equipment) addSeries('equipment', '装备', COLORS.blue, equipment);
  if (activeLines.emergency) addSeries('emergency', '应急物资', COLORS.cyan, emergency);
  if (activeLines.clothing) addSeries('clothing', '被装物资', COLORS.purple, clothing);
  if (activeLines.office) addSeries('office', '办公设备', COLORS.orange, office);
  if (activeLines.vehicles) addSeries('vehicles', '车辆', COLORS.teal, vehicles);

  return {
    animationDuration: 800,
    animationEasing: 'cubicOut' as const,
    tooltip: {
      ...tooltipBase,
      trigger: 'axis' as const,
      formatter: (params: Array<{ seriesName: string; value: number; color: string }>) => {
        let html = `<div style="font-weight:600;margin-bottom:4px">${params[0]?.axisValue || ''}</div>`;
        params.forEach((p) => {
          const base = baseValues[p.seriesName] || 0;
          const absChange = Math.round(base * (p.value - 100) / 100);
          const sign = absChange >= 0 ? '+' : '';
          html += `<div style="display:flex;align-items:center;gap:6px;margin:2px 0">
            <span style="width:8px;height:8px;border-radius:50%;background:${p.color}"></span>
            <span style="flex:1">${p.seriesName}</span>
            <span style="font-weight:600">${p.value}</span>
            <span style="color:${absChange >= 0 ? COLORS.green : COLORS.red};font-size:11px">(${sign}${absChange}万)</span>
          </div>`;
        });
        return html;
      },
    },
    legend: { show: false },
    grid: { left: 10, right: 10, top: 10, bottom: 24, containLabel: true },
    xAxis: {
      type: 'category', data: months,
      axisLine: { lineStyle: { color: COLORS.borderDim } },
      axisLabel: { color: COLORS.textSecondary, fontSize: 11 }, axisTick: { show: false },
    },
    yAxis: {
      type: 'value', min: 95, max: 105,
      axisLine: { show: false }, axisTick: { show: false },
      splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' as const } },
      axisLabel: { color: COLORS.textTertiary, fontSize: 11, formatter: '{value}' },
    },
    series,
  };
}

// ── Tab 1: Equipment Category Pie ──
export function equipmentPieOption(
  data: { name: string; value: number }[],
  colors: string[]
) {
  return {
    animationDuration: 600,
    animationEasing: 'cubicOut' as const,
    tooltip: {
      ...tooltipBase,
      trigger: 'item' as const,
      formatter: (p: Record<string, unknown>) => `${p.name}: ${p.value}万 (${p.percent}%)`,
    },
    series: [
      {
        type: 'pie',
        radius: ['45%', '68%'],
        center: ['35%', '50%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderRadius: 4,
          borderColor: '#0a0e1a',
          borderWidth: 2,
        },
        label: { show: false },
        emphasis: {
          scaleSize: 6,
        },
        data: data.map((d, i) => ({
          name: d.name,
          value: d.value,
          itemStyle: { color: colors[i % colors.length] },
        })),
      },
    ],
    legend: {
      orient: 'vertical' as const,
      right: '2%',
      top: 'center',
      textStyle: { color: COLORS.textSecondary, fontSize: 11 },
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 10,
      formatter: (name: string) => {
        const item = data.find((d) => d.name === name);
        return item ? `${name}  ${item.value}万` : name;
      },
    },
  };
}

// ── Tab 1: Per-Capita Equipment Bar ──
export function perCapitaBarOption(
  categories: string[],
  unitValues: number[],
  avgValues: number[]
) {
  return {
    animationDuration: 600,
    animationEasing: 'cubicOut' as const,
    animationDelay: (idx: number) => idx * 80,
    tooltip: {
      ...tooltipBase,
      trigger: 'axis' as const,
      axisPointer: { type: 'shadow' as const },
    },
    legend: {
      data: ['本单位', '全厅均值'],
      textStyle: { color: COLORS.textSecondary, fontSize: 11 },
      right: 0,
      top: 0,
      itemWidth: 12,
      itemHeight: 6,
    },
    grid: { left: 8, right: 50, top: 28, bottom: 8, containLabel: true },
    xAxis: {
      type: 'value',
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' as const } },
      axisLabel: { color: COLORS.textTertiary, fontSize: 11 },
    },
    yAxis: {
      type: 'category',
      data: categories,
      axisLine: { lineStyle: { color: COLORS.borderDim } },
      axisLabel: { color: COLORS.textSecondary, fontSize: 11 },
      axisTick: { show: false },
    },
    series: [
      {
        name: '本单位',
        type: 'bar',
        barWidth: 10,
        itemStyle: { color: COLORS.blue, borderRadius: [0, 4, 4, 0] },
        data: unitValues,
      },
      {
        name: '全厅均值',
        type: 'bar',
        barWidth: 10,
        itemStyle: { color: COLORS.borderBright, borderRadius: [0, 4, 4, 0], opacity: 0.5 },
        data: avgValues,
      },
    ],
  };
}

// ── Tab 2: Supply Category Pie ──
export function supplyPieOption(
  data: { name: string; value: number; shortage?: boolean }[],
  colors: string[]
) {
  return {
    animationDuration: 600,
    tooltip: {
      ...tooltipBase,
      trigger: 'item' as const,
      formatter: (p: Record<string, unknown>) => {
        const marker = (p.data as { shortage?: boolean } | undefined)?.shortage ? ' (缺储)' : '';
        return `${p.name}${marker}: ${p.value}万 (${p.percent}%)`;
      },
    },
    series: [
      {
        type: 'pie',
        radius: ['45%', '68%'],
        center: ['35%', '50%'],
        itemStyle: {
          borderRadius: 4,
          borderColor: '#0a0e1a',
          borderWidth: 2,
        },
        label: { show: false },
        emphasis: {
          scaleSize: 6,
        },
        data: data.map((d, i) => ({
          name: d.name,
          value: d.value,
          shortage: d.shortage,
          itemStyle: {
            color: d.shortage ? COLORS.red : colors[i % colors.length],
            shadowBlur: d.shortage ? 10 : 0,
            shadowColor: d.shortage ? 'rgba(255,71,87,0.5)' : 'transparent',
          },
        })),
      },
    ],
    legend: {
      orient: 'vertical' as const,
      right: '2%',
      top: 'center',
      textStyle: { color: COLORS.textSecondary, fontSize: 11 },
      itemWidth: 10,
      itemHeight: 10,
      itemGap: 10,
    },
  };
}

// ── Tab 2: Supply Age Distribution Bar ──
export function supplyAgeBarOption(
  ageGroups: string[],
  values: number[]
) {
  const barColors = ['#00f5a0', '#ffd166', '#f97316', '#ff4757', '#ff4757'];
  return {
    animationDuration: 600,
    animationEasing: 'cubicOut' as const,
    animationDelay: (idx: number) => idx * 100,
    tooltip: {
      ...tooltipBase,
      trigger: 'axis' as const,
      axisPointer: { type: 'shadow' as const },
    },
    grid: { left: 10, right: 20, top: 16, bottom: 28, containLabel: true },
    xAxis: {
      type: 'category',
      data: ageGroups,
      axisLine: { lineStyle: { color: COLORS.borderDim } },
      axisLabel: { color: COLORS.textSecondary, fontSize: 11 },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' as const } },
      axisLabel: { color: COLORS.textTertiary, fontSize: 11, formatter: '{value}万' },
    },
    series: [
      {
        type: 'bar',
        barWidth: 28,
        data: values.map((v, i) => ({
          value: v,
          itemStyle: {
            color: barColors[i % barColors.length],
            borderRadius: [4, 4, 0, 0],
          },
        })),
      },
    ],
  };
}

// ── Tab 2: Compliance Gauge ──
export function complianceGaugeOption(value: number) {
  const color = value >= 90 ? COLORS.green : value >= 70 ? COLORS.yellow : COLORS.red;
  return {
    animationDuration: 800,
    animationEasing: 'cubicOut' as const,
    series: [
      {
        type: 'gauge',
        startAngle: 200,
        endAngle: -20,
        min: 0,
        max: 100,
        radius: '85%',
        center: ['50%', '55%'],
        splitNumber: 10,
        axisLine: {
          lineStyle: {
            width: 10,
            color: [
              [0.7, COLORS.red],
              [0.9, COLORS.yellow],
              [1, COLORS.green],
            ],
          },
        },
        pointer: {
          itemStyle: { color },
          width: 4,
          length: '60%',
        },
        axisTick: { show: false },
        splitLine: { length: 8, lineStyle: { color: COLORS.borderDim, width: 1 } },
        axisLabel: { color: COLORS.textTertiary, fontSize: 10, distance: 14 },
        detail: {
          valueAnimation: true,
          fontSize: 24,
          fontWeight: 600,
          fontFamily: 'JetBrains Mono',
          color,
          offsetCenter: [0, '55%'],
          formatter: '{value}%',
        },
        data: [{ value }],
      },
    ],
  };
}

// ── Tab 3: Device Age Structure Bar ──
export function deviceAgeBarOption(
  categories: string[],
  newData: number[],
  midData: number[],
  oldData: number[],
  staleData: number[]
) {
  return {
    animationDuration: 600,
    animationEasing: 'cubicOut' as const,
    tooltip: {
      ...tooltipBase,
      trigger: 'axis' as const,
      axisPointer: { type: 'shadow' as const },
    },
    legend: {
      data: ['1年内', '1-2年', '2年以上', '呆滞'],
      textStyle: { color: COLORS.textSecondary, fontSize: 11 },
      right: 0,
      top: 0,
      itemWidth: 10,
      itemHeight: 6,
    },
    grid: { left: 10, right: 10, top: 28, bottom: 24, containLabel: true },
    xAxis: {
      type: 'category',
      data: categories,
      axisLine: { lineStyle: { color: COLORS.borderDim } },
      axisLabel: { color: COLORS.textSecondary, fontSize: 11 },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' as const } },
      axisLabel: { color: COLORS.textTertiary, fontSize: 11 },
    },
    series: [
      { name: '1年内', type: 'bar', stack: 'total', barWidth: 24, itemStyle: { color: COLORS.green }, data: newData },
      { name: '1-2年', type: 'bar', stack: 'total', itemStyle: { color: COLORS.cyan }, data: midData },
      { name: '2年以上', type: 'bar', stack: 'total', itemStyle: { color: COLORS.yellow }, data: oldData },
      { name: '呆滞', type: 'bar', stack: 'total', itemStyle: { color: COLORS.red, borderRadius: [3, 3, 0, 0] }, data: staleData },
    ],
  };
}

// ── Tab 3: Annual Distribution Line ──
export function distributionLineOption(
  months: string[],
  issued: number[],
  returned: number[]
) {
  return {
    animationDuration: 800,
    animationEasing: 'cubicOut' as const,
    tooltip: {
      ...tooltipBase,
      trigger: 'axis' as const,
    },
    legend: {
      data: ['发放', '回收'],
      textStyle: { color: COLORS.textSecondary, fontSize: 11 },
      right: 0,
      top: 0,
      itemWidth: 12,
      itemHeight: 6,
    },
    grid: { left: 10, right: 20, top: 28, bottom: 24, containLabel: true },
    xAxis: {
      type: 'category',
      data: months,
      axisLine: { lineStyle: { color: COLORS.borderDim } },
      axisLabel: { color: COLORS.textSecondary, fontSize: 11 },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      axisLine: { show: false },
      axisTick: { show: false },
      splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' as const } },
      axisLabel: { color: COLORS.textTertiary, fontSize: 11 },
    },
    series: [
      {
        name: '发放',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        lineStyle: { width: 2, color: COLORS.blue },
        itemStyle: { color: COLORS.blue },
        areaStyle: {
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(33,81,245,0.12)' },
              { offset: 1, color: 'rgba(33,81,245,0)' },
            ],
          },
        },
        data: issued,
      },
      {
        name: '回收',
        type: 'line',
        smooth: true,
        symbol: 'circle',
        symbolSize: 5,
        lineStyle: { width: 2, color: COLORS.cyan, type: 'dashed' as const },
        itemStyle: { color: COLORS.cyan },
        data: returned,
      },
    ],
  };
}
