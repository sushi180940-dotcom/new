import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import { AlertTriangle, Navigation, Clock, Gauge } from 'lucide-react';
import type { AssetData } from '@/data/mockData';
import { assetData, units } from '@/data/mockData';
import {
  equipmentPieOption,
  perCapitaBarOption,
  supplyPieOption,
  supplyAgeBarOption,
  complianceGaugeOption,
  COLORS,
} from './chartUtils';

const springEase = [0.16, 1, 0.3, 1] as [number, number, number, number];

// ═══════════════════════════════════════════════════════════════
// Tab 1 — 装备 (Equipment)  + 新增指标
// ═══════════════════════════════════════════════════════════════

export function EquipmentTab({ data }: { data: AssetData; unitName: string }) {
  const totalEquipment = data.assetCategories.equipment;
  const originalValue = data.equipmentOriginalValue;
  const netValue = totalEquipment;
  const deprRate = data.equipmentDepreciationRate;

  // 分类装备价值占比
  const equipCategories = [
    { name: '武器警械', value: Math.round(totalEquipment * 0.28), color: COLORS.blue },
    { name: '防护装备', value: Math.round(totalEquipment * 0.22), color: COLORS.cyan },
    { name: '安检装备', value: Math.round(totalEquipment * 0.18), color: COLORS.purple },
    { name: '通信装备', value: Math.round(totalEquipment * 0.14), color: COLORS.green },
    { name: '交通工具', value: Math.round(totalEquipment * 0.12), color: COLORS.yellow },
    { name: '其他', value: Math.round(totalEquipment * 0.06), color: COLORS.textTertiary },
  ];

  // 人均装备价值对比
  const categories = ['武器警械', '防护装备', '安检装备', '通信装备', '交通工具'];
  const unitPerCapita = equipCategories.slice(0, 5).map((c) => Math.round(c.value / 120));
  const avgPerCapita = [18, 14, 11, 9, 8];

  // 超编/闲置清单
  const overstockList = [
    { name: '对讲机', spec: 'Motorola CP200D', qty: 45, standard: 30, excess: 15, status: '超编' as const },
    { name: '执法记录仪', spec: 'DSJ-A7', qty: 320, standard: 280, excess: 40, status: '超编' as const },
    { name: '无人机', spec: 'DJI Mavic 3', qty: 3, standard: 8, excess: 0, status: '闲置' as const },
    { name: '防弹盾牌', spec: 'PE-III级', qty: 18, standard: 15, excess: 3, status: '超编' as const },
    { name: '金属探测器', spec: 'GP-3003B1', qty: 6, standard: 10, excess: 0, status: '闲置' as const },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* 装备资产总原值 / 总净值 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">装备资产总原值</span>
            <div className="text-data-md font-mono text-text-primary">{Math.round(originalValue / 100)}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">装备资产总净值</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.blue }}>{Math.round(netValue / 100)}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">综合折旧率</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.yellow }}>{deprRate}%</div>
          </div>
        </div>
      </motion.div>

      {/* 分类装备价值占比 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">分类装备价值占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore echarts={echarts} option={equipmentPieOption(equipCategories, equipCategories.map((c) => c.color))} style={{ height: '100%', width: '100%' }} />
        </div>
      </motion.div>

      {/* 人均装备价值对比 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">人均装备价值对比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore echarts={echarts} option={perCapitaBarOption(categories, unitPerCapita, avgPerCapita)} style={{ height: '100%', width: '100%' }} />
        </div>
      </motion.div>

      {/* 超编/闲置装备清单 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">超编/闲置装备清单</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-3 py-2">装备名称</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">在编</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">标准</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">超出</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
              </tr>
            </thead>
            <tbody>
              {overstockList.map((item, i) => (
                <motion.tr key={item.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-3 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.qty}</td>
                  <td className="px-2 py-2 text-text-secondary font-mono">{item.standard}</td>
                  <td className="px-2 py-2 font-mono" style={{ color: item.excess > 0 ? COLORS.yellow : COLORS.textSecondary }}>{item.excess > 0 ? `+${item.excess}` : '-'}</td>
                  <td className="px-2 py-2">
                    <span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: item.status === '超编' ? 'rgba(255,209,102,0.15)' : 'rgba(255,71,87,0.15)', color: item.status === '超编' ? COLORS.yellow : COLORS.red }}>{item.status}</span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 2 — 应急物资 (Emergency Supplies)  + 新增指标
// ═══════════════════════════════════════════════════════════════

export function SuppliesTab({ data }: { data: AssetData; unitName: string }) {
  const totalEmergency = data.assetCategories.emergencySupplies;

  // 物资品类覆盖率（新增）— 防御性默认值
  const categoryCoverage = data.emergencyCategoryCoverageRate ?? 85;

  // 各类物资数量和价值（新增）— 防御性默认值
  const qtyData = data.emergencyQuantityByCategory ?? [];

  // 各类物资价值占比（已有）
  const supplyCategories = useMemo(() => {
    const items = [
      { name: '防护用品', value: Math.round(totalEmergency * 0.30), shortage: false },
      { name: '急救药品', value: Math.round(totalEmergency * 0.22), shortage: false },
      { name: '照明设备', value: Math.round(totalEmergency * 0.18), shortage: false },
      { name: '通信设备', value: Math.round(totalEmergency * 0.14), shortage: false },
      { name: '食品饮水', value: Math.round(totalEmergency * 0.10), shortage: false },
      { name: '其他', value: Math.round(totalEmergency * 0.06), shortage: false },
    ];
    const shortageTypes = new Set(data.emergencySupplyTypes.filter((s) => s.status !== 'normal').map((s) => s.type));
    if (shortageTypes.has('急救包')) items[1].shortage = true;
    if (shortageTypes.has('通信设备')) items[3].shortage = true;
    if (shortageTypes.has('消防器材')) items[0].shortage = true;
    if (shortageTypes.has('救生衣')) items[0].shortage = true;
    if (shortageTypes.has('防暴器材')) items[0].shortage = true;
    if (shortageTypes.has('应急照明')) items[2].shortage = true;
    return items;
  }, [totalEmergency, data.emergencySupplyTypes]);

  const supplyColors = [COLORS.blue, COLORS.cyan, COLORS.green, COLORS.yellow, COLORS.purple, COLORS.textTertiary];

  // 各类物资数量占比（新增）
  const totalQty = qtyData.reduce((s, d) => s + d.quantity, 0);

  // 仓库分布（新增）— 防御性默认值
  const warehouseData = data.emergencyWarehouses ?? [];

  // 代储价值（新增）— 防御性默认值
  const agencyData = data.emergencyAgencyStorage ?? [];

  // 区域覆盖度（新增）— 防御性默认值
  const regionalCoverage = data.emergencyRegionalCoverage ?? 80;

  // 库龄（已有）
  const ageGroups = ['0-6月', '6-12月', '1-2年', '2-3年', '>3年'];
  const ageValues = [Math.round(totalEmergency * 0.35), Math.round(totalEmergency * 0.28), Math.round(totalEmergency * 0.20), Math.round(totalEmergency * 0.12), Math.round(totalEmergency * 0.05)];

  // 达标率（已有）
  const complianceRate = useMemo(() => {
    const totalTypes = data.emergencySupplyTypes.length;
    const normalTypes = data.emergencySupplyTypes.filter((s) => s.status === 'normal').length;
    return Math.round((normalTypes / totalTypes) * 100);
  }, [data.emergencySupplyTypes]);

  const nearExpiryItems = [
    { name: '急救包A型', date: '2023-05-12', shelf: '3年', remaining: '45天', status: '临期' as const, action: '尽快使用' },
    { name: '应急干粮', date: '2023-08-20', shelf: '2年', remaining: '已过期', status: '已过期' as const, action: '申请报废' },
    { name: '消毒液', date: '2024-01-15', shelf: '1年', remaining: '30天', status: '临期' as const, action: '尽快使用' },
    { name: '手电筒电池', date: '2022-11-03', shelf: '3年', remaining: '已过期', status: '已过期' as const, action: '申请报废' },
  ];

  const statusColors = { '正常': COLORS.green, '临期': COLORS.yellow, '已过期': COLORS.red };

  return (
    <div className="flex flex-col gap-5">
      {/* 核心指标卡片 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">应急物资总价值</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.cyan }}>{Math.round(totalEmergency / 100)}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">品类覆盖率</span>
            <div className="text-data-md font-mono" style={{ color: categoryCoverage >= 90 ? COLORS.green : COLORS.yellow }}>{categoryCoverage}%</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">区域覆盖度</span>
            <div className="text-data-md font-mono" style={{ color: regionalCoverage >= 80 ? COLORS.green : COLORS.yellow }}>{regionalCoverage}%</div>
          </div>
        </div>
      </motion.div>

      {/* 各类物资数量占比（新增） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">各类物资数量占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{
              animationDuration: 600, tooltip: { trigger: 'item', backgroundColor: '#0a0e1a', borderColor: '#2a3a5c', textStyle: { color: '#d8dce6' }, formatter: (p: Record<string, unknown>) => `${p.name}: ${p.value}件 (${p.percent}%)` },
              series: [{ type: 'pie', radius: ['45%', '68%'], center: ['35%', '50%'], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }, label: { show: false }, emphasis: { scaleSize: 6 },
                data: qtyData.map((d, i) => ({ name: d.type, value: d.quantity, itemStyle: { color: supplyColors[i % supplyColors.length] } })),
              }],
              legend: { orient: 'vertical', right: '2%', top: 'center', textStyle: { color: COLORS.textSecondary, fontSize: 11 }, itemWidth: 10, itemHeight: 10, itemGap: 10 },
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* 各类物资价值占比（已有） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.05, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">各类物资价值占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore echarts={echarts} option={supplyPieOption(supplyCategories, supplyColors)} style={{ height: '100%', width: '100%' }} />
        </div>
      </motion.div>

      {/* 各仓库/存放点价值分布（新增） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">各仓库/存放点价值分布</h4>
        <div className="h-[160px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{
              animationDuration: 600, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: '#0a0e1a', borderColor: '#2a3a5c', textStyle: { color: '#d8dce6' } },
              grid: { left: 10, right: 20, top: 10, bottom: 24, containLabel: true },
              xAxis: { type: 'category', data: warehouseData.map((d) => d.name), axisLine: { lineStyle: { color: COLORS.borderDim } }, axisLabel: { color: COLORS.textSecondary, fontSize: 11 }, axisTick: { show: false } },
              yAxis: { type: 'value', axisLine: { show: false }, axisTick: { show: false }, splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' } }, axisLabel: { color: COLORS.textTertiary, fontSize: 11, formatter: '{value}万' } },
              series: [{ type: 'bar', barWidth: 28, itemStyle: { color: COLORS.cyan, borderRadius: [4, 4, 0, 0] }, data: warehouseData.map((d) => Math.round(d.value / 100)) }],
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* 各厅属单位代储价值（新增） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">各厅属单位代储价值</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-3 py-2">代储单位</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">代储金额</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">占比</th>
            </tr></thead>
            <tbody>
              {agencyData.map((item, i) => (
                <motion.tr key={item.unitName} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-3 py-2 text-text-primary">{item.unitName}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{Math.round(item.value / 100)}万</td>
                  <td className="px-2 py-2 font-mono" style={{ color: COLORS.cyan }}>{(item.value / totalEmergency * 100).toFixed(1)}%</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* 在库物资库龄分布（已有） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">在库物资库龄分布</h4>
        <div className="h-[160px]"><ReactEChartsCore echarts={echarts} option={supplyAgeBarOption(ageGroups, ageValues)} style={{ height: '100%', width: '100%' }} /></div>
      </motion.div>

      {/* 临期/过期物资明细（已有） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.25, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">临期/过期物资明细</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">物资名称</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">入库</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">剩余</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">建议</th>
            </tr></thead>
            <tbody>
              {nearExpiryItems.map((item, i) => (
                <motion.tr key={item.name} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 font-mono" style={{ color: statusColors[item.status] }}>{item.remaining}</td>
                  <td className="px-2 py-2"><span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: `${statusColors[item.status]}22`, color: statusColors[item.status] }}>{item.status}</span></td>
                  <td className="px-2 py-2 text-text-secondary">{item.action}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* 报废记录（新增） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">报废记录</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">资产名称</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">类型</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">日期</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">原因</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
              </tr>
            </thead>
            <tbody>
              {data.scrapRecords.map((item, i) => (
                <motion.tr key={item.assetName + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.35 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-primary">{item.assetName}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.assetType}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.reason}</td>
                  <td className="px-2 py-2">
                    <span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{
                      backgroundColor: item.approvalStatus === '已通过' ? 'rgba(0,245,160,0.15)' : item.approvalStatus === '审批中' ? 'rgba(255,209,102,0.15)' : 'rgba(255,71,87,0.15)',
                      color: item.approvalStatus === '已通过' ? '#00f5a0' : item.approvalStatus === '审批中' ? '#ffd166' : '#ff4757'
                    }}>{item.approvalStatus}</span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* 储备达标率仪表盘（已有） */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.3, ease: springEase }} className="flex items-center gap-4">
        <div className="w-[140px] h-[140px]"><ReactEChartsCore echarts={echarts} option={complianceGaugeOption(complianceRate)} style={{ height: '100%', width: '100%' }} /></div>
        <div className="flex flex-col gap-1">
          <span className="text-body text-text-secondary">应急物资储备达标率</span>
          <span className="text-data-md font-mono" style={{ color: complianceRate >= 90 ? COLORS.green : complianceRate >= 70 ? COLORS.yellow : COLORS.red }}>{complianceRate}%</span>
          <span className="text-small text-text-tertiary">属地标准: 90%</span>
        </div>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 3 — 被装物资 (Clothing Supplies)
// ═══════════════════════════════════════════════════════════════

export function ClothingTab({ data }: { data: AssetData; unitName: string }) {
  const totalClothing = data.assetCategories.clothingSupplies ?? data.assetCategories.officeDevices ?? 0;

  const clothingCategories = [
    { name: '警服常服', value: Math.round(totalClothing * 0.35), color: COLORS.blue },
    { name: '作训服', value: Math.round(totalClothing * 0.25), color: COLORS.cyan },
    { name: '防寒被装', value: Math.round(totalClothing * 0.18), color: COLORS.purple },
    { name: '鞋靴', value: Math.round(totalClothing * 0.12), color: COLORS.green },
    { name: '配饰标识', value: Math.round(totalClothing * 0.06), color: COLORS.yellow },
    { name: '其他', value: Math.round(totalClothing * 0.04), color: COLORS.textTertiary },
  ];

  const ageCategories = ['警服常服', '作训服', '防寒被装', '鞋靴', '配饰标识'];
  const ageNew = [80, 60, 25, 35, 20];
  const ageMid = [55, 45, 30, 28, 15];
  const ageOld = [30, 20, 18, 15, 8];
  const ageStale = [10, 8, 5, 6, 3];

  // Real scrap records from data
  const staleItems = data.scrapRecords.filter((r) => r.assetType === '被装物资' || r.assetType === '装备');

  const actionColors: Record<string, string> = { '已通过': COLORS.green, '审批中': COLORS.yellow, '待提交': COLORS.red };

  return (
    <div className="flex flex-col gap-5">
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">库存总件数</span>
            <div className="text-data-md font-mono text-text-primary">{Math.round(totalClothing / 150)}件</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">库存金额</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.purple }}>{Math.round(totalClothing / 100)}万</div>
          </div>
        </div>
        <h4 className="text-h4 text-text-primary mb-2">被装分类占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{ animationDuration: 600, tooltip: { trigger: 'item', backgroundColor: '#0a0e1a', borderColor: '#2a3a5c', textStyle: { color: '#d8dce6' }, formatter: (p: Record<string, unknown>) => `${p.name}: ${p.value}万 (${p.percent}%)` },
              series: [{ type: 'pie', radius: ['45%', '68%'], center: ['35%', '50%'], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }, label: { show: false }, emphasis: { scaleSize: 6 },
                data: clothingCategories.map((d) => ({ name: d.name, value: d.value, itemStyle: { color: d.color } })),
              }],
              legend: { orient: 'vertical', right: '2%', top: 'center', textStyle: { color: COLORS.textSecondary, fontSize: 11 }, itemWidth: 10, itemHeight: 10, itemGap: 10 },
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">被装库存库龄结构</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{ animationDuration: 600, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: '#0a0e1a', borderColor: '#2a3a5c', textStyle: { color: '#d8dce6' } },
              legend: { data: ['1年内', '1-2年', '2-3年', '呆滞'], textStyle: { color: COLORS.textSecondary, fontSize: 11 }, right: 0, top: 0, itemWidth: 10, itemHeight: 6 },
              grid: { left: 10, right: 10, top: 28, bottom: 24, containLabel: true },
              xAxis: { type: 'category', data: ageCategories, axisLine: { lineStyle: { color: COLORS.borderDim } }, axisLabel: { color: COLORS.textSecondary, fontSize: 11 }, axisTick: { show: false } },
              yAxis: { type: 'value', axisLine: { show: false }, axisTick: { show: false }, splitLine: { lineStyle: { color: COLORS.borderDim, type: 'dashed' } }, axisLabel: { color: COLORS.textTertiary, fontSize: 11 } },
              series: [
                { name: '1年内', type: 'bar', stack: 'total', barWidth: 24, itemStyle: { color: COLORS.green }, data: ageNew },
                { name: '1-2年', type: 'bar', stack: 'total', itemStyle: { color: COLORS.cyan }, data: ageMid },
                { name: '2-3年', type: 'bar', stack: 'total', itemStyle: { color: COLORS.yellow }, data: ageOld },
                { name: '呆滞', type: 'bar', stack: 'total', itemStyle: { color: COLORS.red, borderRadius: [3, 3, 0, 0] }, data: ageStale },
              ],
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {staleItems.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3, delay: 0.2 }}
          className="rounded-md border-l-[3px] p-3 flex items-start gap-2" style={{ backgroundColor: 'rgba(255,71,87,0.08)', borderColor: COLORS.red }}>
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: COLORS.red }} />
          <span className="text-body" style={{ color: COLORS.red }}>发现 {staleItems.length * 5} 件呆滞被装物资（超2年未领用），建议尽快处置</span>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.25, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">呆滞库存预警</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">资产名称</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">类型</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">提交日期</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">原因</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">审批状态</th>
              </tr>
            </thead>
            <tbody>
              {staleItems.map((item, i) => (
                <motion.tr key={item.assetName + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-primary">{item.assetName}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.assetType}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.reason}</td>
                  <td className="px-2 py-2"><span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: `${actionColors[item.approvalStatus]}22`, color: actionColors[item.approvalStatus] }}>{item.approvalStatus}</span></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 4 — 办公设备 (Office Devices)  + 新增指标
// ═══════════════════════════════════════════════════════════════

export function OfficeTab({ data }: { data: AssetData; unitName: string }) {
  const totalOffice = data.assetCategories.officeDevices;
  const deviceTypes = data.officeDeviceTypes;

  // 发放计划完成率 — 防御性默认值
  const plan = data.officeDeviceDistributionPlan ?? { planned: 100, actual: 90 };
  const completionRate = plan.planned > 0 ? Math.round((plan.actual / plan.planned) * 100) : 0;


  // 设备类型饼图
  const deviceColors = [COLORS.blue, COLORS.cyan, COLORS.green, COLORS.yellow, COLORS.purple];

  // 设备清单表
  const deviceList = [
    { name: '台式电脑', count: Math.round(totalOffice * 0.33 / 5), value: Math.round(totalOffice * 0.33) },
    { name: '笔记本电脑', count: Math.round(totalOffice * 0.12 / 8), value: Math.round(totalOffice * 0.12) },
    { name: '打印机', count: Math.round(totalOffice * 0.09 / 8), value: Math.round(totalOffice * 0.09) },
    { name: '投影仪', count: Math.round(totalOffice * 0.09 / 20), value: Math.round(totalOffice * 0.09) },
    { name: '服务器', count: Math.round(totalOffice * 0.26 / 60), value: Math.round(totalOffice * 0.26) },
    { name: '其他设备', count: 12, value: Math.round(totalOffice * 0.11) },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* 库存设备总数量/总价值 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">库存设备总数量</span>
            <div className="text-data-md font-mono text-text-primary">{deviceTypes.reduce((s, d) => s + d.count, 0)}台</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">库存设备总价值</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.orange }}>{Math.round(totalOffice / 100)}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">发放完成率</span>
            <div className="text-data-md font-mono" style={{ color: completionRate >= 90 ? COLORS.green : COLORS.yellow }}>{completionRate}%</div>
            <span className="text-[10px] text-text-tertiary">计划{plan.planned} / 实际{plan.actual}</span>
          </div>
        </div>
      </motion.div>

      {/* 设备分类价值占比 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">设备分类价值占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{ animationDuration: 600, tooltip: { trigger: 'item', backgroundColor: '#0a0e1a', borderColor: '#2a3a5c', textStyle: { color: '#d8dce6' }, formatter: (p: Record<string, unknown>) => `${p.name}: ${p.value}万 (${p.percent}%)` },
              series: [{ type: 'pie', radius: ['45%', '68%'], center: ['35%', '50%'], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }, label: { show: false }, emphasis: { scaleSize: 6 },
                data: deviceTypes.map((d, i) => ({ name: d.type, value: Math.round(d.value / 100), itemStyle: { color: deviceColors[i % deviceColors.length] } })),
              }],
              legend: { orient: 'vertical', right: '2%', top: 'center', textStyle: { color: COLORS.textSecondary, fontSize: 11 }, itemWidth: 10, itemHeight: 10, itemGap: 10 },
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* 设备分类数量/价值明细表 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">设备库存明细</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-3 py-2">设备类型</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">数量</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">价值</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">占比</th>
            </tr></thead>
            <tbody>
              {deviceTypes.map((item, i) => (
                <motion.tr key={item.type} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-3 py-2 text-text-primary">{item.type}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.count}台</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{Math.round(item.value / 100)}万</td>
                  <td className="px-2 py-2 font-mono" style={{ color: COLORS.orange }}>{(item.value / totalOffice * 100).toFixed(1)}%</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* 发放计划完成率仪表盘 */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15, ease: springEase }} className="flex items-center gap-4">
        <div className="w-[140px] h-[140px]">
          <ReactEChartsCore
            echarts={echarts}
            option={{
              animationDuration: 800, animationEasing: 'cubicOut' as const,
              series: [{ type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100, radius: '85%', center: ['50%', '55%'], splitNumber: 10,
                axisLine: { lineStyle: { width: 10, color: [[0.7, COLORS.red], [0.9, COLORS.yellow], [1, COLORS.green]] } },
                pointer: { itemStyle: { color: completionRate >= 90 ? COLORS.green : COLORS.yellow }, width: 4, length: '60%' },
                axisTick: { show: false }, splitLine: { length: 8, lineStyle: { color: COLORS.borderDim, width: 1 } },
                axisLabel: { color: COLORS.textTertiary, fontSize: 10, distance: 14 },
                detail: { valueAnimation: true, fontSize: 24, fontWeight: 600, fontFamily: 'JetBrains Mono', color: completionRate >= 90 ? COLORS.green : COLORS.yellow, offsetCenter: [0, '55%'], formatter: '{value}%' },
                data: [{ value: completionRate }],
              }],
            }}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
        <div className="flex flex-col gap-1">
          <span className="text-body text-text-secondary">发放计划完成率</span>
          <span className="text-data-md font-mono" style={{ color: completionRate >= 90 ? COLORS.green : COLORS.yellow }}>{completionRate}%</span>
          <span className="text-small text-text-tertiary">计划发放: {plan.planned}台</span>
          <span className="text-small text-text-tertiary">实际发放: {plan.actual}台</span>
        </div>
      </motion.div>

    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 5 — 车辆与移动资产 (Vehicles & Mobile Assets)
// ═══════════════════════════════════════════════════════════════

const VEHICLE_TYPES = [
  { name: '警车', count: 32, value: 640, status: '正常' as const, gps: true, mileage: 125000 },
  { name: '囚车', count: 6, value: 360, status: '正常' as const, gps: true, mileage: 48000 },
  { name: '摩托车', count: 18, value: 108, status: '正常' as const, gps: false, mileage: 22000 },
  { name: '运兵车', count: 4, value: 280, status: '维修' as const, gps: true, mileage: 186000 },
  { name: '救护车', count: 2, value: 120, status: '正常' as const, gps: true, mileage: 65000 },
  { name: '无人机', count: 12, value: 180, status: '正常' as const, gps: false, mileage: 0 },
];

// VehicleTab is inlined in AssetPanorama.tsx

// ═══════════════════════════════════════════════════════════════
// Tab 6 — 资产处置 (Disposal) — 采购/处置/报废/转让/供应商/使用时长
// ═══════════════════════════════════════════════════════════════

export function DisposalTab({ data }: { data: AssetData; unitName: string }) {
  const totalDisposal = data.disposalRecords.reduce((s, r) => s + r.amount, 0);
  const totalScrap = data.scrapRecords.length;
  const totalTransfer = data.transferRecords.length;

  const methodColors: Record<string, string> = { '报废': COLORS.red, '转让': COLORS.blue, '捐赠': COLORS.cyan, '调拨': COLORS.yellow };
  const statusColors: Record<string, string> = { '已通过': COLORS.green, '审批中': COLORS.yellow, '待提交': COLORS.red };

  return (
    <div className="flex flex-col gap-5">
      {/* Summary cards */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, ease: springEase }}>
        <div className="flex gap-3 mb-3">
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">本年处置金额</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.yellow }}>{totalDisposal}万</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">报废申请</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.red }}>{totalScrap}项</div>
          </div>
          <div className="flex-1 rounded-lg border p-3" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
            <span className="text-small text-text-secondary">资产调拨</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.blue }}>{totalTransfer}项</div>
          </div>
        </div>
      </motion.div>

      {/* Disposal records */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">处置记录</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">日期</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">资产名称</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">处置方式</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">金额</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">原因</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
            </tr></thead>
            <tbody>
              {data.disposalRecords.map((item, i) => (
                <motion.tr key={item.assetName + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.15 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 text-text-primary">{item.assetName}</td>
                  <td className="px-2 py-2"><span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: `${methodColors[item.method]}22`, color: methodColors[item.method] }}>{item.method}</span></td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.amount}万</td>
                  <td className="px-2 py-2 text-text-secondary">{item.reason}</td>
                  <td className="px-2 py-2"><span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: item.status === '已完成' ? 'rgba(0,245,160,0.15)' : 'rgba(255,209,102,0.15)', color: item.status === '已完成' ? '#00f5a0' : '#ffd166' }}>{item.status}</span></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Transfer records */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">调拨记录</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">日期</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">资产名称</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">转出单位</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">转入单位</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">金额</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
            </tr></thead>
            <tbody>
              {data.transferRecords.map((item, i) => (
                <motion.tr key={item.assetName + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.2 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 text-text-primary">{item.assetName}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.fromUnit}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.toUnit}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.amount}万</td>
                  <td className="px-2 py-2"><span className="text-small font-medium px-1.5 py-0.5 rounded-sm" style={{ backgroundColor: item.status === '已完成' ? 'rgba(0,245,160,0.15)' : 'rgba(255,209,102,0.15)', color: item.status === '已完成' ? '#00f5a0' : '#ffd166' }}>{item.status}</span></td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Supplier records */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">供应商信息</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">供应商名称</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">类别</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">采购金额</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">订单数</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">评级</th>
            </tr></thead>
            <tbody>
              {data.supplierRecords.map((item, i) => (
                <motion.tr key={item.name + i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.25 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.category}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.totalAmount}万</td>
                  <td className="px-2 py-2 text-text-secondary font-mono">{item.orderCount}笔</td>
                  <td className="px-2 py-2">
                    <div className="flex items-center gap-0.5">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <span key={j} className="text-[10px]" style={{ color: j < item.rating ? '#ffd166' : '#1e2a45' }}>★</span>
                      ))}
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Usage hours */}
      <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.25, ease: springEase }}>
        <h4 className="text-h4 text-text-primary mb-2">资产使用时长统计</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead><tr style={{ backgroundColor: '#101628' }}>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">资产类型</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">累计使用时长(h)</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">日均使用(h)</th>
              <th className="text-left text-text-secondary font-semibold px-2 py-2">使用率</th>
            </tr></thead>
            <tbody>
              {data.usageHours.map((item, i) => (
                <motion.tr key={item.assetType} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.3 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors" style={{ borderColor: '#1e2a45' }}>
                  <td className="px-2 py-2 text-text-primary">{item.assetType}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.totalHours}</td>
                  <td className="px-2 py-2 text-text-secondary font-mono">{item.dailyAverage}</td>
                  <td className="px-2 py-2">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: '#1e2a45' }}>
                        <div className="h-full rounded-full" style={{ width: `${item.utilizationRate}%`, backgroundColor: item.utilizationRate >= 80 ? '#00f5a0' : item.utilizationRate >= 50 ? '#ffd166' : '#ff4757' }} />
                      </div>
                      <span className="font-mono" style={{ color: item.utilizationRate >= 80 ? '#00f5a0' : item.utilizationRate >= 50 ? '#ffd166' : '#ff4757' }}>{item.utilizationRate}%</span>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
