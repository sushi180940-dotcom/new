import { useState, useEffect, memo, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Search, BarChart3 } from 'lucide-react';
import BreadcrumbNav from './BreadcrumbNav';
import GlobalSearch from './GlobalSearch';
import { useLocation } from 'react-router';
import { assetData, units } from '@/data/mockData';

interface NavbarProps {
  className?: string;
}

const panoramaLabels: Record<string, string> = {
  'economic': '经济运行全景',
  'financial': '财务全景',
  'asset': '资产全景',
  'personnel': '人员全景',
};

// ── Warning severity colors ──
const WARNING_TYPE_STYLES: Record<string, { label: string; color: string }> = {
  '异常': { label: '【异常】', color: '#f97316' },
  '缺储': { label: '【缺储】', color: '#ff4757' },
  '超期': { label: '【超期】', color: '#ffd166' },
  '低利用率': { label: '【低利用率】', color: '#6b7fa3' },
};

// ── Generate warning data from assetData ──
function generateWarnings() {
  const items: { type: string; unitName: string; message: string; time: string }[] = [];
  const timeLabels = ['2分钟前', '5分钟前', '8分钟前', '12分钟前', '15分钟前', '20分钟前'];
  let tIdx = 0;

  Object.entries(assetData).forEach(([unitId, data]) => {
    const unit = units.find((u) => u.id === unitId);
    if (!unit) return;

    const sh = data.emergencySupplyTypes.filter((s) => s.status === 'critical' || s.status === 'warning');
    if (sh.length > 0) {
      items.push({
        type: '缺储',
        unitName: unit.name,
        message: `${sh[0].type}库存不足`,
        time: timeLabels[tIdx++ % timeLabels.length],
      });
    }
    if (data.utilizationRate < 75) {
      items.push({
        type: '低利用率',
        unitName: unit.name,
        message: `资产利用率连续低于阈值`,
        time: timeLabels[tIdx++ % timeLabels.length],
      });
    }
  });

  // Add vehicle and equipment warnings
  items.push({ type: '异常', unitName: '总队B', message: '车辆使用率连续7日低于阈值', time: '5分钟前' });
  items.push({ type: '超期', unitName: '支队B', message: '通信设备即将过保（余15天）', time: '8分钟前' });
  items.push({ type: '缺储', unitName: '总队A', message: '急救包库存低于安全线30%', time: '2分钟前' });

  return items.slice(0, 8);
}

// ── Format current date time ──
function formatDateTime() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const h = String(now.getHours()).padStart(2, '0');
  const min = String(now.getMinutes()).padStart(2, '0');
  return `${y}-${m}-${d} ${h}:${min}`;
}

const Navbar = memo(function Navbar({ className = '' }: NavbarProps) {
  const [showSearch, setShowSearch] = useState(false);
  const [currentTime, setCurrentTime] = useState(formatDateTime());
  const location = useLocation();

  // Update time every minute
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(formatDateTime()), 60000);
    return () => clearInterval(timer);
  }, []);

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowSearch(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Build breadcrumb segments
  const buildBreadcrumb = useCallback(() => {
    const segments = [{ label: '全厅', path: '/' }];
    if (location.pathname.startsWith('/panorama/')) {
      const panoramaKey = location.pathname.split('/')[2];
      const label = panoramaLabels[panoramaKey] || '全景';
      segments.push({ label, path: location.pathname });
    }
    return segments;
  }, [location.pathname]);

  const breadcrumbSegments = buildBreadcrumb();
  const isAssetPage = location.pathname === '/panorama/asset';

  // Warning data
  const warnings = useMemo(() => generateWarnings(), []);

  // Build marquee text
  const marqueeText = useMemo(() => {
    return warnings.map((w) => {
      const style = WARNING_TYPE_STYLES[w.type] || WARNING_TYPE_STYLES['异常'];
      return `${style.label}${w.unitName} ${w.message} — ${w.time}`;
    }).join('    ');
  }, [warnings]);

  return (
    <>
      {/* ═══════════════════════════════════════════ */}
      {/* Fixed top container: nav + marquee        */}
      {/* ═══════════════════════════════════════════ */}
      <motion.div
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6, delay: 0.2, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
        className={`fixed top-0 left-0 right-0 z-50 ${className}`}
      >
        {/* ── Row 1: Main Navigation (48px) ── */}
        <div
          className="h-[48px] flex items-center justify-between px-5 border-b"
          style={{
            backgroundColor: 'rgba(5, 8, 16, 0.95)',
            backdropFilter: 'blur(16px)',
            WebkitBackdropFilter: 'blur(16px)',
            borderColor: '#1e2a45',
          }}
        >
          {/* Left: Logo + Breadcrumb */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              {/* Blue square icon */}
              <div
                className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: 'linear-gradient(135deg, #2151f5, #3b6ef5)' }}
              >
                <BarChart3 className="w-4 h-4 text-white" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-[13px] text-text-primary font-semibold tracking-tight">
                  警保数据资源中心
                </span>
                <div className="hidden md:block mt-0.5">
                  <BreadcrumbNav segments={breadcrumbSegments} />
                </div>
              </div>
            </div>
          </div>

          {/* Center: Search Bar */}
          <div className="hidden lg:flex flex-1 items-center justify-center mx-6" style={{ maxWidth: 420 }}>
            <button
              onClick={() => setShowSearch(true)}
              className="w-full flex items-center gap-3 px-4 py-1.5 rounded-lg border transition-all duration-200"
              style={{
                backgroundColor: '#0a0e1a',
                borderColor: '#1e2a45',
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = '#2a3a5c'; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = '#1e2a45'; }}
            >
              <Search className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#3d4f70' }} />
              <span className="flex-1 text-left text-[12px]" style={{ color: '#3d4f70' }}>
                搜索单位名称、指标、项目...
              </span>
              <span
                className="text-[10px] px-1.5 py-0.5 rounded flex-shrink-0 font-mono"
                style={{ color: '#3d4f70', backgroundColor: '#101628' }}
              >
                ⌘K
              </span>
            </button>
          </div>

          {/* Right: Data status + Time + Avatar */}
          <div className="flex items-center gap-4">
            {/* Live status */}
            <div className="hidden md:flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ backgroundColor: '#00f5a0' }} />
                <span className="relative inline-flex rounded-full h-2 w-2" style={{ backgroundColor: '#00f5a0' }} />
              </span>
              <span className="text-[11px]" style={{ color: '#6b7fa3' }}>数据实时</span>
              <span className="text-[11px] font-mono" style={{ color: '#3d4f70' }}>{currentTime}</span>
            </div>

            {/* Avatar */}
            <div
              className="w-7 h-7 rounded-full flex items-center justify-center cursor-pointer flex-shrink-0"
              style={{ background: 'linear-gradient(135deg, #a855f7, #7c3aed)' }}
            >
              <span className="text-[11px] font-semibold text-white">管</span>
            </div>
          </div>
        </div>

        {/* ── Row 2: Warning Marquee (26px) ── */}
        <div
          className="h-[26px] flex items-center overflow-hidden"
          style={{
            backgroundColor: 'rgba(255,71,87,0.06)',
            borderBottom: '1px solid rgba(255,71,87,0.15)',
          }}
        >
          {/* Fixed label */}
          <div
            className="flex items-center gap-1.5 px-3 h-full flex-shrink-0 z-10"
            style={{ backgroundColor: 'rgba(255,71,87,0.06)' }}
          >
            <span className="relative flex h-1.5 w-1.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ backgroundColor: '#ff4757' }} />
              <span className="relative inline-flex rounded-full h-1.5 w-1.5" style={{ backgroundColor: '#ff4757' }} />
            </span>
            <span className="text-[11px] font-bold" style={{ color: '#ff4757' }}>实时预警</span>
          </div>

          {/* Scrolling content — starts from right edge of fixed label */}
          <div className="flex-1 overflow-hidden relative h-full pl-2">
            <motion.div
              className="whitespace-nowrap h-full flex items-center"
              initial={{ x: '0%' }}
              animate={{ x: '-50%' }}
              transition={{ duration: 40, repeat: Infinity, ease: 'linear' }}
            >
              <span className="text-[11px] inline-block pr-16" style={{ color: 'rgba(255,71,87,0.65)' }}>
                {marqueeText}
              </span>
              <span className="text-[11px] inline-block pr-16" style={{ color: 'rgba(255,71,87,0.65)' }}>
                {marqueeText}
              </span>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Global Search Modal */}
      <GlobalSearch isOpen={showSearch} onClose={() => setShowSearch(false)} />
    </>
  );
});

export default Navbar;
