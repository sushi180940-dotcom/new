import { memo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, BarChart3, Map, Users } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router';
import type { LucideIcon } from 'lucide-react';

interface DockItem {
  path: string;
  label: string;
  icon: LucideIcon;
}

const dockItems: DockItem[] = [
  { path: '/panorama/economic', label: '经济运行', icon: TrendingUp },
  { path: '/panorama/financial', label: '财务全景', icon: BarChart3 },
  { path: '/panorama/asset', label: '资产全景', icon: Map },
  { path: '/panorama/personnel', label: '人员全景', icon: Users },
];

const PanoramaDock = memo(function PanoramaDock() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleNav = useCallback((path: string) => {
    navigate(path);
  }, [navigate]);

  return (
    <motion.nav
      initial={{ y: 40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{
        duration: 0.5,
        delay: 0.8,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      }}
      className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 flex items-center gap-0.5 px-1 py-1 rounded-full"
      style={{
        backgroundColor: 'rgba(5, 8, 16, 0.9)',
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        border: '1px solid #1e2a45',
        boxShadow: '0 4px 24px rgba(0,0,0,0.4)',
      }}
    >
      {dockItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;

        return (
          <button
            key={item.path}
            onClick={() => handleNav(item.path)}
            className={`relative flex items-center gap-1.5 px-4 py-1.5 rounded-full text-[11px] transition-all duration-300 ${
              isActive
                ? 'text-white'
                : 'text-text-secondary hover:text-text-primary hover:bg-surface/50'
            }`}
            style={isActive ? {
              backgroundColor: 'rgba(33,81,245,0.15)',
            } : {}}
          >
            {/* Cyan gradient top edge for active */}
            {isActive && (
              <motion.div
                layoutId="dock-active-indicator"
                className="absolute top-0 left-2 right-2 h-[2px] rounded-full"
                style={{
                  background: 'linear-gradient(90deg, #00e5ff, #2151f5)',
                  boxShadow: '0 0 8px rgba(0,229,255,0.6)',
                }}
                transition={{
                  type: 'spring',
                  stiffness: 400,
                  damping: 30,
                }}
              />
            )}
            <Icon className="w-3.5 h-3.5 relative z-10" />
            <span className="relative z-10 font-medium whitespace-nowrap">{item.label}</span>
          </button>
        );
      })}
    </motion.nav>
  );
});

export default PanoramaDock;
