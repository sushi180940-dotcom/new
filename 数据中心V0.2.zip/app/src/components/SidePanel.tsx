import { useEffect, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import StatusDot from './StatusDot';
import type { Unit } from '@/data/mockData';
import type { LucideIcon } from 'lucide-react';

interface Tab {
  id: string;
  label: string;
  icon?: LucideIcon;
  content: React.ReactNode;
}

interface SidePanelProps {
  isOpen: boolean;
  unit: Unit | null;
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  onClose: () => void;
  className?: string;
}

const SidePanel = memo(function SidePanel({
  isOpen,
  unit,
  tabs,
  activeTab,
  onTabChange,
  onClose,
  className = '',
}: SidePanelProps) {
  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const activeTabContent = tabs.find(t => t.id === activeTab)?.content;

  return (
    <AnimatePresence>
      {isOpen && unit && (
        <>
          {/* Backdrop overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-30"
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            initial={{ x: 520 }}
            animate={{ x: 0 }}
            exit={{ x: 520 }}
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 30,
            }}
            className={`fixed right-0 top-[56px] bottom-0 w-[520px] z-40 overflow-hidden ${className}`}
            style={{
              background: '#0a0e1a',
              backgroundImage: 'linear-gradient(90deg, rgba(33,81,245,0.06) 0%, transparent 8%)',
              borderLeft: '1px solid #1e2a45',
              boxShadow: '-12px 0 48px rgba(0,0,0,0.4)',
            }}
          >
            {/* Header */}
            <div className="px-6 pt-6 pb-4">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-3">
                    <h2 className="text-h2 text-text-primary">{unit.name}</h2>
                    <StatusDot status={unit.status} size="md" />
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <span
                      className="px-2 py-0.5 rounded-sm text-small font-medium"
                      style={{
                        backgroundColor: 'rgba(33,81,245,0.15)',
                        color: '#4f8af7',
                      }}
                    >
                      {unit.type}
                    </span>
                    <span className="text-small text-text-secondary">{unit.region}</span>
                    {unit.description && (
                      <>
                        <span className="text-text-tertiary">·</span>
                        <span className="text-small text-text-secondary">{unit.description}</span>
                      </>
                    )}
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-md hover:bg-surface transition-colors text-text-secondary hover:text-text-primary"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Tabs */}
              {tabs.length > 1 && (
                <div className="flex gap-1 border-b border-border-dim mt-4 overflow-x-auto scrollbar-hide">
                  {tabs.map((tab) => {
                    const isActive = tab.id === activeTab;
                    return (
                      <button
                        key={tab.id}
                        onClick={() => onTabChange(tab.id)}
                        className={`relative px-3 py-2 text-[12px] font-medium transition-colors border-b-2 flex-shrink-0 whitespace-nowrap ${
                          isActive
                            ? 'text-[#4f8af7] border-[#2151f5]'
                            : 'text-text-secondary border-transparent hover:text-text-primary'
                        }`}
                      >
                        <span className="flex items-center gap-1">
                          {tab.icon && <tab.icon className="w-3.5 h-3.5" />}
                          {tab.label}
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Tab Content */}
            <div className="px-6 pb-24 overflow-y-auto" style={{ height: 'calc(100% - 140px)' }}>
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.2 }}
                >
                  {activeTabContent}
                </motion.div>
              </AnimatePresence>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
});

export default SidePanel;
