// ============================================================
// Provincial Department Financial Intelligence Command Center
// Mock Data Layer — Comprehensive TypeScript Types & Mock Data
// ============================================================

// --- Status & Types ---
export type UnitType = '总队' | '支队' | '大队';
export type UnitStatus = 'normal' | 'warning' | 'critical';
export type RegionName = '省会市' | '东江市' | '西湖市' | '南山市' | '北原市' | '中卫市';

// --- Core Unit Interface ---
export interface Unit {
  id: string;
  name: string;
  type: UnitType;
  region: RegionName;
  x: number;
  y: number;
  status: UnitStatus;
  description?: string;
}

// --- Economic Data (经济运行全景) ---
export interface EconomicData {
  unitId: string;
  // Budget execution
  budgetExecutionRate: number; // 0-100
  budgetAmount: number; // in 万元
  actualExpenditure: number; // in 万元
  budgetYear: number;
  // Personnel
  personnelCount: number;
  authorizedPositions: number;
  // Projects
  keyProjects: number;
  completedProjects: number;
  delayedProjects: number;
  // Three public funds (三公经费)
  threePublicFunds: number; // in 万元
  threePublicFundsBudget: number;
  threePublicFundsRate: number; // execution rate 0-100
  // Trends (monthly for sparklines)
  monthlyExpenditure: number[]; // 12 months
  monthlyBudgetExecution: number[]; // 12 months
  // Comparison
  lastYearSamePeriod: number; // actual expenditure last year
  yearOverYearChange: number; // percentage change
}

// --- Financial Data (财务全景) ---
export interface FinancialData {
  unitId: string;
  // Debt ratios
  debtToAssetRatio: number; // 0-100
  liabilityTotal: number; // in 万元
  assetTotal: number; // in 万元
  // Liquidity
  currentRatio: number;
  quickRatio: number;
  currentAssets: number;
  currentLiabilities: number;
  // Revenue/expense
  revenueTotal: number;
  expenseTotal: number;
  revenueExpenseRatio: number;
  // Cash flow
  operatingCashFlow: number;
  financingCashFlow: number;
  investingCashFlow: number;
  // YoY change
  debtToAssetChange: number;
  currentRatioChange: number;
  revenueExpenseChange: number;
}

// --- Asset Data (资产全景) ---
export interface AssetData {
  unitId: string;
  totalAssetValue: number; // in 万元
  assetCategories: {
    equipment: number; // 装备
    emergencySupplies: number; // 应急物资
    clothingSupplies: number; // 被装物资
    officeDevices: number; // 办公设备
    vehicles: number; // 车辆
    realEstate: number; // 房产
    other: number;
  };
  // Equipment detail
  equipmentTypes: {
    type: string;
    count: number;
    value: number;
  }[];
  // Emergency supplies
  emergencySupplyTypes: {
    type: string;
    required: number;
    actual: number;
    status: 'normal' | 'warning' | 'critical';
  }[];
  // Office devices
  officeDeviceTypes: {
    type: string;
    count: number;
    value: number;
  }[];
  // Asset utilization rate
  utilizationRate: number;
  // Year-over-year
  assetValueChange: number;
  // ── Asset lifecycle: disposal records ──
  disposalRecords: {
    date: string;
    assetName: string;
    method: '报废' | '转让' | '捐赠' | '调拨';
    amount: number;
    reason: string;
    status: '已完成' | '审批中';
  }[];
  // ── Asset lifecycle: scrap records ──
  scrapRecords: {
    date: string;
    assetName: string;
    assetType: string;
    reason: string;
    approvalStatus: '已通过' | '审批中' | '待提交';
  }[];
  // ── Asset lifecycle: transfer records ──
  transferRecords: {
    date: string;
    assetName: string;
    fromUnit: string;
    toUnit: string;
    amount: number;
    status: '已完成' | '审批中';
  }[];
  // ── Supplier dimension ──
  supplierRecords: {
    name: string;
    category: string;
    totalAmount: number;
    orderCount: number;
    rating: number;
  }[];
  // ── Usage hours dimension ──
  usageHours: {
    assetType: string;
    totalHours: number;
    dailyAverage: number;
    utilizationRate: number;
  }[];
  // ── Emergency supply: category coverage rate ──
  emergencyCategoryCoverageRate: number;
  // ── Emergency supply: quantity by category ──
  emergencyQuantityByCategory: {
    type: string;
    quantity: number;
  }[];
  // ── Emergency supply: warehouse distribution ──
  emergencyWarehouses: {
    name: string;
    value: number;
  }[];
  // ── Emergency supply: agency storage ──
  emergencyAgencyStorage: {
    unitName: string;
    value: number;
  }[];
  // ── Emergency supply: regional coverage ──
  emergencyRegionalCoverage: number;
  // ── Office device: distribution plan ──
  officeDeviceDistributionPlan: {
    planned: number;
    actual: number;
  };
  // ── Office device: distribution by unit ──
  officeDeviceDistributionByUnit: {
    unitName: string;
    planned: number;
    actual: number;
  }[];
  // ── Monthly data for time dimension ──
  monthlyAssetData: {
    month: string;
    equipment: number;
    emergency: number;
    clothing: number;
    office: number;
    vehicles: number;
  }[];
}

// --- Personnel Data (人员结构与配置全景) ---
export interface PersonnelData {
  unitId: string;
  // Staffing
  totalPersonnel: number;
  authorizedPositions: number;
  staffingRate: number; // 0-100
  // Structure
  ageStructure: {
    under25: number;
    age26to35: number;
    age36to45: number;
    age46to55: number;
    over55: number;
  };
  // Education
  educationStructure: {
    doctor: number;
    master: number;
    bachelor: number;
    college: number;
    other: number;
  };
  // Position types
  positionTypes: {
    type: string;
    authorized: number;
    actual: number;
    vacancyRate: number;
  }[];
  // Key positions
  keyPositions: {
    title: string;
    holder: string | null;
    isVacant: boolean;
    vacancyDays?: number;
  }[];
  // Years of service
  avgYearsOfService: number;
  // YoY
  personnelChange: number;
}

// --- Warning / Alert Item ---
export interface WarningItem {
  id: string;
  unitId: string;
  unitName: string;
  type: 'budget' | 'asset' | 'financial' | 'personnel';
  severity: 'warning' | 'critical';
  message: string;
  timestamp: string;
  panorama: 'economic' | 'financial' | 'asset' | 'personnel';
}

// --- Panorama Overview Stats ---
export interface PanoramaOverview {
  economic: {
    totalBudget: number;
    totalExpenditure: number;
    avgExecutionRate: number;
    totalProjects: number;
    delayedProjects: number;
    trend: number[]; // 7-day sparkline
  };
  financial: {
    avgDebtToAsset: number;
    avgCurrentRatio: number;
    avgRevenueExpenseRatio: number;
    totalAssets: number;
    totalLiabilities: number;
    trend: number[]; // 7-day sparkline
  };
  asset: {
    totalAssetValue: number;
    totalEquipmentCount: number;
    avgUtilizationRate: number;
    supplyShortageUnits: number;
    trend: number[]; // 7-day sparkline
  };
  personnel: {
    totalPersonnel: number;
    totalAuthorized: number;
    overallStaffingRate: number;
    vacantPositions: number;
    trend: number[]; // 7-day sparkline
  };
}

// ============================================================
// Mock Units — 12 units with complete data
// ============================================================

export const units: Unit[] = [
  { id: 'A', name: '总队A', type: '总队', region: '省会市', x: 50, y: 50, status: 'normal', description: '省厅直属总队，负责全省综合业务' },
  { id: 'B', name: '总队B', type: '总队', region: '省会市', x: 45, y: 45, status: 'normal', description: '省厅直属总队，负责全省专项业务' },
  { id: 'C', name: '支队A', type: '支队', region: '东江市', x: 75, y: 40, status: 'warning', description: '东江市公安局支队' },
  { id: 'D', name: '支队B', type: '支队', region: '西湖市', x: 20, y: 55, status: 'normal', description: '西湖市公安局支队' },
  { id: 'E', name: '支队C', type: '支队', region: '南山市', x: 60, y: 80, status: 'critical', description: '南山市公安局支队' },
  { id: 'F', name: '支队D', type: '支队', region: '北原市', x: 30, y: 20, status: 'normal', description: '北原市公安局支队' },
  { id: 'G', name: '支队E', type: '支队', region: '中卫市', x: 50, y: 30, status: 'warning', description: '中卫市公安局支队' },
  { id: 'H', name: '大队A', type: '大队', region: '东江市', x: 78, y: 35, status: 'normal', description: '东江市大队' },
  { id: 'I', name: '大队B', type: '大队', region: '西湖市', x: 22, y: 60, status: 'normal', description: '西湖市大队' },
  { id: 'J', name: '大队C', type: '大队', region: '南山市', x: 65, y: 75, status: 'warning', description: '南山市大队' },
  { id: 'K', name: '大队D', type: '大队', region: '北原市', x: 25, y: 25, status: 'normal', description: '北原市大队' },
  { id: 'L', name: '大队E', type: '大队', region: '省会市', x: 55, y: 55, status: 'normal', description: '省会市直属大队' },
];

// ============================================================
// Economic Data (经济运行全景)
// ============================================================

export const economicData: Record<string, EconomicData> = {
  A: {
    unitId: 'A', budgetExecutionRate: 91.2, budgetAmount: 28500, actualExpenditure: 25992,
    budgetYear: 2025, personnelCount: 342, authorizedPositions: 350, keyProjects: 12,
    completedProjects: 8, delayedProjects: 1, threePublicFunds: 186, threePublicFundsBudget: 220,
    threePublicFundsRate: 84.5,
    monthlyExpenditure: [2100, 1980, 2250, 2100, 2300, 2450, 2200, 2350, 2180, 2280, 2320, 0],
    monthlyBudgetExecution: [7.4, 14.3, 22.2, 29.6, 37.7, 46.3, 54.0, 62.2, 69.9, 77.9, 86.0, 91.2],
    lastYearSamePeriod: 24100, yearOverYearChange: 7.8,
  },
  B: {
    unitId: 'B', budgetExecutionRate: 88.7, budgetAmount: 22400, actualExpenditure: 19869,
    budgetYear: 2025, personnelCount: 278, authorizedPositions: 280, keyProjects: 9,
    completedProjects: 6, delayedProjects: 1, threePublicFunds: 142, threePublicFundsBudget: 170,
    threePublicFundsRate: 83.5,
    monthlyExpenditure: [1650, 1580, 1780, 1650, 1820, 1950, 1720, 1880, 1700, 1780, 1820, 0],
    monthlyBudgetExecution: [7.4, 14.4, 22.3, 29.7, 37.8, 46.5, 54.2, 62.6, 70.2, 78.1, 86.3, 88.7],
    lastYearSamePeriod: 18500, yearOverYearChange: 7.4,
  },
  C: {
    unitId: 'C', budgetExecutionRate: 76.3, budgetAmount: 12800, actualExpenditure: 9766,
    budgetYear: 2025, personnelCount: 186, authorizedPositions: 195, keyProjects: 6,
    completedProjects: 3, delayedProjects: 2, threePublicFunds: 98, threePublicFundsBudget: 130,
    threePublicFundsRate: 75.4,
    monthlyExpenditure: [820, 780, 850, 800, 860, 920, 810, 870, 800, 836, 420, 0],
    monthlyBudgetExecution: [6.4, 12.5, 19.1, 25.4, 32.1, 39.3, 45.6, 52.4, 58.6, 65.1, 68.4, 76.3],
    lastYearSamePeriod: 9200, yearOverYearChange: 6.1,
  },
  D: {
    unitId: 'D', budgetExecutionRate: 93.5, budgetAmount: 11200, actualExpenditure: 10472,
    budgetYear: 2025, personnelCount: 168, authorizedPositions: 170, keyProjects: 5,
    completedProjects: 4, delayedProjects: 0, threePublicFunds: 72, threePublicFundsBudget: 85,
    threePublicFundsRate: 84.7,
    monthlyExpenditure: [860, 820, 900, 860, 920, 980, 880, 930, 860, 902, 460, 0],
    monthlyBudgetExecution: [7.7, 15.0, 23.0, 30.7, 38.9, 47.6, 55.4, 63.7, 71.4, 79.4, 83.5, 93.5],
    lastYearSamePeriod: 9800, yearOverYearChange: 6.9,
  },
  E: {
    unitId: 'E', budgetExecutionRate: 68.4, budgetAmount: 9600, actualExpenditure: 6566,
    budgetYear: 2025, personnelCount: 145, authorizedPositions: 160, keyProjects: 4,
    completedProjects: 1, delayedProjects: 2, threePublicFunds: 88, threePublicFundsBudget: 115,
    threePublicFundsRate: 76.5,
    monthlyExpenditure: [550, 520, 580, 540, 580, 620, 540, 600, 540, 496, 0, 0],
    monthlyBudgetExecution: [5.7, 11.1, 17.1, 22.7, 28.8, 35.2, 40.8, 47.1, 52.7, 57.9, 57.9, 68.4],
    lastYearSamePeriod: 7200, yearOverYearChange: -8.8,
  },
  F: {
    unitId: 'F', budgetExecutionRate: 89.1, budgetAmount: 8900, actualExpenditure: 7930,
    budgetYear: 2025, personnelCount: 134, authorizedPositions: 138, keyProjects: 4,
    completedProjects: 3, delayedProjects: 0, threePublicFunds: 56, threePublicFundsBudget: 68,
    threePublicFundsRate: 82.4,
    monthlyExpenditure: [660, 620, 690, 660, 700, 750, 670, 720, 660, 700, 0, 0],
    monthlyBudgetExecution: [7.4, 14.4, 22.1, 29.5, 37.4, 45.8, 53.3, 61.4, 68.8, 76.7, 76.7, 89.1],
    lastYearSamePeriod: 7100, yearOverYearChange: 11.7,
  },
  G: {
    unitId: 'G', budgetExecutionRate: 81.6, budgetAmount: 7600, actualExpenditure: 6202,
    budgetYear: 2025, personnelCount: 118, authorizedPositions: 125, keyProjects: 3,
    completedProjects: 2, delayedProjects: 1, threePublicFunds: 48, threePublicFundsBudget: 60,
    threePublicFundsRate: 80.0,
    monthlyExpenditure: [520, 490, 550, 520, 560, 590, 520, 572, 520, 0, 0, 0],
    monthlyBudgetExecution: [6.8, 13.3, 20.5, 27.3, 34.7, 42.5, 49.3, 56.8, 63.7, 63.7, 63.7, 81.6],
    lastYearSamePeriod: 5800, yearOverYearChange: 6.9,
  },
  H: {
    unitId: 'H', budgetExecutionRate: 85.2, budgetAmount: 5200, actualExpenditure: 4430,
    budgetYear: 2025, personnelCount: 82, authorizedPositions: 85, keyProjects: 2,
    completedProjects: 1, delayedProjects: 1, threePublicFunds: 32, threePublicFundsBudget: 40,
    threePublicFundsRate: 80.0,
    monthlyExpenditure: [370, 350, 390, 370, 400, 420, 380, 400, 350, 0, 0, 0],
    monthlyBudgetExecution: [7.1, 13.8, 21.3, 28.4, 36.1, 44.2, 51.5, 59.2, 65.9, 65.9, 65.9, 85.2],
    lastYearSamePeriod: 4100, yearOverYearChange: 8.0,
  },
  I: {
    unitId: 'I', budgetExecutionRate: 92.3, budgetAmount: 4800, actualExpenditure: 4430,
    budgetYear: 2025, personnelCount: 76, authorizedPositions: 78, keyProjects: 2,
    completedProjects: 2, delayedProjects: 0, threePublicFunds: 28, threePublicFundsBudget: 32,
    threePublicFundsRate: 87.5,
    monthlyExpenditure: [370, 350, 380, 370, 390, 420, 380, 400, 370, 0, 0, 0],
    monthlyBudgetExecution: [7.7, 15.0, 22.9, 30.6, 38.7, 47.5, 55.4, 63.7, 71.4, 71.4, 71.4, 92.3],
    lastYearSamePeriod: 3900, yearOverYearChange: 13.6,
  },
  J: {
    unitId: 'J', budgetExecutionRate: 74.8, budgetAmount: 4200, actualExpenditure: 3142,
    budgetYear: 2025, personnelCount: 68, authorizedPositions: 72, keyProjects: 2,
    completedProjects: 1, delayedProjects: 1, threePublicFunds: 30, threePublicFundsBudget: 38,
    threePublicFundsRate: 78.9,
    monthlyExpenditure: [262, 248, 276, 262, 280, 300, 264, 0, 0, 0, 0, 0],
    monthlyBudgetExecution: [6.2, 12.1, 18.7, 24.9, 31.6, 38.7, 45.0, 45.0, 45.0, 45.0, 45.0, 74.8],
    lastYearSamePeriod: 2900, yearOverYearChange: 8.3,
  },
  K: {
    unitId: 'K', budgetExecutionRate: 90.5, budgetAmount: 3800, actualExpenditure: 3439,
    budgetYear: 2025, personnelCount: 62, authorizedPositions: 65, keyProjects: 1,
    completedProjects: 1, delayedProjects: 0, threePublicFunds: 22, threePublicFundsBudget: 26,
    threePublicFundsRate: 84.6,
    monthlyExpenditure: [285, 270, 300, 285, 304, 325, 290, 0, 0, 0, 0, 0],
    monthlyBudgetExecution: [7.5, 14.6, 22.5, 30.0, 38.0, 46.6, 54.2, 54.2, 54.2, 54.2, 54.2, 90.5],
    lastYearSamePeriod: 3100, yearOverYearChange: 10.9,
  },
  L: {
    unitId: 'L', budgetExecutionRate: 86.7, budgetAmount: 6400, actualExpenditure: 5549,
    budgetYear: 2025, personnelCount: 98, authorizedPositions: 100, keyProjects: 3,
    completedProjects: 2, delayedProjects: 1, threePublicFunds: 38, threePublicFundsBudget: 45,
    threePublicFundsRate: 84.4,
    monthlyExpenditure: [462, 438, 486, 462, 494, 528, 470, 499, 0, 0, 0, 0],
    monthlyBudgetExecution: [7.2, 14.0, 21.6, 28.8, 36.6, 44.8, 52.2, 60.0, 60.0, 60.0, 60.0, 86.7],
    lastYearSamePeriod: 4900, yearOverYearChange: 13.2,
  },
};

// ============================================================
// Financial Data (财务全景)
// ============================================================

export const financialData: Record<string, FinancialData> = {
  A: {
    unitId: 'A', debtToAssetRatio: 32.4, liabilityTotal: 12400, assetTotal: 38272,
    currentRatio: 2.15, quickRatio: 1.82, currentAssets: 18600, currentLiabilities: 8650,
    revenueTotal: 22400, expenseTotal: 25992, revenueExpenseRatio: 86.2,
    operatingCashFlow: 8200, financingCashFlow: -1200, investingCashFlow: -2800,
    debtToAssetChange: -2.1, currentRatioChange: 0.15, revenueExpenseChange: 3.2,
  },
  B: {
    unitId: 'B', debtToAssetRatio: 38.6, liabilityTotal: 11200, assetTotal: 29016,
    currentRatio: 1.92, quickRatio: 1.55, currentAssets: 14800, currentLiabilities: 7700,
    revenueTotal: 18600, expenseTotal: 19869, revenueExpenseRatio: 93.6,
    operatingCashFlow: 6200, financingCashFlow: -800, investingCashFlow: -2200,
    debtToAssetChange: 1.2, currentRatioChange: -0.08, revenueExpenseChange: -1.5,
  },
  C: {
    unitId: 'C', debtToAssetRatio: 45.2, liabilityTotal: 7200, assetTotal: 15929,
    currentRatio: 1.45, quickRatio: 1.12, currentAssets: 7800, currentLiabilities: 5380,
    revenueTotal: 8800, expenseTotal: 9766, revenueExpenseRatio: 90.1,
    operatingCashFlow: 3200, financingCashFlow: -600, investingCashFlow: -1200,
    debtToAssetChange: 3.5, currentRatioChange: -0.22, revenueExpenseChange: 5.8,
  },
  D: {
    unitId: 'D', debtToAssetRatio: 28.8, liabilityTotal: 4800, assetTotal: 16667,
    currentRatio: 2.45, quickRatio: 2.1, currentAssets: 8600, currentLiabilities: 3510,
    revenueTotal: 10200, expenseTotal: 10472, revenueExpenseRatio: 97.4,
    operatingCashFlow: 4200, financingCashFlow: -400, investingCashFlow: -900,
    debtToAssetChange: -1.5, currentRatioChange: 0.2, revenueExpenseChange: 2.1,
  },
  E: {
    unitId: 'E', debtToAssetRatio: 52.8, liabilityTotal: 5800, assetTotal: 10985,
    currentRatio: 1.18, quickRatio: 0.92, currentAssets: 5200, currentLiabilities: 4408,
    revenueTotal: 6800, expenseTotal: 6566, revenueExpenseRatio: 103.6,
    operatingCashFlow: 1800, financingCashFlow: -500, investingCashFlow: -700,
    debtToAssetChange: 5.2, currentRatioChange: -0.35, revenueExpenseChange: 8.4,
  },
  F: {
    unitId: 'F', debtToAssetRatio: 35.2, liabilityTotal: 3800, assetTotal: 10795,
    currentRatio: 2.02, quickRatio: 1.68, currentAssets: 6200, currentLiabilities: 3069,
    revenueTotal: 8200, expenseTotal: 7930, revenueExpenseRatio: 103.4,
    operatingCashFlow: 3600, financingCashFlow: -300, investingCashFlow: -650,
    debtToAssetChange: -0.8, currentRatioChange: 0.1, revenueExpenseChange: 4.2,
  },
  G: {
    unitId: 'G', debtToAssetRatio: 41.6, liabilityTotal: 3400, assetTotal: 8173,
    currentRatio: 1.68, quickRatio: 1.35, currentAssets: 4800, currentLiabilities: 2857,
    revenueTotal: 6200, expenseTotal: 6202, revenueExpenseRatio: 100.0,
    operatingCashFlow: 2800, financingCashFlow: -250, investingCashFlow: -500,
    debtToAssetChange: 2.0, currentRatioChange: -0.12, revenueExpenseChange: 0.5,
  },
  H: {
    unitId: 'H', debtToAssetRatio: 36.4, liabilityTotal: 2000, assetTotal: 5495,
    currentRatio: 1.85, quickRatio: 1.52, currentAssets: 3200, currentLiabilities: 1730,
    revenueTotal: 4200, expenseTotal: 4430, revenueExpenseRatio: 94.8,
    operatingCashFlow: 1800, financingCashFlow: -150, investingCashFlow: -350,
    debtToAssetChange: -1.2, currentRatioChange: 0.08, revenueExpenseChange: -2.1,
  },
  I: {
    unitId: 'I', debtToAssetRatio: 30.2, liabilityTotal: 1600, assetTotal: 5298,
    currentRatio: 2.28, quickRatio: 1.95, currentAssets: 3100, currentLiabilities: 1360,
    revenueTotal: 4600, expenseTotal: 4430, revenueExpenseRatio: 103.8,
    operatingCashFlow: 2000, financingCashFlow: -120, investingCashFlow: -300,
    debtToAssetChange: -2.0, currentRatioChange: 0.18, revenueExpenseChange: 5.5,
  },
  J: {
    unitId: 'J', debtToAssetRatio: 48.6, liabilityTotal: 1800, assetTotal: 3704,
    currentRatio: 1.32, quickRatio: 1.02, currentAssets: 2200, currentLiabilities: 1667,
    revenueTotal: 3400, expenseTotal: 3142, revenueExpenseRatio: 108.2,
    operatingCashFlow: 1200, financingCashFlow: -180, investingCashFlow: -250,
    debtToAssetChange: 4.0, currentRatioChange: -0.28, revenueExpenseChange: 9.2,
  },
  K: {
    unitId: 'K', debtToAssetRatio: 33.8, liabilityTotal: 1400, assetTotal: 4142,
    currentRatio: 2.05, quickRatio: 1.72, currentAssets: 2000, currentLiabilities: 976,
    revenueTotal: 3600, expenseTotal: 3439, revenueExpenseRatio: 104.7,
    operatingCashFlow: 1400, financingCashFlow: -100, investingCashFlow: -200,
    debtToAssetChange: -0.5, currentRatioChange: 0.12, revenueExpenseChange: 3.8,
  },
  L: {
    unitId: 'L', debtToAssetRatio: 37.4, liabilityTotal: 2800, assetTotal: 7487,
    currentRatio: 1.78, quickRatio: 1.48, currentAssets: 4200, currentLiabilities: 2358,
    revenueTotal: 5600, expenseTotal: 5549, revenueExpenseRatio: 100.9,
    operatingCashFlow: 2400, financingCashFlow: -200, investingCashFlow: -450,
    debtToAssetChange: 1.5, currentRatioChange: -0.06, revenueExpenseChange: 1.8,
  },
};

// ============================================================
// Asset Data (资产全景)
// ============================================================

export const assetData: Record<string, AssetData> = {
  A: {
    unitId: 'A', totalAssetValue: 38272,
    assetCategories: { equipment: 7300, emergencySupplies: 4200, clothingSupplies: 5200, officeDevices: 5800, vehicles: 8900, realEstate: 5200, other: 1672 },
    equipmentOriginalValue: 16892,
    equipmentDepreciationRate: 26,
    equipmentTypes: [{ type: '执法记录仪', count: 680, value: 3400 }, { type: '对讲机', count: 420, value: 2100 }, { type: '无人机', count: 48, value: 2880 }, { type: '防护装备', count: 1200, value: 2400 }, { type: '检测设备', count: 72, value: 1720 }],
    emergencySupplyTypes: [{ type: '急救包', required: 500, actual: 480, status: 'warning' }, { type: '救生衣', required: 800, actual: 820, status: 'normal' }, { type: '应急照明', required: 300, actual: 290, status: 'normal' }, { type: '消防器材', required: 200, actual: 195, status: 'normal' }, { type: '通信设备', required: 100, actual: 85, status: 'warning' }, { type: '防暴器材', required: 150, actual: 148, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 380, value: 1900 }, { type: '笔记本电脑', count: 120, value: 960 }, { type: '打印机', count: 85, value: 680 }, { type: '投影仪', count: 35, value: 700 }, { type: '服务器', count: 24, value: 1520 }],
    utilizationRate: 88.5,
    assetValueChange: 5.2,
    disposalRecords: [
      { date: '2024-06-09', assetName: '服务器', method: '报废', amount: 33, reason: '达到使用年限，性能下降', status: '已完成' },
      { date: '2024-06-24', assetName: '作训靴', method: '报废', amount: 16, reason: '达到使用年限，性能下降', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-01-03', assetName: '作训靴(3515)', assetType: '应急物资', reason: '达到使用年限', approvalStatus: '待提交' },
      { date: '2024-02-23', assetName: '手电筒电池', assetType: '装备', reason: '损坏无法修复', approvalStatus: '审批中' },
    ],
    transferRecords: [
      { date: '2024-03-09', assetName: '金属探测器', fromUnit: '总队A', toUnit: '总队A', amount: 96, status: '已完成' },
      { date: '2024-01-13', assetName: '无人机(Mavic3)', fromUnit: '总队A', toUnit: '支队C', amount: 98, status: '审批中' },
    ],
    supplierRecords: [
      { name: '中航工业', category: '装备', totalAmount: 243, orderCount: 5, rating: 5 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 332, orderCount: 12, rating: 5 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 474, orderCount: 14, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1982, dailyAverage: 11.0, utilizationRate: 72 },
      { assetType: '应急物资', totalHours: 460, dailyAverage: 2.6, utilizationRate: 24 },
      { assetType: '被装物资', totalHours: 323, dailyAverage: 1.8, utilizationRate: 54 },
      { assetType: '办公设备', totalHours: 2291, dailyAverage: 12.7, utilizationRate: 79 },
      { assetType: '车辆', totalHours: 2163, dailyAverage: 12.0, utilizationRate: 72 },
    ],
    emergencyCategoryCoverageRate: 92,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 850 }, { type: '急救药品', quantity: 620 }, { type: '照明设备', quantity: 480 }, { type: '通信设备', quantity: 320 }, { type: '食品饮水', quantity: 280 }, { type: '其他', quantity: 150 }],
    emergencyWarehouses: [{ name: '总队主库', value: 1800 }, { name: '东江分库', value: 1200 }, { name: '西湖分库', value: 800 }, { name: '南山分库', value: 400 }],
    emergencyAgencyStorage: [{ unitName: '总队A', value: 1200 }, { unitName: '支队C', value: 800 }, { unitName: '支队D', value: 600 }, { unitName: '支队E', value: 400 }],
    emergencyRegionalCoverage: 95,
    officeDeviceDistributionPlan: { planned: 420, actual: 385 },
    officeDeviceDistributionByUnit: [{ unitName: '总队机关', planned: 120, actual: 112 }, { unitName: '直属大队', planned: 80, actual: 75 }, { unitName: '保障部门', planned: 60, actual: 55 }, { unitName: '训练基地', planned: 50, actual: 45 }, { unitName: '其他', planned: 110, actual: 98 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 4903, emergency: 2094, clothing: 2442, office: 2732, vehicles: 3325 },
      { month: '2024-08', equipment: 5173, emergency: 1983, clothing: 2489, office: 2681, vehicles: 3107 },
      { month: '2024-09', equipment: 5486, emergency: 2036, clothing: 2659, office: 2979, vehicles: 3349 },
      { month: '2024-10', equipment: 5463, emergency: 1936, clothing: 2611, office: 2825, vehicles: 3087 },
      { month: '2024-11', equipment: 5346, emergency: 2025, clothing: 2383, office: 2736, vehicles: 3194 },
      { month: '2024-12', equipment: 5076, emergency: 2185, clothing: 2412, office: 2850, vehicles: 3166 },
      { month: '2025-01', equipment: 4857, emergency: 2017, clothing: 2316, office: 2912, vehicles: 3161 },
      { month: '2025-02', equipment: 5210, emergency: 2037, clothing: 2333, office: 2608, vehicles: 3467 },
      { month: '2025-03', equipment: 5380, emergency: 2061, clothing: 2408, office: 2835, vehicles: 3255 },
      { month: '2025-04', equipment: 5205, emergency: 2134, clothing: 2373, office: 2635, vehicles: 3071 },
      { month: '2025-05', equipment: 5052, emergency: 2187, clothing: 2575, office: 2634, vehicles: 3382 },
      { month: '2025-06', equipment: 5398, emergency: 2119, clothing: 2598, office: 2704, vehicles: 3185 },
    ],
  },
  B: {
    unitId: 'B', totalAssetValue: 29016,
    assetCategories: { equipment: 6000, emergencySupplies: 3100, clothingSupplies: 3800, officeDevices: 4200, vehicles: 6800, realEstate: 3800, other: 1316 },
    equipmentOriginalValue: 13746,
    equipmentDepreciationRate: 29,
    equipmentTypes: [{ type: '执法记录仪', count: 520, value: 2600 }, { type: '对讲机', count: 340, value: 1700 }, { type: '无人机', count: 36, value: 2160 }, { type: '防护装备', count: 900, value: 1800 }, { type: '检测设备', count: 56, value: 1340 }],
    emergencySupplyTypes: [{ type: '急救包', required: 400, actual: 390, status: 'normal' }, { type: '救生衣', required: 600, actual: 580, status: 'normal' }, { type: '应急照明', required: 250, actual: 240, status: 'normal' }, { type: '消防器材', required: 160, actual: 155, status: 'normal' }, { type: '通信设备', required: 80, actual: 72, status: 'warning' }, { type: '防暴器材', required: 120, actual: 118, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 290, value: 1450 }, { type: '笔记本电脑', count: 95, value: 760 }, { type: '打印机', count: 65, value: 520 }, { type: '投影仪', count: 28, value: 560 }, { type: '服务器', count: 18, value: 910 }],
    utilizationRate: 85.2,
    assetValueChange: 4.8,
    disposalRecords: [
      { date: '2024-05-16', assetName: '打印机', method: '转让', amount: 101, reason: '调拨至其他单位使用', status: '已完成' },
      { date: '2024-02-21', assetName: '投影仪', method: '报废', amount: 106, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-04-13', assetName: '冬常服', method: '报废', amount: 72, reason: '达到使用年限，性能下降', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-01-22', assetName: '手电筒电池', assetType: '被装物资', reason: '技术淘汰', approvalStatus: '待提交' },
      { date: '2024-03-04', assetName: '多功能服(加厚)', assetType: '装备', reason: '损坏无法修复', approvalStatus: '审批中' },
      { date: '2024-01-24', assetName: '手电筒电池', assetType: '办公设备', reason: '损坏无法修复', approvalStatus: '待提交' },
      { date: '2024-01-28', assetName: '手电筒电池', assetType: '办公设备', reason: '损坏无法修复', approvalStatus: '已通过' },
    ],
    transferRecords: [
      { date: '2024-05-11', assetName: '防弹盾牌', fromUnit: '总队B', toUnit: '总队B', amount: 38, status: '审批中' },
    ],
    supplierRecords: [
      { name: '海康威视数字技术', category: '安防设备', totalAmount: 90, orderCount: 5, rating: 4 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 424, orderCount: 18, rating: 4 },
      { name: '戴尔(中国)有限公司', category: '办公设备', totalAmount: 467, orderCount: 5, rating: 5 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 439, orderCount: 20, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1057, dailyAverage: 5.9, utilizationRate: 68 },
      { assetType: '应急物资', totalHours: 437, dailyAverage: 2.4, utilizationRate: 50 },
      { assetType: '被装物资', totalHours: 784, dailyAverage: 4.4, utilizationRate: 75 },
      { assetType: '办公设备', totalHours: 1669, dailyAverage: 9.3, utilizationRate: 78 },
      { assetType: '车辆', totalHours: 3080, dailyAverage: 17.1, utilizationRate: 84 },
    ],
    emergencyCategoryCoverageRate: 88,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 680 }, { type: '急救药品', quantity: 520 }, { type: '照明设备', quantity: 390 }, { type: '通信设备', quantity: 260 }, { type: '食品饮水', quantity: 220 }, { type: '其他', quantity: 130 }],
    emergencyWarehouses: [{ name: '总队主库', value: 1500 }, { name: '北原分库', value: 900 }, { name: '中卫分库', value: 700 }],
    emergencyAgencyStorage: [{ unitName: '总队B', value: 1000 }, { unitName: '支队D', value: 700 }, { unitName: '大队E', value: 500 }],
    emergencyRegionalCoverage: 90,
    officeDeviceDistributionPlan: { planned: 320, actual: 298 },
    officeDeviceDistributionByUnit: [{ unitName: '总队机关', planned: 100, actual: 94 }, { unitName: '直属大队', planned: 65, actual: 60 }, { unitName: '保障部门', planned: 50, actual: 46 }, { unitName: '训练基地', planned: 40, actual: 37 }, { unitName: '其他', planned: 65, actual: 61 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5233, emergency: 2008, clothing: 2576, office: 2886, vehicles: 3373 },
      { month: '2024-08', equipment: 5005, emergency: 2059, clothing: 2504, office: 2843, vehicles: 3332 },
      { month: '2024-09', equipment: 5182, emergency: 2124, clothing: 2564, office: 2731, vehicles: 3061 },
      { month: '2024-10', equipment: 5053, emergency: 2015, clothing: 2332, office: 2673, vehicles: 3010 },
      { month: '2024-11', equipment: 5402, emergency: 2183, clothing: 2417, office: 2801, vehicles: 3112 },
      { month: '2024-12', equipment: 4807, emergency: 1936, clothing: 2662, office: 2823, vehicles: 3030 },
      { month: '2025-01', equipment: 5034, emergency: 1934, clothing: 2316, office: 2940, vehicles: 3169 },
      { month: '2025-02', equipment: 4872, emergency: 2163, clothing: 2421, office: 2642, vehicles: 3342 },
      { month: '2025-03', equipment: 5297, emergency: 2009, clothing: 2576, office: 2567, vehicles: 3370 },
      { month: '2025-04', equipment: 5384, emergency: 2195, clothing: 2542, office: 2624, vehicles: 3401 },
      { month: '2025-05', equipment: 5284, emergency: 2108, clothing: 2397, office: 2548, vehicles: 3049 },
      { month: '2025-06', equipment: 5474, emergency: 2120, clothing: 2481, office: 2716, vehicles: 3210 },
    ],
  },
  C: {
    unitId: 'C', totalAssetValue: 15929,
    assetCategories: { equipment: 2700, emergencySupplies: 2100, clothingSupplies: 2500, officeDevices: 2800, vehicles: 3200, realEstate: 1800, other: 829 },
    equipmentOriginalValue: 6190,
    equipmentDepreciationRate: 16,
    equipmentTypes: [{ type: '执法记录仪', count: 280, value: 1400 }, { type: '对讲机', count: 180, value: 900 }, { type: '无人机', count: 18, value: 1080 }, { type: '防护装备', count: 480, value: 960 }, { type: '检测设备', count: 36, value: 860 }],
    emergencySupplyTypes: [{ type: '急救包', required: 220, actual: 195, status: 'warning' }, { type: '救生衣', required: 350, actual: 340, status: 'normal' }, { type: '应急照明', required: 140, actual: 135, status: 'normal' }, { type: '消防器材', required: 100, actual: 92, status: 'warning' }, { type: '通信设备', required: 50, actual: 38, status: 'critical' }, { type: '防暴器材', required: 75, actual: 70, status: 'warning' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 160, value: 800 }, { type: '笔记本电脑', count: 52, value: 416 }, { type: '打印机', count: 38, value: 304 }, { type: '投影仪', count: 16, value: 320 }, { type: '服务器', count: 10, value: 960 }],
    utilizationRate: 78.6,
    assetValueChange: 3.2,
    disposalRecords: [
      { date: '2024-06-21', assetName: '打印机', method: '报废', amount: 12, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-01-08', assetName: '服务器', method: '捐赠', amount: 29, reason: '支援基层单位', status: '审批中' },
      { date: '2024-04-06', assetName: '对讲机', method: '转让', amount: 64, reason: '调拨至其他单位使用', status: '已完成' },
      { date: '2024-04-26', assetName: '作训靴', method: '报废', amount: 17, reason: '达到使用年限，性能下降', status: '已完成' },
      { date: '2024-01-25', assetName: '服务器', method: '报废', amount: 26, reason: '达到使用年限，性能下降', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-04-07', assetName: '消毒液', assetType: '装备', reason: '达到使用年限', approvalStatus: '已通过' },
      { date: '2024-04-01', assetName: '雨衣(分体式)', assetType: '办公设备', reason: '库存积压超2年', approvalStatus: '审批中' },
      { date: '2024-04-23', assetName: '手电筒电池', assetType: '装备', reason: '损坏无法修复', approvalStatus: '已通过' },
    ],
    transferRecords: [
      { date: '2024-05-02', assetName: '应急照明灯', fromUnit: '支队C', toUnit: '总队B', amount: 22, status: '审批中' },
      { date: '2024-05-28', assetName: '执法记录仪', fromUnit: '支队C', toUnit: '总队A', amount: 24, status: '已完成' },
      { date: '2024-02-03', assetName: '执法记录仪', fromUnit: '支队C', toUnit: '总队B', amount: 182, status: '已完成' },
    ],
    supplierRecords: [
      { name: '戴尔(中国)有限公司', category: '办公设备', totalAmount: 354, orderCount: 4, rating: 5 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 367, orderCount: 5, rating: 5 },
      { name: '中航工业', category: '装备', totalAmount: 264, orderCount: 19, rating: 5 },
      { name: '三一重工', category: '车辆', totalAmount: 211, orderCount: 11, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1218, dailyAverage: 6.8, utilizationRate: 80 },
      { assetType: '应急物资', totalHours: 222, dailyAverage: 1.2, utilizationRate: 36 },
      { assetType: '被装物资', totalHours: 502, dailyAverage: 2.8, utilizationRate: 48 },
      { assetType: '办公设备', totalHours: 2187, dailyAverage: 12.2, utilizationRate: 90 },
      { assetType: '车辆', totalHours: 2614, dailyAverage: 14.5, utilizationRate: 79 },
    ],
    emergencyCategoryCoverageRate: 75,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 420 }, { type: '急救药品', quantity: 310 }, { type: '照明设备', quantity: 250 }, { type: '通信设备', quantity: 160 }, { type: '食品饮水', quantity: 140 }, { type: '其他', quantity: 80 }],
    emergencyWarehouses: [{ name: '支队主库', value: 1200 }, { name: '大队储备点', value: 900 }],
    emergencyAgencyStorage: [{ unitName: '支队C', value: 800 }, { unitName: '大队A', value: 600 }],
    emergencyRegionalCoverage: 78,
    officeDeviceDistributionPlan: { planned: 185, actual: 168 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 60, actual: 55 }, { unitName: '大队A', planned: 35, actual: 32 }, { unitName: '大队B', planned: 30, actual: 27 }, { unitName: '其他', planned: 60, actual: 54 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5123, emergency: 1937, clothing: 2304, office: 2734, vehicles: 3318 },
      { month: '2024-08', equipment: 5376, emergency: 1951, clothing: 2337, office: 2775, vehicles: 3109 },
      { month: '2024-09', equipment: 5318, emergency: 2035, clothing: 2367, office: 2977, vehicles: 3178 },
      { month: '2024-10', equipment: 4870, emergency: 2025, clothing: 2489, office: 2645, vehicles: 3080 },
      { month: '2024-11', equipment: 5248, emergency: 2178, clothing: 2660, office: 2654, vehicles: 3313 },
      { month: '2024-12', equipment: 5469, emergency: 2170, clothing: 2304, office: 2841, vehicles: 3418 },
      { month: '2025-01', equipment: 5367, emergency: 2053, clothing: 2639, office: 2553, vehicles: 3480 },
      { month: '2025-02', equipment: 4937, emergency: 2035, clothing: 2359, office: 2955, vehicles: 3054 },
      { month: '2025-03', equipment: 5366, emergency: 1979, clothing: 2439, office: 2644, vehicles: 3309 },
      { month: '2025-04', equipment: 5015, emergency: 2075, clothing: 2404, office: 2851, vehicles: 3324 },
      { month: '2025-05', equipment: 5070, emergency: 2158, clothing: 2550, office: 2628, vehicles: 3463 },
      { month: '2025-06', equipment: 4852, emergency: 1947, clothing: 2624, office: 2716, vehicles: 3424 },
    ],
  },
  D: {
    unitId: 'D', totalAssetValue: 16667,
    assetCategories: { equipment: 2700, emergencySupplies: 2200, clothingSupplies: 2700, officeDevices: 3000, vehicles: 3400, realEstate: 1900, other: 767 },
    equipmentOriginalValue: 6585,
    equipmentDepreciationRate: 18,
    equipmentTypes: [{ type: '执法记录仪', count: 300, value: 1500 }, { type: '对讲机', count: 190, value: 950 }, { type: '无人机', count: 20, value: 1200 }, { type: '防护装备', count: 500, value: 1000 }, { type: '检测设备', count: 38, value: 750 }],
    emergencySupplyTypes: [{ type: '急救包', required: 230, actual: 225, status: 'normal' }, { type: '救生衣', required: 360, actual: 355, status: 'normal' }, { type: '应急照明', required: 145, actual: 142, status: 'normal' }, { type: '消防器材', required: 100, actual: 96, status: 'normal' }, { type: '通信设备', required: 55, actual: 50, status: 'normal' }, { type: '防暴器材', required: 78, actual: 75, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 170, value: 850 }, { type: '笔记本电脑', count: 56, value: 448 }, { type: '打印机', count: 40, value: 320 }, { type: '投影仪', count: 17, value: 340 }, { type: '服务器', count: 11, value: 1040 }],
    utilizationRate: 91.2,
    assetValueChange: 6.5,
    disposalRecords: [
      { date: '2024-01-11', assetName: '投影仪', method: '报废', amount: 86, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-06-15', assetName: '作训靴', method: '转让', amount: 95, reason: '调拨至其他单位使用', status: '审批中' },
      { date: '2024-01-03', assetName: '投影仪', method: '报废', amount: 74, reason: '达到使用年限，性能下降', status: '已完成' },
      { date: '2024-05-18', assetName: '投影仪', method: '捐赠', amount: 60, reason: '支援基层单位', status: '已完成' },
    ],
    scrapRecords: [
      { date: '2024-03-12', assetName: '消毒液', assetType: '被装物资', reason: '技术淘汰', approvalStatus: '已通过' },
      { date: '2024-06-08', assetName: '手电筒电池', assetType: '被装物资', reason: '技术淘汰', approvalStatus: '待提交' },
    ],
    transferRecords: [
      { date: '2024-04-01', assetName: '金属探测器', fromUnit: '支队D', toUnit: '支队C', amount: 115, status: '已完成' },
    ],
    supplierRecords: [
      { name: '华为技术有限公司', category: '通信装备', totalAmount: 245, orderCount: 4, rating: 5 },
      { name: '三一重工', category: '车辆', totalAmount: 489, orderCount: 18, rating: 4 },
      { name: '摩托罗拉系统', category: '通信装备', totalAmount: 163, orderCount: 9, rating: 3 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 468, orderCount: 17, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1516, dailyAverage: 8.4, utilizationRate: 79 },
      { assetType: '应急物资', totalHours: 216, dailyAverage: 1.2, utilizationRate: 34 },
      { assetType: '被装物资', totalHours: 312, dailyAverage: 1.7, utilizationRate: 52 },
      { assetType: '办公设备', totalHours: 1908, dailyAverage: 10.6, utilizationRate: 80 },
      { assetType: '车辆', totalHours: 2570, dailyAverage: 14.3, utilizationRate: 67 },
    ],
    emergencyCategoryCoverageRate: 90,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 450 }, { type: '急救药品', quantity: 330 }, { type: '照明设备', quantity: 260 }, { type: '通信设备', quantity: 170 }, { type: '食品饮水', quantity: 150 }, { type: '其他', quantity: 90 }],
    emergencyWarehouses: [{ name: '支队主库', value: 1300 }, { name: '西湖储备点', value: 900 }],
    emergencyAgencyStorage: [{ unitName: '支队D', value: 850 }, { unitName: '大队B', value: 650 }],
    emergencyRegionalCoverage: 88,
    officeDeviceDistributionPlan: { planned: 195, actual: 180 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 65, actual: 60 }, { unitName: '大队C', planned: 38, actual: 35 }, { unitName: '大队D', planned: 32, actual: 29 }, { unitName: '其他', planned: 60, actual: 56 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5085, emergency: 2079, clothing: 2628, office: 2760, vehicles: 3204 },
      { month: '2024-08', equipment: 5495, emergency: 2174, clothing: 2469, office: 2980, vehicles: 3014 },
      { month: '2024-09', equipment: 4918, emergency: 2033, clothing: 2391, office: 2797, vehicles: 3492 },
      { month: '2024-10', equipment: 5071, emergency: 1919, clothing: 2355, office: 2805, vehicles: 3222 },
      { month: '2024-11', equipment: 5153, emergency: 2060, clothing: 2523, office: 2810, vehicles: 3261 },
      { month: '2024-12', equipment: 4918, emergency: 2097, clothing: 2595, office: 2597, vehicles: 3130 },
      { month: '2025-01', equipment: 4845, emergency: 2123, clothing: 2300, office: 2766, vehicles: 3473 },
      { month: '2025-02', equipment: 5351, emergency: 2000, clothing: 2486, office: 2720, vehicles: 3035 },
      { month: '2025-03', equipment: 5480, emergency: 2069, clothing: 2619, office: 2660, vehicles: 3339 },
      { month: '2025-04', equipment: 4927, emergency: 2053, clothing: 2559, office: 2658, vehicles: 3341 },
      { month: '2025-05', equipment: 5218, emergency: 2067, clothing: 2506, office: 2856, vehicles: 3151 },
      { month: '2025-06', equipment: 5367, emergency: 1965, clothing: 2398, office: 2715, vehicles: 3340 },
    ],
  },
  E: {
    unitId: 'E', totalAssetValue: 10985,
    assetCategories: { equipment: 1420, emergencySupplies: 1800, clothingSupplies: 1980, officeDevices: 2200, vehicles: 2100, realEstate: 950, other: 535 },
    equipmentOriginalValue: 4250,
    equipmentDepreciationRate: 20,
    equipmentTypes: [{ type: '执法记录仪', count: 190, value: 950 }, { type: '对讲机', count: 120, value: 600 }, { type: '无人机', count: 10, value: 600 }, { type: '防护装备', count: 320, value: 640 }, { type: '检测设备', count: 25, value: 610 }],
    emergencySupplyTypes: [{ type: '急救包', required: 150, actual: 128, status: 'critical' }, { type: '救生衣', required: 240, actual: 200, status: 'critical' }, { type: '应急照明', required: 95, actual: 88, status: 'warning' }, { type: '消防器材', required: 70, actual: 58, status: 'critical' }, { type: '通信设备', required: 35, actual: 28, status: 'critical' }, { type: '防暴器材', required: 52, actual: 45, status: 'warning' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 125, value: 625 }, { type: '笔记本电脑', count: 40, value: 320 }, { type: '打印机', count: 28, value: 224 }, { type: '投影仪', count: 12, value: 240 }, { type: '服务器', count: 8, value: 791 }],
    utilizationRate: 72.4,
    assetValueChange: -2.1,
    disposalRecords: [
      { date: '2024-05-19', assetName: '对讲机', method: '转让', amount: 56, reason: '调拨至其他单位使用', status: '已完成' },
      { date: '2024-03-07', assetName: '执法记录仪', method: '捐赠', amount: 105, reason: '支援基层单位', status: '审批中' },
      { date: '2024-04-15', assetName: '服务器', method: '调拨', amount: 70, reason: '资源优化配置', status: '审批中' },
      { date: '2024-06-03', assetName: '对讲机', method: '转让', amount: 70, reason: '调拨至其他单位使用', status: '审批中' },
      { date: '2024-02-22', assetName: '对讲机', method: '报废', amount: 33, reason: '达到使用年限，性能下降', status: '已完成' },
    ],
    scrapRecords: [
      { date: '2024-01-02', assetName: '作训靴(3515)', assetType: '装备', reason: '达到使用年限', approvalStatus: '审批中' },
      { date: '2024-04-21', assetName: '急救包A型', assetType: '应急物资', reason: '库存积压超2年', approvalStatus: '审批中' },
    ],
    transferRecords: [
      { date: '2024-01-25', assetName: '无人机(Mavic3)', fromUnit: '大队E', toUnit: '支队L', amount: 66, status: '已完成' },
      { date: '2024-06-17', assetName: '防弹盾牌', fromUnit: '大队E', toUnit: '总队B', amount: 152, status: '已完成' },
      { date: '2024-01-15', assetName: '金属探测器', fromUnit: '大队E', toUnit: '支队L', amount: 180, status: '审批中' },
    ],
    supplierRecords: [
      { name: '三一重工', category: '车辆', totalAmount: 131, orderCount: 18, rating: 4 },
      { name: '中航工业', category: '装备', totalAmount: 280, orderCount: 11, rating: 5 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 434, orderCount: 10, rating: 5 },
      { name: '海康威视数字技术', category: '安防设备', totalAmount: 480, orderCount: 11, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1867, dailyAverage: 10.4, utilizationRate: 91 },
      { assetType: '应急物资', totalHours: 420, dailyAverage: 2.3, utilizationRate: 35 },
      { assetType: '被装物资', totalHours: 440, dailyAverage: 2.4, utilizationRate: 68 },
      { assetType: '办公设备', totalHours: 1579, dailyAverage: 8.8, utilizationRate: 92 },
      { assetType: '车辆', totalHours: 2585, dailyAverage: 14.4, utilizationRate: 72 },
    ],
    emergencyCategoryCoverageRate: 68,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 280 }, { type: '急救药品', quantity: 210 }, { type: '照明设备', quantity: 180 }, { type: '通信设备', quantity: 110 }, { type: '食品饮水', quantity: 100 }, { type: '其他', quantity: 60 }],
    emergencyWarehouses: [{ name: '支队主库', value: 950 }, { name: '南山储备点', value: 850 }],
    emergencyAgencyStorage: [{ unitName: '支队E', value: 650 }, { unitName: '大队C', value: 550 }],
    emergencyRegionalCoverage: 70,
    officeDeviceDistributionPlan: { planned: 145, actual: 128 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 48, actual: 42 }, { unitName: '大队E', planned: 28, actual: 25 }, { unitName: '其他', planned: 69, actual: 61 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5078, emergency: 2071, clothing: 2463, office: 2957, vehicles: 3276 },
      { month: '2024-08', equipment: 4882, emergency: 1970, clothing: 2377, office: 2618, vehicles: 3196 },
      { month: '2024-09', equipment: 4956, emergency: 2009, clothing: 2332, office: 2712, vehicles: 3208 },
      { month: '2024-10', equipment: 5138, emergency: 2177, clothing: 2538, office: 2712, vehicles: 3031 },
      { month: '2024-11', equipment: 5011, emergency: 2115, clothing: 2499, office: 2963, vehicles: 3394 },
      { month: '2024-12', equipment: 5398, emergency: 1910, clothing: 2691, office: 2794, vehicles: 3194 },
      { month: '2025-01', equipment: 5288, emergency: 1903, clothing: 2480, office: 2652, vehicles: 3385 },
      { month: '2025-02', equipment: 5199, emergency: 2114, clothing: 2575, office: 2882, vehicles: 3376 },
      { month: '2025-03', equipment: 5359, emergency: 2012, clothing: 2549, office: 2612, vehicles: 3139 },
      { month: '2025-04', equipment: 5246, emergency: 2148, clothing: 2314, office: 2699, vehicles: 3172 },
      { month: '2025-05', equipment: 5484, emergency: 2107, clothing: 2670, office: 2584, vehicles: 3430 },
      { month: '2025-06', equipment: 5278, emergency: 1965, clothing: 2618, office: 2773, vehicles: 3013 },
    ],
  },
  F: {
    unitId: 'F', totalAssetValue: 10795,
    assetCategories: { equipment: 1430, emergencySupplies: 1750, clothingSupplies: 2070, officeDevices: 2300, vehicles: 2150, realEstate: 850, other: 245 },
    equipmentOriginalValue: 4605,
    equipmentDepreciationRate: 24,
    equipmentTypes: [{ type: '执法记录仪', count: 195, value: 975 }, { type: '对讲机', count: 125, value: 625 }, { type: '无人机', count: 12, value: 720 }, { type: '防护装备', count: 330, value: 660 }, { type: '检测设备', count: 26, value: 520 }],
    emergencySupplyTypes: [{ type: '急救包', required: 155, actual: 152, status: 'normal' }, { type: '救生衣', required: 250, actual: 245, status: 'normal' }, { type: '应急照明', required: 100, actual: 98, status: 'normal' }, { type: '消防器材', required: 72, actual: 68, status: 'normal' }, { type: '通信设备', required: 36, actual: 34, status: 'normal' }, { type: '防暴器材', required: 54, actual: 52, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 130, value: 650 }, { type: '笔记本电脑', count: 42, value: 336 }, { type: '打印机', count: 30, value: 240 }, { type: '投影仪', count: 13, value: 260 }, { type: '服务器', count: 8, value: 814 }],
    utilizationRate: 89.3,
    assetValueChange: 5.8,
    disposalRecords: [
      { date: '2024-01-21', assetName: '执法记录仪', method: '报废', amount: 22, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-01-09', assetName: '执法记录仪', method: '转让', amount: 46, reason: '调拨至其他单位使用', status: '已完成' },
      { date: '2024-03-11', assetName: '执法记录仪', method: '调拨', amount: 40, reason: '资源优化配置', status: '审批中' },
      { date: '2024-01-16', assetName: '电脑主机', method: '捐赠', amount: 100, reason: '支援基层单位', status: '已完成' },
      { date: '2024-02-21', assetName: '打印机', method: '捐赠', amount: 104, reason: '支援基层单位', status: '已完成' },
    ],
    scrapRecords: [
      { date: '2024-02-07', assetName: '消毒液', assetType: '被装物资', reason: '损坏无法修复', approvalStatus: '已通过' },
      { date: '2024-02-16', assetName: '手电筒电池', assetType: '被装物资', reason: '损坏无法修复', approvalStatus: '审批中' },
    ],
    transferRecords: [
      { date: '2024-06-23', assetName: '无人机(Mavic3)', fromUnit: '大队F', toUnit: '总队B', amount: 89, status: '已完成' },
      { date: '2024-05-01', assetName: '应急照明灯', fromUnit: '大队F', toUnit: '支队L', amount: 111, status: '已完成' },
      { date: '2024-01-19', assetName: '金属探测器', fromUnit: '大队F', toUnit: '总队B', amount: 188, status: '审批中' },
    ],
    supplierRecords: [
      { name: '戴尔(中国)有限公司', category: '办公设备', totalAmount: 322, orderCount: 16, rating: 5 },
      { name: '三一重工', category: '车辆', totalAmount: 388, orderCount: 14, rating: 4 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 85, orderCount: 19, rating: 5 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 381, orderCount: 13, rating: 4 },
      { name: '华为技术有限公司', category: '通信装备', totalAmount: 56, orderCount: 16, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1803, dailyAverage: 10.0, utilizationRate: 66 },
      { assetType: '应急物资', totalHours: 321, dailyAverage: 1.8, utilizationRate: 43 },
      { assetType: '被装物资', totalHours: 625, dailyAverage: 3.5, utilizationRate: 69 },
      { assetType: '办公设备', totalHours: 2224, dailyAverage: 12.4, utilizationRate: 74 },
      { assetType: '车辆', totalHours: 2891, dailyAverage: 16.1, utilizationRate: 70 },
    ],
    emergencyCategoryCoverageRate: 85,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 290 }, { type: '急救药品', quantity: 220 }, { type: '照明设备', quantity: 185 }, { type: '通信设备', quantity: 115 }, { type: '食品饮水', quantity: 105 }, { type: '其他', quantity: 65 }],
    emergencyWarehouses: [{ name: '支队主库', value: 1000 }, { name: '北原储备点', value: 750 }],
    emergencyAgencyStorage: [{ unitName: '支队D', value: 700 }, { unitName: '大队D', value: 500 }],
    emergencyRegionalCoverage: 85,
    officeDeviceDistributionPlan: { planned: 150, actual: 140 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 50, actual: 46 }, { unitName: '保障部门', planned: 35, actual: 33 }, { unitName: '其他', planned: 65, actual: 61 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5334, emergency: 2038, clothing: 2615, office: 2913, vehicles: 3470 },
      { month: '2024-08', equipment: 5351, emergency: 2147, clothing: 2538, office: 2723, vehicles: 3422 },
      { month: '2024-09', equipment: 5406, emergency: 2037, clothing: 2465, office: 2936, vehicles: 3125 },
      { month: '2024-10', equipment: 4888, emergency: 2042, clothing: 2530, office: 2624, vehicles: 3384 },
      { month: '2024-11', equipment: 5275, emergency: 2191, clothing: 2612, office: 2842, vehicles: 3194 },
      { month: '2024-12', equipment: 5144, emergency: 1914, clothing: 2553, office: 2935, vehicles: 3166 },
      { month: '2025-01', equipment: 4986, emergency: 2149, clothing: 2408, office: 2681, vehicles: 3408 },
      { month: '2025-02', equipment: 5064, emergency: 2074, clothing: 2443, office: 2950, vehicles: 3305 },
      { month: '2025-03', equipment: 5082, emergency: 2184, clothing: 2305, office: 2764, vehicles: 3485 },
      { month: '2025-04', equipment: 4995, emergency: 1943, clothing: 2423, office: 2868, vehicles: 3208 },
      { month: '2025-05', equipment: 5300, emergency: 2184, clothing: 2688, office: 2623, vehicles: 3353 },
      { month: '2025-06', equipment: 5287, emergency: 2151, clothing: 2529, office: 2905, vehicles: 3008 },
    ],
  },
  G: {
    unitId: 'G', totalAssetValue: 8173,
    assetCategories: { equipment: 1070, emergencySupplies: 1350, clothingSupplies: 1580, officeDevices: 1750, vehicles: 1650, realEstate: 550, other: 223 },
    equipmentOriginalValue: 3312,
    equipmentDepreciationRate: 20,
    equipmentTypes: [{ type: '执法记录仪', count: 148, value: 740 }, { type: '对讲机', count: 95, value: 475 }, { type: '无人机', count: 9, value: 540 }, { type: '防护装备', count: 250, value: 500 }, { type: '检测设备', count: 20, value: 395 }],
    emergencySupplyTypes: [{ type: '急救包', required: 118, actual: 110, status: 'warning' }, { type: '救生衣', required: 188, actual: 180, status: 'warning' }, { type: '应急照明', required: 76, actual: 72, status: 'normal' }, { type: '消防器材', required: 55, actual: 50, status: 'warning' }, { type: '通信设备', required: 28, actual: 24, status: 'warning' }, { type: '防暴器材', required: 40, actual: 38, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 98, value: 490 }, { type: '笔记本电脑', count: 32, value: 256 }, { type: '打印机', count: 22, value: 176 }, { type: '投影仪', count: 10, value: 200 }, { type: '服务器', count: 6, value: 628 }],
    utilizationRate: 82.1,
    assetValueChange: 4.1,
    disposalRecords: [
      { date: '2024-02-13', assetName: '服务器', method: '捐赠', amount: 44, reason: '支援基层单位', status: '审批中' },
      { date: '2024-05-17', assetName: '防弹盾牌', method: '调拨', amount: 59, reason: '资源优化配置', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-06-15', assetName: '多功能服(加厚)', assetType: '办公设备', reason: '技术淘汰', approvalStatus: '已通过' },
      { date: '2024-01-24', assetName: '作训靴(3515)', assetType: '办公设备', reason: '达到使用年限', approvalStatus: '待提交' },
      { date: '2024-05-25', assetName: '手电筒电池', assetType: '应急物资', reason: '损坏无法修复', approvalStatus: '已通过' },
    ],
    transferRecords: [
      { date: '2024-05-10', assetName: '无人机(Mavic3)', fromUnit: '大队G', toUnit: '总队B', amount: 85, status: '已完成' },
      { date: '2024-03-06', assetName: '应急照明灯', fromUnit: '大队G', toUnit: '总队B', amount: 191, status: '已完成' },
      { date: '2024-03-02', assetName: '无人机(Mavic3)', fromUnit: '大队G', toUnit: '支队L', amount: 188, status: '已完成' },
    ],
    supplierRecords: [
      { name: '中航工业', category: '装备', totalAmount: 290, orderCount: 18, rating: 5 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 275, orderCount: 13, rating: 4 },
      { name: '三一重工', category: '车辆', totalAmount: 144, orderCount: 4, rating: 4 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 179, orderCount: 18, rating: 5 },
      { name: '华为技术有限公司', category: '通信装备', totalAmount: 108, orderCount: 5, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1620, dailyAverage: 9.0, utilizationRate: 91 },
      { assetType: '应急物资', totalHours: 137, dailyAverage: 0.8, utilizationRate: 56 },
      { assetType: '被装物资', totalHours: 622, dailyAverage: 3.5, utilizationRate: 43 },
      { assetType: '办公设备', totalHours: 1655, dailyAverage: 9.2, utilizationRate: 74 },
      { assetType: '车辆', totalHours: 3661, dailyAverage: 20.3, utilizationRate: 83 },
    ],
    emergencyCategoryCoverageRate: 78,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 220 }, { type: '急救药品', quantity: 170 }, { type: '照明设备', quantity: 140 }, { type: '通信设备', quantity: 90 }, { type: '食品饮水', quantity: 80 }, { type: '其他', quantity: 50 }],
    emergencyWarehouses: [{ name: '支队主库', value: 750 }, { name: '中卫储备点', value: 600 }],
    emergencyAgencyStorage: [{ unitName: '支队E', value: 550 }, { unitName: '大队E', value: 400 }],
    emergencyRegionalCoverage: 80,
    officeDeviceDistributionPlan: { planned: 115, actual: 105 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 38, actual: 35 }, { unitName: '保障部门', planned: 28, actual: 26 }, { unitName: '其他', planned: 49, actual: 44 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5111, emergency: 1943, clothing: 2427, office: 2560, vehicles: 3285 },
      { month: '2024-08', equipment: 5226, emergency: 2015, clothing: 2697, office: 2767, vehicles: 3194 },
      { month: '2024-09', equipment: 5261, emergency: 2126, clothing: 2452, office: 2940, vehicles: 3301 },
      { month: '2024-10', equipment: 5239, emergency: 2056, clothing: 2591, office: 2817, vehicles: 3030 },
      { month: '2024-11', equipment: 5424, emergency: 1950, clothing: 2690, office: 2606, vehicles: 3320 },
      { month: '2024-12', equipment: 5016, emergency: 2035, clothing: 2638, office: 2541, vehicles: 3080 },
      { month: '2025-01', equipment: 5045, emergency: 1988, clothing: 2582, office: 2538, vehicles: 3080 },
      { month: '2025-02', equipment: 4802, emergency: 2109, clothing: 2530, office: 2852, vehicles: 3304 },
      { month: '2025-03', equipment: 5281, emergency: 2049, clothing: 2316, office: 2618, vehicles: 3147 },
      { month: '2025-04', equipment: 5089, emergency: 2132, clothing: 2336, office: 2851, vehicles: 3119 },
      { month: '2025-05', equipment: 5070, emergency: 2001, clothing: 2517, office: 2558, vehicles: 3278 },
      { month: '2025-06', equipment: 5030, emergency: 1976, clothing: 2436, office: 2923, vehicles: 3072 },
    ],
  },
  H: {
    unitId: 'H', totalAssetValue: 5495,
    assetCategories: { equipment: 720, emergencySupplies: 900, clothingSupplies: 1060, officeDevices: 1180, vehicles: 1100, realEstate: 380, other: 155 },
    equipmentOriginalValue: 2132,
    equipmentDepreciationRate: 17,
    equipmentTypes: [{ type: '执法记录仪', count: 98, value: 490 }, { type: '对讲机', count: 62, value: 310 }, { type: '无人机', count: 6, value: 360 }, { type: '防护装备', count: 168, value: 336 }, { type: '检测设备', count: 14, value: 284 }],
    emergencySupplyTypes: [{ type: '急救包', required: 80, actual: 76, status: 'normal' }, { type: '救生衣', required: 128, actual: 125, status: 'normal' }, { type: '应急照明', required: 50, actual: 48, status: 'normal' }, { type: '消防器材', required: 36, actual: 34, status: 'normal' }, { type: '通信设备', required: 18, actual: 16, status: 'normal' }, { type: '防暴器材', required: 28, actual: 26, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 66, value: 330 }, { type: '笔记本电脑', count: 22, value: 176 }, { type: '打印机', count: 15, value: 120 }, { type: '投影仪', count: 7, value: 140 }, { type: '服务器', count: 4, value: 414 }],
    utilizationRate: 86.5,
    assetValueChange: 5.2,
    disposalRecords: [
      { date: '2024-02-26', assetName: '对讲机', method: '报废', amount: 81, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-01-15', assetName: '对讲机', method: '调拨', amount: 94, reason: '资源优化配置', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-05-18', assetName: '雨衣(分体式)', assetType: '装备', reason: '达到使用年限', approvalStatus: '待提交' },
      { date: '2024-01-14', assetName: '手电筒电池', assetType: '办公设备', reason: '技术淘汰', approvalStatus: '已通过' },
      { date: '2024-01-08', assetName: '手电筒电池', assetType: '被装物资', reason: '技术淘汰', approvalStatus: '待提交' },
    ],
    transferRecords: [
      { date: '2024-04-09', assetName: '金属探测器', fromUnit: '大队H', toUnit: '支队L', amount: 172, status: '审批中' },
      { date: '2024-01-16', assetName: '应急照明灯', fromUnit: '大队H', toUnit: '支队L', amount: 95, status: '审批中' },
      { date: '2024-06-04', assetName: '金属探测器', fromUnit: '大队H', toUnit: '支队D', amount: 115, status: '审批中' },
    ],
    supplierRecords: [
      { name: '三一重工', category: '车辆', totalAmount: 282, orderCount: 5, rating: 4 },
      { name: '中航工业', category: '装备', totalAmount: 211, orderCount: 11, rating: 5 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 215, orderCount: 6, rating: 5 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 445, orderCount: 15, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1853, dailyAverage: 10.3, utilizationRate: 60 },
      { assetType: '应急物资', totalHours: 436, dailyAverage: 2.4, utilizationRate: 54 },
      { assetType: '被装物资', totalHours: 536, dailyAverage: 3.0, utilizationRate: 66 },
      { assetType: '办公设备', totalHours: 1555, dailyAverage: 8.6, utilizationRate: 76 },
      { assetType: '车辆', totalHours: 3061, dailyAverage: 17.0, utilizationRate: 76 },
    ],
    emergencyCategoryCoverageRate: 88,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 150 }, { type: '急救药品', quantity: 110 }, { type: '照明设备', quantity: 95 }, { type: '通信设备', quantity: 60 }, { type: '食品饮水', quantity: 55 }, { type: '其他', quantity: 35 }],
    emergencyWarehouses: [{ name: '大队储备库', value: 500 }, { name: '东江储备点', value: 400 }],
    emergencyAgencyStorage: [{ unitName: '大队A', value: 380 }, { unitName: '支队C', value: 300 }],
    emergencyRegionalCoverage: 85,
    officeDeviceDistributionPlan: { planned: 78, actual: 72 },
    officeDeviceDistributionByUnit: [{ unitName: '大队本部', planned: 26, actual: 24 }, { unitName: '中队一', planned: 18, actual: 16 }, { unitName: '中队二', planned: 16, actual: 15 }, { unitName: '其他', planned: 18, actual: 17 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5437, emergency: 2155, clothing: 2620, office: 2726, vehicles: 3389 },
      { month: '2024-08', equipment: 4852, emergency: 2004, clothing: 2436, office: 2781, vehicles: 3067 },
      { month: '2024-09', equipment: 5094, emergency: 2124, clothing: 2657, office: 2748, vehicles: 3062 },
      { month: '2024-10', equipment: 4829, emergency: 2022, clothing: 2663, office: 2581, vehicles: 3159 },
      { month: '2024-11', equipment: 5364, emergency: 1907, clothing: 2582, office: 2708, vehicles: 3047 },
      { month: '2024-12', equipment: 5030, emergency: 1958, clothing: 2536, office: 2984, vehicles: 3060 },
      { month: '2025-01', equipment: 5463, emergency: 1978, clothing: 2555, office: 2977, vehicles: 3366 },
      { month: '2025-02', equipment: 5098, emergency: 2160, clothing: 2661, office: 2639, vehicles: 3212 },
      { month: '2025-03', equipment: 5294, emergency: 2141, clothing: 2424, office: 2733, vehicles: 3282 },
      { month: '2025-04', equipment: 4948, emergency: 2096, clothing: 2397, office: 2971, vehicles: 3306 },
      { month: '2025-05', equipment: 5320, emergency: 1969, clothing: 2335, office: 2641, vehicles: 3395 },
      { month: '2025-06', equipment: 5224, emergency: 2074, clothing: 2559, office: 2636, vehicles: 3420 },
    ],
  },
  I: {
    unitId: 'I', totalAssetValue: 5298,
    assetCategories: { equipment: 700, emergencySupplies: 870, clothingSupplies: 1020, officeDevices: 1140, vehicles: 1060, realEstate: 360, other: 148 },
    equipmentOriginalValue: 2066,
    equipmentDepreciationRate: 17,
    equipmentTypes: [{ type: '执法记录仪', count: 95, value: 475 }, { type: '对讲机', count: 60, value: 300 }, { type: '无人机', count: 6, value: 360 }, { type: '防护装备', count: 162, value: 324 }, { type: '检测设备', count: 13, value: 261 }],
    emergencySupplyTypes: [{ type: '急救包', required: 78, actual: 75, status: 'normal' }, { type: '救生衣', required: 124, actual: 122, status: 'normal' }, { type: '应急照明', required: 48, actual: 46, status: 'normal' }, { type: '消防器材', required: 35, actual: 33, status: 'normal' }, { type: '通信设备', required: 18, actual: 16, status: 'normal' }, { type: '防暴器材', required: 26, actual: 25, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 64, value: 320 }, { type: '笔记本电脑', count: 21, value: 168 }, { type: '打印机', count: 14, value: 112 }, { type: '投影仪', count: 7, value: 140 }, { type: '服务器', count: 4, value: 400 }],
    utilizationRate: 90.2,
    assetValueChange: 7.1,
    disposalRecords: [
      { date: '2024-06-10', assetName: '冬常服', method: '捐赠', amount: 115, reason: '支援基层单位', status: '已完成' },
      { date: '2024-05-16', assetName: '防弹盾牌', method: '调拨', amount: 47, reason: '资源优化配置', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-03-28', assetName: '作训靴(3515)', assetType: '应急物资', reason: '库存积压超2年', approvalStatus: '已通过' },
      { date: '2024-04-02', assetName: '多功能服(加厚)', assetType: '装备', reason: '库存积压超2年', approvalStatus: '审批中' },
      { date: '2024-06-26', assetName: '消毒液', assetType: '应急物资', reason: '库存积压超2年', approvalStatus: '已通过' },
    ],
    transferRecords: [
      { date: '2024-05-15', assetName: '无人机(Mavic3)', fromUnit: '大队I', toUnit: '总队B', amount: 114, status: '已完成' },
    ],
    supplierRecords: [
      { name: '中航工业', category: '装备', totalAmount: 223, orderCount: 15, rating: 5 },
      { name: '三一重工', category: '车辆', totalAmount: 382, orderCount: 5, rating: 4 },
      { name: '华为技术有限公司', category: '通信装备', totalAmount: 486, orderCount: 13, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1892, dailyAverage: 10.5, utilizationRate: 84 },
      { assetType: '应急物资', totalHours: 262, dailyAverage: 1.5, utilizationRate: 60 },
      { assetType: '被装物资', totalHours: 667, dailyAverage: 3.7, utilizationRate: 71 },
      { assetType: '办公设备', totalHours: 2393, dailyAverage: 13.3, utilizationRate: 87 },
      { assetType: '车辆', totalHours: 2073, dailyAverage: 11.5, utilizationRate: 84 },
    ],
    emergencyCategoryCoverageRate: 90,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 145 }, { type: '急救药品', quantity: 108 }, { type: '照明设备', quantity: 92 }, { type: '通信设备', quantity: 58 }, { type: '食品饮水', quantity: 53 }, { type: '其他', quantity: 34 }],
    emergencyWarehouses: [{ name: '大队储备库', value: 480 }, { name: '西湖储备点', value: 390 }],
    emergencyAgencyStorage: [{ unitName: '大队B', value: 360 }, { unitName: '支队D', value: 290 }],
    emergencyRegionalCoverage: 87,
    officeDeviceDistributionPlan: { planned: 75, actual: 70 },
    officeDeviceDistributionByUnit: [{ unitName: '大队本部', planned: 25, actual: 23 }, { unitName: '中队一', planned: 17, actual: 16 }, { unitName: '中队二', planned: 15, actual: 14 }, { unitName: '其他', planned: 18, actual: 17 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 4870, emergency: 2020, clothing: 2623, office: 2850, vehicles: 3471 },
      { month: '2024-08', equipment: 5094, emergency: 2016, clothing: 2682, office: 2546, vehicles: 3222 },
      { month: '2024-09', equipment: 4900, emergency: 1951, clothing: 2527, office: 2585, vehicles: 3355 },
      { month: '2024-10', equipment: 5106, emergency: 1914, clothing: 2323, office: 2666, vehicles: 3407 },
      { month: '2024-11', equipment: 4857, emergency: 2050, clothing: 2483, office: 2691, vehicles: 3220 },
      { month: '2024-12', equipment: 4949, emergency: 2025, clothing: 2571, office: 2710, vehicles: 3289 },
      { month: '2025-01', equipment: 5498, emergency: 1992, clothing: 2387, office: 2589, vehicles: 3040 },
      { month: '2025-02', equipment: 5424, emergency: 2095, clothing: 2617, office: 2849, vehicles: 3123 },
      { month: '2025-03', equipment: 5309, emergency: 2198, clothing: 2373, office: 2618, vehicles: 3236 },
      { month: '2025-04', equipment: 5453, emergency: 2030, clothing: 2535, office: 2630, vehicles: 3341 },
      { month: '2025-05', equipment: 4809, emergency: 2138, clothing: 2447, office: 2846, vehicles: 3279 },
      { month: '2025-06', equipment: 4961, emergency: 1937, clothing: 2526, office: 2983, vehicles: 3176 },
    ],
  },
  J: {
    unitId: 'J', totalAssetValue: 3704,
    assetCategories: { equipment: 480, emergencySupplies: 610, clothingSupplies: 720, officeDevices: 800, vehicles: 740, realEstate: 240, other: 114 },
    equipmentOriginalValue: 1428,
    equipmentDepreciationRate: 16,
    equipmentTypes: [{ type: '执法记录仪', count: 66, value: 330 }, { type: '对讲机', count: 42, value: 210 }, { type: '无人机', count: 4, value: 240 }, { type: '防护装备', count: 114, value: 228 }, { type: '检测设备', count: 10, value: 192 }],
    emergencySupplyTypes: [{ type: '急救包', required: 55, actual: 48, status: 'warning' }, { type: '救生衣', required: 88, actual: 76, status: 'critical' }, { type: '应急照明', required: 34, actual: 30, status: 'warning' }, { type: '消防器材', required: 25, actual: 22, status: 'warning' }, { type: '通信设备', required: 12, actual: 10, status: 'warning' }, { type: '防暴器材', required: 18, actual: 16, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 45, value: 225 }, { type: '笔记本电脑', count: 15, value: 120 }, { type: '打印机', count: 10, value: 80 }, { type: '投影仪', count: 5, value: 100 }, { type: '服务器', count: 3, value: 275 }],
    utilizationRate: 75.8,
    assetValueChange: -1.5,
    disposalRecords: [
      { date: '2024-06-09', assetName: '冬常服', method: '调拨', amount: 113, reason: '资源优化配置', status: '审批中' },
      { date: '2024-04-28', assetName: '冬常服', method: '转让', amount: 18, reason: '调拨至其他单位使用', status: '已完成' },
      { date: '2024-05-12', assetName: '对讲机', method: '调拨', amount: 94, reason: '资源优化配置', status: '审批中' },
      { date: '2024-06-13', assetName: '对讲机', method: '报废', amount: 6, reason: '达到使用年限，性能下降', status: '已完成' },
    ],
    scrapRecords: [
      { date: '2024-06-16', assetName: '消毒液', assetType: '办公设备', reason: '损坏无法修复', approvalStatus: '待提交' },
      { date: '2024-03-08', assetName: '手电筒电池', assetType: '应急物资', reason: '技术淘汰', approvalStatus: '待提交' },
      { date: '2024-06-25', assetName: '手电筒电池', assetType: '应急物资', reason: '达到使用年限', approvalStatus: '待提交' },
      { date: '2024-06-02', assetName: '多功能服(加厚)', assetType: '装备', reason: '达到使用年限', approvalStatus: '待提交' },
    ],
    transferRecords: [
      { date: '2024-06-14', assetName: '金属探测器', fromUnit: '大队J', toUnit: '总队A', amount: 43, status: '审批中' },
      { date: '2024-05-17', assetName: '应急照明灯', fromUnit: '大队J', toUnit: '总队A', amount: 75, status: '审批中' },
    ],
    supplierRecords: [
      { name: '摩托罗拉系统', category: '通信装备', totalAmount: 88, orderCount: 7, rating: 3 },
      { name: '三一重工', category: '车辆', totalAmount: 436, orderCount: 10, rating: 4 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 490, orderCount: 15, rating: 4 },
      { name: '海康威视数字技术', category: '安防设备', totalAmount: 483, orderCount: 20, rating: 4 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1549, dailyAverage: 8.6, utilizationRate: 65 },
      { assetType: '应急物资', totalHours: 302, dailyAverage: 1.7, utilizationRate: 20 },
      { assetType: '被装物资', totalHours: 435, dailyAverage: 2.4, utilizationRate: 74 },
      { assetType: '办公设备', totalHours: 1626, dailyAverage: 9.0, utilizationRate: 84 },
      { assetType: '车辆', totalHours: 2754, dailyAverage: 15.3, utilizationRate: 86 },
    ],
    emergencyCategoryCoverageRate: 72,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 100 }, { type: '急救药品', quantity: 78 }, { type: '照明设备', quantity: 68 }, { type: '通信设备', quantity: 42 }, { type: '食品饮水', quantity: 38 }, { type: '其他', quantity: 24 }],
    emergencyWarehouses: [{ name: '大队储备库', value: 340 }, { name: '南山储备点', value: 270 }],
    emergencyAgencyStorage: [{ unitName: '大队C', value: 260 }, { unitName: '支队E', value: 210 }],
    emergencyRegionalCoverage: 75,
    officeDeviceDistributionPlan: { planned: 55, actual: 48 },
    officeDeviceDistributionByUnit: [{ unitName: '大队本部', planned: 18, actual: 16 }, { unitName: '中队一', planned: 13, actual: 11 }, { unitName: '中队二', planned: 12, actual: 10 }, { unitName: '其他', planned: 12, actual: 11 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5488, emergency: 2034, clothing: 2599, office: 2695, vehicles: 3421 },
      { month: '2024-08', equipment: 5453, emergency: 2090, clothing: 2355, office: 2845, vehicles: 3119 },
      { month: '2024-09', equipment: 5282, emergency: 1912, clothing: 2617, office: 2952, vehicles: 3482 },
      { month: '2024-10', equipment: 5374, emergency: 2067, clothing: 2612, office: 2613, vehicles: 3331 },
      { month: '2024-11', equipment: 4864, emergency: 2137, clothing: 2658, office: 2654, vehicles: 3332 },
      { month: '2024-12', equipment: 5218, emergency: 1959, clothing: 2371, office: 2523, vehicles: 3484 },
      { month: '2025-01', equipment: 4838, emergency: 2055, clothing: 2552, office: 2559, vehicles: 3049 },
      { month: '2025-02', equipment: 5040, emergency: 2175, clothing: 2369, office: 2698, vehicles: 3232 },
      { month: '2025-03', equipment: 5179, emergency: 2176, clothing: 2514, office: 2800, vehicles: 3380 },
      { month: '2025-04', equipment: 4958, emergency: 2112, clothing: 2635, office: 2550, vehicles: 3426 },
      { month: '2025-05', equipment: 5301, emergency: 2108, clothing: 2443, office: 2516, vehicles: 3353 },
      { month: '2025-06', equipment: 5179, emergency: 2011, clothing: 2527, office: 2727, vehicles: 3486 },
    ],
  },
  K: {
    unitId: 'K', totalAssetValue: 4142,
    assetCategories: { equipment: 540, emergencySupplies: 680, clothingSupplies: 800, officeDevices: 890, vehicles: 830, realEstate: 270, other: 132 },
    equipmentOriginalValue: 1838,
    equipmentDepreciationRate: 27,
    equipmentTypes: [{ type: '执法记录仪', count: 74, value: 370 }, { type: '对讲机', count: 47, value: 235 }, { type: '无人机', count: 5, value: 300 }, { type: '防护装备', count: 128, value: 256 }, { type: '检测设备', count: 10, value: 179 }],
    emergencySupplyTypes: [{ type: '急救包', required: 62, actual: 60, status: 'normal' }, { type: '救生衣', required: 98, actual: 96, status: 'normal' }, { type: '应急照明', required: 38, actual: 37, status: 'normal' }, { type: '消防器材', required: 28, actual: 26, status: 'normal' }, { type: '通信设备', required: 14, actual: 13, status: 'normal' }, { type: '防暴器材', required: 20, actual: 19, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 50, value: 250 }, { type: '笔记本电脑', count: 17, value: 136 }, { type: '打印机', count: 11, value: 88 }, { type: '投影仪', count: 6, value: 120 }, { type: '服务器', count: 3, value: 296 }],
    utilizationRate: 91.8,
    assetValueChange: 6.2,
    disposalRecords: [
      { date: '2024-01-22', assetName: '防弹盾牌', method: '捐赠', amount: 74, reason: '支援基层单位', status: '审批中' },
      { date: '2024-04-09', assetName: '服务器', method: '报废', amount: 20, reason: '达到使用年限，性能下降', status: '审批中' },
      { date: '2024-06-07', assetName: '电脑主机', method: '报废', amount: 11, reason: '达到使用年限，性能下降', status: '审批中' },
    ],
    scrapRecords: [
      { date: '2024-02-26', assetName: '急救包A型', assetType: '应急物资', reason: '达到使用年限', approvalStatus: '待提交' },
      { date: '2024-02-19', assetName: '作训靴(3515)', assetType: '应急物资', reason: '技术淘汰', approvalStatus: '已通过' },
    ],
    transferRecords: [
      { date: '2024-03-26', assetName: '金属探测器', fromUnit: '大队K', toUnit: '总队A', amount: 179, status: '已完成' },
      { date: '2024-02-01', assetName: '应急照明灯', fromUnit: '大队K', toUnit: '总队B', amount: 160, status: '审批中' },
      { date: '2024-01-06', assetName: '应急照明灯', fromUnit: '大队K', toUnit: '总队A', amount: 42, status: '审批中' },
    ],
    supplierRecords: [
      { name: '戴尔(中国)有限公司', category: '办公设备', totalAmount: 448, orderCount: 14, rating: 5 },
      { name: '摩托罗拉系统', category: '通信装备', totalAmount: 312, orderCount: 6, rating: 3 },
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 281, orderCount: 19, rating: 4 },
      { name: '海康威视数字技术', category: '安防设备', totalAmount: 163, orderCount: 4, rating: 4 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 422, orderCount: 19, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 1417, dailyAverage: 7.9, utilizationRate: 89 },
      { assetType: '应急物资', totalHours: 429, dailyAverage: 2.4, utilizationRate: 21 },
      { assetType: '被装物资', totalHours: 331, dailyAverage: 1.8, utilizationRate: 70 },
      { assetType: '办公设备', totalHours: 2367, dailyAverage: 13.2, utilizationRate: 82 },
      { assetType: '车辆', totalHours: 2873, dailyAverage: 16.0, utilizationRate: 86 },
    ],
    emergencyCategoryCoverageRate: 87,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 112 }, { type: '急救药品', quantity: 82 }, { type: '照明设备', quantity: 72 }, { type: '通信设备', quantity: 46 }, { type: '食品饮水', quantity: 42 }, { type: '其他', quantity: 26 }],
    emergencyWarehouses: [{ name: '大队储备库', value: 380 }, { name: '北原储备点', value: 300 }],
    emergencyAgencyStorage: [{ unitName: '大队D', value: 290 }, { unitName: '支队D', value: 230 }],
    emergencyRegionalCoverage: 82,
    officeDeviceDistributionPlan: { planned: 60, actual: 56 },
    officeDeviceDistributionByUnit: [{ unitName: '大队本部', planned: 20, actual: 18 }, { unitName: '中队一', planned: 14, actual: 13 }, { unitName: '中队二', planned: 13, actual: 12 }, { unitName: '其他', planned: 13, actual: 13 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 4910, emergency: 2151, clothing: 2664, office: 2965, vehicles: 3227 },
      { month: '2024-08', equipment: 4875, emergency: 1941, clothing: 2464, office: 2811, vehicles: 3075 },
      { month: '2024-09', equipment: 4867, emergency: 1964, clothing: 2440, office: 2819, vehicles: 3324 },
      { month: '2024-10', equipment: 5399, emergency: 2180, clothing: 2664, office: 2666, vehicles: 3195 },
      { month: '2024-11', equipment: 5411, emergency: 2171, clothing: 2450, office: 2732, vehicles: 3258 },
      { month: '2024-12', equipment: 5419, emergency: 2120, clothing: 2350, office: 2906, vehicles: 3359 },
      { month: '2025-01', equipment: 4917, emergency: 2182, clothing: 2669, office: 2943, vehicles: 3110 },
      { month: '2025-02', equipment: 5240, emergency: 2131, clothing: 2416, office: 2711, vehicles: 3173 },
      { month: '2025-03', equipment: 5264, emergency: 2104, clothing: 2512, office: 2873, vehicles: 3048 },
      { month: '2025-04', equipment: 5120, emergency: 2118, clothing: 2460, office: 2840, vehicles: 3130 },
      { month: '2025-05', equipment: 5183, emergency: 1978, clothing: 2651, office: 2972, vehicles: 3242 },
      { month: '2025-06', equipment: 4868, emergency: 1946, clothing: 2343, office: 2547, vehicles: 3221 },
    ],
  },
  L: {
    unitId: 'L', totalAssetValue: 7487,
    assetCategories: { equipment: 960, emergencySupplies: 1220, clothingSupplies: 1460, officeDevices: 1620, vehicles: 1500, realEstate: 520, other: 207 },
    equipmentOriginalValue: 2987,
    equipmentDepreciationRate: 17,
    equipmentTypes: [{ type: '执法记录仪', count: 134, value: 670 }, { type: '对讲机', count: 85, value: 425 }, { type: '无人机', count: 9, value: 540 }, { type: '防护装备', count: 232, value: 464 }, { type: '检测设备', count: 19, value: 321 }],
    emergencySupplyTypes: [{ type: '急救包', required: 112, actual: 108, status: 'normal' }, { type: '救生衣', required: 178, actual: 172, status: 'warning' }, { type: '应急照明', required: 70, actual: 68, status: 'normal' }, { type: '消防器材', required: 50, actual: 48, status: 'normal' }, { type: '通信设备', required: 25, actual: 23, status: 'normal' }, { type: '防暴器材', required: 38, actual: 36, status: 'normal' }],
    officeDeviceTypes: [{ type: '台式电脑', count: 90, value: 450 }, { type: '笔记本电脑', count: 30, value: 240 }, { type: '打印机', count: 21, value: 168 }, { type: '投影仪', count: 9, value: 180 }, { type: '服务器', count: 6, value: 582 }],
    utilizationRate: 87.4,
    assetValueChange: 5.5,
    disposalRecords: [
      { date: '2024-02-18', assetName: '电脑主机', method: '捐赠', amount: 80, reason: '支援基层单位', status: '审批中' },
      { date: '2024-04-12', assetName: '执法记录仪', method: '报废', amount: 116, reason: '达到使用年限，性能下降', status: '已完成' },
    ],
    scrapRecords: [
      { date: '2024-05-10', assetName: '多功能服(加厚)', assetType: '被装物资', reason: '损坏无法修复', approvalStatus: '已通过' },
      { date: '2024-06-16', assetName: '作训靴(3515)', assetType: '被装物资', reason: '技术淘汰', approvalStatus: '待提交' },
      { date: '2024-03-04', assetName: '消毒液', assetType: '办公设备', reason: '损坏无法修复', approvalStatus: '审批中' },
    ],
    transferRecords: [
      { date: '2024-06-25', assetName: '应急照明灯', fromUnit: '支队L', toUnit: '支队C', amount: 99, status: '已完成' },
      { date: '2024-02-28', assetName: '金属探测器', fromUnit: '支队L', toUnit: '支队C', amount: 27, status: '已完成' },
    ],
    supplierRecords: [
      { name: '联想(北京)有限公司', category: '办公设备', totalAmount: 242, orderCount: 16, rating: 4 },
      { name: '中航工业', category: '装备', totalAmount: 282, orderCount: 13, rating: 5 },
      { name: '摩托罗拉系统', category: '通信装备', totalAmount: 130, orderCount: 14, rating: 3 },
      { name: '大疆创新科技', category: '无人机', totalAmount: 209, orderCount: 13, rating: 5 },
      { name: '戴尔(中国)有限公司', category: '办公设备', totalAmount: 447, orderCount: 5, rating: 5 },
    ],
    usageHours: [
      { assetType: '装备', totalHours: 907, dailyAverage: 5.0, utilizationRate: 69 },
      { assetType: '应急物资', totalHours: 180, dailyAverage: 1.0, utilizationRate: 59 },
      { assetType: '被装物资', totalHours: 325, dailyAverage: 1.8, utilizationRate: 45 },
      { assetType: '办公设备', totalHours: 1778, dailyAverage: 9.9, utilizationRate: 84 },
      { assetType: '车辆', totalHours: 3355, dailyAverage: 18.6, utilizationRate: 78 },
    ],
    emergencyCategoryCoverageRate: 85,
    emergencyQuantityByCategory: [{ type: '防护用品', quantity: 200 }, { type: '急救药品', quantity: 155 }, { type: '照明设备', quantity: 130 }, { type: '通信设备', quantity: 85 }, { type: '食品饮水', quantity: 75 }, { type: '其他', quantity: 48 }],
    emergencyWarehouses: [{ name: '支队主库', value: 650 }, { name: '省会储备点', value: 570 }],
    emergencyAgencyStorage: [{ unitName: '支队L', value: 500 }, { unitName: '大队E', value: 420 }],
    emergencyRegionalCoverage: 86,
    officeDeviceDistributionPlan: { planned: 105, actual: 98 },
    officeDeviceDistributionByUnit: [{ unitName: '支队机关', planned: 35, actual: 33 }, { unitName: '直属中队', planned: 25, actual: 23 }, { unitName: '保障部门', planned: 20, actual: 18 }, { unitName: '其他', planned: 25, actual: 24 }],
    monthlyAssetData: [
      { month: '2024-07', equipment: 5297, emergency: 2126, clothing: 2512, office: 2639, vehicles: 3110 },
      { month: '2024-08', equipment: 5324, emergency: 1958, clothing: 2476, office: 2720, vehicles: 3056 },
      { month: '2024-09', equipment: 5090, emergency: 2149, clothing: 2569, office: 2841, vehicles: 3157 },
      { month: '2024-10', equipment: 4846, emergency: 2012, clothing: 2502, office: 2806, vehicles: 3028 },
      { month: '2024-11', equipment: 4807, emergency: 2004, clothing: 2454, office: 2984, vehicles: 3108 },
      { month: '2024-12', equipment: 4940, emergency: 2030, clothing: 2448, office: 2667, vehicles: 3061 },
      { month: '2025-01', equipment: 4807, emergency: 2154, clothing: 2682, office: 2720, vehicles: 3089 },
      { month: '2025-02', equipment: 4932, emergency: 2094, clothing: 2572, office: 2860, vehicles: 3117 },
      { month: '2025-03', equipment: 5312, emergency: 2186, clothing: 2642, office: 2912, vehicles: 3181 },
      { month: '2025-04', equipment: 4873, emergency: 2103, clothing: 2679, office: 2521, vehicles: 3223 },
      { month: '2025-05', equipment: 4819, emergency: 2135, clothing: 2339, office: 2941, vehicles: 3160 },
      { month: '2025-06', equipment: 5389, emergency: 2119, clothing: 2593, office: 2707, vehicles: 3363 },
    ],
  },
};

// ============================================================
// Personnel Data (人员结构与配置全景)
// ============================================================

export const personnelData: Record<string, PersonnelData> = {
  A: {
    unitId: 'A', totalPersonnel: 342, authorizedPositions: 350, staffingRate: 97.7,
    ageStructure: { under25: 28, age26to35: 125, age36to45: 118, age46to55: 58, over55: 13 },
    educationStructure: { doctor: 4, master: 38, bachelor: 210, college: 68, other: 22 },
    positionTypes: [
      { type: '指挥管理', authorized: 45, actual: 43, vacancyRate: 4.4 },
      { type: '专业技术', authorized: 120, actual: 118, vacancyRate: 1.7 },
      { type: '行政执法', authorized: 145, actual: 142, vacancyRate: 2.1 },
      { type: '后勤保障', authorized: 40, actual: 39, vacancyRate: 2.5 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '张明远', isVacant: false },
      { title: '资产管理', holder: '李秀华', isVacant: false },
      { title: '预算专员', holder: '王建国', isVacant: false },
      { title: '审计主管', holder: '陈晓红', isVacant: false },
      { title: '出纳', holder: null, isVacant: true, vacancyDays: 12 },
    ],
    avgYearsOfService: 12.5,
    personnelChange: 2.1,
  },
  B: {
    unitId: 'B', totalPersonnel: 278, authorizedPositions: 280, staffingRate: 99.3,
    ageStructure: { under25: 22, age26to35: 98, age36to45: 96, age46to55: 50, over55: 12 },
    educationStructure: { doctor: 3, master: 30, bachelor: 172, college: 55, other: 18 },
    positionTypes: [
      { type: '指挥管理', authorized: 36, actual: 36, vacancyRate: 0 },
      { type: '专业技术', authorized: 96, actual: 96, vacancyRate: 0 },
      { type: '行政执法', authorized: 116, actual: 115, vacancyRate: 0.9 },
      { type: '后勤保障', authorized: 32, actual: 31, vacancyRate: 3.1 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '刘志强', isVacant: false },
      { title: '资产管理', holder: '赵雪梅', isVacant: false },
      { title: '预算专员', holder: '孙伟', isVacant: false },
      { title: '审计主管', holder: '周丽华', isVacant: false },
      { title: '出纳', holder: '吴建东', isVacant: false },
    ],
    avgYearsOfService: 11.8,
    personnelChange: 1.5,
  },
  C: {
    unitId: 'C', totalPersonnel: 186, authorizedPositions: 195, staffingRate: 95.4,
    ageStructure: { under25: 18, age26to35: 72, age36to45: 60, age46to55: 28, over55: 8 },
    educationStructure: { doctor: 1, master: 18, bachelor: 108, college: 42, other: 17 },
    positionTypes: [
      { type: '指挥管理', authorized: 26, actual: 24, vacancyRate: 7.7 },
      { type: '专业技术', authorized: 64, actual: 62, vacancyRate: 3.1 },
      { type: '行政执法', authorized: 78, actual: 74, vacancyRate: 5.1 },
      { type: '后勤保障', authorized: 27, actual: 26, vacancyRate: 3.7 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '郑建国', isVacant: false },
      { title: '资产管理', holder: null, isVacant: true, vacancyDays: 28 },
      { title: '预算专员', holder: '黄丽华', isVacant: false },
      { title: '审计主管', holder: null, isVacant: true, vacancyDays: 45 },
      { title: '出纳', holder: '李明', isVacant: false },
    ],
    avgYearsOfService: 10.2,
    personnelChange: -1.2,
  },
  D: {
    unitId: 'D', totalPersonnel: 168, authorizedPositions: 170, staffingRate: 98.8,
    ageStructure: { under25: 14, age26to35: 62, age36to45: 58, age46to55: 28, over55: 6 },
    educationStructure: { doctor: 2, master: 16, bachelor: 98, college: 38, other: 14 },
    positionTypes: [
      { type: '指挥管理', authorized: 22, actual: 22, vacancyRate: 0 },
      { type: '专业技术', authorized: 58, actual: 57, vacancyRate: 1.7 },
      { type: '行政执法', authorized: 68, actual: 67, vacancyRate: 1.5 },
      { type: '后勤保障', authorized: 22, actual: 22, vacancyRate: 0 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '徐明远', isVacant: false },
      { title: '资产管理', holder: '林小红', isVacant: false },
      { title: '预算专员', holder: '朱建华', isVacant: false },
      { title: '审计主管', holder: '何美玲', isVacant: false },
      { title: '出纳', holder: '谢志强', isVacant: false },
    ],
    avgYearsOfService: 13.2,
    personnelChange: 0.8,
  },
  E: {
    unitId: 'E', totalPersonnel: 145, authorizedPositions: 160, staffingRate: 90.6,
    ageStructure: { under25: 10, age26to35: 48, age36to45: 52, age46to55: 28, over55: 7 },
    educationStructure: { doctor: 0, master: 10, bachelor: 78, college: 40, other: 17 },
    positionTypes: [
      { type: '指挥管理', authorized: 22, actual: 18, vacancyRate: 18.2 },
      { type: '专业技术', authorized: 52, actual: 48, vacancyRate: 7.7 },
      { type: '行政执法', authorized: 60, actual: 55, vacancyRate: 8.3 },
      { type: '后勤保障', authorized: 26, actual: 26, vacancyRate: 0 },
    ],
    keyPositions: [
      { title: '财务主管', holder: null, isVacant: true, vacancyDays: 62 },
      { title: '资产管理', holder: '罗建军', isVacant: false },
      { title: '预算专员', holder: null, isVacant: true, vacancyDays: 35 },
      { title: '审计主管', holder: '梁雪琴', isVacant: false },
      { title: '出纳', holder: '高志远', isVacant: false },
    ],
    avgYearsOfService: 14.8,
    personnelChange: -3.5,
  },
  F: {
    unitId: 'F', totalPersonnel: 134, authorizedPositions: 138, staffingRate: 97.1,
    ageStructure: { under25: 12, age26to35: 50, age36to45: 44, age46to55: 22, over55: 6 },
    educationStructure: { doctor: 1, master: 12, bachelor: 78, college: 32, other: 11 },
    positionTypes: [
      { type: '指挥管理', authorized: 18, actual: 18, vacancyRate: 0 },
      { type: '专业技术', authorized: 48, actual: 47, vacancyRate: 2.1 },
      { type: '行政执法', authorized: 52, actual: 50, vacancyRate: 3.8 },
      { type: '后勤保障', authorized: 20, actual: 19, vacancyRate: 5.0 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '方建国', isVacant: false },
      { title: '资产管理', holder: '唐丽娟', isVacant: false },
      { title: '预算专员', holder: '韩志强', isVacant: false },
      { title: '审计主管', holder: '冯秀英', isVacant: false },
      { title: '出纳', holder: '董明华', isVacant: false },
    ],
    avgYearsOfService: 11.5,
    personnelChange: 1.8,
  },
  G: {
    unitId: 'G', totalPersonnel: 118, authorizedPositions: 125, staffingRate: 94.4,
    ageStructure: { under25: 10, age26to35: 44, age36to45: 40, age46to55: 18, over55: 6 },
    educationStructure: { doctor: 0, master: 8, bachelor: 66, college: 30, other: 14 },
    positionTypes: [
      { type: '指挥管理', authorized: 16, actual: 15, vacancyRate: 6.3 },
      { type: '专业技术', authorized: 42, actual: 40, vacancyRate: 4.8 },
      { type: '行政执法', authorized: 48, actual: 45, vacancyRate: 6.3 },
      { type: '后勤保障', authorized: 19, actual: 18, vacancyRate: 5.3 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '潘国栋', isVacant: false },
      { title: '资产管理', holder: null, isVacant: true, vacancyDays: 18 },
      { title: '预算专员', holder: '蒋美华', isVacant: false },
      { title: '审计主管', holder: '蔡建明', isVacant: false },
      { title: '出纳', holder: null, isVacant: true, vacancyDays: 8 },
    ],
    avgYearsOfService: 12.8,
    personnelChange: -0.5,
  },
  H: {
    unitId: 'H', totalPersonnel: 82, authorizedPositions: 85, staffingRate: 96.5,
    ageStructure: { under25: 8, age26to35: 30, age36to45: 28, age46to55: 12, over55: 4 },
    educationStructure: { doctor: 0, master: 6, bachelor: 44, college: 22, other: 10 },
    positionTypes: [
      { type: '指挥管理', authorized: 12, actual: 12, vacancyRate: 0 },
      { type: '专业技术', authorized: 28, actual: 27, vacancyRate: 3.6 },
      { type: '行政执法', authorized: 32, actual: 31, vacancyRate: 3.1 },
      { type: '后勤保障', authorized: 13, actual: 12, vacancyRate: 7.7 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '贾丽华', isVacant: false },
      { title: '资产管理', holder: '魏建国', isVacant: false },
      { title: '预算专员', holder: '丁雪梅', isVacant: false },
      { title: '审计主管', holder: '叶志强', isVacant: false },
      { title: '出纳', holder: '余小红', isVacant: false },
    ],
    avgYearsOfService: 9.8,
    personnelChange: 2.5,
  },
  I: {
    unitId: 'I', totalPersonnel: 76, authorizedPositions: 78, staffingRate: 97.4,
    ageStructure: { under25: 6, age26to35: 28, age36to45: 26, age46to55: 12, over55: 4 },
    educationStructure: { doctor: 0, master: 5, bachelor: 42, college: 20, other: 9 },
    positionTypes: [
      { type: '指挥管理', authorized: 10, actual: 10, vacancyRate: 0 },
      { type: '专业技术', authorized: 26, actual: 26, vacancyRate: 0 },
      { type: '行政执法', authorized: 30, actual: 29, vacancyRate: 3.3 },
      { type: '后勤保障', authorized: 12, actual: 11, vacancyRate: 8.3 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '白玉兰', isVacant: false },
      { title: '资产管理', holder: '郝建军', isVacant: false },
      { title: '预算专员', holder: '孔雪琴', isVacant: false },
      { title: '审计主管', holder: '向国强', isVacant: false },
      { title: '出纳', holder: '齐美丽', isVacant: false },
    ],
    avgYearsOfService: 10.5,
    personnelChange: 1.2,
  },
  J: {
    unitId: 'J', totalPersonnel: 68, authorizedPositions: 72, staffingRate: 94.4,
    ageStructure: { under25: 5, age26to35: 24, age36to45: 24, age46to55: 12, over55: 3 },
    educationStructure: { doctor: 0, master: 4, bachelor: 36, college: 20, other: 8 },
    positionTypes: [
      { type: '指挥管理', authorized: 10, actual: 9, vacancyRate: 10.0 },
      { type: '专业技术', authorized: 24, actual: 23, vacancyRate: 4.2 },
      { type: '行政执法', authorized: 28, actual: 26, vacancyRate: 7.1 },
      { type: '后勤保障', authorized: 10, actual: 10, vacancyRate: 0 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '孟建国', isVacant: false },
      { title: '资产管理', holder: null, isVacant: true, vacancyDays: 22 },
      { title: '预算专员', holder: '龙丽华', isVacant: false },
      { title: '审计主管', holder: '万志强', isVacant: false },
      { title: '出纳', holder: '段小红', isVacant: false },
    ],
    avgYearsOfService: 11.2,
    personnelChange: -0.8,
  },
  K: {
    unitId: 'K', totalPersonnel: 62, authorizedPositions: 65, staffingRate: 95.4,
    ageStructure: { under25: 5, age26to35: 22, age36to45: 22, age46to55: 10, over55: 3 },
    educationStructure: { doctor: 0, master: 4, bachelor: 34, college: 18, other: 6 },
    positionTypes: [
      { type: '指挥管理', authorized: 9, actual: 9, vacancyRate: 0 },
      { type: '专业技术', authorized: 22, actual: 21, vacancyRate: 4.5 },
      { type: '行政执法', authorized: 26, actual: 25, vacancyRate: 3.8 },
      { type: '后勤保障', authorized: 8, actual: 7, vacancyRate: 12.5 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '常建华', isVacant: false },
      { title: '资产管理', holder: '樊美玲', isVacant: false },
      { title: '预算专员', holder: '施国栋', isVacant: false },
      { title: '审计主管', holder: '涂小丽', isVacant: false },
      { title: '出纳', holder: '焦志强', isVacant: false },
    ],
    avgYearsOfService: 12.2,
    personnelChange: 0.5,
  },
  L: {
    unitId: 'L', totalPersonnel: 98, authorizedPositions: 100, staffingRate: 98.0,
    ageStructure: { under25: 8, age26to35: 36, age36to45: 32, age46to55: 18, over55: 4 },
    educationStructure: { doctor: 1, master: 10, bachelor: 56, college: 22, other: 9 },
    positionTypes: [
      { type: '指挥管理', authorized: 14, actual: 14, vacancyRate: 0 },
      { type: '专业技术', authorized: 34, actual: 33, vacancyRate: 2.9 },
      { type: '行政执法', authorized: 38, actual: 37, vacancyRate: 2.6 },
      { type: '后勤保障', authorized: 14, actual: 14, vacancyRate: 0 },
    ],
    keyPositions: [
      { title: '财务主管', holder: '严国梁', isVacant: false },
      { title: '资产管理', holder: '温秀华', isVacant: false },
      { title: '预算专员', holder: '安志强', isVacant: false },
      { title: '审计主管', holder: '尹雪梅', isVacant: false },
      { title: '出纳', holder: '乔建国', isVacant: false },
    ],
    avgYearsOfService: 11.0,
    personnelChange: 1.5,
  },
};

// ============================================================
// Warning / Alert Items
// ============================================================

export const warningItems: WarningItem[] = [
  { id: 'w1', unitId: 'C', unitName: '支队C', type: 'budget', severity: 'warning', message: '预算执行率低于序时进度3.2%', timestamp: '10分钟前', panorama: 'economic' },
  { id: 'w2', unitId: 'E', unitName: '支队E', type: 'asset', severity: 'critical', message: '应急物资缺储2类', timestamp: '23分钟前', panorama: 'asset' },
  { id: 'w3', unitId: 'G', unitName: '支队E', type: 'personnel', severity: 'warning', message: '资产管理员岗位缺配', timestamp: '1小时前', panorama: 'personnel' },
  { id: 'w4', unitId: 'E', unitName: '支队E', type: 'budget', severity: 'critical', message: '预算执行率低于序时进度5.8%', timestamp: '1.5小时前', panorama: 'economic' },
  { id: 'w5', unitId: 'C', unitName: '支队C', type: 'asset', severity: 'critical', message: '通信设备储备不足（缺储12台）', timestamp: '2小时前', panorama: 'asset' },
  { id: 'w6', unitId: 'J', unitName: '大队C', type: 'asset', severity: 'warning', message: '救生衣缺储12件', timestamp: '3小时前', panorama: 'asset' },
  { id: 'w7', unitId: 'E', unitName: '支队E', type: 'financial', severity: 'critical', message: '资产负债率超过50%（52.8%）', timestamp: '3.5小时前', panorama: 'financial' },
  { id: 'w8', unitId: 'G', unitName: '支队E', type: 'budget', severity: 'warning', message: '预算执行率偏低（81.6%）', timestamp: '4小时前', panorama: 'economic' },
];

// ============================================================
// Aggregated Overview Stats
// ============================================================

export const panoramaOverview: PanoramaOverview = {
  economic: {
    totalBudget: 125400,
    totalExpenditure: 110150,
    avgExecutionRate: 86.2,
    totalProjects: 53,
    delayedProjects: 10,
    trend: [84.5, 85.1, 84.8, 85.6, 85.2, 85.8, 86.2],
  },
  financial: {
    avgDebtToAsset: 37.8,
    avgCurrentRatio: 1.92,
    avgRevenueExpenseRatio: 98.4,
    totalAssets: 167898,
    totalLiabilities: 56000,
    trend: [39.2, 38.8, 38.5, 38.2, 38.0, 37.9, 37.8],
  },
  asset: {
    totalAssetValue: 116473,
    totalEquipmentCount: 3456,
    avgUtilizationRate: 85.8,
    supplyShortageUnits: 4,
    trend: [108200, 109800, 110500, 112000, 113200, 114800, 116473],
  },
  personnel: {
    totalPersonnel: 1849,
    totalAuthorized: 1908,
    overallStaffingRate: 96.9,
    vacantPositions: 59,
    trend: [95.2, 95.8, 96.1, 96.3, 96.5, 96.7, 96.9],
  },
};

// ============================================================
// Utility Functions
// ============================================================

export function getUnitById(id: string): Unit | undefined {
  return units.find(u => u.id === id);
}

export function getUnitEconomicData(unitId: string): EconomicData | undefined {
  return economicData[unitId];
}

export function getUnitFinancialData(unitId: string): FinancialData | undefined {
  return financialData[unitId];
}

export function getUnitAssetData(unitId: string): AssetData | undefined {
  return assetData[unitId];
}

export function getUnitPersonnelData(unitId: string): PersonnelData | undefined {
  return personnelData[unitId];
}

export function getWarningsByUnit(unitId: string): WarningItem[] {
  return warningItems.filter(w => w.unitId === unitId);
}

export function getWarningsByPanorama(panorama: string): WarningItem[] {
  return warningItems.filter(w => w.panorama === panorama);
}

export function getStatusColor(status: UnitStatus): string {
  switch (status) {
    case 'normal': return '#00f5a0';
    case 'warning': return '#ffd166';
    case 'critical': return '#ff4757';
  }
}

export function getStatusText(status: UnitStatus): string {
  switch (status) {
    case 'normal': return '正常';
    case 'warning': return '预警';
    case 'critical': return '告警';
  }
}
