// ==================== 全局配置 ====================
const charts = {};
const initializedPages = { main: false, income: false, expense: false, sangong: false, purchase: false };

const commonTooltip = {
    backgroundColor: 'rgba(4, 12, 28, 0.98)',
    borderColor: 'rgba(0, 212, 255, 0.4)',
    textStyle: { color: '#e2e8f0', fontSize: 13 },
    padding: [12, 16],
    extraCssText: 'box-shadow: 0 4px 24px rgba(0,0,0,0.6); border-radius: 8px;'
};

function initChart(id, option) {
    var el = document.getElementById(id);
    if (!el) { console.warn('Chart element not found:', id); return null; }
    var w = el.clientWidth, h = el.clientHeight;
    if (w === 0 || h === 0) {
        console.warn('Chart container zero size:', id, w, h);
        return null;
    }
    var chart = echarts.init(el, 'dark');
    chart.setOption({backgroundColor:'transparent',...option});
    charts[id] = chart;
    return chart;
}

// ==================== 页面切换 ====================
function showPage(pageId) {
    document.querySelectorAll('.page, .detail-page, .panorama-page').forEach(function(p) {
        p.classList.remove('active');
    });
    var target = document.getElementById('page-' + pageId);
    if (target) target.classList.add('active');

    var sub = document.getElementById('pageSubtitle');
    var bc = document.getElementById('breadcrumb');
    var bcCurrent = document.getElementById('bcCurrent');
    var pageWrapper = document.querySelector('.page-wrapper');

    // 判断目标页面类型
    var isPanorama = target && target.classList.contains('panorama-page');
    var isDetail = target && target.classList.contains('detail-page');

    if (pageId === 'main') {
        sub.textContent = '经济运行全景';
        bc.style.display = 'none';
        if (pageWrapper) pageWrapper.style.display = '';
        document.querySelectorAll('.nav-tab').forEach(function(b, i) { b.classList.toggle('active', i === 0); });
    } else if (isPanorama) {
        // 全景页面：显示 page-wrapper，隐藏 breadcrumb
        sub.textContent = '详情';
        bc.style.display = 'none';
        if (pageWrapper) pageWrapper.style.display = '';
    } else {
        // 详情/下钻页面：隐藏 page-wrapper，显示 breadcrumb
        var titles = { income: '收入详情分析', expense: '支出详情分析', sangong: '三公经费详情', purchase: '采购合同执行分析' };
        sub.textContent = titles[pageId] || '详情';
        bc.style.display = 'block';
        bcCurrent.textContent = titles[pageId] || '详情';
        if (pageWrapper) pageWrapper.style.display = 'none';
    }

    document.body.offsetHeight;
    setTimeout(function() {
        initPageWithRetry(pageId, 0);
    }, 300);
}

function initPageWithRetry(pageId, attempt) {
    if (attempt > 10) {
        console.error('Failed to init charts after 10 retries for page:', pageId);
        return;
    }
    var allReady = true;
    var chartIds = getChartIdsForPage(pageId);
    for (var i = 0; i < chartIds.length; i++) {
        var el = document.getElementById(chartIds[i]);
        if (!el) continue;
        if (el.clientWidth === 0 || el.clientHeight === 0) {
            allReady = false;
            break;
        }
    }
    if (allReady) {
        if (!initializedPages[pageId]) {
            initPageCharts(pageId);
            initializedPages[pageId] = true;
        }
        setTimeout(function() {
            Object.values(charts).forEach(function(c) { c && c.resize(); });
        }, 100);
    } else {
        setTimeout(function() {
            initPageWithRetry(pageId, attempt + 1);
        }, 200);
    }
}

function getChartIdsForPage(pageId) {
    switch(pageId) {
        case 'main': return ['incomeStructure','incomeTrend','budgetChange','fujianMap','purchaseFunnel','expenseStructure','sanGong','expenseTrend'];
        case 'income': return ['incomeUnitRank','incomeYoY','incomeVolatility','incomeRatioTrend','budgetYearCompare'];
        case 'expense': return ['expenseYoY','expenseBudgetRate','expenseRatioTrend','unitExecRank','subjectExecCompare'];
        case 'sangong': return ['sgYearTrend','sgItemRatio','sgItemExec','sgReduceEffect'];
        case 'purchase': return ['contractPayRate','contractAcceptRate','overdueRate','warrantyRate'];
        case 'unit-detail': return ['chart-unit-progress','chart-unit-budgetvsfinal','chart-unit-projects','chart-unit-fundtype','chart-unit-yearly','chart-unit-deptpct','chart-unit-deptcompare'];
        case 'vehicle-gps': return [];
        case 'asset-usage': return ['chart-usage-heatmap','chart-supplier-rank','chart-asset-aging','chart-usage-rank'];
        case 'unit-asset-detail': return ['chart-uad-equip-pie','chart-uad-equip-percapita','chart-uad-emergency-pie','chart-uad-clothing-pie','chart-uad-clothing-age','chart-uad-office-pie'];
        default: return [];
    }
}

function switchNav(btn, page) {
    document.querySelectorAll('.nav-tab').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    var subtitles = {
        economic: '经济运行全景',
        financial: '财务全景',
        asset: '资产全景',
        personnel: '人员全景'
    };
    document.getElementById('pageSubtitle').textContent = subtitles[page] || '经济运行全景';

    document.querySelectorAll('.panorama-page, .detail-page, .page').forEach(function(p) {
        p.classList.remove('active');
    });

    var pageMap = {
        economic: 'page-main',
        financial: 'page-financial',
        asset: 'page-asset',
        personnel: 'page-personnel'
    };
    var target = document.getElementById(pageMap[page]);
    if (target) target.classList.add('active');

    document.getElementById('breadcrumb').style.display = 'none';

    if (page === 'asset' && !window.assetChartsInitialized) {
        setTimeout(function() { initAssetCharts(); window.assetChartsInitialized = true; }, 200);
    }
    if (page === 'financial' && !window.financialChartsInited) {
        setTimeout(function() { initFinancialCharts(); }, 200);
    }
    if (page === 'personnel' && !window.personnelChartsInited) {
        setTimeout(function() { initPersonnelCharts(); }, 200);
    }

    setTimeout(function() {
        Object.values(charts).forEach(function(c) { c && c.resize(); });
        if (window.assetCharts) {
            Object.values(window.assetCharts).forEach(function(c) { c && c.resize(); });
        }
        if (window.personnelCharts) {
            Object.values(window.personnelCharts).forEach(function(c) { c && c.resize(); });
        }
    }, 300);
}

// ==================== 单位经济运行详情 ====================
function showUnitDetail(unitName) {
    document.getElementById('unitDetailTitle').textContent = unitName + ' - 经济运行详情';
    window.currentUnitName = unitName;
    // 更新KPI数据（模拟数据，根据城市名生成确定性数据）
    var citySeed = unitName.charCodeAt(0) + unitName.charCodeAt(unitName.length - 1);
    var budget = 3000 + (citySeed % 70) * 100;
    var execRate = 55 + (citySeed % 35);
    var deviation = (execRate - 75).toFixed(1);
    var projects = 8 + (citySeed % 12);
    var projNormal = Math.floor(projects * 0.7);
    var projWarn = projects - projNormal;
    var personnelPct = 35 + (citySeed % 25);
    var personnelYoy = ((citySeed % 10) - 3).toFixed(1);
    var personnelYoySign = personnelYoy > 0 ? '+' : '';

    document.getElementById('ud-budget').textContent = budget.toLocaleString();
    document.getElementById('ud-execrate').textContent = execRate + '%';
    document.getElementById('ud-execrate').style.color = execRate >= 75 ? '#10b981' : execRate >= 60 ? '#fbbf24' : '#ef4444';
    document.getElementById('ud-deviation').textContent = (deviation > 0 ? '+' : '') + deviation + '%';
    document.getElementById('ud-deviation').style.color = deviation >= 0 ? '#10b981' : '#ef4444';
    document.getElementById('ud-projects').textContent = projects;
    document.getElementById('ud-proj-normal').textContent = projNormal;
    document.getElementById('ud-proj-warn').textContent = projWarn;
    document.getElementById('ud-personnelpct').textContent = personnelPct + '%';
    document.getElementById('ud-personnelyoy').textContent = personnelYoySign + personnelYoy + '%';
    document.getElementById('ud-personnelyoy').style.color = personnelYoy >= 0 ? '#10b981' : '#ef4444';

    // 显示页面
    document.querySelectorAll('.page, .detail-page, .panorama-page').forEach(function(p) { p.classList.remove('active'); });
    document.getElementById('page-unit-detail').classList.add('active');
    document.getElementById('breadcrumb').style.display = 'none';
    document.querySelector('.page-wrapper').style.display = 'none';

    // 强制浏览器重排，确保容器获得正确尺寸
    document.body.offsetHeight;

    // 初始化图表（使用重试机制确保容器已就绪）
    setTimeout(function() {
        initPageWithRetry('unit-detail', 0);
    }, 300);
}

function highlightUnit(unitName) {
    var mapChart = charts['fujianMap'];
    if (mapChart) {
        mapChart.dispatchAction({ type: 'highlight', seriesIndex: 0 });
        mapChart.dispatchAction({ type: 'showTip', seriesIndex: 0, name: unitName });
    }
}

// ==================== 分发器 ====================
function initPageCharts(pageId) {
    switch(pageId) {
        case 'main': initMainCharts(); break;
        case 'income': initIncomeCharts(); break;
        case 'expense': initExpenseCharts(); break;
        case 'sangong': initSangongCharts(); break;
        case 'purchase': initPurchaseCharts(); break;
        case 'unit-detail': initUnitDetailCharts(); break;
        case 'vehicle-gps': initVehicleGpsCharts(); break;
        case 'asset-usage': initAssetUsageCharts(); break;
        case 'unit-asset-detail': initUnitAssetDetailCharts(); break;
    }
}

// ==================== 响应式 & 时钟 ====================
window.addEventListener('resize', function() {
    Object.values(charts).forEach(function(c) { c && c.resize(); });
    if (window.assetCharts) {
        Object.values(window.assetCharts).forEach(function(c) { c && c.resize(); });
    }
    if (window.personnelCharts) {
        Object.values(window.personnelCharts).forEach(function(c) { c && c.resize(); });
    }
});

setInterval(function() {
    var now = new Date();
    document.getElementById('headerTime').textContent = '\uD83D\uDD50 ' + now.toTimeString().split(' ')[0];
    document.getElementById('headerDate').textContent = '\uD83D\uDCC5 ' + now.toISOString().split('T')[0];
}, 1000);

// ==================== 页面加载 ====================
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        initPageCharts('main');
        initializedPages.main = true;
    }, 300);
});
