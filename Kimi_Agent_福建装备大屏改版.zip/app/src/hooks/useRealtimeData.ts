import { useState, useEffect, useCallback } from 'react';

export interface EquipmentData {
  totalCount: number;
  categoryDistribution: { name: string; value: number }[];
  inStockCount: number;
  outStockCount: number;
  inStockPercent: number;
  outStockPercent: number;
}

export interface AnalysisData {
  expiredCount: number;
  expiredPercent: number;
  nearScrapCount: number;
  nearScrapPercent: number;
  inUseCount: number;
  inUsePercent: number;
  maintenanceCount: number;
  maintenancePercent: number;
  topUsedEquipment: { name: string; count: number }[];
}

export interface DistributionData {
  totalInventory: number;
  generalCount: number;
  emergencyCount: number;
  cityDistribution: { city: string; general: number; emergency: number; total: number }[];
}

export interface BusinessEvent {
  id: string;
  type: 'purchase' | 'inbound' | 'daily_transfer' | 'outbound';
  location: string;
  time: string;
  summary: string;
  orderNo: string;
  coords: [number, number];
  equipment?: string;
  quantity?: number;
}

export interface WarningItem {
  id: string;
  warehouse: string;
  equipment: string;
  currentStock: number;
  safeStock: number;
  level: 'general' | 'severe' | 'critical';
  gap: number;
  coords: [number, number];
}

export interface RankItem {
  district: string;
  generalCount: number;
  emergencyCount: number;
  total: number;
}

export interface ExpiredItem {
  name: string;
  unit: string;
  equipment: string;
  count: number;
  days: number;
  level: 'normal' | 'warning' | 'critical';
}

export interface EquipmentUsage {
  today: { name: string; count: number }[];
  month: { name: string; count: number }[];
  year: { name: string; count: number }[];
}

export interface EnvDevice {
  name: string;
  icon: string;
  total: number;
  online: number;
  status: 'normal' | 'warning' | 'offline';
}

// ===== 8.2 应急事件相关接口 =====
export type EmergencyType = 'terrorist' | 'criminal' | 'mass' | 'disaster' | 'security' | 'checkpoint';
export type EmergencyLevel = 'general' | 'severe' | 'critical';
export type EmergencyStatus = 'reported' | 'analyzing' | 'dispatched' | 'coordinating' | 'resolved';

export interface EmergencyEvent {
  id: string;
  type: EmergencyType;
  level: EmergencyLevel;
  location: string;
  address: string;
  lat: number;
  lng: number;
  time: string;
  status: EmergencyStatus;
  description: string;
}

export interface RecommendedEquipment {
  name: string;
  spec: string;
  quantity: number;
  reason: string;
}

export interface EmergencyAnalysis {
  eventId: string;
  eventType: EmergencyType;
  eventLevel: EmergencyLevel;
  analysisTime: string;
  recommendations: RecommendedEquipment[];
}

export interface WarehouseFulfillment {
  warehouseId: string;
  warehouseName: string;
  distance: number;
  equipment: { name: string; available: number; needed: number }[];
  fulfillmentRate: number;
}

export interface EquipmentDistribution {
  centerLat: number;
  centerLng: number;
  radius: number;
  warehouses: WarehouseFulfillment[];
  overallFulfillment: number;
  isSufficient: boolean;
}

export interface TransferPlan {
  sourceWarehouse: string;
  targetLocation: string;
  equipment: { name: string; quantity: number }[];
  estimatedArrival: string;
  orderNo: string;
}

export interface TransferScheme {
  name: string;
  strategy: string;
  plans: TransferPlan[];
  totalTime: number;
  totalWarehouses: number;
}

export interface LinkedWarehouse {
  id: string;
  name: string;
  distance: number;
  equipment: { name: string; quantity: number }[];
  estimatedTransportTime: number;
}

export interface StrategyOption {
  id: string;
  sources: { warehouse: string; quantity: number; equipment: string }[];
  totalTime: number;
  totalCost: number;
  riskScore: number;
  isOptimal: boolean;
}

const EMERGENCY_TYPE_LABELS: Record<EmergencyType, string> = {
  terrorist: '暴力恐怖袭击',
  criminal: '重大恶性刑事案件',
  mass: '群体性事件',
  disaster: '自然灾害应急救援',
  security: '大型活动安保',
  checkpoint: '临时设卡盘查',
};

const EMERGENCY_TYPE_ICONS: Record<EmergencyType, string> = {
  terrorist: '⚡', criminal: '🔒', mass: '👥', disaster: '🌊', security: '🛡️', checkpoint: '🚧',
};

const EQUIPMENT_CATEGORIES = ['防护装备', '救援装备', '通讯装备', '侦测装备', '照明装备', '破拆装备', '救生装备', '医疗装备'];

export const CITIES = [
  '省本级', '福州市', '厦门市', '莆田市', '三明市', '泉州市',
  '漳州市', '南平市', '龙岩市', '宁德市', '平潭综合实验区'
];

export const CITY_DISTRICTS: Record<string, string[]> = {
  '福州市': ['鼓楼区', '台江区', '仓山区', '晋安区', '马尾区', '长乐区', '闽侯县', '连江县', '罗源县', '闽清县', '永泰县', '福清市', '平潭县'],
  '厦门市': ['思明区', '海沧区', '湖里区', '集美区', '同安区', '翔安区'],
  '莆田市': ['城厢区', '涵江区', '荔城区', '秀屿区', '仙游县'],
  '三明市': ['三元区', '沙县区', '明溪县', '清流县', '宁化县', '大田县', '尤溪县', '将乐县', '泰宁县', '建宁县', '永安市'],
  '泉州市': ['丰泽区', '鲤城区', '洛江区', '泉港区', '晋江市', '石狮市', '南安市', '惠安县', '安溪县', '永春县', '德化县'],
  '漳州市': ['芗城区', '龙文区', '龙海区', '长泰区', '云霄县', '漳浦县', '诏安县', '东山县', '南靖县', '平和县', '华安县'],
  '南平市': ['延平区', '建阳区', '邵武市', '武夷山市', '建瓯市', '顺昌县', '浦城县', '光泽县', '松溪县', '政和县'],
  '龙岩市': ['新罗区', '永定区', '长汀县', '上杭县', '武平县', '连城县', '漳平市'],
  '宁德市': ['蕉城区', '福安市', '福鼎市', '霞浦县', '古田县', '屏南县', '寿宁县', '周宁县', '柘荣县'],
  '平潭综合实验区': ['平潭综合实验区'],
};

// 城市对应的SVG坐标（与CenterMap一致）
const CITY_SVG_COORDS: Record<string, { x: number; y: number }> = {
  '福州市': { x: 720, y: 350 }, '厦门市': { x: 510, y: 580 }, '莆田市': { x: 620, y: 460 },
  '三明市': { x: 380, y: 370 }, '泉州市': { x: 520, y: 530 }, '漳州市': { x: 420, y: 620 },
  '南平市': { x: 480, y: 220 }, '龙岩市': { x: 280, y: 540 }, '宁德市': { x: 780, y: 260 },
  '平潭综合实验区': { x: 790, y: 400 },
  '连江县': { x: 810, y: 310 },
  '省本级': { x: 600, y: 300 },
};

const EQUIPMENT_NAMES = [
  '防爆头盔', '空气呼吸器', '液压破拆钳', '生命探测仪', '红外热像仪',
  '有毒气体检测仪', '机动链锯', '救生抛投器', '移动照明灯组', '救援三脚架',
  '防火服', '防化服', '救生绳', '救援担架', '手持对讲机',
  '卫星电话', '无人机', '雷达探测仪', '切割锯', '千斤顶'
];

function rand(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function clampPercent(value: number): number {
  return Math.min(100, Math.max(0, parseFloat(value.toFixed(2))));
}

function generateUsageData(): EquipmentUsage {
  const names = ['防爆头盔', '空气呼吸器', '液压破拆钳', '生命探测仪', '红外热像仪', '有毒气体检测仪', '机动链锯', '救生抛投器', '移动照明灯组', '救援三脚架'];
  return {
    today: names.map(name => ({ name, count: rand(5, 45) })).sort((a, b) => b.count - a.count),
    month: names.map(name => ({ name, count: rand(120, 890) })).sort((a, b) => b.count - a.count),
    year: names.map(name => ({ name, count: rand(1500, 9800) })).sort((a, b) => b.count - a.count),
  };
}

// ===== 生成环境设备数据 =====
function generateEnvDevices(): EnvDevice[] {
  const devices = [
    { name: '温湿度仪器', icon: '🌡️', total: rand(60, 120) },
    { name: '除湿机', icon: '❄️', total: rand(80, 140) },
    { name: '精密空调', icon: '🌀', total: rand(40, 90) },
    { name: '水浸报警器', icon: '💧', total: rand(30, 70) },
  ];
  return devices.map((d, i) => {
    const onlineRate = i === 3 ? rand(80, 92) : rand(88, 98); // 水浸报警器略低
    const online = Math.round(d.total * onlineRate / 100);
    const status: EnvDevice['status'] = i === 3 && Math.random() > 0.6 ? 'warning' : 'normal';
    return { ...d, online, status };
  });
}

function generateCityDistribution() {
  return CITIES.map(city => {
    const isProvincial = city === '省本级';
    const general = isProvincial ? rand(35000, 55000) : rand(5000, 25000);
    const emergency = isProvincial ? rand(18000, 28000) : rand(2000, 12000);
    return { city, general, emergency, total: general + emergency };
  });
}

// ===== 生成应急事件 =====
// 只保留群体事件为当前事件，其余为历史事件
function generateEmergencyEvents(count: number): EmergencyEvent[] {
  const types: EmergencyType[] = ['terrorist', 'criminal', 'mass', 'disaster', 'security', 'checkpoint'];
  const levels: EmergencyLevel[] = ['general', 'severe', 'critical'];
  const addresses = ['中山路128号', '建设大道56号', '学府路89号', '工业路33号', '人民公园东侧', '火车站南广场', '港口码头A区', '高速出口K23', '化工厂区B栋', '商业街中段'];
  const descs = ['接到群众报警，现场有不明身份人员持械', '发生重大刑事案件，嫌疑人已逃离现场', '现场聚集大量人员，秩序混乱', '突发自然灾害，需紧急救援力量', '大型活动现场人流密集，需加强安保', '设卡盘查中，发现可疑人员和车辆'];

  return Array.from({ length: count }, (_, i) => {
    // 第1个为群体事件（当前活跃，位于连江县），其余为历史事件
    const isActive = i === 0;
    const type = isActive ? 'mass' : types[i % types.length];
    const level = isActive ? 'critical' : levels[rand(0, levels.length - 1)];
    const status: EmergencyStatus = isActive ? 'dispatched' : 'resolved';
    const city = isActive ? '连江县' : CITIES[rand(0, CITIES.length - 1)];
    const coords = CITY_SVG_COORDS[city] || CITY_SVG_COORDS['福州市'];
    const offsetX = isActive ? rand(-30, 30) : rand(-60, 60);
    const offsetY = isActive ? rand(-20, 20) : rand(-40, 40);

    return {
      id: `EMG${Date.now()}${i}`,
      type,
      level,
      location: city,
      address: addresses[rand(0, addresses.length - 1)],
      lat: coords.x + offsetX,
      lng: coords.y + offsetY,
      time: new Date(Date.now() - rand(0, isActive ? 600000 : 86400000)).toLocaleTimeString('zh-CN', { hour12: false }),
      status,
      description: isActive ? '现场聚集大量人员，秩序混乱，需紧急处置' : descs[rand(0, descs.length - 1)],
    };
  });
}

// ===== 生成装备分析 =====
function generateAnalysis(event: EmergencyEvent): EmergencyAnalysis {
  const equipMap: Record<EmergencyType, RecommendedEquipment[]> = {
    terrorist: [{ name: '防弹背心', spec: '三级防护', quantity: rand(15, 40), reason: '应对持械攻击' }, { name: '防暴盾牌', spec: '透明聚碳酸酯', quantity: rand(10, 30), reason: '近距离防护' }, { name: '手持对讲机', spec: '数字加密', quantity: rand(8, 20), reason: '现场通讯协同' }],
    criminal: [{ name: '手持对讲机', spec: '数字加密', quantity: rand(6, 15), reason: '追捕通讯' }, { name: '红外热像仪', spec: '手持式', quantity: rand(3, 8), reason: '夜间搜捕' }, { name: '无人机', spec: '四旋翼侦察', quantity: rand(2, 6), reason: '空中侦察追踪' }],
    mass: [{ name: '防暴盾牌', spec: '组合式', quantity: rand(20, 50), reason: '人群隔离防护' }, { name: '手持对讲机', spec: '集群调度', quantity: rand(15, 30), reason: '多单位协同' }, { name: '移动照明灯组', spec: 'LED 500W', quantity: rand(4, 10), reason: '夜间现场照明' }],
    disaster: [{ name: '液压破拆钳', spec: '双管扩张', quantity: rand(4, 12), reason: '废墟破拆救援' }, { name: '生命探测仪', spec: '雷达式', quantity: rand(3, 8), reason: '被困人员定位' }, { name: '救援担架', spec: '折叠式', quantity: rand(8, 20), reason: '伤员转运' }],
    security: [{ name: '手持对讲机', spec: '集群调度', quantity: rand(20, 40), reason: '多点位通讯' }, { name: '金属探测仪', spec: '门架式', quantity: rand(2, 6), reason: '安检排爆' }, { name: '有毒气体检测仪', spec: '便携式', quantity: rand(4, 10), reason: '环境监测' }],
    checkpoint: [{ name: '手持对讲机', spec: '数字加密', quantity: rand(6, 15), reason: '卡点通讯' }, { name: '阻车器', spec: '液压全自动', quantity: rand(2, 6), reason: '强制拦截' }, { name: '有毒气体检测仪', spec: '多合一', quantity: rand(2, 6), reason: '危险品查验' }],
  };

  return {
    eventId: event.id,
    eventType: event.type,
    eventLevel: event.level,
    analysisTime: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
    recommendations: equipMap[event.type] || equipMap.terrorist,
  };
}

// ===== 生成装备分布分析（模拟多仓库联合调度：部分物资不足） =====
function generateDistribution(event: EmergencyEvent): EquipmentDistribution {
  // 连江县周边2-3个装备库，距离固定合理值
  const warehouseNames = ['连江中心储备库', '马尾应急保障仓', '福清物资调拨库'];
  const distances = [5, 40, 25]; // km
  const radius = 50;
  // 获取该事件类型对应的推荐装备列表（与自动分析一致）
  const analysis = generateAnalysis(event);
  const recommendedEquip = analysis.recommendations;

  // 为每个仓库分配不同的库存（模拟部分物资不足）
  const stockRatios = [
    { name: '连江中心储备库', ratios: [0.9, 0.8, 0.5] },   // 最近，库存较充足
    { name: '马尾应急保障仓', ratios: [0.3, 1.1, 1.0] },    // 较远，部分装备充足
    { name: '福清物资调拨库', ratios: [0.4, 0.4, 0.6] },    // 中等距离，库存一般
  ];

  const warehouses: WarehouseFulfillment[] = stockRatios.map((sr, idx) => {
    const equipList = recommendedEquip.map((eq, j) => {
      const ratio = sr.ratios[j] || 0.5;
      const available = Math.max(0, Math.round(eq.quantity * ratio));
      return {
        name: eq.name,
        available,
        needed: eq.quantity,
      };
    });
    const totalNeeded = equipList.reduce((s, e) => s + e.needed, 0);
    const totalAvailable = equipList.reduce((s, e) => s + e.available, 0);
    return {
      warehouseId: `WH${rand(100, 999)}`,
      warehouseName: warehouseNames[idx],
      distance: distances[idx],
      equipment: equipList,
      fulfillmentRate: totalNeeded > 0 ? Math.min(100, Math.round((totalAvailable / totalNeeded) * 100)) : 0,
    };
  });

  const overall = Math.round(warehouses.reduce((s, w) => s + w.fulfillmentRate, 0) / warehouses.length);

  return {
    centerLat: event.lat,
    centerLng: event.lng,
    radius,
    warehouses,
    overallFulfillment: overall,
    isSufficient: false, // 联合调度场景：单个仓库不足，需要多仓联合
  };
}

// ===== 生成3种调拨方案（多仓库联合调度） =====
function generateTransferSchemes(event: EmergencyEvent, distribution: EquipmentDistribution): TransferScheme[] {
  // 收集所有仓库的可用装备
  const allEquip: Record<string, { needed: number; sources: { warehouse: string; qty: number }[] }> = {};
  distribution.warehouses.forEach(w => {
    w.equipment.forEach(eq => {
      if (!allEquip[eq.name]) {
        allEquip[eq.name] = { needed: eq.needed, sources: [] };
      }
      if (eq.available > 0) {
        allEquip[eq.name].sources.push({ warehouse: w.warehouseName, qty: eq.available });
      }
    });
  });

  const makePlan = (eqName: string, warehouse: string, qty: number, arrival: number, orderNo: string): TransferPlan => ({
    sourceWarehouse: warehouse,
    targetLocation: `${event.location}${event.address}`,
    equipment: [{ name: eqName, quantity: qty }],
    estimatedArrival: `${arrival}分钟`,
    orderNo,
  });

  // 方案A：时间优先 - 从距离最近的仓库取（sources按距离排序，取前1-2个）
  const planA: TransferPlan[] = [];
  Object.entries(allEquip).forEach(([eqName, data]) => {
    let remaining = data.needed;
    const sorted = [...data.sources].sort(() => Math.random() - 0.5); // 模拟距离优先
    sorted.forEach(src => {
      if (remaining <= 0) return;
      const take = Math.min(src.qty, remaining);
      planA.push(makePlan(eqName, src.warehouse, take, rand(15, 40), `A-${rand(10000, 99999)}`));
      remaining -= take;
    });
  });

  // 方案B：集中优先 - 优先从单个大仓库取，减少调度复杂度
  const planB: TransferPlan[] = [];
  Object.entries(allEquip).forEach(([eqName, data]) => {
    let remaining = data.needed;
    const sorted = [...data.sources].sort((a, b) => b.qty - a.qty);
    let warehouseCount = 0;
    sorted.forEach(src => {
      if (remaining <= 0 || warehouseCount >= 2) return;
      const take = Math.min(src.qty, remaining);
      planB.push(makePlan(eqName, src.warehouse, take, rand(25, 55), `B-${rand(10000, 99999)}`));
      remaining -= take;
      warehouseCount++;
    });
  });

  // 方案C：均衡方案 - 从多个仓库均匀分配
  const planC: TransferPlan[] = [];
  Object.entries(allEquip).forEach(([eqName, data]) => {
    let remaining = data.needed;
    const sorted = [...data.sources].filter(s => s.qty > 0).sort(() => Math.random() - 0.5);
    sorted.forEach(src => {
      if (remaining <= 0) return;
      const take = Math.min(Math.ceil(src.qty * 0.7), remaining, Math.max(1, Math.ceil(data.needed / sorted.length)));
      planC.push(makePlan(eqName, src.warehouse, take, rand(20, 50), `C-${rand(10000, 99999)}`));
      remaining -= take;
    });
  });

  return [
    { name: '方案A', strategy: '时间优先', plans: planA.slice(0, 8), totalTime: Math.max(...planA.map(p => parseInt(p.estimatedArrival))), totalWarehouses: new Set(planA.map(p => p.sourceWarehouse)).size },
    { name: '方案B', strategy: '集中优先', plans: planB.slice(0, 8), totalTime: Math.max(...planB.map(p => parseInt(p.estimatedArrival))), totalWarehouses: new Set(planB.map(p => p.sourceWarehouse)).size },
    { name: '方案C', strategy: '均衡调度', plans: planC.slice(0, 8), totalTime: Math.max(...planC.map(p => parseInt(p.estimatedArrival))), totalWarehouses: new Set(planC.map(p => p.sourceWarehouse)).size },
  ];
}

// ===== 生成联动仓库 =====
function generateLinkedWarehouses(_event: EmergencyEvent): LinkedWarehouse[] {
  const names = ['泉州应急储备库', '莆田物资中心', '南平战备仓库', '龙岩后勤基地', '宁德港口仓'];
  return names.map(name => ({
    id: `LK${rand(100, 999)}`,
    name,
    distance: rand(50, 200),
    equipment: EQUIPMENT_NAMES.slice(0, 4).map(n => ({ name: n, quantity: rand(20, 100) })),
    estimatedTransportTime: rand(60, 240),
  }));
}

// ===== 生成调拨策略 =====
function generateStrategies(): StrategyOption[] {
  return [
    { id: 'S1', sources: [{ warehouse: '就近仓A', quantity: rand(20, 50), equipment: '防火服' }, { warehouse: '就近仓A', quantity: rand(10, 30), equipment: '呼吸器' }], totalTime: rand(20, 40), totalCost: rand(5000, 15000), riskScore: rand(15, 35), isOptimal: true },
    { id: 'S2', sources: [{ warehouse: '就近仓A', quantity: rand(15, 40), equipment: '防火服' }, { warehouse: '联动仓B', quantity: rand(15, 35), equipment: '呼吸器' }], totalTime: rand(35, 60), totalCost: rand(8000, 20000), riskScore: rand(20, 40), isOptimal: false },
    { id: 'S3', sources: [{ warehouse: '联动仓B', quantity: rand(30, 60), equipment: '防火服' }, { warehouse: '联动仓C', quantity: rand(20, 40), equipment: '呼吸器' }], totalTime: rand(50, 90), totalCost: rand(12000, 30000), riskScore: rand(25, 50), isOptimal: false },
  ];
}

export { EMERGENCY_TYPE_LABELS, EMERGENCY_TYPE_ICONS };

export function useRealtimeData() {
  const [equipment, setEquipment] = useState<EquipmentData>({
    totalCount: 156820,
    categoryDistribution: EQUIPMENT_CATEGORIES.map(name => ({ name, value: rand(8000, 25000) })),
    inStockCount: 128450,
    outStockCount: 28370,
    inStockPercent: 81.9,
    outStockPercent: 18.1,
  });

  const [analysis, setAnalysis] = useState<AnalysisData>({
    expiredCount: 342,
    expiredPercent: 0.22,
    nearScrapCount: 1280,
    nearScrapPercent: 0.82,
    inUseCount: 23450,
    inUsePercent: 14.96,
    maintenanceCount: 1856,
    maintenancePercent: 1.18,
    topUsedEquipment: EQUIPMENT_NAMES.slice(0, 10).map(name => ({ name, count: rand(120, 890) })),
  });

  const [distribution, setDistribution] = useState<DistributionData>({
    totalInventory: 156820,
    generalCount: 102450,
    emergencyCount: 54370,
    cityDistribution: generateCityDistribution(),
  });

  const [events, setEvents] = useState<BusinessEvent[]>([]);
  const [warnings, setWarnings] = useState<WarningItem[]>([]);
  const [ranks, setRanks] = useState<RankItem[]>([]);
  const [usage, setUsage] = useState<EquipmentUsage>(generateUsageData());
  const [expiredByUnit, setExpiredByUnit] = useState<ExpiredItem[]>([]);
  const [expiredByEquip, setExpiredByEquip] = useState<ExpiredItem[]>([]);

  // 8.2 应急事件状态
  const [emergencyEvents, setEmergencyEvents] = useState<EmergencyEvent[]>([]);
  const [emergencyAnalyses, setEmergencyAnalyses] = useState<Record<string, EmergencyAnalysis>>({});
  const [emergencyDistributions, setEmergencyDistributions] = useState<Record<string, EquipmentDistribution>>({});
  const [emergencyTransfers, setEmergencyTransfers] = useState<Record<string, TransferScheme[]>>({});
  const [emergencyLinked, setEmergencyLinked] = useState<Record<string, LinkedWarehouse[]>>({});
  const [emergencyStrategies, setEmergencyStrategies] = useState<Record<string, StrategyOption[]>>({});
  const [envDevices] = useState<EnvDevice[]>(generateEnvDevices());

  const generateEvent = useCallback((): BusinessEvent => {
    const types: BusinessEvent['type'][] = ['purchase', 'inbound', 'daily_transfer', 'outbound'];
    const type = types[rand(0, 3)];
    const summaries: Record<string, string> = { purchase: '装备采购', inbound: '装备入库', daily_transfer: '日常调拨', outbound: '应急调拨' };
    return {
      id: `EVT${Date.now()}${rand(1000, 9999)}`, type,
      location: CITIES[rand(0, CITIES.length - 1)],
      time: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
      summary: summaries[type], orderNo: `ORD${rand(100000, 999999)}`,
      coords: [rand(116, 120) + Math.random(), rand(23, 28) + Math.random()],
      equipment: EQUIPMENT_NAMES[rand(0, EQUIPMENT_NAMES.length - 1)],
      quantity: rand(5, 200),
    };
  }, []);

  const generateWarnings = useCallback((): WarningItem[] => {
    return Array.from({ length: rand(5, 8) }, (_, i) => {
      const safeStock = rand(100, 500);
      const currentStock = rand(20, Math.floor(safeStock * 0.8));
      const gap = safeStock - currentStock;
      let level: WarningItem['level'] = 'general';
      if (gap > safeStock * 0.5) level = 'critical';
      else if (gap > safeStock * 0.3) level = 'severe';
      return { id: `WRN${Date.now()}${i}`, warehouse: CITIES[rand(0, CITIES.length - 1)] + '仓库', equipment: EQUIPMENT_NAMES[rand(0, EQUIPMENT_NAMES.length - 1)], currentStock, safeStock, level, gap, coords: [rand(116, 120) + Math.random(), rand(23, 28) + Math.random()] };
    });
  }, []);

  const generateCityRanks = useCallback((): RankItem[] => {
    return CITIES.map(city => {
      const isProvincial = city === '省本级';
      const generalCount = isProvincial ? rand(25000, 45000) : rand(3000, 15000);
      const emergencyCount = isProvincial ? rand(12000, 22000) : rand(1500, 8000);
      return { district: city, generalCount, emergencyCount, total: generalCount + emergencyCount };
    }).sort((a, b) => b.total - a.total);
  }, []);

  const generateDistrictRanks = useCallback((city: string): RankItem[] => {
    const districts = CITY_DISTRICTS[city] || [city];
    return districts.map(district => {
      const generalCount = rand(500, 5000);
      const emergencyCount = rand(200, 2000);
      return { district, generalCount, emergencyCount, total: generalCount + emergencyCount };
    }).sort((a, b) => b.total - a.total);
  }, []);

  // 生成过期装备数据（按单位维度）
  const generateExpiredByUnit = useCallback((): ExpiredItem[] => {
    const equipNames = ['防爆头盔', '空气呼吸器', '液压破拆钳', '生命探测仪', '红外热像仪', '有毒气体检测仪', '机动链锯', '救生抛投器', '移动照明灯组', '救援三脚架', '防火服', '防化服', '救生绳', '救援担架', '手持对讲机'];
    return CITIES.filter(c => c !== '省本级').map((city, i) => ({
      name: city,
      unit: city + '仓库',
      equipment: equipNames[i % equipNames.length],
      count: rand(15, 280),
      days: rand(30, 730),
      level: (['normal', 'warning', 'critical'] as const)[rand(0, 2)],
    })).sort((a, b) => b.count - a.count);
  }, []);

  // 生成过期装备数据（按装备维度）
  const generateExpiredByEquip = useCallback((): ExpiredItem[] => {
    const equipNames = ['防爆头盔', '空气呼吸器', '液压破拆钳', '生命探测仪', '红外热像仪', '有毒气体检测仪', '机动链锯', '救生抛投器', '移动照明灯组', '救援三脚架'];
    return equipNames.map((name, i) => ({
      name,
      unit: CITIES[i % CITIES.length] + '仓库',
      equipment: name,
      count: rand(50, 450),
      days: rand(60, 540),
      level: (['normal', 'warning', 'critical'] as const)[rand(0, 2)],
    })).sort((a, b) => b.count - a.count);
  }, []);

  // 初始化
  useEffect(() => {
    setRanks(generateCityRanks());
    setWarnings(generateWarnings());
    setEvents(Array.from({ length: 8 }, generateEvent));
    setExpiredByUnit(generateExpiredByUnit());
    setExpiredByEquip(generateExpiredByEquip());

    // 初始化应急事件
    const initEvents = generateEmergencyEvents(6);
    setEmergencyEvents(initEvents);

    // 为每个事件生成分析数据
    const analyses: Record<string, EmergencyAnalysis> = {};
    const distributions: Record<string, EquipmentDistribution> = {};
    const transfers: Record<string, TransferScheme[]> = {};
    const linked: Record<string, LinkedWarehouse[]> = {};
    const strategies: Record<string, StrategyOption[]> = {};

    initEvents.forEach(evt => {
      analyses[evt.id] = generateAnalysis(evt);
      const dist = generateDistribution(evt);
      distributions[evt.id] = dist;
      transfers[evt.id] = generateTransferSchemes(evt, dist);
      linked[evt.id] = generateLinkedWarehouses(evt);
      strategies[evt.id] = generateStrategies();
    });

    setEmergencyAnalyses(analyses);
    setEmergencyDistributions(distributions);
    setEmergencyTransfers(transfers);
    setEmergencyLinked(linked);
    setEmergencyStrategies(strategies);
  }, []);

  // 定时刷新
  useEffect(() => {
    const interval = setInterval(() => {
      setEquipment(prev => {
        const totalCount = Math.max(100000, prev.totalCount + rand(-50, 80));
        const inStockCount = Math.max(50000, prev.inStockCount + rand(-30, 50));
        const outStockCount = Math.max(10000, prev.outStockCount + rand(-20, 30));
        return { ...prev, totalCount, inStockCount, outStockCount, inStockPercent: clampPercent((inStockCount / totalCount) * 100), outStockPercent: clampPercent((outStockCount / totalCount) * 100), categoryDistribution: prev.categoryDistribution.map(cat => ({ ...cat, value: Math.max(1000, cat.value + rand(-200, 300)) })) };
      });

      setAnalysis(prev => {
        const expiredCount = Math.max(0, prev.expiredCount + rand(-8, 12));
        const nearScrapCount = Math.max(0, prev.nearScrapCount + rand(-20, 30));
        const inUseCount = Math.max(0, prev.inUseCount + rand(-80, 120));
        const maintenanceCount = Math.max(0, prev.maintenanceCount + rand(-15, 25));
        const totalCount = equipment.totalCount || 156820;
        return { ...prev, expiredCount, expiredPercent: clampPercent((expiredCount / totalCount) * 100), nearScrapCount, nearScrapPercent: clampPercent((nearScrapCount / totalCount) * 100), inUseCount, inUsePercent: clampPercent((inUseCount / totalCount) * 100), maintenanceCount, maintenancePercent: clampPercent((maintenanceCount / totalCount) * 100) };
      });

      setDistribution(prev => {
        const cityDist = prev.cityDistribution.map(c => ({ ...c, general: Math.max(1000, c.general + rand(-200, 300)), emergency: Math.max(500, c.emergency + rand(-100, 200)) })).map(c => ({ ...c, total: c.general + c.emergency }));
        return { ...prev, totalInventory: cityDist.reduce((s, c) => s + c.total, 0), generalCount: cityDist.reduce((s, c) => s + c.general, 0), emergencyCount: cityDist.reduce((s, c) => s + c.emergency, 0), cityDistribution: cityDist };
      });

      setEvents(prev => { const newEvent = generateEvent(); return [newEvent, ...prev].slice(0, 20); });
      if (Math.random() > 0.7) setWarnings(generateWarnings());

      setUsage(prev => ({
        today: prev.today.map(item => ({ ...item, count: Math.max(1, item.count + rand(-3, 5)) })).sort((a, b) => b.count - a.count),
        month: prev.month.map(item => ({ ...item, count: Math.max(50, item.count + rand(-30, 40)) })).sort((a, b) => b.count - a.count),
        year: prev.year.map(item => ({ ...item, count: Math.max(1000, item.count + rand(-100, 150)) })).sort((a, b) => b.count - a.count),
      }));

      // 刷新过期装备数据
      if (Math.random() > 0.5) {
        setExpiredByUnit(generateExpiredByUnit());
        setExpiredByEquip(generateExpiredByEquip());
      }

          // 应急事件状态固定为"已调拨"，不再动态变化
    }, 5000);

    return () => clearInterval(interval);
  }, [generateEvent, generateWarnings, equipment.totalCount]);

  // 手动添加应急事件
  const addEmergencyEvent = useCallback((params: {
    type: EmergencyType;
    level: EmergencyLevel;
    location: string;
    address: string;
    description: string;
  }) => {
    const cityCoords = CITY_SVG_COORDS[params.location] || CITY_SVG_COORDS['福州市'];
    const offsetX = rand(-50, 50);
    const offsetY = rand(-30, 30);
    const newEvent: EmergencyEvent = {
      id: `EMG${Date.now()}`,
      type: params.type,
      level: params.level,
      location: params.location,
      address: params.address,
      lat: cityCoords.x + offsetX,
      lng: cityCoords.y + offsetY,
      time: new Date().toLocaleTimeString('zh-CN', { hour12: false }),
      status: 'reported',
      description: params.description,
    };

    setEmergencyEvents(prev => [newEvent, ...prev]);

    // 自动生成分析数据
    const analysis = generateAnalysis(newEvent);
    const dist = generateDistribution(newEvent);
    const txs = generateTransferSchemes(newEvent, dist);
    const lk = generateLinkedWarehouses(newEvent);
    const st = generateStrategies();

    setEmergencyAnalyses(prev => ({ ...prev, [newEvent.id]: analysis }));
    setEmergencyDistributions(prev => ({ ...prev, [newEvent.id]: dist }));
    setEmergencyTransfers(prev => ({ ...prev, [newEvent.id]: txs }));
    setEmergencyLinked(prev => ({ ...prev, [newEvent.id]: lk }));
    setEmergencyStrategies(prev => ({ ...prev, [newEvent.id]: st }));
  }, []);

  // 手动结束应急事件
  const resolveEmergencyEvent = useCallback((eventId: string) => {
    setEmergencyEvents(prev => prev.map(evt =>
      evt.id === eventId ? { ...evt, status: 'resolved' as const } : evt
    ));
  }, []);

  return {
    equipment, analysis, distribution, events, warnings, ranks, usage,
    expiredByUnit, expiredByEquip, generateDistrictRanks,
    // 8.2 应急事件
    emergencyEvents, emergencyAnalyses, emergencyDistributions,
    emergencyTransfers, emergencyLinked, emergencyStrategies,
    addEmergencyEvent, resolveEmergencyEvent,
    envDevices,
  };
}