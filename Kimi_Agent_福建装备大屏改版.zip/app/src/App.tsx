import { useState, useEffect, useRef } from 'react';
import TopNav from './sections/TopNav';
import ErrorBoundary from './sections/ErrorBoundary';
import ProvincialDashboard from './sections/ProvincialDashboard';
import EmergencyDashboard from './sections/EmergencyDashboard';

type ViewType = 'provincial' | 'emergency';

export default function App() {
  const [activeView, setActiveView] = useState<ViewType>('provincial');
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);

  // React 挂载完成后隐藏 loading 屏幕
  useEffect(() => {
    const el = document.getElementById('loading-screen');
    if (el) {
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    }
  }, []);

  // 背景动画（共用底层）
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => { canvas.width = window.innerWidth; canvas.height = window.innerHeight; };
    resize();
    window.addEventListener('resize', resize);

    const particles: { x: number; y: number; vx: number; vy: number; size: number; alpha: number; color: string; }[] = [];
    for (let i = 0; i < 60; i++) {
      particles.push({
        x: Math.random() * canvas.width, y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3, vy: (Math.random() - 0.5) * 0.3,
        size: Math.random() * 2 + 0.5, alpha: Math.random() * 0.4 + 0.1,
        color: Math.random() > 0.7 ? '#00f0ff' : Math.random() > 0.5 ? '#0055ff' : '#0a2a5c',
      });
    }

    let running = true;
    const animate = () => {
      if (!running) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const gradient = ctx.createRadialGradient(canvas.width * 0.5, canvas.height * 0.4, 0, canvas.width * 0.5, canvas.height * 0.4, canvas.width * 0.8);
      gradient.addColorStop(0, 'rgba(10, 20, 45, 1)');
      gradient.addColorStop(0.5, 'rgba(5, 10, 20, 1)');
      gradient.addColorStop(1, 'rgba(3, 6, 14, 1)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      particles.forEach(p => {
        p.x += p.vx; p.y += p.vy;
        if (p.x < 0) p.x = canvas.width; if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height; if (p.y > canvas.height) p.y = 0;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.fill();
        ctx.globalAlpha = 1;
      });

      const time = Date.now() * 0.0005;
      for (let i = 0; i < 5; i++) {
        const x = canvas.width * (0.2 + i * 0.15) + Math.sin(time + i) * 100;
        const y = canvas.height * (0.3 + Math.cos(time * 0.7 + i) * 0.2);
        const radius = 80 + Math.sin(time + i * 2) * 30;
        const ripple = ctx.createRadialGradient(x, y, 0, x, y, radius);
        ripple.addColorStop(0, 'rgba(0, 240, 255, 0.03)');
        ripple.addColorStop(0.5, 'rgba(0, 85, 255, 0.02)');
        ripple.addColorStop(1, 'rgba(0, 240, 255, 0)');
        ctx.fillStyle = ripple;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
      }

      ctx.strokeStyle = 'rgba(0, 240, 255, 0.04)';
      ctx.lineWidth = 1;
      const gridSize = 60;
      for (let x = 0; x < canvas.width; x += gridSize) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke(); }
      for (let y = 0; y < canvas.height; y += gridSize) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke(); }

      animRef.current = requestAnimationFrame(animate);
    };
    animRef.current = requestAnimationFrame(animate);

    return () => { running = false; window.removeEventListener('resize', resize); cancelAnimationFrame(animRef.current); };
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', position: 'relative', background: '#050a14' }}>
      {/* 共用背景 */}
      <canvas ref={canvasRef} style={{ position: 'fixed', inset: 0, zIndex: 0 }} />

      {/* 顶部导航 */}
      <TopNav activeView={activeView} onSwitchView={setActiveView} />

      {/* 视图切换 - key 确保 React 完全卸载旧组件，ErrorBoundary 防止单个组件崩溃导致全屏白屏 */}
      {activeView === 'provincial' ? (
        <ErrorBoundary key="provincial"><ProvincialDashboard /></ErrorBoundary>
      ) : (
        <ErrorBoundary key="emergency"><EmergencyDashboard /></ErrorBoundary>
      )}
    </div>
  );
}
