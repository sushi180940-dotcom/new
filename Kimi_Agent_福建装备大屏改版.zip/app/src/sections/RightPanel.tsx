import { useEffect, useRef, useState } from 'react';
import { Trophy, AlertTriangle, TrendingDown, CheckCircle, WrenchIcon, BarChart3, Package, Building2, Wrench } from 'lucide-react';
import * as echarts from 'echarts';
import type { RankItem, AnalysisData, EquipmentUsage, ExpiredItem } from '../hooks/useRealtimeData';

interface RightPanelProps {
  ranks: RankItem[];
  analysis: AnalysisData;
  usage: EquipmentUsage;
  expiredByUnit: ExpiredItem[];
  expiredByEquip: ExpiredItem[];
  generateDistrictRanks: (city: string) => RankItem[];
}

const PADDING = 16;
const GAP = 12;
const MOD1_H = 195;
const MOD2_H = 300;

export default function RightPanel({ ranks: _ranks, analysis, usage, expiredByUnit, expiredByEquip, generateDistrictRanks: _generateDistrictRanks }: RightPanelProps) {
  const [expiredView, setExpiredView] = useState<'unit' | 'equipment'>('unit');
  const [usagePeriod, setUsagePeriod] = useState<'today' | 'month' | 'year'>('today');

  const gauge1Ref = useRef<HTMLDivElement>(null);
  const gauge2Ref = useRef<HTMLDivElement>(null);
  const gauge3Ref = useRef<HTMLDivElement>(null);
  const gauge4Ref = useRef<HTMLDivElement>(null);
  const g1 = useRef<echarts.ECharts | null>(null);
  const g2 = useRef<echarts.ECharts | null>(null);
  const g3 = useRef<echarts.ECharts | null>(null);
  const g4 = useRef<echarts.ECharts | null>(null);
  const usageRef = useRef<HTMLDivElement>(null);
  const uChart = useRef<echarts.ECharts | null>(null);

  // 仪表盘
  useEffect(() => {
    if (gauge1Ref.current && !g1.current) g1.current = echarts.init(gauge1Ref.current);
    if (gauge2Ref.current && !g2.current) g2.current = echarts.init(gauge2Ref.current);
    if (gauge3Ref.current && !g3.current) g3.current = echarts.init(gauge3Ref.current);
    if (gauge4Ref.current && !g4.current) g4.current = echarts.init(gauge4Ref.current);
    const opt = (v: number, c: string, n: string) => ({
      series: [{ type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100, radius: '88%', center: ['50%', '55%'], splitNumber: 5, itemStyle: { color: c }, progress: { show: true, width: 8, roundCap: true }, pointer: { show: false }, axisLine: { lineStyle: { width: 8, color: [[1, 'rgba(255,255,255,0.06)']] } }, axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false }, title: { offsetCenter: [0, '68%'], fontSize: 10, color: '#94a3b8' }, detail: { fontSize: 16, fontWeight: 700, fontFamily: 'Roboto Mono, monospace', offsetCenter: [0, '0%'], valueAnimation: true, formatter: '{value}%', color: '#fff' }, data: [{ value: v, name: n }] }],
    });
    if (g1.current) g1.current.setOption(opt(analysis.expiredPercent, '#ff4444', '过期占比'));
    if (g2.current) g2.current.setOption(opt(analysis.nearScrapPercent, '#ffcc00', '临废占比'));
    if (g3.current) g3.current.setOption(opt(analysis.inUsePercent, '#00ff9d', '在用占比'));
    if (g4.current) g4.current.setOption(opt(analysis.maintenancePercent, '#a78bfa', '维修占比'));
    const onR = () => { g1.current?.resize(); g2.current?.resize(); g3.current?.resize(); g4.current?.resize(); };
    window.addEventListener('resize', onR);
    return () => {
      window.removeEventListener('resize', onR);
      try { g1.current?.dispose(); g2.current?.dispose(); g3.current?.dispose(); g4.current?.dispose(); } catch (e) { /* ignore */ }
      g1.current = null; g2.current = null; g3.current = null; g4.current = null;
    };
  }, [analysis]);

  // 使用柱状图
  useEffect(() => {
    if (usageRef.current && !uChart.current) uChart.current = echarts.init(usageRef.current);
    if (!uChart.current || !usageRef.current) return;
    const containerH = usageRef.current.clientHeight;
    uChart.current.resize({ height: containerH });
    const data = usage[usagePeriod];
    uChart.current.setOption({
      tooltip: { trigger: 'axis', backgroundColor: 'rgba(16,30,55,0.95)', borderColor: 'rgba(0,240,255,0.3)', textStyle: { color: '#fff', fontSize: 12 }, formatter: (params: any) => `<div style="color:#00f0ff;font-weight:700;margin-bottom:4px">${params[0].name}</div><div>使用: <b style="color:#fff">${params[0].value.toLocaleString()}</b> 次</div>` },
      grid: { left: 2, right: 20, top: 6, bottom: 2, containLabel: true },
      xAxis: { type: 'category', data: data.map(d => d.name), axisLabel: { color: '#64748b', fontSize: 8, rotate: 18, interval: 0 }, axisLine: { lineStyle: { color: 'rgba(0,240,255,0.08)' } }, axisTick: { show: false } },
      yAxis: { type: 'value', axisLabel: { color: '#64748b', fontSize: 8 }, splitLine: { lineStyle: { color: 'rgba(0,240,255,0.04)' } }, axisLine: { show: false }, axisTick: { show: false } },
      series: [{ type: 'bar', data: data.map((d, i) => ({ value: d.count, itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: i < 3 ? '#00f0ff' : '#0088dd' }, { offset: 1, color: i < 3 ? 'rgba(0,240,255,0.2)' : 'rgba(0,85,255,0.1)' }]), borderRadius: [3, 3, 0, 0] } })), barWidth: 10, label: { show: true, position: 'top', color: '#00f0ff', fontSize: 8, fontFamily: 'Roboto Mono, monospace' } }],
    }, true);
    const onR = () => uChart.current?.resize();
    window.addEventListener('resize', onR);
    return () => {
      window.removeEventListener('resize', onR);
      try { uChart.current?.dispose(); } catch (e) { /* ignore */ }
      uChart.current = null;
    };
  }, [usage, usagePeriod]);

  const displayExpired = expiredView === 'unit' ? expiredByUnit : expiredByEquip;

  return (
    <aside style={{ position: 'fixed', top: 68, right: 0, bottom: 0, width: '22%', minWidth: 300, padding: `${PADDING}px`, display: 'flex', flexDirection: 'column', gap: GAP, overflow: 'hidden', zIndex: 20 }}>
      {/* === 模块1: 综合数据分析 === */}
      <div className="glass-panel" style={{ padding: 14, flexShrink: 0, height: MOD1_H, overflow: 'hidden' }}>
        <div className="module-title" style={{ marginBottom: 6, paddingBottom: 6, fontSize: 14 }}>综合数据分析</div>
        <div style={{ display: 'flex', gap: 2 }}>
          <div ref={gauge1Ref} style={{ width: '25%', height: 88 }} />
          <div ref={gauge2Ref} style={{ width: '25%', height: 88 }} />
          <div ref={gauge3Ref} style={{ width: '25%', height: 88 }} />
          <div ref={gauge4Ref} style={{ width: '25%', height: 88 }} />
        </div>
        <div style={{ display: 'flex', gap: 3, marginTop: 2 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 2, padding: '2px 4px', background: 'rgba(255,68,68,0.06)', borderRadius: 5 }}><AlertTriangle size={9} style={{ color: '#ff4444', flexShrink: 0 }} /><span style={{ fontSize: 9, color: '#ff4444', whiteSpace: 'nowrap' }}>过期:{analysis.expiredCount}</span></div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 2, padding: '2px 4px', background: 'rgba(255,204,0,0.06)', borderRadius: 5 }}><TrendingDown size={9} style={{ color: '#ffcc00', flexShrink: 0 }} /><span style={{ fontSize: 9, color: '#ffcc00', whiteSpace: 'nowrap' }}>临废:{analysis.nearScrapCount}</span></div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 2, padding: '2px 4px', background: 'rgba(0,255,157,0.06)', borderRadius: 5 }}><CheckCircle size={9} style={{ color: '#00ff9d', flexShrink: 0 }} /><span style={{ fontSize: 9, color: '#00ff9d', whiteSpace: 'nowrap' }}>在用:{analysis.inUseCount}</span></div>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 2, padding: '2px 4px', background: 'rgba(167,139,250,0.06)', borderRadius: 5 }}><WrenchIcon size={9} style={{ color: '#a78bfa', flexShrink: 0 }} /><span style={{ fontSize: 9, color: '#a78bfa', whiteSpace: 'nowrap' }}>维修:{analysis.maintenanceCount}</span></div>
        </div>
      </div>

      {/* === 模块2: 过期装备排名 === */}
      <div className="glass-panel" style={{ padding: 14, flexShrink: 0, height: MOD2_H, overflow: 'hidden' }}>
        <div className="module-title" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 5, paddingBottom: 5, fontSize: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Trophy size={14} />过期装备排名</div>
          {/* 切换按钮：按单位 / 按装备 */}
          <div style={{ display: 'flex', gap: 1, padding: 2, background: 'rgba(255,68,68,0.05)', borderRadius: 10, border: '1px solid rgba(255,68,68,0.12)' }}>
            <button onClick={() => setExpiredView('unit')} style={{ display: 'flex', alignItems: 'center', gap: 3, padding: '3px 8px', borderRadius: 8, fontSize: 10, fontWeight: 600, border: 'none', cursor: 'pointer', transition: 'all 0.2s', background: expiredView === 'unit' ? 'rgba(255,68,68,0.2)' : 'transparent', color: expiredView === 'unit' ? '#ff4444' : '#64748b' }}><Building2 size={11} />按单位</button>
            <button onClick={() => setExpiredView('equipment')} style={{ display: 'flex', alignItems: 'center', gap: 3, padding: '3px 8px', borderRadius: 8, fontSize: 10, fontWeight: 600, border: 'none', cursor: 'pointer', transition: 'all 0.2s', background: expiredView === 'equipment' ? 'rgba(255,68,68,0.2)' : 'transparent', color: expiredView === 'equipment' ? '#ff4444' : '#64748b' }}><Wrench size={11} />按装备</button>
          </div>
        </div>
        {/* 表头 */}
        <div style={{ display: 'flex', padding: '2px 6px 5px', borderBottom: '1px solid rgba(255,68,68,0.1)', marginBottom: 2, fontSize: 9, color: '#64748b', fontWeight: 500 }}>
          <span style={{ width: 24, textAlign: 'center' }}>排名</span>
          <span style={{ flex: 1 }}>{expiredView === 'unit' ? '单位' : '装备名称'}</span>
          <span style={{ width: 50, textAlign: 'right' }}>数量</span>
        </div>
        {/* 数据 */}
        <div>
          {displayExpired.slice(0, 10).map((item, idx) => (
            <div key={`${item.name}-${idx}`} style={{ display: 'flex', alignItems: 'center', padding: '5px 6px', background: idx < 3 ? 'rgba(255,68,68,0.03)' : undefined, borderRadius: 4 }}>
              <span style={{ width: 24, textAlign: 'center', fontSize: idx < 3 ? 14 : 11, color: idx < 3 ? '#ff4444' : '#64748b' }}>
                {idx < 3 ? <Trophy size={13} style={{ color: idx === 0 ? '#ffcc00' : idx === 1 ? '#c0c0c0' : '#cd7f32' }} /> : String(idx + 1).padStart(2, '0')}
              </span>
              <span style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 4, overflow: 'hidden' }}>
                {expiredView === 'unit' ? <Building2 size={11} style={{ color: '#00f0ff', flexShrink: 0 }} /> : <Package size={11} style={{ color: '#ff8800', flexShrink: 0 }} />}
                <span style={{ color: '#e2e8f0', fontSize: 11, fontWeight: idx < 3 ? 600 : 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</span>
              </span>
              <span className="stat-number" style={{ width: 50, textAlign: 'right', color: '#ff4444', fontSize: 13, fontWeight: 700 }}>{item.count}</span>
            </div>
          ))}
        </div>
      </div>

      {/* === 模块3: 装备使用Top10 === */}
      <div className="glass-panel" style={{ padding: 14, flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div className="module-title" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6, paddingBottom: 6, fontSize: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><BarChart3 size={14} />装备使用Top10</div>
          <div style={{ display: 'flex', gap: 1, padding: 2, background: 'rgba(0,240,255,0.05)', borderRadius: 10 }}>
            {[{ k: 'today' as const, l: '今日' }, { k: 'month' as const, l: '本月' }, { k: 'year' as const, l: '年度' }].map(i => (
              <button key={i.k} onClick={() => setUsagePeriod(i.k)} style={{ padding: '2px 8px', borderRadius: 8, fontSize: 10, fontWeight: 600, border: 'none', cursor: 'pointer', transition: 'all 0.2s', background: usagePeriod === i.k ? 'rgba(0,240,255,0.2)' : 'transparent', color: usagePeriod === i.k ? '#00f0ff' : '#64748b', boxShadow: usagePeriod === i.k ? '0 0 6px rgba(0,240,255,0.12)' : 'none' }}>{i.l}</button>
            ))}
          </div>
        </div>
        <div ref={usageRef} style={{ width: '100%', flex: 1, minHeight: 0 }} />
      </div>
    </aside>
  );
}
