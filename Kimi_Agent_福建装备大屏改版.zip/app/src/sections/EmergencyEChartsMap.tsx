import { useEffect, useRef, useState, useCallback } from 'react';
import * as echarts from 'echarts';
import { X } from 'lucide-react';
import { EMERGENCY_TYPE_LABELS } from '../hooks/useRealtimeData';
import type { EmergencyEvent } from '../hooks/useRealtimeData';

const EMG_COLORS: Record<string, string> = {
  terrorist: '#ff1a1a', criminal: '#ff6600', mass: '#ffaa00',
  disaster: '#3366ff', security: '#00cc66', checkpoint: '#aa44ff',
};
const EMG_LEVEL_COLORS = { general: '#ffcc00', severe: '#ff8800', critical: '#ff1a1a' };
const EMG_LEVEL_LABELS = { general: '三级（一般）', severe: '二级（严重）', critical: '一级（危急）' };
const EMG_STATUS: Record<string, string> = {
  reported: '已接报', analyzing: '分析中', dispatched: '已调拨', coordinating: '联动中', resolved: '已处置',
};

const CITY_COORDS: Record<string, [number, number]> = {
  '福州市': [119.306239, 26.075302],
  '厦门市': [118.089425, 24.479833],
  '莆田市': [119.007777, 25.454202],
  '三明市': [117.638678, 26.263406],
  '泉州市': [118.675676, 24.874475],
  '漳州市': [117.676033, 24.511156],
  '南平市': [118.181851, 26.643626],
  '龙岩市': [117.017536, 25.075123],
  '宁德市': [119.554174, 26.668784],
  '平潭综合实验区': [119.791612, 25.503571],
};

// 福州区县数据
const FUZHOU_DISTRICTS = [
  { name: '鼓楼区', value: 4200 }, { name: '台江区', value: 3800 },
  { name: '仓山区', value: 5600 }, { name: '晋安区', value: 3200 },
  { name: '马尾区', value: 2400 }, { name: '长乐区', value: 2800 },
  { name: '福清市', value: 3500 }, { name: '闽侯县', value: 1800 },
  { name: '连江县', value: 1500 }, { name: '罗源县', value: 1100 },
  { name: '闽清县', value: 1200 }, { name: '永泰县', value: 950 },
  { name: '平潭县', value: 1600 },
];

const FUZHOU_COORDS: Record<string, [number, number]> = {
  '鼓楼区': [119.29929, 26.082284], '台江区': [119.310156, 26.058616],
  '仓山区': [119.320988, 26.038912], '晋安区': [119.328597, 26.078837],
  '马尾区': [119.458725, 25.991975], '长乐区': [119.510849, 25.960583],
  '闽侯县': [119.145117, 26.148567], '连江县': [119.538365, 26.202109],
  '罗源县': [119.552645, 26.487234], '闽清县': [118.868416, 26.223793],
  '永泰县': [118.939089, 25.864825], '平潭县': [119.791197, 25.503672],
  '福清市': [119.376992, 25.720402],
};

interface Props {
  events: EmergencyEvent[];
  selected: EmergencyEvent | null;
  onSelect: (e: EmergencyEvent) => void;
}

export default function EmergencyEChartsMap({ events, selected, onSelect }: Props) {
  const [geoLoaded, setGeoLoaded] = useState(false);
  const [fuzhouGeoLoaded, setFuzhouGeoLoaded] = useState(false);
  const [drillDown, setDrillDown] = useState<'province' | 'fuzhou'>('province');
  const [showDetail, setShowDetail] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<echarts.ECharts | null>(null);

  // 当有选中事件时默认展示详情
  useEffect(() => {
    if (selected) setShowDetail(true);
  }, [selected?.id]);

  // 加载福建 geoJSON
  useEffect(() => {
    if (geoLoaded) return;
    let cancelled = false;
    fetch('./map/fujian.json')
      .then(r => r.json())
      .then(j => { if (!cancelled) { echarts.registerMap('fujian_emg', j); setGeoLoaded(true); } })
      .catch(err => { if (!cancelled) console.error('Load fujian emg error:', err); });
    return () => { cancelled = true; };
  }, [geoLoaded]);

  // 加载福州 geoJSON
  useEffect(() => {
    if (fuzhouGeoLoaded) return;
    let cancelled = false;
    fetch('./map/fuzhou.json')
      .then(r => r.json())
      .then(j => { if (!cancelled) { echarts.registerMap('fuzhou_emg', j); setFuzhouGeoLoaded(true); } })
      .catch(err => { if (!cancelled) console.error('Load fuzhou emg error:', err); });
    return () => { cancelled = true; };
  }, [fuzhouGeoLoaded]);

  // 初始化 ECharts（只执行一次）
  useEffect(() => {
    if (!containerRef.current || chartRef.current) return;
    try { chartRef.current = echarts.init(containerRef.current, undefined, { renderer: 'canvas' }); }
    catch (e) { console.error('Emergency ECharts init failed:', e); return; }
    const resize = () => { try { chartRef.current?.resize(); } catch (e) { /* ignore */ } };
    window.addEventListener('resize', resize);
    return () => {
      window.removeEventListener('resize', resize);
      try { chartRef.current?.dispose(); } catch (e) { /* ignore */ }
      chartRef.current = null;
    };
  }, []);

  // 所有区县坐标（合并地市+福州区县）
  const ALL_COORDS: Record<string, [number, number]> = { ...CITY_COORDS };
  Object.entries(FUZHOU_COORDS).forEach(([k, v]) => { ALL_COORDS[k] = v; });

  // 事件坐标
  function getEventCoord(event: EmergencyEvent): [number, number] {
    // 先尝试直接匹配区县名称
    const directKey = Object.keys(ALL_COORDS).find(c => event.location === c || event.location.includes(c));
    if (directKey) return ALL_COORDS[directKey];
    // 再尝试模糊匹配城市名称（去掉"市"后缀）
    const cityKey = Object.keys(CITY_COORDS).find(c => {
      const short = c.replace('市', '').replace('综合实验区', '');
      return short && event.location.includes(short);
    });
    const base: [number, number] = cityKey ? CITY_COORDS[cityKey] : [118.0, 26.0];
    return base;
  }

  // 构建全省配置
  const buildProvinceOption = useCallback((): echarts.EChartsOption => {
    const cityData = Object.entries(CITY_COORDS).map(([name, coord]) => ({
      name, value: [...coord, 0],
      itemStyle: { color: 'rgba(0,240,255,0.4)', borderColor: 'rgba(0,240,255,0.6)', borderWidth: 0.8 },
      symbol: 'circle', symbolSize: 8,
      label: { show: true, formatter: name, color: 'rgba(200,220,255,0.5)', fontSize: 9, fontWeight: 500, offset: [0, -12] },
    }));

    const eventData = events.map((evt, idx) => {
      const coord = getEventCoord(evt);
      const color = EMG_COLORS[evt.type] || '#ff4444';
      const isSel = selected?.id === evt.id;
      const isHistory = evt.status === 'resolved';
      const sz = evt.level === 'critical' ? 16 : evt.level === 'severe' ? 11 : 9;
      return {
        name: evt.id, value: [...coord, evt.type], eventData: evt,
        itemStyle: { color, borderColor: color, borderWidth: isHistory ? 1 : 2, shadowBlur: isHistory ? 4 : 14, shadowColor: color },
        symbol: 'diamond', symbolSize: isSel ? sz + 5 : sz,
        label: isHistory ? { show: false } : { show: true, formatter: `{t|事件${idx + 1}}\n{s|${EMG_STATUS[evt.status]}}`, rich: { t: { fontSize: 10, color, fontWeight: 700, lineHeight: 14 }, s: { fontSize: 9, color: '#94a3b8' } }, offset: [0, -22], textBorderColor: '#000', textBorderWidth: 2 },
        emphasis: { scale: 1.6, itemStyle: { shadowBlur: 24 } },
      };
    });

    const pulseData = selected ? [{ name: selected.id, value: [...getEventCoord(selected), selected.type], itemStyle: { color: EMG_COLORS[selected.type] || '#ff4444', borderColor: '#fff', borderWidth: 1 } }] : [];

    const flyLines: any[] = [];
    if (selected) {
      const evtCoord = getEventCoord(selected);
      const nearestCity = Object.values(CITY_COORDS).reduce((best, c) => {
        const d1 = Math.hypot(best[0] - evtCoord[0], best[1] - evtCoord[1]);
        const d2 = Math.hypot(c[0] - evtCoord[0], c[1] - evtCoord[1]);
        return d1 < d2 ? best : c;
      });
      const c = EMG_COLORS[selected.type] || '#ff4444';
      flyLines.push({ coords: [evtCoord, nearestCity], lineStyle: { color: c, width: 1.5, opacity: 0.4, curveness: 0.2 } });
    }

    return {
      backgroundColor: 'transparent',
      geo: {
        map: 'fujian_emg', roam: true, zoom: 1.1, center: [118.0, 26.0],
        itemStyle: { areaColor: 'rgba(40, 5, 5, 0.2)', borderColor: 'rgba(255, 60, 60, 0.2)', borderWidth: 1.5 },
        emphasis: { itemStyle: { areaColor: 'rgba(60, 10, 10, 0.3)', borderColor: 'rgba(255, 80, 80, 0.35)', borderWidth: 2 }, label: { show: false } },
        select: { itemStyle: { areaColor: 'rgba(40, 5, 5, 0.2)' }, label: { show: false } },
        label: { show: false },
      } as any,
      series: [
        ...(flyLines.length > 0 ? [{ type: 'lines' as const, coordinateSystem: 'geo' as const, data: flyLines, effect: { show: true, period: 3, trailLength: 0.5, color: '#fff', symbol: 'arrow', symbolSize: 3 }, lineStyle: { width: 0, curveness: 0.2 }, zlevel: 1 }] : []),
        { type: 'scatter' as const, coordinateSystem: 'geo' as const, data: cityData, zlevel: 2 },
        ...(pulseData.length > 0 ? [{ type: 'effectScatter' as const, coordinateSystem: 'geo' as const, data: pulseData, symbol: 'diamond', symbolSize: 28, showEffectOn: 'render' as const, rippleEffect: { brushType: 'stroke' as const, scale: 3, period: 2 }, zlevel: 3 }] : []),
        { type: 'scatter' as const, coordinateSystem: 'geo' as const, data: eventData, zlevel: 4 },
      ],
      tooltip: {
        trigger: 'item',
        backgroundColor: 'rgba(20,8,8,0.95)',
        borderColor: 'rgba(255,80,80,0.3)',
        textStyle: { color: '#fff', fontSize: 12 },
        formatter: (params: any) => {
          const evt: EmergencyEvent | undefined = params?.data?.eventData;
          if (!evt) return '';
          const color = EMG_COLORS[evt.type] || '#ff4444';
          const eventIndex = events.findIndex(e => e.id === evt.id) + 1;
          return `<div style="font-weight:800;color:${color};font-size:14px;margin-bottom:6px">事件${eventIndex}</div><div style="color:#94a3b8;font-size:11px;margin-bottom:4px">${evt.location} · ${evt.address}</div><div style="color:#e2e8f0;font-size:11px;margin-bottom:6px">${evt.description}</div><div style="display:flex;gap:8px"><span style="font-size:10px;padding:2px 8px;border-radius:6px;background:${EMG_LEVEL_COLORS[evt.level]}22;color:${EMG_LEVEL_COLORS[evt.level]};border:1px solid ${EMG_LEVEL_COLORS[evt.level]}44;font-weight:700">${EMG_LEVEL_LABELS[evt.level]}</span><span style="font-size:10px;color:#94a3b8">${EMG_STATUS[evt.status]}</span><span style="font-size:10px;color:#64748b;margin-left:auto">${evt.time}</span></div>`;
        },
      },
    };
  }, [events, selected]);

  // 构建福州区县配置
  const buildFuzhouOption = useCallback((): echarts.EChartsOption => {
    const maxVal = Math.max(...FUZHOU_DISTRICTS.map(d => d.value));
    const minVal = Math.min(...FUZHOU_DISTRICTS.map(d => d.value));

    const districtData = FUZHOU_DISTRICTS.map(d => {
      const ratio = (d.value - minVal) / (maxVal - minVal || 1);
      const redInt = Math.round(40 + ratio * 40);
      return {
        name: d.name, value: d.value,
        itemStyle: { areaColor: `rgba(${redInt + 40}, 5, 5, ${0.15 + ratio * 0.2})`, borderColor: `rgba(255, ${Math.round(60 + ratio * 40)}, 60, 0.3)`, borderWidth: 1.5 },
        label: { show: false },
        emphasis: { itemStyle: { areaColor: `rgba(${redInt + 60}, 10, 10, 0.35)`, borderColor: `rgba(255, 80, 80, 0.5)`, borderWidth: 2 }, label: { show: true, color: '#ff4444', fontSize: 11, fontWeight: 700, textBorderColor: '#000', textBorderWidth: 2 } },
      };
    });

    const scatterData = FUZHOU_DISTRICTS.map(d => {
      const coord = FUZHOU_COORDS[d.name];
      if (!coord) return null;
      const ratio = d.value / maxVal;
      return {
        name: d.name, value: [...coord, d.value],
        symbolSize: Math.round(10 + ratio * 18),
        itemStyle: { color: `rgba(255, ${Math.round(80 + ratio * 40)}, 60, ${0.5 + ratio * 0.4})`, borderColor: '#ff4444', borderWidth: 1.5, shadowBlur: 10, shadowColor: `rgba(255, 68, 68, ${0.3 + ratio * 0.4})` },
        label: { show: true, formatter: `{n|${d.name}}\n{v|${d.value.toLocaleString()}}`, rich: { n: { fontSize: 10, color: '#e2e8f0', fontWeight: 600, lineHeight: 14 }, v: { fontSize: 11, color: '#ff4444', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' } }, textBorderColor: '#000', textBorderWidth: 2, offset: [0, -16] },
      };
    }).filter(Boolean);

    // 事件坐标适配到福州区县
    const eventData = events.map(evt => {
      const coord = getEventCoord(evt);
      const color = EMG_COLORS[evt.type] || '#ff4444';
      const isHistory = evt.status === 'resolved';
      const sz = evt.level === 'critical' ? 14 : evt.level === 'severe' ? 10 : 8;
      return {
        name: evt.id, value: [...coord, evt.type], eventData: evt,
        itemStyle: { color, borderColor: color, borderWidth: isHistory ? 1 : 2, shadowBlur: isHistory ? 4 : 12, shadowColor: color },
        symbol: 'diamond', symbolSize: sz,
        label: isHistory ? { show: false } : { show: true, formatter: `{t|${EMERGENCY_TYPE_LABELS[evt.type] || ''}}`, rich: { t: { fontSize: 9, color, fontWeight: 700 } }, offset: [0, -18], textBorderColor: '#000', textBorderWidth: 2 },
      };
    });

    return {
      backgroundColor: 'transparent',
      animationDurationUpdate: 800,
      animationEasingUpdate: 'cubicInOut',
      geo: {
        map: 'fuzhou_emg', roam: true, zoom: 1.12, center: [119.32, 26.05],
        itemStyle: { areaColor: 'rgba(30, 5, 5, 0.12)', borderColor: 'rgba(255, 60, 60, 0.25)', borderWidth: 1.5, shadowColor: 'rgba(0,0,0,0.4)', shadowBlur: 8 },
        emphasis: { itemStyle: { areaColor: 'rgba(60, 10, 10, 0.3)', borderColor: '#ff4444', borderWidth: 2 }, label: { show: true, color: '#ff4444', fontSize: 11, fontWeight: 700, textBorderColor: '#000', textBorderWidth: 2 } },
        select: { itemStyle: { areaColor: 'rgba(30, 5, 5, 0.12)' }, label: { show: false } },
        label: { show: false },
      } as any,
      series: [
        { type: 'map', geoIndex: 0, map: 'fuzhou_emg', data: districtData, emphasis: { itemStyle: { areaColor: 'rgba(60, 10, 10, 0.35)' }, label: { show: true, color: '#ff4444' } }, select: { itemStyle: { areaColor: 'rgba(30, 5, 5, 0.12)' } }, animationDurationUpdate: 600 },
        { type: 'scatter', coordinateSystem: 'geo', data: scatterData, symbol: 'circle', zlevel: 3, animationDurationUpdate: 800 },
        { type: 'scatter', coordinateSystem: 'geo', data: eventData, zlevel: 4 },
      ],
      tooltip: { show: false },
      graphic: [
        {
          type: 'group', left: 'center', top: 8,
          children: [
            { type: 'rect', shape: { width: 380, height: 36, r: 10 }, style: { fill: 'rgba(8,3,3,0.92)', stroke: 'rgba(255,80,80,0.2)', lineWidth: 1 }, left: 'center', top: 0 },
            { type: 'text', style: { text: '福州市 · 区县应急分布', fill: '#ff4444', font: 'bold 13px Roboto Mono,monospace' }, left: 'center', top: 10 },
          ],
        },
      ],
    };
  }, [events, selected]);

  // 更新图表
  useEffect(() => {
    if (!chartRef.current || !geoLoaded) return;
    try {
      chartRef.current.clear();
      if (drillDown === 'fuzhou' && fuzhouGeoLoaded) {
        chartRef.current.setOption(buildFuzhouOption(), true);
      } else {
        chartRef.current.setOption(buildProvinceOption(), true);
      }
    } catch (e) { console.error('Emergency chart update error:', e); }
  }, [geoLoaded, fuzhouGeoLoaded, drillDown, buildProvinceOption, buildFuzhouOption, events, selected]);

  // 点击下钻 + 事件详情切换
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    const handler = (params: any) => {
      if (drillDown === 'province' && params?.name === '福州市') {
        setDrillDown('fuzhou');
      } else if (drillDown === 'fuzhou') {
        const evt: EmergencyEvent | undefined = params?.data?.eventData;
        if (evt) { onSelect(evt); setShowDetail(true); }
      } else {
        const evt: EmergencyEvent | undefined = params?.data?.eventData;
        if (evt) { onSelect(evt); setShowDetail(true); }
      }
    };
    chart.on('click', handler);
    return () => { try { chart.off('click', handler); } catch (e) { /* ignore */ } };
  }, [drillDown, onSelect]);

  // 滚轮缩放返回全省
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || drillDown !== 'fuzhou') return;
    const finishedHandler = () => {
      try {
        const opt = chart.getOption() as any;
        const zoom = opt?.geo?.[0]?.zoom ?? 1;
        if (zoom < 0.85) setDrillDown('province');
      } catch (e) { /* ignore */ }
    };
    chart.on('finished', finishedHandler);
    return () => { try { chart.off('finished', finishedHandler); } catch (e) { /* ignore */ } };
  }, [drillDown]);

  // 详情卡片像素坐标
  const [cardPos, setCardPos] = useState<{ left: number; top: number } | null>(null);

  // 计算选中事件的像素坐标（在图表渲染完成后执行）
  useEffect(() => {
    if (!selected || !chartRef.current || !geoLoaded) return;
    const chart = chartRef.current;
    const computePos = () => {
      const coord = getEventCoord(selected);
      const px = chart.convertToPixel('geo', coord) as [number, number] | null;
      if (px) setCardPos({ left: px[0], top: px[1] - 200 });
    };
    // 延迟到图表渲染完成后计算坐标
    requestAnimationFrame(() => {
      requestAnimationFrame(computePos);
    });
  }, [selected, drillDown, geoLoaded]);

  // 监听地图缩放/拖拽，更新卡片位置
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || !selected) return;
    const roamHandler = () => {
      const coord = getEventCoord(selected);
      const px = chart.convertToPixel('geo', coord) as [number, number] | null;
      if (px) setCardPos({ left: px[0], top: px[1] - 200 });
    };
    chart.on('georoam', roamHandler);
    return () => { try { chart.off('georoam', roamHandler); } catch (e) { /* ignore */ } };
  }, [selected]);

  return (
    <div style={{ position: 'absolute', inset: 0, zIndex: 10 }}>
      {/* 事件详情浮层卡片 - 定位到事件点位上方 */}
      {showDetail && selected && cardPos && (
        <EventDetailCard
          event={selected}
          eventIndex={events.findIndex(e => e.id === selected.id) + 1}
          onClose={() => { setShowDetail(false); }}
          position={cardPos}
        />
      )}
      <div ref={containerRef} style={{ position: 'absolute', inset: 0 }} />
    </div>
  );
}

// ===== 事件详情浮层卡片 =====
function EventDetailCard({ event, eventIndex, onClose, position }: {
  event: EmergencyEvent; eventIndex: number; onClose: () => void;
  position: { left: number; top: number };
}) {
  const color = EMG_COLORS[event.type] || '#ff4444';
  return (
    <div style={{
      position: 'absolute',
      left: position.left,
      top: position.top,
      transform: 'translateX(-50%)',
      zIndex: 30, width: 340,
      background: 'rgba(8,3,3,0.95)', backdropFilter: 'blur(16px)',
      borderRadius: 14, border: `1px solid ${color}44`,
      boxShadow: `0 8px 32px rgba(0,0,0,0.5), 0 0 16px ${color}22`,
      pointerEvents: 'auto',
    }}>
      {/* 头部 */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', borderBottom: `1px solid ${color}33` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 10, height: 10, background: color, transform: 'rotate(45deg)', boxShadow: `0 0 8px ${color}`, flexShrink: 0 }} />
          <span style={{ fontSize: 15, fontWeight: 800, color }}>事件{eventIndex}</span>
          <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 6, background: `${EMG_LEVEL_COLORS[event.level]}22`, color: EMG_LEVEL_COLORS[event.level], border: `1px solid ${EMG_LEVEL_COLORS[event.level]}44` }}>{EMG_LEVEL_LABELS[event.level]}</span>
        </div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: 4 }}><X size={16} /></button>
      </div>
      {/* 内容 */}
      <div style={{ padding: '12px 16px' }}>
        <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 8 }}>{EMERGENCY_TYPE_LABELS[event.type]}</div>
        <div style={{ fontSize: 12, color: '#e2e8f0', fontWeight: 600, marginBottom: 4 }}>{event.location} · {event.address}</div>
        <div style={{ fontSize: 11, color: '#94a3b8', marginBottom: 10, lineHeight: 1.5 }}>{event.description}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, paddingTop: 10, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <span style={{ fontSize: 10, color: '#94a3b8' }}>{EMG_STATUS[event.status]}</span>
          <span style={{ fontSize: 10, color: '#64748b', marginLeft: 'auto', fontFamily: 'Roboto Mono, monospace' }}>{event.time}</span>
        </div>
      </div>
    </div>
  );
}
