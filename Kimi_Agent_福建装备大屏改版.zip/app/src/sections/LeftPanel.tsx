import { useEffect, useRef, useState } from 'react';
import { PieChart, Package, Truck, Factory, FileCheck } from 'lucide-react';
import * as echarts from 'echarts';
import type { EquipmentData, DistributionData } from '../hooks/useRealtimeData';

interface LeftPanelProps {
  equipment: EquipmentData;
  distribution: DistributionData;
}

// 精确高度分配（基于 1000px 视口）
const PADDING = 16;
const GAP = 12;
const MOD1_H = 190;  // 装备分类占比（饼图）
const MOD3_H = 225;  // 供应统计（增加高度确保4项完整显示）
// 装备分布统计 = 剩余空间

export default function LeftPanel({ equipment, distribution }: LeftPanelProps) {
  const pieRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const pieChart = useRef<echarts.ECharts | null>(null);
  const barChart = useRef<echarts.ECharts | null>(null);

  // 供应统计数据（模拟实时变化）
  const [supplyStats, setSupplyStats] = useState({
    products: 1248,
    suppliers: 86,
    manufacturers: 42,
    agreementSuppliers: 35,
  });

  useEffect(() => {
    if (pieRef.current && !pieChart.current) pieChart.current = echarts.init(pieRef.current);
    if (barRef.current && !barChart.current) barChart.current = echarts.init(barRef.current);
    const onResize = () => { pieChart.current?.resize(); barChart.current?.resize(); };
    window.addEventListener('resize', onResize);
    return () => {
      window.removeEventListener('resize', onResize);
      try { pieChart.current?.dispose(); barChart.current?.dispose(); } catch (e) { /* ignore */ }
      pieChart.current = null; barChart.current = null;
    };
  }, []);

  // 供应统计数据定时微调
  useEffect(() => {
    const timer = setInterval(() => {
      setSupplyStats(prev => ({
        products: prev.products + Math.floor(Math.random() * 5),
        suppliers: Math.max(60, prev.suppliers + (Math.random() > 0.7 ? 1 : 0)),
        manufacturers: Math.max(30, prev.manufacturers + (Math.random() > 0.8 ? 1 : 0)),
        agreementSuppliers: Math.max(20, prev.agreementSuppliers + (Math.random() > 0.85 ? 1 : 0)),
      }));
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  // 饼图 — 带标签显示数量和占比
  useEffect(() => {
    if (!pieChart.current) return;
    pieChart.current.setOption({
      tooltip: { trigger: 'item', backgroundColor: 'rgba(16,30,55,0.9)', borderColor: 'rgba(0,240,255,0.3)', textStyle: { color: '#fff', fontSize: 12 }, formatter: (params: any) => `<div style="font-weight:700;margin-bottom:3px;color:#00f0ff">${params.name}</div><div>数量: <b>${params.value.toLocaleString()}</b></div><div>占比: <b>${params.percent}%</b></div>` },
      legend: { orient: 'vertical', right: 0, top: 'center', textStyle: { color: '#94a3b8', fontSize: 10 }, itemWidth: 8, itemHeight: 8, itemGap: 5 },
      series: [{ type: 'pie', radius: ['38%', '62%'], center: ['30%', '50%'], avoidLabelOverlap: false, padAngle: 2, itemStyle: { borderRadius: 4, borderColor: '#0a1120', borderWidth: 2 }, label: { show: true, position: 'outside', formatter: (p: any) => `{n|${p.name}}\n{v|${p.value.toLocaleString()}} {pct|${p.percent}%}`, rich: { n: { fontSize: 9, color: '#94a3b8', lineHeight: 14 }, v: { fontSize: 10, color: '#e2e8f0', fontWeight: 700, fontFamily: 'Roboto Mono, monospace' }, pct: { fontSize: 9, color: '#00f0ff', fontWeight: 600 } } }, emphasis: { label: { show: true, fontSize: 13, fontWeight: 'bold', color: '#fff' } }, data: equipment.categoryDistribution.map((cat, i) => ({ ...cat, itemStyle: { color: ['#00f0ff', '#00ff9d', '#ffcc00', '#ff6b6b', '#a78bfa', '#4ecdc4', '#ff8c42', '#c7f464'][i] } })) }],
    });
  }, [equipment.categoryDistribution]);

  // 横道图 — 确保10个城市全部显示
  useEffect(() => {
    if (!barChart.current || !barRef.current) return;
    // 获取echarts容器实际高度（减去标题和统计卡片）
    const containerH = barRef.current.clientHeight;
    barChart.current.resize({ height: containerH });

    const sorted = [...distribution.cityDistribution].sort((a, b) => a.total - b.total);
    barChart.current.setOption({
      tooltip: {
        trigger: 'axis', backgroundColor: 'rgba(16,30,55,0.95)', borderColor: 'rgba(0,240,255,0.3)', textStyle: { color: '#fff', fontSize: 12 },
        formatter: (params: any) => {
          const city = params[0].name;
          const g = params.find((p: any) => p.seriesName === '一般装备')?.value || 0;
          const e = params.find((p: any) => p.seriesName === '应急装备')?.value || 0;
          const t = g + e;
          return `<div style="font-weight:700;margin-bottom:6px;color:#00f0ff">${city}</div><div style="margin-bottom:3px"><span style="color:#00a8ff">■</span> 一般: <b>${g.toLocaleString()}</b> (${t > 0 ? ((g / t) * 100).toFixed(1) : 0}%)</div><div style="margin-bottom:3px"><span style="color:#ff4444">■</span> 应急: <b>${e.toLocaleString()}</b> (${t > 0 ? ((e / t) * 100).toFixed(1) : 0}%)</div><div style="border-top:1px solid rgba(255,255,255,0.1);margin-top:4px;padding-top:4px;color:#94a3b8">合计: <b style="color:#fff">${t.toLocaleString()}</b></div>`;
        },
      },
      legend: { show: true, top: 0, right: 0, textStyle: { color: '#94a3b8', fontSize: 9 }, itemWidth: 8, itemHeight: 5, itemGap: 8 },
      grid: { left: 2, right: 8, top: 18, bottom: 1, containLabel: true },
      xAxis: { type: 'value', axisLabel: { color: '#64748b', fontSize: 8 }, splitLine: { lineStyle: { color: 'rgba(0,240,255,0.05)' } }, axisLine: { show: false } },
      yAxis: { type: 'category', data: sorted.map(d => d.city), axisLabel: { color: '#94a3b8', fontSize: 10, interval: 0 }, axisLine: { show: false }, axisTick: { show: false } },
      series: [
        { name: '一般装备', type: 'bar', stack: 'total', data: sorted.map(d => ({ value: d.general, itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{ offset: 0, color: '#0055aa' }, { offset: 1, color: '#00a8ff' }]) } })), barWidth: 5, barGap: '10%', barCategoryGap: '15%' },
        { name: '应急装备', type: 'bar', stack: 'total', data: sorted.map(d => ({ value: d.emergency, itemStyle: { color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [{ offset: 0, color: '#aa2222' }, { offset: 1, color: '#ff4444' }]), borderRadius: [0, 3, 3, 0] } })), barWidth: 5, barGap: '10%', barCategoryGap: '15%' },
      ],
    });
  }, [distribution.cityDistribution]);

  return (
    <aside style={{ position: 'fixed', top: 68, left: 0, bottom: 0, width: '22%', minWidth: 300, padding: `${PADDING}px`, display: 'flex', flexDirection: 'column', gap: GAP, overflow: 'hidden', zIndex: 20 }}>
      {/* === 模块1: 装备分类占比 === */}
      <div className="glass-panel" style={{ padding: 14, flexShrink: 0, height: MOD1_H, overflow: 'hidden' }}>
        <div className="module-title" style={{ marginBottom: 8, paddingBottom: 8, fontSize: 14 }}><PieChart size={14} />装备分类占比</div>
        <div ref={pieRef} style={{ width: '100%', height: 'calc(100% - 30px)' }} />
      </div>

      {/* === 模块2: 装备分布统计 === */}
      <div className="glass-panel" style={{ padding: 14, flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div className="module-title" style={{ marginBottom: 6, paddingBottom: 6, fontSize: 14 }}>装备分布统计</div>
        <div style={{ display: 'flex', gap: 6, marginBottom: 8, flexShrink: 0 }}>
          <div style={{ flex: 1, textAlign: 'center', padding: '4px 2px', background: 'rgba(0,100,200,0.06)', borderRadius: 5 }}>
            <div style={{ fontSize: 9, color: '#94a3b8' }}>总库存</div>
            <div className="stat-number" style={{ fontSize: 13, color: '#00f0ff' }}>{distribution.totalInventory.toLocaleString()}</div>
          </div>
          <div style={{ flex: 1, textAlign: 'center', padding: '4px 2px', background: 'rgba(0,100,200,0.06)', borderRadius: 5 }}>
            <div style={{ fontSize: 9, color: '#94a3b8' }}>一般装备</div>
            <div className="stat-number" style={{ fontSize: 13, color: '#00a8ff' }}>{distribution.generalCount.toLocaleString()}</div>
          </div>
          <div style={{ flex: 1, textAlign: 'center', padding: '4px 2px', background: 'rgba(255,68,68,0.06)', borderRadius: 5 }}>
            <div style={{ fontSize: 9, color: '#94a3b8' }}>应急装备</div>
            <div className="stat-number" style={{ fontSize: 13, color: '#ff4444' }}>{distribution.emergencyCount.toLocaleString()}</div>
          </div>
        </div>
        <div ref={barRef} style={{ width: '100%', flex: 1, minHeight: 0 }} />
      </div>

      {/* === 模块3: 供应统计 === */}
      <div className="glass-panel" style={{ padding: 14, flexShrink: 0, height: MOD3_H, overflow: 'hidden' }}>
        <div className="module-title" style={{ marginBottom: 8, paddingBottom: 8, fontSize: 14 }}><Truck size={14} />供应统计</div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {/* 商品 */}
          <div style={{ padding: '6px 4px', background: 'rgba(0,168,255,0.05)', borderRadius: 8, border: '1px solid rgba(0,168,255,0.12)', textAlign: 'center' }}>
            <Package size={15} style={{ color: '#00a8ff', marginBottom: 2 }} />
            <div className="stat-number" style={{ fontSize: 17, color: '#00f0ff', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' }}>{String(supplyStats.products).padStart(4, '0')}</div>
            <div style={{ fontSize: 9, color: '#64748b', marginTop: 1 }}>商品</div>
          </div>
          {/* 供应商 */}
          <div style={{ padding: '6px 4px', background: 'rgba(0,255,157,0.05)', borderRadius: 8, border: '1px solid rgba(0,255,157,0.12)', textAlign: 'center' }}>
            <Truck size={15} style={{ color: '#00ff9d', marginBottom: 2 }} />
            <div className="stat-number" style={{ fontSize: 17, color: '#00ff9d', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' }}>{String(supplyStats.suppliers).padStart(3, '0')}</div>
            <div style={{ fontSize: 9, color: '#64748b', marginTop: 1 }}>供应商</div>
          </div>
          {/* 生产商 */}
          <div style={{ padding: '6px 4px', background: 'rgba(255,204,0,0.05)', borderRadius: 8, border: '1px solid rgba(255,204,0,0.12)', textAlign: 'center' }}>
            <Factory size={15} style={{ color: '#ffcc00', marginBottom: 2 }} />
            <div className="stat-number" style={{ fontSize: 17, color: '#ffcc00', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' }}>{String(supplyStats.manufacturers).padStart(3, '0')}</div>
            <div style={{ fontSize: 9, color: '#64748b', marginTop: 1 }}>生产商</div>
          </div>
          {/* 协议供货商 */}
          <div style={{ padding: '6px 4px', background: 'rgba(167,139,250,0.05)', borderRadius: 8, border: '1px solid rgba(167,139,250,0.12)', textAlign: 'center' }}>
            <FileCheck size={15} style={{ color: '#a78bfa', marginBottom: 2 }} />
            <div className="stat-number" style={{ fontSize: 17, color: '#a78bfa', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' }}>{String(supplyStats.agreementSuppliers).padStart(3, '0')}</div>
            <div style={{ fontSize: 9, color: '#64748b', marginTop: 1 }}>协议供货商</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
