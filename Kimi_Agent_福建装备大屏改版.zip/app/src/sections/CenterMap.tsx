import EChartsMap from './EChartsMap';
import type { BusinessEvent, WarningItem, EmergencyEvent, EquipmentData, DistributionData } from '../hooks/useRealtimeData';

interface CenterMapProps {
  events: BusinessEvent[];
  warnings: WarningItem[];
  emergencyEvents: EmergencyEvent[];
  selectedEmergency?: EmergencyEvent | null;
  onSelectEmergency?: (evt: EmergencyEvent | null) => void;
  equipment: EquipmentData;
  distribution: DistributionData;
  drillDown?: 'province' | 'fuzhou';
  onDrillDown?: (v: 'province' | 'fuzhou') => void;
}

export default function CenterMap(props: CenterMapProps) {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <EChartsMap {...props} />
    </div>
  );
}
