import { useState, useCallback, useEffect } from 'react';
import {
  Siren, Crosshair, Package, Route, GitBranch, ChevronRight, Circle, CheckCircle2, Loader2,
  Truck, Plus, X, Check, AlertTriangle, BookOpen, BarChart3, TrendingUp,
  Clock as ClockIcon, Zap,
} from 'lucide-react';
import { useRealtimeData, EMERGENCY_TYPE_LABELS } from '../hooks/useRealtimeData';
import type {
  EmergencyEvent, EmergencyType, EmergencyLevel, EmergencyAnalysis,
  EquipmentDistribution, TransferScheme,
} from '../hooks/useRealtimeData';
import EmergencyEChartsMap from './EmergencyEChartsMap';

const EMG_COLORS: Record<string, string> = {
  terrorist: '#ff1a1a', criminal: '#ff6600', mass: '#ffaa00',
  disaster: '#3366ff', security: '#00cc66', checkpoint: '#aa44ff',
};
const EMG_LEVEL_LABELS = { general: '三级（一般）', severe: '二级（严重）', critical: '一级（危急）' };
const EMG_LEVEL_COLORS = { general: '#ffcc00', severe: '#ff8800', critical: '#ff1a1a' };
const EMG_STATUS: Record<string, string> = {
  reported: '已接报', analyzing: '分析中', dispatched: '已调拨', coordinating: '联动中', resolved: '已处置',
};
const STATUS_ICONS: Record<string, typeof Circle> = {
  reported: Siren, analyzing: Loader2, dispatched: Truck, coordinating: GitBranch, resolved: CheckCircle2,
};

export default function EmergencyDashboard() {
  const {
    emergencyEvents, emergencyAnalyses, emergencyDistributions,
    emergencyTransfers, addEmergencyEvent, resolveEmergencyEvent,
  } = useRealtimeData();

  const [selectedEvent, setSelectedEvent] = useState<EmergencyEvent | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showLegend, setShowLegend] = useState(false);
  const [showStatsModal, setShowStatsModal] = useState(false);

  // 默认选中事件1（数组第一个），数据加载后生效
  useEffect(() => {
    if (emergencyEvents.length > 0 && !selectedEvent) {
      setSelectedEvent(emergencyEvents[0]);
    }
  }, [emergencyEvents]);

  // 点击事件：选中/取消选中
  const handleSelectEvent = useCallback((evt: EmergencyEvent) => {
    setSelectedEvent(prev => prev?.id === evt.id ? null : evt);
  }, []);

  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', position: 'relative' }}>
      {/* ===== 左侧：应急事件列表 ===== */}
      <aside style={{ position: 'fixed', top: 68, left: 0, bottom: 0, width: '22%', minWidth: 300, padding: '12px', display: 'flex', flexDirection: 'column', gap: 10, overflow: 'hidden', zIndex: 20 }}>
        <EmergencyEventList
          events={emergencyEvents}
          analyses={emergencyAnalyses}
          selected={selectedEvent}
          onSelect={handleSelectEvent}
          onAdd={() => setShowAddForm(true)}
          onResolve={resolveEmergencyEvent}
          onShowStats={() => setShowStatsModal(true)}
        />
        {showAddForm && (
          <AddEventForm onAdd={addEmergencyEvent} onClose={() => setShowAddForm(false)} />
        )}
      </aside>

      {/* ===== 中央：ECharts 应急地图 ===== */}
      <div style={{ position: 'fixed', top: 68, left: '22%', right: '22%', bottom: 0, zIndex: 5 }}>
        <EmergencyEChartsMap
          events={emergencyEvents}
          selected={selectedEvent}
          onSelect={setSelectedEvent}
        />
        {/* 底部滚动条 */}
        <EmergencyTicker events={emergencyEvents} />
        {/* 右下角图例按钮 */}
        <button
          onClick={() => setShowLegend(!showLegend)}
          style={{
            position: 'absolute', bottom: 52, right: 16, zIndex: 25,
            display: 'flex', alignItems: 'center', gap: 5,
            padding: '6px 14px',
            background: showLegend ? 'rgba(0,240,255,0.2)' : 'rgba(5,10,20,0.8)',
            backdropFilter: 'blur(8px)', borderRadius: 20,
            border: `1px solid ${showLegend ? 'rgba(0,240,255,0.4)' : 'rgba(255,255,255,0.12)'}`,
            color: showLegend ? '#00f0ff' : '#94a3b8', fontSize: 12, fontWeight: 600,
            cursor: 'pointer', transition: 'all 0.25s ease',
            boxShadow: showLegend ? '0 0 12px rgba(0,240,255,0.15)' : '0 2px 8px rgba(0,0,0,0.3)',
          }}
        >
          <BookOpen size={14} />图例
        </button>
        {showLegend && <LegendPanel onClose={() => setShowLegend(false)} />}
        {showStatsModal && <DataStatsModal events={emergencyEvents} transfers={emergencyTransfers} onClose={() => setShowStatsModal(false)} />}
      </div>

      {/* ===== 右侧：自动分析推荐 + 周边装备分布 + 联合调拨方案 ===== */}
      <aside style={{ position: 'fixed', top: 68, right: 0, bottom: 0, width: '22%', minWidth: 300, padding: '12px', display: 'flex', flexDirection: 'column', gap: 10, overflow: 'hidden', zIndex: 20 }}>
        {selectedEvent && (
          <>
            <AnalysisRecommendPanel analysis={emergencyAnalyses[selectedEvent.id]} />
            <EquipmentDistributionPanel distribution={emergencyDistributions[selectedEvent.id]} />
            <TransferStrategyPanel transfers={emergencyTransfers[selectedEvent.id]} />
          </>
        )}
      </aside>
    </div>
  );
}

// ===== 应急事件列表（左侧） =====
function EmergencyEventList({ events, analyses, selected, onSelect, onAdd, onResolve, onShowStats }: {
  events: EmergencyEvent[]; analyses: Record<string, EmergencyAnalysis>; selected: EmergencyEvent | null; onSelect: (e: EmergencyEvent) => void; onAdd: () => void; onResolve: (id: string) => void; onShowStats: () => void;
}) {
  const [filter, setFilter] = useState<'all' | 'critical' | 'severe' | 'general'>('all');
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const activeEvents = events.filter(e => e.status !== 'resolved');
  const historyEvents = events.filter(e => e.status === 'resolved');
  const allEvents = [...activeEvents, ...historyEvents];
  const filtered = filter === 'all' ? allEvents : allEvents.filter(e => e.level === filter);

  return (
    <>
      {/* ===== 事件统计卡片 ===== */}
      <div className="glass-panel" style={{ padding: '12px 14px', flexShrink: 0 }}>
        <div className="module-title" style={{ fontSize: 13, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
          <BarChart3 size={13} style={{ color: '#00f0ff' }} />事件统计
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
          {allEvents.map((evt, idx) => {
            // 统计该类型事件的总发生次数
            const typeCount = events.filter(e => e.type === evt.type).length;
            const color = EMG_COLORS[evt.type] || '#94a3b8';
            return (
              <div key={evt.id} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: 'rgba(255,255,255,0.02)', borderRadius: 6 }}>
                <div style={{ width: 8, height: 8, background: color, transform: 'rotate(45deg)', boxShadow: `0 0 6px ${color}`, flexShrink: 0 }} />
                <span style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0', flex: 1 }}>事件{idx + 1}</span>
                <span style={{ fontSize: 18, fontWeight: 900, color, fontFamily: 'Roboto Mono, monospace' }}>{typeCount}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="glass-panel" style={{ padding: '12px 14px', flexShrink: 0 }}>
        <div className="module-title" style={{ fontSize: 14, marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Siren size={14} style={{ color: '#ff4444' }} />应急事件</div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            <span style={{ fontSize: 10, color: '#64748b' }}>活跃{activeEvents.length} · 历史{historyEvents.length}</span>
            <button onClick={onShowStats} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '3px 10px', background: 'rgba(0,240,255,0.1)', border: '1px solid rgba(0,240,255,0.25)', borderRadius: 10, color: '#00f0ff', fontSize: 10, fontWeight: 600, cursor: 'pointer', transition: 'all 0.2s' }} onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,240,255,0.2)')} onMouseLeave={e => (e.currentTarget.style.background = 'rgba(0,240,255,0.1)')}><BarChart3 size={11} />分析</button>
            <button onClick={onAdd} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '3px 10px', background: 'rgba(255,68,68,0.15)', border: '1px solid rgba(255,68,68,0.3)', borderRadius: 10, color: '#ff4444', fontSize: 10, fontWeight: 600, cursor: 'pointer', transition: 'all 0.2s' }} onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,68,68,0.25)')} onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,68,68,0.15)')}><Plus size={11} />添加</button>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 3, padding: 2, background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
          {([['all', '全部'], ['critical', '危急'], ['severe', '严重'], ['general', '一般']] as const).map(([k, l]) => (
            <button key={k} onClick={() => setFilter(k)} style={{ flex: 1, padding: '3px 0', borderRadius: 8, fontSize: 10, fontWeight: 600, border: 'none', cursor: 'pointer', background: filter === k ? 'rgba(0,240,255,0.15)' : 'transparent', color: filter === k ? '#00f0ff' : '#64748b' }}>{l}</button>
          ))}
        </div>
      </div>

      <div className="glass-panel" style={{ padding: '10px 12px', flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 5, overflow: 'hidden' }}>
          {filtered.length === 0 && <div style={{ textAlign: 'center', padding: '24px 0', color: '#64748b', fontSize: 12 }}>暂无事件</div>}
          {filtered.map((evt, idx) => {
            const analysis = analyses[evt.id];
            const StatusIcon = STATUS_ICONS[evt.status] || Circle;
            const isSel = selected?.id === evt.id;
            const isHistory = evt.status === 'resolved';
            const isFirstHistory = isHistory && (idx === 0 || filtered[idx - 1].status !== 'resolved');
            return (
              <div key={evt.id}>
                {isFirstHistory && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', marginBottom: 4 }}>
                    <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.08)' }} />
                    <span style={{ fontSize: 9, color: '#475569', fontWeight: 600, letterSpacing: 1 }}>历史事件</span>
                    <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.08)' }} />
                  </div>
                )}
                <div onClick={() => onSelect(evt)} style={{ padding: '8px 10px', borderRadius: 8, cursor: 'pointer', transition: 'all 0.2s', background: isSel ? 'rgba(255,68,68,0.15)' : 'rgba(0,0,0,0.15)', border: `1px solid ${isSel ? EMG_COLORS[evt.type] : 'rgba(255,255,255,0.05)'}`, opacity: isHistory ? 0.55 : 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', background: EMG_COLORS[evt.type], boxShadow: `0 0 8px ${EMG_COLORS[evt.type]}`, flexShrink: 0 }} />
                    <span style={{ fontSize: 9, fontWeight: 700, padding: '1px 6px', borderRadius: 4, background: `${EMG_LEVEL_COLORS[evt.level]}22`, color: EMG_LEVEL_COLORS[evt.level], border: `1px solid ${EMG_LEVEL_COLORS[evt.level]}44` }}>{EMG_LEVEL_LABELS[evt.level]}</span>
                    <span style={{ fontSize: 12, fontWeight: 600, color: EMG_COLORS[evt.type], flex: 1 }}>事件{idx + 1}</span>
                    {isHistory && <span style={{ fontSize: 9, padding: '1px 6px', borderRadius: 4, background: 'rgba(0,255,157,0.1)', color: '#00ff9d', border: '1px solid rgba(0,255,157,0.2)' }}>已结束</span>}
                    <StatusIcon size={11} style={{ color: '#94a3b8' }} />
                  </div>
                  <div style={{ fontSize: 11, color: '#e2e8f0', marginBottom: 2 }}>{evt.location} · {evt.address}</div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ fontSize: 10, color: '#64748b', display: 'flex', gap: 8 }}>
                      <span>{evt.time}</span><span>{EMG_STATUS[evt.status]}</span>
                    </div>
                    {!isHistory && (
                      <button onClick={(e) => { e.stopPropagation(); setConfirmId(evt.id); }} style={{ display: 'flex', alignItems: 'center', gap: 2, padding: '1px 6px', background: 'rgba(0,255,157,0.1)', border: '1px solid rgba(0,255,157,0.25)', borderRadius: 6, color: '#00ff9d', fontSize: 9, fontWeight: 600, cursor: 'pointer' }} onMouseEnter={e => (e.currentTarget.style.background = 'rgba(0,255,157,0.2)')} onMouseLeave={e => (e.currentTarget.style.background = 'rgba(0,255,157,0.1)')}><Check size={9} />结束</button>
                    )}
                  </div>
                  {analysis && (
                    <div style={{ marginTop: 4, padding: '3px 6px', background: 'rgba(0,240,255,0.05)', borderRadius: 4 }}>
                      <span style={{ fontSize: 9, color: '#94a3b8' }}>推荐: </span>
                      {analysis.recommendations.slice(0, 2).map((r, i) => (
                        <span key={i} style={{ fontSize: 9, color: '#00f0ff' }}>{r.name}×{r.quantity}{i < 1 ? ', ' : ''}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* 二次确认弹窗 */}
      {confirmId && (
        <div style={{ position: 'absolute', inset: 0, zIndex: 500, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
          <div className="glass-panel" style={{ width: 300, padding: '20px 24px', borderRadius: 14, border: '1px solid rgba(255,68,68,0.25)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12 }}>
              <AlertTriangle size={20} style={{ color: '#ff4444' }} />
              <h4 style={{ fontSize: 15, fontWeight: 700, color: '#ff4444' }}>确认结束事件？</h4>
            </div>
            <p style={{ fontSize: 12, color: '#94a3b8', marginBottom: 16 }}>结束后该事件将标记为历史事件。此操作不可撤销。</p>
            <div style={{ display: 'flex', gap: 8 }}>
              <button onClick={() => setConfirmId(null)} style={{ flex: 1, padding: '8px', borderRadius: 10, fontSize: 12, fontWeight: 600, border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(0,0,0,0.15)', color: '#94a3b8', cursor: 'pointer' }}>取消</button>
              <button onClick={() => { onResolve(confirmId); setConfirmId(null); }} style={{ flex: 1, padding: '8px', borderRadius: 10, fontSize: 12, fontWeight: 600, border: 'none', background: 'rgba(255,68,68,0.2)', color: '#ff4444', cursor: 'pointer' }}>确认结束</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

// ===== 底部滚动条（纯CSS animation，无RAF） =====
function EmergencyTicker({ events }: { events: EmergencyEvent[] }) {
  const items = events.filter(e => e.status !== 'resolved').slice(0, 8);
  if (items.length === 0) return null;
  const doubled = [...items, ...items, ...items];
  return (
    <div style={{ position: 'absolute', bottom: 10, left: 14, right: 14, zIndex: 15, height: 32, background: 'rgba(10,5,5,0.85)', backdropFilter: 'blur(8px)', borderRadius: 16, border: '1px solid rgba(255,80,80,0.18)', overflow: 'hidden', display: 'flex', alignItems: 'center' }}>
      <div style={{ padding: '0 10px', fontSize: 10, fontWeight: 700, color: '#ff4444', borderRight: '1px solid rgba(255,80,80,0.2)', whiteSpace: 'nowrap', flexShrink: 0, letterSpacing: 1 }}>应急动态</div>
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', gap: 28, padding: '0 14px', animation: 'tickerScroll 40s linear infinite' }}>
          {doubled.map((e, i) => (
            <div key={`${e.id}-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 7, flexShrink: 0 }}>
              <div style={{ width: 6, height: 6, background: EMG_COLORS[e.type], transform: 'rotate(45deg)', boxShadow: `0 0 4px ${EMG_COLORS[e.type]}` }} />
              <span style={{ fontSize: 10, color: '#64748b', fontFamily: 'Roboto Mono, monospace' }}>[{e.time}]</span>
              <span style={{ fontSize: 10, fontWeight: 600, color: EMG_COLORS[e.type] }}>{EMERGENCY_TYPE_LABELS[e.type]}</span>
              <span style={{ fontSize: 10, color: '#e2e8f0' }}>{e.location}</span>
              <span style={{ fontSize: 10, color: EMG_LEVEL_COLORS[e.level] }}>{EMG_LEVEL_LABELS[e.level]}</span>
              <span style={{ fontSize: 10, color: '#94a3b8' }}>{EMG_STATUS[e.status]}</span>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes tickerScroll{from{transform:translateX(0)}to{transform:translateX(-33.33%)}}`}</style>
    </div>
  );
}

// ===== 自动分析推荐面板（右侧上） =====
function AnalysisRecommendPanel({ analysis }: { analysis?: EmergencyAnalysis }) {
  if (!analysis) return null;
  return (
    <div className="glass-panel" style={{ padding: '12px 14px', flexShrink: 0 }}>
      <div className="module-title" style={{ fontSize: 13, marginBottom: 8 }}><Crosshair size={13} style={{ color: '#00f0ff' }} />自动分析推荐</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {analysis.recommendations.map((rec, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 8px', background: 'rgba(0,240,255,0.04)', borderRadius: 6 }}>
            <ChevronRight size={10} style={{ color: '#00f0ff', flexShrink: 0 }} />
            <span style={{ fontSize: 11, color: '#e2e8f0', fontWeight: 500 }}>{rec.name}</span>
            <span style={{ fontSize: 10, color: '#64748b' }}>{rec.spec}</span>
            <span style={{ fontSize: 12, color: '#00f0ff', fontFamily: 'Roboto Mono, monospace', marginLeft: 'auto', fontWeight: 800 }}>×{rec.quantity}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== 装备分布分析面板（右侧中） =====
function EquipmentDistributionPanel({ distribution }: { distribution?: EquipmentDistribution }) {
  if (!distribution) return null;
  const equipTotals: Record<string, { totalAvail: number; totalNeed: number }> = {};
  distribution.warehouses.forEach(w => {
    w.equipment.forEach(eq => {
      if (!equipTotals[eq.name]) equipTotals[eq.name] = { totalAvail: 0, totalNeed: eq.needed };
      equipTotals[eq.name].totalAvail += eq.available;
    });
  });
  const shortfallItems = Object.entries(equipTotals).filter(([_, v]) => v.totalAvail < v.totalNeed);

  return (
    <div className="glass-panel" style={{ padding: '12px 14px', flexShrink: 0, maxHeight: 380, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div className="module-title" style={{ fontSize: 13, marginBottom: 8 }}><Package size={13} style={{ color: '#ffcc00' }} />周边装备分布</div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 6, alignItems: 'center' }}>
        <span style={{ fontSize: 10, color: '#64748b' }}>半径{distribution.radius}km</span>
        <span style={{ fontSize: 10, color: '#64748b' }}>仓库{distribution.warehouses.length}个</span>
        <span style={{ fontSize: 12, fontWeight: 800, color: '#ff8c42', marginLeft: 'auto', fontFamily: 'Roboto Mono, monospace' }}>联合调度</span>
      </div>
      <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden', marginBottom: 6 }}>
        <div style={{ width: `${Math.min(100, distribution.overallFulfillment)}%`, height: '100%', background: '#ff8c42', borderRadius: 2, transition: 'width 0.5s' }} />
      </div>
      {shortfallItems.length > 0 && (
        <div style={{ marginBottom: 8, padding: '5px 8px', background: 'rgba(255,140,66,0.08)', borderRadius: 8, border: '1px solid rgba(255,140,66,0.2)' }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: '#ff8c42', marginBottom: 3 }}><GitBranch size={10} style={{ display: 'inline', marginRight: 4 }} />多仓库联合调度</div>
          {shortfallItems.map(([name, v], i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 9 }}>
              <span style={{ color: '#94a3b8', flex: 1 }}>{name}</span>
              <span style={{ color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>总存{v.totalAvail}</span>
              <span style={{ color: '#ff4444', fontFamily: 'Roboto Mono, monospace' }}>需{v.totalNeed}</span>
              <span style={{ color: '#ff8c42', fontWeight: 700 }}>缺口{v.totalNeed - v.totalAvail}</span>
            </div>
          ))}
        </div>
      )}
      <div style={{ overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 5 }}>
        {distribution.warehouses.map((w, i) => (
          <div key={i} style={{ padding: '5px 8px', background: 'rgba(255,255,255,0.02)', borderRadius: 8, border: '1px solid rgba(255,255,255,0.04)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 3 }}>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#e2e8f0' }}>{w.warehouseName}</span>
              <span style={{ fontSize: 9, color: '#64748b' }}>{w.distance}km</span>
              <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.05)', borderRadius: 2, overflow: 'hidden' }}>
                <div style={{ width: `${w.fulfillmentRate}%`, height: '100%', background: w.fulfillmentRate >= 80 ? '#00ff9d' : w.fulfillmentRate >= 50 ? '#ffcc00' : '#ff4444', borderRadius: 2 }} />
              </div>
              <span style={{ fontSize: 10, fontWeight: 700, color: w.fulfillmentRate >= 80 ? '#00ff9d' : w.fulfillmentRate >= 50 ? '#ffcc00' : '#ff4444', fontFamily: 'Roboto Mono, monospace' }}>{w.fulfillmentRate}%</span>
            </div>
            {w.equipment.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
                {w.equipment.map((eq, j) => {
                  const isShort = eq.available < eq.needed;
                  return (
                    <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '1px 0' }}>
                      <span style={{ fontSize: 9, color: '#94a3b8', flex: 1 }}>{eq.name}</span>
                      <span style={{ fontSize: 9, color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>存{eq.available}</span>
                      <span style={{ fontSize: 9, color: '#ff4444', fontFamily: 'Roboto Mono, monospace' }}>需{eq.needed}</span>
                      {isShort && <span style={{ fontSize: 8, padding: '1px 4px', borderRadius: 4, background: 'rgba(255,68,68,0.15)', color: '#ff4444', fontWeight: 700 }}>不足</span>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== 调拨策略面板（3种方案选择） =====
function TransferStrategyPanel({ transfers }: { transfers?: TransferScheme[] }) {
  const [selectedScheme, setSelectedScheme] = useState(0);
  if (!transfers || transfers.length === 0) {
    return (
      <div className="glass-panel" style={{ padding: '12px 14px', flex: 1, minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        <div className="module-title" style={{ fontSize: 13, marginBottom: 8 }}><Route size={13} style={{ color: '#00ff9d' }} />联合调拨方案</div>
        <div style={{ textAlign: 'center', padding: '16px 0', color: '#64748b', fontSize: 11 }}>暂无调拨方案</div>
      </div>
    );
  }
  const scheme = transfers[selectedScheme];
  const schemeColors = ['#00ff9d', '#00f0ff', '#ff8c42'];
  const schemeBgs = ['rgba(0,255,157,0.08)', 'rgba(0,240,255,0.08)', 'rgba(255,140,66,0.08)'];
  const equipGroups: Record<string, { total: number; sources: { warehouse: string; qty: number; arrival: string }[] }> = {};
  scheme.plans.forEach(plan => {
    plan.equipment?.forEach(eq => {
      if (!equipGroups[eq.name]) equipGroups[eq.name] = { total: 0, sources: [] };
      equipGroups[eq.name].total += eq.quantity;
      equipGroups[eq.name].sources.push({ warehouse: plan.sourceWarehouse, qty: eq.quantity, arrival: plan.estimatedArrival });
    });
  });

  return (
    <div className="glass-panel" style={{ padding: '12px 14px', flex: 1, minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <div className="module-title" style={{ fontSize: 13, marginBottom: 8 }}><Route size={13} style={{ color: '#00ff9d' }} />联合调拨方案<span style={{ fontSize: 9, color: '#ff8c42', marginLeft: 8, fontWeight: 600 }}>{scheme.plans.length}条调度</span></div>
      <div style={{ display: 'flex', gap: 4, marginBottom: 10, padding: 3, background: 'rgba(255,255,255,0.03)', borderRadius: 10 }}>
        {transfers.map((s, i) => (
          <button key={i} onClick={() => setSelectedScheme(i)} style={{ flex: 1, padding: '5px 4px', borderRadius: 8, fontSize: 10, fontWeight: 700, border: `1px solid ${selectedScheme === i ? schemeColors[i] : 'transparent'}`, background: selectedScheme === i ? schemeBgs[i] : 'transparent', color: selectedScheme === i ? schemeColors[i] : '#64748b', cursor: 'pointer', transition: 'all 0.2s' }}>
            <div>{s.name}</div><div style={{ fontSize: 8, fontWeight: 500, opacity: 0.7 }}>{s.strategy}</div>
          </button>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 10, marginBottom: 10, padding: '5px 8px', background: schemeBgs[selectedScheme], borderRadius: 8, border: `1px solid ${schemeColors[selectedScheme]}22` }}>
        <div style={{ textAlign: 'center', flex: 1 }}><div style={{ fontSize: 9, color: '#64748b' }}>调度仓库</div><div style={{ fontSize: 14, fontWeight: 800, color: schemeColors[selectedScheme], fontFamily: 'Roboto Mono, monospace' }}>{scheme.totalWarehouses}</div></div>
        <div style={{ textAlign: 'center', flex: 1 }}><div style={{ fontSize: 9, color: '#64748b' }}>最长时间</div><div style={{ fontSize: 14, fontWeight: 800, color: schemeColors[selectedScheme], fontFamily: 'Roboto Mono, monospace' }}>{scheme.totalTime}min</div></div>
        <div style={{ textAlign: 'center', flex: 1 }}><div style={{ fontSize: 9, color: '#64748b' }}>调拨条数</div><div style={{ fontSize: 14, fontWeight: 800, color: schemeColors[selectedScheme], fontFamily: 'Roboto Mono, monospace' }}>{scheme.plans.length}</div></div>
      </div>
      <div style={{ overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
        {Object.entries(equipGroups).map(([eqName, data]) => (
          <div key={eqName} style={{ padding: '8px 10px', background: 'rgba(0,255,157,0.04)', borderRadius: 8, border: `1px solid ${schemeColors[selectedScheme]}18` }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6 }}>
              <Package size={12} style={{ color: '#ffcc00', flexShrink: 0 }} />
              <span style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0', flex: 1 }}>{eqName}</span>
              <span style={{ fontSize: 14, fontWeight: 900, color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>x{data.total}</span>
              {data.sources.length > 1 && <span style={{ fontSize: 8, padding: '1px 6px', borderRadius: 6, background: 'rgba(255,140,66,0.15)', color: '#ff8c42', fontWeight: 700, marginLeft: 4 }}>联合{data.sources.length}仓</span>}
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
              {data.sources.map((src, j) => (
                <div key={j} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '3px 6px', background: 'rgba(0,0,0,0.15)', borderRadius: 6 }}>
                  <Truck size={9} style={{ color: schemeColors[selectedScheme], flexShrink: 0 }} />
                  <span style={{ fontSize: 10, fontWeight: 600, color: '#e2e8f0', flex: 1 }}>{src.warehouse}</span>
                  <span style={{ fontSize: 11, fontWeight: 800, color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>x{src.qty}</span>
                  <span style={{ fontSize: 9, color: '#94a3b8' }}>{src.arrival}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ===== 图例面板 =====
function LegendPanel({ onClose }: { onClose: () => void }) {
  const typeItems = [
    { key: 'terrorist', label: '暴力恐怖袭击', color: '#ff1a1a' },
    { key: 'criminal', label: '重大恶性刑事案件', color: '#ff6600' },
    { key: 'mass', label: '群体性事件', color: '#ffaa00' },
    { key: 'disaster', label: '自然灾害应急救援', color: '#3366ff' },
    { key: 'security', label: '大型活动安保', color: '#00cc66' },
    { key: 'checkpoint', label: '临时设卡盘查', color: '#aa44ff' },
  ];
  const levelItems = [
    { label: '一级（危急）', color: '#ff1a1a', desc: '最大菱形 + 脉冲扩散环' },
    { label: '二级（严重）', color: '#ff8800', desc: '中等菱形 + 静态外环' },
    { label: '三级（一般）', color: '#ffcc00', desc: '最小菱形' },
  ];
  return (
    <div style={{ position: 'absolute', bottom: 92, right: 16, zIndex: 25, width: 260, maxHeight: 420, overflowY: 'auto' }}>
      <div className="glass-panel" style={{ padding: '14px 16px', borderRadius: 14, border: '1px solid rgba(0,240,255,0.2)', background: 'rgba(5,10,20,0.92)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(0,240,255,0.15)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 14, fontWeight: 700, color: '#00f0ff' }}><BookOpen size={14} />图例</div>
          <button onClick={onClose} style={{ padding: 2, background: 'transparent', border: 'none', color: '#64748b', cursor: 'pointer' }}><X size={14} /></button>
        </div>
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>事件类型</div>
          {typeItems.map(item => (
            <div key={item.key} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
              <div style={{ width: 10, height: 10, background: item.color, transform: 'rotate(45deg)', boxShadow: `0 0 6px ${item.color}`, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: '#e2e8f0' }}>{item.label}</span>
            </div>
          ))}
        </div>
        <div style={{ marginBottom: 12, paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>事件等级</div>
          {levelItems.map((item, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
              <div style={{ width: 8 + i * 2, height: 8 + i * 2, background: item.color, transform: 'rotate(45deg)', boxShadow: `0 0 4px ${item.color}`, flexShrink: 0 }} />
              <span style={{ fontSize: 11, color: '#e2e8f0' }}>{item.label}</span>
              <span style={{ fontSize: 9, color: '#64748b', marginLeft: 'auto' }}>{item.desc}</span>
            </div>
          ))}
        </div>
        <div style={{ paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>其他说明</div>
          {[
            { icon: '\uD83D\uDD35', label: '城市节点', desc: '青色圆点 + 城市名称' },
            { icon: '\uD83D\uDD34', label: '聚合数量', desc: '红点内显示数字' },
            { icon: '\uD83D\uDD37', label: '选中高亮', desc: '青色边框环绕' },
            { icon: '\u26A1', label: '飞线', desc: '虚线流动动画' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '3px 0', fontSize: 11 }}>
              <span style={{ color: '#94a3b8', width: 16, textAlign: 'center', flexShrink: 0 }}>{item.icon}</span>
              <span style={{ color: '#e2e8f0' }}>{item.label}</span>
              <span style={{ color: '#64748b', fontSize: 9, marginLeft: 'auto' }}>{item.desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== 数据统计分析弹窗 =====
function DataStatsModal({ events, transfers, onClose }: {
  events: EmergencyEvent[]; transfers: Record<string, TransferScheme[]>; onClose: () => void;
}) {
  const totalEvents = events.length;
  const activeCount = events.filter(e => e.status !== 'resolved').length;
  const resolvedCount = events.filter(e => e.status === 'resolved').length;
  const typeFreq: Record<string, number> = {};
  events.forEach(e => { typeFreq[e.type] = (typeFreq[e.type] || 0) + 1; });
  const sortedTypeFreq = Object.entries(typeFreq).filter(([_, count]) => count > 0).sort((a, b) => b[1] - a[1]);
  const levelFreq: Record<string, number> = {};
  events.forEach(e => { levelFreq[e.level] = (levelFreq[e.level] || 0) + 1; });
  const avgResponseMinutes = totalEvents > 0 ? Math.round(events.reduce((s, e) => s + (e.status === 'resolved' || e.status === 'dispatched' ? 18 + Math.floor(Math.random() * 25) : 0), 0) / (resolvedCount || 1)) : 0;
  const equipCount: Record<string, number> = {};
  Object.values(transfers).flat().forEach(scheme => {
    scheme.plans.forEach(plan => {
      plan.equipment?.forEach(eq => { equipCount[eq.name] = (equipCount[eq.name] || 0) + eq.quantity; });
    });
  });
  const sortedEquipRank = Object.entries(equipCount).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const totalConsumption = Object.values(equipCount).reduce((s, c) => s + c, 0);

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 3000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.6)', backdropFilter: 'blur(6px)' }} onClick={onClose}>
      <div style={{ width: 720, maxHeight: '85vh', background: 'linear-gradient(180deg, rgba(8,14,28,0.98) 0%, rgba(5,8,18,0.98) 100%)', borderRadius: 20, border: '1px solid rgba(0,240,255,0.2)', boxShadow: '0 0 40px rgba(0,240,255,0.08), 0 20px 60px rgba(0,0,0,0.5)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }} onClick={e => e.stopPropagation()}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 24px', borderBottom: '1px solid rgba(0,240,255,0.12)', background: 'rgba(0,240,255,0.03)', flexShrink: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 10, background: 'rgba(0,240,255,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><BarChart3 size={20} style={{ color: '#00f0ff' }} /></div>
            <div><div style={{ fontSize: 16, fontWeight: 700, color: '#00f0ff' }}>数据统计分析</div><div style={{ fontSize: 10, color: '#64748b' }}>历次应急事件及装备调拨汇总</div></div>
          </div>
          <button onClick={onClose} style={{ width: 32, height: 32, borderRadius: 8, border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(255,255,255,0.05)', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#94a3b8' }}><X size={16} /></button>
        </div>
        <div style={{ padding: '20px 24px', overflowY: 'auto', flex: 1 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 12, marginBottom: 20 }}>
            <div style={{ padding: '14px 12px', background: 'rgba(0,240,255,0.05)', borderRadius: 12, border: '1px solid rgba(0,240,255,0.12)', textAlign: 'center' }}><Siren size={18} style={{ color: '#ff4444', marginBottom: 6 }} /><div style={{ fontSize: 26, fontWeight: 900, color: '#ff4444', fontFamily: 'Roboto Mono, monospace' }}>{totalEvents}</div><div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>事件总数</div></div>
            <div style={{ padding: '14px 12px', background: 'rgba(0,255,157,0.05)', borderRadius: 12, border: '1px solid rgba(0,255,157,0.12)', textAlign: 'center' }}><Zap size={18} style={{ color: '#00ff9d', marginBottom: 6 }} /><div style={{ fontSize: 26, fontWeight: 900, color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>{activeCount}</div><div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>进行中</div></div>
            <div style={{ padding: '14px 12px', background: 'rgba(255,204,0,0.05)', borderRadius: 12, border: '1px solid rgba(255,204,0,0.12)', textAlign: 'center' }}><CheckCircle2 size={18} style={{ color: '#ffcc00', marginBottom: 6 }} /><div style={{ fontSize: 26, fontWeight: 900, color: '#ffcc00', fontFamily: 'Roboto Mono, monospace' }}>{resolvedCount}</div><div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>已结束</div></div>
            <div style={{ padding: '14px 12px', background: 'rgba(167,139,250,0.05)', borderRadius: 12, border: '1px solid rgba(167,139,250,0.12)', textAlign: 'center' }}><ClockIcon size={18} style={{ color: '#a78bfa', marginBottom: 6 }} /><div style={{ fontSize: 26, fontWeight: 900, color: '#a78bfa', fontFamily: 'Roboto Mono, monospace' }}>{avgResponseMinutes}<span style={{ fontSize: 12 }}>min</span></div><div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>平均响应</div></div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 20 }}>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.04)' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0', marginBottom: 10 }}><TrendingUp size={13} style={{ color: '#00f0ff', display: 'inline', marginRight: 6 }} />事件类型频率</div>
              {sortedTypeFreq.map(([t, count], i) => (
                <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                  <span style={{ width: 18, textAlign: 'center', fontSize: 11, color: '#64748b' }}>{i + 1}</span>
                  <div style={{ width: 7, height: 7, background: EMG_COLORS[t as EmergencyType] || '#94a3b8', transform: 'rotate(45deg)', boxShadow: `0 0 4px ${EMG_COLORS[t as EmergencyType] || '#94a3b8'}`, flexShrink: 0 }} />
                  <span style={{ fontSize: 11, color: '#e2e8f0', flex: 1 }}>{EMERGENCY_TYPE_LABELS[t as EmergencyType] || t}</span>
                  <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}><div style={{ width: `${(count / totalEvents) * 100}%`, height: '100%', background: EMG_COLORS[t as EmergencyType] || '#94a3b8', borderRadius: 2 }} /></div>
                  <span style={{ fontSize: 12, fontWeight: 800, color: EMG_COLORS[t as EmergencyType] || '#94a3b8', fontFamily: 'Roboto Mono, monospace', width: 24, textAlign: 'right' }}>{count}</span>
                </div>
              ))}
            </div>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.04)' }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0', marginBottom: 10 }}><AlertTriangle size={13} style={{ color: '#ff4444', display: 'inline', marginRight: 6 }} />事件等级分布</div>
              {Object.entries(levelFreq).map(([lv, count]) => (
                <div key={lv} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 0' }}>
                  <span style={{ fontSize: 10, fontWeight: 700, padding: '2px 8px', borderRadius: 6, background: `${EMG_LEVEL_COLORS[lv as EmergencyLevel]}22`, color: EMG_LEVEL_COLORS[lv as EmergencyLevel], border: `1px solid ${EMG_LEVEL_COLORS[lv as EmergencyLevel]}44` }}>{EMG_LEVEL_LABELS[lv as EmergencyLevel]}</span>
                  <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}><div style={{ width: `${(count / totalEvents) * 100}%`, height: '100%', background: EMG_LEVEL_COLORS[lv as EmergencyLevel], borderRadius: 2 }} /></div>
                  <span style={{ fontSize: 12, fontWeight: 800, color: EMG_LEVEL_COLORS[lv as EmergencyLevel], fontFamily: 'Roboto Mono, monospace', width: 24, textAlign: 'right' }}>{count}</span>
                </div>
              ))}
            </div>
          </div>
          {sortedEquipRank.length > 0 && (
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.04)', marginBottom: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <BarChart3 size={13} style={{ color: '#00f0ff' }} />
                <span style={{ fontSize: 12, fontWeight: 700, color: '#e2e8f0' }}>常用调拨装备排名</span>
                <span style={{ fontSize: 10, color: '#64748b', marginLeft: 'auto' }}>总消耗 {totalConsumption.toLocaleString()} 件</span>
              </div>
              {sortedEquipRank.map(([name, count], i) => (
                <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
                  <span style={{ width: 18, textAlign: 'center', fontSize: 11, color: '#64748b' }}>{i + 1}</span>
                  <span style={{ fontSize: 11, color: '#e2e8f0', flex: 1 }}>{name}</span>
                  <div style={{ flex: 1, height: 4, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}><div style={{ width: `${(count / totalConsumption) * 100}%`, height: '100%', background: i < 3 ? '#00f0ff' : '#64748b', borderRadius: 2 }} /></div>
                  <span style={{ fontSize: 12, fontWeight: 800, color: i < 3 ? '#00f0ff' : '#94a3b8', fontFamily: 'Roboto Mono, monospace', width: 40, textAlign: 'right' }}>{count}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ===== 添加事件表单 =====
function AddEventForm({ onAdd, onClose }: { onAdd: (p: { type: EmergencyType; level: EmergencyLevel; location: string; address: string; description: string }) => void; onClose: () => void; }) {
  const [type, setType] = useState<EmergencyType>('mass');
  const [level, setLevel] = useState<EmergencyLevel>('general');
  const [location, setLocation] = useState('福州市');
  const [address, setAddress] = useState('');
  const [description, setDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdd({ type, level, location, address, description });
    onClose();
  };

  const typeOptions: EmergencyType[] = ['terrorist', 'criminal', 'mass', 'disaster', 'security', 'checkpoint'];
  const levelOptions: EmergencyLevel[] = ['critical', 'severe', 'general'];

  return (
    <div style={{ position: 'fixed', inset: 0, zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(4px)' }}>
      <div style={{ width: 420, padding: '24px', background: 'linear-gradient(180deg, rgba(8,14,28,0.98) 0%, rgba(5,8,18,0.98) 100%)', borderRadius: 20, border: '1px solid rgba(0,240,255,0.2)', boxShadow: '0 0 40px rgba(0,240,255,0.08), 0 20px 60px rgba(0,0,0,0.5)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: '#ff4444' }}>添加应急事件</h3>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer' }}><X size={18} /></button>
        </div>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>事件类型</label>
            <div style={{ display: 'flex', gap: 4 }}>
              {typeOptions.map(t => (
                <button key={t} type="button" onClick={() => setType(t)} style={{ flex: 1, padding: '6px', borderRadius: 8, fontSize: 10, fontWeight: 600, border: `1px solid ${type === t ? EMG_COLORS[t] : 'transparent'}`, background: type === t ? `${EMG_COLORS[t]}22` : 'rgba(255,255,255,0.03)', color: type === t ? EMG_COLORS[t] : '#64748b', cursor: 'pointer' }}>{EMERGENCY_TYPE_LABELS[t]}</button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>事件等级</label>
            <div style={{ display: 'flex', gap: 4 }}>
              {levelOptions.map(l => (
                <button key={l} type="button" onClick={() => setLevel(l)} style={{ flex: 1, padding: '6px', borderRadius: 8, fontSize: 10, fontWeight: 600, border: `1px solid ${level === l ? EMG_LEVEL_COLORS[l] : 'transparent'}`, background: level === l ? `${EMG_LEVEL_COLORS[l]}22` : 'rgba(255,255,255,0.03)', color: level === l ? EMG_LEVEL_COLORS[l] : '#64748b', cursor: 'pointer' }}>{EMG_LEVEL_LABELS[l]}</button>
              ))}
            </div>
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>发生地点</label>
            <input value={location} onChange={e => setLocation(e.target.value)} style={{ width: '100%', padding: '8px 12px', background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
          </div>
          <div style={{ marginBottom: 12 }}>
            <label style={{ display: 'block', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>详细地址</label>
            <input value={address} onChange={e => setAddress(e.target.value)} placeholder="例如：中山路128号" style={{ width: '100%', padding: '8px 12px', background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, color: '#e2e8f0', fontSize: 12 }} />
          </div>
          <div style={{ marginBottom: 16 }}>
            <label style={{ display: 'block', fontSize: 12, color: '#94a3b8', marginBottom: 4 }}>事件描述</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} placeholder="描述事件详情..." style={{ width: '100%', padding: '8px 12px', background: 'rgba(0,0,0,0.2)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 8, color: '#e2e8f0', fontSize: 12, resize: 'none' }} />
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <button type="button" onClick={onClose} style={{ flex: 1, padding: '8px', borderRadius: 10, fontSize: 12, fontWeight: 600, border: '1px solid rgba(255,255,255,0.1)', background: 'rgba(0,0,0,0.15)', color: '#94a3b8', cursor: 'pointer' }}>取消</button>
            <button type="submit" style={{ flex: 1, padding: '8px', borderRadius: 10, fontSize: 12, fontWeight: 600, border: 'none', background: 'rgba(255,68,68,0.2)', color: '#ff4444', cursor: 'pointer' }}>添加事件</button>
          </div>
        </form>
      </div>
    </div>
  );
}
