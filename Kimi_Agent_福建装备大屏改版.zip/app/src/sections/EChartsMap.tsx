import { useEffect, useRef, useState, useCallback } from 'react';
import * as echarts from 'echarts';
import { BookOpen, X } from 'lucide-react';
import type { BusinessEvent, WarningItem, EmergencyEvent, EquipmentData, DistributionData } from '../hooks/useRealtimeData';
import { EMERGENCY_TYPE_LABELS } from '../hooks/useRealtimeData';

const EVT_COLORS: Record<string, string> = {
  purchase: '#00ff9d', inbound: '#00a8ff', daily_transfer: '#00f0ff', outbound: '#ffcc00',
};
const EMG_COLORS: Record<string, string> = {
  terrorist: '#ff4444', criminal: '#ff8800', mass: '#00f0ff',
  disaster: '#00ff9d', security: '#a78bfa', checkpoint: '#ffcc00',
};

interface EChartsMapProps {
  events: BusinessEvent[];
  warnings: WarningItem[];
  emergencyEvents: EmergencyEvent[];
  selectedEmergency?: EmergencyEvent | null;
  onSelectEmergency?: (evt: EmergencyEvent | null) => void;
  equipment: EquipmentData;
  distribution: DistributionData;
  drillDown?: 'province' | 'fuzhou';
  onDrillDown?: (v: 'province' | 'fuzhou') => void;
}

const CITY_COORDS: Record<string, [number, number]> = {
  '福州市': [119.306239, 26.075302],
  '厦门市': [118.089425, 24.479833],
  '莆田市': [119.007777, 25.454202],
  '三明市': [117.638678, 26.263406],
  '泉州市': [118.675676, 24.874475],
  '漳州市': [117.676033, 24.511156],
  '南平市': [118.181851, 26.643626],
  '龙岩市': [117.017536, 25.075123],
  '宁德市': [119.554174, 26.668784],
  '平潭综合实验区': [119.791612, 25.503571],
  '省本级': [118.8, 26.1],
};

const FUZHOU_DISTRICTS = [
  { name: '鼓楼区', value: 2850 }, { name: '台江区', value: 2340 }, { name: '仓山区', value: 3120 },
  { name: '晋安区', value: 1980 }, { name: '马尾区', value: 1560 }, { name: '长乐区', value: 1890 },
  { name: '福清市', value: 2670 }, { name: '闽侯县', value: 1240 }, { name: '连江县', value: 980 },
  { name: '罗源县', value: 720 }, { name: '闽清县', value: 850 }, { name: '永泰县', value: 650 },
  { name: '平潭县', value: 1150 },
];

const FUZHOU_COORDS: Record<string, [number, number]> = {
  '鼓楼区': [119.29929, 26.082284], '台江区': [119.310156, 26.058616], '仓山区': [119.320988, 26.038912],
  '晋安区': [119.328597, 26.078837], '马尾区': [119.458725, 25.991975], '长乐区': [119.510849, 25.960583],
  '闽侯县': [119.145117, 26.148567], '连江县': [119.538365, 26.202109], '罗源县': [119.552645, 26.487234],
  '闽清县': [118.868416, 26.223793], '永泰县': [118.939089, 25.864825], '平潭县': [119.791197, 25.503672],
  '福清市': [119.376992, 25.720402],
};

export default function EChartsMap({
  events, warnings, emergencyEvents,
  equipment: _equipment, distribution,
  drillDown: drillDownProp, onDrillDown,
}: EChartsMapProps) {
  // ====== 所有 state 必须在最顶部 ======
  const [showLegend, setShowLegend] = useState(false);
  const [geoLoaded, setGeoLoaded] = useState(false);
  const [drillDownInternal, setDrillDownInternal] = useState<'province' | 'fuzhou'>('province');
  const [fuzhouGeoLoaded, setFuzhouGeoLoaded] = useState(false);
  const [selectedDistrict, setSelectedDistrict] = useState<string | null>(null);
  const drillDown = drillDownProp ?? drillDownInternal;
  const setDrillDown = (v: 'province' | 'fuzhou') => { setDrillDownInternal(v); onDrillDown?.(v); };

  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<echarts.ECharts | null>(null);

  useEffect(() => {
    if (geoLoaded) return;
    let cancelled = false;
    fetch('./map/fujian.json')
      .then(r => r.json())
      .then(j => { if (!cancelled) { echarts.registerMap('fujian', j); setGeoLoaded(true); } })
      .catch(err => { if (!cancelled) console.error('Load fujian geoJSON error:', err); });
    return () => { cancelled = true; };
  }, [geoLoaded]);

  useEffect(() => {
    if (fuzhouGeoLoaded) return;
    let cancelled = false;
    fetch('./map/fuzhou.json')
      .then(r => r.json())
      .then(j => { if (!cancelled) { echarts.registerMap('fuzhou', j); setFuzhouGeoLoaded(true); } })
      .catch(err => { if (!cancelled) console.error('Load fuzhou geoJSON error:', err); });
    return () => { cancelled = true; };
  }, [fuzhouGeoLoaded]);

  useEffect(() => {
    if (!containerRef.current || chartRef.current) return;
    try {
      chartRef.current = echarts.init(containerRef.current, undefined, { renderer: 'canvas' });
    } catch (e) {
      console.error('ECharts init failed:', e);
      return;
    }
    const resize = () => { try { chartRef.current?.resize(); } catch (e) { /* ignore */ } };
    window.addEventListener('resize', resize);
    return () => {
      window.removeEventListener('resize', resize);
      try { chartRef.current?.dispose(); } catch (e) { /* ignore */ }
      chartRef.current = null;
    };
  }, []);

  const buildProvinceOption = useCallback((): echarts.EChartsOption => {
    const cityData = Object.entries(CITY_COORDS).map(([name, coord]) => {
      // 精确匹配 + 模糊匹配兜底
      let cityDist = distribution.cityDistribution.find(d => d.city === name);
      if (!cityDist) {
        const short = name.replace('市', '').replace('综合实验区', '');
        cityDist = distribution.cityDistribution.find(d => d.city.includes(short) || short.includes(d.city.replace('市', '').replace('综合实验区', '')));
      }
      // 兜底：基于名称hash生成确定性数值
      const hash = name.split('').reduce((s, c) => s + c.charCodeAt(0), 0);
      const fallbackTotal = cityDist ? cityDist.total : (8000 + (hash % 42000));
      const isStar = name === '省本级';
      const isFz = name === '福州市';
      const isWarn = warnings.some(w => {
        const cn = w.warehouse.replace(/仓库$/, '').replace(/储备库$/, '').replace(/应急仓$/, '');
        return name.includes(cn) || cn.includes(name.replace('市', '').replace('综合实验区', ''));
      });
      return {
        name, value: [...coord, fallbackTotal],
        itemStyle: {
          color: isStar ? '#ffcc00' : isFz ? '#ff4444' : isWarn ? '#ff4444' : '#00a8ff',
          borderColor: isStar ? '#ffcc00' : isFz ? '#ffcc00' : isWarn ? '#ff4444' : '#00f0ff',
          borderWidth: isStar ? 3 : isFz ? 3 : 2,
          shadowBlur: isStar ? 15 : isFz ? 20 : 10,
          shadowColor: isStar ? 'rgba(255,204,0,0.6)' : isFz ? 'rgba(255,204,0,0.8)' : isWarn ? 'rgba(255,68,68,0.5)' : 'rgba(0,240,255,0.5)',
        },
        label: {
          show: true,
          formatter: (p: any) => {
            const n = p?.name || name;
            const total = p?.value?.[2] ?? fallbackTotal;
            const tStr = typeof total === 'number' ? total.toLocaleString() : String(total);
            return isStar ? `★${tStr}\n${n}` : `${tStr}\n${n}`;
          },
          color: isStar ? '#ffcc00' : isFz ? '#ffcc00' : isWarn ? '#ffaaaa' : '#e8f4ff',
          fontSize: isStar ? 15 : isFz ? 14 : 13,
          fontWeight: isStar ? 800 : isFz ? 700 : 600,
          textBorderColor: '#000', textBorderWidth: 2, offset: [0, -15],
        },
        symbol: isStar ? 'star' : 'circle',
        symbolSize: isStar ? 24 : isFz ? 28 : name.length > 4 ? 14 : 12,
      };
    });

    const fuzhouPulseData = [{ name: '福州市', value: [CITY_COORDS['福州市'][0], CITY_COORDS['福州市'][1], 100] }];

    const transferEvents = events.filter(e => e.type === 'daily_transfer' || e.type === 'outbound');
    const flyLines: any[] = [];
    const cityNames = Object.keys(CITY_COORDS);
    transferEvents.slice(0, 12).forEach(evt => {
      const src = cityNames.find(c => evt.location.includes(c.replace('市', ''))) || '福州市';
      const tgt = cityNames[Math.floor(Math.random() * cityNames.length)];
      if (src !== tgt && CITY_COORDS[src] && CITY_COORDS[tgt]) {
        flyLines.push({ coords: [CITY_COORDS[src], CITY_COORDS[tgt]], lineStyle: { color: EVT_COLORS[evt.type] || '#00f0ff', width: 1.5, opacity: 0.6, curveness: 0.2 } });
      }
    });

    const emgData = emergencyEvents.map(evt => ({
      name: evt.location,
      value: [evt.lat || CITY_COORDS[evt.location]?.[0] || 119.3, evt.lng || CITY_COORDS[evt.location]?.[1] || 26.1],
      itemStyle: { color: EMG_COLORS[evt.type] || '#ff4444', borderColor: EMG_COLORS[evt.type] || '#ff4444', borderWidth: 1.5, shadowBlur: 10, shadowColor: EMG_COLORS[evt.type] || '#ff4444' },
      symbol: 'diamond',
      symbolSize: evt.level === 'critical' ? 14 : evt.level === 'severe' ? 10 : 8,
      label: { show: evt.status !== 'resolved', formatter: EMERGENCY_TYPE_LABELS[evt.type] || '', color: EMG_COLORS[evt.type] || '#ff4444', fontSize: 10, fontWeight: 700, textBorderColor: '#000', textBorderWidth: 2, offset: [12, 0] },
    }));

    const adjLines: any[] = [];
    const adjPairs = [['福州市','宁德市'],['福州市','莆田市'],['福州市','三明市'],['厦门市','漳州市'],['厦门市','泉州市'],['莆田市','泉州市'],['泉州市','漳州市'],['三明市','南平市'],['三明市','龙岩市'],['南平市','宁德市'],['龙岩市','漳州市'],['平潭综合实验区','福州市']];
    adjPairs.forEach(([a, b]) => { if (CITY_COORDS[a] && CITY_COORDS[b]) adjLines.push({ coords: [CITY_COORDS[a], CITY_COORDS[b]] }); });

    return {
      backgroundColor: 'transparent',
      geo: {
        map: 'fujian', roam: true, zoom: 1.15, center: [118.0, 26.0],
        itemStyle: { areaColor: 'rgba(0, 40, 80, 0.15)', borderColor: 'rgba(0, 240, 255, 0.25)', borderWidth: 1.5, shadowColor: 'rgba(0, 0, 0, 0.5)', shadowBlur: 10 },
        emphasis: { itemStyle: { areaColor: 'rgba(0, 60, 120, 0.25)', borderColor: '#00f0ff', borderWidth: 2 }, label: { show: false } },
        select: { itemStyle: { areaColor: 'rgba(0, 40, 80, 0.15)' }, label: { show: false } },
        label: { show: false },
      } as any,
      series: [
        { type: 'lines', coordinateSystem: 'geo', data: adjLines, lineStyle: { color: 'rgba(0, 240, 255, 0.1)', width: 0.8, type: 'dashed' }, silent: true, zlevel: 1 },
        { type: 'lines', coordinateSystem: 'geo', data: flyLines, effect: { show: true, period: 4, trailLength: 0.5, color: '#fff', symbol: 'arrow', symbolSize: 4 }, lineStyle: { width: 0, curveness: 0.2 }, zlevel: 2 },
        { type: 'effectScatter', coordinateSystem: 'geo', data: fuzhouPulseData, symbolSize: 45, showEffectOn: 'render', rippleEffect: { brushType: 'stroke', scale: 3, period: 2 }, itemStyle: { color: 'rgba(255,204,0,0.3)', borderColor: '#ffcc00', borderWidth: 1 }, zlevel: 2, silent: true },
        { type: 'scatter', coordinateSystem: 'geo', data: cityData, zlevel: 3 },
        { type: 'scatter', coordinateSystem: 'geo', data: emgData, zlevel: 4 },
      ],
      tooltip: { show: false },
    };
  }, [events, warnings, emergencyEvents, distribution]);

  const buildFuzhouOption = useCallback((): echarts.EChartsOption => {
    const maxVal = Math.max(...FUZHOU_DISTRICTS.map(d => d.value));
    const minVal = Math.min(...FUZHOU_DISTRICTS.map(d => d.value));
    const districtData = FUZHOU_DISTRICTS.map(d => {
      const ratio = (d.value - minVal) / (maxVal - minVal || 1);
      const blueInt = Math.round(30 + ratio * 50);
      return {
        name: d.name, value: d.value,
        itemStyle: { areaColor: `rgba(0, ${blueInt}, ${Math.round(60 + ratio * 80)}, ${0.2 + ratio * 0.2})` },
        label: { show: false },
        emphasis: { itemStyle: { areaColor: `rgba(0, ${blueInt + 30}, 160, 0.45)` }, label: { show: true, color: '#00f0ff', fontSize: 11, fontWeight: 700, textBorderColor: '#000', textBorderWidth: 2 } },
        select: { itemStyle: { areaColor: `rgba(0, ${blueInt}, ${Math.round(60 + ratio * 80)}, ${0.2 + ratio * 0.2})` } },
      };
    });
    const scatterData = FUZHOU_DISTRICTS.map(d => {
      const coord = FUZHOU_COORDS[d.name];
      if (!coord) return null;
      const ratio = d.value / maxVal;
      return {
        name: d.name, value: [...coord, d.value],
        symbolSize: Math.round(12 + ratio * 22),
        itemStyle: { color: `rgba(0, 168, 255, ${0.5 + ratio * 0.4})`, borderColor: '#00f0ff', borderWidth: 1.5, shadowBlur: 10, shadowColor: `rgba(0, 240, 255, ${0.3 + ratio * 0.4})` },
        label: { show: true, formatter: `{n|${d.name}}\n{v|${d.value.toLocaleString()}}`, rich: { n: { fontSize: 10, color: '#e2e8f0', fontWeight: 600, lineHeight: 14 }, v: { fontSize: 12, color: '#00f0ff', fontWeight: 800, fontFamily: 'Roboto Mono, monospace' } }, textBorderColor: '#000', textBorderWidth: 2, offset: [0, -18] },
      };
    }).filter(Boolean);
    return {
      backgroundColor: 'transparent',
      animationDurationUpdate: 800,
      animationEasingUpdate: 'cubicInOut',
      geo: {
        map: 'fuzhou', roam: true, zoom: 1.12, center: [119.32, 26.05],
        itemStyle: { areaColor: 'rgba(0, 25, 50, 0.12)', borderColor: 'rgba(0, 240, 255, 0.3)', borderWidth: 1.5, shadowColor: 'rgba(0, 0, 0, 0.4)', shadowBlur: 8 },
        emphasis: { itemStyle: { areaColor: 'rgba(0, 80, 160, 0.3)', borderColor: '#00f0ff', borderWidth: 2 }, label: { show: true, color: '#00f0ff', fontSize: 11, fontWeight: 700, textBorderColor: '#000', textBorderWidth: 2 } },
        select: { itemStyle: { areaColor: 'rgba(0, 25, 50, 0.12)' }, label: { show: false } },
        label: { show: false },
      },
      series: [
        { type: 'map', geoIndex: 0, map: 'fuzhou', data: districtData, emphasis: { itemStyle: { areaColor: 'rgba(0, 80, 160, 0.35)' }, label: { show: true, color: '#00f0ff' } }, select: { itemStyle: { areaColor: 'rgba(0, 50, 100, 0.2)' } }, animationDurationUpdate: 600 },
        { type: 'scatter', coordinateSystem: 'geo', data: scatterData, symbol: 'circle', zlevel: 3, animationDurationUpdate: 800 },
      ],
      tooltip: { show: false },
    };
  }, []);

  useEffect(() => {
    if (!chartRef.current || !geoLoaded) return;
    try {
      chartRef.current.clear();
      if (drillDown === 'fuzhou' && fuzhouGeoLoaded) {
        chartRef.current.setOption(buildFuzhouOption(), true);
      } else {
        chartRef.current.setOption(buildProvinceOption(), true);
      }
    } catch (e) { console.error('Chart update error:', e); }
  }, [geoLoaded, fuzhouGeoLoaded, drillDown, buildProvinceOption, buildFuzhouOption, events, warnings, emergencyEvents, distribution]);

  useEffect(() => {
    const chart = chartRef.current;
    if (!chart) return;
    const handler = (params: any) => {
      if (drillDown === 'province' && params?.name === '福州市') {
        setDrillDown('fuzhou');
      } else if (drillDown === 'province' && params?.name && CITY_COORDS[params.name]) {
        setSelectedDistrict(params.name);
      } else if (drillDown === 'fuzhou' && params?.name) {
        const dist = FUZHOU_DISTRICTS.find(d => d.name === params.name);
        if (dist) setSelectedDistrict(params.name);
      }
    };
    chart.on('click', handler);
    return () => { try { chart.off('click', handler); } catch (e) { /* ignore */ } };
  }, [drillDown]);

  useEffect(() => {
    if (drillDown === 'province') setSelectedDistrict(null);
  }, [drillDown]);

  // 暴露调试 API
  useEffect(() => {
    const api = {
      drillDown: (v: 'province' | 'fuzhou') => setDrillDown(v),
      getDrillDown: () => drillDown,
    };
    (window as any).__echartsMap = api;
    return () => { delete (window as any).__echartsMap; };
  }, [drillDown]);

  // ====== 滚轮缩放返回全省（监听 finished 事件） ======
  useEffect(() => {
    const chart = chartRef.current;
    if (!chart || drillDown !== 'fuzhou') return;
    const finishedHandler = () => {
      try {
        const opt = chart.getOption() as any;
        const zoom = opt?.geo?.[0]?.zoom ?? 1;
        if (zoom < 0.85) setDrillDown('province');
      } catch (e) { /* ignore */ }
    };
    chart.on('finished', finishedHandler);
    return () => { try { chart.off('finished', finishedHandler); } catch (e) { /* ignore */ } };
  }, [drillDown]);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      {drillDown === 'fuzhou' && (
        <div style={{ position: 'absolute', top: 12, left: '50%', transform: 'translateX(-50%)', zIndex: 25, padding: '6px 20px', background: 'rgba(5,10,20,0.8)', backdropFilter: 'blur(8px)', borderRadius: 20, border: '1px solid rgba(0,240,255,0.2)', color: '#00f0ff', fontSize: 13, fontWeight: 700, letterSpacing: 1, pointerEvents: 'none', display: 'flex', alignItems: 'center', gap: 12, whiteSpace: 'nowrap' }}>
          <span>福州市 · 区县装备分布</span>
          <span style={{ fontSize: 10, color: '#64748b', fontWeight: 400 }}>滚轮缩小返回全省</span>
        </div>
      )}
      {selectedDistrict && (
        <DistrictDetailPanel districtName={selectedDistrict} onClose={() => setSelectedDistrict(null)} />
      )}
      {drillDown === 'province' && <BusinessTicker events={events} />}
      <div ref={containerRef} style={{ position: 'absolute', inset: 0, zIndex: 10 }} />
      <button onClick={() => setShowLegend(!showLegend)} style={{ position: 'absolute', bottom: 10, right: 16, zIndex: 25, display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: 'rgba(5,10,20,0.8)', backdropFilter: 'blur(8px)', borderRadius: 20, border: '1px solid rgba(0,240,255,0.25)', color: '#00f0ff', fontSize: 11, fontWeight: 600, cursor: 'pointer', transition: 'all 0.25s ease' }}><BookOpen size={13} /> 图例</button>
      {showLegend && <LegendPanel onClose={() => setShowLegend(false)} />}
    </div>
  );
}

function DistrictDetailPanel({ districtName, onClose }: { districtName: string; onClose: () => void }) {
  const fuzhouDist = FUZHOU_DISTRICTS.find(d => d.name === districtName);
  // 地市：基于名称生成确定性数值
  const cityHash = districtName.split('').reduce((s, c) => s + c.charCodeAt(0), 0);
  const cityValue = fuzhouDist ? fuzhouDist.value : (8000 + (cityHash % 22000));
  const dist = { name: districtName, value: cityValue };
  const equipCategories = [
    { name: '指挥调度装备', count: Math.round(dist.value * 0.05), fail: '1.8%', mtbf: '4,500h' },
    { name: '信息通信装备', count: Math.round(dist.value * 0.15), fail: '4.2%', mtbf: '2,100h' },
    { name: '现场勘查装备', count: Math.round(dist.value * 0.09), fail: '2.5%', mtbf: '3,800h' },
    { name: '警用械具', count: Math.round(dist.value * 0.24), fail: '5.6%', mtbf: '1,500h' },
    { name: '民警防护装备', count: Math.round(dist.value * 0.18), fail: '1.5%', mtbf: '4,800h' },
    { name: '防护器材', count: Math.round(dist.value * 0.15), fail: '2.8%', mtbf: '3,200h' },
    { name: '其他装备', count: Math.round(dist.value * 0.14), fail: '2.1%', mtbf: '3,600h' },
  ];
  return (
    <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 50, width: 420, maxHeight: '80vh', overflow: 'auto', background: 'rgba(5,10,20,0.95)', backdropFilter: 'blur(16px)', borderRadius: 16, border: '1px solid rgba(0,240,255,0.3)', boxShadow: '0 8px 48px rgba(0,0,0,0.6)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px', borderBottom: '1px solid rgba(0,240,255,0.15)' }}>
        <div><div style={{ fontSize: 16, fontWeight: 800, color: '#00f0ff' }}>{dist.name}</div><div style={{ fontSize: 11, color: '#64748b', marginTop: 2 }}>装备物资详情</div></div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: 4 }}><X size={18} /></button>
      </div>
      <div style={{ display: 'flex', padding: '14px 18px', gap: 12, borderBottom: '1px solid rgba(0,240,255,0.1)' }}>
        {[{ label: '装备总数', value: dist.value.toLocaleString(), color: '#00f0ff', bg: 'rgba(0,240,255,0.05)' }, { label: '一般装备', value: Math.round(dist.value * 0.62).toLocaleString(), color: '#00ff9d', bg: 'rgba(0,255,157,0.05)' }, { label: '应急装备', value: Math.round(dist.value * 0.38).toLocaleString(), color: '#ffcc00', bg: 'rgba(255,204,0,0.05)' }].map(item => (
          <div key={item.label} style={{ flex: 1, textAlign: 'center', padding: '10px 0', background: item.bg, borderRadius: 10 }}>
            <div style={{ fontSize: 22, fontWeight: 900, color: item.color, fontFamily: 'Roboto Mono, monospace' }}>{item.value}</div>
            <div style={{ fontSize: 10, color: '#64748b', marginTop: 4 }}>{item.label}</div>
          </div>
        ))}
      </div>
      <div style={{ padding: '12px 18px' }}>
        <div style={{ fontSize: 12, fontWeight: 700, color: '#94a3b8', marginBottom: 10 }}>装备分类明细</div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
          <thead><tr style={{ background: 'rgba(0,240,255,0.05)' }}>{['品类', '数量', '故障率', '平均无故障工作时间'].map(h => <th key={h} style={{ padding: '5px 8px', color: '#00f0ff', fontWeight: 700, textAlign: h === '品类' ? 'left' : 'center' }}>{h}</th>)}</tr></thead>
          <tbody>{equipCategories.map((cat, idx) => (
            <tr key={cat.name} style={{ background: idx % 2 === 0 ? 'rgba(0,240,255,0.015)' : 'transparent' }}>
              <td style={{ padding: '4px 8px', color: '#e2e8f0', fontWeight: 600 }}>{cat.name}</td>
              <td style={{ padding: '4px 8px', color: '#00f0ff', textAlign: 'center', fontWeight: 700, fontFamily: 'Roboto Mono, monospace' }}>{cat.count}</td>
              <td style={{ padding: '4px 8px', color: parseFloat(cat.fail) > 3 ? '#ff4444' : '#00ff9d', textAlign: 'center', fontWeight: 700 }}>{cat.fail}</td>
              <td style={{ padding: '4px 8px', color: '#94a3b8', textAlign: 'center', fontFamily: 'Roboto Mono, monospace' }}>{cat.mtbf}</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div style={{ display: 'flex', padding: '12px 18px 16px', gap: 10, borderTop: '1px solid rgba(0,240,255,0.1)' }}>
        {[{ label: '过期装备', value: Math.round(dist.value * 0.027), color: '#ff4444' }, { label: '临废装备', value: Math.round(dist.value * 0.054), color: '#ffcc00' }, { label: '维修装备', value: '1.1%', color: '#ff8800' }].map(item => (
          <div key={item.label} style={{ flex: 1, textAlign: 'center', padding: '8px 0' }}>
            <div style={{ fontSize: 14, fontWeight: 800, color: item.color, fontFamily: 'Roboto Mono, monospace' }}>{typeof item.value === 'number' ? item.value : item.value}</div>
            <div style={{ fontSize: 10, color: '#64748b', marginTop: 2 }}>{item.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

function LegendPanel({ onClose }: { onClose: () => void }) {
  return (
    <div style={{ position: 'absolute', bottom: 52, right: 16, zIndex: 30, width: 200, padding: 14, background: 'rgba(3,8,18,0.95)', backdropFilter: 'blur(12px)', borderRadius: 14, border: '1px solid rgba(0,240,255,0.2)', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}>
      <button onClick={onClose} style={{ position: 'absolute', top: 8, right: 8, background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: 4 }}><X size={14} /></button>
      <div style={{ marginBottom: 12 }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>业务动态</div>
        {[{ c: '#00ff9d', l: '装备采购' }, { c: '#00a8ff', l: '装备入库' }, { c: '#00f0ff', l: '日常调拨' }, { c: '#ffcc00', l: '应急调拨' }].map(item => (
          <div key={item.l} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: item.c, boxShadow: `0 0 6px ${item.c}`, flexShrink: 0 }} />
            <span style={{ fontSize: 11, color: '#e2e8f0' }}>{item.l}</span>
          </div>
        ))}
      </div>
      <div style={{ marginBottom: 12, paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>城市节点</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#00a8ff', border: '1.5px solid #00f0ff', flexShrink: 0 }} />
          <span style={{ fontSize: 11, color: '#e2e8f0' }}>地市节点</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
          <svg width="12" height="12" style={{ flexShrink: 0 }}><polygon points="6,1 7.5,4.5 11,4.8 8.2,7.2 9,10.5 6,8.8 3,10.5 3.8,7.2 1,4.8 4.5,4.5" fill="#ffcc00" stroke="#ffcc00" strokeWidth="0.5" /></svg>
          <span style={{ fontSize: 11, color: '#e2e8f0' }}>省本级</span>
        </div>
      </div>
      <div style={{ paddingTop: 8, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ fontSize: 11, fontWeight: 600, color: '#94a3b8', marginBottom: 8 }}>应急事件</div>
        {[{ c: '#ff4444', l: '暴力恐怖袭击' }, { c: '#00f0ff', l: '群体性事件' }, { c: '#00ff9d', l: '自然灾害救援' }, { c: '#a78bfa', l: '大型活动安保' }].map(item => (
          <div key={item.l} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0' }}>
            <div style={{ width: 8, height: 8, background: item.c, transform: 'rotate(45deg)', boxShadow: `0 0 4px ${item.c}`, flexShrink: 0 }} />
            <span style={{ fontSize: 11, color: '#e2e8f0' }}>{item.l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BusinessTicker({ events }: { events: BusinessEvent[] }) {
  const items = events.filter(e => e.type === 'purchase' || e.type === 'inbound' || e.type === 'daily_transfer' || e.type === 'outbound').slice(0, 10);
  const tripled = [...items, ...items, ...items];
  return (
    <div style={{ position: 'absolute', bottom: 10, left: 14, right: 14, zIndex: 15, height: 32, background: 'rgba(3,6,14,0.85)', backdropFilter: 'blur(8px)', borderRadius: 16, border: '1px solid rgba(0,240,255,0.15)', overflow: 'hidden', display: 'flex', alignItems: 'center' }}>
      <div style={{ padding: '0 10px', fontSize: 10, fontWeight: 700, color: '#00f0ff', borderRight: '1px solid rgba(0,240,255,0.2)', whiteSpace: 'nowrap', flexShrink: 0, letterSpacing: 1 }}>业务动态</div>
      <div style={{ flex: 1, overflow: 'hidden' }}>
        <div style={{ display: 'flex', alignItems: 'center', whiteSpace: 'nowrap', gap: 32, padding: '0 14px', animation: 'bizTicker 60s linear infinite' }}>
          {tripled.map((e, i) => (
            <div key={`${e.id}-${i}`} style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: EVT_COLORS[e.type] || '#00f0ff', boxShadow: `0 0 4px ${EVT_COLORS[e.type] || '#00f0ff'}` }} />
              <span style={{ fontSize: 10, color: '#64748b', fontFamily: 'Roboto Mono, monospace' }}>[{e.time}]</span>
              <span style={{ fontSize: 10, fontWeight: 600, color: EVT_COLORS[e.type] || '#00f0ff' }}>{e.type === 'purchase' ? '采购' : e.type === 'inbound' ? '入库' : e.type === 'outbound' ? '出库' : '调拨'}</span>
              <span style={{ fontSize: 10, color: '#e2e8f0' }}>{e.location}</span>
              <span style={{ fontSize: 10, color: '#94a3b8' }}>{(e.quantity ?? 0).toLocaleString()}件</span>
            </div>
          ))}
        </div>
      </div>
      <style>{`@keyframes bizTicker{from{transform:translateX(0)}to{transform:translateX(-33.33%)}}`}</style>
    </div>
  );
}
