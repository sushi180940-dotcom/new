import { useState } from 'react';
import { Siren, Crosshair, Package, Route, ChevronDown, ChevronUp, Circle, CheckCircle2, Loader2, Truck, Zap } from 'lucide-react';
import type {
  EmergencyEvent, EmergencyAnalysis, EquipmentDistribution,
  TransferScheme,
} from '../hooks/useRealtimeData';
import { EMERGENCY_TYPE_LABELS } from '../hooks/useRealtimeData';

interface Props {
  events: EmergencyEvent[];
  analyses: Record<string, EmergencyAnalysis>;
  distributions: Record<string, EquipmentDistribution>;
  transfers: Record<string, TransferScheme[]>;
  onSelectEvent: (event: EmergencyEvent | null) => void;
}

const TYPE_COLORS: Record<string, string> = {
  fire: '#ff4444', flood: '#4488ff', earthquake: '#ff8800',
  accident: '#ffcc00', chemical: '#cc44ff', collapse: '#888888',
};
const TYPE_BG: Record<string, string> = {
  fire: 'rgba(255,68,68,0.1)', flood: 'rgba(68,136,255,0.1)', earthquake: 'rgba(255,136,0,0.1)',
  accident: 'rgba(255,204,0,0.1)', chemical: 'rgba(204,68,255,0.1)', collapse: 'rgba(136,136,136,0.1)',
};
const LEVEL_LABELS = { general: '一般', severe: '严重', critical: '危急' };
const LEVEL_COLORS = { general: '#ffcc00', severe: '#ff8800', critical: '#ff4444' };
const STATUS_LABELS: Record<string, string> = {
  reported: '已接报', analyzing: '分析中', dispatched: '已调拨', coordinating: '联动中', resolved: '已处置',
};
const STATUS_ICONS: Record<string, typeof Circle> = {
  reported: Siren, analyzing: Loader2, dispatched: Truck, coordinating: Zap, resolved: CheckCircle2,
};

export default function EmergencyPanel({
  events, analyses, distributions, transfers,
  onSelectEvent,
}: Props) {
  const [expandedEvt, setExpandedEvt] = useState<string | null>(null);

  const toggleExpand = (id: string) => {
    const next = expandedEvt === id ? null : id;
    setExpandedEvt(next);
    if (next) {
      const evt = events.find(e => e.id === id);
      onSelectEvent(evt || null);
    }
  };

  return (
    <div className="glass-panel" style={{ padding: 14, flexShrink: 0, height: 260, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
      <div className="module-title" style={{ marginBottom: 6, paddingBottom: 6, fontSize: 14, display: 'flex', alignItems: 'center', gap: 6 }}>
        <Siren size={15} style={{ color: '#ff4444' }} />应急事件
        <span style={{ marginLeft: 'auto', fontSize: 10, color: '#64748b', fontWeight: 400, fontFamily: 'Roboto Mono, monospace' }}>{events.length} 个活跃</span>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, overflow: 'hidden' }}>
        {events.map(evt => {
          const analysis = analyses[evt.id];
          const StatusIcon = STATUS_ICONS[evt.status] || Circle;
          const isExpanded = expandedEvt === evt.id;
          return (
            <div key={evt.id} style={{ borderRadius: 6, overflow: 'hidden' }}>
              {/* 事件标题行 */}
              <div
                onClick={() => toggleExpand(evt.id)}
                style={{
                  display: 'flex', alignItems: 'center', gap: 6, padding: '5px 8px',
                  background: TYPE_BG[evt.type] || 'rgba(0,0,0,0.1)',
                  border: `1px solid ${TYPE_COLORS[evt.type]}22`,
                  borderRadius: 6, cursor: 'pointer', transition: 'all 0.2s',
                }}
              >
                {/* 类型色块 */}
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: TYPE_COLORS[evt.type], boxShadow: `0 0 6px ${TYPE_COLORS[evt.type]}`, flexShrink: 0 }} />
                {/* 等级 */}
                <span style={{ fontSize: 9, fontWeight: 700, padding: '1px 5px', borderRadius: 4, background: `${LEVEL_COLORS[evt.level]}22`, color: LEVEL_COLORS[evt.level], border: `1px solid ${LEVEL_COLORS[evt.level]}44`, whiteSpace: 'nowrap' }}>
                  {LEVEL_LABELS[evt.level]}
                </span>
                {/* 类型 */}
                <span style={{ fontSize: 11, fontWeight: 600, color: TYPE_COLORS[evt.type], flexShrink: 0 }}>
                  {EMERGENCY_TYPE_LABELS[evt.type]}
                </span>
                {/* 地点 */}
                <span style={{ fontSize: 10, color: '#94a3b8', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', flex: 1 }}>
                  {evt.location}
                </span>
                {/* 状态 */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 3, flexShrink: 0 }}>
                  <StatusIcon size={10} style={{ color: '#94a3b8' }} />
                  <span style={{ fontSize: 9, color: '#94a3b8' }}>{STATUS_LABELS[evt.status]}</span>
                </div>
                {/* 展开箭头 */}
                {isExpanded ? <ChevronUp size={12} style={{ color: '#64748b', flexShrink: 0 }} /> : <ChevronDown size={12} style={{ color: '#64748b', flexShrink: 0 }} />}
              </div>

              {/* 展开详情 */}
              {isExpanded && analysis && (
                <div style={{ padding: '6px 8px', background: 'rgba(16,30,55,0.5)', borderLeft: `2px solid ${TYPE_COLORS[evt.type]}`, marginLeft: 4 }}>
                  {/* 地址 + 时间 */}
                  <div style={{ fontSize: 10, color: '#64748b', marginBottom: 4 }}>{evt.address} · {evt.time}</div>
                  <div style={{ fontSize: 10, color: '#94a3b8', marginBottom: 6 }}>{evt.description}</div>

                  {/* 8.2.2 装备推荐 */}
                  <DetailSection icon={<Crosshair size={10} />} title="装备推荐" color="#00f0ff">
                    {analysis.recommendations.map((rec, i) => (
                      <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '2px 0' }}>
                        <span style={{ fontSize: 10, color: '#e2e8f0', fontWeight: 500 }}>{rec.name}</span>
                        <span style={{ fontSize: 9, color: '#64748b' }}>{rec.spec}</span>
                        <span style={{ fontSize: 10, color: '#00f0ff', fontFamily: 'Roboto Mono, monospace', marginLeft: 'auto' }}>×{rec.quantity}</span>
                      </div>
                    ))}
                  </DetailSection>

                  {/* 8.2.3 周边分布 */}
                  {distributions[evt.id] && (
                    <DetailSection icon={<Package size={10} />} title="周边装备分布" color="#ffcc00">
                      <div style={{ display: 'flex', gap: 6, marginBottom: 4 }}>
                        <span style={{ fontSize: 9, color: '#64748b' }}>半径: {distributions[evt.id].radius}km</span>
                        <span style={{ fontSize: 9, color: distributions[evt.id].isSufficient ? '#00ff9d' : '#ff4444', fontWeight: 600 }}>
                          满足度: {distributions[evt.id].overallFulfillment}%
                        </span>
                      </div>
                      {distributions[evt.id].warehouses.slice(0, 3).map((w, i) => (
                        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '1px 0' }}>
                          <span style={{ fontSize: 9, color: '#94a3b8' }}>{w.warehouseName}</span>
                          <span style={{ fontSize: 9, color: '#64748b' }}>{w.distance}km</span>
                          <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden' }}>
                            <div style={{ width: `${w.fulfillmentRate}%`, height: '100%', background: w.fulfillmentRate >= 80 ? '#00ff9d' : w.fulfillmentRate >= 50 ? '#ffcc00' : '#ff4444', borderRadius: 2 }} />
                          </div>
                          <span style={{ fontSize: 9, color: w.fulfillmentRate >= 80 ? '#00ff9d' : '#ffcc00', fontFamily: 'Roboto Mono, monospace' }}>{w.fulfillmentRate}%</span>
                        </div>
                      ))}
                    </DetailSection>
                  )}

                  {/* 8.2.4 调拨方案 */}
                  {transfers[evt.id] && transfers[evt.id].length > 0 && (
                    <DetailSection icon={<Route size={10} />} title="调拨方案" color="#00ff9d">
                      {transfers[evt.id].map((scheme, si) => (
                        <div key={si} style={{ marginBottom: 4 }}>
                          <div style={{ fontSize: 9, fontWeight: 700, color: si === 0 ? '#00ff9d' : si === 1 ? '#00f0ff' : '#ff8c42', marginBottom: 2 }}>
                            {scheme.name} · {scheme.strategy}
                          </div>
                          {scheme.plans.slice(0, 3).map((plan, i) => (
                            <div key={i} style={{ padding: '1px 0', fontSize: 9 }}>
                              <span style={{ color: '#00ff9d' }}>{plan.sourceWarehouse}</span>
                              <span style={{ color: '#64748b' }}> → {plan.estimatedArrival}到达</span>
                            </div>
                          ))}
                        </div>
                      ))}
                    </DetailSection>
                  )}

                  {/* 联动仓库和最佳策略已移除 */}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

function DetailSection({ icon, title, color, children }: { icon: React.ReactNode; title: string; color: string; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 6 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginBottom: 3, paddingBottom: 2, borderBottom: `1px solid ${color}22` }}>
        <span style={{ color }}>{icon}</span>
        <span style={{ fontSize: 10, fontWeight: 600, color }}>{title}</span>
      </div>
      {children}
    </div>
  );
}
