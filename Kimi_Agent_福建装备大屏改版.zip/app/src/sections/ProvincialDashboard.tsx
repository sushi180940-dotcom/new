import { useState } from 'react';
import LeftPanel from './LeftPanel';
import RightPanel from './RightPanel';
import CenterMap from './CenterMap';
import { useRealtimeData } from '../hooks/useRealtimeData';
import type { EnvDevice } from '../hooks/useRealtimeData';

export default function ProvincialDashboard() {
  const {
    equipment, analysis, distribution, events, warnings, ranks, usage,
    expiredByUnit, expiredByEquip, generateDistrictRanks,
    emergencyEvents, envDevices,
  } = useRealtimeData();

  const [drillDown, setDrillDown] = useState<'province' | 'fuzhou'>('province');

  return (
    <div style={{ width: '100vw', height: '100vh', overflow: 'hidden', position: 'relative' }}>
      <LeftPanel equipment={equipment} distribution={distribution} />

      {/* 中央区域 */}
      <div style={{ position: 'fixed', top: 68, left: '22%', right: '22%', bottom: 0, zIndex: 5 }}>
        {/* 全省装备总数量 — 与左右各11%间距 */}
        {drillDown === 'province' && (
          <div style={{
            position: 'absolute', top: 12, left: '26.4%', right: '44%',
            zIndex: 25, padding: '10px 64px',
            display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6,
            whiteSpace: 'nowrap', pointerEvents: 'none',
          }}>
            <div style={{ fontSize: 20, fontWeight: 900, color: '#e2e8f0', letterSpacing: 4 }}>全省装备总数量</div>
            <div style={{ fontSize: 66, fontWeight: 2200, color: '#00f0ff', fontFamily: 'Roboto Mono, monospace', letterSpacing: 11, lineHeight: 1.1, textShadow: '0 0 20px rgba(0,240,255,0.3)' }}>
              00,156,844
            </div>
            <div style={{ display: 'flex', gap: 24, marginTop: 2 }}>
              <div>
                <div style={{ fontSize: 30, fontWeight: 1000, color: '#00ff9d', fontFamily: 'Roboto Mono, monospace' }}>128,544</div>
                <div style={{ fontSize: 10, color: '#00ff9d', marginTop: 2 }}>在库（81.96%）</div>
              </div>
              <div>
                <div style={{ fontSize: 30, fontWeight: 1000, color: '#ffcc00', fontFamily: 'Roboto Mono, monospace' }}>28,341</div>
                <div style={{ fontSize: 10, color: '#ffcc00', marginTop: 2 }}>出库（18.76%）</div>
              </div>
              <div>
                <div style={{ fontSize: 30, fontWeight: 1000, color: '#ff4444', fontFamily: 'Roboto Mono, monospace' }}>95,691</div>
                <div style={{ fontSize: 10, color: '#ff4444', marginTop: 2 }}>应急装备（70.35%）</div>
              </div>
            </div>
          </div>
        )}

        <CenterMap
          events={events}
          warnings={warnings}
          emergencyEvents={emergencyEvents}
          equipment={equipment}
          distribution={distribution}
          drillDown={drillDown}
          onDrillDown={setDrillDown}
        />

        {/* 环境设备监控状态条 */}
        {drillDown === 'province' && (
          <EnvDeviceBar devices={envDevices} />
        )}
      </div>

      <RightPanel
        ranks={ranks}
        analysis={analysis}
        usage={usage}
        expiredByUnit={expiredByUnit}
        expiredByEquip={expiredByEquip}
        generateDistrictRanks={generateDistrictRanks}
      />
    </div>
  );
}

// ===== 省厅仓库A 环境设备监控 =====
const ENV_DEVICE_DETAILS: { name: string; icon: string; getValue: () => string; color: string }[] = [
  { name: '温湿度仪器', icon: '🌡️', color: '#00f0ff', getValue: () => `${(20 + Math.random() * 8).toFixed(1)}℃ / 湿度${(50 + Math.random() * 25).toFixed(0)}%` },
  { name: '除湿机', icon: '❄️', color: '#00a8ff', getValue: () => `运行中 / 功率${(60 + Math.random() * 35).toFixed(0)}%` },
  { name: '精密空调', icon: '🌀', color: '#a78bfa', getValue: () => `${(18 + Math.random() * 6).toFixed(1)}℃ / ${['制冷', '除湿', '送风'][Math.floor(Math.random() * 3)]}` },
  { name: '水浸报警器', icon: '💧', color: '#00ff9d', getValue: () => Math.random() > 0.8 ? '⚠️ 低水位告警' : '正常 / 未触发' },
];

function EnvDeviceBar({ devices }: { devices: EnvDevice[] }) {
  return (
    <div style={{
      position: 'absolute', bottom: 52, left: 14, right: 14, zIndex: 20,
      background: 'rgba(5,10,20,0.85)', backdropFilter: 'blur(12px)',
      borderRadius: 12, border: '1px solid rgba(0,240,255,0.12)',
      padding: '10px 16px',
    }}>
      {/* 仓库标题 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <div style={{ fontSize: 11, fontWeight: 800, color: '#00f0ff', letterSpacing: 1 }}>🏭 省厅仓库A · 环境设备监控</div>
        <div style={{ flex: 1, height: 1, background: 'rgba(0,240,255,0.1)' }} />
      </div>
      {/* 4设备横向排列 */}
      <div style={{ display: 'flex', gap: 8 }}>
        {ENV_DEVICE_DETAILS.map((d, i) => {
          const dev = devices[i];
          const isWarn = d.name === '水浸报警器' && dev?.status === 'warning';
          const statusColor = isWarn ? '#ffcc00' : '#00ff9d';
          return (
            <div key={d.name} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '8px 6px', background: 'rgba(255,255,255,0.02)', borderRadius: 8, border: `1px solid ${statusColor}11` }}>
              <div style={{ fontSize: 16 }}>{d.icon}</div>
              <div style={{ fontSize: 10, fontWeight: 700, color: '#94a3b8' }}>{d.name}</div>
              <div style={{ fontSize: 12, fontWeight: 800, color: '#e2e8f0', fontFamily: 'Roboto Mono, monospace', textAlign: 'center', lineHeight: 1.4 }}>{d.getValue()}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 2 }}>
                <div style={{ width: 6, height: 6, borderRadius: '50%', background: statusColor, boxShadow: `0 0 4px ${statusColor}` }} />
                <span style={{ fontSize: 9, color: statusColor, fontWeight: 700 }}>{isWarn ? '告警' : '正常'}</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
