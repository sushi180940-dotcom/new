import { useState, useEffect } from 'react';
import { Activity, Users, LogIn, LayoutDashboard, Siren } from 'lucide-react';

interface TopNavProps {
  activeView: 'provincial' | 'emergency';
  onSwitchView: (view: 'provincial' | 'emergency') => void;
}

export default function TopNav({ activeView, onSwitchView }: TopNavProps) {
  const [time, setTime] = useState(new Date());
  const [loginCount, setLoginCount] = useState(156);
  const [loginTimes, setLoginTimes] = useState(3842);

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
      setLoginCount(prev => prev + Math.floor(Math.random() * 3));
      setLoginTimes(prev => prev + Math.floor(Math.random() * 5) + 1);
    }, 3000);
    return () => clearInterval(timer);
  }, []);

  const timeStr = time.toLocaleTimeString('zh-CN', { hour12: false });
  const dateStr = time.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    weekday: 'long',
  });

  const viewTitle = activeView === 'provincial' ? '全省管理一张图' : '应急指挥一张图';

  return (
    <header
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        right: 0,
        height: 68,
        zIndex: 100,
        background: 'linear-gradient(180deg, rgba(5,10,20,0.95) 0%, rgba(5,10,20,0.85) 70%, transparent 100%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 24px',
      }}
    >
      {/* 左侧：系统标题 + 切换按钮 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <Activity size={28} style={{ color: '#00f0ff', filter: 'drop-shadow(0 0 6px rgba(0,240,255,0.5))' }} />
          <h1 style={{ fontSize: 24, fontWeight: 700, color: '#ffffff', letterSpacing: 2, textShadow: '0 0 12px rgba(0,240,255,0.3)' }}>
            装备物资系统
          </h1>
        </div>

        <div style={{ width: 1, height: 28, background: 'rgba(0,240,255,0.3)', marginLeft: 8 }} />

        {/* 当前视图标题 */}
        <span style={{ fontSize: 14, color: '#00f0ff', fontWeight: 500, letterSpacing: 1 }}>
          {viewTitle}
        </span>

        <div style={{ width: 1, height: 20, background: 'rgba(0,240,255,0.15)', margin: '0 4px' }} />

        {/* 视图切换按钮 */}
        <div style={{ display: 'flex', gap: 2, padding: 2, background: 'rgba(0,240,255,0.05)', borderRadius: 12, border: '1px solid rgba(0,240,255,0.12)' }}>
          <button
            onClick={() => onSwitchView('provincial')}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '4px 12px', borderRadius: 10, fontSize: 12, fontWeight: 600,
              border: 'none', cursor: 'pointer', transition: 'all 0.25s ease',
              background: activeView === 'provincial' ? 'rgba(0,240,255,0.2)' : 'transparent',
              color: activeView === 'provincial' ? '#00f0ff' : '#64748b',
              boxShadow: activeView === 'provincial' ? '0 0 10px rgba(0,240,255,0.15)' : 'none',
            }}
          >
            <LayoutDashboard size={13} />
            全省管理
          </button>
          <button
            onClick={() => onSwitchView('emergency')}
            style={{
              display: 'flex', alignItems: 'center', gap: 5,
              padding: '4px 12px', borderRadius: 10, fontSize: 12, fontWeight: 600,
              border: 'none', cursor: 'pointer', transition: 'all 0.25s ease',
              background: activeView === 'emergency' ? 'rgba(255,68,68,0.25)' : 'transparent',
              color: activeView === 'emergency' ? '#ff4444' : '#64748b',
              boxShadow: activeView === 'emergency' ? '0 0 10px rgba(255,68,68,0.15)' : 'none',
            }}
          >
            <Siren size={13} />
            应急指挥
          </button>
        </div>
      </div>

      {/* 右侧 */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
        {/* 登录人数 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 16px', background: 'rgba(0,240,255,0.08)', borderRadius: 20, border: '1px solid rgba(0,240,255,0.2)' }}>
          <Users size={15} style={{ color: '#00f0ff' }} />
          <span style={{ fontSize: 12, color: '#94a3b8' }}>登录人数</span>
          <span className="stat-number" style={{ fontSize: 15, fontWeight: 700, color: '#00f0ff' }}>{loginCount.toLocaleString()}</span>
        </div>
        {/* 登录次数 */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 16px', background: 'rgba(0,255,157,0.08)', borderRadius: 20, border: '1px solid rgba(0,255,157,0.2)' }}>
          <LogIn size={15} style={{ color: '#00ff9d' }} />
          <span style={{ fontSize: 12, color: '#94a3b8' }}>登录次数</span>
          <span className="stat-number" style={{ fontSize: 15, fontWeight: 700, color: '#00ff9d' }}>{loginTimes.toLocaleString()}</span>
        </div>

        <div style={{ width: 1, height: 24, background: 'rgba(255,255,255,0.1)' }} />

        {/* 时间 */}
        <div style={{ textAlign: 'right' }}>
          <div className="stat-number" style={{ fontSize: 22, fontWeight: 700, color: '#ffffff', letterSpacing: 2 }}>
            {timeStr}
          </div>
          <div style={{ fontSize: 12, color: '#94a3b8', marginTop: 2 }}>{dateStr}</div>
        </div>
      </div>
    </header>
  );
}
