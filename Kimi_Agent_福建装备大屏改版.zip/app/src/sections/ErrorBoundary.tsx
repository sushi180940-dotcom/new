import { Component, type ReactNode } from 'react';

interface Props { children: ReactNode; fallback?: ReactNode; }
interface State { hasError: boolean; error?: Error; }

export default class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) { super(props); this.state = { hasError: false }; }
  static getDerivedStateFromError(error: Error): State { return { hasError: true, error }; }
  componentDidCatch(error: Error, info: React.ErrorInfo) { console.error('ErrorBoundary caught:', error, info); }
  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div style={{ width: '100vw', height: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#03060e', flexDirection: 'column', gap: 16 }}>
          <div style={{ fontSize: 16, fontWeight: 700, color: '#ff4444' }}>组件加载出错</div>
          <div style={{ fontSize: 12, color: '#64748b', maxWidth: 400, textAlign: 'center' }}>{this.state.error?.message}</div>
          <button onClick={() => this.setState({ hasError: false })} style={{ padding: '8px 20px', background: 'rgba(0,240,255,0.1)', border: '1px solid rgba(0,240,255,0.3)', borderRadius: 8, color: '#00f0ff', cursor: 'pointer' }}>重试</button>
        </div>
      );
    }
    return this.props.children;
  }
}
