// ==================== 人员全景图表 ====================
window.personnelCharts = {};
window.personnelChartsInited = false;

function initPersonnelCharts() {
    var el;

    // 编制使用率饼图
    el = document.getElementById('chart-bianzhi');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.bianzhi = echarts.init(el, 'dark');
        personnelCharts.bianzhi.setOption({
            backgroundColor:'transparent',
            tooltip: { trigger:'item', formatter:'{b}: {c}人 ({d}%)' },
            series: [{
                type:'pie', radius:['55%','72%'], center:['50%','50%'], avoidLabelOverlap:false,
                itemStyle: { borderRadius:8, borderColor:'#0a0e1a', borderWidth:3 },
                label: { show:false },
                emphasis: {
                    label: { show:true, fontSize:14, fontWeight:'bold', color:'#fff', formatter:'{b}\n{d}%' }
                },
                data: [
                    { value:8426, name:'已用编制', itemStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'#00d4ff'},{offset:1,color:'#0ea5e9'}]}} },
                    { value:464, name:'空编', itemStyle:{color:'rgba(100,116,139,0.25)'} }
                ]
            }],
            graphic: [
                { type:'text', left:'center', top:'40%', style:{text:'94.8%',fill:'#00d4ff',fontSize:24,fontWeight:'bold',fontFamily:'Orbitron'} },
                { type:'text', left:'center', top:'58%', style:{text:'编制使用率',fill:'#64748b',fontSize:11} }
            ]
        });
    }

    // 职级分布金字塔（蝴蝶图）
    el = document.getElementById('chart-zhiji');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.zhiji = echarts.init(el, 'dark');
        personnelCharts.zhiji.setOption({
            backgroundColor:'transparent',
            tooltip: {
                trigger:'axis', axisPointer:{type:'shadow'},
                formatter: function(params) {
                    var r = '<div style="font-weight:600;margin-bottom:6px;">' + params[0].axisValue + '</div>';
                    params.forEach(function(p) {
                        r += '<div style="display:flex;align-items:center;gap:6px;margin:3px 0;">' +
                            '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:' + p.color + ';"></span>' +
                            '<span style="flex:1;">' + p.seriesName + ':</span>' +
                            '<span style="font-weight:600;">' + Math.abs(p.value) + '人</span></div>';
                    });
                    return r;
                }
            },
            grid: { left:'18%', right:'18%', top:'10%', bottom:'10%' },
            xAxis: { type:'value', min:-400, max:400, axisLine:{show:false}, axisTick:{show:false},
                splitLine:{lineStyle:{color:'rgba(0,212,255,0.06)'}}, axisLabel:{formatter:function(v){return Math.abs(v);},color:'#64748b',fontSize:10} },
            yAxis: { type:'category', data:['科员及以下','科级','处级','厅级'], axisLine:{show:false}, axisTick:{show:false}, axisLabel:{color:'#94a3b8',fontSize:11} },
            series: [
                { name:'男性', type:'bar', stack:'total', data:[-3200,-1800,-420,-28],
                    itemStyle:{color:{type:'linear',x:0,y:0,x2:1,y2:0,colorStops:[{offset:0,color:'#0ea5e9'},{offset:1,color:'#00d4ff'}]}}, barWidth:24,
                    label:{show:true,position:'left',formatter:function(p){return Math.abs(p.value);},color:'#94a3b8',fontSize:10} },
                { name:'女性', type:'bar', stack:'total', data:[2100,950,180,12],
                    itemStyle:{color:{type:'linear',x:0,y:0,x2:1,y2:0,colorStops:[{offset:0,color:'#ec4899'},{offset:1,color:'#f472b6'}]}},
                    label:{show:true,position:'right',color:'#94a3b8',fontSize:10} }
            ]
        });
    }

    // 年龄结构堆叠柱状图
    el = document.getElementById('chart-nianling');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.nianling = echarts.init(el, 'dark');
        personnelCharts.nianling.setOption({
            backgroundColor:'transparent',
            tooltip: { trigger:'axis', axisPointer:{type:'shadow'} },
            legend: { data:['30岁以下','31-40岁','41-50岁','51-60岁'], bottom:0, textStyle:{color:'#94a3b8',fontSize:10}, itemWidth:10, itemHeight:10 },
            grid: { left:'3%', right:'4%', bottom:'14%', top:'6%', containLabel:true },
            xAxis: { type:'category', data:['厅机关','刑侦总队','交警总队','治安总队','网安总队','特警总队','监管总队','后勤中心'],
                axisLine:{lineStyle:{color:'rgba(0,212,255,0.1)'}}, axisLabel:{color:'#94a3b8',fontSize:9,rotate:25}, axisTick:{show:false} },
            yAxis: { type:'value', max:100, axisLine:{show:false}, splitLine:{lineStyle:{color:'rgba(0,212,255,0.05)'}}, axisLabel:{color:'#64748b',fontSize:10,formatter:'{value}%'} },
            series: [
                { name:'30岁以下', type:'bar', stack:'total', data:[12,18,8,22,35,28,10,6], itemStyle:{color:'#34d399'} },
                { name:'31-40岁', type:'bar', stack:'total', data:[28,32,20,35,42,38,22,18], itemStyle:{color:'#00d4ff'} },
                { name:'41-50岁', type:'bar', stack:'total', data:[32,28,26,25,15,19,26,28], itemStyle:{color:'#fbbf24'} },
                { name:'51-60岁', type:'bar', stack:'total', data:[28,22,46,18,8,15,42,48], itemStyle:{color:'#f87171'},
                    markLine: { silent:true, lineStyle:{color:'#f87171',type:'dashed',opacity:0.5}, data:[{yAxis:30}], label:{formatter:'预警线 30%',color:'#f87171',fontSize:9} } }
            ]
        });
    }

    // 学历结构玫瑰图
    el = document.getElementById('chart-xueli');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.xueli = echarts.init(el, 'dark');
        personnelCharts.xueli.setOption({
            backgroundColor:'transparent',
            tooltip: { trigger:'item', formatter:'{b}: {c}人 ({d}%)' },
            series: [{
                type:'pie', radius:[15,90], center:['50%','50%'], roseType:'area',
                itemStyle: { borderRadius:6, borderColor:'#0a0e1a', borderWidth:2 },
                label: { color:'#94a3b8', fontSize:10, formatter:'{b}\n{d}%' },
                labelLine: { lineStyle:{color:'rgba(148,163,184,0.3)'} },
                data: [
                    { value:180, name:'博士', itemStyle:{color:'#a78bfa'} },
                    { value:850, name:'硕士', itemStyle:{color:'#38bdf8'} },
                    { value:5760, name:'本科', itemStyle:{color:'#00d4ff'} },
                    { value:1200, name:'大专', itemStyle:{color:'#fbbf24'} },
                    { value:436, name:'中专及以下', itemStyle:{color:'#64748b'} }
                ]
            }],
            graphic: [
                { type:'text', left:'center', top:'44%', style:{text:'68.5%',fill:'#00d4ff',fontSize:22,fontWeight:'bold',fontFamily:'Orbitron'} },
                { type:'text', left:'center', top:'60%', style:{text:'本科及以上',fill:'#94a3b8',fontSize:10} }
            ]
        });
    }

    // 人员分类趋势折线图
    el = document.getElementById('chart-fenlei');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.fenlei = echarts.init(el, 'dark');
        personnelCharts.fenlei.setOption({
            backgroundColor:'transparent',
            tooltip: { trigger:'axis', axisPointer:{type:'cross',label:{backgroundColor:'#0f172a'}} },
            legend: { data:['公务员','事业编','辅警','工勤'], bottom:0, textStyle:{color:'#94a3b8',fontSize:10}, itemWidth:10, itemHeight:10 },
            grid: { left:'3%', right:'4%', bottom:'14%', top:'6%', containLabel:true },
            xAxis: { type:'category', boundaryGap:false, data:['2022','2023','2024','2025','2026'],
                axisLine:{lineStyle:{color:'rgba(0,212,255,0.1)'}}, axisLabel:{color:'#94a3b8',fontSize:10}, axisTick:{show:false} },
            yAxis: { type:'value', axisLine:{show:false}, splitLine:{lineStyle:{color:'rgba(0,212,255,0.05)'}}, axisLabel:{color:'#64748b',fontSize:10} },
            series: [
                { name:'公务员', type:'line', smooth:true, data:[5200,5350,5500,5650,5800], lineStyle:{color:'#00d4ff',width:2}, itemStyle:{color:'#00d4ff'}, symbol:'circle', symbolSize:4,
                    areaStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'rgba(0,212,255,0.25)'},{offset:1,color:'rgba(0,212,255,0.02)'}]}} },
                { name:'事业编', type:'line', smooth:true, data:[1200,1180,1150,1120,1080], lineStyle:{color:'#34d399',width:2}, itemStyle:{color:'#34d399'}, symbol:'circle', symbolSize:4,
                    areaStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'rgba(52,211,153,0.25)'},{offset:1,color:'rgba(52,211,153,0.02)'}]}} },
                { name:'辅警', type:'line', smooth:true, data:[800,950,1100,1350,1580], lineStyle:{color:'#f59e0b',width:2}, itemStyle:{color:'#f59e0b'}, symbol:'circle', symbolSize:4,
                    areaStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'rgba(245,158,11,0.25)'},{offset:1,color:'rgba(245,158,11,0.02)'}]}} },
                { name:'工勤', type:'line', smooth:true, data:[420,400,380,360,340], lineStyle:{color:'#64748b',width:2}, itemStyle:{color:'#64748b'}, symbol:'circle', symbolSize:4,
                    areaStyle:{color:{type:'linear',x:0,y:0,x2:0,y2:1,colorStops:[{offset:0,color:'rgba(100,116,139,0.25)'},{offset:1,color:'rgba(100,116,139,0.02)'}]}} }
            ]
        });
    }

    // 各单位人员数量横向柱状图
    el = document.getElementById('chart-danwei');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        personnelCharts.danwei = echarts.init(el, 'dark');
        personnelCharts.danwei.setOption({
            backgroundColor:'transparent',
            tooltip: { trigger:'axis', axisPointer:{type:'shadow'}, formatter:'{b}: {c}人' },
            grid: { left:'3%', right:'12%', bottom:'3%', top:'3%', containLabel:true },
            xAxis: { type:'value', axisLine:{show:false}, splitLine:{lineStyle:{color:'rgba(0,212,255,0.05)'}}, axisLabel:{color:'#64748b',fontSize:10} },
            yAxis: { type:'category', data:['后勤中心','监管总队','网安总队','治安总队','特警总队','厅机关','刑侦总队','交警总队'],
                axisLine:{lineStyle:{color:'rgba(0,212,255,0.1)'}}, axisLabel:{color:'#94a3b8',fontSize:10}, axisTick:{show:false} },
            series: [{
                type:'bar', barWidth:14,
                data: [
                    {value:382,itemStyle:{color:'#34d399'}},{value:456,itemStyle:{color:'#34d399'}},
                    {value:598,itemStyle:{color:'#34d399'}},{value:658,itemStyle:{color:'#34d399'}},
                    {value:856,itemStyle:{color:'#fbbf24'}},{value:1245,itemStyle:{color:'#fbbf24'}},
                    {value:962,itemStyle:{color:'#f87171'}},{value:1489,itemStyle:{color:'#fbbf24'}}
                ],
                itemStyle:{borderRadius:[0,4,4,0]},
                label:{show:true,position:'right',color:'#94a3b8',fontSize:10,formatter:'{c}人'}
            }]
        });
    }
    personnelChartsInited = true;
}

function showPersonnelDetail(title) {
    var modalTitle = document.getElementById('personnelModalTitle');
    var modal = document.getElementById('personnelModal');
    if (modalTitle) modalTitle.textContent = title;
    if (modal) modal.classList.add('active');
}

function closePersonnelModal() {
    var modal = document.getElementById('personnelModal');
    if (modal) modal.classList.remove('active');
}

// 事件监听
document.addEventListener('DOMContentLoaded', function() {
    var personnelModal = document.getElementById('personnelModal');
    if (personnelModal) {
        personnelModal.addEventListener('click', function(e) {
            if (e.target === personnelModal) closePersonnelModal();
        });
    }
});
