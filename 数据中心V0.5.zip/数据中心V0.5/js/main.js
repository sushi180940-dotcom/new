// ==================== 全局配置 ====================
const charts = {};
const initializedPages = { main: false, income: false, expense: false, sangong: false, purchase: false };

const commonTooltip = {
    backgroundColor: 'rgba(4, 12, 28, 0.98)',
    borderColor: 'rgba(0, 212, 255, 0.4)',
    textStyle: { color: '#e2e8f0', fontSize: 13 },
    padding: [12, 16],
    extraCssText: 'box-shadow: 0 4px 24px rgba(0,0,0,0.6); border-radius: 8px;'
};

function initChart(id, option) {
    var el = document.getElementById(id);
    if (!el) { console.warn('Chart element not found:', id); return null; }
    var w = el.clientWidth, h = el.clientHeight;
    if (w === 0 || h === 0) {
        console.warn('Chart container zero size:', id, w, h);
        return null;
    }
    var chart = echarts.init(el, 'dark');
    chart.setOption({backgroundColor:'transparent',...option});
    charts[id] = chart;
    return chart;
}

// ==================== 页面切换 ====================
function showPage(pageId) {
    document.querySelectorAll('.page, .detail-page, .panorama-page').forEach(function(p) {
        p.classList.remove('active');
    });
    var target = document.getElementById('page-' + pageId);
    if (target) target.classList.add('active');

    var sub = document.getElementById('pageSubtitle');
    var bc = document.getElementById('breadcrumb');
    var bcCurrent = document.getElementById('bcCurrent');
    var pageWrapper = document.querySelector('.page-wrapper');

    // 判断目标页面类型
    var isPanorama = target && target.classList.contains('panorama-page');
    var isDetail = target && target.classList.contains('detail-page');

    if (pageId === 'main') {
        sub.textContent = '经济运行全景';
        bc.style.display = 'none';
        document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = ''; });
        document.querySelectorAll('.nav-tab').forEach(function(b, i) { b.classList.toggle('active', i === 0); });
    } else if (isPanorama) {
        // 全景页面：显示 panorama-page，隐藏 breadcrumb
        sub.textContent = '详情';
        bc.style.display = 'none';
        document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = ''; });
    } else {
        // 详情/下钻页面：隐藏 panorama-page，显示 breadcrumb
        var titles = { income: '收入详情分析', expense: '支出详情分析', sangong: '三公经费详情', purchase: '采购合同执行分析' };
        sub.textContent = titles[pageId] || '详情';
        bc.style.display = 'block';
        bcCurrent.textContent = titles[pageId] || '详情';
        document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = 'none'; });
    }

    document.body.offsetHeight;
    setTimeout(function() {
        initPageWithRetry(pageId, 0);
    }, 300);
}

function initPageWithRetry(pageId, attempt) {
    if (attempt > 10) {
        console.error('Failed to init charts after 10 retries for page:', pageId);
        return;
    }
    var allReady = true;
    var chartIds = getChartIdsForPage(pageId);
    for (var i = 0; i < chartIds.length; i++) {
        var el = document.getElementById(chartIds[i]);
        if (!el) continue;
        if (el.clientWidth === 0 || el.clientHeight === 0) {
            allReady = false;
            break;
        }
    }
    if (allReady) {
        if (!initializedPages[pageId]) {
            initPageCharts(pageId);
            initializedPages[pageId] = true;
        }
        setTimeout(function() {
            Object.values(charts).forEach(function(c) { c && c.resize(); });
        }, 100);
    } else {
        setTimeout(function() {
            initPageWithRetry(pageId, attempt + 1);
        }, 200);
    }
}

function getChartIdsForPage(pageId) {
    switch(pageId) {
        case 'main': return ['incomeStructure','incomeTrend','budgetChange','fujianMap','purchaseFunnel','expenseStructure','sanGong','expenseTrend'];
        case 'income': return ['incomeUnitRank','incomeYoY','incomeVolatility','incomeRatioTrend','budgetYearCompare'];
        case 'expense': return ['expenseYoY','expenseBudgetRate','expenseRatioTrend','unitExecRank','subjectExecCompare'];
        case 'sangong': return ['sgYearTrend','sgItemRatio','sgItemExec','sgReduceEffect'];
        case 'purchase': return ['contractPayRate','contractAcceptRate','overdueRate','warrantyRate'];
        case 'unit-detail': return ['chart-unit-progress','chart-unit-budgetvsfinal','chart-unit-projects','chart-unit-fundtype','chart-unit-yearly','chart-unit-deptpct','chart-unit-deptcompare'];
        case 'vehicle-gps': return [];
        case 'asset-usage': return ['chart-usage-heatmap','chart-supplier-rank','chart-asset-aging','chart-usage-rank'];
        case 'unit-asset-detail': return ['chart-uad-equip-pie','chart-uad-equip-percapita','chart-uad-emergency-pie','chart-uad-clothing-pie','chart-uad-clothing-age','chart-uad-office-pie'];
        default: return [];
    }
}

function switchNav(btn, page) {
    window.location.hash = page;
    document.querySelectorAll('.nav-tab').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');
    var subtitles = {
        economic: '经济运行全景',
        financial: '财务全景',
        asset: '资产全景',
        personnel: '人员全景',
        warning: '智慧监督'
    };
    document.getElementById('pageSubtitle').textContent = subtitles[page] || '经济运行全景';

    document.querySelectorAll('.panorama-page, .detail-page, .page').forEach(function(p) {
        p.classList.remove('active');
    });
    document.querySelectorAll('.detail-page').forEach(function(p) { p.style.display = 'none'; });

    var pageMap = {
        economic: 'page-main',
        financial: 'page-financial',
        asset: 'page-asset',
        personnel: 'page-personnel',
        warning: 'page-warning'
    };
    var target = document.getElementById(pageMap[page]);
    if (target) target.classList.add('active');

    document.getElementById('breadcrumb').style.display = 'none';
    document.querySelectorAll('.detail-page').forEach(function(p) { p.classList.remove('active'); p.style.display = 'none'; });
    document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = ''; });

    if (page === 'asset' && !window.assetChartsInitialized) {
        setTimeout(function() { initAssetCharts(); window.assetChartsInitialized = true; }, 200);
    }
    if (page === 'financial' && !window.financialChartsInited) {
        setTimeout(function() { initFinancialCharts(); }, 200);
    }
    if (page === 'personnel' && !window.personnelChartsInited) {
        setTimeout(function() { initPersonnelCharts(); }, 200);
    }
    if (page === 'warning' && !window.warningChartsInited) {
        setTimeout(function() { initWarningPage(); window.warningChartsInited = true; }, 200);
    }

    setTimeout(function() {
        Object.values(charts).forEach(function(c) { c && c.resize(); });
        if (window.assetCharts) {
            Object.values(window.assetCharts).forEach(function(c) { c && c.resize(); });
        }
        if (window.personnelCharts) {
            Object.values(window.personnelCharts).forEach(function(c) { c && c.resize(); });
        }
    }, 300);
}

// ==================== 单位经济运行详情 ====================
function showUnitDetail(unitName) {
    document.getElementById('unitDetailTitle').textContent = unitName + ' - 经济运行详情';
    window.currentUnitName = unitName;
    // 更新KPI数据（模拟数据，根据城市名生成确定性数据）
    var citySeed = unitName.charCodeAt(0) + unitName.charCodeAt(unitName.length - 1);
    var budget = 3000 + (citySeed % 70) * 100;
    var execRate = 55 + (citySeed % 35);
    var deviation = (execRate - 75).toFixed(1);
    var projects = 8 + (citySeed % 12);
    var projNormal = Math.floor(projects * 0.7);
    var projWarn = projects - projNormal;
    var personnelPct = 35 + (citySeed % 25);
    var personnelYoy = ((citySeed % 10) - 3).toFixed(1);
    var personnelYoySign = personnelYoy > 0 ? '+' : '';

    document.getElementById('ud-budget').textContent = budget.toLocaleString();
    document.getElementById('ud-execrate').textContent = execRate + '%';
    document.getElementById('ud-execrate').style.color = execRate >= 75 ? '#10b981' : execRate >= 60 ? '#fbbf24' : '#ef4444';
    document.getElementById('ud-deviation').textContent = (deviation > 0 ? '+' : '') + deviation + '%';
    document.getElementById('ud-deviation').style.color = deviation >= 0 ? '#10b981' : '#ef4444';
    document.getElementById('ud-projects').textContent = projects;
    document.getElementById('ud-proj-normal').textContent = projNormal;
    document.getElementById('ud-proj-warn').textContent = projWarn;
    document.getElementById('ud-personnelpct').textContent = personnelPct + '%';
    document.getElementById('ud-personnelyoy').textContent = personnelYoySign + personnelYoy + '%';
    document.getElementById('ud-personnelyoy').style.color = personnelYoy >= 0 ? '#10b981' : '#ef4444';

    // 显示页面
    document.querySelectorAll('.page, .detail-page, .panorama-page').forEach(function(p) { p.classList.remove('active'); });
    document.getElementById('page-unit-detail').classList.add('active');
    document.getElementById('breadcrumb').style.display = 'none';
    document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = 'none'; });

    // 强制浏览器重排，确保容器获得正确尺寸
    document.body.offsetHeight;

    // 初始化图表（使用重试机制确保容器已就绪）
    setTimeout(function() {
        initPageWithRetry('unit-detail', 0);
    }, 300);
}

function highlightUnit(unitName) {
    var mapChart = charts['fujianMap'];
    if (mapChart) {
        mapChart.dispatchAction({ type: 'highlight', seriesIndex: 0 });
        mapChart.dispatchAction({ type: 'showTip', seriesIndex: 0, name: unitName });
    }
}

// ==================== 分发器 ====================
function initPageCharts(pageId) {
    switch(pageId) {
        case 'main': initMainCharts(); break;
        case 'income': initIncomeCharts(); break;
        case 'expense': initExpenseCharts(); break;
        case 'sangong': initSangongCharts(); break;
        case 'purchase': initPurchaseCharts(); break;
        case 'unit-detail': initUnitDetailCharts(); break;
        case 'vehicle-gps': initVehicleGpsCharts(); break;
        case 'asset-usage': initAssetUsageCharts(); break;
        case 'unit-asset-detail': initUnitAssetDetailCharts(); break;
    }
}

// ==================== 响应式 & 时钟 ====================
window.addEventListener('resize', function() {
    Object.values(charts).forEach(function(c) { c && c.resize(); });
    if (window.assetCharts) {
        Object.values(window.assetCharts).forEach(function(c) { c && c.resize(); });
    }
    if (window.personnelCharts) {
        Object.values(window.personnelCharts).forEach(function(c) { c && c.resize(); });
    }
});

setInterval(function() {
    var now = new Date();
    document.getElementById('headerTime').textContent = '\uD83D\uDD50 ' + now.toTimeString().split(' ')[0];
    document.getElementById('headerDate').textContent = '\uD83D\uDCC5 ' + now.toISOString().split('T')[0];
}, 1000);

// ==================== 预警规则弹窗 ====================
function openWarnRuleModal() {
    var modal = document.getElementById('warnRuleModal');
    if (modal) modal.classList.add('active');
}
function closeWarnRuleModal() {
    var modal = document.getElementById('warnRuleModal');
    if (modal) modal.classList.remove('active');
}
function saveWarnRules() {
    var inputs = document.querySelectorAll('#warnRuleModal .warn-rule-input');
    var rules = {};
    inputs.forEach(function(input) {
        rules[input.id] = input.value;
    });
    var toggles = document.querySelectorAll('#warnRuleModal .warn-rule-toggle');
    toggles.forEach(function(toggle, idx) {
        rules['toggle_' + idx] = toggle.classList.contains('active');
    });
    console.log('预警规则已保存:', rules);
    closeWarnRuleModal();
    setTimeout(function() {
        alert('✅ 预警规则配置已保存生效');
    }, 200);
}
function resetWarnRules() {
    var defaults = {
        'wr-exec-severe': 50, 'wr-exec-slow': 70, 'wr-exec-dev': 5,
        'wr-sangong-warn': 85, 'wr-sangong-danger': 95, 'wr-sangong-reduce': 10,
        'wr-asset-expiry': 30, 'wr-asset-stagnant': 10, 'wr-asset-diff': 2,
        'wr-vehicle-offline': 30, 'wr-vehicle-util': 20, 'wr-vehicle-speed': 120,
        'wr-staff-tense': 95, 'wr-staff-retire': 51, 'wr-staff-wave': 10,
        'wr-proc-accept': 7, 'wr-proc-pay': 15, 'wr-proc-warranty': 30
    };
    for (var key in defaults) {
        var input = document.getElementById(key);
        if (input) input.value = defaults[key];
    }
    document.querySelectorAll('#warnRuleModal .warn-rule-toggle').forEach(function(t) {
        t.classList.add('active');
    });
}

// 点击弹窗遮罩关闭
document.addEventListener('click', function(e) {
    var modal = document.getElementById('warnRuleModal');
    if (modal && e.target === modal) {
        closeWarnRuleModal();
    }
});

// ==================== 智慧监督页面 ====================
var warnTreeData = [
    { id: 'fund', name: '资金收支监控', icon: 'fa-coins', type: 'domain', children: [
        { id: 'fund-1', name: '大额交易', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r001', name: '大额对私支付监控', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r002', name: '单笔超50万支付预警', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r003', name: '高频小额转账识别', icon: 'fa-file-alt', type: 'rule' }
        ]},
        { id: 'fund-2', name: '可疑收款方', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r004', name: '收款方黑名单监测', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r005', name: '异常对公账户识别', icon: 'fa-file-alt', type: 'rule' }
        ]}
    ]},
    { id: 'budget', name: '预算执行监控', icon: 'fa-chart-pie', type: 'domain', children: [
        { id: 'budget-1', name: '执行进度', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r006', name: '预算执行率偏低预警', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r007', name: '重点项目执行滞后', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r008', name: '年底突击花钱识别', icon: 'fa-file-alt', type: 'rule' }
        ]},
        { id: 'budget-2', name: '预算调整', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r009', name: '频繁调整预算预警', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r010', name: '超预算调整幅度监测', icon: 'fa-file-alt', type: 'rule' }
        ]}
    ]},
    { id: 'three', name: '三公经费监控', icon: 'fa-car', type: 'domain', children: [
        { id: 'three-1', name: '公务接待', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r011', name: '超标准接待预警', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r012', name: '节假日接待识别', icon: 'fa-file-alt', type: 'rule' }
        ]},
        { id: 'three-2', name: '因公出国', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r013', name: '超期出国监测', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r014', name: '出国费用超标预警', icon: 'fa-file-alt', type: 'rule' }
        ]}
    ]},
    { id: 'asset', name: '国有资产监控', icon: 'fa-building', type: 'domain', children: [
        { id: 'asset-1', name: '资产卡片', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r015', name: '资产账实不符预警', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r016', name: '资产闲置超期监测', icon: 'fa-file-alt', type: 'rule' }
        ]},
        { id: 'asset-2', name: '处置记录', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r017', name: '低价处置资产识别', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r018', name: '未审批处置预警', icon: 'fa-file-alt', type: 'rule' }
        ]}
    ]},
    { id: 'account', name: '会计核算监控', icon: 'fa-calculator', type: 'domain', children: [
        { id: 'account-1', name: '凭证监控', icon: 'fa-folder', type: 'folder', children: [
            { id: 'r019', name: '摘要敏感词监测', icon: 'fa-file-alt', type: 'rule' },
            { id: 'r020', name: '借贷不平衡预警', icon: 'fa-file-alt', type: 'rule' }
        ]}
    ]}
];

var warnRulesData = [
    { id: 'r001', name: '大额对私支付监控', domain: '资金收支监控', object: '账户交易', condition: '对方户名类型=个人 且 交易性质=支出 且 累计金额>5万', level: 'yellow', status: 'active', time: '2024-06-28 14:32' },
    { id: 'r002', name: '单笔超50万支付预警', domain: '资金收支监控', object: '账户交易', condition: '单笔交易金额>500,000元', level: 'red', status: 'active', time: '2024-06-25 10:15' },
    { id: 'r003', name: '高频小额转账识别', domain: '资金收支监控', object: '账户交易', condition: '单日向同一对象转账>5次 且 单笔<1万', level: 'yellow', status: 'active', time: '2024-06-20 09:45' },
    { id: 'r004', name: '收款方黑名单监测', domain: '资金收支监控', object: '收款方行为', condition: '收款方在黑名单库中', level: 'red', status: 'active', time: '2024-06-18 16:22' },
    { id: 'r005', name: '异常对公账户识别', domain: '资金收支监控', object: '收款方行为', condition: '收款方为新注册企业(<90天)', level: 'yellow', status: 'inactive', time: '2024-06-15 11:08' },
    { id: 'r006', name: '预算执行率偏低预警', domain: '预算执行监控', object: '预算项目执行情况', condition: '执行率<40% 且 已过半年', level: 'yellow', status: 'active', time: '2024-06-28 08:30' },
    { id: 'r007', name: '重点项目执行滞后', domain: '预算执行监控', object: '预算项目执行情况', condition: '重点项目 且 执行率<30%', level: 'red', status: 'active', time: '2024-06-26 14:18' },
    { id: 'r008', name: '年底突击花钱识别', domain: '预算执行监控', object: '预算项目执行情况', condition: '11-12月支出占全年>50%', level: 'yellow', status: 'draft', time: '2024-06-10 10:00' },
    { id: 'r009', name: '频繁调整预算预警', domain: '预算执行监控', object: '预算调整记录', condition: '单项目年度调整>3次', level: 'yellow', status: 'active', time: '2024-06-22 09:33' },
    { id: 'r010', name: '超预算调整幅度监测', domain: '预算执行监控', object: '预算调整记录', condition: '调整幅度>30%', level: 'red', status: 'active', time: '2024-06-20 15:45' }
];

function initWarningPage() {
    renderWarnTree(warnTreeData, document.getElementById('warningTree'));
    renderWarnTable(warnRulesData);
    var selAll = document.getElementById('warnSelectAll');
    if (selAll) selAll.addEventListener('change', function() {
        document.querySelectorAll('#warnRuleTableBody input[type="checkbox"]').forEach(function(cb) { cb.checked = this.checked; }.bind(this));
    });
}

function renderWarnTree(nodes, container, level) {
    level = level || 0;
    nodes.forEach(function(node) {
        var item = document.createElement('div');
        item.className = 'warn-tree-node';
        var hasChildren = node.children && node.children.length > 0;
        var paddingLeft = level * 10;
        var iconClass = 'icon ';
        if (node.type === 'domain') iconClass += 'domain';
        else if (node.type === 'folder') iconClass += 'folder';
        else iconClass += 'rule';

        item.innerHTML = '<div class="warn-tree-item" style="padding-left:' + (10 + paddingLeft) + 'px" data-id="' + node.id + '" data-type="' + node.type + '" onclick="selectWarnTreeItem(this, \'' + node.id + '\', ' + hasChildren + ')">' +
            (hasChildren ? '<span class="toggle" onclick="event.stopPropagation();toggleWarnTree(this)"><i class="fas fa-chevron-right"></i></span>' : '<span class="toggle" style="visibility:hidden"><i class="fas fa-chevron-right"></i></span>') +
            '<span class="' + iconClass + '"><i class="fas ' + node.icon + '"></i></span>' +
            '<span style="flex:1">' + node.name + '</span>' +
            (node.type === 'rule' ? '<span style="font-size:10px;color:#475569">v1.3</span>' : '') +
            '</div>' +
            (hasChildren ? '<div class="warn-tree-children" id="wchildren-' + node.id + '"></div>' : '');
        container.appendChild(item);
        if (hasChildren) renderWarnTree(node.children, item.querySelector('#wchildren-' + node.id), level + 1);
    });
}

function toggleWarnTree(el) {
    el.classList.toggle('expanded');
    var children = el.closest('.warn-tree-node').querySelector('.warn-tree-children');
    if (children) children.classList.toggle('expanded');
}

function selectWarnTreeItem(el, id, hasChildren) {
    document.querySelectorAll('.warn-tree-item').forEach(function(item) { item.classList.remove('active'); });
    el.classList.add('active');
    if (hasChildren) {
        var toggle = el.querySelector('.toggle');
        if (!toggle.classList.contains('expanded')) toggleWarnTree(toggle);
    }
    var domainMap = {fund:'资金收支监控',budget:'预算执行监控',three:'三公经费监控',asset:'国有资产监控',account:'会计核算监控'};
    if (id.startsWith('r')) {
        var filtered = warnRulesData.filter(function(r) { return r.id === id; });
        renderWarnTable(filtered.length > 0 ? filtered : warnRulesData);
    } else if (domainMap[id]) {
        var f = warnRulesData.filter(function(r) { return r.domain === domainMap[id]; });
        renderWarnTable(f.length > 0 ? f : warnRulesData);
    } else {
        renderWarnTable(warnRulesData);
    }
}

function renderWarnTable(data) {
    var tbody = document.getElementById('warnRuleTableBody');
    tbody.innerHTML = '';
    data.forEach(function(rule) {
        var levelClass = rule.level === 'red' ? 'warn-level-red' : 'warn-level-yellow';
        var levelText = rule.level === 'red' ? '红色' : '黄色';
        var statusClass = rule.status === 'active' ? 'active' : (rule.status === 'draft' ? 'draft' : 'inactive');
        var statusText = rule.status === 'active' ? '已启用' : (rule.status === 'draft' ? '草稿' : '已停用');
        var row = document.createElement('tr');
        row.innerHTML = '<td><input type="checkbox"></td>' +
            '<td><strong>' + rule.name + '</strong></td>' +
            '<td><span style="color:#00d4ff;font-size:0.75rem">' + rule.domain + '</span></td>' +
            '<td>' + rule.object + '</td>' +
            '<td><span style="font-size:0.75rem;color:#64748b">' + rule.condition + '</span></td>' +
            '<td><span class="warn-level-badge ' + levelClass + '">' + levelText + '</span></td>' +
            '<td><span class="warn-status-badge ' + statusClass + '"><i class="fas fa-circle" style="font-size:5px"></i> ' + statusText + '</span></td>' +
            '<td style="font-size:0.75rem;color:#475569">' + rule.time + '</td>' +
            '<td><div class="warn-action-btns">' +
            '<button class="warn-action-btn edit" title="编辑" onclick="openWarnEditor(\'' + rule.id + '\', \'edit\')"><i class="fas fa-edit"></i></button>' +
            '<button class="warn-action-btn test" title="测试" onclick="openWarnEditor(\'' + rule.id + '\', \'test\')"><i class="fas fa-vial"></i></button>' +
            '<button class="warn-action-btn stop" title="停用/启用" onclick="toggleWarnRule(\'' + rule.id + '\')"><i class="fas fa-pause"></i></button>' +
            '<button class="warn-action-btn delete" title="删除" onclick="deleteWarnRule(\'' + rule.id + '\')"><i class="fas fa-trash-alt"></i></button>' +
            '</div></td>';
        tbody.appendChild(row);
    });
    document.getElementById('warnStatTotal').textContent = data.length;
    document.getElementById('warnStatActive').textContent = data.filter(function(r) { return r.status === 'active'; }).length;
}

function toggleWarnRule(id) {
    var rule = warnRulesData.find(function(r) { return r.id === id; });
    if (rule) { rule.status = rule.status === 'active' ? 'inactive' : 'active'; renderWarnTable(warnRulesData); }
}

function deleteWarnRule(id) {
    if (confirm('确定要删除该规则吗？此操作不可恢复。')) {
        var index = warnRulesData.findIndex(function(r) { return r.id === id; });
        if (index > -1) { warnRulesData.splice(index, 1); renderWarnTable(warnRulesData); }
    }
}

function filterWarnRules(type, el) {
    document.querySelectorAll('.warning-filter-tag').forEach(function(tag) { tag.classList.remove('active'); });
    el.classList.add('active');
    renderWarnTable(type === 'all' ? warnRulesData : warnRulesData.filter(function(r) { return r.status === type; }));
}

function batchWarnAction(type) { alert('批量' + (type === 'enable' ? '启用' : type === 'disable' ? '停用' : '删除') + '功能'); }
function openWarnEditor(id, mode) {
    var url = 'rule-editor.html';
    if (id) url += '?id=' + encodeURIComponent(id);
    if (mode) url += (id ? '&' : '?') + 'mode=' + encodeURIComponent(mode);
    window.location.href = url;
}

// ==================== 智慧监督详情页面 ====================
var triggerData = [
    { time: '09:15:32', rule: '大额对私支付监控', domain: '资金收支监控', object: '刑侦总队-张某', value: '68,500元', threshold: '>50,000元', level: 'yellow', status: '已触发' },
    { time: '09:42:18', rule: '单笔超50万支付预警', domain: '资金收支监控', object: '交警总队-设备采购', value: '520,000元', threshold: '>500,000元', level: 'red', status: '已触发' },
    { time: '10:05:44', rule: '预算执行率偏低预警', domain: '预算执行监控', object: '网安总队-信息化项目', value: '执行率32%', threshold: '<40%', level: 'yellow', status: '已触发' },
    { time: '10:28:09', rule: '重点项目执行滞后', domain: '预算执行监控', object: '禁毒总队-实验室建设', value: '执行率18%', threshold: '<30%', level: 'red', status: '已触发' },
    { time: '11:15:27', rule: '收款方黑名单监测', domain: '资金收支监控', object: '治安总队-装修款', value: '对方在黑名单', threshold: '黑名单匹配', level: 'red', status: '已触发' },
    { time: '11:38:53', rule: '超标准接待预警', domain: '三公经费监控', object: '科信总队-接待费', value: '人均680元', threshold: '>400元/人', level: 'yellow', status: '已触发' },
    { time: '12:02:11', rule: '高频小额转账识别', domain: '资金收支监控', object: '监管总队-李某', value: '8笔/日', threshold: '>5笔/日', level: 'yellow', status: '已触发' },
    { time: '13:45:29', rule: '资产账实不符预警', domain: '国有资产监控', object: '厅机关-电脑设备', value: '差异12台', threshold: '>0', level: 'red', status: '已触发' },
    { time: '14:10:07', rule: '摘要敏感词监测', domain: '会计核算监控', object: '特警总队-报销单', value: '包含"会所"', threshold: '敏感词匹配', level: 'yellow', status: '已触发' },
    { time: '14:33:56', rule: '年底突击花钱识别', domain: '预算执行监控', object: '法制总队-培训费', value: '12月占比62%', threshold: '>50%', level: 'yellow', status: '已触发' }
];

var pendingData = [
    { time: '09:42:18', rule: '单笔超50万支付预警', domain: '资金收支监控', object: '交警总队-设备采购', value: '520,000元', threshold: '>500,000元', level: 'red', status: 'unread' },
    { time: '08:30:05', rule: '收款方黑名单监测', domain: '资金收支监控', object: '治安总队-装修款', value: '对方在黑名单', threshold: '黑名单匹配', level: 'red', status: 'unread' },
    { time: '13:45:29', rule: '资产账实不符预警', domain: '国有资产监控', object: '厅机关-电脑设备', value: '差异12台', threshold: '>0', level: 'red', status: 'processing' },
    { time: '07:15:22', rule: '重点项目执行滞后', domain: '预算执行监控', object: '禁毒总队-实验室建设', value: '执行率18%', threshold: '<30%', level: 'red', status: 'awaiting' },
    { time: '09:15:32', rule: '大额对私支付监控', domain: '资金收支监控', object: '刑侦总队-张某', value: '68,500元', threshold: '>50,000元', level: 'yellow', status: 'unread' },
    { time: '10:05:44', rule: '预算执行率偏低预警', domain: '预算执行监控', object: '网安总队-信息化项目', value: '执行率32%', threshold: '<40%', level: 'yellow', status: 'processing' },
    { time: '11:38:53', rule: '超标准接待预警', domain: '三公经费监控', object: '科信总队-接待费', value: '人均680元', threshold: '>400元/人', level: 'yellow', status: 'awaiting' },
    { time: '06:50:17', rule: '频繁调整预算预警', domain: '预算执行监控', object: '交警总队-路面改造', value: '年度调整5次', threshold: '>3次', level: 'yellow', status: 'unread' },
    { time: '14:10:07', rule: '摘要敏感词监测', domain: '会计核算监控', object: '特警总队-报销单', value: '包含"会所"', threshold: '敏感词匹配', level: 'yellow', status: 'processing' },
    { time: '05:20:33', rule: '公车使用异常监测', domain: '三公经费监控', object: '监管总队-京A12345', value: '非工作日使用', threshold: '节假日用车', level: 'yellow', status: 'unread' },
    { time: '12:45:08', rule: '出国费用超标预警', domain: '三公经费监控', object: '刑侦总队-考察团', value: '人均8.5万', threshold: '>5万/人', level: 'red', status: 'awaiting' },
    { time: '15:10:41', rule: '凭证号段缺失预警', domain: '会计核算监控', object: '厅机关-财务处', value: '缺失3个号', threshold: '断号>0', level: 'yellow', status: 'unread' },
    { time: '03:30:15', rule: '未审批处置预警', domain: '国有资产监控', object: '治安总队-旧车辆', value: '未走审批流程', threshold: '未审批', level: 'red', status: 'awaiting' },
    { time: '11:20:49', rule: '超期出国监测', domain: '三公经费监控', object: '网安总队-技术交流', value: '超期7天', threshold: '>5天', level: 'yellow', status: 'processing' },
    { time: '16:05:27', rule: '节假日接待识别', domain: '三公经费监控', object: '科信总队-接待记录', value: '国庆假日接待', threshold: '节假日', level: 'yellow', status: 'unread' }
];

function showWarnDetail(type) {
    var pageId = type === 'trigger' ? 'page-warn-trigger' : 'page-warn-pending';
    var sub = document.getElementById('pageSubtitle');
    var bc = document.getElementById('breadcrumb');
    var bcCurrent = document.getElementById('bcCurrent');

    sub.textContent = type === 'trigger' ? '今日触发预警' : '待处理预警';
    bc.style.display = 'block';
    if (bcCurrent) bcCurrent.textContent = type === 'trigger' ? '今日触发预警' : '待处理预警';

    // Hide all pages
    document.querySelectorAll('.panorama-page, .page').forEach(function(p) { p.classList.remove('active'); p.style.display = 'none'; });
    document.querySelectorAll('.detail-page').forEach(function(p) { p.classList.remove('active'); p.style.display = 'none'; });

    // Show target detail page
    var target = document.getElementById(pageId);
    if (target) { target.classList.add('active'); target.style.display = 'block'; }

    if (type === 'trigger') renderTriggerTable(triggerData);
    else renderPendingTable(pendingData);
}

function renderTriggerTable(data) {
    var tbody = document.getElementById('triggerTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    data.forEach(function(row, idx) {
        var levelClass = row.level === 'red' ? 'warn-level-red' : 'warn-level-yellow';
        var levelText = row.level === 'red' ? '红色' : '黄色';
        var tr = document.createElement('tr');
        tr.innerHTML = '<td>' + (idx + 1) + '</td>' +
            '<td style="font-size:0.72rem;color:#94a3b8">' + row.time + '</td>' +
            '<td><strong>' + row.rule + '</strong></td>' +
            '<td><span style="color:#00d4ff;font-size:0.72rem">' + row.domain + '</span></td>' +
            '<td>' + row.object + '</td>' +
            '<td style="color:#fbbf24;font-weight:600">' + row.value + '</td>' +
            '<td style="font-size:0.72rem;color:#64748b">' + row.threshold + '</td>' +
            '<td><span class="warn-level-badge ' + levelClass + '">' + levelText + '</span></td>' +
            '<td><span style="font-size:0.72rem;color:#34d399">' + row.status + '</span></td>' +
            '<td><div class="warn-detail-action"><button class="warn-detail-action-btn" onclick="showToast(\'查看详情\')">查看</button></div></td>';
        tbody.appendChild(tr);
    });
}

function renderPendingTable(data) {
    var tbody = document.getElementById('pendingTableBody');
    if (!tbody) return;
    tbody.innerHTML = '';
    var statusMap = { unread: '未查看', processing: '处理中', awaiting: '待确认' };
    var statusClass = { unread: 'unread', processing: 'processing', awaiting: 'awaiting' };
    data.forEach(function(row, idx) {
        var levelClass = row.level === 'red' ? 'warn-level-red' : 'warn-level-yellow';
        var levelText = row.level === 'red' ? '红色' : '黄色';
        var sc = statusClass[row.status] || 'unread';
        var st = statusMap[row.status] || row.status;
        var tr = document.createElement('tr');
        tr.innerHTML = '<td>' + (idx + 1) + '</td>' +
            '<td style="font-size:0.72rem;color:#94a3b8">' + row.time + '</td>' +
            '<td><strong>' + row.rule + '</strong></td>' +
            '<td><span style="color:#00d4ff;font-size:0.72rem">' + row.domain + '</span></td>' +
            '<td>' + row.object + '</td>' +
            '<td style="color:#fbbf24;font-weight:600">' + row.value + '</td>' +
            '<td style="font-size:0.72rem;color:#64748b">' + row.threshold + '</td>' +
            '<td><span class="warn-level-badge ' + levelClass + '">' + levelText + '</span></td>' +
            '<td><span class="warn-status-dot ' + sc + '"><i class="fas fa-circle" style="font-size:5px"></i> ' + st + '</span></td>' +
            '<td><div class="warn-detail-action"><button class="warn-detail-action-btn" onclick="showToast(\'标记处理中\')">处理</button><button class="warn-detail-action-btn" onclick="showToast(\'查看详情\')">查看</button></div></td>';
        tbody.appendChild(tr);
    });
}

function filterTrigger(level, el) {
    el.parentElement.querySelectorAll('.warn-filter-chip').forEach(function(c) { c.classList.remove('active'); });
    el.classList.add('active');
    var filtered = level === 'all' ? triggerData : triggerData.filter(function(r) { return r.level === level; });
    renderTriggerTable(filtered);
}
function filterTriggerDomain(domain, el) {
    el.parentElement.querySelectorAll('.warn-filter-chip').forEach(function(c) { c.classList.remove('active'); });
    el.classList.add('active');
}
function filterPending(level, el) {
    el.parentElement.querySelectorAll('.warn-filter-chip').forEach(function(c) { c.classList.remove('active'); });
    el.classList.add('active');
    var filtered = level === 'all' ? pendingData : pendingData.filter(function(r) { return r.level === level; });
    renderPendingTable(filtered);
}
function filterPendingStatus(status, el) {
    el.parentElement.querySelectorAll('.warn-filter-chip').forEach(function(c) { c.classList.remove('active'); });
    el.classList.add('active');
    var filtered = status === 'all' ? pendingData : pendingData.filter(function(r) { return r.status === status; });
    renderPendingTable(filtered);
}

// ==================== 页面加载 ====================
document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
        initPageCharts('main');
        initializedPages.main = true;
    }, 300);
    // Handle hash-based navigation for warning page
    var hash = window.location.hash.replace('#', '');
    if (hash === 'warning') {
        var tabs = document.querySelectorAll('.nav-tab');
        if (tabs[4]) switchNav(tabs[4], 'warning');
    }
});
