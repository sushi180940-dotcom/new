// ==================== 资产全景图表 ====================
window.assetCharts = {};
window.assetChartsInitialized = false;

var assetCommonOption = { backgroundColor: 'transparent', textStyle: { fontFamily: 'Microsoft YaHei, Noto Sans SC, sans-serif' } };
var assetColors = ['#00d4ff','#0ea5e9','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899','#06b6d4'];

var rankData = {
    equip: [
        {name:'厅机关', val:'8,200万', trend:'up', rate:'3.2%'},
        {name:'科通总队', val:'7,500万', trend:'up', rate:'4.5%'},
        {name:'监管总队', val:'6,800万', trend:'down', rate:'1.1%'},
        {name:'特警总队', val:'6,200万', trend:'up', rate:'2.8%'},
        {name:'治安总队', val:'5,800万', trend:'up', rate:'1.5%'},
        {name:'刑警总队', val:'5,100万', trend:'down', rate:'0.8%'},
        {name:'交警总队', val:'4,200万', trend:'up', rate:'3.9%'},
        {name:'网安总队', val:'2,800万', trend:'up', rate:'5.6%'}
    ],
    office: [
        {name:'厅机关', val:'1,850台', trend:'up', rate:'2.1%'},
        {name:'交警总队', val:'1,240台', trend:'up', rate:'3.5%'},
        {name:'治安总队', val:'980台', trend:'down', rate:'0.8%'},
        {name:'刑警总队', val:'860台', trend:'up', rate:'1.2%'},
        {name:'特警总队', val:'720台', trend:'up', rate:'2.8%'},
        {name:'监管总队', val:'650台', trend:'down', rate:'1.5%'},
        {name:'科通总队', val:'480台', trend:'up', rate:'4.2%'},
        {name:'网安总队', val:'320台', trend:'up', rate:'3.1%'}
    ],
    clothing: [
        {name:'交警总队', val:'3,200套', trend:'up', rate:'5.1%'},
        {name:'特警总队', val:'2,800套', trend:'up', rate:'2.3%'},
        {name:'治安总队', val:'2,400套', trend:'down', rate:'0.5%'},
        {name:'厅机关', val:'1,800套', trend:'up', rate:'1.8%'},
        {name:'刑警总队', val:'1,500套', trend:'up', rate:'3.2%'},
        {name:'监管总队', val:'1,200套', trend:'down', rate:'0.9%'},
        {name:'科通总队', val:'980套', trend:'up', rate:'2.5%'},
        {name:'网安总队', val:'650套', trend:'up', rate:'4.1%'}
    ]
};

function initAssetCharts() {
    var el;

    // Office gauge
    el = document.getElementById('chart-office-gauge');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.office = echarts.init(el, 'dark');
        window.assetCharts.office.setOption({
            ...assetCommonOption,
            series: [{ type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100, splitNumber: 5, radius: '85%', center: ['50%','55%'],
                axisLine: { lineStyle: { width: 8, color: [[0.6,'#ef4444'],[0.9,'#f59e0b'],[1,'#10b981']] } },
                pointer: { itemStyle: { color: '#00d4ff' }, width: 3, length: '55%' },
                axisTick: { distance: -8, length: 4, lineStyle: { color: '#fff', width: 1 } },
                splitLine: { distance: -8, length: 8, lineStyle: { color: '#fff', width: 1 } },
                axisLabel: { color: '#94a3b8', distance: 12, fontSize: 10 },
                detail: { valueAnimation: true, formatter: '{value}%', color: '#00d4ff', fontSize: 18, fontWeight: 'bold', offsetCenter: [0,'50%'] },
                data: [{ value: 78.5, name: '健康度' }], title: { offsetCenter: [0,'70%'], fontSize: 12, color: '#94a3b8' }
            }]
        });
    }

    // Clothing gauge
    el = document.getElementById('chart-clothing-gauge');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.clothing = echarts.init(el, 'dark');
        window.assetCharts.clothing.setOption({
            ...assetCommonOption,
            series: [{ type: 'gauge', startAngle: 200, endAngle: -20, min: 0, max: 100, splitNumber: 5, radius: '85%', center: ['50%','55%'],
                axisLine: { lineStyle: { width: 8, color: [[0.6,'#ef4444'],[0.9,'#f59e0b'],[1,'#10b981']] } },
                pointer: { itemStyle: { color: '#0ea5e9' }, width: 3, length: '55%' },
                axisTick: { distance: -8, length: 4, lineStyle: { color: '#fff', width: 1 } },
                splitLine: { distance: -8, length: 8, lineStyle: { color: '#fff', width: 1 } },
                axisLabel: { color: '#94a3b8', distance: 12, fontSize: 10 },
                detail: { valueAnimation: true, formatter: '{value}%', color: '#0ea5e9', fontSize: 18, fontWeight: 'bold', offsetCenter: [0,'50%'] },
                data: [{ value: 92.4, name: '完成率' }], title: { offsetCenter: [0,'70%'], fontSize: 12, color: '#94a3b8' }
            }]
        });
    }

    // Health trend
    el = document.getElementById('chart-health-trend');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.healthTrend = echarts.init(el, 'dark');
        window.assetCharts.healthTrend.setOption({
            ...assetCommonOption, tooltip: { trigger: 'axis' },
            grid: { left: '2%', right: '4%', bottom: '2%', top: '10%', containLabel: true },
            xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { show: false }, axisTick: { show: false }, axisLabel: { color: '#64748b', fontSize: 10 } },
            yAxis: { type: 'value', min: 60, max: 100, axisLine: { show: false }, splitLine: { lineStyle: { color: '#1e293b' } }, axisLabel: { color: '#94a3b8', fontSize: 10 } },
            series: [{ type: 'line', data: [72, 75, 78, 76, 80, 85.2], smooth: true, lineStyle: { color: '#f59e0b', width: 2 }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(245,158,11,0.2)'},{offset:1,color:'rgba(245,158,11,0)'}] } }, itemStyle: { color: '#f59e0b' }, symbol: 'circle', symbolSize: 6 }]
        });
    }

    // Treemap
    el = document.getElementById('chart-treemap');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.treemap = echarts.init(el, 'dark');
        window.assetCharts.treemap.setOption({
            ...assetCommonOption, color: assetColors, tooltip: { formatter: function(p) { return p.name + ': ' + p.value + '万元'; } },
            series: [{ type: 'treemap', roam: false, nodeClick: false, breadcrumb: { show: false },
                label: { show: true, formatter: '{b}\n{c}万', fontSize: 12, color: '#fff' },
                itemStyle: { borderColor: '#0a0e1a', borderWidth: 2, gapWidth: 2 },
                width: '95%', height: '92%', left: '2.5%', top: '4%',
                data: [
                    { name: '武器警械', value: 12800, itemStyle: { color: '#00d4ff' } },
                    { name: '防护装备', value: 9600, itemStyle: { color: '#0ea5e9' } },
                    { name: '通信设备', value: 8200, itemStyle: { color: '#10b981' } },
                    { name: '警用交通', value: 6500, itemStyle: { color: '#f59e0b' } },
                    { name: '刑侦技术', value: 3200, itemStyle: { color: '#8b5cf6' } },
                    { name: '警服被装', value: 2800, itemStyle: { color: '#ec4899' } },
                    { name: '其他', value: 3800, itemStyle: { color: '#64748b' } }
                ]
            }]
        });
    }

    // Equip bar
    el = document.getElementById('chart-equip-bar');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.equipBar = echarts.init(el, 'dark');
        window.assetCharts.equipBar.setOption({
            ...assetCommonOption, tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
            grid: { left: '3%', right: '18%', bottom: '3%', top: '5%', containLabel: true },
            xAxis: { type: 'value', axisLine: { lineStyle: { color: '#334155' } }, splitLine: { lineStyle: { color: '#1e293b' } }, axisLabel: { color: '#94a3b8', fontSize: 12 } },
            yAxis: { type: 'category', data: ['网安总队','交警总队','刑警总队','治安总队','特警总队','监管总队','科通总队','厅机关'].reverse(), axisLine: { lineStyle: { color: '#334155' } }, axisLabel: { color: '#e2e8f0', fontSize: 13 } },
            series: [{ type: 'bar', data: [2800,4200,5100,5800,6200,6800,7500,8200].reverse(),
                itemStyle: { color: { type: 'linear', x:0,y:0,x2:1,y2:0, colorStops:[{offset:0,color:'#0ea5e9'},{offset:1,color:'#00d4ff'}] }, borderRadius: [0,4,4,0] },
                label: { show: true, position: 'right', color: '#00d4ff', fontSize: 12, formatter: '{c}万' }, barWidth: '55%'
            }]
        });
        // 点击柱子进入单位资产详情
        window.assetCharts.equipBar.on('click', function(params) {
            if (params.name) {
                showUnitAssetDetail(params.name);
            }
        });
    }

    // Radar
    el = document.getElementById('chart-radar');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.radar = echarts.init(el, 'dark');
        window.assetCharts.radar.setOption({
            ...assetCommonOption, tooltip: {},
            radar: {
                indicator: [{name:'防护类',max:100},{name:'救援类',max:100},{name:'通讯类',max:100},{name:'生活保障',max:100},{name:'医疗急救',max:100},{name:'照明动力',max:100}],
                shape: 'polygon', splitNumber: 4, axisName: { color: '#94a3b8', fontSize: 13 },
                splitLine: { lineStyle: { color: '#1e293b' } },
                splitArea: { show: true, areaStyle: { color: ['rgba(0,212,255,0.02)','rgba(0,212,255,0.05)'] } },
                axisLine: { lineStyle: { color: '#334155' } }
            },
            series: [{ type: 'radar',
                data: [
                    { value: [52,78,85,92,88,75], name: '库存充足度', areaStyle: { color: 'rgba(239,68,68,0.2)' }, lineStyle: { color: '#ef4444', width: 2 }, itemStyle: { color: '#ef4444' } },
                    { value: [100,100,100,100,100,100], name: '标准线', lineStyle: { color: 'rgba(0,212,255,0.3)', type: 'dashed', width: 1 }, itemStyle: { color: 'transparent' }, areaStyle: { color: 'transparent' }, symbol: 'none' }
                ]
            }]
        });
    }

    // Pie
    el = document.getElementById('chart-pie');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.pie = echarts.init(el, 'dark');
        window.assetCharts.pie.setOption({
            ...assetCommonOption, tooltip: { trigger: 'item', formatter: '{b}: {c}万元 ({d}%)' },
            legend: { show: false },
            series: [{ type: 'pie', radius: ['45%','75%'], center: ['50%','50%'], avoidLabelOverlap: false, label: { show: false }, labelLine: { show: false },
                data: [
                    { value: 3200, name: '1号中心库', itemStyle: { color: '#00d4ff' } },
                    { value: 2100, name: '2号应急库', itemStyle: { color: '#0ea5e9' } },
                    { value: 1800, name: '3号战备库', itemStyle: { color: '#10b981' } },
                    { value: 950, name: '交警代储点', itemStyle: { color: '#f59e0b' } },
                    { value: 600, name: '其他代储', itemStyle: { color: '#8b5cf6' } }
                ]
            }]
        });
    }

    // Trend mini
    el = document.getElementById('chart-trend');
    if (el && el.clientWidth > 0 && el.clientHeight > 0) {
        window.assetCharts.trend = echarts.init(el, 'dark');
        window.assetCharts.trend.setOption({
            ...assetCommonOption, tooltip: { trigger: 'axis' },
            grid: { left: '2%', right: '4%', bottom: '2%', top: '15%', containLabel: true },
            xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { show: false }, axisTick: { show: false }, axisLabel: { color: '#64748b', fontSize: 10 } },
            yAxis: { type: 'value', axisLine: { show: false }, splitLine: { show: false }, axisLabel: { show: false } },
            series: [{ type: 'line', data: [8200,8350,8100,8400,8520,8650], smooth: true, lineStyle: { color: '#00d4ff', width: 1.5 }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(0,212,255,0.2)'},{offset:1,color:'rgba(0,212,255,0)'}] } }, itemStyle: { color: '#00d4ff' }, symbol: 'none' }]
        });
    }

    // Map tooltip interactions
    var tooltipA = document.getElementById('mapTooltipA');
    if (tooltipA) {
        document.querySelectorAll('.map-bubble-a').forEach(function(bubble) {
            bubble.addEventListener('mouseenter', function(e) {
                var wrap = bubble.closest('.map-wrap-a');
                var rect = wrap.getBoundingClientRect();
                var cx = parseFloat(bubble.querySelector('circle').getAttribute('cx'));
                var cy = parseFloat(bubble.querySelector('circle').getAttribute('cy'));
                document.getElementById('mtTitleA').textContent = bubble.dataset.city;
                document.getElementById('mtValueA').textContent = bubble.dataset.value + '万元';
                document.getElementById('mtRateA').textContent = bubble.dataset.rate + '%';
                tooltipA.style.left = (cx / 400 * rect.width + 10) + 'px';
                tooltipA.style.top = (cy / 260 * rect.height - 10) + 'px';
                tooltipA.classList.add('show');
            });
            bubble.addEventListener('mouseleave', function() { tooltipA.classList.remove('show'); });
        });
    }
}

function switchRankTab(el, type) {
    document.querySelectorAll('.tab-btn-a').forEach(function(b) { b.classList.remove('active'); });
    el.classList.add('active');
    var data = rankData[type];
    var tbody = document.getElementById('rankTableBodyA');
    if (tbody) {
        tbody.innerHTML = data.map(function(item, i) {
            return '<tr><td class="rank-num-a">' + (i+1) + '</td><td class="rank-name-a">' + item.name + '</td><td class="rank-val-a">' + item.val + '</td><td style="text-align:right;"><span class="rank-trend-a ' + item.trend + '">' + (item.trend === 'up' ? '↑' : '↓') + ' ' + item.rate + '</span></td></tr>';
        }).join('');
    }
}

function handleWarningClickA(el, type) {
    document.querySelectorAll('.warning-item-a').forEach(function(i) { i.classList.remove('linked'); });
    el.classList.add('linked');
    document.querySelectorAll('.col-panel-a').forEach(function(p) { p.classList.remove('highlight-active'); });
    var capsule = document.getElementById('capsule-expiry');
    var officeMatch = document.getElementById('office-match');
    if (capsule) capsule.classList.remove('flash');
    if (officeMatch) officeMatch.classList.remove('warning');

    switch(type) {
        case 'shortage':
            if (window.assetCharts.radar) {
                window.assetCharts.radar.dispatchAction({ type: 'highlight', seriesIndex: 0, dataIndex: 0 });
                setTimeout(function() { window.assetCharts.radar.dispatchAction({ type: 'downplay', seriesIndex: 0, dataIndex: 0 }); }, 2000);
            }
            break;
        case 'expiry':
            if (capsule) capsule.classList.add('flash');
            break;
        case 'stagnant':
            var colOffice = document.getElementById('col-office');
            if (colOffice) colOffice.classList.add('highlight-active');
            break;
        case 'vehicle':
            break;
        case 'inventory':
            var colOffice2 = document.getElementById('col-office');
            if (colOffice2) colOffice2.classList.add('highlight-active');
            if (officeMatch) officeMatch.classList.add('warning');
            break;
        case 'clothing':
            var colClothing = document.getElementById('col-clothing');
            if (colClothing) colClothing.classList.add('highlight-active');
            break;
    }
}

function filterWarningsA(el, type) {
    document.querySelectorAll('.filter-tag-a').forEach(function(t) { t.classList.remove('active'); });
    el.classList.add('active');
    document.querySelectorAll('.warning-item-a').forEach(function(item) {
        item.style.display = (type === 'all' || item.dataset.type === type) ? 'flex' : 'none';
    });
}


// ==================== 车辆GPS实时监控 ====================
var vehicleData = [
    {vid:'V001',plate:'闽O·A1234',driver:'张警官',lat:0,lng:0,status:'online',speed:45,location:'鼓楼区五四路',mileage:125800,type:'巡逻车',dept:'交警总队'},
    {vid:'V002',plate:'闽O·B5678',driver:'李警官',lat:0,lng:0,status:'online',speed:32,location:'台江区工业路',mileage:98200,type:'警车',dept:'治安总队'},
    {vid:'V003',plate:'闽O·C9012',driver:'王警官',lat:0,lng:0,status:'online',speed:0,location:'仓山区浦上大道',mileage:156400,type:'特警车',dept:'特警总队'},
    {vid:'V004',plate:'闽O·D3456',driver:'赵警官',lat:0,lng:0,status:'alarm',speed:85,location:'仓山区福峡路',mileage:87400,type:'巡逻车',dept:'交警总队'},
    {vid:'V005',plate:'闽O·E7890',driver:'刘警官',lat:0,lng:0,status:'online',speed:28,location:'晋安区福马路',mileage:203100,type:'指挥车',dept:'厅机关'},
    {vid:'V006',plate:'闽O·F2345',driver:'陈警官',lat:0,lng:0,status:'offline',speed:0,location:'晋安区新店镇',mileage:67800,type:'警车',dept:'刑侦总队'},
    {vid:'V007',plate:'闽O·G6789',driver:'杨警官',lat:0,lng:0,status:'online',speed:52,location:'鼓楼区华林路',mileage:112300,type:'巡逻车',dept:'网安总队'},
    {vid:'V008',plate:'闽O·H0123',driver:'黄警官',lat:0,lng:0,status:'online',speed:0,location:'鼓楼区北二环',mileage:145600,type:'押运车',dept:'监管总队'},
    {vid:'V009',plate:'闽O·J4567',driver:'周警官',lat:0,lng:0,status:'offline',speed:0,location:'台江区鳌峰路',mileage:92300,type:'警车',dept:'禁毒总队'},
    {vid:'V010',plate:'闽O·K8901',driver:'吴警官',lat:0,lng:0,status:'online',speed:38,location:'台江区西二环',mileage:187500,type:'巡逻车',dept:'科信总队'}
];

function initVehicleGpsCharts() {
    renderVehicleList();
}

function renderVehicleList() {
    var list = document.getElementById('vehicleList');
    if (!list) return;
    list.innerHTML = vehicleData.map(function(v) {
        var statusText = v.status === 'online' ? '在线' : v.status === 'alarm' ? '告警' : '离线';
        var speedText = v.speed > 0 ? v.speed + ' km/h' : '停靠';
        return '<div class="vgps-item" data-vid="' + v.vid + '" onclick="selectVehicle(\'' + v.vid + '\')">' +
            '<div class="vgps-dot ' + v.status + '"></div>' +
            '<div class="vgps-info">' +
                '<div class="vgps-plate">' + v.plate + '</div>' +
                '<div class="vgps-detail">' + v.driver + ' · ' + v.dept + '</div>' +
            '</div>' +
            '<div class="vgps-speed">' + speedText + '</div>' +
        '</div>';
    }).join('');
}

function selectVehicle(vid) {
    var v = vehicleData.find(function(d) { return d.vid === vid; });
    if (!v) return;

    // 优先使用迷你弹窗（资产全景页），否则使用完整弹窗（GPS详情页）
    var miniPopup = document.getElementById('vehiclePopupMini');
    var fullPopup = document.getElementById('vehiclePopup');
    var isMini = !!miniPopup;
    var popup = miniPopup || fullPopup;
    if (!popup) return;

    // 高亮列表项（仅GPS详情页有列表）
    if (fullPopup) {
        document.querySelectorAll('.vgps-item').forEach(function(el) { el.classList.remove('selected'); });
        var item = document.querySelector('.vgps-item[data-vid="' + vid + '"]');
        if (item) item.classList.add('selected');
    }

    // 隐藏其他弹窗
    if (miniPopup) miniPopup.classList.remove('show');
    if (fullPopup && popup !== fullPopup) fullPopup.classList.remove('show');

    // 填充数据
    var suffix = isMini ? '-m' : '';
    document.getElementById('vgp-plate' + suffix).textContent = v.plate;
    var stEl = document.getElementById('vgp-status' + suffix);
    stEl.textContent = v.status === 'online' ? '在线' : v.status === 'alarm' ? '告警' : '离线';
    stEl.className = 'vgp-status ' + v.status;
    document.getElementById('vgp-driver' + suffix).textContent = v.driver;
    document.getElementById('vgp-location' + suffix).textContent = v.location;
    document.getElementById('vgp-speed' + suffix).textContent = v.speed > 0 ? v.speed + ' km/h' : '停靠';
    if (!isMini) {
        document.getElementById('vgp-mileage').textContent = (v.mileage / 10000).toFixed(2) + '万km';
    }
    document.getElementById('vgp-dept' + suffix).textContent = v.dept;

    popup.classList.add('show');
}

// ==================== 资产使用分析 ====================
function initAssetUsageCharts() {
    var ucolors = { blue:'#409eff', cyan:'#00d4ff', green:'#67c23a', yellow:'#e6a23c', red:'#f56c6c', purple:'#a855f7' };
    var uTextColor = '#8b9dc3';
    var uAxisColor = 'rgba(139,157,195,0.2)';
    var cto = function(id, opt) {
        var el = document.getElementById(id);
        if (el && el.clientWidth > 0 && el.clientHeight > 0) {
            if (!window.assetUsageCharts) window.assetUsageCharts = {};
            if (window.assetUsageCharts[id]) { window.assetUsageCharts[id].dispose(); }
            window.assetUsageCharts[id] = echarts.init(el, 'dark');
            window.assetUsageCharts[id].setOption(opt);
        }
    };

    // (1) 资产使用频次热力图
    var units = ['厅机关','交警总队','治安总队','特警总队','刑侦总队','网安总队','监管总队','禁毒总队','科信总队','科通处','法制总队','人事处','警保部','反恐总队'];
    var types = ['武器警械','防护装备','通信设备','警用交通','刑侦技术','警服被装','办公设备','其他'];
    var heatData = [];
    for (var i = 0; i < units.length; i++) {
        for (var j = 0; j < types.length; j++) {
            var base = 50 + ((i * 7 + j * 13) % 150);
            if (i < 3 && j < 3) base += 80;
            heatData.push([j, i, base]);
        }
    }
    cto('chart-usage-heatmap', {
        backgroundColor: 'transparent',
        tooltip: { position: 'top', backgroundColor: 'rgba(16,24,48,0.95)', borderColor: ucolors.blue, textStyle: { color: '#e0e6f0' },
            formatter: function(p) { return units[p.value[1]] + '<br/>' + types[p.value[0]] + ': <span style="color:#00d4ff;font-weight:700;">' + p.value[2] + '次</span>'; }
        },
        grid: { left: 65, right: 20, top: 10, bottom: 30 },
        xAxis: { type: 'category', data: types, axisLine: { lineStyle: { color: uAxisColor } }, axisLabel: { color: uTextColor, fontSize: 9, rotate: 20 }, axisTick: { show: false }, splitArea: { show: true, areaStyle: { color: 'rgba(64,158,255,0.02)' } } },
        yAxis: { type: 'category', data: units, axisLine: { lineStyle: { color: uAxisColor } }, axisLabel: { color: uTextColor, fontSize: 9 }, axisTick: { show: false }, splitArea: { show: true, areaStyle: { color: 'rgba(64,158,255,0.02)' } } },
        visualMap: { min: 0, max: 250, calculable: true, orient: 'horizontal', left: 'center', bottom: 0, itemWidth: 12, itemHeight: 50, textStyle: { color: uTextColor, fontSize: 10 }, inRange: { color: [ucolors.red, ucolors.yellow, ucolors.green, ucolors.blue] }, text: ['高频', '低频'] },
        series: [{ type: 'heatmap', data: heatData, label: { show: true, color: '#fff', fontSize: 8, textShadowColor: 'rgba(0,0,0,0.5)', textShadowBlur: 2 }, itemStyle: { borderColor: 'rgba(10,14,26,0.5)', borderWidth: 1, borderRadius: 3 }, emphasis: { itemStyle: { shadowBlur: 12, shadowColor: 'rgba(64,158,255,0.4)', borderColor: ucolors.cyan, borderWidth: 2 } } }]
    });

    // (2) 供应商采购排名
    var suppliers = ['华为技术','海康威视','大疆创新','中兴通讯','三一重工','比亚迪','海能达','浙江大华','宇视科技','其他'];
    var sAmounts = [2850, 1920, 1680, 1350, 980, 760, 620, 540, 430, 470];
    cto('chart-supplier-rank', {
        backgroundColor: 'transparent', tooltip: { trigger: 'axis', backgroundColor: 'rgba(16,24,48,0.95)', borderColor: ucolors.blue, textStyle: { color: '#e0e6f0' }, formatter: function(p) { var d = p[0]; return d.name + '<br/>采购金额: <span style="color:#00d4ff;font-weight:700;">' + d.value + '万</span>'; } },
        grid: { left: 10, right: 70, top: 10, bottom: 10, containLabel: true },
        xAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 9 } },
        yAxis: { type: 'category', data: suppliers, axisLine: { lineStyle: { color: uAxisColor } }, axisLabel: { color: '#94a3b8', fontSize: 10 }, inverse: true },
        series: [{ type: 'bar', barWidth: 14, data: sAmounts, itemStyle: { color: { type: 'linear', x:0,y:0,x2:1,y2:0, colorStops:[{offset:0,color:'#0ea5e9'},{offset:1,color:'#00d4ff'}] }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#94a3b8', fontSize: 9, formatter: '{c}万' } }]
    });

    // (3) 资产年限与折旧分析
    var assetCats = ['武器警械','防护装备','通信设备','警用交通','刑侦技术','警服被装','办公设备','其他'];
    var catCounts = [320, 280, 450, 520, 180, 680, 920, 350];
    var catYears = [3.2, 2.8, 4.1, 5.6, 3.5, 2.1, 4.8, 6.2];
    var catDeprec = [32, 28, 41, 56, 35, 21, 48, 62];
    cto('chart-asset-aging', {
        backgroundColor: 'transparent', tooltip: { trigger: 'axis', backgroundColor: 'rgba(16,24,48,0.95)', borderColor: ucolors.blue, textStyle: { color: '#e0e6f0' } },
        legend: { data: ['资产数量','平均折旧率(%)'], top: 0, textStyle: { color: uTextColor, fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 40, top: 30, bottom: 25, containLabel: true },
        xAxis: { type: 'category', data: assetCats, axisLine: { lineStyle: { color: uAxisColor } }, axisLabel: { color: uTextColor, fontSize: 9, rotate: 15 }, axisTick: { show: false } },
        yAxis: [
            { type: 'value', name: '数量', nameTextStyle: { color: uTextColor, fontSize: 9 }, axisLine: { show: false }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 9 } },
            { type: 'value', name: '折旧%', nameTextStyle: { color: uTextColor, fontSize: 9 }, axisLine: { show: false }, splitLine: { show: false }, axisLabel: { color: '#64748b', fontSize: 9, formatter: '{value}%' }, max: 100 }
        ],
        series: [
            { name: '资产数量', type: 'bar', barWidth: '40%', data: catCounts, itemStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'#0ea5e9'},{offset:1,color:'rgba(14,165,233,0.3)'}] }, borderRadius: [4,4,0,0] } },
            { name: '平均折旧率(%)', type: 'line', yAxisIndex: 1, data: catDeprec, smooth: true, symbol: 'circle', symbolSize: 5, lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' }, markLine: { silent: true, lineStyle: { color: '#ef4444', type: 'dashed', opacity: 0.5 }, data: [{ yAxis: 50, label: { formatter: '预警线50%', color: '#ef4444', fontSize: 9 } }] } }
        ]
    });

    // (4) 各单位装备使用率排名
    var u2 = ['厅机关','交警总队','治安总队','特警总队','刑侦总队','网安总队','监管总队','禁毒总队','科信总队','科通处','法制总队','人事处','警保部','反恐总队'];
    var u2Rate = [85, 92, 76, 88, 72, 68, 81, 75, 63, 70, 66, 78, 82, 90];
    cto('chart-usage-rank', {
        backgroundColor: 'transparent', tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' }, backgroundColor: 'rgba(16,24,48,0.95)', borderColor: ucolors.blue, textStyle: { color: '#e0e6f0' }, formatter: function(p) { return p[0].name + '<br/>使用率: <span style="color:#00d4ff;font-weight:700;">' + p[0].value + '%</span>'; } },
        grid: { left: 10, right: 50, top: 10, bottom: 10, containLabel: true },
        xAxis: { type: 'value', max: 100, axisLine: { show: false }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 9, formatter: '{value}%' } },
        yAxis: { type: 'category', data: u2, axisLine: { lineStyle: { color: uAxisColor } }, axisLabel: { color: '#94a3b8', fontSize: 9 }, inverse: true },
        series: [{ type: 'bar', barWidth: 12, data: u2Rate.map(function(v) { return { value: v, itemStyle: { color: v >= 90 ? '#10b981' : v >= 70 ? '#f59e0b' : '#ef4444', borderRadius: [0,4,4,0] } }; }), label: { show: true, position: 'right', color: '#94a3b8', fontSize: 9, formatter: '{c}%' } }]
    });
}


// ==================== 单位资产详情 ====================
window.currentAssetUnit = '';
window.uadCharts = {};

function showUnitAssetDetail(unitName) {
    window.currentAssetUnit = unitName;
    document.getElementById('unitAssetTitle').innerHTML = unitName + ' <span style="font-size:14px;color:#64748b;font-weight:400;">· 资产详情</span>';

    // 重置TAB到第一个
    document.querySelectorAll('.uad-tab').forEach(function(t) { t.classList.remove('active'); });
    document.querySelectorAll('.uad-panel').forEach(function(p) { p.classList.remove('active'); });
    document.querySelector('.uad-tab[data-tab="equip"]').classList.add('active');
    document.getElementById('uad-equip').classList.add('active');

    // 显示页面
    document.querySelectorAll('.page, .detail-page, .panorama-page').forEach(function(p) { p.classList.remove('active'); });
    document.getElementById('page-unit-asset-detail').classList.add('active');
    document.getElementById('breadcrumb').style.display = 'none';
    document.querySelectorAll('.panorama-page').forEach(function(p) { p.style.display = 'none'; });
    document.body.offsetHeight;

    setTimeout(function() {
        initUnitAssetDetailCharts();
    }, 200);
}

function switchUadTab(btn, tabName) {
    document.querySelectorAll('.uad-tab').forEach(function(t) { t.classList.remove('active'); });
    btn.classList.add('active');
    document.querySelectorAll('.uad-panel').forEach(function(p) { p.classList.remove('active'); });
    document.getElementById('uad-' + tabName).classList.add('active');

    // 如果是资产处置TAB，需要初始化图表
    if (tabName === 'dispose' || tabName === 'vehicle' || tabName === 'office' || tabName === 'clothing' || tabName === 'emergency' || tabName === 'equip') {
        setTimeout(function() { initUnitAssetDetailCharts(); }, 100);
    }
}

function initUnitAssetDetailCharts() {
    var unit = window.currentAssetUnit || '厅机关';
    var seed = unit.charCodeAt(0) + unit.charCodeAt(unit.length - 1);
    var c = function(id, opt) {
        var el = document.getElementById(id);
        if (el && el.clientWidth > 0 && el.clientHeight > 0) {
            if (window.uadCharts[id]) { window.uadCharts[id].dispose(); }
            window.uadCharts[id] = echarts.init(el, 'dark');
            window.uadCharts[id].setOption(opt);
        }
    };
    var tc = { bg: 'transparent', txt: '#8b9dc3', axis: 'rgba(139,157,195,0.2)', gridC: 'rgba(139,157,195,0.08)' };

    // ---- 生成数据 ----
    var orig = 300 + (seed % 500);
    var net = Math.round(orig * (0.4 + (seed % 30) / 100));
    var dep = ((1 - net / orig) * 100).toFixed(0);
    document.getElementById('uad-eq-original').textContent = orig + '万';
    document.getElementById('uad-eq-net').textContent = net + '万';
    document.getElementById('uad-eq-deprec').textContent = dep + '%';

    var emCount = 80 + (seed % 120);
    var emVal = (emCount * 0.15).toFixed(0);
    document.getElementById('uad-em-count').textContent = emCount + '件';
    document.getElementById('uad-em-value').textContent = emVal + '万';
    document.getElementById('uad-em-rate').textContent = (85 + (seed % 14)) + '%';

    var clCount = 200 + (seed % 300);
    document.getElementById('uad-cl-count').textContent = clCount + '件';
    document.getElementById('uad-cl-value').textContent = (10 + (seed % 20)) + '万';

    var ofCount = 100 + (seed % 200);
    document.getElementById('uad-of-count').textContent = ofCount + '台';
    document.getElementById('uad-of-value').textContent = (15 + (seed % 30)) + '万';
    document.getElementById('uad-of-rate').textContent = (80 + (seed % 18)) + '%';

    var vhVal = 15 + (seed % 35);
    document.getElementById('uad-vh-value').textContent = vhVal + '万';
    document.getElementById('uad-vh-util').textContent = (70 + (seed % 25)) + '%';
    document.getElementById('uad-vh-gps').textContent = (85 + (seed % 12)) + '%';

    var dpAmt = 100 + (seed % 400);
    document.getElementById('uad-dp-amount').textContent = dpAmt + '万';
    document.getElementById('uad-dp-scrap').textContent = (1 + (seed % 4)) + '项';
    document.getElementById('uad-dp-transfer').textContent = (1 + (seed % 5)) + '项';

    // ---- TAB1: 装备 饼图 ----
    c('chart-uad-equip-pie', {
        backgroundColor: 'transparent', tooltip: { trigger: 'item', formatter: '{b}: {c}万 ({d}%)' },
        legend: { orient: 'vertical', right: 5, top: 'center', textStyle: { color: tc.txt, fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
        series: [{ type: 'pie', radius: ['40%', '65%'], center: ['32%', '50%'], label: { show: false }, labelLine: { show: false },
            data: [
                { value: Math.round(orig*0.25), name: '武器警械', itemStyle: { color: '#3b82f6' } },
                { value: Math.round(orig*0.20), name: '防护装备', itemStyle: { color: '#06b6d4' } },
                { value: Math.round(orig*0.18), name: '安检装备', itemStyle: { color: '#a855f7' } },
                { value: Math.round(orig*0.15), name: '通信装备', itemStyle: { color: '#10b981' } },
                { value: Math.round(orig*0.12), name: '交通工具', itemStyle: { color: '#fbbf24' } },
                { value: Math.round(orig*0.10), name: '其他', itemStyle: { color: '#64748b' } }
            ], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
        }]
    });

    // TAB1: 人均装备对比
    var cats = ['武器警械','防护装备','安检装备','通信装备','交通工具'];
    var myVal = [15,8,6,4,2].map(function(v) { return v + (seed % 5); });
    var avgVal = [18,12,10,8,5];
    c('chart-uad-equip-percapita', {
        backgroundColor: 'transparent', tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: { data: ['本单位','全厅均值'], top: 0, textStyle: { color: tc.txt, fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 20, top: 28, bottom: 10, containLabel: true },
        xAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: tc.gridC, type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        yAxis: { type: 'category', data: cats, axisLine: { lineStyle: { color: tc.axis } }, axisLabel: { color: tc.txt, fontSize: 10 }, inverse: true },
        series: [
            { name: '本单位', type: 'bar', barWidth: 10, data: myVal, itemStyle: { color: '#3b82f6', borderRadius: [0,3,3,0] } },
            { name: '全厅均值', type: 'bar', barWidth: 10, data: avgVal, itemStyle: { color: 'rgba(100,116,139,0.4)', borderRadius: [0,3,3,0] } }
        ]
    });

    // TAB1: 超编闲置表格
    var eqItems = [
        {name:'防弹背心', actual:45, std:30, over:15, status:'超编'},
        {name:'手持电台', actual:68, std:50, over:18, status:'超编'},
        {name:'执法记录仪', actual:32, std:35, over:0, status:'正常'},
        {name:'防暴盾牌', actual:20, std:25, over:0, status:'闲置'},
        {name:'警用无人机', actual:8, std:5, over:3, status:'超编'}
    ];
    document.getElementById('uad-eq-table').innerHTML = eqItems.map(function(it) {
        var badgeClass = it.status === '超编' ? 'uad-badge-idle' : it.status === '闲置' ? 'uad-badge-idle' : 'uad-badge-normal';
        return '<tr><td>' + it.name + '</td><td>' + it.actual + '</td><td>' + it.std + '</td><td>' + (it.over > 0 ? '+' + it.over : '-') + '</td><td><span class="uad-badge ' + badgeClass + '">' + it.status + '</span></td></tr>';
    }).join('');

    // TAB2: 应急物资 饼图
    c('chart-uad-emergency-pie', {
        backgroundColor: 'transparent', tooltip: { trigger: 'item', formatter: '{b}: {c}件 ({d}%)' },
        legend: { orient: 'vertical', right: 5, top: 'center', textStyle: { color: tc.txt, fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
        series: [{ type: 'pie', radius: ['40%', '65%'], center: ['32%', '50%'], label: { show: false },
            data: [
                { value: Math.round(emCount*0.30), name: '救生器材', itemStyle: { color: '#3b82f6' } },
                { value: Math.round(emCount*0.25), name: '照明设备', itemStyle: { color: '#06b6d4' } },
                { value: Math.round(emCount*0.20), name: '通讯设备', itemStyle: { color: '#10b981' } },
                { value: Math.round(emCount*0.15), name: '医疗急救', itemStyle: { color: '#fbbf24' } },
                { value: Math.round(emCount*0.10), name: '其他', itemStyle: { color: '#64748b' } }
            ], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
        }]
    });

    // TAB2: 应急物资清单
    var emItems = [
        {name:'救生绳', type:'救生器材', qty:25, expire:'2027-06', status:'正常'},
        {name:'强光手电', type:'照明设备', qty:40, expire:'2026-12', status:'正常'},
        {name:'急救包', type:'医疗急救', qty:20, expire:'2025-08', status:'即将到期'},
        {name:'对讲机(应急)', type:'通讯设备', qty:30, expire:'2028-03', status:'正常'},
        {name:'充气救生艇', type:'救生器材', qty:5, expire:'2027-01', status:'正常'}
    ];
    document.getElementById('uad-em-table').innerHTML = emItems.map(function(it) {
        var bc = it.status === '即将到期' ? 'uad-badge-warn' : 'uad-badge-normal';
        return '<tr><td>' + it.name + '</td><td>' + it.type + '</td><td>' + it.qty + '件</td><td>' + it.expire + '</td><td><span class="uad-badge ' + bc + '">' + it.status + '</span></td></tr>';
    }).join('');

    // TAB3: 被装 饼图
    c('chart-uad-clothing-pie', {
        backgroundColor: 'transparent', tooltip: { trigger: 'item', formatter: '{b}: {c}件 ({d}%)' },
        legend: { orient: 'vertical', right: 5, top: 'center', textStyle: { color: tc.txt, fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
        series: [{ type: 'pie', radius: ['40%', '65%'], center: ['32%', '50%'], label: { show: false },
            data: [
                { value: Math.round(clCount*0.35), name: '警服常服', itemStyle: { color: '#3b82f6' } },
                { value: Math.round(clCount*0.25), name: '作训服', itemStyle: { color: '#06b6d4' } },
                { value: Math.round(clCount*0.15), name: '防寒被装', itemStyle: { color: '#a855f7' } },
                { value: Math.round(clCount*0.12), name: '鞋靴', itemStyle: { color: '#10b981' } },
                { value: Math.round(clCount*0.08), name: '配饰标识', itemStyle: { color: '#fbbf24' } },
                { value: Math.round(clCount*0.05), name: '其他', itemStyle: { color: '#64748b' } }
            ], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
        }]
    });

    // TAB3: 被装库龄 堆叠柱状图
    var clCats = ['警服常服','作训服','防寒被装','鞋靴','配饰标识'];
    c('chart-uad-clothing-age', {
        backgroundColor: 'transparent', tooltip: { trigger: 'axis' },
        legend: { data: ['1年内','1-2年','2-3年','呆滞'], top: 0, textStyle: { color: tc.txt, fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 10, top: 28, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: clCats, axisLine: { lineStyle: { color: tc.axis } }, axisLabel: { color: tc.txt, fontSize: 10 }, axisTick: { show: false } },
        yAxis: { type: 'value', axisLine: { show: false }, splitLine: { lineStyle: { color: tc.gridC, type: 'dashed' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        series: [
            { name: '1年内', type: 'bar', stack: 'age', data: [80,60,40,30,20], itemStyle: { color: '#10b981' }, barWidth: '35%' },
            { name: '1-2年', type: 'bar', stack: 'age', data: [50,40,25,20,15], itemStyle: { color: '#06b6d4' } },
            { name: '2-3年', type: 'bar', stack: 'age', data: [30,20,15,10,8], itemStyle: { color: '#fbbf24' } },
            { name: '呆滞', type: 'bar', stack: 'age', data: [15,10,8,5,3], itemStyle: { color: '#ef4444' } }
        ]
    });

    // TAB3: 呆滞预警
    var stagnant = 5 + (seed % 8);
    document.getElementById('uad-cl-alert').innerHTML = '&#9888; 发现 ' + stagnant + ' 件呆滞被装物资（超2年未领用），建议尽快处置';

    var clWarn = [
        {name:'冬执勤服', qty:15, time:'2.5年', sug:'调拨至新警'},
        {name:'老式作训鞋', qty:23, time:'3年', sug:'报废更新'},
        {name:'旧式臂章', qty:8, time:'2年', sug:'统一回收'}
    ];
    document.getElementById('uad-cl-table').innerHTML = clWarn.map(function(it) {
        return '<tr><td>' + it.name + '</td><td>' + it.qty + '件</td><td>' + it.time + '</td><td>' + it.sug + '</td></tr>';
    }).join('');

    // TAB4: 办公设备 饼图
    c('chart-uad-office-pie', {
        backgroundColor: 'transparent', tooltip: { trigger: 'item', formatter: '{b}: {c}台 ({d}%)' },
        legend: { orient: 'vertical', right: 5, top: 'center', textStyle: { color: tc.txt, fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
        series: [{ type: 'pie', radius: ['40%', '65%'], center: ['32%', '50%'], label: { show: false },
            data: [
                { value: Math.round(ofCount*0.40), name: '台式电脑', itemStyle: { color: '#3b82f6' } },
                { value: Math.round(ofCount*0.20), name: '笔记本电脑', itemStyle: { color: '#06b6d4' } },
                { value: Math.round(ofCount*0.15), name: '打印机', itemStyle: { color: '#10b981' } },
                { value: Math.round(ofCount*0.12), name: '投影仪', itemStyle: { color: '#fbbf24' } },
                { value: Math.round(ofCount*0.13), name: '服务器', itemStyle: { color: '#a855f7' } }
            ], itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
        }]
    });

    // TAB4: 设备库存明细
    var ofItems = [
        {name:'台式电脑', qty: Math.round(ofCount*0.40), val: Math.round(ofCount*0.40)*0.05, pct:'28.3%'},
        {name:'笔记本电脑', qty: Math.round(ofCount*0.20), val: Math.round(ofCount*0.20)*0.07, pct:'14.6%'},
        {name:'打印机', qty: Math.round(ofCount*0.15), val: Math.round(ofCount*0.15)*0.07, pct:'10.4%'},
        {name:'投影仪', qty: Math.round(ofCount*0.12), val: Math.round(ofCount*0.12)*0.2, pct:'11.3%'},
        {name:'服务器', qty: Math.round(ofCount*0.13), val: Math.round(ofCount*0.13)*1.0, pct:'35.4%'}
    ];
    document.getElementById('uad-of-table').innerHTML = ofItems.map(function(it) {
        return '<tr><td>' + it.name + '</td><td>' + it.qty + '台</td><td>' + it.val.toFixed(0) + '万</td><td style="color:#f97316;">' + it.pct + '</td></tr>';
    }).join('');

    // TAB5: 车辆类型分布
    var vTypes = [
        {name:'警车', value: Math.round(vhVal*0.35), color:'#3b82f6'},
        {name:'囚车/特种', value: Math.round(vhVal*0.18), color:'#06b6d4'},
        {name:'摩托车', value: Math.round(vhVal*0.12), color:'#10b981'},
        {name:'运兵车', value: Math.round(vhVal*0.15), color:'#fbbf24'},
        {name:'无人机', value: Math.round(vhVal*0.10), color:'#a855f7'},
        {name:'其他', value: Math.round(vhVal*0.10), color:'#64748b'}
    ];
    document.getElementById('uad-vh-types').innerHTML = vTypes.map(function(vt) {
        return '<div class="uad-vtype-item"><div class="uad-vtype-left"><div class="uad-vtype-dot" style="background:' + vt.color + '"></div><span class="uad-vtype-name">' + vt.name + '</span></div><span class="uad-vtype-value">' + vt.value + '万</span></div>';
    }).join('');

    // TAB5: 车辆清单
    var vhList = [
        {type:'警车', qty:'32辆', val: Math.round(vhVal*0.35), gps:'在线', status:'正常'},
        {type:'囚车', qty:'6辆', val: Math.round(vhVal*0.18), gps:'在线', status:'正常'},
        {type:'摩托车', qty:'18辆', val: Math.round(vhVal*0.12), gps:'—', status:'正常'},
        {type:'运兵车', qty:'4辆', val: Math.round(vhVal*0.15), gps:'在线', status:'维修'}
    ];
    document.getElementById('uad-vh-table').innerHTML = vhList.map(function(v) {
        var gpsColor = v.gps === '在线' ? 'color:#10b981;' : 'color:#64748b;';
        var stBadge = v.status === '正常' ? 'uad-badge-normal' : 'uad-badge-warn';
        return '<tr><td>' + v.type + '</td><td>' + v.qty + '</td><td>' + v.val + '</td><td style="' + gpsColor + '">' + v.gps + '</td><td><span class="uad-badge ' + stBadge + '">' + v.status + '</span></td></tr>';
    }).join('');

    // TAB6: 处置记录
    var dpItems = [
        {date:'2024-01-21', name:'执法记录仪', way:'报废', amt:'22万', reason:'达到使用年限，性能下降', status:'审批中'},
        {date:'2024-01-09', name:'执法记录仪', way:'转让', amt:'46万', reason:'调拨至其他单位使用', status:'已完成'},
        {date:'2024-03-11', name:'执法记录仪', way:'调拨', amt:'40万', reason:'资源优化配置', status:'审批中'},
        {date:'2024-01-16', name:'电脑主机', way:'捐赠', amt:'100万', reason:'支援基层单位', status:'已完成'},
        {date:'2024-02-21', name:'打印机', way:'捐赠', amt:'104万', reason:'支援基层单位', status:'已完成'}
    ];
    document.getElementById('uad-dp-table').innerHTML = dpItems.map(function(d) {
        var wayClass = d.way === '报废' ? 'uad-badge-scrap' : d.way === '转让' ? 'uad-badge-transfer' : d.way === '调拨' ? 'uad-badge-donate' : 'uad-badge-donate';
        var stClass = d.status === '已完成' ? 'uad-badge-done' : 'uad-badge-pending';
        return '<tr><td>' + d.date + '</td><td>' + d.name + '</td><td><span class="uad-badge ' + wayClass + '">' + d.way + '</span></td><td>' + d.amt + '</td><td>' + d.reason + '</td><td><span class="uad-badge ' + stClass + '">' + d.status + '</span></td></tr>';
    }).join('');
}
