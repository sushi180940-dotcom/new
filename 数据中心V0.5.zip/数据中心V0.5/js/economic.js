// ==================== 主屏图表 ====================
function initMainCharts() {
    initChart('incomeStructure', {
        tooltip: { ...commonTooltip, trigger: 'item', formatter: '{b}: {c}亿元 ({d}%)' },
        legend: { orient: 'vertical', right: 8, top: 'center', textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 12, itemHeight: 12, itemGap: 8 },
        series: [{ type: 'pie', radius: ['42%', '68%'], center: ['34%', '50%'], avoidLabelOverlap: true,
            label: { show: true, position: 'inside', fontSize: 11, color: '#fff', fontWeight: 600, formatter: '{d}%' },
            labelLine: { show: false },
            data: [
                { value: 5.89, name: '财政拨款', itemStyle: { color: '#00d4ff' } },
                { value: 1.26, name: '非税收入', itemStyle: { color: '#0ea5e9' } },
                { value: 0.84, name: '上级补助', itemStyle: { color: '#6366f1' } },
                { value: 0.43, name: '其他收入', itemStyle: { color: '#8b5cf6' } }
            ]
        }]
    });

    initChart('incomeTrend', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['财政拨款','政法转移支付','装备建设专项'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}千万' } },
        series: [
            { name: '财政拨款', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [8.2,8.5,9.1,9.8,10.2,10.5], lineStyle: { color: '#00d4ff', width: 2.5 }, itemStyle: { color: '#00d4ff' }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(0,212,255,0.25)'},{offset:1,color:'rgba(0,212,255,0)'}] } } },
            { name: '政法转移支付', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [3.5,3.8,4.2,4.5,4.8,5.1], lineStyle: { color: '#f59e0b', width: 2.5 }, itemStyle: { color: '#f59e0b' } },
            { name: '装备建设专项', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [1.2,1.5,1.8,2.1,2.3,2.6], lineStyle: { color: '#10b981', width: 2.5 }, itemStyle: { color: '#10b981' } }
        ]
    });

    initChart('budgetChange', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 10, top: 20, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['年初预算','追加','追减','调剂','调整预算'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11, interval: 0 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}亿' } },
        series: [{ type: 'bar', barWidth: '48%', data: [
            { value: 7.5, itemStyle: { color: '#0ea5e9' } },
            { value: 1.2, itemStyle: { color: '#10b981' } },
            { value: -0.3, itemStyle: { color: '#ef4444' } },
            { value: 0.05, itemStyle: { color: '#f59e0b' } },
            { value: 8.45, itemStyle: { color: '#00d4ff' } }
        ], label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: function(p) {
            if (p.dataIndex === 1) return '+' + p.value + '亿\n(+16.0%)';
            if (p.dataIndex === 2) return p.value + '亿\n(-4.0%)';
            if (p.dataIndex === 3) return '+' + p.value + '亿\n(+0.7%)';
            return p.value + '亿';
        } } }]
    });

    var fujianUnits = [
        {name:'厅机关',x:300,y:200,value:85.2,status:'normal'},{name:'刑侦总队',x:260,y:240,value:31.2,status:'danger'},
        {name:'交警总队',x:340,y:180,value:72.4,status:'warning'},{name:'治安总队',x:320,y:250,value:68.5,status:'warning'},
        {name:'网安总队',x:280,y:160,value:58.4,status:'warning'},{name:'特警总队',x:360,y:220,value:91.3,status:'normal'},
        {name:'监管总队',x:250,y:200,value:45.6,status:'danger'},{name:'禁毒总队',x:340,y:140,value:78.5,status:'normal'},
        {name:'科信总队',x:290,y:180,value:55.6,status:'warning'},{name:'警务保障部',x:370,y:190,value:76.8,status:'normal'},
        {name:'人事处',x:270,y:140,value:92.1,status:'normal'},{name:'反恐总队',x:330,y:230,value:89.0,status:'normal'},
        {name:'科通处',x:310,y:160,value:62.4,status:'warning'},{name:'法制总队',x:350,y:260,value:48.9,status:'danger'}
    ];
    initChart('fujianMap', {
        tooltip: { ...commonTooltip, trigger: 'item', formatter: function(p) {
            var d = p.data; var sc = d.status==='danger'?'#ef4444':d.status==='warning'?'#f59e0b':'#10b981';
            var st = d.status==='danger'?'严重滞后':d.status==='warning'?'执行偏慢':'正常';
            return '<div style="font-weight:700;color:#00d4ff;margin-bottom:6px;font-size:14px;">' + d.name + '</div><div style="margin-bottom:4px;">预算执行率：<span style="color:' + sc + ';font-weight:700;">' + d.value + '%</span></div><div>状态：<span style="color:' + sc + ';">' + st + '</span></div>';
        }},
        grid: { left: 20, right: 20, top: 20, bottom: 20 }, xAxis: { show: false, min: 200, max: 400 }, yAxis: { show: false, min: 100, max: 300 },
        series: [
            { type: 'effectScatter', symbolSize: function(d) { return Math.max(12, d[2]/4); },
                data: fujianUnits.map(function(u) { return { name: u.name, value: [u.x, u.y, u.value], status: u.status,
                    itemStyle: { color: u.status==='danger'?'#ef4444':u.status==='warning'?'#f59e0b':'#10b981', shadowBlur: 15, shadowColor: u.status==='danger'?'rgba(239,68,68,0.5)':u.status==='warning'?'rgba(245,158,11,0.5)':'rgba(16,185,129,0.5)' } }; }),
                rippleEffect: { brushType: 'stroke', scale: 3, period: 4 }
            },
            { type: 'line', smooth: 0.3, symbol: 'none', lineStyle: { color: 'rgba(0,212,255,0.15)', width: 2 },
                data: [[260,280],[270,290],[300,295],[330,285],[350,270],[370,250],[380,230],[375,200],[360,170],[340,140],[320,125],[300,120],[280,125],[260,140],[245,160],[235,180],[240,200],[250,220],[255,240],[260,260],[260,280]].map(function(p) { return {value: p}; })
            }
        ],
        graphic: fujianUnits.map(function(u) { return { type: 'text', left: ((u.x-200)/200*100)+'%', top: ((u.y-100)/200*100)+'%', style: { text: u.name, fill: 'rgba(226,232,240,0.9)', fontSize: 10, textAlign: 'center', textVerticalAlign: 'top', fontWeight: 500 }, offset: [0, 14] }; })
    });
    // 点击气泡跳转单位详情
    if (charts['fujianMap']) {
        charts['fujianMap'].on('click', function(params) {
            if (params.data && params.data.name) {
                showUnitDetail(params.data.name);
            }
        });
    }

    initChart('purchaseFunnel', {
        tooltip: { ...commonTooltip, trigger: 'item', formatter: '{b}: {c}亿元 ({d}%)' },
        series: [{ type: 'funnel', left: '10%', top: 10, bottom: 10, width: '80%', min: 0, max: 2.5, minSize: '20%', maxSize: '100%', sort: 'descending', gap: 2,
            label: { show: true, position: 'inside', fontSize: 11, color: '#fff', fontWeight: 600, formatter: '{b}\n{c}亿' }, labelLine: { length: 10, lineStyle: { width: 1, type: 'solid' } }, itemStyle: { borderColor: 'rgba(0,0,0,0.3)', borderWidth: 1 },
            data: [
                { value: 2.5, name: '采购预算', itemStyle: { color: '#0ea5e9' } }, { value: 2.1, name: '已立项', itemStyle: { color: '#6366f1' } }, { value: 1.8, name: '已招标', itemStyle: { color: '#8b5cf6' } }, { value: 1.5, name: '已签合同', itemStyle: { color: '#d946ef' } }, { value: 1.2, name: '已支付', itemStyle: { color: '#00d4ff' } }
            ]
        }]
    });

    initChart('expenseStructure', {
        tooltip: { ...commonTooltip, formatter: '{b}: {c}亿元 ({d}%)' },
        series: [{ type: 'treemap', width: '95%', height: '92%', top: '4%', left: '2.5%', roam: false, nodeClick: false, breadcrumb: { show: false },
            label: { show: true, fontSize: 11, color: '#fff', fontWeight: 600, formatter: '{b}\n{c}亿\n({d}%)' }, itemStyle: { borderColor: 'rgba(6,18,37,0.8)', borderWidth: 2, gapWidth: 2 }, levels: [{ itemStyle: { borderWidth: 0, gapWidth: 2 } }],
            data: [
                { name: '人员经费', value: 2.89, itemStyle: { color: '#0ea5e9' } }, { name: '公用经费', value: 1.42, itemStyle: { color: '#6366f1' } }, { name: '项目经费', value: 1.25, itemStyle: { color: '#8b5cf6' } }, { name: '装备购置', value: 0.72, itemStyle: { color: '#d946ef' } }
            ]
        }]
    });

    initChart('sanGong', {
        tooltip: { ...commonTooltip },
        series: [
            { type: 'gauge', center: ['20%','55%'], radius: '72%', startAngle: 200, endAngle: -20, min: 0, max: 100, splitNumber: 5,
                axisLine: { lineStyle: { width: 6, color: [[0.6,'#10b981'],[0.8,'#f59e0b'],[1,'#ef4444']] } }, pointer: { itemStyle: { color: '#00d4ff' }, width: 3 },
                axisTick: { distance: -10, length: 4, lineStyle: { color: '#fff', width: 1 } }, splitLine: { distance: -10, length: 8, lineStyle: { color: '#fff', width: 2 } }, axisLabel: { distance: 4, color: '#64748b', fontSize: 9 },
                detail: { valueAnimation: true, fontSize: 15, color: '#fff', offsetCenter: [0, '60%'], formatter: '{value}%' },
                data: [{ value: 72, name: '总额 426万', title: { offsetCenter: [0, '38%'], fontSize: 10, color: '#94a3b8' } }]
            },
            { type: 'gauge', center: ['50%','55%'], radius: '72%', startAngle: 200, endAngle: -20, min: 0, max: 100, splitNumber: 5,
                axisLine: { lineStyle: { width: 6, color: [[0.6,'#10b981'],[0.8,'#f59e0b'],[1,'#ef4444']] } }, pointer: { itemStyle: { color: '#00d4ff' }, width: 3 },
                axisTick: { distance: -10, length: 4, lineStyle: { color: '#fff', width: 1 } }, splitLine: { distance: -10, length: 8, lineStyle: { color: '#fff', width: 2 } }, axisLabel: { distance: 4, color: '#64748b', fontSize: 9 },
                detail: { valueAnimation: true, fontSize: 15, color: '#fff', offsetCenter: [0, '60%'], formatter: '{value}%' },
                data: [{ value: 85, name: '公车 268万', title: { offsetCenter: [0, '38%'], fontSize: 10, color: '#94a3b8' } }]
            },
            { type: 'gauge', center: ['80%','55%'], radius: '72%', startAngle: 200, endAngle: -20, min: 0, max: 100, splitNumber: 5,
                axisLine: { lineStyle: { width: 6, color: [[0.6,'#10b981'],[0.8,'#f59e0b'],[1,'#ef4444']] } }, pointer: { itemStyle: { color: '#00d4ff' }, width: 3 },
                axisTick: { distance: -10, length: 4, lineStyle: { color: '#fff', width: 1 } }, splitLine: { distance: -10, length: 8, lineStyle: { color: '#fff', width: 2 } }, axisLabel: { distance: 4, color: '#64748b', fontSize: 9 },
                detail: { valueAnimation: true, fontSize: 15, color: '#fff', offsetCenter: [0, '60%'], formatter: '{value}%' },
                data: [{ value: 45, name: '接待 128万', title: { offsetCenter: [0, '38%'], fontSize: 10, color: '#94a3b8' } }]
            }
        ]
    });

    initChart('expenseTrend', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['应急装备','信息化','基建'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}百万' } },
        series: [
            { name: '应急装备', type: 'line', smooth: true, symbol: 'none', data: [120,180,250,320,380,420], lineStyle: { color: '#ef4444', width: 2.5 }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(239,68,68,0.25)'},{offset:1,color:'rgba(239,68,68,0)'}] } } },
            { name: '信息化', type: 'line', smooth: true, symbol: 'none', data: [80,90,110,140,180,220], lineStyle: { color: '#00d4ff', width: 2.5 }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(0,212,255,0.25)'},{offset:1,color:'rgba(0,212,255,0)'}] } } },
            { name: '基建', type: 'line', smooth: true, symbol: 'none', data: [200,220,240,260,280,300], lineStyle: { color: '#10b981', width: 2.5 }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(16,185,129,0.25)'},{offset:1,color:'rgba(16,185,129,0)'}] } } }
        ]
    });
}

// ==================== 收入详情页 ====================
function initIncomeCharts() {
    initChart('incomeUnitRank', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['法制总队','监管总队','科通处','科信总队','禁毒总队','人事处','警保部','网安总队','治安总队','厅机关'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [{ type: 'bar', barWidth: 16, data: [2.1,2.8,3.5,4.2,4.8,5.6,6.2,8.5,12.3,49.9], itemStyle: { color: function(p) { return p.dataIndex > 7 ? '#00d4ff' : '#0ea5e9'; }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }]
    });

    initChart('incomeYoY', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['财政拨款','非税收入','上级补助','装备建设专项','政法转移支付'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11, interval: 0 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [{ type: 'bar', barWidth: 26, data: [5.2,8.6,12.4,18.5,6.8], itemStyle: { color: function(p) { return p.value > 10 ? '#10b981' : '#00d4ff'; }, borderRadius: [4,4,0,0] }, label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '+{c}%' } }]
    });

    initChart('incomeVolatility', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['财政拨款','非税收入','上级补助','装备建设专项','政法转移支付'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11, interval: 0 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        series: [{ type: 'bar', barWidth: 26, data: [0.08,0.15,0.22,0.35,0.12], itemStyle: { color: function(p) { return p.value > 0.2 ? '#f59e0b' : '#00d4ff'; }, borderRadius: [4,4,0,0] }, label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600 } }]
    });

    initChart('incomeRatioTrend', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['财政拨款','政法转移支付','装备建设专项'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [
            { name: '财政拨款', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [70,69,68,70,71,70], lineStyle: { color: '#00d4ff', width: 2.5 }, itemStyle: { color: '#00d4ff' } },
            { name: '政法转移支付', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [15,16,15,14,15,15], lineStyle: { color: '#f59e0b', width: 2.5 }, itemStyle: { color: '#f59e0b' } },
            { name: '装备建设专项', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [5,6,7,8,8,9], lineStyle: { color: '#10b981', width: 2.5 }, itemStyle: { color: '#10b981' } }
        ]
    });

    initChart('budgetYearCompare', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['2022','2023','2024','2025','2026'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}亿' } },
        series: [
            { name: '年初预算', type: 'bar', barWidth: 20, data: [6.2,6.8,7.1,7.5,7.5], itemStyle: { color: '#0ea5e9', borderRadius: [4,4,0,0] } },
            { name: '调整预算', type: 'bar', barWidth: 20, data: [6.5,7.2,7.6,7.8,8.45], itemStyle: { color: '#00d4ff', borderRadius: [4,4,0,0] } }
        ]
    });
}

// ==================== 支出详情页 ====================
function initExpenseCharts() {
    initChart('expenseYoY', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['应急装备','信息化建设','基建','人员经费','公用经费'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11, interval: 0 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [{ type: 'bar', barWidth: 28, data: [25,67,12,3,8], itemStyle: { color: function(p) { return p.value > 20 ? '#ef4444' : p.value > 10 ? '#f59e0b' : '#10b981'; }, borderRadius: [4,4,0,0] }, label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '+{c}%' } }]
    });

    initChart('expenseBudgetRate', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['基建','公用经费','应急装备','信息化','人员经费'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [
            { name: '执行率', type: 'bar', barWidth: 16, data: [38,68.7,72,85,92.1], itemStyle: { color: function(p) { return p.value < 50 ? '#ef4444' : p.value < 75 ? '#f59e0b' : '#10b981'; }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }
        ]
    });

    initChart('expenseRatioTrend', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['应急装备','信息化','基建'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [
            { name: '应急装备', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [8,10,12,14,15,16], lineStyle: { color: '#ef4444', width: 2.5 }, itemStyle: { color: '#ef4444' } },
            { name: '信息化', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [5,6,7,8,10,12], lineStyle: { color: '#00d4ff', width: 2.5 }, itemStyle: { color: '#00d4ff' } },
            { name: '基建', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [18,17,17,16,16,15], lineStyle: { color: '#10b981', width: 2.5 }, itemStyle: { color: '#10b981' } }
        ]
    });

    initChart('unitExecRank', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['刑侦总队','监管总队','法制总队','科信总队','科通处','网安总队','治安总队','禁毒总队','特警总队','厅机关'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [{ type: 'bar', barWidth: 16, data: [31.2,45.6,48.9,55.6,62.4,58.4,68.5,78.5,91.3,92.1], itemStyle: { color: function(p) { return p.value < 50 ? '#ef4444' : p.value < 70 ? '#f59e0b' : '#10b981'; }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }]
    });

    initChart('subjectExecCompare', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['人员经费','公用经费','项目经费','装备购置'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [
            { name: '人员经费', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [15,28,42,55,72,85.2], lineStyle: { color: '#10b981', width: 2.5 }, itemStyle: { color: '#10b981' } },
            { name: '公用经费', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [12,22,35,48,58,68.7], lineStyle: { color: '#f59e0b', width: 2.5 }, itemStyle: { color: '#f59e0b' } },
            { name: '项目经费', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [5,12,20,30,42,52.3], lineStyle: { color: '#0ea5e9', width: 2.5 }, itemStyle: { color: '#0ea5e9' } },
            { name: '装备购置', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [3,8,15,25,35,45.8], lineStyle: { color: '#ef4444', width: 2.5 }, itemStyle: { color: '#ef4444' } }
        ]
    });
}

// ==================== 三公经费详情页 ====================
function initSangongCharts() {
    initChart('sgYearTrend', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 32, bottom: 20, containLabel: true },
        legend: { data: ['支出总额','预算额度'], top: 0, textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 14, itemHeight: 3 },
        xAxis: { type: 'category', data: ['2022','2023','2024','2025','2026(预测)'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}万' } },
        series: [
            { name: '支出总额', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: [580,540,510,486,426], lineStyle: { color: '#00d4ff', width: 3 }, itemStyle: { color: '#00d4ff' }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(0,212,255,0.25)'},{offset:1,color:'rgba(0,212,255,0)'}] } } },
            { name: '预算额度', type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: [650,620,600,580,580], lineStyle: { color: '#f59e0b', width: 2, type: 'dashed' }, itemStyle: { color: '#f59e0b' } }
        ]
    });

    initChart('sgItemRatio', {
        tooltip: { ...commonTooltip, trigger: 'item', formatter: '{b}: {c}万元 ({d}%)' },
        legend: { orient: 'vertical', right: 10, top: 'center', textStyle: { color: '#94a3b8', fontSize: 11 }, itemWidth: 12, itemHeight: 12, itemGap: 8 },
        series: [{ type: 'pie', radius: ['42%', '68%'], center: ['36%', '50%'], avoidLabelOverlap: true,
            label: { show: true, position: 'inside', fontSize: 11, color: '#fff', fontWeight: 600, formatter: '{d}%' },
            labelLine: { show: false },
            data: [
                { value: 267.5, name: '公务用车', itemStyle: { color: '#00d4ff' } },
                { value: 127.8, name: '公务接待', itemStyle: { color: '#0ea5e9' } },
                { value: 30.7, name: '因公出国', itemStyle: { color: '#6366f1' } }
            ]
        }]
    });

    initChart('sgItemExec', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['因公出国','公务接待','公务用车','三公总额'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [
            { name: '执行率', type: 'bar', barWidth: 20, data: [45,62,85,73.4], itemStyle: { color: function(p) { return p.value < 60 ? '#10b981' : p.value < 80 ? '#00d4ff' : '#f59e0b'; }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }
        ]
    });

    initChart('sgReduceEffect', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['2022','2023','2024','2025','2026'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [{ type: 'bar', barWidth: 32, data: [-5.2,-6.9,-5.6,-4.7,-12.4], itemStyle: { color: '#10b981', borderRadius: [4,4,0,0] }, label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }]
    });
}

// ==================== 采购合同详情页 ====================
function initPurchaseCharts() {
    initChart('contractPayRate', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['网络设备','警用车辆','视频监控','应急装备','办公设备','信息系统'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [{ type: 'bar', barWidth: 16, data: [95,88,72,65,58,45], itemStyle: { color: function(p) { return p.value < 60 ? '#ef4444' : p.value < 80 ? '#f59e0b' : '#10b981'; }, borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }]
    });

    initChart('contractAcceptRate', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 10, right: 20, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['信息系统','办公设备','应急装备','视频监控','警用车辆','网络设备'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 11 } },
        series: [
            { name: '已验收', type: 'bar', stack: 'total', barWidth: 18, data: [92,85,78,65,55,48], itemStyle: { color: '#10b981', borderRadius: [0,4,4,0] } },
            { name: '待验收', type: 'bar', stack: 'total', barWidth: 18, data: [8,15,22,35,45,52], itemStyle: { color: '#f59e0b' } }
        ]
    });

    initChart('overdueRate', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [{ type: 'line', smooth: true, symbol: 'circle', symbolSize: 6, data: [2.1,1.8,2.5,3.2,4.1,5.8], lineStyle: { color: '#ef4444', width: 3 }, itemStyle: { color: '#ef4444' }, areaStyle: { color: { type: 'linear', x:0,y:0,x2:0,y2:1, colorStops:[{offset:0,color:'rgba(239,68,68,0.25)'},{offset:1,color:'rgba(239,68,68,0)'}] } }, markLine: { data: [{ yAxis: 3, name: '警戒线', lineStyle: { color: '#f59e0b', type: 'dashed', width: 2 } }], label: { formatter: '警戒线 3%', color: '#f59e0b', fontSize: 11 } } }]
    });

    initChart('warrantyRate', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        grid: { left: 10, right: 10, top: 12, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['1月','2月','3月','4月','5月','6月'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 11 } },
        yAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 11, formatter: '{value}%' } },
        series: [{ type: 'bar', barWidth: 26, data: [3.2,2.8,4.1,5.5,6.8,8.2], itemStyle: { color: function(p) { return p.value > 5 ? '#ef4444' : '#f59e0b'; }, borderRadius: [4,4,0,0] }, label: { show: true, position: 'top', color: '#e2e8f0', fontSize: 11, fontWeight: 600, formatter: '{c}%' } }]
    });
}

// ==================== 单位经济运行详情图表 ====================
function initUnitDetailCharts() {
    var unit = window.currentUnitName || '刑侦总队';
    var seed = unit.charCodeAt(0) + unit.charCodeAt(unit.length - 1);
    var r = function(min, max) { return min + (seed % (max - min + 1)); };
    var rf = function(min, max) { return (min + (seed % 1000) / 1000 * (max - min)).toFixed(1); };

    // (1) 预算执行进度情况 - 水平条形进度图
    initChart('chart-unit-progress', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' },
            formatter: function(p) {
                var d = p[0];
                return d.name + '<br/>预算: ' + d.data.budget + '万<br/>执行: ' + d.data.actual + '万<br/>执行率: <span style="color:#00d4ff;font-weight:700;">' + d.data.rate + '%</span>';
            }
        },
        grid: { left: 10, right: 80, top: 10, bottom: 10, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10, formatter: '{value}%' } },
        yAxis: { type: 'category', data: ['装备购置','项目支出','公用经费','人员经费'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 10 }, inverse: true },
        series: [{
            type: 'bar', barWidth: 18,
            data: [
                { value: 45 + (seed % 40), budget: 1200, actual: 540 + (seed % 480), rate: (45 + (seed % 40)), itemStyle: { color: new echarts.graphic.LinearGradient(0,0,1,0,[{offset:0,color:'#ef4444'},{offset:1,color:'#f87171'}]), borderRadius: [0,4,4,0] } },
                { value: 55 + (seed % 35), budget: 800, actual: 440 + (seed % 280), rate: (55 + (seed % 35)), itemStyle: { color: new echarts.graphic.LinearGradient(0,0,1,0,[{offset:0,color:'#f59e0b'},{offset:1,color:'#fbbf24'}]), borderRadius: [0,4,4,0] } },
                { value: 65 + (seed % 25), budget: 600, actual: 390 + (seed % 150), rate: (65 + (seed % 25)), itemStyle: { color: new echarts.graphic.LinearGradient(0,0,1,0,[{offset:0,color:'#0ea5e9'},{offset:1,color:'#00d4ff'}]), borderRadius: [0,4,4,0] } },
                { value: 80 + (seed % 15), budget: 900, actual: 720 + (seed % 135), rate: (80 + (seed % 15)), itemStyle: { color: new echarts.graphic.LinearGradient(0,0,1,0,[{offset:0,color:'#10b981'},{offset:1,color:'#34d399'}]), borderRadius: [0,4,4,0] } }
            ],
            label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 10, fontWeight: 600, formatter: function(p) { return p.data.rate + '%'; } }
        }]
    });

    // (2) 预算与决算对比 - 分组柱状图
    initChart('chart-unit-budgetvsfinal', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: { data: ['预算数','决算数'], top: 0, textStyle: { color: '#94a3b8', fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 10, top: 28, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['2021','2022','2023','2024','2025'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        yAxis: { type: 'value', name: '万元', nameTextStyle: { color: '#64748b', fontSize: 9 }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        series: [
            { name: '预算数', type: 'bar', barWidth: '30%', data: [3200+(seed%500), 3500+(seed%400), 3800+(seed%600), 3600+(seed%300), 4000+(seed%500)], itemStyle: { color: '#0ea5e9', borderRadius: [4,4,0,0] } },
            { name: '决算数', type: 'bar', barWidth: '30%', data: [3100+(seed%600), 3400+(seed%500), 3950+(seed%400), 3550+(seed%400), 4100+(seed%300)], itemStyle: { color: '#00d4ff', borderRadius: [4,4,0,0] } }
        ]
    });

    // (3) 项目运行情况 - 项目进度甘特图样式
    var projNames = ['智慧警务平台','视频监控升级','指挥中心改造','警用装备采购','信息化二期','训练基地建设','车辆更新','办公场所维修'];
    var projData = [];
    for (var i = 0; i < 6; i++) {
        var progress = 20 + ((seed + i * 17) % 75);
        var status = progress >= 80 ? '正常' : progress >= 50 ? '偏慢' : '滞后';
        var color = progress >= 80 ? '#10b981' : progress >= 50 ? '#f59e0b' : '#ef4444';
        projData.push({ name: projNames[i], value: progress, status: status, itemStyle: { color: color, borderRadius: [0,4,4,0] } });
    }
    initChart('chart-unit-projects', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' },
            formatter: function(p) {
                var d = p[0];
                return d.name + '<br/>进度: <span style="color:#00d4ff;font-weight:700;">' + d.value + '%</span><br/>状态: ' + d.data.status;
            }
        },
        grid: { left: 10, right: 60, top: 5, bottom: 5, containLabel: true },
        xAxis: { type: 'value', max: 100, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10, formatter: '{value}%' } },
        yAxis: { type: 'category', data: projData.map(function(d) { return d.name; }), axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 9 }, inverse: true },
        series: [{
            type: 'bar', barWidth: 14, data: projData,
            label: { show: true, position: 'right', color: '#e2e8f0', fontSize: 9, formatter: function(p) { return p.value + '% ' + p.data.status; } }
        }]
    });

    // (4) 不同类型经费占比 - 环形图
    initChart('chart-unit-fundtype', {
        tooltip: { ...commonTooltip, trigger: 'item', formatter: '{b}: {c}万 ({d}%)' },
        legend: { orient: 'vertical', right: 5, top: 'center', textStyle: { color: '#94a3b8', fontSize: 9 }, itemWidth: 8, itemHeight: 8 },
        series: [{
            type: 'pie', radius: ['40%', '65%'], center: ['35%', '50%'],
            label: { show: true, color: '#94a3b8', fontSize: 9, formatter: '{b}\n{d}%' },
            labelLine: { lineStyle: { color: 'rgba(148,163,184,0.3)' } },
            data: [
                { value: 900 + (seed % 300), name: '人员经费', itemStyle: { color: '#00d4ff' } },
                { value: 600 + (seed % 200), name: '公用经费', itemStyle: { color: '#0ea5e9' } },
                { value: 800 + (seed % 250), name: '项目支出', itemStyle: { color: '#6366f1' } },
                { value: 400 + (seed % 150), name: '装备购置', itemStyle: { color: '#8b5cf6' } },
                { value: 200 + (seed % 100), name: '其他', itemStyle: { color: '#64748b' } }
            ],
            itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
        }],
        graphic: [
            { type: 'text', left: '26%', top: '42%', style: { text: '合计', fill: '#64748b', fontSize: 10 } },
            { type: 'text', left: '22%', top: '52%', style: { text: ((2900 + seed % 1000) / 10000).toFixed(2) + '亿', fill: '#00d4ff', fontSize: 14, fontWeight: 'bold' } }
        ]
    });

    // (5) 各经费历年趋势 - 多线折线图
    initChart('chart-unit-yearly', {
        tooltip: { ...commonTooltip, trigger: 'axis' },
        legend: { data: ['人员经费','公用经费','项目支出','装备购置'], top: 0, textStyle: { color: '#94a3b8', fontSize: 10 }, itemWidth: 12, itemHeight: 3 },
        grid: { left: 10, right: 10, top: 32, bottom: 15, containLabel: true },
        xAxis: { type: 'category', data: ['2021','2022','2023','2024','2025'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        yAxis: { type: 'value', name: '万元', nameTextStyle: { color: '#64748b', fontSize: 9 }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        series: [
            { name: '人员经费', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [700,750,800,850,900+(seed%300)], lineStyle: { color: '#00d4ff', width: 2 }, itemStyle: { color: '#00d4ff' } },
            { name: '公用经费', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [450,480,520,550,600+(seed%200)], lineStyle: { color: '#f59e0b', width: 2 }, itemStyle: { color: '#f59e0b' } },
            { name: '项目支出', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [550,600,680,750,800+(seed%250)], lineStyle: { color: '#10b981', width: 2 }, itemStyle: { color: '#10b981' } },
            { name: '装备购置', type: 'line', smooth: true, symbol: 'circle', symbolSize: 5, data: [300,320,350,380,400+(seed%150)], lineStyle: { color: '#8b5cf6', width: 2 }, itemStyle: { color: '#8b5cf6' } }
        ]
    });

    // (6) 各部门预算经费占比及变动 - 堆叠柱状图
    initChart('chart-unit-deptpct', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: { data: ['2024年','2025年'], top: 0, textStyle: { color: '#94a3b8', fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 10, top: 28, bottom: 20, containLabel: true },
        xAxis: { type: 'category', data: ['办公室','刑警支队','交警支队','治安支队','科信支队','后勤处'], axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#64748b', fontSize: 9, rotate: 15 }, axisTick: { show: false } },
        yAxis: { type: 'value', name: '万元', nameTextStyle: { color: '#64748b', fontSize: 9 }, splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        series: [
            { name: '2024年', type: 'bar', barWidth: '35%', data: [400,350,380,320,280,250].map(function(v) { return v + (seed % 50); }), itemStyle: { color: 'rgba(14,165,233,0.5)', borderRadius: [4,4,0,0] } },
            { name: '2025年', type: 'bar', barWidth: '35%', data: [420,370,400,340,300,260].map(function(v) { return v + (seed % 60); }), itemStyle: { color: '#00d4ff', borderRadius: [4,4,0,0] } }
        ]
    });

    // (7) 各部门运行经费横向对比 - 横向条形图
    var depts = ['办公室','后勤处','科信支队','治安支队','刑警支队','交警支队'];
    var budgets = [420,260,300,340,370,400].map(function(v) { return v + (seed % 80); });
    var actuals = budgets.map(function(v) { return Math.round(v * (0.6 + (seed % 30) / 100)); });
    initChart('chart-unit-deptcompare', {
        tooltip: { ...commonTooltip, trigger: 'axis', axisPointer: { type: 'shadow' },
            formatter: function(params) {
                var html = '<div style="font-weight:700;margin-bottom:4px;">' + params[0].axisValue + '</div>';
                params.forEach(function(p) {
                    html += '<div style="display:flex;justify-content:space-between;gap:16px;margin:2px 0;"><span style="color:' + p.color + '">&#9679; ' + p.seriesName + '</span><span style="font-weight:600;">' + p.value + '万</span></div>';
                });
                return html;
            }
        },
        legend: { data: ['预算','执行'], top: 0, textStyle: { color: '#94a3b8', fontSize: 10 }, itemWidth: 10, itemHeight: 6 },
        grid: { left: 10, right: 20, top: 28, bottom: 10, containLabel: true },
        xAxis: { type: 'value', splitLine: { lineStyle: { color: 'rgba(255,255,255,0.05)' } }, axisLabel: { color: '#64748b', fontSize: 10 } },
        yAxis: { type: 'category', data: depts, axisLine: { lineStyle: { color: 'rgba(255,255,255,0.1)' } }, axisLabel: { color: '#94a3b8', fontSize: 10 }, inverse: true },
        series: [
            { name: '预算', type: 'bar', barWidth: 12, data: budgets, itemStyle: { color: 'rgba(0,212,255,0.4)', borderRadius: [0,4,4,0] } },
            { name: '执行', type: 'bar', barWidth: 12, data: actuals, itemStyle: { color: '#00d4ff', borderRadius: [0,4,4,0] }, label: { show: true, position: 'right', color: '#94a3b8', fontSize: 9, formatter: function(p) {
                var idx = p.dataIndex;
                var rate = (actuals[idx] / budgets[idx] * 100).toFixed(0);
                return rate + '%';
            } } }
        ]
    });
}
