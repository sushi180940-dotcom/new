// ==================== 财务全景图表 ====================
var financialCharts = {};
var financialChartsInited = false;
var currentStructureTab = 0;
var finHeatmapMode = 'current';

function initFinancialCharts() {
    var fcolors = {
        blue: '#409eff', cyan: '#00d4ff', green: '#67c23a',
        yellow: '#e6a23c', red: '#f56c6c', purple: '#a855f7',
        orange: '#ff9f43', pink: '#ff6b9d', teal: '#1dd1a1'
    };
    var fTextColor = '#8b9dc3';
    var fAxisColor = 'rgba(139, 157, 195, 0.2)';

    // 1. 预决算对比瀑布图
    financialCharts.budget = echarts.init(document.getElementById('chart-budget'));
    var budgetData = {
        categories: ['财政拨款', '非税收入', '其他收入', '人员经费', '公用经费', '项目支出', '装备购置'],
        budget: [8500, 2100, 980, 4200, 1800, 3500, 3080],
        actual: [8320, 1956, 1115, 4450, 1920, 3680, 3341],
        diff: [-180, -144, 135, 250, 120, 180, 261]
    };
    financialCharts.budget.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: function(params) {
                var html = '<div style="font-weight:700;margin-bottom:8px;">' + params[0].name + '</div>';
                params.forEach(function(p) {
                    var val = p.value > 0 && p.seriesName === '差异额' ? '+' + p.value : p.value;
                    html += '<div style="display:flex;justify-content:space-between;gap:20px;margin:4px 0;">' +
                            '<span style="color:' + p.color + '">&#9679; ' + p.seriesName + '</span>' +
                            '<span style="font-weight:600;">' + val + '万</span></div>';
                });
                return html;
            }
        },
        legend: {
            data: ['预算数', '决算数', '差异额'],
            top: 0, right: 0,
            textStyle: { color: fTextColor, fontSize: 11 },
            itemWidth: 14, itemHeight: 8
        },
        grid: { left: 50, right: 20, top: 35, bottom: 25 },
        xAxis: {
            type: 'category',
            data: budgetData.categories,
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 11, rotate: 20 },
            axisTick: { show: false }
        },
        yAxis: {
            type: 'value',
            name: '万元',
            nameTextStyle: { color: fTextColor, fontSize: 11 },
            axisLine: { show: false },
            axisLabel: { color: fTextColor, fontSize: 11 },
            splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } }
        },
        series: [
            {
                name: '预算数',
                type: 'bar',
                data: budgetData.budget,
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: fcolors.blue },
                        { offset: 1, color: 'rgba(64,158,255,0.2)' }
                    ]),
                    borderRadius: [4, 4, 0, 0]
                },
                barWidth: '22%',
                animationDelay: function(idx) { return idx * 100; }
            },
            {
                name: '决算数',
                type: 'bar',
                data: budgetData.actual,
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: fcolors.cyan },
                        { offset: 1, color: 'rgba(0,212,255,0.2)' }
                    ]),
                    borderRadius: [4, 4, 0, 0]
                },
                barWidth: '22%',
                animationDelay: function(idx) { return idx * 100 + 50; }
            },
            {
                name: '差异额',
                type: 'bar',
                data: budgetData.diff,
                itemStyle: {
                    color: function(params) {
                        return params.value >= 0 ?
                            new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: fcolors.red }, { offset: 1, color: 'rgba(245,108,108,0.2)' }
                            ]) :
                            new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                                { offset: 0, color: 'rgba(103,194,58,0.2)' }, { offset: 1, color: fcolors.green }
                            ]);
                    },
                    borderRadius: function(params) { return params.value >= 0 ? [4, 4, 0, 0] : [0, 0, 4, 4]; }
                },
                barWidth: '22%',
                animationDelay: function(idx) { return idx * 100 + 100; }
            }
        ]
    });

    // 2. 结构偏离度 Tab切换
    financialCharts.structure = echarts.init(document.getElementById('chart-structure'));

    var structureOption0 = {
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'item',
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: '{b}: {c}万 ({d}%)'
        },
        legend: {
            orient: 'vertical',
            right: 5,
            top: 'center',
            textStyle: { color: fTextColor, fontSize: 10 },
            itemWidth: 10, itemHeight: 10,
            data: ['财政拨款', '非税收入', '其他收入', '人员经费', '公用经费', '项目支出']
        },
        series: [
            {
                name: '预算结构',
                type: 'pie',
                radius: ['28%', '44%'],
                center: ['32%', '50%'],
                label: { show: false },
                labelLine: { show: false },
                data: [
                    { value: 8500, name: '财政拨款', itemStyle: { color: fcolors.blue } },
                    { value: 2100, name: '非税收入', itemStyle: { color: fcolors.cyan } },
                    { value: 980, name: '其他收入', itemStyle: { color: fcolors.green } }
                ],
                itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
            },
            {
                name: '决算结构',
                type: 'pie',
                radius: ['50%', '68%'],
                center: ['32%', '50%'],
                label: {
                    show: true,
                    position: 'outside',
                    formatter: '{b}\n{d}%',
                    color: fTextColor,
                    fontSize: 10
                },
                labelLine: { lineStyle: { color: fAxisColor } },
                data: [
                    { value: 8320, name: '财政拨款', itemStyle: { color: fcolors.blue } },
                    { value: 1956, name: '非税收入', itemStyle: { color: fcolors.cyan } },
                    { value: 1115, name: '其他收入', itemStyle: { color: fcolors.green } },
                    { value: 4450, name: '人员经费', itemStyle: { color: fcolors.yellow } },
                    { value: 1920, name: '公用经费', itemStyle: { color: fcolors.orange } },
                    { value: 7021, name: '项目支出', itemStyle: { color: fcolors.red } }
                ],
                itemStyle: { borderRadius: 4, borderColor: '#0a0e1a', borderWidth: 2 }
            }
        ],
        graphic: [
            {
                type: 'text',
                left: '25%', top: '46%',
                style: { text: '预算', fill: fTextColor, fontSize: 12, fontWeight: 'bold' }
            },
            {
                type: 'text',
                left: '23%', top: '54%',
                style: { text: '结构', fill: fTextColor, fontSize: 12, fontWeight: 'bold' }
            }
        ]
    };

    var units = ['厅机关', '刑警总队', '交警总队', '治安总队', '网安总队', '特警总队', '监管总队', '禁毒总队'];
    var structureOption1 = {
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'shadow' },
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: function(params) {
                var html = '<div style="font-weight:700;margin-bottom:6px;">' + params[0].axisValue + '</div>';
                params.forEach(function(p) {
                    html += '<div style="display:flex;justify-content:space-between;gap:20px;margin:3px 0;">' +
                            '<span style="color:' + p.color + '">&#9679; ' + p.seriesName + '</span>' +
                            '<span style="font-weight:600;">' + p.value + '%</span></div>';
                });
                return html;
            }
        },
        legend: {
            data: ['人员经费(预算)', '人员经费(决算)', '公用经费(预算)', '公用经费(决算)', '项目支出(预算)', '项目支出(决算)'],
            top: 0,
            textStyle: { color: fTextColor, fontSize: 9 },
            itemWidth: 10, itemHeight: 6
        },
        grid: { left: 60, right: 20, top: 40, bottom: 20 },
        xAxis: {
            type: 'value',
            name: '占比%',
            nameTextStyle: { color: fTextColor, fontSize: 10 },
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10 },
            splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } }
        },
        yAxis: {
            type: 'category',
            data: units,
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10 },
            axisTick: { show: false }
        },
        series: [
            {
                name: '人员经费(预算)', type: 'bar', stack: 'budget',
                data: [42, 38, 35, 40, 36, 39, 41, 37],
                itemStyle: { color: 'rgba(64,158,255,0.4)' },
                barWidth: '35%'
            },
            {
                name: '公用经费(预算)', type: 'bar', stack: 'budget',
                data: [18, 16, 15, 17, 14, 16, 15, 16],
                itemStyle: { color: 'rgba(0,212,255,0.4)' }
            },
            {
                name: '项目支出(预算)', type: 'bar', stack: 'budget',
                data: [40, 46, 50, 43, 50, 45, 44, 47],
                itemStyle: { color: 'rgba(103,194,58,0.4)' }
            },
            {
                name: '人员经费(决算)', type: 'bar', stack: 'actual',
                data: [45, 41, 38, 43, 39, 42, 44, 40],
                itemStyle: { color: fcolors.blue },
                barWidth: '35%'
            },
            {
                name: '公用经费(决算)', type: 'bar', stack: 'actual',
                data: [19, 17, 16, 18, 15, 17, 16, 17],
                itemStyle: { color: fcolors.cyan }
            },
            {
                name: '项目支出(决算)', type: 'bar', stack: 'actual',
                data: [36, 42, 46, 39, 46, 41, 40, 43],
                itemStyle: { color: fcolors.green }
            }
        ]
    };

    financialCharts.structure.setOption(structureOption0);
    financialCharts._structureOption0 = structureOption0;
    financialCharts._structureOption1 = structureOption1;

    // 3. 差异归因帕累托图
    financialCharts.pareto = echarts.init(document.getElementById('chart-pareto'));
    var paretoData = [
        { name: '装备购置', diff: 261, reason: '警用无人机采购追加及应急通信设备升级' },
        { name: '人员经费', diff: 250, reason: '新招录民警工资补发及绩效奖金调整' },
        { name: '项目支出', diff: 180, reason: '智慧警务平台二期建设进度超前' },
        { name: '公用经费', diff: 120, reason: '办公场地租赁费上涨及能耗增加' },
        { name: '其他收入', diff: 135, reason: '资产处置收益增加' },
        { name: '非税收入', diff: -144, reason: '罚没收入减少' },
        { name: '财政拨款', diff: -180, reason: '中央转移支付到位延迟' },
        { name: '培训费', diff: 89, reason: '实战化训练频次增加' },
        { name: '差旅费', diff: 65, reason: '跨区域专案侦办任务增多' },
        { name: '维修费', diff: 42, reason: '老旧车辆集中维修' }
    ];
    var cumulative = 0;
    var totalDiff = paretoData.reduce(function(sum, d) { return sum + Math.abs(d.diff); }, 0);
    var sortedData = paretoData.slice().sort(function(a, b) { return Math.abs(b.diff) - Math.abs(a.diff); });
    var barData = sortedData.map(function(d) { return Math.abs(d.diff); });
    var lineData = sortedData.map(function(d) {
        cumulative += Math.abs(d.diff);
        return (cumulative / totalDiff * 100).toFixed(1);
    });

    financialCharts.pareto.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            axisPointer: { type: 'cross' },
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: function(params) {
                var idx = params[0].dataIndex;
                var item = sortedData[idx];
                return '<div style="font-weight:700;margin-bottom:6px;">' + item.name + '</div>' +
                       '<div style="color:' + fcolors.red + '">差异额: ' + item.diff + '万</div>' +
                       '<div style="color:' + fcolors.cyan + '">累计占比: ' + lineData[idx] + '%</div>';
            }
        },
        grid: { left: 50, right: 50, top: 20, bottom: 30 },
        xAxis: {
            type: 'category',
            data: sortedData.map(function(d) { return d.name; }),
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10, rotate: 30 },
            axisTick: { show: false }
        },
        yAxis: [
            {
                type: 'value',
                name: '差异额(万)',
                nameTextStyle: { color: fTextColor, fontSize: 10 },
                axisLine: { show: false },
                axisLabel: { color: fTextColor, fontSize: 10 },
                splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } }
            },
            {
                type: 'value',
                name: '累计%',
                nameTextStyle: { color: fTextColor, fontSize: 10 },
                axisLine: { show: false },
                axisLabel: { color: fTextColor, fontSize: 10, formatter: '{value}%' },
                splitLine: { show: false },
                max: 100
            }
        ],
        series: [
            {
                name: '差异额',
                type: 'bar',
                data: barData,
                itemStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: fcolors.red },
                        { offset: 1, color: 'rgba(245,108,108,0.3)' }
                    ]),
                    borderRadius: [4, 4, 0, 0]
                },
                barWidth: '45%',
                animationDelay: function(idx) { return idx * 80; }
            },
            {
                name: '累计占比',
                type: 'line',
                yAxisIndex: 1,
                data: lineData,
                smooth: true,
                symbol: 'circle',
                symbolSize: 6,
                lineStyle: { color: fcolors.cyan, width: 2 },
                itemStyle: { color: fcolors.cyan, borderColor: '#fff', borderWidth: 1 },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgba(0,212,255,0.2)' },
                        { offset: 1, color: 'rgba(0,212,255,0)' }
                    ])
                }
            }
        ]
    });
    financialCharts._paretoData = sortedData;

    financialCharts.pareto.on('click', function(params) {
        showParetoDetail(financialCharts._paretoData[params.dataIndex]);
    });

    // 4. 流动性监测 + 去年对比
    financialCharts.liquidity = echarts.init(document.getElementById('chart-liquidity'));
    financialCharts.liquidity.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: function(params) {
                var html = '<div style="font-weight:700;margin-bottom:6px;">' + params[0].axisValue + '</div>';
                params.forEach(function(p) {
                    var color = p.seriesName.indexOf('去年') >= 0 ? '#8b9dc3' : p.color;
                    html += '<div style="display:flex;justify-content:space-between;gap:20px;margin:3px 0;">' +
                            '<span style="color:' + color + '">&#9679; ' + p.seriesName + '</span>' +
                            '<span style="font-weight:600;">' + p.value + '%</span></div>';
                });
                return html;
            }
        },
        legend: {
            data: ['流动比率(今年)', '流动比率(去年)', '速动比率(今年)', '速动比率(去年)'],
            top: 0,
            textStyle: { color: fTextColor, fontSize: 10 },
            itemWidth: 12, itemHeight: 6
        },
        grid: { left: 50, right: 30, top: 35, bottom: 25 },
        xAxis: {
            type: 'category',
            data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10 },
            axisTick: { show: false }
        },
        yAxis: {
            type: 'value',
            name: '比率%',
            nameTextStyle: { color: fTextColor, fontSize: 10 },
            axisLine: { show: false },
            axisLabel: { color: fTextColor, fontSize: 10 },
            splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } }
        },
        series: [
            {
                name: '流动比率(今年)', type: 'line',
                data: [165, 158, 172, 168, 175, 180, 178, 185, 182, 188, 192, 195],
                smooth: true,
                symbol: 'circle', symbolSize: 5,
                lineStyle: { color: fcolors.blue, width: 2 },
                itemStyle: { color: fcolors.blue },
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        { offset: 0, color: 'rgba(64,158,255,0.25)' },
                        { offset: 1, color: 'rgba(64,158,255,0)' }
                    ])
                }
            },
            {
                name: '流动比率(去年)', type: 'line',
                data: [155, 150, 162, 158, 165, 170, 168, 175, 172, 178, 182, 185],
                smooth: true,
                symbol: 'circle', symbolSize: 4,
                lineStyle: { color: 'rgba(139,157,195,0.5)', width: 2, type: 'dashed' },
                itemStyle: { color: 'rgba(139,157,195,0.5)' }
            },
            {
                name: '速动比率(今年)', type: 'line',
                data: [145, 138, 152, 148, 155, 160, 158, 165, 162, 168, 172, 175],
                smooth: true,
                symbol: 'diamond', symbolSize: 5,
                lineStyle: { color: fcolors.cyan, width: 2 },
                itemStyle: { color: fcolors.cyan }
            },
            {
                name: '速动比率(去年)', type: 'line',
                data: [135, 130, 142, 138, 145, 150, 148, 155, 152, 158, 162, 165],
                smooth: true,
                symbol: 'diamond', symbolSize: 4,
                lineStyle: { color: 'rgba(139,157,195,0.4)', width: 2, type: 'dashed' },
                itemStyle: { color: 'rgba(139,157,195,0.4)' }
            }
        ]
    });

    // 5. 固定资产成新率热力图 + 同比切换
    financialCharts.assetHeat = echarts.init(document.getElementById('chart-asset-heat'));
    var assetTypes = ['房屋', '车辆', '专用设备', '通用设备', '办公家具', '警用装备'];
    var heatUnits = ['厅机关', '刑警总队', '交警总队', '治安总队', '网安总队', '特警总队', '监管总队', '禁毒总队'];
    var currentValues = [
        [72, 65, 58, 45, 82, 78], [68, 55, 62, 50, 75, 70], [70, 48, 55, 42, 80, 72],
        [75, 60, 68, 55, 85, 80], [65, 52, 60, 48, 70, 65], [80, 70, 75, 60, 88, 85],
        [60, 45, 50, 40, 65, 60], [73, 58, 65, 52, 78, 75]
    ];
    var lastYearValues = [
        [75, 68, 62, 48, 85, 80], [72, 60, 65, 53, 78, 73], [74, 52, 58, 45, 83, 75],
        [78, 64, 72, 58, 88, 83], [68, 56, 63, 50, 73, 68], [83, 74, 78, 63, 90, 87],
        [64, 50, 55, 44, 68, 63], [76, 62, 68, 55, 81, 78]
    ];

    function getHeatmapOption(mode) {
        var isYoy = mode === 'yoy';
        var heatData = [];
        for (var i = 0; i < heatUnits.length; i++) {
            for (var j = 0; j < assetTypes.length; j++) {
                var yoy = currentValues[i][j] - lastYearValues[i][j];
                heatData.push([j, i, isYoy ? yoy : currentValues[i][j]]);
            }
        }
        return {
            backgroundColor: 'transparent',
            tooltip: {
                position: 'top',
                backgroundColor: 'rgba(16, 24, 48, 0.95)',
                borderColor: fcolors.blue,
                textStyle: { color: '#e0e6f0' },
                formatter: function(params) {
                    var cur = currentValues[params.value[1]][params.value[0]];
                    var last = lastYearValues[params.value[1]][params.value[0]];
                    var yoy = cur - last;
                    var yoyStr = yoy > 0 ? '+' + yoy : '' + yoy;
                    var yoyColor = yoy < 0 ? fcolors.red : fcolors.green;
                    var r = '<div style="font-weight:700">' + heatUnits[params.value[1]] + '</div>' +
                           '<div>' + assetTypes[params.value[0]] + '</div>' +
                           '<div>本期成新率: ' + cur + '%</div>' +
                           '<div>上年同期: ' + last + '%</div>' +
                           '<div style="color:' + yoyColor + '">同比变动: ' + yoyStr + '%</div>';
                    if (cur < 50) r += '<div style="color:' + fcolors.red + ';font-size:11px;">&#9888; 低于50%预警线</div>';
                    return r;
                }
            },
            grid: { left: 65, right: 20, top: 5, bottom: 35 },
            xAxis: {
                type: 'category',
                data: assetTypes,
                axisLine: { lineStyle: { color: fAxisColor } },
                axisLabel: { color: fTextColor, fontSize: 10, rotate: 20 },
                axisTick: { show: false },
                splitArea: { show: true, areaStyle: { color: 'rgba(64,158,255,0.02)' } }
            },
            yAxis: {
                type: 'category',
                data: heatUnits,
                axisLine: { lineStyle: { color: fAxisColor } },
                axisLabel: { color: fTextColor, fontSize: 10 },
                axisTick: { show: false },
                splitArea: { show: true, areaStyle: { color: 'rgba(64,158,255,0.02)' } }
            },
            visualMap: {
                min: isYoy ? -15 : 30,
                max: isYoy ? 15 : 90,
                calculable: true,
                orient: 'horizontal',
                left: 'center',
                bottom: 0,
                itemWidth: 12, itemHeight: 60,
                textStyle: { color: fTextColor, fontSize: 10 },
                inRange: {
                    color: isYoy ?
                        [fcolors.red, '#e6a23c', '#f0f0f0', '#95d475', fcolors.green] :
                        [fcolors.red, fcolors.yellow, fcolors.green, fcolors.blue]
                },
                text: isYoy ? ['+15%', '-15%'] : ['90%', '30%']
            },
            series: [{
                name: isYoy ? '同比变动' : '成新率',
                type: 'heatmap',
                data: heatData,
                label: {
                    show: true,
                    color: '#fff',
                    fontSize: 10,
                    fontWeight: 'bold',
                    textShadowColor: 'rgba(0,0,0,0.5)',
                    textShadowBlur: 3,
                    formatter: function(p) {
                        var v = p.value[2];
                        return isYoy ? (v > 0 ? '+' : '') + v : v;
                    }
                },
                itemStyle: {
                    borderColor: 'rgba(10,14,26,0.5)',
                    borderWidth: 1,
                    borderRadius: 4
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 15,
                        shadowColor: 'rgba(64,158,255,0.5)',
                        borderColor: fcolors.cyan,
                        borderWidth: 2
                    }
                }
            }]
        };
    }

    financialCharts.assetHeat.setOption(getHeatmapOption('current'));
    financialCharts._getHeatmapOption = getHeatmapOption;

    // 6. 收入费用率散点图
    financialCharts.efficiency = echarts.init(document.getElementById('chart-efficiency'));
    var scatterData = [
        { name: '厅机关', income: 3200, rate: 62, expense: 1984, ratio: 3.2 },
        { name: '刑警总队', income: 2800, rate: 71, expense: 1988, ratio: 2.8 },
        { name: '交警总队', income: 3500, rate: 58, expense: 2030, ratio: 4.1 },
        { name: '治安总队', income: 2100, rate: 75, expense: 1575, ratio: 2.5 },
        { name: '网安总队', income: 1800, rate: 82, expense: 1476, ratio: 1.8 },
        { name: '特警总队', income: 2600, rate: 65, expense: 1690, ratio: 3.0 },
        { name: '监管总队', income: 1500, rate: 88, expense: 1320, ratio: 1.5 },
        { name: '禁毒总队', income: 2200, rate: 69, expense: 1518, ratio: 2.9 },
        { name: '科信总队', income: 1900, rate: 78, expense: 1482, ratio: 2.1 },
        { name: '警务保障部', income: 4200, rate: 55, expense: 2310, ratio: 5.2 }
    ];

    financialCharts.efficiency.setOption({
        backgroundColor: 'transparent',
        tooltip: {
            backgroundColor: 'rgba(16, 24, 48, 0.95)',
            borderColor: fcolors.blue,
            textStyle: { color: '#e0e6f0' },
            formatter: function(params) {
                var d = params.data;
                return '<div style="font-weight:700;margin-bottom:6px;">' + d[3] + '</div>' +
                       '<div>收入规模: ' + d[0] + '万</div>' +
                       '<div>收入费用率: ' + d[1] + '%</div>' +
                       '<div>总支出: ' + d[2] + '万</div>' +
                       '<div>费用结构效率: ' + d[4] + '</div>';
            }
        },
        grid: { left: 50, right: 30, top: 30, bottom: 40 },
        xAxis: {
            type: 'value',
            name: '收入规模(万)',
            nameTextStyle: { color: fTextColor, fontSize: 10 },
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10 },
            splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } }
        },
        yAxis: {
            type: 'value',
            name: '收入费用率(%)',
            nameTextStyle: { color: fTextColor, fontSize: 10 },
            axisLine: { lineStyle: { color: fAxisColor } },
            axisLabel: { color: fTextColor, fontSize: 10 },
            splitLine: { lineStyle: { color: 'rgba(139,157,195,0.08)', type: 'dashed' } },
            max: 100
        },
        series: [
            {
                type: 'scatter',
                data: scatterData.map(function(d) { return [d.income, d.rate, d.expense, d.name, d.ratio]; }),
                symbolSize: function(data) { return Math.sqrt(data[2]) / 2.5; },
                itemStyle: {
                    color: function(params) {
                        var rate = params.data[1];
                        if (rate > 80) return fcolors.red;
                        if (rate > 70) return fcolors.yellow;
                        if (rate > 60) return fcolors.blue;
                        return fcolors.green;
                    },
                    shadowBlur: 10,
                    shadowColor: 'rgba(64,158,255,0.3)',
                    opacity: 0.85
                },
                label: {
                    show: true,
                    formatter: function(params) { return params.data[3]; },
                    color: fTextColor,
                    fontSize: 10,
                    position: 'top'
                },
                emphasis: {
                    itemStyle: {
                        shadowBlur: 20,
                        shadowColor: 'rgba(64,158,255,0.6)',
                        borderColor: '#fff',
                        borderWidth: 2
                    }
                }
            },
            {
                type: 'line',
                markLine: {
                    silent: true,
                    lineStyle: { color: 'rgba(139,157,195,0.3)', type: 'dashed' },
                    data: [
                        { xAxis: 2500, label: { formatter: '均值', color: fTextColor } },
                        { yAxis: 70, label: { formatter: '警戒线', color: fcolors.yellow } }
                    ]
                }
            }
        ],
        graphic: [
            { type: 'text', left: '15%', top: '15%', style: { text: '高收入高效率', fill: fcolors.green, fontSize: 11, opacity: 0.6 } },
            { type: 'text', left: '65%', top: '15%', style: { text: '高收入低效率', fill: fcolors.red, fontSize: 11, opacity: 0.6 } },
            { type: 'text', left: '15%', top: '75%', style: { text: '低收入高效率', fill: fcolors.blue, fontSize: 11, opacity: 0.6 } },
            { type: 'text', left: '65%', top: '75%', style: { text: '低收入低效率', fill: fcolors.yellow, fontSize: 11, opacity: 0.6 } }
        ]
    });

    financialChartsInited = true;
}

// 财务全景Tab切换
function switchFinTab(chartName, tabIndex, btn) {
    if (chartName === 'structure') {
        currentStructureTab = tabIndex;
        financialCharts.structure.clear();
        financialCharts.structure.setOption(tabIndex === 0 ? financialCharts._structureOption0 : financialCharts._structureOption1);
        document.querySelectorAll('#page-financial .financial-tab-btn').forEach(function(b) { b.classList.remove('active'); });
        btn.classList.add('active');
    }
}

// 财务全景热力图切换
function toggleFinHeatmap() {
    finHeatmapMode = finHeatmapMode === 'current' ? 'yoy' : 'current';
    document.getElementById('heatToggle').textContent = finHeatmapMode === 'current' ? '切换：同比变动' : '切换：本期成新率';
    financialCharts.assetHeat.clear();
    financialCharts.assetHeat.setOption(financialCharts._getHeatmapOption(finHeatmapMode));
}

// 财务全景帕累托详情弹窗
function showParetoDetail(item) {
    document.getElementById('financialModalTitle').textContent = item.name + ' - 差异详情';
    var isPositive = item.diff > 0;
    var diffClass = isPositive ? 'positive' : 'negative';
    var diffSign = isPositive ? '+' : '';
    document.getElementById('financialModalBody').innerHTML =
        '<div class="financial-detail-grid">' +
            '<div class="financial-detail-item">' +
                '<div class="financial-detail-item-label">预算数</div>' +
                '<div class="financial-detail-item-value neutral">' + (item.diff > 0 ? item.diff + 200 : Math.abs(item.diff) + 200) + '万</div>' +
            '</div>' +
            '<div class="financial-detail-item">' +
                '<div class="financial-detail-item-label">决算数</div>' +
                '<div class="financial-detail-item-value neutral">' + (item.diff > 0 ? item.diff + 400 : Math.abs(item.diff) + 100) + '万</div>' +
            '</div>' +
            '<div class="financial-detail-item">' +
                '<div class="financial-detail-item-label">差异额</div>' +
                '<div class="financial-detail-item-value ' + diffClass + '">' + diffSign + item.diff + '万</div>' +
            '</div>' +
            '<div class="financial-detail-item">' +
                '<div class="financial-detail-item-label">差异率</div>' +
                '<div class="financial-detail-item-value ' + diffClass + '">' + (item.diff / 200 * 100).toFixed(1) + '%</div>' +
            '</div>' +
        '</div>' +
        '<div class="financial-detail-reason">' +
            '<strong>差异原因说明：</strong><br>' + item.reason +
        '</div>' +
        '<div style="margin-top:16px;font-size:12px;color:#8b9dc3;line-height:1.8;">' +
            '<strong style="color:#00d4ff;">建议措施：</strong><br>' +
            '1. 加强预算编制精准度，细化科目测算依据；<br>' +
            '2. 建立月度预算执行监控机制，及时发现偏差；<br>' +
            '3. 对重大差异科目开展专项审计，确保资金使用合规。' +
        '</div>';
    document.getElementById('financialModal').classList.add('active');
}

// 财务全景KPI详情弹窗
function showKpiDetail(title) {
    document.getElementById('financialModalTitle').textContent = title + ' - 趋势分析';
    document.getElementById('financialModalBody').innerHTML =
        '<div style="height:300px;" id="financialModalChart"></div>' +
        '<div style="margin-top:16px;font-size:12px;color:#8b9dc3;line-height:1.8;">' +
            '<strong style="color:#00d4ff;">分析结论：</strong><br>' +
            '该指标近12个月呈现波动趋势，主要受季节性因素及政策调整影响。建议持续跟踪监控，对异常波动及时预警。' +
        '</div>';
    document.getElementById('financialModal').classList.add('active');
    setTimeout(function() {
        var modalChart = echarts.init(document.getElementById('financialModalChart'));
        modalChart.setOption({
            backgroundColor: 'transparent',
            tooltip: { trigger: 'axis' },
            xAxis: {
                type: 'category',
                data: ['1月','2月','3月','4月','5月','6月','7月','8月','9月','10月','11月','12月'],
                axisLine: { lineStyle: { color: 'rgba(139, 157, 195, 0.2)' } },
                axisLabel: { color: '#8b9dc3' }
            },
            yAxis: {
                type: 'value',
                axisLine: { lineStyle: { color: 'rgba(139, 157, 195, 0.2)' } },
                axisLabel: { color: '#8b9dc3' },
                splitLine: { lineStyle: { color: 'rgba(139,157,195,0.1)', type: 'dashed' } }
            },
            series: [{
                type: 'line',
                data: [65,68,72,70,75,78,76,80,82,79,85,88],
                smooth: true,
                areaStyle: {
                    color: new echarts.graphic.LinearGradient(0,0,0,1,[
                        {offset:0, color: 'rgba(64,158,255,0.3)'},
                        {offset:1, color: 'rgba(64,158,255,0)'}
                    ])
                },
                itemStyle: { color: '#409eff' },
                lineStyle: { width: 3 }
            }]
        });
    }, 100);
}

// 关闭财务全景模态框
function closeFinModal() {
    document.getElementById('financialModal').classList.remove('active');
}

// 事件监听
document.addEventListener('DOMContentLoaded', function() {
    var finModal = document.getElementById('financialModal');
    if (finModal) {
        finModal.addEventListener('click', function(e) {
            if (e.target === this) closeFinModal();
        });
    }
});
