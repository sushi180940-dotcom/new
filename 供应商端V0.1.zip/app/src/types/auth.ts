// 认证视图状态
export type AuthView = 'login' | 'register' | 'forgotPassword' | 'reviewStatus';

// 登录方式
export type LoginMethod = 'password' | 'verificationCode';

// 注册步骤
export type RegisterStep = 1 | 2;

// 企业信息
export interface CompanyInfo {
  companyName: string;
  shortName: string;
  creditCode: string;
  registerAddress: string;
  legalPerson: string;
  registeredCapital: string;
  registerProvince: string;
  supplierType: string;
  cooperationUnit: string;
  contactName: string;
  idType: string;
  idNumber: string;
  contactPhone: string;
  email: string;
  responsiblePerson: string;
  loginPhone: string;
}

// 资质文件
export interface QualificationFiles {
  // 一、必填（注册提交必传）
  businessLicense: File | null;         // 营业执照副本
  legalPersonId: File | null;            // 法定代表人身份证
  bankPermit: File | null;               // 开户许可证
  industryLicense: File | null;          // 相关生产经营资质许可证
  // 二、条件必填/准入必填
  taxProof: File | null;                 // 近半年完税证明
  taxRating: File | null;                // 上一年度税务评级
  creditChina: File | null;              // 信用中国报告
  creditGov: File | null;                // 政府采购网查询截图
  // 三、建议上传
  companyIntro: File | null;             // 公司及产品简介
  supplyRecord: File | null;             // 供货业绩
}

// 账户安全
export interface AccountSecurity {
  loginAccount: string;
  password: string;
  confirmPassword: string;
  bindPhone: string;
  verificationCode: string;
}

// 完整注册数据
export interface RegisterData {
  companyInfo: CompanyInfo;
  qualificationFiles: QualificationFiles;
  accountSecurity: AccountSecurity;
}

// 登录表单数据
export interface LoginFormData {
  account: string;
  password: string;
  verificationCode: string;
  rememberMe: boolean;
}

// 忘记密码数据
export interface ForgotPasswordData {
  account: string;
  verificationCode: string;
  newPassword: string;
  confirmPassword: string;
}

// 审核状态
export type ReviewStatus = 'pending' | 'approved' | 'rejected';

export interface ReviewInfo {
  status: ReviewStatus;
  submitTime: string;
  estimatedTime: string;
  message?: string;
}

// 表单错误
export interface FormErrors {
  [key: string]: string;
}
