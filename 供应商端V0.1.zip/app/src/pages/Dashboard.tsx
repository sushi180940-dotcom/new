// @ts-nocheck
import { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  FileText, CreditCard, Package, Clock, ClipboardList,
  FileCheck, ShoppingBag, RotateCcw, Plus,
  X, Trash2, Eye, Pencil, SearchIcon, AlertTriangle, Upload, Minus,
  ChevronDown, Truck, Shield, User, CheckCircle2, CheckCircle, FileImage, Info
} from 'lucide-react';
import TreeSelect, { PinyinSearchSelect, defaultTreeData, UnitCodeTreeSelect, decodeUnitCode } from '@/components/TreeSelect';

// ==================== 分类级联数据 ====================
const categoryTree: Record<string, Record<string, string[]>> = {
  '通信设备': {
    '手持终端': ['警用级', '民用级'],
    '卫星通信': ['便携型', '车载型'],
    '对讲设备': ['数字型', '模拟型'],
    '基站设备': ['应急型', '固定型'],
  },
  '监控设备': {
    '执法记录': ['高清型', '标准型'],
    '摄像头': ['红外型', '普通型'],
  },
  '防护装备': {
    '防弹装备': ['三级防护', '二级防护'],
    '头部防护': ['战术级', '标准级'],
    '防护服装': ['战术级', '防暴级'],
  },
  '救援装备': {
    '无人机': ['侦察型', '救援型', '专业型'],
    '破拆工具': ['液压型', '电动型'],
  },
  '照明设备': {
    '应急照明': ['便携型', '移动型'],
    '信号照明': ['手持型', '固定型'],
  },
};

// ==================== 合作单位label映射 ====================
const unitLabelMap: Record<string, string> = {};
function buildUnitLabelMap(nodes: typeof defaultTreeData, prefix = '') {
  nodes.forEach(n => {
    const label = prefix ? `${prefix} / ${n.label}` : n.label;
    unitLabelMap[n.id] = label;
    if (n.children) buildUnitLabelMap(n.children, label);
  });
}
buildUnitLabelMap(defaultTreeData);

// 获取所有叶子节点ID列表
const unitLeafIds: string[] = [];
function collectLeafIds(nodes: typeof defaultTreeData) {
  nodes.forEach(n => {
    if (n.children && n.children.length > 0) collectLeafIds(n.children);
    else unitLeafIds.push(n.id);
  });
}
collectLeafIds(defaultTreeData);

// ==================== 通用工具函数 ====================
function multiKeywordMatch(text: string, keywords: string[]): boolean {
  if (keywords.length === 0) return true;
  const lowerText = text.toLowerCase();
  return keywords.every(k => lowerText.includes(k.toLowerCase()));
}

function parseKeywords(query: string): string[] {
  return query.trim().split(/\s+/).filter(k => k.length > 0);
}

function HighlightText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;
  const keywords = parseKeywords(query);
  if (keywords.length === 0) return <>{text}</>;
  let html = text;
  keywords.forEach(k => {
    const re = new RegExp(k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
    html = html.replace(re, '<mark style="background:#fef3c7;color:#92400e;padding:1px 2px;border-radius:2px">$&</mark>');
  });
  return <span dangerouslySetInnerHTML={{ __html: html }} />;
}

function isDateInRange(dateStr: string, startStr: string, endStr: string): boolean {
  if (!startStr && !endStr) return true;
  const d = new Date(dateStr);
  if (startStr && d < new Date(startStr)) return false;
  if (endStr && d > new Date(endStr + 'T23:59:59')) return false;
  return true;
}

// ==================== 类型定义 ====================
interface RfidTag {
  id: string; orderId: string; itemIndex: number; code: string;
  tagType: '0' | '1'; productDate: string; expireMonths: number;
  serialNo: string; status: 'unprinted' | 'printed' | 'shipped' | 'void';
  printCount: number; createdAt: string;
}

interface OrderItem {
  cat1: string; cat2: string; cat3: string; name: string; model: string;
  unit: string; quantity: number; price: number; code: string; tags: RfidTag[];
  hasBattery: boolean; batteryCycle: number;
  productDate?: string;
  warrantyPeriod?: number;
}

interface Order {
  id: string; name: string; contractId: string;
  supplier: string; supplierCode: string; deliveryDate: string;
  receiver: string; items: OrderItem[];
  shipStatus: 'pending' | 'partial' | 'shipped';
  shippedQty: number;
  inspectStatus: 'none' | 'inspecting' | 'inspected';
  inspectedQty: number;
  shippedAt?: string;
  createTime: string;
  warrantyPeriod?: number;
  contactName?: string;
  contactPhone?: string;
}

interface Contract {
  id: string; partyA: string; partyB: string; name: string;
  amount: string; signDate: string; deliveryDate: string;
  note: string; attachment: string;
  status: '草稿' | '履行中' | '已发货' | '已验收' | '终止';
  orderIds: string[];
}

interface Product {
  id: string; cat1: string; cat2: string; cat3: string;
  name: string; model: string; code: string; unit: string;
  price: string; hasBattery: boolean; batteryCycle: number;
  note: string; image: string; status: string;
  manufacturer: string;
}

interface Supplier {
  id: string;
  companyName: string;
  shortName: string;
  creditCode: string;
}

interface ShipmentItem {
  name: string;
  model: string;
  code: string;
  unit: string;
  isWholeBox: boolean;
  boxCode: string;
  orderedQty: number;
  thisShipQty: number;
  productDate: string;
  expireMonths: number;
  expireDate: string;
  rfidTags: string[];
}

interface ShipmentRecord {
  id: string;
  orderId: string;
  shipDate: string;
  deliveryAddress: string;
  remark: string;
  items: ShipmentItem[];
}

// ==================== RFID编码工具函数 ====================
function generateRfidCode(tagType: '0' | '1', equipCode: string, model: string, productDate: string, expireMonths: number, supplierCode: string, serialNo: number): string {
  const modelShort = model.slice(-3).padStart(3, '0');
  const expireStr = String(expireMonths).padStart(2, '0');
  const serialStr = String(serialNo).padStart(4, '0');
  return `${tagType}-${equipCode}-${modelShort}-${productDate}-${expireStr}-${supplierCode}-${serialStr}`;
}

function formatDateToYYMMDD(dateStr: string): string {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const yy = String(d.getFullYear()).slice(-2);
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yy}${mm}${dd}`;
}

function getNextSerialNo(existingTags: RfidTag[]): number {
  if (existingTags.length === 0) return 1;
  const maxSerial = Math.max(...existingTags.map(t => parseInt(t.serialNo, 10)));
  return maxSerial + 1;
}

function countItemTags(item: OrderItem, tagType?: '0' | '1'): number {
  if (!tagType) return item.tags.length;
  return item.tags.filter(t => t.tagType === tagType).length;
}

function isItemFullyTagged(item: OrderItem): boolean {
  const equipTags = item.tags.filter(t => t.tagType === '0' && t.status !== 'void').length;
  return equipTags >= item.quantity;
}

type ModuleType = 'contract' | 'order' | 'product';

const MY_COMPANY = '华为技术有限公司';
const MY_CREDIT_CODE = '91110000123456789X';
const MY_SUPPLIER_CODE = MY_CREDIT_CODE.slice(8, 17);
const unitOptions = ['台', '套', '件', '顶', '面', '把', '架', '个', '支', '块', '条', '只', '组', '对'];

// ==================== 演示数据 ====================
const initialContracts: Contract[] = [
  { id: 'HT2024001', partyA: 'dept-kx', partyB: '华为技术有限公司', name: '指挥调度系统建设合同', amount: '680000', signDate: '2024-03-10', deliveryDate: '2024-06-10', note: '包含硬件设备和软件系统', attachment: '合同附件-HT2024001.pdf', status: '草稿', orderIds: [] },
  { id: 'HT2024002', partyA: 'dept-wa', partyB: '华为技术有限公司', name: '网络安全设备采购合同', amount: '360000', signDate: '2024-03-15', deliveryDate: '2024-05-15', note: '防火墙、入侵检测等安全设备', attachment: '', status: '履行中', orderIds: ['DD2024001'] },
  { id: 'HT2024003', partyA: 'dept-xz', partyB: '华为技术有限公司', name: '通信保障设备采购合同', amount: '500000', signDate: '2024-03-20', deliveryDate: '2024-07-20', note: '', attachment: '', status: '已验收', orderIds: ['DD2024002'] },
  { id: 'HT2024004', partyA: 'dept-za', partyB: '华为技术有限公司', name: '应急救援装备采购合同', amount: '510000', signDate: '2024-03-25', deliveryDate: '2024-06-25', note: '无人机、破拆工具等', attachment: '', status: '草稿', orderIds: [] },
  { id: 'HT2024005', partyA: 'dept-jj', partyB: '华为技术有限公司', name: '智能交通系统升级合同', amount: '680000', signDate: '2024-03-10', deliveryDate: '2024-09-10', note: '', attachment: '', status: '终止', orderIds: [] },
  { id: 'HT2024006', partyA: 'dept-kx', partyB: '华为技术有限公司', name: '数据中心建设合同', amount: '360000', signDate: '2024-04-01', deliveryDate: '2024-08-01', note: '服务器、存储设备等', attachment: '', status: '已发货', orderIds: ['DD2024003'] },
];

const initialOrders: Order[] = [
  { id: 'DD2024001', name: '网络安全设备首批订单', contractId: 'HT2024002', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-04-15', receiver: 'GDSGAJ.GZSGAJ.THGAJ.XZZD', shipStatus: 'pending', shippedQty: 0, inspectStatus: 'none', inspectedQty: 0, createTime: '2024-03-20 09:30:00', items: [
    { cat1: '通信设备', cat2: '手持终端', cat3: '警用级', name: '手持终端', model: 'XT-2000', unit: '台', quantity: 20, price: 2500, code: '1000001', tags: [], hasBattery: true, batteryCycle: 12 },
    { cat1: '通信设备', cat2: '对讲设备', cat3: '数字型', name: '对讲机', model: 'PD780G', unit: '台', quantity: 50, price: 1800, code: '1000002', tags: [], hasBattery: true, batteryCycle: 12 },
  ]},
  { id: 'DD2024002', name: '通信保障设备订单', contractId: 'HT2024003', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-04-20', receiver: 'GDSGAJ.SZSGAJ.FTGAJ.WAZD', shipStatus: 'shipped', shippedQty: 50, inspectStatus: 'inspecting', inspectedQty: 0, createTime: '2024-03-22 14:15:00', items: [
    { cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', unit: '台', quantity: 50, price: 1200, code: '1000003', tags: [], hasBattery: true, batteryCycle: 6 },
  ]},
  { id: 'DD2024003', name: '数据中心设备订单', contractId: 'HT2024006', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-05-10', receiver: 'GDSGAJ.GZSGAJ.BYGAJ.WAZD', shipStatus: 'pending', shippedQty: 0, inspectStatus: 'none', inspectedQty: 0, createTime: '2024-04-05 11:00:00', items: [
    { cat1: '通信设备', cat2: '基站设备', cat3: '应急型', name: '应急通信基站', model: 'EBS-100', unit: '套', quantity: 5, price: 35000, code: '1000004', tags: [], hasBattery: false, batteryCycle: 0 },
  ]},
  { id: 'DD2024004', name: '执法记录仪第三批订单', contractId: 'HT2024003', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-05-20', receiver: 'GDSGAJ.GZSGAJ.HZGAJ.XZZD', shipStatus: 'shipped', shippedQty: 10, inspectStatus: 'inspecting', inspectedQty: 5, createTime: '2024-04-10 16:45:00', items: [
    { cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', unit: '台', quantity: 10, price: 2500, code: '1000003', tags: [], hasBattery: true, batteryCycle: 6 },
  ]},
  { id: 'DD2024005', name: '应急救援装备订单', contractId: 'HT2024004', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-06-05', receiver: 'GDSGAJ.GZSGAJ.HZGAJ.XZZD', shipStatus: 'shipped', shippedQty: 35, inspectStatus: 'inspecting', inspectedQty: 10, createTime: '2024-04-18 08:20:00', items: [
    { cat1: '防护装备', cat2: '头部防护', cat3: '战术级', name: '战术头盔', model: 'TAC-H1', unit: '顶', quantity: 30, price: 1800, code: '1000005', tags: [], hasBattery: false, batteryCycle: 0 },
    { cat1: '防护装备', cat2: '防弹装备', cat3: '三级防护', name: '防弹盾牌', model: 'FDP-3', unit: '个', quantity: 20, price: 3200, code: '1000006', tags: [], hasBattery: false, batteryCycle: 0 },
    { cat1: '防护装备', cat2: '破拆工具', cat3: '电动型', name: '电动破拆工具组', model: 'DBT-200', unit: '套', quantity: 10, price: 8500, code: '1000007', tags: [], hasBattery: true, batteryCycle: 24 },
  ]},
  { id: 'DD2024006', name: '智能交通设备订单', contractId: 'HT2024005', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-06-15', receiver: 'GDSGAJ.SZSGAJ.NSGAJ.JZZD', shipStatus: 'shipped', shippedQty: 25, inspectStatus: 'inspected', inspectedQty: 25, createTime: '2024-05-01 10:30:00', items: [
    { cat1: '监控设备', cat2: '摄像头', cat3: '红外型', name: '红外夜视摄像头', model: 'IRC-NV1', unit: '台', quantity: 25, price: 3200, code: '1000008', tags: [], hasBattery: false, batteryCycle: 0 },
  ]},
  { id: 'DD2024007', name: '指挥调度系统订单', contractId: 'HT2024001', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-07-01', receiver: 'GDSGAJ.GZSGAJ.BYGAJ.WAZD', shipStatus: 'partial', shippedQty: 15, inspectStatus: 'none', inspectedQty: 0, createTime: '2024-05-15 13:00:00', items: [
    { cat1: '通信设备', cat2: '指挥调度', cat3: '车载型', name: '车载指挥终端', model: 'CCT-500', unit: '台', quantity: 15, price: 12000, code: '1000009', tags: [], hasBattery: true, batteryCycle: 12 },
    { cat1: '通信设备', cat2: '卫星通信', cat3: '便携型', name: '卫星便携站', model: 'SAT-200', unit: '套', quantity: 5, price: 45000, code: '1000010', tags: [], hasBattery: true, batteryCycle: 36 },
  ]},
  { id: 'DD2024008', name: '消防装备补充订单', contractId: 'HT2024004', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-07-20', receiver: 'GDSGAJ.GZSGAJ.HZGAJ.XZZD', shipStatus: 'shipped', shippedQty: 45, inspectStatus: 'inspecting', inspectedQty: 20, createTime: '2024-06-01 09:00:00', items: [
    { cat1: '防护装备', cat2: '消防装备', cat3: '阻燃型', name: '阻燃战斗服', model: 'FRF-100', unit: '套', quantity: 40, price: 1200, code: '1000011', tags: [], hasBattery: false, batteryCycle: 0 },
    { cat1: '通信设备', cat2: '对讲设备', cat3: '防爆型', name: '防爆对讲机', model: 'EPD-800', unit: '台', quantity: 30, price: 3500, code: '1000012', tags: [], hasBattery: true, batteryCycle: 18 },
    { cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '双模执法记录仪', model: 'DSJ-B5', unit: '台', quantity: 15, price: 3800, code: '1000013', tags: [], hasBattery: true, batteryCycle: 12 },
  ]},
  { id: 'DD2024009', name: '警用无人机装备订单', contractId: 'HT2024002', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-08-05', receiver: 'GDSGAJ.GZSGAJ.THGAJ.XZZD', shipStatus: 'pending', shippedQty: 0, inspectStatus: 'none', inspectedQty: 0, createTime: '2024-06-20 15:30:00', items: [
    { cat1: '监控设备', cat2: '无人机', cat3: '侦察型', name: '警用侦察无人机', model: 'UAV-S1', unit: '架', quantity: 8, price: 28000, code: '1000014', tags: [], hasBattery: true, batteryCycle: 12 },
    { cat1: '监控设备', cat2: '无人机', cat3: '载重型', name: '载重无人机', model: 'UAV-L2', unit: '架', quantity: 3, price: 45000, code: '1000015', tags: [], hasBattery: true, batteryCycle: 12 },
  ]},
  { id: 'DD2024010', name: '安防监控设备订单', contractId: 'HT2024006', supplier: '华为技术有限公司', supplierCode: '001234567', deliveryDate: '2024-08-20', receiver: 'GDSGAJ.GZSGAJ.BYGAJ.WAZD', shipStatus: 'shipped', shippedQty: 60, inspectStatus: 'inspecting', inspectedQty: 35, createTime: '2024-07-05 11:45:00', items: [
    { cat1: '监控设备', cat2: '摄像头', cat3: '全景型', name: '全景监控摄像头', model: 'PANO-360', unit: '台', quantity: 30, price: 4200, code: '1000016', tags: [], hasBattery: false, batteryCycle: 0 },
    { cat1: '监控设备', cat2: '录像机', cat3: '网络型', name: '网络硬盘录像机', model: 'NVR-64', unit: '台', quantity: 15, price: 6800, code: '1000017', tags: [], hasBattery: false, batteryCycle: 0 },
    { cat1: '通信设备', cat2: '传输设备', cat3: '光纤型', name: '光纤收发器', model: 'FOT-1000', unit: '对', quantity: 30, price: 800, code: '1000018', tags: [], hasBattery: false, batteryCycle: 0 },
  ]},
];

// ==================== 发货单数据 ====================
interface ShipmentDocItem {
  itemType: string; name: string; model: string;
  unit: string; quantity: number; price: number;
  productDate: string; expireMonths: number;
  rfidCodes: string[]; boxCode: string;
}

interface ShipmentDocument {
  id: string; orderId: string;
  shipDate: string; deliveryAddress: string; remark: string;
  items: ShipmentDocItem[];
}

const shipmentDocs: ShipmentDocument[] = [
  {
    id: 'FH2024001', orderId: 'DD2024002', shipDate: '2024-04-10',
    deliveryAddress: '收货地址待填写', remark: '首批发货',
    items: [
      { itemType: '监控设备/执法记录/高清型', name: '执法记录仪', model: 'DSJ-A7', unit: '台', quantity: 50, price: 1200, productDate: '2024-03-15', expireMonths: 12, rfidCodes: ['0-1000003-7A7-240315-12-123456789-0001', '...共50条'], boxCode: 'BOX-001' },
    ],
  },
  {
    id: 'FH2024002', orderId: 'DD2024004', shipDate: '2024-04-15',
    deliveryAddress: '收货地址待填写', remark: '第三批',
    items: [
      { itemType: '监控设备/执法记录/高清型', name: '执法记录仪', model: 'DSJ-A7', unit: '台', quantity: 10, price: 2500, productDate: '2024-03-20', expireMonths: 12, rfidCodes: ['0-1000003-7A7-240320-12-123456789-0001', '...共10条'], boxCode: 'BOX-003' },
    ],
  },
];

const shipmentRecords: ShipmentRecord[] = [
  {
    id: 'FH2024001', orderId: 'DD2024002', shipDate: '2024-04-10', deliveryAddress: '收货地址待填写', remark: '首批发货',
    items: [{ name: '执法记录仪', model: 'DSJ-A7', code: '1000003', unit: '台', isWholeBox: true, boxCode: 'BOX-A001', orderedQty: 50, thisShipQty: 20, productDate: '2024-03-15', expireMonths: 12, expireDate: '2025-03-15',
      rfidTags: Array.from({length:20}, (_,i) => `0-1000003-JA7-240315-12-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024002', orderId: 'DD2024002', shipDate: '2024-04-15', deliveryAddress: '收货地址待填写', remark: '第二批补发',
    items: [{ name: '执法记录仪', model: 'DSJ-A7', code: '1000003', unit: '台', isWholeBox: false, boxCode: '', orderedQty: 50, thisShipQty: 30, productDate: '2024-03-20', expireMonths: 12, expireDate: '2025-03-20',
      rfidTags: Array.from({length:30}, (_,i) => `0-1000003-JA7-240320-12-123456789-${String(i+21).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024003', orderId: 'DD2024004', shipDate: '2024-04-18', deliveryAddress: '收货地址待填写', remark: '第三批',
    items: [{ name: '执法记录仪', model: 'DSJ-A7', code: '1000003', unit: '台', isWholeBox: true, boxCode: 'BOX-B002', orderedQty: 10, thisShipQty: 10, productDate: '2024-03-22', expireMonths: 12, expireDate: '2025-03-22',
      rfidTags: Array.from({length:10}, (_,i) => `0-1000003-JA7-240322-12-123456789-${String(i+101).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024004', orderId: 'DD2024005', shipDate: '2024-05-12', deliveryAddress: '收货地址待填写', remark: '战术头盔首批',
    items: [{ name: '战术头盔', model: 'TAC-H1', code: '1000005', unit: '顶', isWholeBox: true, boxCode: 'BOX-C003', orderedQty: 30, thisShipQty: 15, productDate: '2024-04-01', expireMonths: 24, expireDate: '2026-04-01',
      rfidTags: Array.from({length:15}, (_,i) => `0-1000005-CH1-240401-24-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024005', orderId: 'DD2024005', shipDate: '2024-05-18', deliveryAddress: '收货地址待填写', remark: '防弹盾牌+破拆工具',
    items: [
      { name: '防弹盾牌', model: 'FDP-3', code: '1000006', unit: '个', isWholeBox: false, boxCode: '', orderedQty: 20, thisShipQty: 10, productDate: '2024-04-05', expireMonths: 36, expireDate: '2027-04-05',
        rfidTags: Array.from({length:10}, (_,i) => `0-1000006-FP3-240405-36-123456789-${String(i+1).padStart(4,'0')}`) },
      { name: '电动破拆工具组', model: 'DBT-200', code: '1000007', unit: '套', isWholeBox: true, boxCode: 'BOX-D004', orderedQty: 10, thisShipQty: 10, productDate: '2024-03-28', expireMonths: 24, expireDate: '2026-03-28',
        rfidTags: Array.from({length:10}, (_,i) => `0-1000007-BT2-240328-24-123456789-${String(i+1).padStart(4,'0')}`) },
    ],
  },
  {
    id: 'FH2024006', orderId: 'DD2024006', shipDate: '2024-05-25', deliveryAddress: '收货地址待填写', remark: '红外摄像头全量发货',
    items: [{ name: '红外夜视摄像头', model: 'IRC-NV1', code: '1000008', unit: '台', isWholeBox: false, boxCode: '', orderedQty: 25, thisShipQty: 25, productDate: '2024-04-10', expireMonths: 18, expireDate: '2025-10-10',
      rfidTags: Array.from({length:25}, (_,i) => `0-1000008-NV1-240410-18-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024007', orderId: 'DD2024007', shipDate: '2024-06-08', deliveryAddress: '收货地址待填写', remark: '指挥终端首批',
    items: [{ name: '车载指挥终端', model: 'CCT-500', code: '1000009', unit: '台', isWholeBox: true, boxCode: 'BOX-E005', orderedQty: 15, thisShipQty: 8, productDate: '2024-05-01', expireMonths: 12, expireDate: '2025-05-01',
      rfidTags: Array.from({length:8}, (_,i) => `0-1000009-CT5-240501-12-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024008', orderId: 'DD2024008', shipDate: '2024-06-20', deliveryAddress: '收货地址待填写', remark: '阻燃战斗服',
    items: [{ name: '阻燃战斗服', model: 'FRF-100', code: '1000011', unit: '套', isWholeBox: true, boxCode: 'BOX-F006', orderedQty: 40, thisShipQty: 25, productDate: '2024-05-10', expireMonths: 36, expireDate: '2027-05-10',
      rfidTags: Array.from({length:25}, (_,i) => `0-1000011-RF1-240510-36-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024009', orderId: 'DD2024008', shipDate: '2024-06-28', deliveryAddress: '收货地址待填写', remark: '防爆对讲机+记录仪',
    items: [
      { name: '防爆对讲机', model: 'EPD-800', code: '1000012', unit: '台', isWholeBox: false, boxCode: '', orderedQty: 30, thisShipQty: 20, productDate: '2024-05-15', expireMonths: 18, expireDate: '2025-11-15',
        rfidTags: Array.from({length:20}, (_,i) => `0-1000012-PD8-240515-18-123456789-${String(i+1).padStart(4,'0')}`) },
    ],
  },
  {
    id: 'FH2024010', orderId: 'DD2024010', shipDate: '2024-07-15', deliveryAddress: '收货地址待填写', remark: '全景摄像头首批',
    items: [{ name: '全景监控摄像头', model: 'PANO-360', code: '1000016', unit: '台', isWholeBox: true, boxCode: 'BOX-G007', orderedQty: 30, thisShipQty: 20, productDate: '2024-06-01', expireMonths: 24, expireDate: '2026-06-01',
      rfidTags: Array.from({length:20}, (_,i) => `0-1000016-P36-240601-24-123456789-${String(i+1).padStart(4,'0')}`) }],
  },
  {
    id: 'FH2024011', orderId: 'DD2024010', shipDate: '2024-07-25', deliveryAddress: '收货地址待填写', remark: '录像机+收发器',
    items: [
      { name: '网络硬盘录像机', model: 'NVR-64', code: '1000017', unit: '台', isWholeBox: false, boxCode: '', orderedQty: 15, thisShipQty: 15, productDate: '2024-06-10', expireMonths: 12, expireDate: '2025-06-10',
        rfidTags: Array.from({length:15}, (_,i) => `0-1000017-VR6-240610-12-123456789-${String(i+1).padStart(4,'0')}`) },
      { name: '光纤收发器', model: 'FOT-1000', code: '1000018', unit: '对', isWholeBox: true, boxCode: 'BOX-H008', orderedQty: 30, thisShipQty: 25, productDate: '2024-06-05', expireMonths: 24, expireDate: '2026-06-05',
        rfidTags: Array.from({length:25}, (_,i) => `0-1000018-OT1-240605-24-123456789-${String(i+1).padStart(4,'0')}`) },
    ],
  },
];
const supplierLibrary: Supplier[] = [
  { id: 'S001', companyName: '华为技术有限公司', shortName: '华为', creditCode: '91440300192383245X' },
  { id: 'S002', companyName: '大疆创新科技有限公司', shortName: '大疆', creditCode: '91440300764973259L' },
  { id: 'S003', companyName: '海能达通信股份有限公司', shortName: '海能达', creditCode: '91440300192384756Y' },
  { id: 'S004', companyName: '深圳警翼智能科技股份有限公司', shortName: '警翼', creditCode: '91440300326374821M' },
  { id: 'S005', companyName: '浙江立泰复合材料股份有限公司', shortName: '立泰', creditCode: '91330500757084523N' },
  { id: 'S006', companyName: '北京安泰富源科贸有限公司', shortName: '安泰富源', creditCode: '91110108756723451P' },
  { id: 'S007', companyName: '华力创通科技股份有限公司', shortName: '华力创通', creditCode: '91110000801345238Q' },
  { id: 'S008', companyName: '海洋王照明科技股份有限公司', shortName: '海洋王', creditCode: '91440300715286473R' },
  { id: 'S009', companyName: '中兴通讯股份有限公司', shortName: '中兴', creditCode: '91440300192385674S' },
  { id: 'S010', companyName: '中国电子科技集团公司', shortName: '中国电科', creditCode: '91110000100012345T' },
];

const initialProducts: Product[] = [
  { id: '1', cat1: '通信设备', cat2: '手持终端', cat3: '警用级', name: '手持终端', model: 'XT-2000', code: '1000001', unit: '台', price: '¥2,500', hasBattery: true, batteryCycle: 12, note: '警用手持通信终端', image: '', status: '已上架', manufacturer: '华为技术有限公司' },
  { id: '2', cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', code: '1000002', unit: '台', price: '¥1,200', hasBattery: true, batteryCycle: 6, note: '高清执法记录', image: '', status: '已上架', manufacturer: '深圳警翼智能科技股份有限公司' },
  { id: '3', cat1: '救援装备', cat2: '无人机', cat3: '专业型', name: '无人机', model: 'M300-RTK', code: '1000003', unit: '架', price: '¥45,000', hasBattery: true, batteryCycle: 3, note: '专业救援无人机', image: '', status: '待审', manufacturer: '大疆创新科技有限公司' },
  { id: '4', cat1: '照明设备', cat2: '应急照明', cat3: '便携型', name: '应急照明灯', model: 'YD-100', code: '1000004', unit: '台', price: '¥350', hasBattery: true, batteryCycle: 6, note: '应急照明设备', image: '', status: '已下架', manufacturer: '海洋王照明科技股份有限公司' },
  { id: '5', cat1: '通信设备', cat2: '对讲设备', cat3: '数字型', name: '对讲机', model: 'PD780G', code: '1000005', unit: '台', price: '¥1,800', hasBattery: true, batteryCycle: 12, note: '数字对讲机', image: '', status: '待审', manufacturer: '海能达通信股份有限公司' },
  { id: '6', cat1: '防护装备', cat2: '防弹装备', cat3: '三级防护', name: '防弹背心', model: 'FDY-3R', code: '1000006', unit: '件', price: '¥3,200', hasBattery: false, batteryCycle: 0, note: '三级防弹背心', image: '', status: '已上架', manufacturer: '北京安泰富源科贸有限公司' },
  { id: '7', cat1: '防护装备', cat2: '头部防护', cat3: '战术级', name: '战术头盔', model: 'MICH-2000', code: '1000007', unit: '顶', price: '¥1,800', hasBattery: false, batteryCycle: 0, note: '战术防护头盔', image: '', status: '草稿', manufacturer: '浙江立泰复合材料股份有限公司' },
  { id: '8', cat1: '通信设备', cat2: '卫星通信', cat3: '便携型', name: '便携式卫星通信终端', model: 'SAT-100', code: '1000008', unit: '台', price: '¥85,000', hasBattery: true, batteryCycle: 24, note: '卫星通信设备', image: '', status: '审核未通过', manufacturer: '华力创通科技股份有限公司' },
];

// ==================== 主组件 ====================
export default function Dashboard() {
  const [activeModule, setActiveModule] = useState<ModuleType>('contract');
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [contracts, setContracts] = useState<Contract[]>(initialContracts);
  const [orders, setOrders] = useState<Order[]>(initialOrders);

  // 弹窗状态
  const [showProductPicker, setShowProductPicker] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [showNewProduct, setShowNewProduct] = useState(false);
  const [showDetail, setShowDetail] = useState<Product | null>(null);
  const [showContractModal, setShowContractModal] = useState(false);
  const [showOrderModal, setShowOrderModal] = useState(false);
  const [confirmModal, setConfirmModal] = useState<{ open: boolean; message: string; onConfirm: () => void }>({ open: false, message: '', onConfirm: () => {} });
  const [orderPrefill, setOrderPrefill] = useState<{ contractId?: string; receiver?: string } | null>(null);
  const [viewContract, setViewContract] = useState<Contract | null>(null);
  const [viewOrder, setViewOrder] = useState<Order | null>(null);
  const [viewShipmentDoc, setViewShipmentDoc] = useState<Order | null>(null);
  const [withdrawOrder, setWithdrawOrder] = useState<Order | null>(null);
  const [editOrder, setEditOrder] = useState<Order | null>(null);
  const [transferKeyword, setTransferKeyword] = useState('');
  const [showCreateShipment, setShowCreateShipment] = useState(false);
  const [importAcceptanceTarget, setImportAcceptanceTarget] = useState<{ type: 'contract' | 'shipment' | 'order'; id: string } | null>(null);
  const [shipmentPrefillOrder, setShipmentPrefillOrder] = useState<Order | null>(null);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // ===== 供应商资质审核状态 =====
  const [supplierStatus, setSupplierStatus] = useState<'unsubmitted' | 'pending' | 'approved'>('unsubmitted');
  const [showSupplierInfo, setShowSupplierInfo] = useState(false);
  // 联系人信息（演示数据）
  const [contactInfo, setContactInfo] = useState({
    contactName: '张明华',
    idType: '身份证',
    idNumber: '310101199003152345',
    contactPhone: '13800138000',
    email: 'zhangmh@example.com',
  });
  // 资质文件（演示数据 - 必填项已上传）
  const [qualFiles, setQualFiles] = useState<Record<string, string>>({
    businessLicense: '已上传-businessLicense',
    legalPersonId: '已上传-legalPersonId',
    industryLicense: '已上传-industryLicense',
    creditChina: '已上传-creditChina',
    creditGov: '已上传-creditGov',
    bankPermit: '已上传-bankPermit',
    taxProof: '',
    taxRating: '已上传-taxRating',
    companyIntro: '已上传-companyIntro',
    supplyRecord: '',
  });

  // ===== 合同管理搜索状态 =====
  const [contractSearch, setContractSearch] = useState({ keywords: '', startDate: '', endDate: '' });

  // ===== 订单管理搜索状态 =====
  const [orderSearch, setOrderSearch] = useState({ keywords: '', contractId: '', receiver: '' });

  // ===== 在用装备分类信息搜索状态 =====
  const [productSearch, setProductSearch] = useState({
    keywords: '', cat3: '', status: ''
  });

  // ===== 过滤逻辑 =====
  const contractKeywords = parseKeywords(contractSearch.keywords);
  const filteredContracts = contracts.filter(d => {
    // 时间区间
    if (!isDateInRange(d.signDate, contractSearch.startDate, contractSearch.endDate)) return false;
    // 多关键词匹配（甲方/乙方/合同名称）
    if (contractKeywords.length === 0) return true;
    const searchText = `${unitLabelMap[d.partyA] || d.partyA} ${d.partyB} ${d.name}`;
    return multiKeywordMatch(searchText, contractKeywords);
  });

  const orderKeywords = parseKeywords(orderSearch.keywords);
  const filteredOrders = orders.filter(d => {
    // 关联合同筛选
    if (orderSearch.contractId && d.contractId !== orderSearch.contractId) return false;
    // 收货对象筛选
    if (orderSearch.receiver && d.receiver !== orderSearch.receiver) return false;
    // 多关键词匹配（订单名称）
    if (orderKeywords.length === 0) return true;
    return multiKeywordMatch(d.name, orderKeywords);
  });

  const productKeywords = parseKeywords(productSearch.keywords);
  const filteredProducts = products.filter(d => {
    // 装备分类筛选（按三级分类）
    if (productSearch.cat3 && d.cat3 !== productSearch.cat3) return false;
    // 状态筛选
    if (productSearch.status && d.status !== productSearch.status) return false;
    // 多关键词匹配（装备名称/型号）
    if (productKeywords.length === 0) return true;
    const searchText = `${d.name} ${d.model}`;
    return multiKeywordMatch(searchText, productKeywords);
  });

  const stats = [
    { label: '总合同数', value: `${contracts.length}个`, icon: <FileText className="w-5 h-5 text-purple-600" />, bg: 'bg-purple-50' },
    { label: '总合同额', value: `¥${contracts.reduce((s, c) => s + (Number(c.amount) || 0), 0).toLocaleString()}`, icon: <CreditCard className="w-5 h-5 text-pink-600" />, bg: 'bg-pink-50' },
    { label: '订单数量', value: `${orders.length}个`, icon: <ClipboardList className="w-5 h-5 text-[#1b2370]" />, bg: 'bg-[#e8ecf5]' },
    { label: '已上架商品', value: `${products.filter(p => p.status === '已上架').length}件`, icon: <Package className="w-5 h-5 text-green-600" />, bg: 'bg-green-50' },
    { label: '待审核商品', value: `${products.filter(p => p.status === '待审').length}件`, icon: <Clock className="w-5 h-5 text-amber-600" />, bg: 'bg-amber-50' },
  ];

  const modules = [
    { key: 'contract' as ModuleType, label: '合同管理', desc: '合同签订与执行', icon: <FileCheck className="w-6 h-6 text-[#1b2370]" />, count: contracts.length, color: 'border-[#3b4f9f] ring-2 ring-blue-100' },
    { key: 'order' as ModuleType, label: '订单管理', desc: '订单填写与发货', icon: <ClipboardList className="w-6 h-6 text-amber-600" />, count: orders.length, color: 'border-amber-500 ring-2 ring-amber-100' },
    { key: 'product' as ModuleType, label: '在用装备分类信息', desc: '在用装备分类信息与申报', icon: <ShoppingBag className="w-6 h-6 text-green-600" />, count: products.length, color: 'border-green-500 ring-2 ring-green-100' },
  ];

  const statusTag = (s: string) => {
    const m: Record<string, string> = {
      '草稿': 'bg-[#e8ecf5] text-slate-600', '履行中': 'bg-[#d4dcee] text-[#2e3a8c]', '已发货': 'bg-purple-100 text-purple-700', '已验收': 'bg-green-100 text-green-700',
      '终止': 'bg-red-100 text-red-700', '已上架': 'bg-green-100 text-green-700', '待审': 'bg-amber-100 text-amber-700',
      '已下架': 'bg-[#e8ecf5] text-slate-500', '审核未通过': 'bg-red-100 text-red-700',
    };
    return m[s] || 'bg-[#e8ecf5] text-slate-600';
  };

  const goToNewProduct = (keyword: string) => {
    setShowRegister(false); setTransferKeyword(keyword); setShowNewProduct(true);
  };

  const handleFillOrder = (contract: Contract) => {
    setActiveModule('order');
    setOrderPrefill({ contractId: contract.id, receiver: contract.partyA });
    setTimeout(() => setShowOrderModal(true), 100);
  };

  const handleDeleteContract = (id: string) => {
    setConfirmModal({ open: true, message: '确定删除该合同吗？删除后不可恢复。', onConfirm: () => { setContracts(prev => prev.filter(c => c.id !== id)); setConfirmModal(prev => ({ ...prev, open: false })); } });
  };

  const handlePriceEdit = (id: string, newPrice: string) => {
    setProducts(prev => prev.map(p => p.id === id ? { ...p, price: `¥${newPrice}` } : p));
  };

  const getContractName = useCallback((contractId: string) => contracts.find(c => c.id === contractId)?.name || contractId, [contracts]);

  const contractActions = (c: Contract) => {
    const btns: React.ReactNode[] = [<button key="view" onClick={() => setViewContract(c)} className="text-[#1b2370] hover:underline text-xs">查看</button>];
    if (c.status === '草稿') {
      btns.push(<button key="edit" onClick={() => setViewContract(c)} className="text-amber-600 hover:underline text-xs">编辑</button>);
      btns.push(<button key="del" onClick={() => handleDeleteContract(c.id)} className="text-red-500 hover:underline text-xs">删除</button>);
    }
    if (c.status === '履行中') {
      btns.push(<button key="order" onClick={() => handleFillOrder(c)} className="text-[#1b2370] hover:underline text-xs">填写订单</button>);
    }
    if (c.status === '已验收') {
      btns.push(<button key="accept" onClick={() => setImportAcceptanceTarget({ type: 'contract', id: c.id })} className="flex items-center gap-1 text-green-700 hover:underline text-xs font-medium"><FileCheck className="w-3 h-3" />导入验收单</button>);
    }
    return <div className="flex items-center gap-2">{btns}</div>;
  };

  // 商品搜索二级/三级分类选项
  // 收集所有三级分类作为装备分类选项
  const productCat3Options = useMemo(() => {
    const set = new Set<string>();
    Object.values(categoryTree).forEach(level2 => {
      Object.values(level2).forEach(level3 => {
        level3.forEach(c => set.add(c));
      });
    });
    return Array.from(set).sort();
  }, []);

  // 供应商资质审核提示界面（unsubmitted/pending 状态）
  if (supplierStatus !== 'approved') {
    return (
      <div className="space-y-5">
        <h1 className="text-lg font-bold text-slate-800">装备采购管理</h1>

        {/* 统计卡片 - 禁用状态 */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 opacity-50">
          {stats.map((s, i) => (
            <div key={i} className="bg-white rounded-xl p-4 border border-slate-200 shadow-police">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ background: s.bg === 'bg-purple-50' ? '#f3e8ff' : s.bg === 'bg-pink-50' ? '#fce7f3' : s.bg === 'bg-[#e8ecf5]' ? '#d4dcee' : s.bg === 'bg-green-50' ? '#dcfce7' : '#fef9c3' }}>
                {s.icon}
              </div>
              <p className="text-xs text-slate-500">{s.label}</p>
              <p className="text-base font-bold text-slate-800 mt-0.5">{s.value}</p>
            </div>
          ))}
        </div>

        {/* 功能模块 - 禁用状态 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 opacity-50">
          {modules.map(m => (
            <div key={m.key}
              className="flex items-center gap-4 p-5 bg-white rounded-xl border-2 border-slate-200 text-left">
              <div className="w-12 h-12 rounded-xl bg-[#f0f3fa] flex items-center justify-center flex-shrink-0">{m.icon}</div>
              <div className="flex-1">
                <div className="flex items-center gap-2"><h3 className="text-base font-bold text-slate-800">{m.label}</h3><span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">{m.count}</span></div>
                <p className="text-xs text-slate-500 mt-0.5">{m.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* 未提交状态：显示提示和提交按钮 */}
        {supplierStatus === 'unsubmitted' && (
          <div className="bg-white rounded-xl border border-amber-200 shadow-police overflow-hidden">
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-6 h-6 text-amber-600" />
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-bold text-slate-800 mb-1">功能暂未开通</h2>
                  <p className="text-sm text-slate-500 mb-4">请先提交联系人及资质信息，审核通过后方可使用合同管理、订单管理、在用装备分类信息等功能。</p>
                  <button onClick={() => setShowSupplierInfo(true)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">
                    <Plus className="w-4 h-4" /> 提交联系人及资质信息
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 待审核状态：显示审核中提示 */}
        {supplierStatus === 'pending' && (
          <div className="bg-white rounded-xl border border-blue-200 shadow-police overflow-hidden">
            <div className="px-6 py-5">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-50 border border-blue-200 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-[#1b2370]" />
                </div>
                <div className="flex-1">
                  <h2 className="text-base font-bold text-slate-800 mb-1">审核中</h2>
                  <p className="text-sm text-slate-500 mb-4">您的联系人及资质信息已提交，正在审核中。审核通过后方可使用全部功能。</p>
                  <div className="flex items-center gap-3">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 text-amber-700 rounded text-xs font-medium border border-amber-200">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
                      待审核
                    </span>
                    {/* 演示按钮 */}
                    <button onClick={() => setSupplierStatus('approved')}
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">
                      <CheckCircle className="w-4 h-4" /> 审核成功（演示）
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 提交联系人及资质信息弹窗 */}
        {showSupplierInfo && (
          <SupplierInfoModal
            contactInfo={contactInfo}
            qualFiles={qualFiles}
            onClose={() => setShowSupplierInfo(false)}
            onSubmit={(c, q) => { setContactInfo(c); setQualFiles(q); setSupplierStatus('pending'); setShowSupplierInfo(false); }}
          />
        )}
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <h1 className="text-lg font-bold text-slate-800">装备采购管理</h1>

      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {stats.map((s, i) => (
          <div key={i} className="bg-white rounded-xl p-4 border border-slate-200 shadow-police">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center mb-2" style={{ background: s.bg === 'bg-purple-50' ? '#f3e8ff' : s.bg === 'bg-pink-50' ? '#fce7f3' : s.bg === 'bg-[#e8ecf5]' ? '#d4dcee' : s.bg === 'bg-green-50' ? '#dcfce7' : '#fef9c3' }}>
              {s.icon}
            </div>
            <p className="text-xs text-slate-500">{s.label}</p>
            <p className="text-base font-bold text-slate-800 mt-0.5">{s.value}</p>
          </div>
        ))}
      </div>

      {/* 功能模块 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {modules.map(m => (
          <button key={m.key} onClick={() => setActiveModule(m.key)}
            className={`flex items-center gap-4 p-5 bg-white rounded-xl border-2 transition-all text-left hover:shadow-md ${activeModule === m.key ? m.color : 'border-slate-200 hover:border-slate-300'}`}>
            <div className="w-12 h-12 rounded-xl bg-[#f0f3fa] flex items-center justify-center flex-shrink-0">{m.icon}</div>
            <div className="flex-1">
              <div className="flex items-center gap-2"><h3 className="text-base font-bold text-slate-800">{m.label}</h3><span className="w-5 h-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center font-bold">{m.count}</span></div>
              <p className="text-xs text-slate-500 mt-0.5">{m.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* ====== 合同管理 ====== */}
      {activeModule === 'contract' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => setShowContractModal(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c]"><Plus className="w-4 h-4" /> 新增合同</button>
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 space-y-3">
            <div className="flex flex-wrap items-center gap-3">
              <div className="flex items-center gap-2">
                <span className="text-sm text-slate-600 whitespace-nowrap">签订时间:</span>
                <input type="date" value={contractSearch.startDate} onChange={e => setContractSearch(p => ({ ...p, startDate: e.target.value }))}
                  className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none" />
                <span className="text-sm text-[#8a9bc4]">~</span>
                <input type="date" value={contractSearch.endDate} onChange={e => setContractSearch(p => ({ ...p, endDate: e.target.value }))}
                  className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <div className="flex-1 min-w-[200px] relative">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8a9bc4]" />
                <input type="text" placeholder="搜索甲方/乙方/合同名称（空格分隔多关键词）"
                  value={contractSearch.keywords} onChange={e => setContractSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setContractSearch({ keywords: '', startDate: '', endDate: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-[#f0f3fa]">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-[#f0f3fa] border-b border-slate-200">
                  <th className="px-4 py-3 text-left font-semibold text-slate-700 w-10"><input type="checkbox" className="rounded" /></th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">甲方</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">乙方</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">合同名称</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">合同金额</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">签订日期</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">最终交货日期</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">备注</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-700">操作</th>
                </tr></thead>
                <tbody>{filteredContracts.map((c, i) => (
                  <tr key={i} className="border-b border-slate-100 hover:bg-[#e8ecf5]/30 transition-colors">
                    <td className="px-4 py-3"><input type="checkbox" className="rounded" /></td>
                    <td className="px-4 py-3 text-slate-600">
                      <HighlightText text={unitLabelMap[c.partyA] || c.partyA} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 text-slate-600">
                      <HighlightText text={c.partyB} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 font-medium text-slate-800">
                      <HighlightText text={c.name} query={contractSearch.keywords} />
                    </td>
                    <td className="px-4 py-3 text-slate-800 font-medium">¥{Number(c.amount).toLocaleString()}</td>
                    <td className="px-4 py-3 text-slate-500">{c.signDate}</td>
                    <td className="px-4 py-3 text-slate-500">{c.deliveryDate}</td>
                    <td className="px-4 py-3 text-slate-500 max-w-[150px] truncate" title={c.note}>{c.note || '-'}</td>
                    <td className="px-4 py-3">{contractActions(c)}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <Pagination total={filteredContracts.length} />
          </div>
        </div>
      )}

      {/* ====== 订单管理 ====== */}
      {activeModule === 'order' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => { setOrderPrefill(null); setShowOrderModal(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c]"><Plus className="w-4 h-4" /> 新增订单</button>
            <button onClick={() => { setShipmentPrefillOrder(null); setShowCreateShipment(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"><Plus className="w-4 h-4" /> 新增发货单</button>
            {selectedOrderId && (
              <button onClick={() => setImportAcceptanceTarget({ type: 'order', id: selectedOrderId })}
                className="flex items-center gap-2 px-4 py-2.5 text-sm font-medium text-green-700 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200 transition-colors">
                <FileCheck className="w-4 h-4" /> 导入整单验收单
              </button>
            )}
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-3">
              <select value={orderSearch.contractId} onChange={e => setOrderSearch(p => ({ ...p, contractId: e.target.value }))}
                className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none min-w-[140px]">
                <option value="">关联合同</option>
                {contracts.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <select value={orderSearch.receiver} onChange={e => setOrderSearch(p => ({ ...p, receiver: e.target.value }))}
                className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none min-w-[140px]">
                <option value="">收货对象</option>
                <option value="GD">广东省</option>
                <option value="HN">湖南省</option>
                <option value="JS">江苏省</option>
                <option value="ZJ">浙江省</option>
              </select>
              <div className="relative flex-1 min-w-[200px]">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8a9bc4]" />
                <input type="text" placeholder="搜索订单名称（空格分隔多关键词）"
                  value={orderSearch.keywords} onChange={e => setOrderSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setOrderSearch({ keywords: '', contractId: '', receiver: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-[#f0f3fa]">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          {/* 左右分栏：左侧订单列表 + 右侧发货单详情 */}
          <div className="flex gap-4" style={{ minHeight: 500 }}>
            {/* 左侧：订单列表 */}
            <div className="w-[32%] bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col">
              <div className="px-4 py-3 bg-[#f0f3fa] border-b border-slate-200 font-semibold text-slate-700 text-sm">订单列表</div>
              <div className="flex-1 overflow-y-auto">
                {filteredOrders.map((o, i) => {
                  const totalItems = o.items.reduce((s, it) => s + it.quantity, 0);
                  const getDisplay = () => {
                    if (o.inspectStatus === 'inspecting') return `待验收 ${o.inspectedQty}/${totalItems}`;
                    if (o.inspectStatus === 'inspected') return `已验收 ${o.inspectedQty}/${totalItems}`;
                    if (o.shipStatus === 'pending') return `0/${totalItems}`;
                    return `${o.shippedQty}/${totalItems}`;
                  };
                  const isActive = selectedOrderId === o.id;
                  return (
                    <div key={i} onClick={() => setSelectedOrderId(o.id)}
                      className={`px-4 py-3 border-b border-slate-100 cursor-pointer transition-colors ${isActive ? 'bg-[#e8ecf5] border-l-4 border-l-[#1b2370]' : 'hover:bg-[#f8fafc] border-l-4 border-l-transparent'}`}>
                      <div className="flex items-center justify-between gap-2">
                        <div className="font-medium text-slate-800 text-sm truncate flex-1">
                          <HighlightText text={o.name} query={orderSearch.keywords} />
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button onClick={e => { e.stopPropagation(); setViewOrder(o); }} title="查看详情" className="p-1 hover:bg-[#d4dcee] rounded transition-colors">
                            <Eye className="w-3.5 h-3.5 text-[#3b4f9f]" />
                          </button>
                          {(o.shipStatus === 'pending' || o.shipStatus === 'partial') && (
                            <button onClick={e => { e.stopPropagation(); setShipmentPrefillOrder(o); setShowCreateShipment(true); }} title="发货" className="p-1 hover:bg-green-100 rounded transition-colors">
                              <Truck className="w-3.5 h-3.5 text-green-600" />
                            </button>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-1.5 text-xs text-slate-500">
                        <span className="truncate">{getContractName(o.contractId)}</span>
                        <span className="text-slate-300 flex-shrink-0">|</span>
                        <span className="truncate">{decodeUnitCode(o.receiver) || o.receiver}</span>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-400">
                        <span>创建：{o.createTime}</span>
                      </div>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-xs text-slate-600">{getDisplay()}</span>
                        <span className={`inline-block px-2 py-0.5 rounded text-xs ${o.shipStatus === 'pending' ? 'bg-[#e8ecf5] text-slate-500' : o.shipStatus === 'shipped' && o.inspectStatus === 'inspected' ? 'bg-green-100 text-green-700' : o.shipStatus === 'shipped' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>
                          {o.shipStatus === 'pending' ? '待发货' : o.inspectStatus === 'inspected' ? '已验收' : '已发货'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1.5 text-[11px] text-slate-500">
                        <span className="inline-flex items-center gap-1"><Truck className="w-3 h-3 text-[#3b4f9f]" /> 总发货：<strong className="text-[#1b2370]">{o.shippedQty}</strong></span>
                        <span className="text-slate-300">|</span>
                        <span className="inline-flex items-center gap-1"><Package className="w-3 h-3 text-green-600" /> 总入库：<strong className="text-green-700">{o.inspectedQty}</strong></span>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="px-4 py-2 border-t border-slate-200 text-xs text-slate-500">共 {filteredOrders.length} 条</div>
            </div>

            {/* 右侧：发货单详情 */}
            <div className="flex-1 bg-white rounded-xl border border-slate-200 overflow-hidden flex flex-col">
              <div className="px-4 py-3 bg-[#f0f3fa] border-b border-slate-200 font-semibold text-slate-700 text-sm flex items-center justify-between">
                <span>发货单详情</span>
                {selectedOrderId && (
                  <span className="text-xs font-normal text-slate-500">
                    {(() => {
                      const o = orders.find(x => x.id === selectedOrderId);
                      return o ? o.id : '';
                    })()}
                  </span>
                )}
              </div>
              <div className="flex-1 overflow-auto">
                {!selectedOrderId ? (
                  <div className="flex items-center justify-center h-48 text-slate-400 text-sm">请点击左侧订单查看发货单详情</div>
                ) : (() => {
                  const order = orders.find(x => x.id === selectedOrderId);
                  const records = shipmentRecords.filter(r => r.orderId === selectedOrderId);
                  if (!order) return <div className="flex items-center justify-center h-48 text-slate-400 text-sm">订单不存在</div>;
                  if (records.length === 0) return <div className="flex items-center justify-center h-48 text-slate-400 text-sm">该订单暂无发货单</div>;
                  return (
                    <div className="divide-y divide-slate-100">
                      {records.map(rec => {
                        const shipTotal = rec.items.reduce((s, it) => s + it.thisShipQty, 0);
                        return (
                        <div key={rec.id} className="p-4">
                          {/* 发货单头部 + 操作按钮 */}
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                              <span className="font-mono font-medium text-slate-700">{rec.id}</span>
                              <span>{rec.shipDate}</span>
                              <span>{rec.deliveryAddress}</span>
                              <span className="text-slate-400">{rec.remark}</span>
                            </div>
                            <div className="flex items-center gap-2 flex-shrink-0">
                              <button onClick={() => {}} className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#1b2370] bg-[#e8ecf5] hover:bg-[#d4dcee] rounded border border-[#c5cfe5] transition-colors">
                                <Upload className="w-3 h-3" /> 导入RFID编码/箱体码
                              </button>
                              <button onClick={() => setImportAcceptanceTarget({ type: 'shipment', id: rec.id })} className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-green-700 bg-green-50 hover:bg-green-100 rounded border border-green-200 transition-colors">
                                <FileCheck className="w-3 h-3" /> 导入验收单
                              </button>
                              <button onClick={() => setViewShipmentDoc(order)} className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-white bg-[#1b2370] hover:bg-[#2e3a8c] rounded transition-colors">
                                <FileText className="w-3 h-3" /> 打印发货单
                              </button>
                              {order && order.inspectStatus === 'inspecting' && (
                                <button onClick={() => setWithdrawOrder(order)} className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-amber-700 bg-amber-50 hover:bg-amber-100 rounded border border-amber-200 transition-colors">
                                  <RotateCcw className="w-3 h-3" /> 撤回
                                </button>
                              )}
                            </div>
                          </div>
                          {/* 发货单统计 */}
                          <div className="flex items-center gap-4 mb-2 px-1">
                            <span className="inline-flex items-center gap-1 text-[11px] text-slate-500"><Truck className="w-3 h-3 text-[#3b4f9f]" /> 本次发货：<strong className="text-[#1b2370]">{shipTotal}</strong></span>
                            <span className="inline-flex items-center gap-1 text-[11px] text-slate-500"><Package className="w-3 h-3 text-green-600" /> 入库数量：<strong className="text-green-700">{shipTotal}</strong></span>
                          </div>
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="bg-[#f8fafc] border-b border-slate-200">
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">装备名称</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">型号</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">装备编码</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">计量单位</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">是否整箱</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">RFID编码</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">箱体码</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">采购数量</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">本次发货</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">生产日期</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">有效期(月)</th>
                                  <th className="px-2 py-2 text-left font-semibold text-slate-700">有效期至</th>
                                </tr>
                              </thead>
                              <tbody>
                                {rec.items.map((item, idx) => {
                                  const missingRfid = item.rfidTags.length === 0;
                                  const missingBoxCode = item.isWholeBox && !item.boxCode;
                                  const hasWarning = missingRfid || missingBoxCode;
                                  return (
                                    <tr key={idx} className={`border-b border-slate-50 hover:bg-[#f8fafc] ${hasWarning ? 'bg-red-50' : ''}`}>
                                      <td className="px-2 py-2.5 font-medium text-slate-800">
                                        <div className="flex items-center gap-1.5">
                                          {item.name}
                                          {hasWarning && <span className="text-[10px] text-red-600 font-medium whitespace-nowrap border border-red-200 bg-red-50 px-1.5 py-0.5 rounded">未导入RFID编码/箱体码</span>}
                                        </div>
                                      </td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.model}</td>
                                      <td className="px-2 py-2.5 font-mono text-slate-600">{item.code}</td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.unit}</td>
                                      <td className="px-2 py-2.5">
                                        <span className={`inline-block px-2 py-0.5 rounded text-xs ${item.isWholeBox ? 'bg-green-100 text-green-700' : 'bg-[#e8ecf5] text-slate-500'}`}>
                                          {item.isWholeBox ? '是' : '否'}
                                        </span>
                                      </td>
                                      <td className="px-2 py-2.5">
                                        {item.rfidTags.length > 0 ? (
                                          <span className="font-mono text-slate-700 text-[10px]" title={item.rfidTags.join('\n')}>
                                            {item.rfidTags[0].slice(0, 20)}
                                            {item.rfidTags.length > 1 ? ` 等${item.rfidTags.length}条` : ''}
                                          </span>
                                        ) : (
                                          <span className="text-red-400 text-[10px] font-medium">-</span>
                                        )}
                                      </td>
                                      <td className="px-2 py-2.5">
                                        {item.boxCode ? (
                                          <span className="font-mono text-slate-700">{item.boxCode}</span>
                                        ) : (
                                          <span className="text-red-400 text-[10px] font-medium">{item.isWholeBox ? '未导入' : '-'}</span>
                                        )}
                                      </td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.orderedQty}</td>
                                      <td className="px-2 py-2.5 font-semibold text-[#1b2370]">{item.thisShipQty}</td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.productDate}</td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.expireMonths}</td>
                                      <td className="px-2 py-2.5 text-slate-600">{item.expireDate}</td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      );})}
                    </div>
                  );
                })()}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ====== 在用装备分类信息 ====== */}
      {activeModule === 'product' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <button onClick={() => { setTransferKeyword(''); setShowNewProduct(true); }}
              className="flex items-center gap-2 px-4 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700"><Plus className="w-4 h-4" /> 新品申报</button>
          </div>

          {/* 搜索区域 */}
          <div className="bg-white rounded-xl border border-slate-200 p-4">
            <div className="flex flex-wrap items-center gap-3">
              <select value={productSearch.cat3} onChange={e => setProductSearch(p => ({ ...p, cat3: e.target.value }))}
                className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none">
                <option value="">装备分类</option>
                {productCat3Options.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={productSearch.status} onChange={e => setProductSearch(p => ({ ...p, status: e.target.value }))}
                className="px-3 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none">
                <option value="">全部状态</option>
                <option value="已上架">已上架</option>
                <option value="待审">待审</option>
                <option value="已下架">已下架</option>
                <option value="草稿">草稿</option>
                <option value="审核未通过">审核未通过</option>
              </select>
              <div className="relative flex-1 min-w-[200px]">
                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#8a9bc4]" />
                <input type="text" placeholder="搜索装备名称/型号（空格分隔多关键词）"
                  value={productSearch.keywords} onChange={e => setProductSearch(p => ({ ...p, keywords: e.target.value }))}
                  className="w-full pl-10 pr-4 py-2 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm outline-none" />
              </div>
              <button onClick={() => setProductSearch({ keywords: '', cat3: '', status: '' })}
                className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-[#f0f3fa]">
                <RotateCcw className="w-4 h-4" /> 重置
              </button>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="bg-[#f0f3fa] border-b border-slate-200">
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">装备分类</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">装备名称</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">型号</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">装备编码</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">原厂商</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">计量单位</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">是否电池</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">保养周期</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">备注</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">状态</th>
                  <th className="px-3 py-3 text-left font-semibold text-slate-700">操作</th>
                </tr></thead>
                <tbody>{filteredProducts.map(p => (
                  <tr key={p.id} className="border-b border-slate-100 hover:bg-[#e8ecf5]/30 transition-colors">
                    <td className="px-3 py-3 text-slate-600">{p.cat3 || p.cat2 || p.cat1}</td>
                    <td className="px-3 py-3 font-medium text-slate-800">
                      <HighlightText text={p.name} query={productSearch.keywords} />
                    </td>
                    <td className="px-3 py-3 text-slate-600">
                      <HighlightText text={p.model} query={productSearch.keywords} />
                    </td>
                    <td className="px-3 py-3 text-slate-500">{p.code}</td>
                    <td className="px-3 py-3 text-slate-600 max-w-[120px] truncate" title={p.manufacturer}>{p.manufacturer}</td>
                    <td className="px-3 py-3 text-slate-600">{p.unit}</td>
                    <td className="px-3 py-3"><span className={`inline-block px-2 py-0.5 rounded text-xs ${p.hasBattery ? 'bg-green-100 text-green-700' : 'bg-[#e8ecf5] text-slate-500'}`}>{p.hasBattery ? '是' : '否'}</span></td>
                    <td className="px-3 py-3 text-slate-600">{p.hasBattery ? `${p.batteryCycle}个月` : '-'}</td>
                    <td className="px-3 py-3 text-slate-500 max-w-[100px] truncate">{p.note}</td>
                    <td className="px-3 py-3"><span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium ${statusTag(p.status)}`}>{p.status}</span></td>
                    <td className="px-3 py-3"><div className="flex items-center gap-2">
                      <button onClick={() => setShowDetail(p)} className="text-[#1b2370] hover:text-[#16205a]"><Eye className="w-4 h-4" /></button>
                      {p.status !== '已上架' && p.status !== '待审' && <button className="text-amber-600 hover:text-amber-800"><Pencil className="w-4 h-4" /></button>}
                      <button onClick={() => setProducts(prev => prev.filter(x => x.id !== p.id))} className="text-red-500 hover:text-red-700"><Trash2 className="w-4 h-4" /></button>
                    </div></td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
            <Pagination total={filteredProducts.length} />
          </div>
        </div>
      )}

      {/* ==================== 弹窗 ==================== */}
      {showRegister && <RegisterModal onClose={() => setShowRegister(false)} onAdd={setProducts} onGoNewProduct={goToNewProduct} />}
      {showNewProduct && <NewProductModal onClose={() => setShowNewProduct(false)} onAdd={setProducts} transferKeyword={transferKeyword} suppliers={supplierLibrary} />}
      {showProductPicker && <EquipmentPicker onClose={() => setShowProductPicker(false)} onConfirm={(picked) => { setProducts(prev => [...prev, ...picked.map(p => ({ ...p, id: Date.now().toString(), status: '待审', batteryCycle: 0, image: '', note: '' }))]); setShowProductPicker(false); }} onGoNewProduct={() => { setShowProductPicker(false); setShowNewProduct(true); }} />}
      {showDetail && <DetailModal product={showDetail} onClose={() => setShowDetail(null)} />}
      {showContractModal && <ContractModal onClose={() => setShowContractModal(false)} onAdd={setContracts} setConfirm={setConfirmModal} />}
      {viewContract && <ContractDetailModal contract={viewContract} orders={orders.filter(o => viewContract.orderIds.includes(o.id))} onClose={() => setViewContract(null)} onJumpToOrder={(_orderId) => { setActiveModule('order'); setViewContract(null); }} />}
      {viewShipmentDoc && (
        <ShipmentDocPreview order={viewShipmentDoc} onClose={() => setViewShipmentDoc(null)} />
      )}
      {withdrawOrder && (
        <WithdrawModal order={withdrawOrder} onClose={() => setWithdrawOrder(null)} onConfirm={() => { setOrders(prev => prev.map(o => o.id === withdrawOrder.id ? { ...o, inspectStatus: 'none' as const, inspectedQty: 0 } : o)); setWithdrawOrder(null); }} />
      )}
      {editOrder && (
        <OrderModal onClose={() => setEditOrder(null)} onSave={(updated) => { setOrders(prev => prev.map(o => o.id === updated.id ? updated : o)); setEditOrder(null); }} contracts={contracts} prefill={null} editOrder={editOrder} onGoNewProduct={() => { setEditOrder(null); setShowNewProduct(true); }} />
      )}
      {viewOrder && (
        <OrderDetailModal
          order={viewOrder}
          onClose={() => setViewOrder(null)}
          getContractName={getContractName}
          onShip={(order) => {
            setViewOrder(null);
            setShipmentPrefillOrder(order);
            setShowCreateShipment(true);
          }}
        />
      )}
      {showOrderModal && <OrderModal onClose={() => { setShowOrderModal(false); setOrderPrefill(null); }} onAdd={setOrders} contracts={contracts} prefill={orderPrefill} setConfirm={setConfirmModal} onGoNewProduct={() => { setShowOrderModal(false); setShowNewProduct(true); }} />}
      {confirmModal.open && <ConfirmModal message={confirmModal.message} onConfirm={confirmModal.onConfirm} onCancel={() => setConfirmModal(prev => ({ ...prev, open: false }))} />}
      {showCreateShipment && (
        <CreateShipmentModal
          orders={orders}
          contracts={contracts}
          prefillOrder={shipmentPrefillOrder}
          onClose={() => { setShowCreateShipment(false); setShipmentPrefillOrder(null); }}
        />
      )}
      {importAcceptanceTarget && (
        <ImportAcceptanceModal
          target={importAcceptanceTarget}
          onClose={() => setImportAcceptanceTarget(null)}
          onImport={(fileName) => {
            // 实际项目中这里会上传文件到后端
            console.log(`Imported acceptance sheet for ${importAcceptanceTarget.type} ${importAcceptanceTarget.id}: ${fileName}`);
          }}
        />
      )}
    </div>
  );
}

// ==================== 可编辑单价组件 ====================
function EditablePrice({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(value.replace('¥', '').replace(/,/g, ''));
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setVal(value.replace('¥', '').replace(/,/g, '')); }, [value]);
  useEffect(() => { if (editing && inputRef.current) inputRef.current.focus(); }, [editing]);

  const handleBlur = () => { setEditing(false); if (val && !isNaN(Number(val)) && Number(val) > 0) onChange(val); };
  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter') handleBlur(); };

  if (editing) {
    return (
      <div className="flex items-center gap-1">
        <span className="text-xs text-[#8a9bc4]">¥</span>
        <input ref={inputRef} type="number" value={val} onChange={e => setVal(e.target.value)}
          onBlur={handleBlur} onKeyDown={handleKeyDown}
          className="w-20 px-1.5 py-1 bg-white border border-[#5a6fad] rounded text-xs outline-none focus:ring-1 focus:ring-[#1b2370]/20" />
      </div>
    );
  }
  return (
    <button onClick={() => setEditing(true)} className="text-slate-800 font-medium hover:text-[#2e3a8c] hover:underline transition-colors text-left">{value}</button>
  );
}

// ==================== 分页 ====================
function Pagination({ total }: { total: number }) {
  return (
    <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200">
      <p className="text-xs text-slate-500">共 {total} 条</p>
      <div className="flex items-center gap-1">
        <button className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 text-[#8a9bc4] hover:bg-[#f0f3fa] text-xs">&lt;</button>
        <button className="w-8 h-8 flex items-center justify-center rounded bg-[#1b2370] text-white text-xs font-medium">1</button>
        <button className="w-8 h-8 flex items-center justify-center rounded border border-slate-200 text-slate-600 hover:bg-[#f0f3fa] text-xs">&gt;</button>
      </div>
    </div>
  );
}

// ==================== 装备库数据（供 EquipmentPicker 使用）====================
const productLibrary = [
  { cat1: '通信设备', cat2: '手持终端', cat3: '警用级', name: '手持对讲机', model: 'PD780G', code: 'SP009', unit: '台', price: 3200 },
  { cat1: '通信设备', cat2: '手持终端', cat3: '民用级', name: '手持对讲机', model: 'PD500', code: 'SP010', unit: '台', price: 800 },
  { cat1: '通信设备', cat2: '卫星通信', cat3: '便携型', name: '卫星电话', model: 'SAT-200', code: 'SP011', unit: '台', price: 12000 },
  { cat1: '监控设备', cat2: '执法记录', cat3: '高清型', name: '执法记录仪', model: 'DSJ-A7', code: 'SP012', unit: '台', price: 2500 },
  { cat1: '防护装备', cat2: '防弹装备', cat3: '三级防护', name: '防弹盾牌', model: 'FDP-3', code: 'SP013', unit: '个', price: 3200 },
];

// ==================== 装备选择弹窗 ====================
interface SelectedEquipRow {
  cat1: string; cat2: string; cat3: string;
  name: string; model: string; code: string;
  unit: string; price: number; hasBattery: boolean;
  batteryCycle: string;
  note: string;
}

// 自定义Radio组件 - 截图样式
function CustomRadio({ checked, onChange, label }: { checked: boolean; onChange: () => void; label: string }) {
  return (
    <label className="flex items-center gap-1 cursor-pointer select-none" onClick={onChange}>
      <span className={`relative w-3.5 h-3.5 rounded-full border flex items-center justify-center flex-shrink-0 ${checked ? 'border-blue-500' : 'border-slate-300'}`}>
        {checked && <span className="w-2 h-2 rounded-full bg-blue-500" />}
      </span>
      <span className="text-[11px] text-slate-600">{label}</span>
    </label>
  );
}

function EquipmentPicker({ onClose, onConfirm, onGoNewProduct }: { onClose: () => void; onConfirm: (items: OrderItem[]) => void; onGoNewProduct?: () => void; }) {
  const [cat1, setCat1] = useState(''); const [cat2, setCat2] = useState(''); const [cat3, setCat3] = useState('');
  const [searchName, setSearchName] = useState(''); const [searchQuery, setSearchQuery] = useState('');
  const [selected, setSelected] = useState<SelectedEquipRow[]>([
    { cat1: '通信设备', cat2: '卫星通信', cat3: '便携型', name: '卫星电话', model: 'SAT-200', code: 'SP011', unit: '台', price: 12000, hasBattery: true, batteryCycle: '24', note: '' },
    { cat1: '通信设备', cat2: '手持终端', cat3: '民用级', name: '手持对讲机', model: 'PD500', code: 'SP010', unit: '台', price: 800, hasBattery: false, batteryCycle: '', note: '' },
  ]);
  const cat2Options = cat1 ? Object.keys(categoryTree[cat1] || {}) : [];
  const cat3Options = cat1 && cat2 ? (categoryTree[cat1]?.[cat2] || []) : [];
  const results = useMemo(() => {
    let list = [...productLibrary];
    if (cat1) list = list.filter(p => p.cat1 === cat1); if (cat2) list = list.filter(p => p.cat2 === cat2); if (cat3) list = list.filter(p => p.cat3 === cat3);
    const kw = parseKeywords(searchQuery);
    if (kw.length > 0) list = list.filter(p => multiKeywordMatch(`${p.name} ${p.code}`, kw));
    return list;
  }, [cat1, cat2, cat3, searchQuery]);
  const isCodeSelected = (code: string) => selected.some(s => s.code === code);
  const toggleSelect = (item: typeof productLibrary[0]) => {
    setSelected(prev => {
      const exists = prev.some(s => s.code === item.code);
      if (exists) return prev.filter(s => s.code !== item.code);
      return [...prev, { cat1: item.cat1, cat2: item.cat2, cat3: item.cat3, name: item.name, model: item.model, code: item.code, unit: item.unit, price: item.price, hasBattery: false, batteryCycle: '', note: '' }];
    });
  };
  const updateSelected = (code: string, field: keyof SelectedEquipRow, value: string | boolean) => {
    setSelected(prev => prev.map(s => s.code === code ? { ...s, [field]: value } : s));
  };
  const handleSearch = () => setSearchQuery(searchName);
  const handleConfirm = () => {
    onConfirm(selected.map(s => ({ cat1: s.cat1, cat2: s.cat2, cat3: s.cat3, name: s.name, model: s.model, unit: s.unit, quantity: 1, price: s.price, code: s.code, tags: [] })));
  };
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '85vw', height: '85vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">商品信息登记</h3><button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          {/* 筛选条件 */}
          <div><p className="text-xs text-slate-500 mb-2">筛选条件</p><div className="grid grid-cols-3 gap-3">
            <select value={cat1} onChange={e => { setCat1(e.target.value); setCat2(''); setCat3(''); }} className="px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none"><option value="">一级分类</option>{Object.keys(categoryTree).map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={cat2} onChange={e => { setCat2(e.target.value); setCat3(''); }} disabled={!cat1} className={`px-4 py-3 border rounded-lg text-sm outline-none ${!cat1 ? 'bg-slate-50 text-slate-400 border-slate-200' : 'bg-white border-slate-200'}`}><option value="">请先选一级</option>{cat2Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={cat3} onChange={e => setCat3(e.target.value)} disabled={!cat2} className={`px-4 py-3 border rounded-lg text-sm outline-none ${!cat2 ? 'bg-slate-50 text-slate-400 border-slate-200' : 'bg-white border-slate-200'}`}><option value="">请先选二级</option>{cat3Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
          </div></div>
          {/* 装备名称搜索 */}
          <div><p className="text-xs text-slate-500 mb-2">装备名称</p><div className="flex gap-2"><div className="relative flex-1"><SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" /><input type="text" placeholder="输入名称，多关键词用空格分隔 如：头盔 防暴" value={searchName} onChange={e => setSearchName(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} className="w-full pl-9 pr-3 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-blue-500" /></div><button onClick={handleSearch} className="px-6 py-3 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors">搜索</button></div></div>
          {/* 匹配结果（多选） */}
          <div><p className="text-xs text-slate-500 mb-2">匹配结果（多选）</p><div className="border border-slate-200 rounded-lg overflow-hidden" style={{ maxHeight: '220px', overflowY: 'auto' }}>
            <table className="w-full text-xs"><thead className="sticky top-0 z-10"><tr className="bg-slate-50 border-b border-slate-200"><th className="px-3 py-2 text-left font-medium text-slate-600 w-8"></th><th className="px-3 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备编码</th></tr></thead>
              <tbody>{results.map((item) => { const sel = isCodeSelected(item.code); return (<tr key={item.code} onClick={() => toggleSelect(item)} className={`border-b border-slate-100 last:border-0 cursor-pointer transition-colors ${sel ? 'bg-blue-50/60' : 'hover:bg-slate-50'}`}><td className="px-3 py-2.5"><div className={`w-4 h-4 rounded-sm border flex items-center justify-center flex-shrink-0 transition-colors ${sel ? 'bg-blue-500 border-blue-500' : 'border-slate-300'}`}>{sel && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}</div></td><td className="px-3 py-2 text-slate-600">{item.cat1}</td><td className="px-3 py-2 text-slate-600">{item.cat2}</td><td className="px-3 py-2 text-slate-600">{item.cat3}</td><td className="px-3 py-2 font-medium text-slate-800">{item.name}</td><td className="px-3 py-2 text-slate-500 font-mono">{item.code}</td></tr>); })}</tbody>
            </table>
            {results.length === 0 && (
              <div className="p-6 text-center">
                <p className="text-sm text-slate-400 mb-3">未搜索到匹配装备</p>
                {onGoNewProduct && (
                  <button onClick={() => { onClose(); onGoNewProduct(); }} className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">
                    <Plus className="w-4 h-4" /> 新品申报
                  </button>
                )}
              </div>
            )}
          </div></div>
          {/* 已选X项 */}
          <p className="text-xs text-slate-500">已选 {selected.length} 项</p>
          {/* 已选商品表格 */}
          {selected.length > 0 && (<div><p className="text-xs text-slate-500 mb-2">已选商品</p><div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs"><thead><tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-2 py-2 text-left font-medium text-slate-600">一级分类</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">二级分类</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">三级分类</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">装备名称</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">型号</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">计量单位<span className="text-red-500">*</span></th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">参考单价<span className="text-red-500">*</span></th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">是否电池<span className="text-red-500">*</span></th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">备注</th>
              <th className="px-2 py-2 text-left font-medium text-slate-600">操作</th>
            </tr></thead>
            <tbody>{selected.map((s) => (<tr key={s.code} className="border-b border-slate-100 last:border-0">
              <td className="px-2 py-2 text-slate-600">{s.cat1}</td>
              <td className="px-2 py-2 text-slate-600">{s.cat2}</td>
              <td className="px-2 py-2 text-slate-600">{s.cat3}</td>
              <td className="px-2 py-2 font-medium text-slate-800">{s.name}</td>
              <td className="px-2 py-2.5"><input type="text" value={s.model} onChange={e => updateSelected(s.code, 'model', e.target.value)} className="w-24 px-2 py-1.5 border border-slate-200 rounded text-xs outline-none focus:border-blue-500 bg-white" /></td>
              <td className="px-2 py-2.5"><select value={s.unit} onChange={e => updateSelected(s.code, 'unit', e.target.value)} className="w-14 px-1 py-1.5 border border-slate-200 rounded text-xs outline-none bg-white">{unitOptions.map(u => <option key={u} value={u}>{u}</option>)}</select></td>
              <td className="px-2 py-2 text-blue-500 font-medium">&#165;{s.price.toLocaleString()}</td>
              <td className="px-2 py-2.5">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-600">
                    <CustomRadio checked={!s.hasBattery} onChange={() => updateSelected(s.code, 'hasBattery', false)} label="否" />
                    <CustomRadio checked={s.hasBattery} onChange={() => updateSelected(s.code, 'hasBattery', true)} label="是" />
                  </div>
                  {s.hasBattery && (
                    <div className="flex items-center gap-1">
                      <input type="text" value={s.batteryCycle} onChange={e => updateSelected(s.code, 'batteryCycle', e.target.value)} className="w-10 px-1 py-1 border border-slate-200 rounded text-xs text-center outline-none focus:border-blue-500" />
                      <span className="text-[11px] text-slate-500">月</span>
                    </div>
                  )}
                </div>
              </td>
              <td className="px-2 py-2.5"><input type="text" value={s.note} onChange={e => updateSelected(s.code, 'note', e.target.value)} placeholder="备注" className="w-16 px-2 py-1 border border-slate-200 rounded text-xs outline-none focus:border-blue-500 text-slate-600 placeholder:text-slate-300" /></td>
              <td className="px-2 py-2.5"><button onClick={() => setSelected(prev => prev.filter(x => x.code !== s.code))} className="text-red-500 hover:text-red-700 text-xs font-medium">移除</button></td>
            </tr>))}</tbody>
            </table>
          </div></div>)}
        </div>
        <div className="flex items-center justify-between px-5 py-3 border-t border-slate-200 bg-slate-50 flex-shrink-0">
          <span className="text-xs text-slate-500">共 {selected.length} 件商品</span>
          <div className="flex gap-3">
            <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
            <button onClick={handleConfirm} disabled={selected.length === 0} className="px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed">确认添加</button>
          </div>
        </div>
      </div>
    </div>
  );
}
function ContractModal({ onClose, onAdd, setConfirm }: { onClose: () => void; onAdd: React.Dispatch<React.SetStateAction<Contract[]>>; setConfirm: React.Dispatch<React.SetStateAction<{ open: boolean; message: string; onConfirm: () => void }>>; }) {
  const [form, setForm] = useState({ partyA: '', name: '', amount: '', signDate: '', deliveryDate: '', note: '', attachment: '' as string | File });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const update = (field: string, value: string) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const validate = () => { const e: Record<string, string> = {}; if (!form.partyA) e.partyA = '请选择甲方'; if (!form.name.trim()) e.name = '请输入合同名称'; if (!form.amount || isNaN(Number(form.amount)) || Number(form.amount) <= 0) e.amount = '请输入有效的合同金额'; if (!form.signDate) e.signDate = '请选择签订日期'; if (!form.deliveryDate) e.deliveryDate = '请选择最终交货日期'; setErrors(e); return Object.keys(e).length === 0; };
  const handleSubmit = () => { if (!validate()) return; setConfirm({ open: true, message: '提交后不可修改，请确认内容是否无误，如需修改请联系甲方', onConfirm: () => { const newContract: Contract = { id: `HT${Date.now().toString().slice(-8)}`, partyA: form.partyA, partyB: MY_COMPANY, name: form.name.trim(), amount: form.amount, signDate: form.signDate, deliveryDate: form.deliveryDate, note: form.note.trim(), attachment: typeof form.attachment === 'string' ? form.attachment : form.attachment.name || '', status: '草稿', orderIds: [] }; onAdd(prev => [newContract, ...prev]); setConfirm(prev => ({ ...prev, open: false })); onClose(); } }); };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">新增合同</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 甲方</label><PinyinSearchSelect value={form.partyA} onChange={(v) => update('partyA', v)} error={errors.partyA} />{errors.partyA && <p className="mt-1 text-red-500 text-xs">{errors.partyA}</p>}</div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 乙方</label><input type="text" value={MY_COMPANY} disabled className="w-full px-4 py-3 bg-[#e8ecf5] border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 合同名称</label><input type="text" placeholder="请输入合同名称" value={form.name} onChange={e => update('name', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.name ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.name && <p className="mt-1 text-red-500 text-xs">{errors.name}</p>}</div>
          <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 合同金额</label><div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#8a9bc4]">¥</span><input type="number" placeholder="请输入合同金额" value={form.amount} onChange={e => update('amount', e.target.value)} className={`w-full pl-8 pr-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.amount ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} /></div>{errors.amount && <p className="mt-1 text-red-500 text-xs">{errors.amount}</p>}</div>
          <div className="grid grid-cols-2 gap-3"><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 签订日期</label><input type="date" value={form.signDate} onChange={e => update('signDate', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.signDate ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.signDate && <p className="mt-1 text-red-500 text-xs">{errors.signDate}</p>}</div><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 最终交货日期</label><input type="date" value={form.deliveryDate} onChange={e => update('deliveryDate', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.deliveryDate ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.deliveryDate && <p className="mt-1 text-red-500 text-xs">{errors.deliveryDate}</p>}</div></div>
          <div><label className="block text-sm font-medium text-slate-700 mb-1.5">备注</label><textarea placeholder="请输入备注..." value={form.note} onChange={e => update('note', e.target.value)} rows={3} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f] resize-none" /></div>
          <div><label className="block text-sm font-medium text-slate-700 mb-1.5">合同文件</label><div onClick={() => { const el = document.getElementById('contract-attach') as HTMLInputElement; el?.click(); }} className="relative border-2 border-dashed rounded-xl p-4 cursor-pointer transition-all text-center border-slate-300 bg-[#f0f3fa]/50 hover:border-[#5a6fad] hover:bg-[#e8ecf5]/30"><input id="contract-attach" type="file" accept=".pdf,.doc,.docx,.jpg,.png" className="hidden" onChange={e => { if (e.target.files?.[0]) update('attachment', e.target.files[0].name); }} />{form.attachment ? (<div className="flex items-center justify-center gap-2"><FileText className="w-5 h-5 text-green-600" /><span className="text-sm text-slate-700 font-medium">{typeof form.attachment === 'string' ? form.attachment : ''}</span><button onClick={e => { e.stopPropagation(); update('attachment', ''); }} className="ml-auto p-1 hover:bg-red-100 rounded"><X className="w-4 h-4 text-red-500" /></button></div>) : (<div className="flex flex-col items-center gap-1"><Upload className="w-6 h-6 text-[#8a9bc4]" /><span className="text-xs text-slate-500">点击上传合同文件（PDF/Word/图片）</span></div>)}</div></div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button><button onClick={handleSubmit} className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">提交</button></div>
      </div>
    </div>
  );
}

// ==================== 合同详情弹窗 ====================
function ContractDetailModal({ contract, orders, onClose, onJumpToOrder }: { contract: Contract; orders: Order[]; onClose: () => void; onJumpToOrder: (_orderId: string) => void; }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">合同详情</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><FileText className="w-4 h-4 text-[#1b2370]" /> 基本信息</h4><div className="grid grid-cols-2 gap-3"><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">甲方</p><p className="text-sm font-medium text-slate-800">{unitLabelMap[contract.partyA] || contract.partyA}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">乙方</p><p className="text-sm font-medium text-slate-800">{contract.partyB}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">合同名称</p><p className="text-sm font-medium text-slate-800">{contract.name}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">合同金额</p><p className="text-sm font-medium text-[#2e3a8c]">¥{Number(contract.amount).toLocaleString()}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">签订日期</p><p className="text-sm font-medium text-slate-800">{contract.signDate}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">最终交货日期</p><p className="text-sm font-medium text-slate-800">{contract.deliveryDate}</p></div>{contract.attachment && (<div className="p-3 bg-[#f0f3fa] rounded-lg col-span-2 flex items-center gap-2"><FileText className="w-4 h-4 text-green-600" /><p className="text-xs text-slate-500">合同附件</p><p className="text-sm font-medium text-slate-800">{contract.attachment}</p></div>)}{contract.note && <div className="p-3 bg-[#f0f3fa] rounded-lg col-span-2"><p className="text-xs text-slate-500">备注</p><p className="text-sm text-slate-800">{contract.note}</p></div>}</div></div>
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><ClipboardList className="w-4 h-4 text-amber-600" /> 关联订单</h4>{orders.length === 0 ? (<div className="p-6 bg-[#f0f3fa] border border-slate-200 rounded-xl text-center"><p className="text-sm text-[#8a9bc4]">暂无关联订单</p></div>) : (<div className="space-y-2">{orders.map(o => (<div key={o.id} className="flex items-center justify-between p-3 bg-[#f0f3fa] rounded-lg border border-slate-200"><div className="grid grid-cols-3 gap-4 flex-1"><div><p className="text-xs text-slate-500">订单名称</p><p className="text-sm font-medium text-slate-800">{o.name}</p></div><div><p className="text-xs text-slate-500">预计送货日期</p><p className="text-sm text-slate-800">{o.deliveryDate}</p></div><div><p className="text-xs text-slate-500">收货对象</p><p className="text-sm text-slate-800">{decodeUnitCode(o.receiver) || o.receiver}</p></div></div><button onClick={() => onJumpToOrder(o.id)} className="ml-4 px-3 py-1.5 text-xs text-[#1b2370] bg-[#e8ecf5] hover:bg-[#d4dcee] rounded-md transition-colors">查看</button></div>))}</div>)}</div>
        </div>
      </div>
    </div>
  );
}

// ==================== 新增/填写订单弹窗 ====================
function OrderModal({ onClose, onAdd, onSave, contracts, prefill, editOrder, setConfirm, onGoNewProduct }: { onClose: () => void; onAdd?: React.Dispatch<React.SetStateAction<Order[]>>; onSave?: (o: Order) => void; contracts: Contract[]; prefill: { contractId?: string; receiver?: string } | null; editOrder?: Order | null; setConfirm?: React.Dispatch<React.SetStateAction<{ open: boolean; message: string; onConfirm: () => void }>>; onGoNewProduct?: () => void; }) {
  const isEdit = !!editOrder;
  const [form, setForm] = useState({ name: editOrder?.name || '', contractId: editOrder?.contractId || prefill?.contractId || '', supplier: MY_COMPANY, supplierCode: MY_SUPPLIER_CODE, deliveryDate: editOrder?.deliveryDate || '', receiver: editOrder?.receiver || prefill?.receiver || '', warrantyPeriod: editOrder?.warrantyPeriod || '', contactName: editOrder?.contactName || '', contactPhone: editOrder?.contactPhone || '' });
  const [items, setItems] = useState<OrderItem[]>(editOrder?.items || []); const [errors, setErrors] = useState<Record<string, string>>({}); const [showPicker, setShowPicker] = useState(false);
  useEffect(() => { if (!isEdit && prefill?.contractId) { const c = contracts.find(ct => ct.id === prefill.contractId); setForm(prev => ({ ...prev, contractId: prefill.contractId || '', receiver: prefill.receiver || c?.partyA || '' })); } }, [prefill, contracts, isEdit]);
  const update = (field: string, value: string) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const handleContractChange = (contractId: string) => { const c = contracts.find(ct => ct.id === contractId); setForm(prev => ({ ...prev, contractId, receiver: c?.partyA || prev.receiver })); };
  const handleAddFromPicker = (picked: OrderItem[]) => { setItems(prev => [...prev, ...picked.map(p => ({ ...p, hasBattery: false, batteryCycle: 0 }))]); setShowPicker(false); };
  const removeItem = (idx: number) => setItems(prev => prev.filter((_, i) => i !== idx));
  const updateItemField = (idx: number, field: 'price' | 'quantity', value: number) => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, [field]: value } : it)); };
  const totalAmount = items.reduce((s, it) => s + (it.price || 0) * it.quantity, 0);
  const validate = () => { const e: Record<string, string> = {}; if (!form.receiver) e.receiver = '请选择收货对象'; if (items.length === 0) e.items = '请至少添加一条装备信息'; setErrors(e); return Object.keys(e).length === 0; };
  const handleSubmit = () => { if (!validate()) return; if (isEdit && onSave) { onSave({ ...editOrder, name: form.name.trim(), contractId: form.contractId, deliveryDate: form.deliveryDate, receiver: form.receiver, warrantyPeriod: form.warrantyPeriod ? Number(form.warrantyPeriod) : undefined, contactName: form.contactName, contactPhone: form.contactPhone, items }); onClose(); } else if (onAdd && setConfirm) { setConfirm({ open: true, message: '提交后不可修改，请确认内容是否无误，如需修改请联系甲方', onConfirm: () => { const now = new Date(); const createTime = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')} ${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}:${String(now.getSeconds()).padStart(2,'0')}`; const newOrder: Order = { id: `DD${Date.now().toString().slice(-8)}`, name: form.name.trim() || `订单-${Date.now().toString().slice(-4)}`, contractId: form.contractId, supplier: form.supplier, supplierCode: form.supplierCode, deliveryDate: form.deliveryDate, receiver: form.receiver, items: items.map(it => ({ ...it, hasBattery: it.hasBattery ?? false, batteryCycle: it.batteryCycle ?? 0 })), shipStatus: 'pending', shippedQty: 0, inspectStatus: 'none', inspectedQty: 0, createTime, warrantyPeriod: form.warrantyPeriod ? Number(form.warrantyPeriod) : undefined, contactName: form.contactName, contactPhone: form.contactPhone }; onAdd(prev => [newOrder, ...prev]); setConfirm(prev => ({ ...prev, open: false })); onClose(); } }); } };
  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
        <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
          <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">{isEdit ? '编辑订单' : prefill?.contractId ? '填写订单' : '新增订单'}</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
          <div className="p-5 space-y-4 overflow-y-auto flex-1">
            <div><h4 className="text-xs font-medium text-slate-500 mb-2">基本信息</h4><div className="grid grid-cols-2 gap-3"><div><label className="block text-sm font-medium text-slate-700 mb-1.5">订单名称</label><input type="text" placeholder="请输入订单名称" value={form.name} onChange={e => update('name', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">关联合同</label><select value={form.contractId} onChange={e => handleContractChange(e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]"><option value="">请选择关联合同</option>{contracts.map(c => <option key={c.id} value={c.id}>{c.id} - {c.name}</option>)}</select></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">供应商 <span className="text-[#8a9bc4] font-normal">（自动填入）</span></label><input type="text" value={form.supplier} disabled className="w-full px-4 py-3 bg-[#e8ecf5] border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">供应商企业编码 <span className="text-[#8a9bc4] font-normal">（自动填入）</span></label><input type="text" value={form.supplierCode} disabled className="w-full px-4 py-3 bg-[#e8ecf5] border border-slate-200 rounded-lg text-sm text-slate-500 cursor-not-allowed" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">预计送货日期</label><input type="date" value={form.deliveryDate} onChange={e => update('deliveryDate', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div><div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 收货对象</label><UnitCodeTreeSelect value={form.receiver} onChange={(v) => update('receiver', v)} error={errors.receiver} />{errors.receiver && <p className="mt-1 text-red-500 text-xs">{errors.receiver}</p>}</div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">联系人</label><input type="text" placeholder="请输入联系人" value={form.contactName || ''} onChange={e => update('contactName', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">联系电话</label><input type="tel" placeholder="请输入联系电话" maxLength={11} value={form.contactPhone || ''} onChange={e => update('contactPhone', e.target.value.replace(/\D/g, ''))} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div><div><label className="block text-sm font-medium text-slate-700 mb-1.5">质保期（月）</label><input type="number" min={1} placeholder="请输入质保期（月）" value={form.warrantyPeriod || ''} onChange={e => update('warrantyPeriod', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div></div></div>
            <div><div className="flex items-center justify-between mb-2"><h4 className="text-xs font-medium text-slate-500">装备信息</h4><button onClick={() => setShowPicker(true)} className="flex items-center gap-1 px-3 py-1.5 bg-[#e8ecf5] text-[#2e3a8c] rounded-md text-xs font-medium hover:bg-[#d4dcee] transition-colors"><Plus className="w-3 h-3" /> 添加装备</button></div>{errors.items && <p className="text-xs text-red-500 mb-2">{errors.items}</p>}{items.length === 0 ? (<div className="p-6 bg-[#f0f3fa] border border-slate-200 rounded-xl text-center"><p className="text-sm text-[#8a9bc4]">暂无装备信息，点击"添加装备"按钮添加</p></div>) : (<div className="border border-slate-200 rounded-lg overflow-hidden"><table className="w-full text-xs"><thead><tr className="bg-[#f0f3fa] border-b border-slate-200"><th className="px-2 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-2 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-2 py-2 text-left font-medium text-slate-600">型号</th><th className="px-2 py-2 text-left font-medium text-slate-600">装备编码</th><th className="px-2 py-2 text-left font-medium text-slate-600">计量单位</th><th className="px-2 py-2 text-left font-medium text-slate-600">单价</th><th className="px-2 py-2 text-left font-medium text-slate-600">数量</th><th className="px-2 py-2 text-left font-medium text-slate-600">金额</th><th className="px-2 py-2 text-left font-medium text-slate-600">生产日期</th><th className="px-2 py-2 text-left font-medium text-slate-600">质保期(月)</th><th className="px-2 py-2 text-left font-medium text-slate-600">是否电池<span className="text-red-500">*</span></th><th className="px-2 py-2 text-left font-medium text-slate-600">保养周期</th><th className="px-2 py-2 text-left font-medium text-slate-600 w-12">操作</th></tr></thead><tbody>{items.map((item, idx) => { const amount = (item.price || 0) * item.quantity; return (<tr key={idx} className="border-b border-slate-100 last:border-0"><td className="px-2 py-2 text-slate-600">{item.cat1}</td><td className="px-2 py-2 text-slate-600">{item.cat2}</td><td className="px-2 py-2 text-slate-600">{item.cat3}</td><td className="px-2 py-2 font-medium text-slate-800">{item.name}</td><td className="px-2 py-2 text-slate-500">{item.model}</td><td className="px-2 py-2 text-slate-500 font-mono">{item.code}</td><td className="px-2 py-2 text-slate-600">{item.unit}</td><td className="px-2 py-2"><div className="flex items-center gap-0.5"><span className="text-xs text-[#8a9bc4]">¥</span><input type="number" min={0} value={item.price || 0} onChange={e => updateItemField(idx, 'price', Number(e.target.value))} className="w-16 px-1 py-0.5 bg-white border border-slate-200 rounded text-xs outline-none focus:ring-1 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div></td><td className="px-2 py-2"><input type="number" min={1} value={item.quantity} onChange={e => updateItemField(idx, 'quantity', Number(e.target.value))} className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-xs outline-none focus:ring-1 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f] text-center" /></td><td className="px-2 py-2 text-[#2e3a8c] font-medium">¥{amount.toLocaleString()}</td><td className="px-2 py-2"><input type="date" value={item.productDate || ''} onChange={e => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, productDate: e.target.value } : it)); }} className="w-24 px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px] outline-none focus:ring-1 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></td><td className="px-2 py-2"><input type="number" min={1} value={item.warrantyPeriod || ''} onChange={e => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, warrantyPeriod: Number(e.target.value) } : it)); }} className="w-12 px-1 py-0.5 bg-white border border-slate-200 rounded text-[10px] outline-none focus:ring-1 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f] text-center" /></td><td className="px-2 py-2"><div className="flex items-center gap-1.5 text-[11px]"><label className="flex items-center gap-0.5 cursor-pointer whitespace-nowrap"><input type="radio" name={`batt-${idx}`} checked={!item.hasBattery} onChange={() => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, hasBattery: false, batteryCycle: 0 } : it)); }} className="w-3 h-3 accent-[#1b2370]" />否</label><label className="flex items-center gap-0.5 cursor-pointer whitespace-nowrap"><input type="radio" name={`batt-${idx}`} checked={item.hasBattery} onChange={() => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, hasBattery: true, batteryCycle: it.batteryCycle || 12 } : it)); }} className="w-3 h-3 accent-[#1b2370]" />是</label></div></td><td className="px-2 py-2">{item.hasBattery ? (<div className="flex items-center gap-1"><input type="number" min={1} value={item.batteryCycle || ''} onChange={e => { setItems(prev => prev.map((it, i) => i === idx ? { ...it, batteryCycle: Number(e.target.value) } : it)); }} className="w-10 px-1 py-1 border border-slate-200 rounded text-xs text-center outline-none focus:border-blue-500" /><span className="text-[11px] text-slate-500">月</span></div>) : <span className="text-slate-400">-</span>}</td><td className="px-2 py-2"><button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700"><Trash2 className="w-3.5 h-3.5" /></button></td></tr>); })}</tbody></table>{items.length > 0 && (<div className="px-3 py-2 bg-[#f0f3fa] border-t border-slate-200 text-right"><span className="text-xs text-slate-500">合计金额：</span><span className="text-sm font-bold text-[#2e3a8c]">¥{totalAmount.toLocaleString()}</span></div>)}</div>)}</div>
          </div>
          <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button><button onClick={handleSubmit} disabled={items.length === 0} className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors disabled:opacity-50 disabled:cursor-not-allowed">{isEdit ? '保存' : '提交'}</button></div>
        </div>
      </div>
      {showPicker && <EquipmentPicker onClose={() => setShowPicker(false)} onConfirm={handleAddFromPicker} onGoNewProduct={() => { setShowPicker(false); onGoNewProduct?.(); }} />}
    </>
  );
}

// ==================== 订单详情弹窗 ====================
function OrderDetailModal({ order, onClose, getContractName, onShip }: { order: Order; onClose: () => void; getContractName: (id: string) => string; onShip?: (order: Order) => void; }) {
  const totalAmount = order.items.reduce((s, it) => s + (it.price || 0) * it.quantity, 0);
  const records = shipmentRecords.filter(r => r.orderId === order.id);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '75vw', height: '75vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">订单详情</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-5 overflow-y-auto flex-1">
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><ClipboardList className="w-4 h-4 text-[#1b2370]" /> 基本信息</h4><div className="grid grid-cols-3 gap-3"><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">订单名称</p><p className="text-sm font-medium text-slate-800">{order.name}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">关联合同</p><p className="text-sm font-medium text-slate-800">{order.contractId} {getContractName(order.contractId) ? `- ${getContractName(order.contractId)}` : ''}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">供应商</p><p className="text-sm font-medium text-slate-800">{order.supplier}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">企业编码</p><p className="text-sm font-medium text-slate-800">{order.supplierCode}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">预计送货日期</p><p className="text-sm font-medium text-slate-800">{order.deliveryDate || '-'}</p></div><div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">收货对象</p><p className="text-sm font-medium text-slate-800">{decodeUnitCode(order.receiver) || order.receiver}</p></div><div className="p-3 bg-[#e8ecf5] rounded-lg border border-[#c5cfe5]"><p className="text-xs text-[#3b4f9f] flex items-center gap-1"><Truck className="w-3 h-3" /> 总发货数量</p><p className="text-sm font-bold text-[#1b2370]">{order.shippedQty}</p></div><div className="p-3 bg-green-50 rounded-lg border border-green-200"><p className="text-xs text-green-700 flex items-center gap-1"><Package className="w-3 h-3" /> 总入库数量</p><p className="text-sm font-bold text-green-800">{order.inspectedQty}</p></div></div></div>
          <div><h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><Package className="w-4 h-4 text-green-600" /> 装备信息</h4><div className="border border-slate-200 rounded-lg overflow-hidden"><table className="w-full text-xs"><thead><tr className="bg-[#f0f3fa] border-b border-slate-200"><th className="px-3 py-2 text-left font-medium text-slate-600">一级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">二级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">三级分类</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备名称</th><th className="px-3 py-2 text-left font-medium text-slate-600">型号</th><th className="px-3 py-2 text-left font-medium text-slate-600">装备编码</th><th className="px-3 py-2 text-left font-medium text-slate-600">计量单位</th><th className="px-3 py-2 text-left font-medium text-slate-600">单价</th><th className="px-3 py-2 text-left font-medium text-slate-600">数量</th><th className="px-3 py-2 text-left font-medium text-slate-600">金额</th><th className="px-3 py-2 text-left font-medium text-slate-600">是否电池</th><th className="px-3 py-2 text-left font-medium text-slate-600">保养周期</th></tr></thead><tbody>{order.items.map((item, idx) => { const amount = (item.price || 0) * item.quantity; return (<tr key={idx} className="border-b border-slate-100 last:border-0 hover:bg-[#e8ecf5]/30"><td className="px-3 py-2 text-slate-600">{item.cat1}</td><td className="px-3 py-2 text-slate-600">{item.cat2}</td><td className="px-3 py-2 text-slate-600">{item.cat3}</td><td className="px-3 py-2 font-medium text-slate-800">{item.name}</td><td className="px-3 py-2.5 text-slate-500">{item.model}</td><td className="px-3 py-2 text-slate-500 font-mono">{item.code}</td><td className="px-3 py-2.5 text-slate-600">{item.unit}</td><td className="px-3 py-2.5 text-slate-700">¥{(item.price || 0).toLocaleString()}</td><td className="px-3 py-2.5 text-slate-700 font-medium">{item.quantity}</td><td className="px-3 py-2.5 text-[#2e3a8c] font-medium">¥{amount.toLocaleString()}</td><td className="px-3 py-2.5"><span className={`inline-block px-2 py-0.5 rounded text-xs ${item.hasBattery ? 'bg-green-100 text-green-700' : 'bg-[#e8ecf5] text-slate-500'}`}>{item.hasBattery ? '是' : '否'}</span></td><td className="px-3 py-2.5 text-slate-600">{item.hasBattery ? `${item.batteryCycle}个月` : '-'}</td></tr>); })}</tbody></table></div><div className="mt-2 text-right"><span className="text-xs text-slate-500">合计金额：</span><span className="text-base font-bold text-[#2e3a8c]">¥{totalAmount.toLocaleString()}</span></div></div>
          {/* 发货明细 */}
          {records.length > 0 && <ShipmentDetailSection records={records} />}
        </div>
        {onShip && order.shipStatus !== 'shipped' && (<div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">关闭</button><button onClick={() => { onClose(); onShip(order); }} className="px-5 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">发货</button></div>)}
      </div>
    </div>
  );
}

// ==================== 发货明细展示组件 ====================
function ShipmentDetailSection({ records }: { records: ShipmentRecord[] }) {
  const [expandedRfids, setExpandedRfids] = useState<Record<string, boolean>>({});
  const toggleRfid = (key: string) => setExpandedRfids(prev => ({ ...prev, [key]: !prev[key] }));
  return (
    <div>
      <h4 className="text-sm font-bold text-slate-800 mb-3 flex items-center gap-2"><Truck className="w-4 h-4 text-orange-600" /> 发货明细</h4>
      <div className="space-y-3">
        {records.map(rec => (
          <div key={rec.id} className="border border-slate-200 rounded-lg overflow-hidden">
            {/* 发货单头部 */}
            <div className="bg-orange-50 px-4 py-2.5 flex items-center gap-6 text-xs flex-wrap">
              <span className="font-medium text-slate-700">发货单号：<span className="text-slate-900 font-mono">{rec.id}</span></span>
              <span className="text-slate-500">发货日期：<span className="text-slate-700">{rec.shipDate}</span></span>
              {rec.remark && <span className="text-slate-500">备注：<span className="text-slate-700">{rec.remark}</span></span>}
            </div>
            {/* 发货明细表格 */}
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead><tr className="bg-[#f0f3fa] border-b border-slate-200">
                  <th className="px-3 py-2 text-left font-medium text-slate-600">装备名称</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">型号</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">装备编码</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">计量单位</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">是否整箱</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">箱体码</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">采购数量</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">本次发货</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">生产日期</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">有效期(月)</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">有效期至</th>
                  <th className="px-3 py-2 text-left font-medium text-slate-600">RFID</th>
                </tr></thead>
                <tbody>
                  {rec.items.map((item, idx) => {
                    const rfidKey = `${rec.id}-${idx}`;
                    const rfidExpanded = expandedRfids[rfidKey];
                    return (
                      <tr key={idx} className="border-b border-slate-100 last:border-0 hover:bg-[#e8ecf5]/30">
                        <td className="px-3 py-2 font-medium text-slate-800">{item.name}</td>
                        <td className="px-3 py-2.5 text-slate-500">{item.model}</td>
                        <td className="px-3 py-2 text-slate-500 font-mono">{item.code}</td>
                        <td className="px-3 py-2.5 text-slate-600">{item.unit}</td>
                        <td className="px-3 py-2.5"><span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-medium ${item.isWholeBox ? 'bg-green-100 text-green-700' : 'bg-[#e8ecf5] text-slate-600'}`}>{item.isWholeBox ? '是' : '否'}</span></td>
                        <td className="px-3 py-2.5">{item.boxCode ? <span className="font-mono text-slate-700">{item.boxCode}</span> : <span className="text-slate-400">-</span>}</td>
                        <td className="px-3 py-2.5 text-slate-700">{item.orderedQty}</td>
                        <td className="px-3 py-2.5 font-bold text-[#2e3a8c]">{item.thisShipQty}</td>
                        <td className="px-3 py-2.5 text-slate-600">{item.productDate}</td>
                        <td className="px-3 py-2.5 text-slate-600">{item.expireMonths}</td>
                        <td className="px-3 py-2.5 text-slate-600">{item.expireDate}</td>
                        <td className="px-3 py-2.5">
                          <button onClick={() => toggleRfid(rfidKey)} className="flex items-center gap-1 text-[#1b2370] hover:text-[#16205a] transition-colors">
                            <span className="font-medium">{item.rfidTags.length}条</span>
                            <ChevronDown className={`w-3.5 h-3.5 transition-transform ${rfidExpanded ? 'rotate-180' : ''}`} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {/* RFID展开区域 */}
            {rec.items.map((item, idx) => {
              const rfidKey = `${rec.id}-${idx}`;
              if (!expandedRfids[rfidKey]) return null;
              return (
                <div key={`rfid-${idx}`} className="bg-[#f0f3fa] border-t border-slate-200 px-4 py-3">
                  <p className="text-[11px] font-medium text-slate-500 mb-2 flex items-center gap-1"><Package className="w-3 h-3" /> {item.name} ({item.model}) - RFID 编码列表</p>
                  <div className="grid grid-cols-2 gap-1.5">
                    {item.rfidTags.map((tag, tidx) => (
                      <span key={tidx} className="text-[11px] font-mono text-slate-600 bg-white border border-slate-200 rounded px-2 py-1">{tag}</span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

// ==================== 导入验收单弹窗 ====================
function ImportAcceptanceModal({ target, onClose, onImport }: { target: { type: 'contract' | 'shipment' | 'order'; id: string }; onClose: () => void; onImport: (fileName: string) => void; }) {
  const [fileName, setFileName] = useState('');
  const [confirmed, setConfirmed] = useState(false);

  const handleFileSelect = () => {
    const mockName = `验收单_${target.id}_${new Date().toISOString().slice(0, 10)}.pdf`;
    setFileName(mockName);
    setConfirmed(true);
  };

  const handleImport = () => {
    if (confirmed && fileName) {
      onImport(fileName);
      onClose();
    }
  };

  const titleMap = { contract: '导入合同验收单', shipment: '导入发货单验收单', order: '导入整单验收单' };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[480px] animate-fade-in overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200">
          <h3 className="text-base font-bold text-slate-800">{titleMap[target.type]}</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <FileCheck className="w-5 h-5 text-[#1b2370] flex-shrink-0" />
            <p className="text-sm text-[#1b2370]">目标：{target.id}</p>
          </div>

          <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-[#3b4f9f] cursor-pointer transition-colors bg-slate-50/50"
            onClick={handleFileSelect}>
            {confirmed ? (
              <div className="flex items-center justify-center gap-2">
                <CheckCircle2 className="w-6 h-6 text-green-600" />
                <div className="text-left">
                  <p className="text-sm text-green-700 font-medium">{fileName}</p>
                  <p className="text-xs text-slate-500">点击更换文件</p>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center gap-2">
                <Upload className="w-8 h-8 text-slate-400" />
                <p className="text-sm text-slate-600 font-medium">点击上传验收单</p>
                <p className="text-xs text-slate-400">支持 PDF、JPG、PNG 格式，单个文件不超过 20MB</p>
              </div>
            )}
          </div>

          {confirmed && (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <CheckCircle className="w-3.5 h-3.5 text-green-600" />
              <span>文件已确认，双方线下盖章后导入</span>
            </div>
          )}
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa]">
          <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
          <button onClick={handleImport} disabled={!confirmed}
            className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
            导入
          </button>
        </div>
      </div>
    </div>
  );
}

// ==================== 二次确认弹窗 ====================
function ConfirmModal({ message, onConfirm, onCancel }: { message: string; onConfirm: () => void; onCancel: () => void; }) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50" onClick={onCancel}>
      <div className="bg-white rounded-xl shadow-xl w-full max-w-md animate-fade-in p-5" onClick={e => e.stopPropagation()}>
        <div className="flex items-start gap-3 mb-4"><div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center flex-shrink-0"><AlertTriangle className="w-5 h-5 text-amber-600" /></div><div><h3 className="text-base font-bold text-slate-800 mb-1">确认提交</h3><p className="text-sm text-slate-600">{message}</p></div></div>
        <div className="flex justify-end gap-3"><button onClick={onCancel} className="px-4 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-[#f0f3fa] transition-colors">取消</button><button onClick={onConfirm} className="px-4 py-2 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">确认</button></div>
      </div>
    </div>
  );
}


// ==================== 登记装备弹窗 ====================
function RegisterModal({ onClose, onAdd, onGoNewProduct }: { onClose: () => void; onAdd: React.Dispatch<React.SetStateAction<Product[]>>; onGoNewProduct: (keyword: string) => void; }) {
  const [form, setForm] = useState({ name: '', model: '', code: '', cat1: '', cat2: '', cat3: '', unit: '台', price: '', hasBattery: false, batteryCycle: '12', note: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const update = (field: string, value: string | boolean) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const cat2Options = form.cat1 ? Object.keys(categoryTree[form.cat1] || {}) : [];
  const cat3Options = form.cat1 && form.cat2 ? (categoryTree[form.cat1]?.[form.cat2] || []) : [];
  const validate = () => { const e: Record<string, string> = {}; if (!form.name.trim()) e.name = '请输入装备名称'; if (!form.model.trim()) e.model = '请输入型号'; if (!form.code.trim()) e.code = '请输入装备编码'; if (!form.cat1) e.cat1 = '请选择一级分类'; if (!form.cat2) e.cat2 = '请选择二级分类'; if (!form.cat3) e.cat3 = '请选择三级分类'; setErrors(e); return Object.keys(e).length === 0; };
  const handleSubmit = () => { if (!validate()) return; const newProduct: Product = { id: Date.now().toString(), cat1: form.cat1, cat2: form.cat2, cat3: form.cat3, name: form.name.trim(), model: form.model.trim(), code: form.code.trim(), unit: form.unit, price: form.price ? `¥${parseFloat(form.price).toLocaleString()}` : '¥0', hasBattery: form.hasBattery, batteryCycle: parseInt(form.batteryCycle) || 0, note: form.note.trim(), image: '', status: '待审' }; onAdd(prev => [newProduct, ...prev]); onClose(); };
  const handleGoNew = () => { onClose(); onGoNewProduct(form.name.trim() || form.model.trim() || ''); };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '65vw', height: '70vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">登记装备</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-4 overflow-y-auto flex-1">
          <div className="grid grid-cols-3 gap-3">
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 装备名称</label><input type="text" placeholder="请输入装备名称" value={form.name} onChange={e => update('name', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.name ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.name && <p className="mt-1 text-red-500 text-xs">{errors.name}</p>}</div>
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 型号</label><input type="text" placeholder="请输入型号" value={form.model} onChange={e => update('model', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.model ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.model && <p className="mt-1 text-red-500 text-xs">{errors.model}</p>}</div>
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 装备编码</label><input type="text" placeholder="请输入装备编码" value={form.code} onChange={e => update('code', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.code ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.code && <p className="mt-1 text-red-500 text-xs">{errors.code}</p>}</div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 一级分类</label><select value={form.cat1} onChange={e => update('cat1', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.cat1 ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`}><option value="">请选择</option>{Object.keys(categoryTree).map(c => <option key={c} value={c}>{c}</option>)}</select>{errors.cat1 && <p className="mt-1 text-red-500 text-xs">{errors.cat1}</p>}</div>
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 二级分类</label><select value={form.cat2} onChange={e => update('cat2', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.cat2 ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`}><option value="">请选择</option>{cat2Options.map(c => <option key={c} value={c}>{c}</option>)}</select>{errors.cat2 && <p className="mt-1 text-red-500 text-xs">{errors.cat2}</p>}</div>
            <div><label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 三级分类</label><select value={form.cat3} onChange={e => update('cat3', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.cat3 ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`}><option value="">请选择</option>{cat3Options.map(c => <option key={c} value={c}>{c}</option>)}</select>{errors.cat3 && <p className="mt-1 text-red-500 text-xs">{errors.cat3}</p>}</div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div><label className="block text-sm font-medium text-slate-700 mb-1.5">计量单位</label><select value={form.unit} onChange={e => update('unit', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]">{unitOptions.map(u => <option key={u} value={u}>{u}</option>)}</select></div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1.5">价格</label><div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-[#8a9bc4]">¥</span><input type="number" placeholder="请输入价格" value={form.price} onChange={e => update('price', e.target.value)} className="w-full pl-8 pr-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div></div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1.5">电池质保周期(月)</label><input type="number" value={form.batteryCycle} onChange={e => update('batteryCycle', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" /></div>
          </div>
          <div className="flex items-center gap-2"><input type="checkbox" id="hasBattery" checked={form.hasBattery} onChange={e => update('hasBattery', e.target.checked)} className="w-4 h-4 rounded border-slate-300 text-[#1b2370]" /><label htmlFor="hasBattery" className="text-sm text-slate-700">是否含电池</label></div>
          <div><label className="block text-sm font-medium text-slate-700 mb-1.5">备注</label><textarea placeholder="请输入备注..." value={form.note} onChange={e => update('note', e.target.value)} rows={3} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f] resize-none" /></div>
          <div className="p-3 bg-[#e8ecf5] rounded-lg"><p className="text-xs text-[#1b2370]">提示：登记后装备将进入"待审"状态，审核通过后会自动上架。也可以直接点击"完善信息"前往新增装备页面填写更详细的信息。</p></div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0">
          <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
          <button onClick={handleGoNew} className="px-5 py-2.5 bg-[#e8ecf5] text-[#2e3a8c] border border-[#c5cfe5] rounded-lg text-sm font-medium hover:bg-[#d4dcee] transition-colors">完善信息</button>
          <button onClick={handleSubmit} className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">提交</button>
        </div>
      </div>
    </div>
  );
}

// ==================== 新增装备弹窗 ====================
// ==================== 供应商搜索选择组件 ====================
function SupplierSelect({ value, onChange, error, onAddNew, suppliers }: { value: string; onChange: (v: string) => void; error?: string; onAddNew?: () => void; suppliers: Supplier[] }) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  const selectedSupplier = suppliers.find(s => s.id === value);

  // 搜索过滤（支持多关键词，空格分隔）
  const keywords = useMemo(() => parseKeywords(search), [search]);
  const filtered = useMemo(() => {
    if (keywords.length === 0) return suppliers;
    return suppliers.filter(s => {
      const text = `${s.companyName} ${s.creditCode}`;
      return keywords.every(kw => text.toLowerCase().includes(kw.toLowerCase()));
    });
  }, [keywords, suppliers]);

  const hasExactMatch = filtered.length > 0;

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 100);
  }, [isOpen]);

  // 高亮匹配文字
  const HighlightMatch = ({ text, query }: { text: string; query: string }) => {
    if (!query.trim()) return <>{text}</>;
    const kw = parseKeywords(query);
    if (kw.length === 0) return <>{text}</>;
    const escaped = kw.map(k => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const regex = new RegExp(`(${escaped.join('|')})`, 'i');
    const splitRegex = new RegExp(`(${escaped.join('|')})`, 'i');
    const parts = text.split(splitRegex);
    return <>{parts.filter(Boolean).map((part, i) => kw.some(k => part.toLowerCase() === k.toLowerCase()) ? <span key={i} className="text-[#1b2370] font-bold bg-amber-100">{part}</span> : <span key={i}>{part}</span>)}</>;
  };

  return (
    <div ref={containerRef} className="relative">
      <div onClick={() => setIsOpen(!isOpen)}
        className={`w-full min-h-[46px] px-3 py-2 bg-white border rounded-lg text-sm transition-all outline-none cursor-pointer flex items-center gap-2 ${isOpen ? 'ring-2 ring-[#1b2370]/20 border-[#3b4f9f]' : error ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'}`}>
        {!selectedSupplier ? (
          <span className="text-slate-400">请输入企业名称或统一社会信用代码搜索</span>
        ) : (
          <>
            <Building2 className="w-4 h-4 text-[#1b2370] flex-shrink-0" />
            <span className="text-slate-700 font-medium flex-1 truncate">{selectedSupplier.companyName}</span>
            <button onClick={e => { e.stopPropagation(); onChange(''); }} className="p-0.5 hover:bg-red-100 rounded transition-colors flex-shrink-0">
              <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
            </button>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-slate-400 ml-auto transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </div>

      {isOpen && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          <div className="p-2 border-b border-slate-100">
            <div className="relative">
              <SearchIcon className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input ref={searchRef} type="text" placeholder="企业名称/统一社会信用代码（空格分隔多关键词）"
                value={search} onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" />
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto">
            {filtered.length > 0 ? (
              filtered.map(s => (
                <div key={s.id} onClick={() => { onChange(s.id); setIsOpen(false); setSearch(''); }}
                  className={`flex items-center gap-3 px-3 py-2.5 cursor-pointer transition-colors border-b border-slate-50 last:border-0 ${value === s.id ? 'bg-[#e8ecf5]' : 'hover:bg-slate-50'}`}>
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${value === s.id ? 'border-[#2e3a8c]' : 'border-slate-300'}`}>
                    {value === s.id && <div className="w-2 h-2 rounded-full bg-[#2e3a8c]" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-slate-700 truncate"><HighlightMatch text={s.companyName} query={search} /></p>
                    <p className="text-xs text-slate-400 font-mono mt-0.5"><HighlightMatch text={s.creditCode} query={search} /></p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center">
                <p className="text-sm text-slate-400 mb-3">未搜索到匹配供应商</p>
                {onAddNew && (
                  <button onClick={() => { setIsOpen(false); setSearch(''); onAddNew(); }} className="inline-flex items-center gap-2 px-4 py-2 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">
                    <Plus className="w-4 h-4" /> 新增供应商
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== 新增供应商弹窗 ====================
function AddSupplierModal({ onClose, onAdd }: { onClose: () => void; onAdd: (s: Supplier) => void; }) {
  const [form, setForm] = useState({ companyName: '', shortName: '', creditCode: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [verified, setVerified] = useState(false);

  const update = (field: string, value: string) => {
    setForm(p => ({ ...p, [field]: value }));
    setErrors(p => ({ ...p, [field]: '' }));
    setVerified(false);
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.companyName.trim()) e.companyName = '请输入企业名称';
    if (!form.creditCode.trim()) e.creditCode = '请输入统一社会信用代码';
    else if (!/^[A-Z0-9]{18}$/i.test(form.creditCode.trim())) e.creditCode = '统一社会信用代码为18位字母或数字';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleVerify = () => {
    if (form.creditCode.trim().length >= 5) {
      setVerified(true);
    }
  };

  const handleSubmit = () => {
    if (!validate()) return;
    const newSupplier: Supplier = {
      id: `S${Date.now().toString().slice(-6)}`,
      companyName: form.companyName.trim(),
      shortName: form.shortName.trim() || form.companyName.trim(),
      creditCode: form.creditCode.trim().toUpperCase(),
    };
    onAdd(newSupplier);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[520px] animate-fade-in overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200">
          <h3 className="text-base font-bold text-slate-800">新增供应商</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="p-6 space-y-5">
          <div>
            <h4 className="text-sm font-bold text-slate-800 mb-1">企业信息</h4>
            <p className="text-xs text-slate-400 mb-4">以下为企业注册信息</p>

            <div className="space-y-4">
              <div>
                <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 企业名称</label>
                <input type="text" placeholder="请输入企业名称" value={form.companyName} onChange={e => update('companyName', e.target.value)}
                  className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.companyName ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />
                {errors.companyName && <p className="mt-1 text-red-500 text-xs">{errors.companyName}</p>}
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">单位简称</label>
                <input type="text" placeholder="请输入单位简称" value={form.shortName} onChange={e => update('shortName', e.target.value)}
                  className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]" />
              </div>

              <div>
                <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 统一社会信用代码</label>
                <div className="flex gap-2">
                  <input type="text" placeholder="请输入统一社会信用代码" maxLength={18} value={form.creditCode} onChange={e => update('creditCode', e.target.value.replace(/[^a-zA-Z0-9]/g, '').toUpperCase())}
                    className={`flex-1 px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 font-mono uppercase ${errors.creditCode ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />
                  <button onClick={handleVerify} disabled={form.creditCode.trim().length < 5}
                    className={`px-4 py-3 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${verified ? 'bg-green-50 text-green-700 border border-green-200' : 'text-[#1b2370] bg-[#e8ecf5] border border-[#c5cfe5] hover:bg-[#d4dcee] disabled:opacity-50 disabled:cursor-not-allowed'}`}>
                    {verified ? '已验证' : '注册信息验证'}
                  </button>
                </div>
                {errors.creditCode && <p className="mt-1 text-red-500 text-xs">{errors.creditCode}</p>}
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa]">
          <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
          <button onClick={handleSubmit} className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">确定</button>
        </div>
      </div>
    </div>
  );
}

function NewProductModal({ onClose, onAdd, transferKeyword, suppliers }: { onClose: () => void; onAdd: React.Dispatch<React.SetStateAction<Product[]>>; transferKeyword: string; suppliers: Supplier[] }) {
  const [form, setForm] = useState({ name: transferKeyword || '', model: '', manufacturerId: '', cat1: '', cat2: '', cat3: '', unit: '台', hasBattery: false, note: '', images: [] as string[] });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showAddSupplier, setShowAddSupplier] = useState(false);
  const update = (field: string, value: string | boolean) => { setForm(prev => ({ ...prev, [field]: value })); setErrors(prev => ({ ...prev, [field]: '' })); };
  const cat2Options = form.cat1 ? Object.keys(categoryTree[form.cat1] || {}) : [];
  const cat3Options = form.cat1 && form.cat2 ? (categoryTree[form.cat1]?.[form.cat2] || []) : [];
  const validate = () => { const e: Record<string, string> = {}; if (!form.name.trim()) e.name = '请输入装备名称'; if (!form.model.trim()) e.model = '请输入型号'; if (form.images.length === 0) e.images = '请至少上传1张图片'; setErrors(e); return Object.keys(e).length === 0; };
  const handleImageUpload = () => {
    if (form.images.length >= 5) return;
    const newImg = `https://picsum.photos/seed/${Date.now()}/200/200`;
    setForm(prev => ({ ...prev, images: [...prev.images, newImg] }));
    setErrors(prev => ({ ...prev, images: '' }));
  };
  const removeImage = (idx: number) => setForm(prev => ({ ...prev, images: prev.images.filter((_, i) => i !== idx) }));
  const handleAddSupplier = (newSupplier: Supplier) => {
    // 将新供应商添加到库中，并自动选中
    supplierLibrary.push(newSupplier);
    setForm(prev => ({ ...prev, manufacturerId: newSupplier.id }));
  };
  const handleSubmit = () => { if (!validate()) return; const code = `SP${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`; const supplier = supplierLibrary.find(s => s.id === form.manufacturerId); const newProduct: Product = { id: Date.now().toString(), cat1: form.cat1 || '未分类', cat2: form.cat2 || '未分类', cat3: form.cat3 || '未分类', name: form.name.trim(), model: form.model.trim(), code, unit: form.unit, price: '\u00a50', hasBattery: form.hasBattery, batteryCycle: form.hasBattery ? 12 : 0, note: form.note.trim(), image: form.images[0] || '', status: '待审', manufacturer: supplier?.companyName || '' }; onAdd(prev => [newProduct, ...prev]); onClose(); };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl overflow-hidden animate-fade-in flex flex-col" style={{ width: '700px', maxHeight: '90vh' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0"><h3 className="text-base font-bold text-slate-800">新品申报</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-6 space-y-5 overflow-y-auto flex-1">
          {/* 建议分类（选填） */}
          <div><p className="text-xs text-slate-500 mb-2">建议分类（选填）</p><div className="grid grid-cols-3 gap-3">
            <select value={form.cat1} onChange={e => { update('cat1', e.target.value); update('cat2', ''); update('cat3', ''); }} className="px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none"><option value="">一级分类</option>{Object.keys(categoryTree).map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={form.cat2} onChange={e => { update('cat2', e.target.value); update('cat3', ''); }} disabled={!form.cat1} className={`px-4 py-3 border rounded-lg text-sm outline-none ${!form.cat1 ? 'bg-[#f0f3fa] text-[#8a9bc4] border-slate-200' : 'bg-white border-slate-200'}`}><option value="">请先选一级</option>{cat2Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={form.cat3} onChange={e => update('cat3', e.target.value)} disabled={!form.cat2} className={`px-4 py-3 border rounded-lg text-sm outline-none ${!form.cat2 ? 'bg-[#f0f3fa] text-[#8a9bc4] border-slate-200' : 'bg-white border-slate-200'}`}><option value="">请先选二级</option>{cat3Options.map(c => <option key={c} value={c}>{c}</option>)}</select>
          </div></div>
          {/* 基本信息（必填） */}
          <div><p className="text-xs text-slate-500 mb-3">基本信息（必填）</p><div className="space-y-3">
            <div><input type="text" placeholder="装备名称 *" value={form.name} onChange={e => update('name', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.name ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.name && <p className="mt-1 text-red-500 text-xs">{errors.name}</p>}</div>
            <div><input type="text" placeholder="型号 *" value={form.model} onChange={e => update('model', e.target.value)} className={`w-full px-4 py-3 bg-white border rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 ${errors.model ? 'border-red-300' : 'border-slate-200 focus:border-[#3b4f9f]'}`} />{errors.model && <p className="mt-1 text-red-500 text-xs">{errors.model}</p>}</div>
            <div><label className="block text-sm font-medium text-slate-700 mb-1.5">原厂商</label><SupplierSelect value={form.manufacturerId} onChange={(v) => update('manufacturerId', v)} onAddNew={() => setShowAddSupplier(true)} suppliers={suppliers} /></div>
            <div><select value={form.unit} onChange={e => update('unit', e.target.value)} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]">{unitOptions.map(u => <option key={u} value={u}>{u}</option>)}</select></div>
            <div><p className="text-sm text-slate-700 mb-2">是否电池 <span className="text-red-500">*</span></p><div className="flex items-center gap-4"><label className="flex items-center gap-1.5 text-sm cursor-pointer"><input type="radio" name="hasBattery" checked={!form.hasBattery} onChange={() => update('hasBattery', false)} className="w-4 h-4 text-[#1b2370]" /><span>否</span></label><label className="flex items-center gap-1.5 text-sm cursor-pointer"><input type="radio" name="hasBattery" checked={form.hasBattery} onChange={() => update('hasBattery', true)} className="w-4 h-4 text-[#1b2370]" /><span>是</span></label></div></div>
            <div><p className="text-sm text-slate-700 mb-2">图片上传 <span className="text-red-500">*</span> <span className="text-xs text-[#8a9bc4] font-normal">（至少1张，最多5张）</span></p>{errors.images && <p className="text-xs text-red-500 mb-1">{errors.images}</p>}<div className="flex gap-2 flex-wrap">
              {form.images.map((img, idx) => (<div key={idx} className="relative w-16 h-16 rounded-lg border border-slate-200 overflow-hidden"><img src={img} alt="" className="w-full h-full object-cover" /><button onClick={() => removeImage(idx)} className="absolute top-0.5 right-0.5 w-4 h-4 bg-red-500 text-white rounded-full flex items-center justify-center text-[10px]"><X className="w-3 h-3" /></button></div>))}
              {form.images.length < 5 && (<button onClick={handleImageUpload} className="w-16 h-16 border-2 border-dashed border-slate-300 rounded-lg flex flex-col items-center justify-center text-[#8a9bc4] hover:border-[#5a6fad] hover:text-[#3b4f9f] transition-colors"><Plus className="w-5 h-5" /><span className="text-[10px] mt-0.5">添加</span></button>)}
            </div></div>
          </div></div>
          {/* 备注（选填） */}
          <div><p className="text-xs text-slate-500 mb-2">备注（选填）</p><textarea placeholder="请输入备注..." value={form.note} onChange={e => update('note', e.target.value)} rows={3} className="w-full px-4 py-3 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f] resize-none" /></div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button><button onClick={handleSubmit} className="px-5 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">提交申报</button></div>
      </div>
      {showAddSupplier && <AddSupplierModal onClose={() => setShowAddSupplier(false)} onAdd={handleAddSupplier} />}
    </div>
  );
}

// ==================== 装备详情弹窗 ====================
function DetailModal({ product, onClose }: { product: Product; onClose: () => void; }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg animate-fade-in overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200"><h3 className="text-base font-bold text-slate-800">装备详情</h3><button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button></div>
        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">装备名称</p><p className="text-sm font-medium text-slate-800">{product.name}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">型号</p><p className="text-sm font-medium text-slate-800">{product.model}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">装备编码</p><p className="text-sm font-medium text-slate-800 font-mono">{product.code}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">分类</p><p className="text-sm font-medium text-slate-800">{product.cat1} / {product.cat2} / {product.cat3}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">价格</p><p className="text-sm font-medium text-[#2e3a8c]">{product.price}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">状态</p><p className="text-sm font-medium text-slate-800">{product.status}</p></div>
            <div className="p-3 bg-[#f0f3fa] rounded-lg col-span-2"><p className="text-xs text-slate-500">原厂商</p><p className="text-sm font-medium text-slate-800">{product.manufacturer || '-'}</p></div>
          </div>
          {product.note && <div className="p-3 bg-[#f0f3fa] rounded-lg"><p className="text-xs text-slate-500">备注</p><p className="text-sm text-slate-700">{product.note}</p></div>}
        </div>
        <div className="flex justify-end p-4 border-t border-slate-200 bg-[#f0f3fa]"><button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">关闭</button></div>
      </div>
    </div>
  );
}

// ==================== 新建发货单弹窗 ====================
interface ShipmentLineItem {
  itemIndex: number;
  name: string;
  model: string;
  code: string;
  unit: string;
  isWholeBox: boolean;
  boxCode: string;
  orderedQty: number;
  thisShipQty: number;
  productDate: string;
  expireMonths: number;
  expireDate: string;
  rfidTags: string[];
  checked: boolean;
}

function CreateShipmentModal({ orders, contracts, prefillOrder, onClose }: { orders: Order[]; contracts: Contract[]; prefillOrder: Order | null; onClose: () => void; }) {
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(prefillOrder);
  const [shipments, setShipments] = useState<{ id: string; deliveryAddress: string; remark: string; items: ShipmentLineItem[] }[]>([{ id: `SH${Date.now().toString().slice(-6)}`, deliveryAddress: '', remark: '', items: [] }]);
  const [activeShipmentIdx, setActiveShipmentIdx] = useState(0);
  const [rfidDrawer, setRfidDrawer] = useState<{ open: boolean; item: ShipmentLineItem | null }>({ open: false, item: null });
  const pendingOrders = orders.filter(o => o.shipStatus !== 'shipped');

  const activeShipment = shipments[activeShipmentIdx];
  const shipId = activeShipment.id;
  const deliveryAddress = activeShipment.deliveryAddress;
  const remark = activeShipment.remark;
  const items = activeShipment.items;
  const setDeliveryAddress = (v: string) => setShipments(prev => prev.map((s, i) => i === activeShipmentIdx ? { ...s, deliveryAddress: v } : s));
  const setRemark = (v: string) => setShipments(prev => prev.map((s, i) => i === activeShipmentIdx ? { ...s, remark: v } : s));
  const setItems = (fn: React.SetStateAction<ShipmentLineItem[]>) => {
    setShipments(prev => prev.map((s, i) => i === activeShipmentIdx ? { ...s, items: typeof fn === 'function' ? fn(s.items) : fn } : s));
  };

  const handleSelectOrder = (order: Order) => {
    setSelectedOrder(order);
    setItems(order.items.map((it, idx) => ({
      itemIndex: idx, name: it.name, model: it.model, code: it.code,
      unit: it.unit, isWholeBox: false, boxCode: '', orderedQty: it.quantity,
      thisShipQty: 0, productDate: '', expireMonths: 12, expireDate: '',
      rfidTags: [], checked: true,
    })));
  };

  const updateItem = (itemIndex: number, field: keyof ShipmentLineItem, value: any) => {
    setItems(prev => prev.map(it => {
      if (it.itemIndex !== itemIndex) return it;
      const updated = { ...it, [field]: value };
      if (field === 'productDate' || field === 'expireMonths') {
        if (updated.productDate && updated.expireMonths) {
          const d = new Date(updated.productDate);
          d.setMonth(d.getMonth() + updated.expireMonths);
          updated.expireDate = d.toISOString().slice(0, 10);
        }
      }
      return updated;
    }));
  };

  const totalOrdered = items.reduce((s, it) => s + it.orderedQty, 0);
  const totalShip = items.filter(it => it.checked).reduce((s, it) => s + it.thisShipQty, 0);

  const handleGenerateRfid = (item: ShipmentLineItem) => {
    if (!item.productDate || !item.expireMonths || item.thisShipQty <= 0) return;
    const newTags: string[] = [];
    const pd = formatDateToYYMMDD(item.productDate);
    const supplierCode = MY_SUPPLIER_CODE;
    const startIdx = item.rfidTags.length;
    for (let i = 0; i < item.thisShipQty; i++) {
      const serial = String(startIdx + i + 1).padStart(4, '0');
      const modelShort = item.model.slice(-3).padStart(3, '0');
      const expireStr = String(item.expireMonths).padStart(2, '0');
      newTags.push(`0-${item.code}-${modelShort}-${pd}-${expireStr}-${supplierCode}-${serial}`);
    }
    updateItem(item.itemIndex, 'rfidTags', [...item.rfidTags, ...newTags]);
  };

  const openRfidDrawer = (item: ShipmentLineItem) => {
    if (item.rfidTags.length === 0) handleGenerateRfid(item);
    setRfidDrawer({ open: true, item });
  };

  return (
    <>
      <div className="fixed inset-0 z-50 flex flex-col bg-white animate-fade-in" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-3 px-6 py-3 border-b border-slate-200 flex-shrink-0">
          <button onClick={onClose} className="flex items-center gap-1 text-sm text-slate-600 hover:text-slate-800 transition-colors"><span className="text-[#8a9bc4]">&lt;</span> 返回列表</button>
          <h3 className="text-base font-bold text-slate-800">新建发货单</h3>
          <span className="px-2 py-0.5 bg-amber-100 text-amber-700 text-xs rounded">草稿</span>
        </div>
        <div className="flex-1 overflow-y-auto px-6 py-5 space-y-6">
          <div><h4 className="text-sm font-bold text-slate-800 mb-4">1. 选择订单</h4>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="text-sm text-slate-700 mb-1.5 block">发货单号</label><input type="text" value={shipId} disabled className="w-full px-3 py-2.5 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm text-slate-500" /></div>
              <div><label className="text-sm text-slate-700 mb-1.5 block"><span className="text-red-500">*</span> 订单名称</label>
                <select value={selectedOrder?.id || ''} onChange={e => { const o = orders.find(x => x.id === e.target.value); if (o) handleSelectOrder(o); }} className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-[#3b4f9f]">
                  <option value="">请选择订单</option>
                  {pendingOrders.map(o => <option key={o.id} value={o.id}>{o.name}</option>)}
                </select>
              </div>
              <div><label className="text-sm text-slate-700 mb-1.5 block">供应商</label><input type="text" value={selectedOrder?.supplier || ''} disabled className="w-full px-3 py-2.5 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm text-slate-500" /></div>
              <div><label className="text-sm text-slate-700 mb-1.5 block"><span className="text-red-500">*</span> 预计送货日期</label><input type="text" value={selectedOrder?.deliveryDate || ''} disabled className="w-full px-3 py-2.5 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm text-slate-500" /></div>
              <div><label className="text-sm text-slate-700 mb-1.5 block">收货对象</label>
                <div className="flex items-center gap-2 px-3 py-2.5 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm text-slate-500">
                  <svg className="w-4 h-4 text-[#3b4f9f]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  {selectedOrder ? (unitLabelMap[selectedOrder.receiver] || selectedOrder.receiver) : ''}
                </div>
              </div>
              <div><label className="text-sm text-slate-700 mb-1.5 block">关联合同</label><input type="text" value={selectedOrder ? (contracts.find(c => c.id === selectedOrder.contractId)?.name || selectedOrder.contractId) : ''} disabled className="w-full px-3 py-2.5 bg-[#f0f3fa] border border-slate-200 rounded-lg text-sm text-slate-500" /></div>
              <div className="col-span-2"><label className="text-sm text-slate-700 mb-1.5 block"><span className="text-red-500">*</span> 收货地址</label><input type="text" placeholder="请输入收货地址" value={deliveryAddress} onChange={e => setDeliveryAddress(e.target.value)} className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-[#3b4f9f]" /></div>
            </div>
            <div className="mt-4"><label className="text-sm text-slate-700 mb-1.5 block">备注</label><input type="text" placeholder="请输入备注" value={remark} onChange={e => setRemark(e.target.value)} className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:border-[#3b4f9f]" /></div>
          </div>
          {selectedOrder && items.length > 0 && (<div><h4 className="text-sm font-bold text-slate-800 mb-4">2. 发货明细与RFID生成</h4>
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              {shipments.map((s, idx) => (
                <button key={s.id} onClick={() => setActiveShipmentIdx(idx)} className={`px-3 py-1.5 text-xs font-medium rounded border transition-colors ${idx === activeShipmentIdx ? 'bg-[#1b2370] text-white border-[#1b2370]' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>{s.id}</button>
              ))}
              <button onClick={() => { const newId = `SH${Date.now().toString().slice(-6)}`; const nextIdx = shipments.length; setShipments([...shipments, { id: newId, deliveryAddress: '', remark: '', items: [] }]); setActiveShipmentIdx(nextIdx); }} className="px-3 py-1.5 text-xs font-medium text-[#1b2370] bg-[#e8ecf5] rounded border border-[#c5cfe5] hover:bg-[#d4dcee] flex items-center gap-1"><Plus className="w-3 h-3" />新增发货单</button>
            </div>
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <table className="w-full text-xs">
                <thead><tr className="bg-[#f0f3fa] border-b border-slate-200">
                  <th className="px-2 py-2 text-left font-medium text-slate-600 w-6"></th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">装备名称</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">型号</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">装备编码</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">计量单位</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">是否整箱</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">采购数量</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">本次发货</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">生产日期</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">有效期(月)</th>
                  <th className="px-2 py-2 text-left font-medium text-slate-600">有效期至</th>
                </tr></thead>
                <tbody>{items.map((item) => (<tr key={item.itemIndex} className="border-b border-slate-100 last:border-0">
                  <td className="px-2 py-2"><input type="checkbox" checked={item.checked} onChange={e => updateItem(item.itemIndex, 'checked', e.target.checked)} className="w-4 h-4 rounded" /></td>
                  <td className="px-2 py-2 font-medium text-slate-800">{item.name}</td>
                  <td className="px-2 py-2 text-slate-500">{item.model}</td>
                  <td className="px-2 py-2 text-slate-500 font-mono">{item.code}</td>
                  <td className="px-2 py-2 text-slate-600">{item.unit}</td>
                  <td className="px-2 py-2"><input type="checkbox" checked={item.isWholeBox} onChange={e => updateItem(item.itemIndex, 'isWholeBox', e.target.checked)} className="w-4 h-4 rounded" /></td>
                  <td className="px-2 py-2 text-slate-700">{item.orderedQty}</td>
                  <td className="px-2 py-2"><input type="number" min={0} max={item.orderedQty} value={item.thisShipQty || ''} onChange={e => updateItem(item.itemIndex, 'thisShipQty', parseInt(e.target.value) || 0)} className="w-14 px-1 py-1 border border-slate-200 rounded text-center text-xs outline-none focus:border-[#3b4f9f]" /></td>
                  <td className="px-2 py-2"><input type="date" value={item.productDate} onChange={e => updateItem(item.itemIndex, 'productDate', e.target.value)} className="w-28 px-1 py-1 border border-slate-200 rounded text-xs outline-none focus:border-[#3b4f9f]" /></td>
                  <td className="px-2 py-2"><input type="number" min={1} value={item.expireMonths || ''} onChange={e => updateItem(item.itemIndex, 'expireMonths', parseInt(e.target.value) || 0)} className="w-12 px-1 py-1 border border-slate-200 rounded text-center text-xs outline-none focus:border-[#3b4f9f]" /></td>
                  <td className="px-2 py-2 text-slate-600">{item.expireDate || '-'}</td>
                </tr>))}</tbody>
              </table>
            </div>
            <div className="flex items-center justify-between mt-2 px-1">
              <span className="text-xs text-slate-500">共 {items.length} 行明细</span>
              <div className="flex gap-4 text-xs text-slate-500"><span>采购数量总计：<strong className="text-slate-800">{totalOrdered}</strong></span>|<span>本次发货总数：<strong className="text-[#2e3a8c]">{totalShip}</strong></span></div>
            </div>
          </div>)}
        </div>
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0">
          <span className="text-xs text-slate-500">本次发货总数：<strong className="text-[#2e3a8c]">{totalShip}</strong></span>
          <div className="flex gap-3">
            <button onClick={onClose} className="px-5 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
            <button onClick={onClose} className="px-5 py-2 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">保存草稿</button>
            <button onClick={onClose} className="px-5 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition-colors">确认</button>
          </div>
        </div>
      </div>
      {rfidDrawer.open && rfidDrawer.item && (
        <RfidManageDrawer
          item={rfidDrawer.item}
          shipQty={rfidDrawer.item.thisShipQty}
          onClose={() => setRfidDrawer({ open: false, item: null })}
          onUpdateTags={(tags) => { if (rfidDrawer.item) updateItem(rfidDrawer.item.itemIndex, 'rfidTags', tags); }}
        />
      )}
    </>
  );
}

// ==================== RFID管理侧面弹窗 ====================
function RfidManageDrawer({ item, shipQty, onClose, onUpdateTags }: { item: ShipmentLineItem; shipQty: number; onClose: () => void; onUpdateTags: (tags: string[]) => void; }) {
  const [scanInput, setScanInput] = useState('');
  const [tags, setTags] = useState<string[]>(item.rfidTags);
  useEffect(() => { setTags(item.rfidTags); }, [item.rfidTags]);
  const handleScan = () => {
    if (!scanInput.trim() || tags.length >= shipQty) return;
    if (!tags.includes(scanInput.trim())) {
      const newTags = [...tags, scanInput.trim()];
      setTags(newTags); onUpdateTags(newTags);
    }
    setScanInput('');
  };
  const handleAutoGenerate = () => {
    if (!item.productDate || shipQty <= 0) return;
    const newTags: string[] = [...tags];
    const pd = formatDateToYYMMDD(item.productDate);
    const supplierCode = MY_SUPPLIER_CODE;
    const startIdx = tags.length;
    for (let i = 0; i < shipQty - tags.length; i++) {
      const serial = String(startIdx + i + 1).padStart(4, '0');
      const modelShort = item.model.slice(-3).padStart(3, '0');
      const expireStr = String(item.expireMonths).padStart(2, '0');
      newTags.push(`0-${item.code}-${modelShort}-${pd}-${expireStr}-${supplierCode}-${serial}`);
    }
    setTags(newTags); onUpdateTags(newTags);
  };
  const handleDelete = (idx: number) => {
    const newTags = tags.filter((_, i) => i !== idx);
    setTags(newTags); onUpdateTags(newTags);
  };
  return (
    <div className="fixed inset-0 z-[60]" onClick={onClose}>
      <div className="absolute inset-0 bg-black/20" />
      <div className="absolute right-0 top-0 bottom-0 w-[420px] bg-white shadow-2xl flex flex-col" style={{ animation: 'slideInRight 0.2s ease' }} onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 flex-shrink-0">
          <div><h3 className="text-sm font-bold text-slate-800">RFID管理 - {item.name}（{item.model}）</h3><p className="text-xs text-slate-500 mt-0.5">本次需生成：{shipQty} 已生成：{tags.length}/{shipQty}</p></div>
          <button onClick={onClose} className="p-1 hover:bg-[#e8ecf5] rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="px-4 py-3 border-b border-slate-200 flex-shrink-0 space-y-2">
          <div className="flex gap-2"><input type="text" placeholder="扫描或输入RFID编码，按回车确认" value={scanInput} onChange={e => setScanInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleScan()} className="flex-1 px-3 py-2 border border-slate-200 rounded-lg text-sm outline-none focus:border-[#3b4f9f]" /><button onClick={handleScan} className="px-4 py-2 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c]">RFID扫描</button></div>
          <button onClick={handleAutoGenerate} disabled={tags.length >= shipQty} className="px-3 py-1.5 text-xs text-[#1b2370] bg-[#e8ecf5] rounded border border-[#c5cfe5] hover:bg-[#d4dcee] disabled:opacity-40">自动生成</button>
        </div>
        <div className="flex-1 overflow-y-auto px-4 py-2">
          <table className="w-full text-xs">
            <thead className="sticky top-0 bg-white z-10"><tr className="border-b border-slate-200"><th className="py-2 text-left font-medium text-slate-600 w-10">流水号</th><th className="py-2 text-left font-medium text-slate-600">RFID编码</th><th className="py-2 text-left font-medium text-slate-600 w-14">状态</th><th className="py-2 text-left font-medium text-slate-600 w-8">操作</th></tr></thead>
            <tbody>{tags.map((tag, idx) => (<tr key={idx} className="border-b border-slate-100"><td className="py-2 text-slate-600 font-mono">{String(idx + 1).padStart(4, '0')}</td><td className="py-2 text-slate-700 break-all">{tag}</td><td className="py-2"><span className="text-[#1b2370]">未打印</span></td><td className="py-2"><button onClick={() => handleDelete(idx)} className="text-red-400 hover:text-red-600"><Trash2 className="w-3.5 h-3.5" /></button></td></tr>))}</tbody>
          </table>
          {tags.length === 0 && <div className="py-8 text-center text-sm text-[#8a9bc4]">暂无RFID标签</div>}
        </div>
        <div className="flex items-center justify-between px-4 py-3 border-t border-slate-200 bg-[#f0f3fa] flex-shrink-0">
          <span className="text-xs text-slate-500">共 {tags.length} 个标签</span>
          {tags.length >= shipQty && shipQty > 0 && <span className="text-xs text-green-600 font-medium">已满足发货数量</span>}
        </div>
      </div>
    </div>
  );
}

// ==================== 供应商联系人及资质信息提交弹窗 ====================
function SupplierInfoModal({
  contactInfo, qualFiles, onClose, onSubmit,
}: {
  contactInfo: { contactName: string; idType: string; idNumber: string; contactPhone: string; email: string };
  qualFiles: Record<string, string>;
  onClose: () => void;
  onSubmit: (c: typeof contactInfo, q: typeof qualFiles) => void;
}) {
  const [c, setC] = useState(contactInfo);
  const [q, setQ] = useState(qualFiles);
  const [tab, setTab] = useState<'contact' | 'qual'>('contact');
  const [errs, setErrs] = useState<Record<string, string>>({});

  const updateC = (k: string, v: string) => setC(p => ({ ...p, [k]: v }));
  const toggleQ = (k: string) => setQ(p => ({ ...p, [k]: p[k] ? '' : `已上传-${k}` }));

  const validate = () => {
    const e: Record<string, string> = {};
    if (!c.contactName.trim()) e.contactName = '请输入联系人';
    if (!c.idType) e.idType = '请选择证件类型';
    if (!c.idNumber.trim()) e.idNumber = '请输入证件号码';
    if (!c.contactPhone.trim()) e.contactPhone = '请输入联系电话';
    else if (!/^1[3-9]\d{9}$/.test(c.contactPhone)) e.contactPhone = '手机号格式不正确';
    setErrs(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onSubmit(c, q);
  };

  const requiredFields = [
    { key: 'businessLicense', label: '营业执照副本', desc: '原件扫描/加盖公章' },
    { key: 'legalPersonId', label: '法定代表人身份证', desc: '正反面' },
    { key: 'industryLicense', label: '相关生产经营资质许可证', desc: '如行业强制资质，非通用资质' },
    { key: 'creditChina', label: '"信用中国"信用信息报告', desc: '' },
    { key: 'creditGov', label: '"中国政府采购网"信用查询截图', desc: '' },
  ];
  const optionalFields = [
    { key: 'bankPermit', label: '开户许可证或基本存款账户信息', desc: '' },
    { key: 'taxProof', label: '近半年内任一月份完税证明', desc: '' },
    { key: 'taxRating', label: '上一年度税务评级截图', desc: '' },
    { key: 'companyIntro', label: '公司及产品简介', desc: '图文/PPT均可' },
    { key: 'supplyRecord', label: '供货业绩', desc: '可隐去敏感信息的合同/中标通知书' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[720px] max-h-[90vh] animate-fade-in flex flex-col" onClick={e => e.stopPropagation()}>
        {/* 头部 */}
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0">
          <h3 className="text-base font-bold text-slate-800">提交联系人及资质信息</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>

        {/* Tab */}
        <div className="flex border-b border-slate-200 flex-shrink-0">
          <button onClick={() => setTab('contact')} className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${tab === 'contact' ? 'border-[#1b2370] text-[#1b2370]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            联系人信息
          </button>
          <button onClick={() => setTab('qual')} className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${tab === 'qual' ? 'border-[#1b2370] text-[#1b2370]' : 'border-transparent text-slate-500 hover:text-slate-700'}`}>
            资质上传
          </button>
        </div>

        {/* 内容 */}
        <div className="flex-1 overflow-y-auto p-5">
          {tab === 'contact' && (
            <div className="space-y-4 animate-fade-in">
              <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2"><User className="w-4 h-4 text-[#1b2370]" /> 联系人信息</h4>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 联系人</label>
                  <input type="text" placeholder="请输入联系人" value={c.contactName} onChange={e => updateC('contactName', e.target.value)}
                    className={`w-full px-3 py-2.5 border rounded-lg text-sm outline-none focus:border-[#3b4f9f] ${errs.contactName ? 'border-red-300' : 'border-slate-200'}`} />
                  {errs.contactName && <p className="mt-1 text-red-500 text-xs">{errs.contactName}</p>}
                </div>
                <div>
                  <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 证件类型</label>
                  <select value={c.idType} onChange={e => updateC('idType', e.target.value)}
                    className={`w-full px-3 py-2.5 border rounded-lg text-sm outline-none focus:border-[#3b4f9f] ${errs.idType ? 'border-red-300' : 'border-slate-200'}`}>
                    <option value="">请选择</option>
                    <option value="身份证">身份证</option>
                    <option value="护照">护照</option>
                    <option value="军官证">军官证</option>
                  </select>
                  {errs.idType && <p className="mt-1 text-red-500 text-xs">{errs.idType}</p>}
                </div>
                <div>
                  <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 证件号码</label>
                  <input type="text" placeholder="请输入证件号码" value={c.idNumber} onChange={e => updateC('idNumber', e.target.value)}
                    className={`w-full px-3 py-2.5 border rounded-lg text-sm outline-none focus:border-[#3b4f9f] ${errs.idNumber ? 'border-red-300' : 'border-slate-200'}`} />
                  {errs.idNumber && <p className="mt-1 text-red-500 text-xs">{errs.idNumber}</p>}
                </div>
                <div>
                  <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 联系电话</label>
                  <input type="tel" placeholder="请输入联系电话" maxLength={11} value={c.contactPhone} onChange={e => updateC('contactPhone', e.target.value.replace(/\D/g, ''))}
                    className={`w-full px-3 py-2.5 border rounded-lg text-sm outline-none focus:border-[#3b4f9f] ${errs.contactPhone ? 'border-red-300' : 'border-slate-200'}`} />
                  {errs.contactPhone && <p className="mt-1 text-red-500 text-xs">{errs.contactPhone}</p>}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">电子邮箱</label>
                <input type="email" placeholder="请输入电子邮箱" value={c.email} onChange={e => updateC('email', e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-200 rounded-lg text-sm outline-none focus:border-[#3b4f9f]" />
              </div>
              <div>
                <label className="flex items-center gap-1 text-sm font-medium text-slate-700 mb-1.5"><span className="text-red-500">*</span> 身份证正反面</label>
                <div className="border-2 border-dashed border-slate-300 rounded-xl p-6 text-center hover:border-[#3b4f9f] cursor-pointer transition-colors bg-slate-50/50">
                  <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center mx-auto mb-2 border border-slate-200">
                    <FileImage className="w-5 h-5 text-slate-400" />
                  </div>
                  <p className="text-xs text-slate-500">请上传清晰的身份证照片，支持JPG、PNG格式，每个文件不超过10M</p>
                </div>
              </div>
            </div>
          )}

          {tab === 'qual' && (
            <div className="space-y-6 animate-fade-in">
              {/* 必填 */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Shield className="w-4 h-4 text-red-500" />
                  <h4 className="text-sm font-bold text-slate-800">一、必填</h4>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {requiredFields.map(f => (
                    <div key={f.key}>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-sm font-medium text-slate-700">{f.label}</span>
                        {f.desc && <span className="text-xs text-slate-400">({f.desc})</span>}
                      </div>
                      <div onClick={() => toggleQ(f.key)}
                        className={`relative border-2 border-dashed rounded-xl p-4 cursor-pointer transition-all text-center ${q[f.key] ? 'border-green-400 bg-green-50/50' : 'border-slate-300 bg-slate-50/50 hover:border-[#3b4f9f]'}`}>
                        {q[f.key] ? (
                          <div className="flex items-center justify-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                            <span className="text-sm text-slate-700 font-medium">已上传</span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-1">
                            <Upload className="w-5 h-5 text-slate-400" />
                            <span className="text-xs text-slate-500">点击上传</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* 选填 */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Info className="w-4 h-4 text-blue-500" />
                  <h4 className="text-sm font-bold text-slate-800">二、选填</h4>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {optionalFields.map(f => (
                    <div key={f.key}>
                      <div className="flex items-center gap-2 mb-1.5">
                        <span className="text-sm font-medium text-slate-700">{f.label}</span>
                        {f.desc && <span className="text-xs text-slate-400">({f.desc})</span>}
                      </div>
                      <div onClick={() => toggleQ(f.key)}
                        className={`relative border-2 border-dashed rounded-xl p-4 cursor-pointer transition-all text-center ${q[f.key] ? 'border-green-400 bg-green-50/50' : 'border-slate-300 bg-slate-50/50 hover:border-[#3b4f9f]'}`}>
                        {q[f.key] ? (
                          <div className="flex items-center justify-center gap-2">
                            <CheckCircle2 className="w-5 h-5 text-green-600" />
                            <span className="text-sm text-slate-700 font-medium">已上传</span>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-1">
                            <Upload className="w-5 h-5 text-slate-400" />
                            <span className="text-xs text-slate-500">点击上传</span>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 底部按钮 */}
        <div className="flex items-center justify-between p-4 border-t border-slate-200 flex-shrink-0">
          <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 text-slate-600 rounded-lg text-sm font-medium hover:bg-slate-50 transition-colors">
            取消
          </button>
          <button onClick={handleSubmit}
            className="px-6 py-2.5 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c] transition-colors">
            提交审核
          </button>
        </div>
      </div>
    </div>
  );
}

// ==================== 撤回确认弹窗 ====================
function WithdrawModal({ order, onClose, onConfirm }: { order: Order; onClose: () => void; onConfirm: () => void; }) {
  const records = shipmentRecords.filter(r => r.orderId === order.id);
  const totalShipped = records.reduce((s, r) => s + r.items.reduce((is, it) => is + it.thisShipQty, 0), 0);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[560px] animate-fade-in" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200">
          <h3 className="text-base font-bold text-slate-800">请确认是否撤回已发货装备</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="p-5 space-y-4">
          <p className="text-sm font-medium text-slate-700">已发货的批次：</p>
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead><tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-3 py-2 text-left font-medium text-slate-600">发货单号</th>
                <th className="px-3 py-2 text-left font-medium text-slate-600">发货日期</th>
                <th className="px-3 py-2 text-left font-medium text-slate-600">发货数量</th>
              </tr></thead>
              <tbody>
                {records.map((rec) => (
                  <tr key={rec.id} className="border-b border-slate-100 last:border-0">
                    <td className="px-3 py-2.5 font-mono text-slate-700">{rec.id}</td>
                    <td className="px-3 py-2.5 text-slate-600">{rec.shipDate}</td>
                    <td className="px-3 py-2.5 text-slate-700">{rec.items.reduce((s, it) => s + it.thisShipQty, 0)}台</td>
                  </tr>
                ))}
                {records.length === 0 && (
                  <tr><td colSpan={3} className="px-3 py-4 text-center text-slate-400">暂无发货记录</td></tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">撤回后，订单将回到"已发货"状态，收货方将不再能进行验收操作。</p>
          </div>
        </div>
        <div className="flex justify-end gap-3 p-4 border-t border-slate-200 bg-slate-50">
          <button onClick={onClose} className="px-5 py-2.5 border border-slate-200 rounded-lg text-sm text-slate-600 hover:bg-white transition-colors">取消</button>
          <button onClick={onConfirm} className="px-5 py-2.5 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition-colors">确认撤回</button>
        </div>
      </div>
    </div>
  );
}

// ==================== 发货单预览弹窗 ====================
function ShipmentDocPreview({ order, onClose }: { order: Order; onClose: () => void; }) {
  const doc = shipmentDocs.find(d => d.orderId === order.id);
  const totalAmount = order.items.reduce((s, it) => s + it.price * it.quantity, 0);
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div className="bg-white rounded-xl shadow-xl w-[800px] max-h-[90vh] flex flex-col animate-fade-in" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between p-4 border-b border-slate-200 flex-shrink-0">
          <h3 className="text-base font-bold text-slate-800">发货单预览</h3>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded transition-colors"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="p-4 flex-shrink-0">
          <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 bg-[#1b2370] text-white rounded-lg text-sm font-medium hover:bg-[#2e3a8c]">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
            打印发货单
          </button>
        </div>
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <h2 className="text-center text-xl font-bold text-slate-800 tracking-widest">发 货 单</h2>
          {/* 主表 */}
          <div className="grid grid-cols-3 gap-4 border rounded-lg p-4">
            <div><p className="text-xs text-slate-500 mb-1">发货单号</p><p className="font-semibold text-slate-800">{doc?.id || '-'}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">供应商</p><p className="font-semibold text-slate-800">{order.supplier}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">供应商企业编码</p><p className="font-semibold text-slate-800">{order.supplierCode}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">预计送货日期</p><p className="font-semibold text-slate-800">{order.deliveryDate}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">收货对象</p><p className="font-semibold text-slate-800">{decodeUnitCode(order.receiver) || order.receiver}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">发货日期</p><p className="font-semibold text-slate-800">{doc?.shipDate || '-'}</p></div>
            <div><p className="text-xs text-slate-500 mb-1">备注</p><p className="font-semibold text-slate-800">{doc?.remark || '-'}</p></div>
          </div>
          {/* 明细表格 */}
          <div className="border border-slate-200 rounded-lg overflow-hidden">
            <table className="w-full text-xs">
              <thead><tr className="bg-slate-50 border-b border-slate-200">
                <th className="px-2 py-2 text-left font-medium text-slate-600">装备类型</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">装备名称</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">规格</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">计量单位</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">数量</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">单价</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">生产日期</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">有效期</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">RFID编码</th>
                <th className="px-2 py-2 text-left font-medium text-slate-600">箱体码</th>
              </tr></thead>
              <tbody>{(doc?.items || []).map((item, idx) => (
                <tr key={idx} className="border-b border-slate-100 last:border-0">
                  <td className="px-2 py-2 text-slate-600">{item.itemType}</td>
                  <td className="px-2 py-2 font-medium text-slate-800">{item.name}</td>
                  <td className="px-2 py-2 text-slate-500">{item.model}</td>
                  <td className="px-2 py-2 text-slate-600">{item.unit}</td>
                  <td className="px-2 py-2 text-slate-700">{item.quantity}</td>
                  <td className="px-2 py-2 text-blue-500 font-medium">&#165;{item.price.toLocaleString()}</td>
                  <td className="px-2 py-2 text-slate-600">{item.productDate}</td>
                  <td className="px-2 py-2 text-slate-600">{item.expireMonths}月</td>
                  <td className="px-2 py-2 text-slate-500 text-[10px]">{item.rfidCodes[0]}{item.rfidCodes.length > 1 ? ` (${item.rfidCodes.length}条)` : ''}</td>
                  <td className="px-2 py-2 text-slate-600">{item.boxCode}</td>
                </tr>
              ))}</tbody>
            </table>
          </div>
          {/* 合计 */}
          <div className="text-right text-sm">
            <span className="text-slate-600">合计金额：</span>
            <span className="font-bold text-lg text-[#1b2370]">&#165;{totalAmount.toLocaleString()}</span>
          </div>
          {/* 签字区域 */}
          <div className="flex justify-between pt-6 text-sm text-slate-600">
            <span>发货方签字：________________</span>
            <span>收货方签字：________________</span>
          </div>
        </div>
      </div>
    </div>
  );
}
