import { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { Shield, Bell, ChevronDown, LogOut, User } from 'lucide-react';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

// 模拟企业信息
const mockCompany = {
  name: '华为技术有限公司',
  avatar: '华',
};

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const isProfilePage = location.pathname === '/profile';

  // 点击外部关闭下拉
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  return (
    <div className="min-h-screen bg-[#f0f2f5]">
      {/* 顶部深蓝色导航栏 */}
      <header className="h-14 bg-[#001529] flex items-center justify-between px-4 sticky top-0 z-50">
        {/* 左侧 Logo */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <span className="text-white text-base font-medium">装备物资系统</span>
          <div className="h-6 w-px bg-white/20 mx-2" />
          <nav className="flex items-center gap-1">
            <button
              onClick={() => navigate('/dashboard')}
              className={`px-4 py-1.5 rounded text-sm transition-colors ${
                location.pathname.startsWith('/dashboard') && !isProfilePage
                  ? 'bg-blue-600 text-white'
                  : 'text-white/70 hover:text-white hover:bg-white/10'
              }`}
            >
              装备采购管理
            </button>
          </nav>
        </div>

        {/* 右侧 */}
        <div className="flex items-center gap-4">
          {/* 通知 */}
          <button className="relative p-2 text-white/70 hover:text-white transition-colors">
            <Bell className="w-5 h-5" />
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          </button>

          {/* 企业头像下拉 */}
          <div ref={dropdownRef} className="relative">
            <button
              onClick={() => setShowDropdown(!showDropdown)}
              className="flex items-center gap-2 text-white/90 hover:text-white transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-police flex items-center justify-center text-white text-sm font-bold">
                {mockCompany.avatar}
              </div>
              <span className="text-sm max-w-[120px] truncate">{mockCompany.name}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${showDropdown ? 'rotate-180' : ''}`} />
            </button>

            {showDropdown && (
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-lg shadow-lg border border-slate-200 overflow-hidden animate-fade-in">
                <button
                  onClick={() => { navigate('/profile'); setShowDropdown(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm text-slate-700 hover:bg-blue-50 transition-colors"
                >
                  <User className="w-4 h-4 text-slate-400" />
                  个人中心
                </button>
                <button
                  onClick={() => { navigate('/'); setShowDropdown(false); }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm text-red-600 hover:bg-red-50 transition-colors border-t border-slate-100"
                >
                  <LogOut className="w-4 h-4" />
                  退出登录
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* 页面内容 */}
      <main className="p-6">
        {children}
      </main>
    </div>
  );
}
