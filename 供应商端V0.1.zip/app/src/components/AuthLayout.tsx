import { Shield } from 'lucide-react';
import { type ReactNode } from 'react';

interface AuthLayoutProps {
  children: ReactNode;
}

export default function AuthLayout({ children }: AuthLayoutProps) {
  return (
    <div className="min-h-screen w-full flex flex-col bg-slate-50">
      {/* 顶部公安蓝渐变条 */}
      <div className="h-1.5 w-full bg-gradient-police" />

      {/* 顶部导航 */}
      <header className="w-full bg-white border-b border-slate-200">
        <div className="max-w-xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-police flex items-center justify-center">
              <Shield className="w-4 h-4 text-white" />
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-sm font-bold text-slate-800">供应商协同平台</span>
              <span className="text-[11px] text-slate-400 hidden sm:inline">Supplier Portal</span>
            </div>
          </div>
        </div>
      </header>

      {/* 主内容区 */}
      <main className="flex-1 flex items-start justify-center px-4 sm:px-6 py-8 sm:py-12">
        <div className="w-full max-w-xl">
          {children}
        </div>
      </main>

      {/* 底部 */}
      <footer className="w-full py-4 text-center">
        <p className="text-xs text-slate-400">
          &copy; 2026 供应商协同平台 · 安全合规的物资装备系统
        </p>
      </footer>
    </div>
  );
}
