import { useState, useCallback } from 'react';
import { Loader2, ArrowRight, ArrowLeft, Mail, Smartphone, Lock, Eye, EyeOff, KeyRound, CheckCircle2 } from 'lucide-react';
import { type ForgotPasswordData, type FormErrors } from '@/types/auth';

interface ForgotPasswordProps {
  forgotData: ForgotPasswordData;
  errors: FormErrors;
  isLoading: boolean;
  setForgotData: React.Dispatch<React.SetStateAction<ForgotPasswordData>>;
  onSubmit: () => void;
  onGoLogin: () => void;
}

export default function ForgotPassword({
  forgotData,
  errors,
  isLoading,
  setForgotData,
  onSubmit,
  onGoLogin,
}: ForgotPasswordProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [codeCountdown, setCodeCountdown] = useState(0);
  const [step, setStep] = useState<'account' | 'reset'>('account');

  // 自动识别输入类型
  const inputType = forgotData.account.match(/^1[3-9]\d{9}$/) ? 'phone'
    : forgotData.account.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/) ? 'email'
    : 'unknown';

  // 发送验证码
  const sendCode = useCallback(() => {
    if (!forgotData.account || codeCountdown > 0) return;
    setCodeCountdown(60);
    const timer = setInterval(() => {
      setCodeCountdown(prev => {
        if (prev <= 1) clearInterval(timer);
        return prev - 1;
      });
    }, 1000);
  }, [forgotData.account, codeCountdown]);

  // 验证账号
  const verifyAccount = useCallback(() => {
    const errs: FormErrors = {};
    if (!forgotData.account.trim()) errs.account = '请输入注册邮箱或手机号';
    else if (inputType === 'unknown' && forgotData.account.length > 0)
      errs.account = '请输入有效的手机号或邮箱';

    if (Object.keys(errs).length > 0) {
      return false;
    }
    setStep('reset');
    return true;
  }, [forgotData.account, inputType]);

  const handleSubmit = useCallback(() => {
    onSubmit();
  }, [onSubmit]);

  return (
    <div className="animate-fade-in">
      {/* 标题 */}
      <div className="text-center mb-8">
        <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mx-auto mb-4">
          <KeyRound className="w-6 h-6 text-blue-700" />
        </div>
        <h2 className="text-2xl font-bold text-slate-800 mb-2">重置密码</h2>
        <p className="text-slate-500 text-sm">通过注册邮箱或手机号自助重置密码</p>
      </div>

      {step === 'account' ? (
        <div className="space-y-4 animate-slide-up">
          {/* 账号输入 */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">
              注册邮箱 / 手机号
            </label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                {inputType === 'phone' ? <Smartphone className="w-4 h-4" /> : <Mail className="w-4 h-4" />}
              </div>
              <input
                type="text"
                placeholder="请输入注册时的邮箱或手机号"
                value={forgotData.account}
                onChange={e => setForgotData(prev => ({ ...prev, account: e.target.value }))}
                className={`w-full pl-10 pr-4 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 ${
                  errors.account ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'
                }`}
              />
            </div>
            {errors.account && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.account}</p>}
          </div>

          <button
            onClick={verifyAccount}
            className="w-full py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg"
          >
            下一步
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div className="space-y-4 animate-slide-up">
          {/* 发送验证码提示 */}
          <div className="flex items-center gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <div>
              <p className="text-sm text-blue-800 font-medium">验证码已发送</p>
              <p className="text-xs text-blue-600 mt-0.5">
                已向 {maskAccount(forgotData.account)} 发送验证码
              </p>
            </div>
          </div>

          {/* 验证码 */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">验证码</label>
            <div className="flex gap-3">
              <input
                type="text"
                placeholder="请输入6位验证码"
                maxLength={6}
                value={forgotData.verificationCode}
                onChange={e => setForgotData(prev => ({ ...prev, verificationCode: e.target.value.replace(/\D/g, '') }))}
                className={`flex-1 px-4 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 tracking-widest text-center ${
                  errors.verificationCode ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'
                }`}
              />
              <button
                onClick={sendCode}
                disabled={codeCountdown > 0}
                className={`px-4 py-3 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                  codeCountdown > 0
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100'
                }`}
              >
                {codeCountdown > 0 ? `${codeCountdown}s` : '重新发送'}
              </button>
            </div>
            {errors.verificationCode && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.verificationCode}</p>}
          </div>

          {/* 新密码 */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">新密码</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="至少8位，包含大小写字母和数字"
                value={forgotData.newPassword}
                onChange={e => setForgotData(prev => ({ ...prev, newPassword: e.target.value }))}
                className={`w-full pl-10 pr-10 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 ${
                  errors.newPassword ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.newPassword && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.newPassword}</p>}
          </div>

          {/* 确认密码 */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1.5">确认新密码</label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                placeholder="请再次输入新密码"
                value={forgotData.confirmPassword}
                onChange={e => setForgotData(prev => ({ ...prev, confirmPassword: e.target.value }))}
                className={`w-full pl-10 pr-10 py-3 bg-white border rounded-lg text-sm transition-all outline-none focus:ring-2 focus:ring-blue-500/20 ${
                  errors.confirmPassword ? 'border-red-300' : 'border-slate-200 focus:border-blue-500'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            {errors.confirmPassword && <p className="mt-1 text-red-500 text-xs animate-shake">{errors.confirmPassword}</p>}
          </div>

          {/* 按钮 */}
          <div className="flex gap-3">
            <button
              onClick={() => setStep('account')}
              className="px-6 py-3 border border-slate-200 text-slate-600 rounded-lg font-medium text-sm hover:bg-slate-50 active:scale-[0.98] transition-all flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              返回
            </button>
            <button
              onClick={handleSubmit}
              disabled={isLoading}
              className="flex-1 py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg disabled:opacity-60"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  重置中...
                </>
              ) : (
                <>
                  确认重置
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* 返回登录 */}
      <div className="text-center mt-6">
        <button
          onClick={onGoLogin}
          className="text-sm text-blue-700 hover:underline flex items-center gap-1 mx-auto"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          返回登录
        </button>
      </div>
    </div>
  );
}

// 掩码显示账号
function maskAccount(account: string): string {
  if (account.match(/^1\d{10}$/)) {
    return account.slice(0, 3) + '****' + account.slice(7);
  }
  if (account.includes('@')) {
    const [name, domain] = account.split('@');
    return name.slice(0, 2) + '***@' + domain;
  }
  return account;
}
