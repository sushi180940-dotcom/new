import { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Search, ChevronDown, ChevronRight, X, Building2 } from 'lucide-react';

export interface TreeNode {
  id: string;
  label: string;
  children?: TreeNode[];
}

// 树形数据：省厅 → 具体单位（直属部门/地市公安局）
export const defaultTreeData: TreeNode[] = [
  {
    id: ' Provincial',
    label: '省公安厅',
    children: [
      { id: 'dept-kx', label: '科信处' },
      { id: 'dept-wa', label: '网安总队' },
      { id: 'dept-xz', label: '刑侦总队' },
      { id: 'dept-za', label: '治安总队' },
      { id: 'dept-jj', label: '交警总队' },
      { id: 'dept-jc', label: '经侦总队' },
      { id: 'dept-zd', label: '禁毒总队' },
      { id: 'city-a', label: '市公安局A' },
      { id: 'city-b', label: '市公安局B' },
      { id: 'city-c', label: '市公安局C' },
      { id: 'city-d', label: '市公安局D' },
      { id: 'city-e', label: '市公安局E' },
      { id: 'city-f', label: '市公安局F' },
      { id: 'city-g', label: '市公安局G' },
      { id: 'city-h', label: '市公安局H' },
      { id: 'city-i', label: '市公安局I' },
      { id: 'city-j', label: '市公安局J' },
      { id: 'city-k', label: '市公安局K' },
      { id: 'city-l', label: '市公安局L' },
    ],
  },
];

interface TreeSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
}

// ==================== 拼音首字母搜索选择器 ====================

// 单位名称 → 大写拼音首字母映射
const pinyinMap: Record<string, string> = {
  '省公安厅': 'SGAT',
  '科信处': 'KXC',
  '网安总队': 'WAZD',
  '刑侦总队': 'XZZD',
  '治安总队': 'ZAZD',
  '交警总队': 'JJZD',
  '经侦总队': 'JZZD',
  '禁毒总队': 'JDZD',
  '市公安局A': 'GSJGA',
  '市公安局B': 'GSJGB',
  '市公安局C': 'GSJGC',
  '市公安局D': 'GSJGD',
  '市公安局E': 'GSJGE',
  '市公安局F': 'GSJGF',
  '市公安局G': 'GSJGG',
  '市公安局H': 'GSJGH',
  '市公安局I': 'GSJGI',
  '市公安局J': 'GSJGJ',
  '市公安局K': 'GSJGK',
  '市公安局L': 'GSJGL',
};

// 所有可选单位（叶子节点）- 从树结构中提取
function getLeafNodes(nodes: TreeNode[]): { id: string; label: string; pinyin: string }[] {
  const result: { id: string; label: string; pinyin: string }[] = [];
  const traverse = (nodeList: TreeNode[]) => {
    nodeList.forEach(node => {
      if (node.children && node.children.length > 0) {
        traverse(node.children);
      } else {
        result.push({ id: node.id, label: node.label, pinyin: pinyinMap[node.label] || '' });
      }
    });
  };
  traverse(nodes);
  return result;
}

interface PinyinSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
}

export function PinyinSearchSelect({ value, onChange, placeholder = '请输入单位名称拼音首字母搜索', error }: PinyinSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  // 获取所有叶子节点
  const allUnits = useMemo(() => getLeafNodes(defaultTreeData), []);

  // 搜索过滤（支持拼音首字母和单位名称）
  const filteredUnits = useMemo(() => {
    if (!search.trim()) return [];
    const upper = search.toUpperCase();
    return allUnits.filter(u =>
      u.pinyin.includes(upper) || u.label.includes(search)
    );
  }, [search, allUnits]);

  const selectedLabel = value ? allUnits.find(u => u.id === value)?.label || value : '';
  const selectedPinyin = value ? allUnits.find(u => u.id === value)?.pinyin || '' : '';

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 100);
  }, [isOpen]);

  return (
    <div ref={containerRef} className="relative">
      <div
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full min-h-[46px] px-3 py-2 bg-white border rounded-lg text-sm transition-all outline-none cursor-pointer flex items-center gap-2 ${
          isOpen ? 'ring-2 ring-[#1b2370]/20 border-[#3b4f9f]' : error ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        {!selectedLabel ? (
          <span className="text-slate-400">{placeholder}</span>
        ) : (
          <>
            <Building2 className="w-4 h-4 text-[#1b2370] flex-shrink-0" />
            <span className="text-slate-700 font-medium flex-1 truncate">{selectedLabel}</span>
            <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded font-mono">{selectedPinyin}</span>
            <button onClick={e => { e.stopPropagation(); onChange(''); }} className="p-0.5 hover:bg-red-100 rounded transition-colors flex-shrink-0">
              <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
            </button>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-slate-400 ml-auto transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </div>

      {isOpen && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          <div className="p-2 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                ref={searchRef}
                type="text"
                placeholder="输入拼音首字母或单位名称搜索..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]"
              />
            </div>
          </div>

          <div className="max-h-72 overflow-y-auto p-2">
            {search.trim() === '' ? (
              <div className="py-8 text-center text-sm text-slate-400">
                请输入拼音首字母或单位名称进行搜索
              </div>
            ) : filteredUnits.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                未找到匹配的单位
              </div>
            ) : (
              filteredUnits.map(unit => (
                <div
                  key={unit.id}
                  onClick={() => { onChange(unit.id); setIsOpen(false); setSearch(''); }}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition-colors ${
                    value === unit.id ? 'bg-[#e8ecf5] border border-[#c5cfe5]' : 'hover:bg-slate-50'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 ${
                    value === unit.id ? 'border-[#2e3a8c]' : 'border-slate-300'
                  }`}>
                    {value === unit.id && <div className="w-2 h-2 rounded-full bg-[#2e3a8c]" />}
                  </div>
                  <span className="text-sm text-slate-700 flex-1">{unit.label}</span>
                  <span className="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded font-mono">{unit.pinyin}</span>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function TreeSelect({ value, onChange, placeholder = '请选择意向供货单位', error }: TreeSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set([' Provincial']));
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  // 点击外部关闭
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // 打开时聚焦搜索框
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => searchRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // 扁平化获取所有叶子节点标签
  const leafMap = useMemo(() => {
    const map = new Map<string, string>();
    const traverse = (nodes: TreeNode[]) => {
      nodes.forEach(node => {
        if (node.children && node.children.length > 0) {
          traverse(node.children);
        }
        map.set(node.id, node.label);
      });
    };
    traverse(defaultTreeData);
    return map;
  }, []);

  // 搜索过滤
  const filteredTree = useMemo(() => {
    if (!search.trim()) return defaultTreeData;
    const lower = search.toLowerCase();

    const filterNodes = (nodes: TreeNode[]): TreeNode[] => {
      return nodes.reduce<TreeNode[]>((acc, node) => {
        const matchSelf = node.label.toLowerCase().includes(lower);
        const filteredChildren = node.children ? filterNodes(node.children) : [];

        if (matchSelf) {
          acc.push({ ...node, children: node.children });
        } else if (filteredChildren.length > 0) {
          acc.push({ ...node, children: filteredChildren });
        }
        return acc;
      }, []);
    };

    return filterNodes(defaultTreeData);
  }, [search]);

  // 自动展开搜索结果的父节点
  useEffect(() => {
    if (search.trim()) {
      const newExpanded = new Set<string>();
      const collectParent = (nodes: TreeNode[]) => {
        nodes.forEach(n => {
          newExpanded.add(n.id);
          if (n.children) collectParent(n.children);
        });
      };
      collectParent(filteredTree);
      setExpanded(newExpanded);
    } else {
      setExpanded(new Set([' Provincial']));
    }
  }, [search, filteredTree]);

  const toggleExpanded = useCallback((id: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }, []);

  const selectedLabel = value ? leafMap.get(value) || value : '';

  // 判断节点是否有子节点
  const hasChildren = (node: TreeNode) => node.children && node.children.length > 0;

  // 渲染树节点
  const renderNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expanded.has(node.id);
    const isSelected = value === node.id;
    const children = node.children || [];
    const nodeHasChildren = hasChildren(node);

    return (
      <div key={node.id}>
        <div
          className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md transition-colors cursor-pointer hover:bg-[#e8ecf5] ${depth > 0 ? 'ml-4' : ''}`}
          onClick={() => {
            if (nodeHasChildren) {
              toggleExpanded(node.id);
            } else {
              onChange(node.id);
              setIsOpen(false);
              setSearch('');
            }
          }}
        >
          {nodeHasChildren ? (
            <button
              onClick={e => { e.stopPropagation(); toggleExpanded(node.id); }}
              className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-[#1b2370] transition-colors flex-shrink-0"
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          {/* 单选圆点（仅叶子节点） */}
          {!nodeHasChildren ? (
            <div
              className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 transition-colors ${
                isSelected ? 'border-[#2e3a8c]' : 'border-slate-300 hover:border-[#3b4f9f]'
              }`}
              onClick={e => { e.stopPropagation(); onChange(node.id); setIsOpen(false); setSearch(''); }}
            >
              {isSelected && <div className="w-2 h-2 rounded-full bg-[#2e3a8c]" />}
            </div>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          <span className={`text-sm flex-1 truncate ${nodeHasChildren ? 'font-medium text-slate-700' : 'text-slate-600'}`}>
            {node.label}
          </span>
        </div>

        {/* 子节点 */}
        {nodeHasChildren && isExpanded && (
          <div className="mt-0.5">
            {children.map(child => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div ref={containerRef} className="relative">
      {/* 输入框 */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full min-h-[46px] px-3 py-2 bg-white border rounded-lg text-sm transition-all outline-none cursor-pointer flex items-center gap-2 ${
          isOpen ? 'ring-2 ring-[#1b2370]/20 border-[#3b4f9f]' : error ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        {!selectedLabel ? (
          <span className="text-slate-400">{placeholder}</span>
        ) : (
          <>
            <Building2 className="w-4 h-4 text-[#1b2370] flex-shrink-0" />
            <span className="text-slate-700 font-medium flex-1 truncate">{selectedLabel}</span>
            <button
              onClick={e => { e.stopPropagation(); onChange(''); }}
              className="p-0.5 hover:bg-red-100 rounded transition-colors flex-shrink-0"
            >
              <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
            </button>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-slate-400 ml-auto transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </div>

      {/* 下拉面板 */}
      {isOpen && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          {/* 搜索框 */}
          <div className="p-2 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                ref={searchRef}
                type="text"
                placeholder="搜索单位名称..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]"
              />
            </div>
          </div>

          {/* 树形列表 */}
          <div className="max-h-72 overflow-y-auto p-2">
            {filteredTree.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                未找到匹配的单位
              </div>
            ) : (
              filteredTree.map(node => renderNode(node))
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ==================== 单位编码树形搜索选择器 ====================

interface UnitTreeNode {
  code: string;   // 拼音首字母编码
  name: string;   // 中文名称（用于搜索匹配）
  children?: UnitTreeNode[];
}

// 完整单位层级树
export const unitTreeData: UnitTreeNode[] = [
  {
    code: 'GDSGAJ', name: '广东省公安厅',
    children: [
      {
        code: 'GZSGAJ', name: '广州市公安局',
        children: [
          {
            code: 'THGAJ', name: '天河区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
          {
            code: 'BYGAJ', name: '白云区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'WAZD', name: '网安支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
          {
            code: 'HZGAJ', name: '海珠区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'JJZD', name: '交警支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
          {
            code: 'PYGAJ', name: '番禺区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
            ]
          },
          {
            code: 'HPGAJ', name: '黄埔区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
        ]
      },
      {
        code: 'SZSGAJ', name: '深圳市公安局',
        children: [
          {
            code: 'FTGAJ', name: '福田区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'WAZD', name: '网安支队' },
              { code: 'ZAZD', name: '治安支队' },
            ]
          },
          {
            code: 'NSGAJ', name: '南山区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'JZZD', name: '经侦支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
          {
            code: 'LGGAJ', name: '龙岗区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
        ]
      },
      {
        code: 'FSSGAJ', name: '佛山市公安局',
        children: [
          {
            code: 'NHGAJ', name: '南海区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'JJZD', name: '交警支队' },
            ]
          },
          {
            code: 'SDGAJ', name: '顺德区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
            ]
          },
        ]
      },
      {
        code: 'DGSGAJ', name: '东莞市公安局',
        children: [
          {
            code: 'DGGAJ', name: '东莞区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
        ]
      },
    ]
  },
  {
    code: 'HNSGAJ', name: '湖南省公安厅',
    children: [
      {
        code: 'CSSGAJ', name: '长沙市公安局',
        children: [
          {
            code: 'YTGAJ', name: '雨花区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
              { code: 'PCHZD', name: '派出所' },
            ]
          },
          {
            code: 'TXGAJ', name: '天心区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'WAZD', name: '网安支队' },
            ]
          },
        ]
      },
      {
        code: 'ZZSGAJ', name: '株洲市公安局',
        children: [
          {
            code: 'HTGAJ', name: '荷塘区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'JJZD', name: '交警支队' },
            ]
          },
        ]
      },
    ]
  },
  {
    code: 'JSSGAJ', name: '江苏省公安厅',
    children: [
      {
        code: 'NJSGAJ', name: '南京市公安局',
        children: [
          {
            code: 'XQGAJ', name: '玄武区公安分局',
            children: [
              { code: 'XZZD', name: '刑侦支队' },
              { code: 'ZAZD', name: '治安支队' },
            ]
          },
        ]
      },
    ]
  },
];

// 扁平化所有节点并生成唯一编码
function flattenUnitTree(nodes: UnitTreeNode[], parentPath = ''): { code: string; name: string; fullCode: string; level: number }[] {
  const result: { code: string; name: string; fullCode: string; level: number }[] = [];
  nodes.forEach(node => {
    const fullCode = parentPath ? `${parentPath}.${node.code}` : node.code;
    result.push({ code: node.code, name: node.name, fullCode, level: parentPath.split('.').filter(Boolean).length });
    if (node.children) {
      result.push(...flattenUnitTree(node.children, fullCode));
    }
  });
  return result;
}

// 搜索过滤树 - 匹配节点及其子树都返回
function filterUnitTree(nodes: UnitTreeNode[], query: string): UnitTreeNode[] {
  if (!query.trim()) return [];
  const upper = query.toUpperCase();
  return nodes.reduce<UnitTreeNode[]>((acc, node) => {
    const matchSelf = node.code.toUpperCase().includes(upper) || node.name.includes(query);
    const filteredChildren = node.children ? filterUnitTree(node.children, query) : [];
    if (matchSelf) {
      // 匹配自身，返回完整子树
      acc.push({ ...node });
    } else if (filteredChildren.length > 0) {
      // 子节点匹配，返回自身+过滤后的子节点
      acc.push({ ...node, children: filteredChildren });
    }
    return acc;
  }, []);
}

// 解码 fullCode 为显示文本
export function decodeUnitCode(fullCode: string): string {
  if (!fullCode || !fullCode.includes('.')) {
    // 尝试在树中查找
    const flat = flattenUnitTree(unitTreeData);
    const found = flat.find(f => f.fullCode === fullCode || f.code === fullCode);
    return found ? `${found.name} (${found.code})` : fullCode;
  }
  const parts = fullCode.split('.');
  const names: string[] = [];
  let current = unitTreeData;
  for (let i = 0; i < parts.length; i++) {
    const found = current.find(n => n.code === parts[i]);
    if (found) {
      names.push(`${found.name} (${found.code})`);
      current = found.children || [];
    } else {
      names.push(parts[i]);
      break;
    }
  }
  return names.join(' / ');
}

interface UnitCodeTreeSelectProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
}

export function UnitCodeTreeSelect({ value, onChange, placeholder = '请输入拼音首字母搜索单位', error }: UnitCodeTreeSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const containerRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);

  // 扁平化映射
  const flatMap = useMemo(() => {
    const map = new Map<string, { code: string; name: string }>();
    const traverse = (nodes: UnitTreeNode[], parentPath = '') => {
      nodes.forEach(node => {
        const fullCode = parentPath ? `${parentPath}.${node.code}` : node.code;
        map.set(fullCode, { code: node.code, name: node.name });
        if (node.children) traverse(node.children, fullCode);
      });
    };
    traverse(unitTreeData);
    return map;
  }, []);

  // 搜索过滤
  const filteredTree = useMemo(() => {
    if (!search.trim()) return [];
    return filterUnitTree(unitTreeData, search);
  }, [search]);

  // 自动展开搜索结果
  useEffect(() => {
    if (search.trim()) {
      const newExpanded = new Set<string>();
      const collectCodes = (nodes: UnitTreeNode[], parentPath = '') => {
        nodes.forEach(n => {
          const fc = parentPath ? `${parentPath}.${n.code}` : n.code;
          newExpanded.add(fc);
          if (n.children) collectCodes(n.children, fc);
        });
      };
      collectCodes(filteredTree);
      setExpanded(newExpanded);
    } else {
      setExpanded(new Set());
    }
  }, [search, filteredTree]);

  const selectedEntry = value ? flatMap.get(value) : null;

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 100);
  }, [isOpen]);

  const toggleExpanded = useCallback((fullCode: string) => {
    setExpanded(prev => {
      const next = new Set(prev);
      if (next.has(fullCode)) next.delete(fullCode);
      else next.add(fullCode);
      return next;
    });
  }, []);

  const hasChildren = (node: UnitTreeNode) => node.children && node.children.length > 0;

  const renderNode = (node: UnitTreeNode, parentPath = '', depth = 0) => {
    const fullCode = parentPath ? `${parentPath}.${node.code}` : node.code;
    const isExpanded = expanded.has(fullCode);
    const isSelected = value === fullCode;
    const nodeHasChildren = hasChildren(node);

    return (
      <div key={fullCode}>
        <div
          className={`flex items-center gap-1.5 px-2 py-1.5 rounded-md transition-colors cursor-pointer hover:bg-[#e8ecf5] ${depth > 0 ? 'ml-4' : ''}`}
          onClick={() => {
            if (nodeHasChildren) {
              toggleExpanded(fullCode);
            } else {
              onChange(fullCode);
              setIsOpen(false);
              setSearch('');
            }
          }}
        >
          {nodeHasChildren ? (
            <button
              onClick={e => { e.stopPropagation(); toggleExpanded(fullCode); }}
              className="w-4 h-4 flex items-center justify-center text-slate-400 hover:text-[#1b2370] transition-colors flex-shrink-0"
            >
              {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
            </button>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          {/* 单选圆点（仅叶子节点） */}
          {!nodeHasChildren ? (
            <div
              className={`w-4 h-4 rounded-full border flex items-center justify-center flex-shrink-0 transition-colors ${
                isSelected ? 'border-[#2e3a8c]' : 'border-slate-300 hover:border-[#3b4f9f]'
              }`}
              onClick={e => { e.stopPropagation(); onChange(fullCode); setIsOpen(false); setSearch(''); }}
            >
              {isSelected && <div className="w-2 h-2 rounded-full bg-[#2e3a8c]" />}
            </div>
          ) : (
            <div className="w-4 flex-shrink-0" />
          )}

          {/* 只显示编码，不显示中文名 */}
          <span className={`text-sm font-mono flex-1 truncate ${nodeHasChildren ? 'font-semibold text-slate-700' : 'text-slate-600'}`}>
            {node.code}
          </span>
        </div>

        {nodeHasChildren && isExpanded && (
          <div className="mt-0.5">
            {node.children!.map(child => renderNode(child, fullCode, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div ref={containerRef} className="relative">
      {/* 输入框 */}
      <div
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full min-h-[46px] px-3 py-2 bg-white border rounded-lg text-sm transition-all outline-none cursor-pointer flex items-center gap-2 ${
          isOpen ? 'ring-2 ring-[#1b2370]/20 border-[#3b4f9f]' : error ? 'border-red-300' : 'border-slate-200 hover:border-slate-300'
        }`}
      >
        {!selectedEntry ? (
          <span className="text-slate-400">{placeholder}</span>
        ) : (
          <>
            <Building2 className="w-4 h-4 text-[#1b2370] flex-shrink-0" />
            <span className="text-slate-700 font-mono font-medium flex-1 truncate">{selectedEntry.code}</span>
            <button
              onClick={e => { e.stopPropagation(); onChange(''); }}
              className="p-0.5 hover:bg-red-100 rounded transition-colors flex-shrink-0"
            >
              <X className="w-3.5 h-3.5 text-slate-400 hover:text-red-500" />
            </button>
          </>
        )}
        <ChevronDown className={`w-4 h-4 text-slate-400 ml-auto transition-transform flex-shrink-0 ${isOpen ? 'rotate-180' : ''}`} />
      </div>

      {/* 下拉面板 */}
      {isOpen && (
        <div className="absolute z-50 top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-xl shadow-lg overflow-hidden">
          {/* 搜索框 */}
          <div className="p-2 border-b border-slate-100">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                ref={searchRef}
                type="text"
                placeholder="输入编码或名称搜索，如 XZZD 或 刑侦"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#1b2370]/20 focus:border-[#3b4f9f]"
              />
            </div>
          </div>

          {/* 树形列表 */}
          <div className="max-h-72 overflow-y-auto p-2">
            {search.trim() === '' ? (
              <div className="py-8 text-center text-sm text-slate-400">
                请输入拼音首字母或单位名称搜索
              </div>
            ) : filteredTree.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-400">
                未找到匹配的单位
              </div>
            ) : (
              filteredTree.map(node => renderNode(node))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
