import { useEffect, useState } from 'react';
import { Clock, CheckCircle2, XCircle, Mail, ArrowLeft, RefreshCw } from 'lucide-react';
import { type ReviewInfo } from '@/types/auth';

interface ReviewStatusProps {
  reviewInfo: ReviewInfo | null;
  onGoLogin: () => void;
}

export default function ReviewStatus({ reviewInfo, onGoLogin }: ReviewStatusProps) {
  const [dots, setDots] = useState('');

  // 动态省略号
  useEffect(() => {
    const timer = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);
    return () => clearInterval(timer);
  }, []);

  // 模拟审核完成（演示用：10秒后变为通过）
  const [mockStatus, setMockStatus] = useState<'pending' | 'approved' | 'rejected'>(reviewInfo?.status || 'pending');

  useEffect(() => {
    const timer = setTimeout(() => {
      setMockStatus('approved');
    }, 15000);
    return () => clearTimeout(timer);
  }, []);

  const status = mockStatus;

  return (
    <div className="animate-fade-in text-center">
      {/* 状态图标 */}
      <div className="mb-6">
        {status === 'pending' && (
          <div className="relative w-24 h-24 mx-auto">
            {/* 旋转光环 */}
            <div className="absolute inset-0 rounded-full border-4 border-blue-100" />
            <div className="absolute inset-0 rounded-full border-4 border-transparent border-t-blue-700 animate-spin" />
            <div className="absolute inset-2 rounded-full border-4 border-blue-50" />
            <div className="absolute inset-2 rounded-full border-4 border-transparent border-b-blue-500 spin-slow" />
            {/* 中心图标 */}
            <div className="absolute inset-0 flex items-center justify-center">
              <Clock className="w-10 h-10 text-blue-700" />
            </div>
          </div>
        )}

        {status === 'approved' && (
          <div className="w-24 h-24 mx-auto rounded-full bg-green-100 flex items-center justify-center animate-slide-up">
            <CheckCircle2 className="w-12 h-12 text-green-600" />
          </div>
        )}

        {status === 'rejected' && (
          <div className="w-24 h-24 mx-auto rounded-full bg-red-100 flex items-center justify-center animate-slide-up">
            <XCircle className="w-12 h-12 text-red-600" />
          </div>
        )}
      </div>

      {/* 标题 */}
      <h2 className="text-2xl font-bold text-slate-800 mb-2">
        {status === 'pending' && '资料审核中'}
        {status === 'approved' && '审核已通过'}
        {status === 'rejected' && '审核未通过'}
      </h2>

      {/* 描述 */}
      <p className="text-slate-500 text-sm mb-6 max-w-sm mx-auto">
        {status === 'pending' && (
          <>
            您的供应商注册资料已提交成功，正在接入智能风控审核{dots}
            <br />
            <span className="text-blue-700 font-medium">预计审核时间：{reviewInfo?.estimatedTime || '1-3个工作日'}</span>
          </>
        )}
        {status === 'approved' && (
          <>
            恭喜！您的供应商资质审核已通过
            <br />
            现在可以使用注册账号登录平台
          </>
        )}
        {status === 'rejected' && (
          <>
            很遗憾，您的资料未通过审核
            <br />
            <span className="text-red-600">{reviewInfo?.message || '请检查资料完整性后重新提交'}</span>
          </>
        )}
      </p>

      {/* 信息卡片 */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 mb-6 max-w-sm mx-auto text-left shadow-police">
        <h3 className="text-sm font-medium text-slate-700 mb-3">审核详情</h3>
        <div className="space-y-2.5 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-400">提交时间</span>
            <span className="text-slate-700 font-medium">{reviewInfo?.submitTime || '-'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">审核状态</span>
            <span className={`font-medium ${
              status === 'pending' ? 'text-amber-600' :
              status === 'approved' ? 'text-green-600' : 'text-red-600'
            }`}>
              {status === 'pending' && '审核中'}
              {status === 'approved' && '已通过'}
              {status === 'rejected' && '未通过'}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">预计完成</span>
            <span className="text-slate-700 font-medium">{reviewInfo?.estimatedTime || '-'}</span>
          </div>
          <div className="h-px bg-slate-100 my-2" />
          <div className="flex items-start gap-2">
            <Mail className="w-3.5 h-3.5 text-blue-600 mt-0.5 flex-shrink-0" />
            <p className="text-slate-500">审核结果将通过站内信和邮件/短信同步通知</p>
          </div>
        </div>

        {/* 进度条（审核中时） */}
        {status === 'pending' && (
          <div className="mt-4">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">审核进度</span>
              <span className="text-blue-700 font-medium">审核中</span>
            </div>
            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-blue-600 to-blue-400 rounded-full animate-pulse-slow" style={{ width: '60%' }} />
            </div>
          </div>
        )}
      </div>

      {/* 操作按钮 */}
      <div className="space-y-3 max-w-sm mx-auto">
        {status === 'approved' ? (
          <button
            onClick={onGoLogin}
            className="w-full py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg"
          >
            立即登录
            <ArrowLeft className="w-4 h-4" />
          </button>
        ) : status === 'rejected' ? (
          <button
            onClick={() => window.location.reload()}
            className="w-full py-3 bg-gradient-police text-white rounded-lg font-medium text-sm hover:opacity-95 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-police-lg"
          >
            重新注册
            <RefreshCw className="w-4 h-4" />
          </button>
        ) : (
          <button
            onClick={onGoLogin}
            className="w-full py-3 border-2 border-blue-200 text-blue-700 rounded-lg font-medium text-sm hover:bg-blue-50 active:scale-[0.98] transition-all flex items-center justify-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            返回登录页
          </button>
        )}

        {status === 'pending' && (
          <p className="text-xs text-slate-400">
            提示：15秒后演示自动通过审核
          </p>
        )}
      </div>
    </div>
  );
}
