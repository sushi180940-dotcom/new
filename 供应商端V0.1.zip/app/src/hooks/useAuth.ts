import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router';
import type { AuthView, LoginMethod, RegisterStep, RegisterData, LoginFormData, ForgotPasswordData, ReviewInfo, FormErrors } from '@/types/auth';

const LOGIN_ATTEMPTS_KEY = 'login_attempts';

export function useAuth() {
  const navigate = useNavigate();
  const [currentView, setCurrentView] = useState<AuthView>('login');
  const [loginMethod, setLoginMethod] = useState<LoginMethod>('password');
  const [registerStep, setRegisterStep] = useState<RegisterStep>(1);
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});
  const [loginAttempts, setLoginAttempts] = useState(0);
  const [isFrozen, setIsFrozen] = useState(false);
  const [reviewInfo, setReviewInfo] = useState<ReviewInfo | null>(null);
  const [agreedNotice, setAgreedNotice] = useState(false);
  const [pendingReview, setPendingReview] = useState<{ companyName: string; phone: string; email: string } | null>(null);

  // 注册数据
  const [registerData, setRegisterData] = useState<RegisterData>({
    companyInfo: {
      companyName: '', shortName: '', creditCode: '', registerAddress: '', legalPerson: '',
      registeredCapital: '', registerProvince: '', supplierType: '', cooperationUnit: '',
      contactName: '', idType: '', idNumber: '', contactPhone: '', email: '',
      responsiblePerson: '', loginPhone: '',
    },
    qualificationFiles: {
      businessLicense: null, legalPersonId: null, bankPermit: null, industryLicense: null,
      taxProof: null, taxRating: null, creditChina: null, creditGov: null,
      companyIntro: null, supplyRecord: null,
    },
    accountSecurity: {
      loginAccount: '', password: '', confirmPassword: '', bindPhone: '', verificationCode: '',
    },
  });

  const [loginData, setLoginData] = useState<LoginFormData>({
    account: '13800138000', password: 'password', verificationCode: '', rememberMe: false,
  });

  const [forgotData, setForgotData] = useState<ForgotPasswordData>({
    account: '', verificationCode: '', newPassword: '', confirmPassword: '',
  });

  useEffect(() => {
    const attempts = localStorage.getItem(LOGIN_ATTEMPTS_KEY);
    if (attempts) { setLoginAttempts(parseInt(attempts)); if (parseInt(attempts) >= 5) setIsFrozen(true); }
    const pending = localStorage.getItem('pending_review');
    if (pending) { try { setPendingReview(JSON.parse(pending)); } catch {} }
  }, []);

  const updateCompanyInfo = useCallback((field: string, value: string) => {
    setRegisterData(prev => ({ ...prev, companyInfo: { ...prev.companyInfo, [field]: value } }));
  }, []);
  const updateQualificationFiles = useCallback((field: string, value: File | null) => {
    setRegisterData(prev => ({ ...prev, qualificationFiles: { ...prev.qualificationFiles, [field]: value } }));
  }, []);
  const updateAccountSecurity = useCallback((field: string, value: string) => {
    setRegisterData(prev => ({ ...prev, accountSecurity: { ...prev.accountSecurity, [field]: value } }));
  }, []);

  const validateCompanyInfo = useCallback((): boolean => {
    const c = registerData.companyInfo;
    const e: FormErrors = {};
    if (!c.companyName.trim()) e.companyName = '请输入企业名称';
    if (!c.creditCode.trim()) e.creditCode = '请输入统一社会信用代码';
    if (!c.registerAddress.trim()) e.registerAddress = '请输入注册地';
    if (!c.legalPerson.trim()) e.legalPerson = '请输入法定代表人';
    if (!c.registeredCapital.trim()) e.registeredCapital = '请输入注册资金';
    if (!c.registerProvince.trim()) e.registerProvince = '请选择注册地省（市）';
    if (!c.supplierType) e.supplierType = '请选择供应商类型';
    if (!c.cooperationUnit.trim()) e.cooperationUnit = '请选择合作单位';
    setErrors(e);
    return Object.keys(e).length === 0;
  }, [registerData.companyInfo]);

  const validateQualificationFiles = useCallback((): boolean => {
    const q = registerData.qualificationFiles;
    const e: FormErrors = {};
    if (!q.businessLicense) e.businessLicense = '请上传营业执照副本';
    if (!q.legalPersonId) e.legalPersonId = '请上传法定代表人身份证';
    if (!q.industryLicense) e.industryLicense = '请上传相关生产经营资质许可证';
    if (!q.creditChina) e.creditChina = '请上传"信用中国"信用信息报告';
    if (!q.creditGov) e.creditGov = '请上传"中国政府采购网"信用查询截图';
    setErrors(e);
    return Object.keys(e).length === 0;
  }, [registerData.qualificationFiles]);

  const validateAccountSecurity = useCallback((): boolean => {
    const a = registerData.accountSecurity;
    const e: FormErrors = {};
    if (!a.loginAccount.trim()) e.loginAccount = '请输入登录账号';
    if (!a.password) e.password = '请设置密码';
    else if (a.password.length < 8) e.password = '密码至少8位';
    else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(a.password)) e.password = '需包含大小写字母和数字';
    if (a.password !== a.confirmPassword) e.confirmPassword = '两次密码不一致';
    if (!a.bindPhone.trim()) e.bindPhone = '请输入绑定手机号';
    else if (!/^1[3-9]\d{9}$/.test(a.bindPhone)) e.bindPhone = '手机号格式不正确';
    if (!a.verificationCode || a.verificationCode.length !== 6) e.verificationCode = '请输入6位验证码';
    setErrors(e);
    return Object.keys(e).length === 0;
  }, [registerData.accountSecurity]);

  const validateLogin = useCallback((): boolean => {
    const e: FormErrors = {};
    if (!loginData.account.trim()) e.account = '请输入登录账号';
    if (loginMethod === 'password' && !loginData.password) e.password = '请输入密码';
    if (loginMethod === 'verificationCode' && !loginData.verificationCode) e.verificationCode = '请输入验证码';
    setErrors(e);
    return Object.keys(e).length === 0;
  }, [loginData, loginMethod]);

  const validateForgotPassword = useCallback((): boolean => {
    const e: FormErrors = {};
    if (!forgotData.account.trim()) e.account = '请输入手机号';
    if (!forgotData.verificationCode) e.verificationCode = '请输入验证码';
    if (!forgotData.newPassword) e.newPassword = '请输入新密码';
    if (forgotData.newPassword !== forgotData.confirmPassword) e.confirmPassword = '两次密码不一致';
    setErrors(e);
    return Object.keys(e).length === 0;
  }, [forgotData]);

  const handleLogin = useCallback(async () => {
    if (isFrozen) return;
    if (!validateLogin()) return;
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    if (loginMethod === 'password' && loginData.password !== 'password') {
      const na = loginAttempts + 1;
      setLoginAttempts(na); localStorage.setItem(LOGIN_ATTEMPTS_KEY, String(na));
      if (na >= 5) { setIsFrozen(true); setErrors({ general: '连续5次密码错误，账户已临时冻结，请使用验证码登录' }); }
      else { setErrors({ general: `密码错误，还剩 ${5 - na} 次机会` }); }
      setIsLoading(false); return;
    }
    const pending = localStorage.getItem('pending_review');
    if (pending) {
      try { const p = JSON.parse(pending);
        if (p.phone === loginData.account) { setPendingReview(p); setIsLoading(false); setErrors({ general: '您的企业信息正在审核中，请联系意向供货单位' }); return; }
      } catch {}
    }
    localStorage.removeItem(LOGIN_ATTEMPTS_KEY); setLoginAttempts(0); setIsFrozen(false); setErrors({}); setIsLoading(false);
    navigate('/dashboard');
  }, [validateLogin, loginAttempts, isFrozen, loginMethod, loginData, navigate]);

  const handleRegister = useCallback(async () => {
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 2000));
    const pendingInfo = { companyName: registerData.companyInfo.companyName, phone: registerData.companyInfo.loginPhone, email: '' };
    localStorage.setItem('pending_review', JSON.stringify(pendingInfo)); setPendingReview(pendingInfo);
    setIsLoading(false);
    setReviewInfo({ status: 'pending', submitTime: new Date().toLocaleString('zh-CN'), estimatedTime: '1-3个工作日' });
    setCurrentView('reviewStatus');
  }, [registerData.companyInfo]);

  const handleForgotPassword = useCallback(async () => {
    if (!validateForgotPassword()) return;
    setIsLoading(true);
    await new Promise(r => setTimeout(r, 1500));
    setIsLoading(false);
    alert('密码重置成功！请使用新密码登录。');
    setCurrentView('login');
  }, [validateForgotPassword]);

  const goToRegister = useCallback(() => { setCurrentView('register'); setRegisterStep(1); setAgreedNotice(false); setErrors({}); }, []);
  const goToLogin = useCallback(() => { setCurrentView('login'); setErrors({}); setLoginMethod('password'); }, []);
  const goToForgotPassword = useCallback(() => { setCurrentView('forgotPassword'); setErrors({}); }, []);

  const nextStep = useCallback(() => {
    if (registerStep === 1) {
      if (agreedNotice) { if (validateCompanyInfo()) { setRegisterStep(2); setErrors({}); } }
      else { setErrors({ notice: '请先阅读并勾选同意注册须知' }); }
    } else if (registerStep === 2) {
      if (validateAccountSecurity()) { handleRegister(); }
    }
  }, [registerStep, agreedNotice, validateCompanyInfo, validateAccountSecurity, handleRegister]);

  const prevStep = useCallback(() => { if (registerStep > 1) { setRegisterStep(prev => (prev - 1) as RegisterStep); setErrors({}); } }, [registerStep]);
  const goToStep = useCallback((step: RegisterStep) => { setRegisterStep(step); setErrors({}); }, []);

  return {
    currentView, loginMethod, registerStep, isLoading, errors, loginAttempts, isFrozen, reviewInfo, agreedNotice, pendingReview,
    registerData, loginData, forgotData,
    setCurrentView, setLoginMethod, setRegisterStep, setIsLoading, setErrors, setLoginData, setForgotData, setReviewInfo, setAgreedNotice,
    updateCompanyInfo, updateQualificationFiles, updateAccountSecurity,
    validateCompanyInfo, validateQualificationFiles, validateAccountSecurity, validateLogin, validateForgotPassword,
    handleLogin, handleRegister, handleForgotPassword,
    goToRegister, goToLogin, goToForgotPassword, nextStep, prevStep, goToStep,
  };
}
