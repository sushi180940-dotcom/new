import { useEffect, useRef } from 'react'
import { BarChart2, TrendingUp, TrendingDown, Award } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const suppliers = [
  { name: '某安防科技有限公司', grade: 'A', gradeColor: '#10B981', score: 92.5, dimensions: { supply: 95, quality: 90, service: 93, price: 88, credit: 96, innovation: 92 }, trend: 'up' as const, change: 2.3 },
  { name: '某装备集团有限公司', grade: 'A', gradeColor: '#10B981', score: 89.2, dimensions: { supply: 88, quality: 92, service: 85, price: 90, credit: 94, innovation: 87 }, trend: 'up' as const, change: 1.5 },
  { name: '某警用器材有限公司', grade: 'B+', gradeColor: '#3B82F6', score: 84.6, dimensions: { supply: 82, quality: 86, service: 88, price: 85, credit: 90, innovation: 80 }, trend: 'down' as const, change: 0.8 },
  { name: '某防护设备有限公司', grade: 'B+', gradeColor: '#3B82F6', score: 82.1, dimensions: { supply: 80, quality: 84, service: 82, price: 88, credit: 85, innovation: 78 }, trend: 'up' as const, change: 1.2 },
  { name: '某通信科技有限公司', grade: 'B', gradeColor: '#F59E0B', score: 78.4, dimensions: { supply: 75, quality: 80, service: 78, price: 82, credit: 80, innovation: 85 }, trend: 'down' as const, change: 2.1 },
  { name: '新宇安防科技股份有限公司', grade: 'B', gradeColor: '#F59E0B', score: 76.8, dimensions: { supply: 78, quality: 74, service: 80, price: 76, credit: 82, innovation: 88 }, trend: 'up' as const, change: 3.5 },
  { name: '恒达警用装备制造厂', grade: 'B-', gradeColor: '#8B5CF6', score: 73.5, dimensions: { supply: 72, quality: 76, service: 70, price: 78, credit: 75, innovation: 72 }, trend: 'down' as const, change: 1.8 },
  { name: '国安器材有限责任公司', grade: 'C+', gradeColor: '#EF4444', score: 68.2, dimensions: { supply: 65, quality: 70, service: 68, price: 72, credit: 70, innovation: 62 }, trend: 'down' as const, change: 3.2 },
]

const trendYears = ['2021', '2022', '2023', '2024', '2025']
const trendScores: Record<string, number[]> = {
  '华东安防科技': [85, 87, 89, 90, 92.5],
  '北方装备集团': [82, 84, 86, 87, 89.2],
  '中天警用器材': [80, 81, 82, 83, 84.6],
  '南方防护设备': [76, 78, 79, 80, 82.1],
  '西部通信科技': [80, 79, 78, 79, 78.4],
}

const tableData = suppliers.map((s, i) => ({
  rank: i + 1,
  name: s.name,
  grade: s.grade,
  score: s.score,
  prevRank: [3, 2, 1, 5, 4, 7, 6, 8][i],
  supply: s.dimensions.supply,
  quality: s.dimensions.quality,
  service: s.dimensions.service,
  price: s.dimensions.price,
  credit: s.dimensions.credit,
}))

const dimLabels: Record<string, string> = { supply: '供货能力', quality: '产品质量', service: '售后服务', price: '价格竞争力', credit: '企业信用', innovation: '创新能力' }

export default function SupplierAnalysisPage() {
  const trendRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!trendRef.current) return
    const chart = echarts.init(trendRef.current)
    chart.setOption({
      title: { text: '供应商历史评分趋势', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '2021-2025年综合评分变化', subtextStyle: { fontSize: 11, color: '#6B7280' } },
      tooltip: { trigger: 'axis' },
      legend: { data: Object.keys(trendScores), top: 0, right: 0, textStyle: { fontSize: 9 } },
      grid: { left: 50, right: 20, top: 60, bottom: 30 },
      xAxis: { type: 'category', data: trendYears, axisLabel: { fontSize: 10, color: '#6B7280' } },
      yAxis: { type: 'value', min: 60, max: 100, axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
      series: Object.entries(trendScores).map(([name, data], i) => ({
        name, type: 'line' as const, data, smooth: true,
        lineStyle: { width: 2, color: ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444'][i] },
        itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444'][i] },
        symbol: 'circle', symbolSize: 5,
      })),
      animationDuration: 1000,
    } as echarts.EChartsOption)
    const ro = new ResizeObserver(() => chart.resize())
    ro.observe(trendRef.current)
    return () => { ro.disconnect(); chart.dispose() }
  }, [])

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">供应商能力分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">供应商综合评估与能力排名分析</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">分析维度</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>综合评分</option><option>供货能力</option><option>产品质量</option><option>售后服务</option><option>价格竞争力</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">供应商等级</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部</option><option>A级</option><option>B级</option><option>C级</option>
            </select>
          </div>
        </div>
      </div>

      {/* Supplier Score Cards */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {suppliers.map((s, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-full" style={{ background: s.gradeColor + '20' }}>
                  <Award size={14} style={{ color: s.gradeColor }} />
                </div>
                <div>
                  <div className="text-sm font-semibold text-[#1F2937]">{s.name.replace(/有限公司|有限责任|股份|制造厂/, '').replace(/集团/, '集团')}</div>
                  <div className="flex items-center gap-1">
                    <span className="text-xs font-bold" style={{ color: s.gradeColor }}>{s.grade}级</span>
                    {s.trend === 'up' ? <TrendingUp size={10} className="text-[#10B981]" /> : <TrendingDown size={10} className="text-[#EF4444]" />}
                    <span className={cn('text-[10px]', s.trend === 'up' ? 'text-[#10B981]' : 'text-[#EF4444]')}>{s.trend === 'up' ? '+' : '-'}{s.change}</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-[24px] font-bold text-[#1F2937]">{s.score}</div>
                <span className="text-[10px] text-[#6B7280]">综合评分</span>
              </div>
            </div>
            {/* Mini radar */}
            <div className="mt-3" style={{ height: 140 }}>
              <SupplierMiniRadar dimensions={s.dimensions} color={s.gradeColor} />
            </div>
            {/* Dimension bars */}
            <div className="mt-2 space-y-1.5">
              {Object.entries(s.dimensions).map(([k, v]) => (
                <div key={k} className="flex items-center gap-2">
                  <span className="w-14 text-[10px] text-[#6B7280]">{dimLabels[k]}</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-[#F3F4F6]">
                    <div className="h-full rounded-full transition-all" style={{ width: `${v}%`, background: s.gradeColor }} />
                  </div>
                  <span className="w-6 text-right text-[10px] text-[#374151]">{v}</span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Trend chart */}
      <div className="mb-4 rounded-lg bg-white p-5 shadow-md">
        <div ref={trendRef} style={{ width: '100%', height: 340 }} />
      </div>

      {/* Ranking table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-[#1F2937]">供应商排名对比</h3>
          <span className="text-xs text-[#6B7280]">共 {tableData.length} 家供应商</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['排名', '变化', '供应商名称', '等级', '综合评分', '供货能力', '产品质量', '售后服务', '价格竞争力', '企业信用'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((row, i) => {
                const rankChange = row.prevRank - row.rank
                return (
                  <tr key={i} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                    <td className="px-3 py-3">
                      <span className={cn('inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold', i < 3 ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#374151]')}>{row.rank}</span>
                    </td>
                    <td className="px-3 py-3">
                      {rankChange > 0 ? (
                        <span className="flex items-center gap-0.5 text-xs text-[#10B981]"><TrendingUp size={12} /> ↑{rankChange}</span>
                      ) : rankChange < 0 ? (
                        <span className="flex items-center gap-0.5 text-xs text-[#EF4444]"><TrendingDown size={12} /> ↓{Math.abs(rankChange)}</span>
                      ) : (
                        <span className="text-xs text-[#6B7280]">-</span>
                      )}
                    </td>
                    <td className="px-3 py-3 font-medium text-[#1F2937]">{row.name}</td>
                    <td className="px-3 py-3"><Badge variant={row.grade.startsWith('A') ? 'success' : row.grade.startsWith('B') ? 'warning' : 'danger'}>{row.grade}级</Badge></td>
                    <td className="px-3 py-3 font-bold text-[#1A56DB]">{row.score}</td>
                    <td className="px-3 py-3 text-[#374151]">{row.supply}</td>
                    <td className="px-3 py-3 text-[#374151]">{row.quality}</td>
                    <td className="px-3 py-3 text-[#374151]">{row.service}</td>
                    <td className="px-3 py-3 text-[#374151]">{row.price}</td>
                    <td className="px-3 py-3 text-[#374151]">{row.credit}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

function SupplierMiniRadar({ dimensions, color }: { dimensions: Record<string, number>; color: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current) return
    const chart = echarts.init(ref.current, undefined, { renderer: 'svg' })
    const keys = Object.keys(dimensions)
    chart.setOption({
      radar: {
        indicator: keys.map((k) => ({ name: dimLabels[k] || k, max: 100 })),
        radius: '65%',
        splitNumber: 3,
        axisName: { fontSize: 8, color: '#6B7280' },
        splitLine: { lineStyle: { color: '#E5E7EB' } },
        splitArea: { show: false },
        axisLine: { lineStyle: { color: '#E5E7EB' } },
      },
      series: [{
        type: 'radar',
        data: [{ value: Object.values(dimensions), name: '评分' }],
        lineStyle: { width: 1.5, color },
        itemStyle: { color },
        areaStyle: { color: color + '25' },
        symbolSize: 2,
        label: { show: false },
      }],
      animation: false,
    } as echarts.EChartsOption)
    const ro = new ResizeObserver(() => chart.resize())
    ro.observe(ref.current)
    return () => { ro.disconnect(); chart.dispose() }
  }, [dimensions, color])
  return <div ref={ref} style={{ width: '100%', height: '100%' }} />
}
