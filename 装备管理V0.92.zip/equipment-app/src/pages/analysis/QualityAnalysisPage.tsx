import { useEffect, useRef } from 'react'
import { BarChart2, AlertTriangle } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const categories = ['防弹背心', '执法记录仪', '手铐', '防刺服', '催泪喷射器', '对讲机', '强光手电', '急救包', '防弹头盔', '警用腰带']
const passRates = [97.5, 94.2, 98.8, 96.5, 95.8, 93.5, 92.1, 97.8, 95.5, 96.2]

const manufacturers = ['华东安防', '北方装备', '中天器材', '南方防护', '西部通信', '新宇安防', '恒达制造']
const mfgRates = [96.2, 95.8, 93.5, 94.8, 92.5, 91.2, 90.5]

const fmeaData = [
  { mode: '电池续航衰减', frequency: 42, severity: 6, detection: 4, rpn: 1008, category: '执法记录仪' },
  { mode: '外壳开裂破损', frequency: 35, severity: 5, detection: 5, rpn: 875, category: '防弹背心' },
  { mode: '信号接收不稳', frequency: 28, severity: 7, detection: 3, rpn: 588, category: '对讲机' },
  { mode: '充电接口松动', frequency: 38, severity: 4, detection: 6, rpn: 912, category: '执法记录仪' },
  { mode: '镜片雾化模糊', frequency: 22, severity: 6, detection: 5, rpn: 660, category: '强光手电' },
  { mode: '卡扣锁死失效', frequency: 18, severity: 8, detection: 4, rpn: 576, category: '手铐' },
  { mode: '密封条老化', frequency: 25, severity: 5, detection: 6, rpn: 750, category: '防刺服' },
  { mode: '喷头堵塞', frequency: 20, severity: 7, detection: 5, rpn: 700, category: '催泪喷射器' },
  { mode: '织带磨损断裂', frequency: 30, severity: 4, detection: 7, rpn: 840, category: '警用腰带' },
  { mode: '内衬脱落', frequency: 15, severity: 5, detection: 6, rpn: 450, category: '防弹头盔' },
]

const spcMonths = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
const spcValues = [97.2, 96.8, 97.5, 96.5, 95.8, 97.0, 96.2, 95.5, 96.8, 97.5, 96.0, 97.2]
const UCL = 98.5
const LCL = 94.5
const CL = 96.5

export default function QualityAnalysisPage() {
  const catRef = useRef<HTMLDivElement>(null)
  const mfgRef = useRef<HTMLDivElement>(null)
  const spcRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cleanups: (() => void)[] = []

    // 按品类合格率
    if (catRef.current) {
      const chart = echarts.init(catRef.current)
      chart.setOption({
        title: { text: '质量合格率(按品类)', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '年度质检合格率(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
        grid: { left: 50, right: 20, top: 60, bottom: 50 },
        xAxis: { type: 'category', data: categories, axisLabel: { fontSize: 10, color: '#6B7280', rotate: 30 } },
        yAxis: { type: 'value', min: 85, max: 100, axisLabel: { fontSize: 10, color: '#6B7280', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{
          type: 'bar', data: passRates.map((v) => ({
            value: v, itemStyle: { color: v >= 97 ? '#10B981' : v >= 94 ? '#F59E0B' : '#EF4444', borderRadius: [4, 4, 0, 0] },
          })),
          barWidth: '50%', label: { show: true, position: 'top', fontSize: 10, formatter: '{c}%' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(catRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 按厂家合格率
    if (mfgRef.current) {
      const chart = echarts.init(mfgRef.current)
      chart.setOption({
        title: { text: '质量合格率(按厂家)', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '各制造商合格率对比(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
        grid: { left: 50, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'value', min: 85, max: 100, axisLabel: { fontSize: 10, color: '#6B7280', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'category', data: manufacturers, axisLabel: { fontSize: 10, color: '#374151' } },
        series: [{
          type: 'bar', data: mfgRates.map((v) => ({
            value: v, itemStyle: { color: v >= 95 ? '#10B981' : v >= 92 ? '#F59E0B' : '#EF4444', borderRadius: [0, 4, 4, 0] },
          })),
          barWidth: '50%', label: { show: true, position: 'right', fontSize: 10, formatter: '{c}%' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(mfgRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // SPC控制图
    if (spcRef.current) {
      const chart = echarts.init(spcRef.current)
      chart.setOption({
        title: { text: '质量趋势控制图(SPC)', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '月度合格率趋势与上下控制线', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        legend: { data: ['合格率', 'UCL', 'CL', 'LCL'], top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 50, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: spcMonths, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', min: 92, max: 100, axisLabel: { fontSize: 10, color: '#6B7280', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [
          { name: '合格率', type: 'line', data: spcValues, smooth: true, lineStyle: { width: 2, color: '#1A56DB' }, itemStyle: { color: '#1A56DB' }, symbol: 'circle', symbolSize: 6 },
          { name: 'UCL', type: 'line', data: spcMonths.map(() => UCL), lineStyle: { width: 1, color: '#EF4444', type: 'dashed' }, itemStyle: { color: '#EF4444' }, symbol: 'none' },
          { name: 'CL', type: 'line', data: spcMonths.map(() => CL), lineStyle: { width: 1.5, color: '#10B981' }, itemStyle: { color: '#10B981' }, symbol: 'none' },
          { name: 'LCL', type: 'line', data: spcMonths.map(() => LCL), lineStyle: { width: 1, color: '#EF4444', type: 'dashed' }, itemStyle: { color: '#EF4444' }, symbol: 'none' },
        ],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(spcRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  const rpnLevel = (rpn: number) => rpn >= 800 ? 'danger' as const : rpn >= 500 ? 'warning' as const : 'info' as const
  const rpnLabel = (rpn: number) => rpn >= 800 ? '高风险' : rpn >= 500 ? '中风险' : '低风险'

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">装备质量分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">装备质量合格率、故障模式与过程控制分析</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">分析维度</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>按品类</option><option>按厂家</option><option>按批次</option><option>按时间</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">装备类别</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部品类</option><option>防护装备</option><option>执法装备</option><option>通信装备</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">时间范围</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>近1年</option><option>近3年</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {[
          { label: '平均合格率', value: '96.2%', sub: '↑ 0.3% 同比' },
          { label: '高风险故障模式', value: '3项', sub: '需重点关注' },
          { label: '年度质检批次', value: '1,256批', sub: '↑ 8.5% 同比' },
          { label: '质量事故', value: '2起', sub: '↓ 50% 同比' },
        ].map((s, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <span className="text-[13px] text-[#6B7280]">{s.label}</span>
            <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value}</div>
            <span className="mt-1 text-xs text-[#6B7280]">{s.sub}</span>
          </div>
        ))}
      </div>

      {/* Charts row 1 */}
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={catRef} style={{ width: '100%', height: 320 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={mfgRef} style={{ width: '100%', height: 320 }} />
        </div>
      </div>

      {/* SPC Chart */}
      <div className="mb-4 rounded-lg bg-white p-5 shadow-md">
        <div ref={spcRef} style={{ width: '100%', height: 340 }} />
      </div>

      {/* FMEA Table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} className="text-[#F59E0B]" />
            <h3 className="text-base font-semibold text-[#1F2937]">故障模式FMEA分析</h3>
          </div>
          <span className="text-xs text-[#6B7280]">共 {fmeaData.length} 条记录</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['故障模式', '装备品类', '发生频率', '严重度', '探测度', 'RPN', '风险等级', '建议措施'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {fmeaData.map((row, i) => (
                <tr key={i} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.mode}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.category}</td>
                  <td className="px-3 py-3 text-center text-[#374151]">{row.frequency}</td>
                  <td className="px-3 py-3 text-center text-[#374151]">{row.severity}</td>
                  <td className="px-3 py-3 text-center text-[#374151]">{row.detection}</td>
                  <td className="px-3 py-3 text-center font-bold text-[#1F2937]">{row.rpn}</td>
                  <td className="px-3 py-3"><Badge variant={rpnLevel(row.rpn)}>{rpnLabel(row.rpn)}</Badge></td>
                  <td className="px-3 py-3 text-xs text-[#374151]">
                    {row.rpn >= 800 ? '加强来料检验，增加供应商审核频次' : row.rpn >= 600 ? '优化工艺参数，增加在线检测' : '常规质量监控'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
