import { useEffect, useRef } from 'react'
import { BarChart2, Star, Wrench } from 'lucide-react'
import * as echarts from 'echarts'

/* ── mock data ── */
const repairMonths = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
const repairCounts = [45, 52, 38, 42, 56, 48, 62, 55, 49, 44, 58, 51]
const responseTimes = [
  { value: [24, 8.5], name: '华东安防科技' },
  { value: [18, 12.3], name: '北方装备集团' },
  { value: [32, 6.2], name: '中天警用器材' },
  { value: [15, 15.8], name: '南方防护设备' },
  { value: [28, 9.6], name: '西部通信科技' },
  { value: [12, 22.1], name: '新宇安防科技' },
  { value: [20, 10.4], name: '恒达警用装备' },
  { value: [35, 5.8], name: '国安器材公司' },
  { value: [10, 18.5], name: '锐盾防护科技' },
  { value: [22, 11.2], name: '正大警械制造' },
]

const costTrendYears = ['2021', '2022', '2023', '2024', '2025']
const costTrendData = {
  '维修费用(万元)': [128, 156, 142, 168, 145],
  '配件费用(万元)': [85, 98, 92, 110, 88],
  '人工费用(万元)': [43, 58, 50, 58, 57],
}

const warrantyEquip = ['防弹背心', '执法记录仪', '对讲机', '防刺服', '催泪喷射器', '强光手电', '急救包', '防弹头盔']
const warrantyFailRate = [2.5, 4.8, 3.2, 1.8, 3.5, 5.2, 2.1, 1.5]
const outOfWarrantyFailRate = [6.2, 12.5, 8.8, 4.5, 9.2, 14.8, 5.5, 3.8]

const satisfactionData = [
  { name: '华东安防科技', score: 4.8, total: 256 },
  { name: '北方装备集团', score: 4.5, total: 189 },
  { name: '中天警用器材', score: 4.2, total: 142 },
  { name: '南方防护设备', score: 4.6, total: 178 },
  { name: '西部通信科技', score: 4.0, total: 98 },
  { name: '新宇安防科技', score: 4.3, total: 125 },
]

const wordCloudData = [
  { name: '电池续航', value: 95 },
  { name: '屏幕故障', value: 82 },
  { name: '充电口损坏', value: 78 },
  { name: '外壳磨损', value: 72 },
  { name: '按键失灵', value: 68 },
  { name: '信号不稳', value: 65 },
  { name: '摄像头模糊', value: 60 },
  { name: '存储故障', value: 55 },
  { name: '接口松动', value: 52 },
  { name: '防水失效', value: 48 },
  { name: '背光不亮', value: 45 },
  { name: '声音异常', value: 42 },
  { name: '外壳开裂', value: 38 },
  { name: '卡扣损坏', value: 35 },
  { name: '拉链故障', value: 30 },
  { name: '织带断裂', value: 28 },
  { name: '镜片划痕', value: 25 },
  { name: '电路老化', value: 22 },
  { name: '接触不良', value: 20 },
  { name: '标签脱落', value: 15 },
]

export default function AftersalesAnalysisPage() {
  const freqRef = useRef<HTMLDivElement>(null)
  const scatterRef = useRef<HTMLDivElement>(null)
  const costRef = useRef<HTMLDivElement>(null)
  const warrantyRef = useRef<HTMLDivElement>(null)
  const wordCloudRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cleanups: (() => void)[] = []

    // 报修频率柱状图
    if (freqRef.current) {
      const chart = echarts.init(freqRef.current)
      chart.setOption({
        title: { text: '报修频率统计', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '月度报修次数', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        grid: { left: 45, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: repairMonths, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', name: '次数', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{ type: 'bar', data: repairCounts, barWidth: '50%', itemStyle: { color: '#1A56DB', borderRadius: [4, 4, 0, 0] } }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(freqRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 维修响应时效散点图
    if (scatterRef.current) {
      const chart = echarts.init(scatterRef.current)
      chart.setOption({
        title: { text: '维修响应时效分析', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '响应时效 vs 报修次数', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { formatter: (p: any) => `${p.data.name}<br/>年报修: ${p.data.value[0]}次<br/>平均响应: ${p.data.value[1]}小时` },
        grid: { left: 50, right: 20, top: 60, bottom: 40 },
        xAxis: { type: 'value', name: '年报修次数', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'value', name: '平均响应(小时)', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{
          type: 'scatter', data: responseTimes.map((d) => ({ value: d.value, name: d.name })),
          symbolSize: (data: any) => Math.sqrt(data[0]) * 5,
          itemStyle: { color: (p: any) => { const v = p.data.value[1]; return v <= 8 ? '#10B981' : v <= 15 ? '#F59E0B' : '#EF4444' } },
          label: { show: true, formatter: (p: any) => p.data.name, fontSize: 9, position: 'top' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(scatterRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 维修费用趋势
    if (costRef.current) {
      const chart = echarts.init(costRef.current)
      chart.setOption({
        title: { text: '维修费用趋势', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '年度费用构成(万元)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        legend: { data: Object.keys(costTrendData), top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 50, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: costTrendYears, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: Object.entries(costTrendData).map(([name, data], i) => ({
          name, type: 'line' as const, data, smooth: true, stack: 'total',
          areaStyle: { opacity: 0.2 },
          lineStyle: { width: 2, color: ['#1A56DB', '#10B981', '#F59E0B'][i] },
          itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B'][i] },
          symbol: 'circle', symbolSize: 4,
        })),
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(costRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 质保期内故障率对比
    if (warrantyRef.current) {
      const chart = echarts.init(warrantyRef.current)
      chart.setOption({
        title: { text: '质保期内外故障率对比', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '按装备品类(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: { data: ['质保期内', '质保期外'], top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 80, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'value', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'category', data: warrantyEquip, axisLabel: { fontSize: 10, color: '#374151' } },
        series: [
          { name: '质保期内', type: 'bar', data: warrantyFailRate, barWidth: '35%', itemStyle: { color: '#F59E0B', borderRadius: [0, 4, 4, 0] } },
          { name: '质保期外', type: 'bar', data: outOfWarrantyFailRate, barWidth: '35%', itemStyle: { color: '#EF4444', borderRadius: [0, 4, 4, 0] } },
        ],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(warrantyRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    // 售后问题词云 (用标签气泡形式)
    if (wordCloudRef.current) {
      const chart = echarts.init(wordCloudRef.current)
      const maxVal = Math.max(...wordCloudData.map((d) => d.value))
      const minVal = Math.min(...wordCloudData.map((d) => d.value))
      chart.setOption({
        title: { text: '售后问题关键词', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '问题频次分析', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { formatter: (p: any) => `${p.name}: ${p.value}次` },
        series: [{
          type: 'graph', layout: 'force', animation: true,
          roam: false,
          label: { show: true, fontSize: (p: any) => 10 + (p.data.value - minVal) / (maxVal - minVal) * 14, color: '#374151', fontWeight: (p: any) => p.data.value > 60 ? 'bold' : 'normal' },
          draggable: false,
          force: { repulsion: 200, edgeLength: 10 },
          data: wordCloudData.map((d, i) => ({
            name: d.name, value: d.value,
            itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'][i % 8] },
            symbolSize: 20 + (d.value - minVal) / (maxVal - minVal) * 50,
            label: { show: true },
          })),
          edges: [],
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(wordCloudRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">装备售后研判分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">装备售后数据分析与服务质量评估</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">分析维度</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>按装备</option><option>按供应商</option><option>按时间</option><option>按单位</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">装备类别</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部品类</option><option>防护装备</option><option>执法装备</option><option>通信装备</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">时间范围</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>近1年</option><option>近3年</option><option>近5年</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stats row */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {[
          { label: '年度报修总量', value: '602次', sub: '↑ 5.2% 同比' },
          { label: '平均响应时效', value: '11.6h', sub: '↓ 8.5% 优化' },
          { label: '年度维修费用', value: '¥145万', sub: '↓ 13.7% 同比' },
          { label: '平均满意度', value: '4.4/5.0', sub: '↑ 0.3 提升' },
        ].map((s, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <span className="text-[13px] text-[#6B7280]">{s.label}</span>
            <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value}</div>
            <span className="mt-1 text-xs text-[#10B981]">{s.sub}</span>
          </div>
        ))}
      </div>

      {/* Chart row 1 */}
      <div className="mb-4 grid grid-cols-3 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={freqRef} style={{ width: '100%', height: 300 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={scatterRef} style={{ width: '100%', height: 300 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={costRef} style={{ width: '100%', height: 300 }} />
        </div>
      </div>

      {/* Chart row 2 */}
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={warrantyRef} style={{ width: '100%', height: 340 }} />
        </div>
        {/* Satisfaction cards */}
        <div className="rounded-lg bg-white p-5 shadow-md">
          <h3 className="mb-4 text-base font-semibold text-[#1F2937]">供应商售后服务满意度</h3>
          <div className="grid grid-cols-2 gap-3">
            {satisfactionData.map((s, i) => (
              <div key={i} className="rounded-lg border border-[#E5E7EB] p-4 transition hover:shadow-md">
                <div className="flex items-center gap-2">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#E8F0FE]">
                    <Wrench size={14} className="text-[#1A56DB]" />
                  </div>
                  <span className="text-sm font-medium text-[#1F2937]">{s.name}</span>
                </div>
                <div className="mt-2 flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star key={j} size={14} className={j < Math.floor(s.score) ? 'fill-[#F59E0B] text-[#F59E0B]' : j < s.score ? 'fill-[#F59E0B]/50 text-[#F59E0B]' : 'text-[#D1D5DB]'} />
                  ))}
                  <span className="ml-1 text-sm font-bold text-[#1F2937]">{s.score}</span>
                </div>
                <span className="mt-1 text-xs text-[#6B7280]">{s.total}人评价</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Word Cloud */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div ref={wordCloudRef} style={{ width: '100%', height: 320 }} />
      </div>
    </div>
  )
}
