import { useEffect, useRef } from 'react'
import { BarChart2, TrendingUp, TrendingDown } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const cities = ['YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市', 'YYY市']
const equipCategories = ['防弹背心', '执法记录仪', '手铐', '防刺服', '催泪喷射器', '对讲机', '强光手电', '急救包', '防弹头盔', '警用腰带']

// Heatmap data: compliance rates (0-100)
const heatmapData: [number, number, number][] = []
const heatmapValues = [
  [92,88,95,78,85,90,82,87,91,79,83,86,80,77,84,81,89],
  [85,82,88,75,80,84,78,83,86,74,79,81,76,73,80,77,85],
  [96,94,97,92,93,95,91,94,96,90,92,93,89,88,91,90,95],
  [90,87,92,80,85,88,82,86,89,79,83,85,81,78,84,82,88],
  [88,85,90,76,82,86,80,84,87,75,81,83,78,74,82,79,87],
  [78,75,82,68,72,76,70,74,79,66,71,73,69,65,73,70,77],
  [82,79,86,72,78,81,75,80,83,71,77,79,74,70,78,76,82],
  [86,83,89,77,81,85,79,82,87,76,80,84,78,75,82,80,86],
  [91,89,93,84,87,90,85,88,92,83,86,88,84,82,87,85,90],
  [94,92,96,88,90,93,87,91,95,86,89,91,87,85,90,88,93],
]
for (let i = 0; i < equipCategories.length; i++) {
  for (let j = 0; j < cities.length; j++) {
    heatmapData.push([j, i, heatmapValues[i][j]])
  }
}

const radarIndicators = [
  { name: '防护装备', max: 100 },
  { name: '执法装备', max: 100 },
  { name: '通信装备', max: 100 },
  { name: '警用器械', max: 100 },
  { name: '约束装备', max: 100 },
  { name: '交通装备', max: 100 },
  { name: '医疗装备', max: 100 },
  { name: '服装装具', max: 100 },
]
const radarData = [
  { value: [92, 85, 78, 88, 96, 82, 86, 94], name: '全省平均' },
  { value: [88, 90, 85, 82, 94, 78, 80, 90], name: 'YYY市' },
]

const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
const trendData = {
  '2024年': [82, 83, 84, 85, 86, 86, 87, 87, 88, 88, 89, 89],
  '2025年': [85, 85, 86, 86, 87, 87, 88, 88, 89, 89, 90, 90],
  '2026年(预测)': [87, 88, 88, 89, 89, 90, 90, 91, 91, 92, 92, 93],
}

const priorityData = [
  { name: '对讲机PD780G', gap: 320, rate: 62 },
  { name: '执法记录仪DSJ-A8', gap: 280, rate: 68 },
  { name: '防弹背心III级', gap: 220, rate: 74 },
  { name: '防弹头盔M88', gap: 180, rate: 78 },
  { name: '防刺服FCF-J-SD', gap: 150, rate: 80 },
  { name: '催泪喷射器(手持)', gap: 120, rate: 83 },
  { name: '强光手电T6', gap: 80, rate: 88 },
  { name: '手铐(不锈钢)', gap: 60, rate: 90 },
  { name: '急救包(标准型)', gap: 40, rate: 93 },
  { name: '警用腰带(多功能)', gap: 20, rate: 96 },
]

const tableData = [
  { city: 'YYY市', rate: 92, index: 0.88, gap: 120, status: '良好' as const },
  { city: 'YYY市', rate: 88, index: 0.82, gap: 210, status: '良好' as const },
  { city: 'YYY市', rate: 85, index: 0.78, gap: 280, status: '一般' as const },
  { city: 'YYY市', rate: 82, index: 0.72, gap: 350, status: '一般' as const },
  { city: 'YYY市', rate: 78, index: 0.68, gap: 420, status: '不足' as const },
  { city: 'YYY市', rate: 76, index: 0.65, gap: 480, status: '不足' as const },
  { city: 'YYY市', rate: 74, index: 0.62, gap: 510, status: '不足' as const },
  { city: 'YYY市', rate: 72, index: 0.60, gap: 560, status: '不足' as const },
]

const statusVariant = (s: string) => s === '良好' ? 'success' as const : s === '一般' ? 'warning' as const : 'danger' as const

export default function AllocationAnalysisPage() {
  const heatRef = useRef<HTMLDivElement>(null)
  const radarRef = useRef<HTMLDivElement>(null)
  const trendRef = useRef<HTMLDivElement>(null)
  const barRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cleanups: (() => void)[] = []

    if (heatRef.current) {
      const chart = echarts.init(heatRef.current)
      chart.setOption({
        title: { text: '配备达标率热力图', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '行=装备品类, 列=省辖市(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { position: 'top', formatter: (p: any) => `${equipCategories[p.value[1]]} · ${cities[p.value[0]]}<br/>达标率: <b>${p.value[2]}%</b>` },
        grid: { left: 100, right: 20, top: 60, bottom: 80 },
        xAxis: { type: 'category', data: cities, splitArea: { show: true }, axisLabel: { fontSize: 9, color: '#6B7280', rotate: 45 } },
        yAxis: { type: 'category', data: equipCategories, splitArea: { show: true }, axisLabel: { fontSize: 10, color: '#6B7280' } },
        visualMap: { min: 60, max: 100, calculable: true, orient: 'horizontal', left: 'center', bottom: 0, inRange: { color: ['#FEE2E2', '#FEF3C7', '#D1FAE5'] }, textStyle: { fontSize: 10 } },
        series: [{ type: 'heatmap', data: heatmapData, label: { show: true, fontSize: 8, color: '#374151' }, emphasis: { itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0,0,0,0.2)' } } }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(heatRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (radarRef.current) {
      const chart = echarts.init(radarRef.current)
      chart.setOption({
        title: { text: '配备均衡性雷达图', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '各装备品类达标率对比', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: {},
        legend: { data: ['全省平均', 'YYY市'], top: 0, right: 0, textStyle: { fontSize: 10 } },
        radar: { indicator: radarIndicators, radius: '60%', splitNumber: 4, axisName: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#E5E7EB' } }, splitArea: { areaStyle: { color: ['#fff', '#F9FAFB'] } } },
        series: [{ type: 'radar', data: radarData.map((d, i) => ({ ...d, lineStyle: { color: ['#1A56DB', '#10B981'][i], width: 2 }, itemStyle: { color: ['#1A56DB', '#10B981'][i] }, areaStyle: { color: ['rgba(26,86,219,0.15)', 'rgba(16,185,129,0.15)'][i] }, symbolSize: 4 })) }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(radarRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (trendRef.current) {
      const chart = echarts.init(trendRef.current)
      chart.setOption({
        title: { text: '配备趋势分析', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '月度达标率变化趋势(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        legend: { data: Object.keys(trendData), top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 45, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: months, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', min: 60, max: 100, axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: Object.entries(trendData).map(([name, data], i) => ({
          name, type: 'line' as const, data, smooth: true,
          lineStyle: { width: 2, color: ['#1A56DB', '#10B981', '#F59E0B'][i], type: i === 2 ? ('dashed' as const) : ('solid' as const) },
          itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B'][i] },
          symbol: 'circle', symbolSize: 4,
        })),
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(trendRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (barRef.current) {
      const chart = echarts.init(barRef.current)
      chart.setOption({
        title: { text: '优先级排序', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '按缺口数量降序', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        grid: { left: 120, right: 40, top: 60, bottom: 30 },
        xAxis: { type: 'value', name: '缺口数量', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'category', data: priorityData.map((d) => d.name).reverse(), axisLabel: { fontSize: 10, color: '#374151' } },
        series: [{
          type: 'bar', data: priorityData.map((d) => d.gap).reverse(), barWidth: '60%',
          itemStyle: {
            color: (params: any) => {
              const v = params.value
              return v >= 200 ? '#EF4444' : v >= 100 ? '#F59E0B' : '#10B981'
            }, borderRadius: [0, 4, 4, 0],
          },
          label: { show: true, position: 'right', fontSize: 10, formatter: '{c}件' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(barRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">装备配备研判分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">基于配备标准的装备达标率分析与缺口评估</p>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">单位层级</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全省</option><option>省辖市</option><option>区县</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">警种</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部</option><option>治安警察</option><option>交通警察</option><option>刑事警察</option><option>特警</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">装备类别</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs outline-none focus:border-[#1A56DB]">
              <option>全部品类</option><option>防护装备</option><option>执法装备</option><option>通信装备</option>
            </select>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {[
          { label: '整体达标率', value: '86.5%', sub: '↑ 2.3% 同比', up: true },
          { label: '均衡性指数', value: '0.78', sub: '↑ 0.05 环比', up: true },
          { label: '缺口数量', value: '2,860件', sub: '↓ 320件 较上月', up: true },
          { label: '优先配置项', value: '12项', sub: '需立即补充', up: false },
        ].map((s, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <span className="text-[13px] text-[#6B7280]">{s.label}</span>
            <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value}</div>
            <span className={cn('mt-1 flex items-center gap-1 text-xs', s.up ? 'text-[#10B981]' : 'text-[#EF4444]')}>
              {s.up ? <TrendingUp size={12} /> : <TrendingDown size={12} />}{s.sub}
            </span>
          </div>
        ))}
      </div>

      {/* Chart row 1 */}
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={heatRef} style={{ width: '100%', height: 420 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={radarRef} style={{ width: '100%', height: 420 }} />
        </div>
      </div>

      {/* Chart row 2 */}
      <div className="mb-4 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={trendRef} style={{ width: '100%', height: 340 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={barRef} style={{ width: '100%', height: 340 }} />
        </div>
      </div>

      {/* Table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-[#1F2937]">各地市配备达标情况</h3>
          <span className="text-xs text-[#6B7280]">共 {tableData.length} 条记录</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['地市', '整体达标率', '均衡性指数', '缺口数量', '达标状态', '操作'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((row, i) => (
                <tr key={i} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.city}</td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-20 overflow-hidden rounded-full bg-[#F3F4F6]">
                        <div className="h-full rounded-full transition-all" style={{ width: `${row.rate}%`, background: row.rate >= 85 ? '#10B981' : row.rate >= 75 ? '#F59E0B' : '#EF4444' }} />
                      </div>
                      <span className="text-[#374151]">{row.rate}%</span>
                    </div>
                  </td>
                  <td className="px-3 py-3 text-[#374151]">{row.index.toFixed(2)}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.gap}件</td>
                  <td className="px-3 py-3"><Badge variant={statusVariant(row.status)}>{row.status}</Badge></td>
                  <td className="px-3 py-3"><button className="text-xs text-[#1A56DB] hover:underline">查看详情</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
