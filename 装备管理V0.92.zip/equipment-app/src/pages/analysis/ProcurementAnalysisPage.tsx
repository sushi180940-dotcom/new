import { useEffect, useRef, useState } from 'react'
import { BarChart2, RefreshCw, FileText, Grid3X3, TrendingUp, TrendingDown } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const statCards = [
  { label: '总采购金额', value: '¥12,580万', change: 8.5, up: true, sparkType: 'area' as const, color: '#10B981' },
  { label: '采购项目数', value: '1,256项', change: 12.3, up: true, sparkType: 'bar' as const, color: '#1A56DB' },
  { label: '平均单价', value: '¥10.0万', change: 3.2, up: false, sparkType: 'line' as const, color: '#EF4444' },
  { label: '预测准确率', value: '94.2%', change: 2.1, up: true, sparkType: 'gauge' as const, color: '#10B981' },
]

const sparkData = [
  [820, 932, 901, 934, 1290, 1330, 1320, 1450, 1520, 1580],
  [45, 52, 48, 60, 55, 58, 62, 65, 70, 72],
  [12.5, 12.1, 11.8, 11.5, 11.2, 10.8, 10.5, 10.3, 10.1, 10.0],
  [88, 89, 90, 91, 92, 93, 93, 94, 94, 94.2],
]

const tableData = [
  { name: '防弹背心III级', category: '防护装备', history: 1250, forecast: 380, stock: 420, suggest: 180, price: '¥3,500', budget: '¥63万', priority: '高' as const },
  { name: '执法记录仪DSJ-A8', category: '执法装备', history: 860, forecast: 520, stock: 150, suggest: 400, price: '¥2,800', budget: '¥112万', priority: '高' as const },
  { name: '手铐(不锈钢)', category: '约束装备', history: 3200, forecast: 1800, stock: 950, suggest: 950, price: '¥180', budget: '¥17.1万', priority: '中' as const },
  { name: '防刺服FCF-J-SD', category: '防护装备', history: 780, forecast: 420, stock: 380, suggest: 200, price: '¥1,800', budget: '¥36万', priority: '中' as const },
  { name: '催泪喷射器(手持)', category: '警械装备', history: 2100, forecast: 1200, stock: 600, suggest: 700, price: '¥350', budget: '¥24.5万', priority: '中' as const },
  { name: '对讲机PD780G', category: '通信装备', history: 450, forecast: 280, stock: 120, suggest: 200, price: '¥4,500', budget: '¥90万', priority: '高' as const },
  { name: '强光手电T6', category: '警用器械', history: 1800, forecast: 900, stock: 720, suggest: 280, price: '¥260', budget: '¥7.3万', priority: '低' as const },
  { name: '急救包(标准型)', category: '医疗装备', history: 1500, forecast: 850, stock: 500, suggest: 450, price: '¥420', budget: '¥18.9万', priority: '低' as const },
  { name: '防弹头盔M88', category: '防护装备', history: 680, forecast: 360, stock: 200, suggest: 200, price: '¥2,200', budget: '¥44万', priority: '高' as const },
  { name: '警用腰带(多功能)', category: '服装装具', history: 2600, forecast: 1400, stock: 800, suggest: 720, price: '¥320', budget: '¥23万', priority: '低' as const },
]

const quarters: string[] = []
for (let y = 2021; y <= 2026; y++) {
  for (let q = 1; q <= 4; q++) {
    if (y === 2026 && q > 2) break
    quarters.push(`${y}Q${q}`)
  }
}

const predictData = [280, 310, 340, 380, 420, 450, 480, 520, 560, 590, 630, 680, 720, 760, 810, 860, 920, 980, 1050, 1120, 1200, 1280]
const forecastData = [...predictData]
for (let i = predictData.length - 4; i < predictData.length; i++) {
  forecastData[i] = predictData[i] + (Math.random() - 0.5) * 80
}
const priceTrendData = {
  '防护装备': [3.2, 3.3, 3.4, 3.5, 3.5, 3.6, 3.6, 3.7, 3.7, 3.8, 3.8, 3.8, 3.9, 3.9, 4.0, 4.0, 4.1, 4.1, 4.2, 4.2, 4.3, 4.3],
  '执法装备': [2.4, 2.5, 2.5, 2.6, 2.6, 2.7, 2.7, 2.8, 2.8, 2.9, 2.9, 3.0, 3.0, 3.1, 3.1, 3.2, 3.2, 3.3, 3.3, 3.4, 3.4, 3.5],
  '通信装备': [3.8, 3.9, 4.0, 4.1, 4.2, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0, 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8],
  '警用器械': [0.22, 0.23, 0.23, 0.24, 0.24, 0.25, 0.25, 0.25, 0.26, 0.26, 0.26, 0.27, 0.27, 0.27, 0.28, 0.28, 0.28, 0.29, 0.29, 0.29, 0.30, 0.30],
}

const supplierPieData = [
  { value: 3850, name: '华东安防科技' },
  { value: 2100, name: '北方装备集团' },
  { value: 1850, name: '中天警用器材' },
  { value: 1420, name: '南方防护设备' },
  { value: 680, name: '西部通信科技' },
  { value: 680, name: '其他供应商' },
]

const purchaseMethods = ['公开招标', '邀请招标', '竞争性谈判', '询价采购', '单一来源', '协议供货']
const methodAmounts = [4850, 2100, 3200, 1520, 480, 930]
const methodCounts = [28, 15, 42, 38, 12, 25]

/* ── sparkline component ── */
function SparkChart({ type, data, color }: { type: string; data: number[]; color: string }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current) return
    const chart = echarts.init(ref.current, undefined, { renderer: 'svg' })
    const option: echarts.EChartsOption = {
      grid: { left: 2, right: 2, top: 2, bottom: 2 },
      xAxis: { show: false, type: 'category', data: data.map((_, i) => i) },
      yAxis: { show: false, type: 'value' },
      series: [
        type === 'area'
          ? {
              type: 'line', data, smooth: true, symbol: 'none',
              lineStyle: { width: 1.5, color },
              areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: color + '40' }, { offset: 1, color: color + '00' }] } },
            }
          : type === 'bar'
            ? { type: 'bar', data, barWidth: '60%', itemStyle: { color, borderRadius: [2, 2, 0, 0] } }
            : type === 'gauge'
              ? {
                  type: 'gauge', startAngle: 200, endAngle: -20,
                  min: 80, max: 100, radius: '90%',
                  axisLine: { lineStyle: { width: 6, color: [[1, '#E5E7EB']] } },
                  pointer: { show: false }, axisTick: { show: false }, splitLine: { show: false }, axisLabel: { show: false }, detail: { show: false },
                  data: [{ value: data[data.length - 1] }],
                  title: { show: false },
                }
              : {
                  type: 'line', data, smooth: true, symbol: 'none',
                  lineStyle: { width: 1.5, color },
                },
      ],
      animation: false,
    }
    if (type === 'gauge') {
      ;(option.series as any[])[0].axisLine!.lineStyle!.color = [[data[data.length - 1] / 100, color], [1, '#E5E7EB']]
    }
    chart.setOption(option)
    const ro = new ResizeObserver(() => chart.resize())
    ro.observe(ref.current)
    return () => { ro.disconnect(); chart.dispose() }
  }, [type, data, color])
  return <div ref={ref} style={{ width: '100%', height: 48 }} />
}

/* ── main page ── */
export default function ProcurementAnalysisPage() {
  const [dimension, setDimension] = useState('全局')
  const [timeRange, setTimeRange] = useState('近3年')
  const [category, setCategory] = useState('全部品类')

  const predictRef = useRef<HTMLDivElement>(null)
  const priceRef = useRef<HTMLDivElement>(null)
  const pieRef = useRef<HTMLDivElement>(null)
  const barRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cleanups: (() => void)[] = []

    if (predictRef.current) {
      const chart = echarts.init(predictRef.current)
      const histLen = quarters.length - 4
      const opt: echarts.EChartsOption = {
        title: { text: '采购需求预测', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '基于近5年数据 + AI预测模型', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', formatter: (params: any) => { let s = params[0].axisValue + '<br/>'; params.forEach((p: any) => { s += p.marker + ' ' + p.seriesName + ': ' + p.value + '件<br/>' }); return s } },
        legend: { data: ['历史数据', '预测数据', '置信区间'], top: 0, right: 0 },
        grid: { left: 50, right: 20, top: 60, bottom: 40 },
        xAxis: { type: 'category', data: quarters, axisLabel: { fontSize: 10, color: '#6B7280', rotate: 45 } },
        yAxis: { type: 'value', name: '数量(件)', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        dataZoom: [{ type: 'inside', start: 0, end: 100 }, { type: 'slider', start: 0, end: 100, bottom: 0, height: 16 }],
        series: [
          { name: '历史数据', type: 'line', data: [...predictData.slice(0, histLen), ...Array(4).fill(null)], smooth: true, lineStyle: { width: 2, color: '#1A56DB' }, itemStyle: { color: '#1A56DB' }, symbol: 'circle', symbolSize: 4 },
          { name: '预测数据', type: 'line', data: [...Array(histLen - 1).fill(null), predictData[histLen - 1], ...forecastData.slice(histLen)], smooth: true, lineStyle: { width: 2, color: '#1A56DB', type: 'dashed' }, itemStyle: { color: '#1A56DB' }, symbol: 'diamond', symbolSize: 5 },
          { name: '置信区间', type: 'line', data: forecastData.map((v) => v + 50), smooth: true, lineStyle: { opacity: 0 }, areaStyle: { color: 'rgba(26,86,219,0.08)' }, stack: 'ci', symbol: 'none' },
          { name: 'ci_lower', type: 'line', data: forecastData.map((v) => v - 50), smooth: true, lineStyle: { opacity: 0 }, areaStyle: { color: '#fff' }, stack: 'ci', symbol: 'none' },
        ],
        animationDuration: 1000,
      }
      chart.setOption(opt)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(predictRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (priceRef.current) {
      const chart = echarts.init(priceRef.current)
      const opt: echarts.EChartsOption = {
        title: { text: '采购价格趋势', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '按装备品类(万元)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        legend: { data: Object.keys(priceTrendData), top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 45, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: quarters, axisLabel: { fontSize: 10, color: '#6B7280', rotate: 45 } },
        yAxis: { type: 'value', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: Object.entries(priceTrendData).map(([name, data], i) => ({
          name, type: 'line' as const, data, smooth: true,
          lineStyle: { width: 2, color: ['#1A56DB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'][i] },
          itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'][i] },
          symbol: 'circle', symbolSize: 3,
        })),
        animationDuration: 1000,
      }
      chart.setOption(opt)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(priceRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (pieRef.current) {
      const chart = echarts.init(pieRef.current)
      const opt: echarts.EChartsOption = {
        title: { text: '采购集中度分析', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '按供应商金额占比', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'item', formatter: '{b}: ¥{c}万 ({d}%)' },
        legend: { orient: 'vertical', right: 0, top: 'middle', textStyle: { fontSize: 10 }, itemWidth: 10, itemHeight: 10 },
        series: [{
          type: 'pie', radius: ['45%', '70%'], center: ['35%', '55%'],
          avoidLabelOverlap: true, itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
          label: { show: true, formatter: '{d}%', fontSize: 10 },
          emphasis: { label: { show: true, fontSize: 12, fontWeight: 'bold' }, itemStyle: { shadowBlur: 10, shadowOffsetX: 0, shadowColor: 'rgba(0,0,0,0.2)' } },
          data: supplierPieData.map((d, i) => ({
            ...d, itemStyle: { color: ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6', '#EF4444', '#6B7280'][i] },
          })),
        }],
        animationDuration: 1000,
      }
      chart.setOption(opt)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(pieRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (barRef.current) {
      const chart = echarts.init(barRef.current)
      const opt: echarts.EChartsOption = {
        title: { text: '采购方式对比', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '金额与数量对比', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
        legend: { data: ['金额(万元)', '数量(项)'], top: 0, right: 0, textStyle: { fontSize: 10 } },
        grid: { left: 50, right: 60, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: purchaseMethods, axisLabel: { fontSize: 10, color: '#6B7280', rotate: 20 } },
        yAxis: [
          { type: 'value', name: '金额(万)', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
          { type: 'value', name: '数量', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { show: false } },
        ],
        series: [
          { name: '金额(万元)', type: 'bar', data: methodAmounts, barWidth: '40%', itemStyle: { color: '#1A56DB', borderRadius: [4, 4, 0, 0] } },
          { name: '数量(项)', type: 'line', yAxisIndex: 1, data: methodCounts, lineStyle: { width: 2, color: '#10B981' }, itemStyle: { color: '#10B981' }, symbol: 'circle', symbolSize: 6 },
        ],
        animationDuration: 1000,
      }
      chart.setOption(opt)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(barRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  const priorityVariant = (p: string) => p === '高' ? 'danger' as const : p === '中' ? 'warning' as const : 'success' as const

  return (
    <div>
      {/* Dark Header */}
      <div className="-mx-6 -mt-6 mb-6 bg-[#1E293B] px-6 pb-10 pt-5">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <BarChart2 size={24} className="text-white" />
              <h1 className="text-2xl font-semibold text-white">装备采购研判分析</h1>
            </div>
            <p className="mt-1 text-[13px] text-[#94A3B8]">基于历史数据的装备采购趋势分析与需求预测</p>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 rounded-md border border-white/30 px-3 py-1.5 text-sm text-white transition hover:bg-white/10">
              <FileText size={14} /> 导出分析报告
            </button>
            <button className="flex h-8 w-8 items-center justify-center rounded-md border border-white/30 text-white transition hover:bg-white/10">
              <FileText size={14} />
            </button>
            <button className="flex h-8 w-8 items-center justify-center rounded-md border border-white/30 text-white transition hover:bg-white/10">
              <Grid3X3 size={14} />
            </button>
          </div>
        </div>

        {/* Filter bar */}
        <div className="mt-4 flex flex-wrap items-center gap-3 rounded-lg bg-white px-5 py-3 shadow-lg">
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">分析维度</span>
            <select value={dimension} onChange={(e) => setDimension(e.target.value)} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs text-[#374151] outline-none focus:border-[#1A56DB]">
              <option>全局</option><option>按装备类别</option><option>按单位</option><option>按供应商</option><option>按时间</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">装备类别</span>
            <select value={category} onChange={(e) => setCategory(e.target.value)} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs text-[#374151] outline-none focus:border-[#1A56DB]">
              <option>全部品类</option><option>防护装备</option><option>执法装备</option><option>通信装备</option><option>警用器械</option><option>约束装备</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">时间范围</span>
            <select value={timeRange} onChange={(e) => setTimeRange(e.target.value)} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs text-[#374151] outline-none focus:border-[#1A56DB]">
              <option>近1年</option><option>近3年</option><option>近5年</option><option>自定义</option>
            </select>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-[#6B7280]">单位层级</span>
            <select className="h-8 rounded-md border border-[#D1D5DB] bg-white px-2 text-xs text-[#374151] outline-none focus:border-[#1A56DB]">
              <option>全省</option><option>省辖市</option><option>区县</option>
            </select>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] transition hover:bg-[#F3F4F6]">
              <RefreshCw size={14} />
            </button>
            <button className="text-xs text-[#6B7280] transition hover:text-[#1A56DB]">重置</button>
          </div>
        </div>
      </div>

      {/* Stat cards */}
      <div className="mb-4 grid grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
            <div className="flex items-center justify-between">
              <span className="text-[13px] text-[#6B7280]">{card.label}</span>
              <span className={cn('flex items-center gap-0.5 text-xs font-medium', card.up ? 'text-[#10B981]' : 'text-[#EF4444]')}>
                {card.up ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
                {card.up ? '+' : '-'}{card.change}%
              </span>
            </div>
            <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{card.value}</div>
            <div className="mt-2"><SparkChart type={card.sparkType} data={sparkData[i]} color={card.color} /></div>
          </div>
        ))}
      </div>

      {/* Chart row 1 */}
      <div className="mb-4 grid grid-cols-5 gap-4">
        <div className="col-span-3 rounded-lg bg-white p-5 shadow-md">
          <div ref={predictRef} style={{ width: '100%', height: 320 }} />
        </div>
        <div className="col-span-2 rounded-lg bg-white p-5 shadow-md">
          <div ref={priceRef} style={{ width: '100%', height: 320 }} />
        </div>
      </div>

      {/* Chart row 2 */}
      <div className="mb-4 grid grid-cols-5 gap-4">
        <div className="col-span-2 rounded-lg bg-white p-5 shadow-md">
          <div ref={pieRef} style={{ width: '100%', height: 300 }} />
        </div>
        <div className="col-span-3 rounded-lg bg-white p-5 shadow-md">
          <div ref={barRef} style={{ width: '100%', height: 300 }} />
        </div>
      </div>

      {/* Data table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="text-base font-semibold text-[#1F2937]">采购数据明细</h3>
          <span className="text-xs text-[#6B7280]">共 {tableData.length} 条记录</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['装备名称', '装备类别', '历史采购量', '预测需求量', '当前库存', '建议采购量', '参考单价', '预算估算', '优先级', '操作'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {tableData.map((row, i) => (
                <tr key={i} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.name}</td>
                  <td className="px-3 py-3 text-[#374151]">{row.category}</td>
                  <td className="px-3 py-3 text-right text-[#374151]">{row.history.toLocaleString()}</td>
                  <td className="px-3 py-3 text-right font-medium text-[#1A56DB]">{row.forecast.toLocaleString()}</td>
                  <td className={cn('px-3 py-3 text-right', row.stock < 200 ? 'text-[#EF4444]' : 'text-[#10B981]')}>{row.stock.toLocaleString()}</td>
                  <td className="px-3 py-3 text-right font-bold text-[#1A56DB]">{row.suggest.toLocaleString()}</td>
                  <td className="px-3 py-3 text-right text-[#374151]">{row.price}</td>
                  <td className="px-3 py-3 text-right text-[#374151]">{row.budget}</td>
                  <td className="px-3 py-3"><Badge variant={priorityVariant(row.priority)}>{row.priority}</Badge></td>
                  <td className="px-3 py-3">
                    <div className="flex gap-1">
                      <button className="text-xs text-[#1A56DB] hover:underline">查看趋势</button>
                      <button className="text-xs text-[#1A56DB] hover:underline">加入采购单</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
