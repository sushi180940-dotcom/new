import { useState } from 'react'
import { FileText, Play, Star, Eye, Download, Upload, FolderPlus, Search, Shield, Camera, Link as LinkIcon, Sun, SprayCan, HeartPulse, Radio, FileText as FileIcon2 } from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
type MaterialType = '全部' | '操作手册' | '视频教程' | '课件' | '其他'

interface Material {
  id: number
  title: string
  type: MaterialType
  fileType: string
  size: string
  views: number
  downloads: number
  rating: number
  duration?: string
  color: string
  icon: 'pdf' | 'word' | 'ppt' | 'video' | 'image'
  equipments: string[]
}

/* ── mock data ── */
const materials: Material[] = [
  { id: 1, title: '操作手册-防弹背心', type: '操作手册', fileType: 'PDF', size: '2.5MB', views: 1234, downloads: 567, rating: 4.8, color: '#EF4444', icon: 'pdf', equipments: ['防弹背心 FDY-2R-01', '防弹盾牌 FDP-3S'] },
  { id: 2, title: '执法记录仪操作教程', type: '视频教程', fileType: 'MP4', size: '156MB', views: 3456, downloads: 234, rating: 4.9, duration: '05:32', color: '#8B5CF6', icon: 'video', equipments: ['执法记录仪 DSJ-A7'] },
  { id: 3, title: '新警装备培训课程', type: '课件', fileType: 'PPT', size: '12MB', views: 890, downloads: 123, rating: 4.5, color: '#F59E0B', icon: 'ppt', equipments: ['防弹背心', '执法记录仪', '手铐', '对讲机', '强光手电'] },
  { id: 4, title: '急救包使用指南', type: '操作手册', fileType: 'PDF', size: '1.8MB', views: 2100, downloads: 890, rating: 4.7, color: '#EF4444', icon: 'pdf', equipments: ['急救包 JJ-01'] },
  { id: 5, title: '手铐规范操作视频', type: '视频教程', fileType: 'MP4', size: '89MB', views: 4567, downloads: 345, rating: 4.6, duration: '08:15', color: '#8B5CF6', icon: 'video', equipments: ['手铐 SK-01', '伸缩警棍 SG-01'] },
  { id: 6, title: '防刺服保养与维护', type: '操作手册', fileType: 'PDF', size: '3.2MB', views: 780, downloads: 234, rating: 4.3, color: '#EF4444', icon: 'pdf', equipments: ['防刺服 FCF-J-AH01'] },
  { id: 7, title: '装备管理制度解读', type: '课件', fileType: 'PPT', size: '8MB', views: 1567, downloads: 178, rating: 4.4, color: '#F59E0B', icon: 'ppt', equipments: ['全部装备'] },
  { id: 8, title: '催泪喷射器使用规范', type: '视频教程', fileType: 'MP4', size: '67MB', views: 5678, downloads: 456, rating: 4.8, duration: '06:48', color: '#8B5CF6', icon: 'video', equipments: ['催泪喷射器 CL-200'] },
  { id: 9, title: '对讲机操作与维护手册', type: '操作手册', fileType: 'PDF', size: '4.5MB', views: 980, downloads: 312, rating: 4.2, color: '#EF4444', icon: 'pdf', equipments: ['对讲机 PD780G'] },
  { id: 10, title: '防弹头盔佩戴教程', type: '视频教程', fileType: 'MP4', size: '45MB', views: 2345, downloads: 189, rating: 4.5, duration: '04:22', color: '#8B5CF6', icon: 'video', equipments: ['战术头盔 MICH-2000'] },
  { id: 11, title: '警用装备采购规范', type: '课件', fileType: 'PPT', size: '15MB', views: 670, downloads: 98, rating: 4.1, color: '#F59E0B', icon: 'ppt', equipments: ['全部装备'] },
  { id: 12, title: '强光手电使用说明', type: '操作手册', fileType: 'PDF', size: '1.2MB', views: 1890, downloads: 678, rating: 4.6, color: '#3B82F6', icon: 'word', equipments: ['强光手电 QG-500'] },
]

const typeCounts: Record<string, number> = {
  '全部': materials.length,
  '操作手册': materials.filter((m) => m.type === '操作手册').length,
  '视频教程': materials.filter((m) => m.type === '视频教程').length,
  '课件': materials.filter((m) => m.type === '课件').length,
  '其他': materials.filter((m) => m.type === '其他').length,
}

const typeColors: Record<string, string> = {
  '操作手册': '#1A56DB',
  '视频教程': '#8B5CF6',
  '课件': '#F59E0B',
  '其他': '#6B7280',
}

/* ── equipment icon map ── */
const equipIconMap: Record<string, React.ReactNode> = {
  '防弹背心': <Shield size={12} />,
  '执法记录仪': <Camera size={12} />,
  '手铐': <LinkIcon size={12} />,
  '对讲机': <Radio size={12} />,
  '强光手电': <Sun size={12} />,
  '催泪喷射器': <SprayCan size={12} />,
  '急救包': <HeartPulse size={12} />,
}

function getEquipIcon(equipName: string) {
  for (const key of Object.keys(equipIconMap)) {
    if (equipName.includes(key)) return equipIconMap[key]
  }
  return <FileIcon2 size={12} />
}

function FileIcon({ icon, color }: { icon: string; color: string }) {
  if (icon === 'video') return <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: color + '15' }}><Play size={18} style={{ color }} /></div>
  if (icon === 'ppt') return <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={18} style={{ color }} /></div>
  if (icon === 'pdf') return <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={18} style={{ color }} /></div>
  return <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: color + '15' }}><FileText size={18} style={{ color }} /></div>
}

/* ── equipment tags ── */
function EquipmentTags({ equipments }: { equipments: string[] }) {
  return (
    <div className="flex flex-wrap gap-1">
      {equipments.map((eq, idx) => (
        <span
          key={idx}
          className="inline-flex items-center gap-1 rounded-md bg-[#F3F4F6] px-2 py-0.5 text-xs text-[#374151]"
          title={eq}
        >
          <span className="text-[#6B7280]">{getEquipIcon(eq)}</span>
          <span className="max-w-[120px] truncate">{eq}</span>
        </span>
      ))}
    </div>
  )
}

export default function MaterialsPage() {
  const [activeType, setActiveType] = useState<MaterialType>('全部')
  const [searchText, setSearchText] = useState('')

  const filtered = materials.filter((m) => {
    const matchType = activeType === '全部' || m.type === activeType
    const matchSearch = !searchText ||
      m.title.includes(searchText) ||
      m.equipments.some(e => e.includes(searchText))
    return matchType && matchSearch
  })

  const types: MaterialType[] = ['全部', '操作手册', '视频教程', '课件', '其他']

  return (
    <div>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">培训资料库</h1>
          <p className="mt-1 text-sm text-[#6B7280]">培训资料管理、预览与下载</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 rounded-md bg-[#1A56DB] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#153E7E]">
            <Upload size={16} /> 上传资料
          </button>
          <button className="flex items-center gap-2 rounded-md border border-[#D1D5DB] bg-white px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <FolderPlus size={16} /> 新建文件夹
          </button>
        </div>
      </div>

      {/* Category Filter + Search */}
      <div className="mb-6 flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          {types.map((t) => (
            <button
              key={t}
              onClick={() => setActiveType(t)}
              className={cn(
                'flex items-center gap-1.5 rounded-full px-4 py-1.5 text-sm font-medium transition',
                activeType === t
                  ? 'bg-[#1A56DB] text-white'
                  : 'border border-[#D1D5DB] bg-white text-[#374151] hover:bg-[#F3F4F6]'
              )}
            >
              {t}
              <span className={cn('rounded-full px-1.5 py-0 text-[10px]', activeType === t ? 'bg-white/20 text-white' : 'bg-[#F3F4F6] text-[#6B7280]')}>{typeCounts[t]}</span>
            </button>
          ))}
        </div>
        <div className="relative w-64">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索资料名称或适用装备..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* List Table */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">资料名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">类型</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">格式</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">大小</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">适用装备</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">浏览</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">下载</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">评分</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    <FileText size={48} className="mx-auto mb-3 opacity-30" />
                    未找到匹配的培训资料
                  </td>
                </tr>
              )}
              {filtered.map((m) => (
                <tr key={m.id} className="cursor-pointer border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  {/* 资料名称 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <FileIcon icon={m.icon} color={m.color} />
                      <div>
                        <div className="font-medium text-[#1F2937]">{m.title}</div>
                        {m.duration && <div className="text-xs text-[#9CA3AF]">时长：{m.duration}</div>}
                      </div>
                    </div>
                  </td>
                  {/* 类型 */}
                  <td className="px-4 py-3">
                    <span
                      className="rounded-full px-2.5 py-0.5 text-xs"
                      style={{ background: (typeColors[m.type] || '#6B7280') + '15', color: typeColors[m.type] || '#6B7280' }}
                    >
                      {m.type}
                    </span>
                  </td>
                  {/* 格式 */}
                  <td className="px-4 py-3 text-[#374151]">{m.fileType}</td>
                  {/* 大小 */}
                  <td className="px-4 py-3 text-[#374151]">{m.size}</td>
                  {/* 适用装备 */}
                  <td className="px-4 py-3">
                    <EquipmentTags equipments={m.equipments} />
                  </td>
                  {/* 浏览 */}
                  <td className="px-4 py-3 text-right text-[#374151]">
                    <span className="flex items-center justify-end gap-1">
                      <Eye size={13} className="text-[#9CA3AF]" />
                      {m.views.toLocaleString()}
                    </span>
                  </td>
                  {/* 下载 */}
                  <td className="px-4 py-3 text-right text-[#374151]">
                    <span className="flex items-center justify-end gap-1">
                      <Download size={13} className="text-[#9CA3AF]" />
                      {m.downloads.toLocaleString()}
                    </span>
                  </td>
                  {/* 评分 */}
                  <td className="px-4 py-3">
                    <span className="flex items-center gap-1">
                      <Star size={13} className="fill-[#F59E0B] text-[#F59E0B]" />
                      <span className="text-[#374151]">{m.rating}</span>
                    </span>
                  </td>
                  {/* 操作 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1.5">
                      <button className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2.5 text-xs text-white transition hover:bg-[#153E7E]">
                        <Eye size={12} /> 预览
                      </button>
                      <button className="flex h-7 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-2.5 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
                        <Download size={12} /> 下载
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filtered.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>
    </div>
  )
}
