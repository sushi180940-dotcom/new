import { useEffect, useRef, useState } from 'react'
import { Calendar, Clock, Users, BookOpen, GraduationCap, BarChart3 } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const plans = [
  { id: 1, title: '新警装备使用基础培训', start: '2026-03-01', end: '2026-03-05', location: '省厅培训基地', target: '新入职民警', status: '已完成' as const, count: 45 },
  { id: 2, title: '执法记录仪操作进阶培训', start: '2026-03-10', end: '2026-03-12', location: '市局培训教室A', target: '一线执法民警', status: '已完成' as const, count: 68 },
  { id: 3, title: '防弹背心维护保养专项培训', start: '2026-03-15', end: '2026-03-16', location: '装备管理处', target: '装备管理员', status: '进行中' as const, count: 25 },
  { id: 4, title: '催泪喷射器安全使用培训', start: '2026-03-20', end: '2026-03-22', location: '特警训练基地', target: '特警队员', status: '进行中' as const, count: 35 },
  { id: 5, title: '急救包应急处置培训', start: '2026-04-05', end: '2026-04-07', location: '省厅培训基地', target: '全体民警', status: '计划中' as const, count: 120 },
  { id: 6, title: '对讲机系统操作培训', start: '2026-04-10', end: '2026-04-11', location: '通信技术中心', target: '通信保障人员', status: '计划中' as const, count: 18 },
  { id: 7, title: '手铐规范操作复训', start: '2026-04-15', end: '2026-04-16', location: '各分局训练场', target: '全体民警', status: '计划中' as const, count: 200 },
  { id: 8, title: '防刺服穿脱与保养培训', start: '2026-04-20', end: '2026-04-21', location: '装备管理处', target: '一线民警', status: '计划中' as const, count: 85 },
]

const scores = [
  { name: '张伟', department: '刑侦总队', theory: 92, practical: 88, grade: 'A' as const },
  { name: '李明', department: '治安支队', theory: 85, practical: 90, grade: 'A' as const },
  { name: '王芳', department: '交警支队', theory: 78, practical: 82, grade: 'B' as const },
  { name: '赵强', department: '特警支队', theory: 96, practical: 94, grade: 'A' as const },
  { name: '刘洋', department: '派出所', theory: 72, practical: 76, grade: 'B' as const },
  { name: '陈静', department: '网安支队', theory: 88, practical: 85, grade: 'A' as const },
  { name: '杨勇', department: '经侦支队', theory: 65, practical: 70, grade: 'C' as const },
  { name: '黄丽', department: '禁毒支队', theory: 91, practical: 89, grade: 'A' as const },
  { name: '周军', department: '反恐支队', theory: 83, practical: 86, grade: 'B' as const },
  { name: '吴敏', department: '法制支队', theory: 76, practical: 72, grade: 'B' as const },
]

const calendarDays = Array.from({ length: 31 }, (_, i) => i + 1)
const planDates = [1, 2, 3, 4, 5, 10, 11, 12, 15, 16, 20, 21, 22]
const statusStyles: Record<string, { variant: 'success' | 'warning' | 'info' | 'danger'; label: string; dot: string }> = {
  '已完成': { variant: 'success', label: '已完成', dot: 'bg-[#10B981]' },
  '进行中': { variant: 'info', label: '进行中', dot: 'bg-[#3B82F6]' },
  '计划中': { variant: 'warning', label: '计划中', dot: 'bg-[#F59E0B]' },
  '已取消': { variant: 'danger', label: '已取消', dot: 'bg-[#6B7280]' },
}

const gradeColor = (g: string) => g === 'A' ? 'success' as const : g === 'B' ? 'warning' as const : g === 'C' ? 'info' as const : 'danger' as const

export default function TrainingProcessPage() {
  const [activeTab, setActiveTab] = useState<'plan' | 'implement' | 'assess' | 'report'>('plan')
  const coverageRef = useRef<HTMLDivElement>(null)
  const passRef = useRef<HTMLDivElement>(null)
  const hoursRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (activeTab !== 'report') return
    const cleanups: (() => void)[] = []

    if (coverageRef.current) {
      const chart = echarts.init(coverageRef.current)
      chart.setOption({
        title: { text: '培训覆盖率', left: 'center', top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' } },
        tooltip: { trigger: 'item', formatter: '{b}: {c}人 ({d}%)' },
        legend: { orient: 'vertical', left: 0, bottom: 0, textStyle: { fontSize: 10 } },
        series: [{ type: 'pie', radius: ['45%', '70%'], center: ['60%', '55%'], avoidLabelOverlap: false, label: { show: true, formatter: '{d}%', fontSize: 11 }, emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold' } }, data: [{ value: 856, name: '已培训', itemStyle: { color: '#10B981' } }, { value: 344, name: '未培训', itemStyle: { color: '#E5E7EB' } }] }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(coverageRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (passRef.current) {
      const chart = echarts.init(passRef.current)
      chart.setOption({
        title: { text: '考核通过率', left: 'center', top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' } },
        tooltip: { trigger: 'item', formatter: '{b}: {c}人 ({d}%)' },
        legend: { orient: 'vertical', left: 0, bottom: 0, textStyle: { fontSize: 10 } },
        series: [{ type: 'pie', radius: ['45%', '70%'], center: ['60%', '55%'], avoidLabelOverlap: false, label: { show: true, formatter: '{d}%', fontSize: 11 }, emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold' } }, data: [{ value: 642, name: '通过', itemStyle: { color: '#1A56DB' } }, { value: 128, name: '未通过', itemStyle: { color: '#EF4444' } }, { value: 86, name: '补考', itemStyle: { color: '#F59E0B' } }] }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(passRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (hoursRef.current) {
      const chart = echarts.init(hoursRef.current)
      chart.setOption({
        title: { text: '人均培训时长', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '按季度(小时)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis' },
        grid: { left: 45, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: ['Q1', 'Q2', 'Q3', 'Q4'], axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', name: '小时', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{ type: 'bar', data: [16.5, 18.2, 14.8, 12.5], barWidth: '40%', itemStyle: { color: '#1A56DB', borderRadius: [4, 4, 0, 0] }, label: { show: true, position: 'top', fontSize: 11 } }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(hoursRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [activeTab])

  const tabs = [
    { key: 'plan' as const, label: '培训计划', icon: Calendar },
    { key: 'implement' as const, label: '培训实施', icon: Users },
    { key: 'assess' as const, label: '考核评估', icon: GraduationCap },
    { key: 'report' as const, label: '统计报表', icon: BarChart3 },
  ]

  return (
    <div>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">培训过程管理</h1>
          <p className="mt-1 text-sm text-[#6B7280]">培训计划、实施、考核与统计报表</p>
        </div>
        <button className="flex items-center gap-2 rounded-md bg-[#1A56DB] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#153E7E]">
          <BookOpen size={16} /> 新增培训计划
        </button>
      </div>

      {/* Tabs */}
      <div className="mb-6 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={cn(
                'flex items-center gap-2 border-b-2 pb-3 text-sm font-medium transition',
                activeTab === t.key
                  ? 'border-[#1A56DB] text-[#1A56DB]'
                  : 'border-transparent text-[#6B7280] hover:text-[#374151]'
              )}
            >
              <t.icon size={16} /> {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === 'plan' && (
        <div>
          {/* Calendar View */}
          <div className="mb-6 rounded-lg bg-white p-5 shadow-md">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1F2937]">2026年3月培训日历</h3>
              <div className="flex items-center gap-3 text-xs">
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-[#10B981]" />已完成</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-[#3B82F6]" />进行中</span>
                <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-[#F59E0B]" />计划中</span>
              </div>
            </div>
            <div className="grid grid-cols-7 gap-1">
              {['日', '一', '二', '三', '四', '五', '六'].map((d) => (
                <div key={d} className="py-2 text-center text-xs font-semibold text-[#6B7280]">{d}</div>
              ))}
              {/* Empty cells for March 2026 starts on Sunday */}
              {calendarDays.map((day) => {
                const hasPlan = planDates.includes(day)
                const plan = plans.find((p) => new Date(p.start).getDate() === day)
                const status = plan ? statusStyles[plan.status] : null
                return (
                  <div
                    key={day}
                    className={cn(
                      'relative min-h-[80px] rounded-md border p-1 transition hover:shadow-sm',
                      hasPlan ? 'border-[#D1D5DB] bg-[#FAFBFC]' : 'border-transparent hover:bg-[#F9FAFB]'
                    )}
                  >
                    <span className="absolute left-1 top-1 text-xs font-medium text-[#374151]">{day}</span>
                    {plan && status && (
                      <div className="mt-4 rounded px-1 py-0.5 text-[10px]" style={{ background: status.dot + '15' }}>
                        <span className="flex items-center gap-1 truncate">
                          <span className={cn('h-1.5 w-1.5 rounded-full', status.dot)} />
                          <span className="truncate text-[#374151]">{plan.title.slice(0, 6)}...</span>
                        </span>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
          </div>

          {/* Plan Cards */}
          <div className="grid grid-cols-2 gap-4">
            {plans.map((p) => {
              const st = statusStyles[p.status]
              return (
                <div key={p.id} className="rounded-lg border border-[#E5E7EB] bg-white p-4 transition hover:shadow-md">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-semibold text-[#1F2937]">{p.title}</h4>
                      <div className="mt-1 flex items-center gap-3 text-xs text-[#6B7280]">
                        <span className="flex items-center gap-1"><Clock size={12} /> {p.start} 至 {p.end}</span>
                        <span className="flex items-center gap-1"><Users size={12} /> {p.count}人</span>
                      </div>
                    </div>
                    <Badge variant={st.variant}>{st.label}</Badge>
                  </div>
                  <div className="mt-2 text-xs text-[#6B7280]">
                    <span>地点: {p.location}</span>
                    <span className="ml-3">对象: {p.target}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {activeTab === 'implement' && (
        <div className="rounded-lg bg-white p-6 shadow-md">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#1F2937]">培训实施 - 出勤记录</h3>
            <span className="text-xs text-[#6B7280]">当前培训: 防弹背心维护保养专项培训</span>
          </div>
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['序号', '姓名', '部门', '出勤状态', '签到时间', '备注'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { name: '张伟', dept: '刑侦总队', status: '出勤', time: '08:55', note: '-' },
                { name: '李明', dept: '治安支队', status: '出勤', time: '08:58', note: '-' },
                { name: '王芳', dept: '交警支队', status: '迟到', time: '09:15', note: '交通堵塞' },
                { name: '赵强', dept: '特警支队', status: '出勤', time: '08:50', note: '-' },
                { name: '刘洋', dept: '派出所', status: '请假', time: '-', note: '因公外出' },
                { name: '陈静', dept: '网安支队', status: '出勤', time: '08:52', note: '-' },
                { name: '杨勇', dept: '经侦支队', status: '出勤', time: '09:02', note: '-' },
                { name: '黄丽', dept: '禁毒支队', status: '出勤', time: '08:48', note: '-' },
              ].map((row, i) => (
                <tr key={i} className={cn('border-b border-[#F3F4F6] hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-3 py-2.5 text-[#374151]">{i + 1}</td>
                  <td className="px-3 py-2.5 font-medium text-[#1F2937]">{row.name}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{row.dept}</td>
                  <td className="px-3 py-2.5">
                    <span className={cn('rounded-full px-2 py-0.5 text-[10px] font-medium', row.status === '出勤' ? 'bg-[#D1FAE5] text-[#059669]' : row.status === '迟到' ? 'bg-[#FEF3C7] text-[#D97706]' : 'bg-[#F3F4F6] text-[#6B7280]')}>{row.status}</span>
                  </td>
                  <td className="px-3 py-2.5 text-[#374151]">{row.time}</td>
                  <td className="px-3 py-2.5 text-[#6B7280]">{row.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'assess' && (
        <div>
          {/* Sub-tabs */}
          <div className="mb-4 flex items-center gap-2">
            <button className="rounded-full bg-[#1A56DB] px-4 py-1 text-xs font-medium text-white">理论考试</button>
            <button className="rounded-full border border-[#D1D5DB] bg-white px-4 py-1 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">实操考核</button>
          </div>

          <div className="rounded-lg bg-white p-6 shadow-md">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1F2937]">考核成绩列表</h3>
              <span className="text-xs text-[#6B7280]">共 {scores.length} 人</span>
            </div>
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  {['排名', '姓名', '部门', '理论成绩', '实操成绩', '综合等级', '操作'].map((h) => (
                    <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {scores.map((s, i) => (
                  <tr key={i} className={cn('border-b border-[#F3F4F6] hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                    <td className="px-3 py-3"><span className={cn('inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-bold', i < 3 ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#374151]')}>{i + 1}</span></td>
                    <td className="px-3 py-3 font-medium text-[#1F2937]">{s.name}</td>
                    <td className="px-3 py-3 text-[#374151]">{s.department}</td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#F3F4F6]">
                          <div className="h-full rounded-full bg-[#1A56DB]" style={{ width: `${s.theory}%` }} />
                        </div>
                        <span className="text-[#374151]">{s.theory}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3">
                      <div className="flex items-center gap-2">
                        <div className="h-1.5 w-16 overflow-hidden rounded-full bg-[#F3F4F6]">
                          <div className="h-full rounded-full bg-[#10B981]" style={{ width: `${s.practical}%` }} />
                        </div>
                        <span className="text-[#374151]">{s.practical}</span>
                      </div>
                    </td>
                    <td className="px-3 py-3"><Badge variant={gradeColor(s.grade)}>{s.grade}级</Badge></td>
                    <td className="px-3 py-3"><button className="text-xs text-[#1A56DB] hover:underline">查看详情</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'report' && (
        <div>
          {/* Stats cards */}
          <div className="mb-4 grid grid-cols-4 gap-4">
            {[
              { label: '培训覆盖率', value: '71.3%', sub: '856/1200人' },
              { label: '考核通过率', value: '75.0%', sub: '642/856人' },
              { label: '人均培训时长', value: '16.5h', sub: 'Q1季度' },
              { label: '培训满意度', value: '4.6/5.0', sub: '↑ 0.2' },
            ].map((s, i) => (
              <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
                <span className="text-[13px] text-[#6B7280]">{s.label}</span>
                <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value}</div>
                <span className="mt-1 text-xs text-[#6B7280]">{s.sub}</span>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-lg bg-white p-5 shadow-md">
              <div ref={coverageRef} style={{ width: '100%', height: 260 }} />
            </div>
            <div className="rounded-lg bg-white p-5 shadow-md">
              <div ref={passRef} style={{ width: '100%', height: 260 }} />
            </div>
            <div className="rounded-lg bg-white p-5 shadow-md">
              <div ref={hoursRef} style={{ width: '100%', height: 260 }} />
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
