import { useState } from 'react'
import {
  ArrowLeftRight,
  Search,
  Package,
  Plus,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ── types ── */
interface HandoverRecord {
  id: string
  type: string
  typeTag: 'primary' | 'success' | 'warning' | 'info' | 'danger'
  fromUser: string
  fromUnit: string
  toUser: string
  toUnit: string
  equipmentCount: number
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'danger' | 'default'
  time: string
}

/* ── mock data ── */
const pendingRecords: HandoverRecord[] = [
  {
    id: 'JJ2026001',
    type: '岗位调整',
    typeTag: 'primary',
    fromUser: '张明',
    fromUnit: '刑侦支队',
    toUser: '李强',
    toUnit: '治安大队',
    equipmentCount: 8,
    status: '待对方确认',
    statusColor: 'warning',
    time: '2026-05-28 10:30',
  },
  {
    id: 'JJ2026002',
    type: '退休交接',
    typeTag: 'success',
    fromUser: '王建国',
    fromUnit: '指挥中心',
    toUser: '刘洋',
    toUnit: '指挥中心',
    equipmentCount: 12,
    status: '待监交人确认',
    statusColor: 'info',
    time: '2026-05-25 09:00',
  },
]

const completedRecords: HandoverRecord[] = [
  {
    id: 'JJ2025108',
    type: '调离交接',
    typeTag: 'warning',
    fromUser: '陈浩',
    fromUnit: '交警支队',
    toUser: '赵磊',
    toUnit: '派出所',
    equipmentCount: 6,
    status: '已完成',
    statusColor: 'success',
    time: '2025-12-15 14:30',
  },
  {
    id: 'JJ2025095',
    type: '晋升换装',
    typeTag: 'info',
    fromUser: '孙丽',
    fromUnit: '特警支队',
    toUser: '周敏',
    toUnit: '特警支队',
    equipmentCount: 10,
    status: '已完成',
    statusColor: 'success',
    time: '2025-10-20 11:00',
  },
  {
    id: 'JJ2025082',
    type: '岗位调整',
    typeTag: 'primary',
    fromUser: '吴刚',
    fromUnit: '经侦支队',
    toUser: '郑华',
    toUnit: '网安支队',
    equipmentCount: 7,
    status: '已完成',
    statusColor: 'success',
    time: '2025-08-05 16:00',
  },
  {
    id: 'JJ2025071',
    type: '退休交接',
    typeTag: 'success',
    fromUser: '马秀英',
    fromUnit: '户政科',
    toUser: '黄婷',
    toUnit: '户政科',
    equipmentCount: 5,
    status: '已完成',
    statusColor: 'success',
    time: '2025-06-18 09:30',
  },
]

/* ── main component ── */
export default function HandoverPage() {
  const [activeTab, setActiveTab] = useState<'pending' | 'completed'>('pending')
  const [searchText, setSearchText] = useState('')

  const records = activeTab === 'pending' ? pendingRecords : completedRecords
  const filteredRecords = records.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.fromUser.includes(searchText) ||
      r.toUser.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">交接记录</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={16} />
          发起交接
        </button>
      </div>

      {/* ── Tabs ── */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('pending')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'pending' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            待交接 ({pendingRecords.length})
            {activeTab === 'pending' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'completed' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            已完成 ({completedRecords.length})
            {activeTab === 'completed' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
        </div>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、人员姓名..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Handover Table ── */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">交接单号</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">交接类型</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">交出方</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">接收方</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备数量</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">交接时间</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.map((record) => (
              <tr
                key={record.id}
                className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]"
              >
                <td className="px-4 py-3 font-mono text-[13px] font-medium text-[#1A56DB]">
                  {record.id}
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.typeTag}>{record.type}</Badge>
                </td>
                <td className="px-4 py-3">
                  <div className="text-[13px] font-medium text-[#1F2937]">{record.fromUser}</div>
                  <div className="text-xs text-[#6B7280]">{record.fromUnit}</div>
                </td>
                <td className="px-4 py-3">
                  <div className="text-[13px] font-medium text-[#1F2937]">{record.toUser}</div>
                  <div className="text-xs text-[#6B7280]">{record.toUnit}</div>
                </td>
                <td className="px-4 py-3">
                  <span className="inline-flex items-center gap-1 text-[13px] text-[#374151]">
                    <Package size={13} className="text-[#6B7280]" />
                    {record.equipmentCount} 件
                  </span>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-[13px] text-[#6B7280]">
                  {record.time}
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.statusColor}>{record.status}</Badge>
                </td>
                <td className="px-4 py-3 text-center">
                  <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#1A56DB] px-2.5 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                    <ArrowLeftRight size={12} /> 详情
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <ArrowLeftRight size={48} className="mx-auto mb-3 opacity-30" />
            暂无交接记录
          </div>
        )}
      </div>
    </div>
  )
}
