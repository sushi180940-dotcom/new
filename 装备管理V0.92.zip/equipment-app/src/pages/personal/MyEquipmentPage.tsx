import { useState } from 'react'
import {
  Package, CheckCircle, Clock, Wrench, Trash2, AlertTriangle,
  Hand, MessageSquare, FileText, Search, Download, Shield,
  Radio, Link, Sun, SprayCan, HeartPulse, Camera,
  X, ChevronDown, ChevronUp, Eye, BookOpen, Image, Video,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
interface Equipment {
  id: number
  name: string
  model: string
  code: string
  rfid: string
  category: string
  status: '正常' | '待保养' | '报修中' | '待报废'
  nextMaintain: string | null
  source: string
  purchaseDate: string
  warrantyExpiry: string
  dept: string
  userName: string
  location: string
  lastCheckDate: string
  hasManual: boolean
  hasImage: boolean
  hasMedia: boolean
  icon: React.ReactNode
  iconBg: string
  iconColor: string
}

/* ── status badge ── */
function StatusBadge({ status }: { status: string }) {
  const configs: Record<string, { bg: string; text: string }> = {
    '正常': { bg: 'bg-[#D1FAE5]', text: 'text-[#059669]' },
    '待保养': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
    '报修中': { bg: 'bg-[#DBEAFE]', text: 'text-[#2563EB]' },
    '待报废': { bg: 'bg-[#FEE2E2]', text: 'text-[#DC2626]' },
  }
  const c = configs[status] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span className={cn('inline-block rounded-full px-2.5 py-0.5 text-xs font-medium', c.bg, c.text)}>
      {status}
    </span>
  )
}

/* ── source badge ── */
function SourceBadge({ source }: { source: string }) {
  const colors: Record<string, string> = {
    '采购': 'bg-[#E8F0FE] text-[#1A56DB]',
    '配发': 'bg-[#D1FAE5] text-[#059669]',
    '调拨': 'bg-[#EDE9FE] text-[#7C3AED]',
    '借用': 'bg-[#FEF3C7] text-[#D97706]',
    '捐赠': 'bg-[#FEF3C7] text-[#D97706]',
  }
  return <span className={cn('rounded-full px-2 py-0.5 text-xs', colors[source] || 'bg-[#E5E7EB] text-[#6B7280]')}>{source}</span>
}

/* ── maintenance warning ── */
function MaintainWarning({ dateStr }: { dateStr: string | null }) {
  if (!dateStr) return <span className="text-xs text-[#9CA3AF]">无保养要求</span>
  const daysLeft = Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000)
  if (daysLeft < 0) return <span className="text-xs font-medium text-[#DC2626]"><AlertTriangle size={11} className="inline" /> 已过期</span>
  if (daysLeft < 30) return <span className="text-xs font-medium text-[#D97706]"><Clock size={11} className="inline" /> 剩{daysLeft}天</span>
  return <span className="text-xs text-[#6B7280]">{dateStr}</span>
}

/* ── mock data ── */
const equipmentList: Equipment[] = [
  { id: 1, name: '防弹背心', model: 'FDY-2R-01', code: 'EQ2024001', rfid: 'RFID001001', category: '防护装备', status: '正常', nextMaintain: '2026-08', source: '采购', purchaseDate: '2024-01-15', warrantyExpiry: '2029-01-15', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-03', lastCheckDate: '2026-05-20', hasManual: true, hasImage: true, hasMedia: true, icon: <Shield size={20} />, iconBg: '#FEE2E2', iconColor: '#DC2626' },
  { id: 2, name: '执法记录仪', model: 'DSJ-A7', code: 'EQ2024002', rfid: 'RFID001002', category: '执法设备', status: '正常', nextMaintain: '2026-09', source: '配发', purchaseDate: '2024-02-20', warrantyExpiry: '2027-02-20', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-01', lastCheckDate: '2026-05-18', hasManual: true, hasImage: true, hasMedia: false, icon: <Camera size={20} />, iconBg: '#DBEAFE', iconColor: '#3B82F6' },
  { id: 3, name: '手铐', model: 'SK-01', code: 'EQ2024003', rfid: 'RFID001003', category: '警械设备', status: '正常', nextMaintain: null, source: '配发', purchaseDate: '2024-01-10', warrantyExpiry: '2029-01-10', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-02', lastCheckDate: '2026-05-15', hasManual: true, hasImage: false, hasMedia: false, icon: <Link size={20} />, iconBg: '#E8F0FE', iconColor: '#1A56DB' },
  { id: 4, name: '防刺服', model: 'FCF-J-AH01', code: 'EQ2024004', rfid: 'RFID001004', category: '防护装备', status: '待保养', nextMaintain: '2026-06-15', source: '采购', purchaseDate: '2023-11-10', warrantyExpiry: '2028-11-10', dept: '刑警支队', userName: '张警官', location: '个人保管柜B-01', lastCheckDate: '2026-04-10', hasManual: true, hasImage: true, hasMedia: true, icon: <Shield size={20} />, iconBg: '#FEF3C7', iconColor: '#D97706' },
  { id: 5, name: '对讲机', model: 'GP3688', code: 'EQ2024005', rfid: 'RFID001005', category: '通信设备', status: '报修中', nextMaintain: null, source: '配发', purchaseDate: '2024-01-20', warrantyExpiry: '2027-01-20', dept: '刑警支队', userName: '张警官', location: '设备维修中心', lastCheckDate: '2026-05-25', hasManual: true, hasImage: true, hasMedia: false, icon: <Radio size={20} />, iconBg: '#DBEAFE', iconColor: '#3B82F6' },
  { id: 6, name: '强光手电', model: 'SD-01', code: 'EQ2024006', rfid: 'RFID001006', category: '照明设备', status: '正常', nextMaintain: '2026-10', source: '采购', purchaseDate: '2024-02-15', warrantyExpiry: '2027-02-15', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-04', lastCheckDate: '2026-05-22', hasManual: true, hasImage: false, hasMedia: false, icon: <Sun size={20} />, iconBg: '#FEF3C7', iconColor: '#F59E0B' },
  { id: 7, name: '催泪喷射器', model: 'OC-500', code: 'EQ2024007', rfid: 'RFID001007', category: '警械设备', status: '待报废', nextMaintain: null, source: '配发', purchaseDate: '2023-06-01', warrantyExpiry: '2026-06-01', dept: '刑警支队', userName: '张警官', location: '待报废区', lastCheckDate: '2026-05-01', hasManual: true, hasImage: true, hasMedia: true, icon: <SprayCan size={20} />, iconBg: '#FEE2E2', iconColor: '#EF4444' },
  { id: 8, name: '急救包', model: 'JJ-01', code: 'EQ2024008', rfid: 'RFID001008', category: '医疗装备', status: '正常', nextMaintain: '2026-07', source: '采购', purchaseDate: '2024-01-25', warrantyExpiry: '2027-01-25', dept: '刑警支队', userName: '张警官', location: '个人保管柜C-01', lastCheckDate: '2026-05-20', hasManual: true, hasImage: true, hasMedia: false, icon: <HeartPulse size={20} />, iconBg: '#D1FAE5', iconColor: '#10B981' },
  { id: 9, name: '防割手套', model: 'FG-ST01', code: 'EQ2024009', rfid: 'RFID001009', category: '防护装备', status: '正常', nextMaintain: '2026-11', source: '配发', purchaseDate: '2024-03-01', warrantyExpiry: '2029-03-01', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-05', lastCheckDate: '2026-05-19', hasManual: false, hasImage: true, hasMedia: false, icon: <Shield size={20} />, iconBg: '#D1FAE5', iconColor: '#10B981' },
  { id: 10, name: '警务通', model: 'JW-T800', code: 'EQ2024010', rfid: 'RFID001010', category: '通信设备', status: '正常', nextMaintain: '2026-08', source: '调拨', purchaseDate: '2024-02-01', warrantyExpiry: '2027-02-01', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-06', lastCheckDate: '2026-05-21', hasManual: true, hasImage: true, hasMedia: true, icon: <FileText size={20} />, iconBg: '#E8F0FE', iconColor: '#1A56DB' },
  { id: 11, name: '伸缩警棍', model: 'SG-01', code: 'EQ2024011', rfid: 'RFID001011', category: '警械设备', status: '待保养', nextMaintain: '2026-06-20', source: '配发', purchaseDate: '2024-01-05', warrantyExpiry: '2029-01-05', dept: '刑警支队', userName: '张警官', location: '个人保管柜B-02', lastCheckDate: '2026-04-20', hasManual: true, hasImage: true, hasMedia: false, icon: <Shield size={20} />, iconBg: '#FEF3C7', iconColor: '#D97706' },
  { id: 12, name: '反光背心', model: 'FG-BX01', code: 'EQ2024012', rfid: 'RFID001012', category: '交通装备', status: '正常', nextMaintain: '2026-12', source: '采购', purchaseDate: '2024-03-10', warrantyExpiry: '2027-03-10', dept: '刑警支队', userName: '张警官', location: '个人保管柜A-07', lastCheckDate: '2026-05-23', hasManual: false, hasImage: false, hasMedia: false, icon: <Shield size={20} />, iconBg: '#FEF3C7', iconColor: '#F59E0B' },
]

/* ── 装备详情弹窗 ── */
function EquipmentDetailModal({ item, open, onClose }: { item: Equipment | null; open: boolean; onClose: () => void }) {
  const [showMore, setShowMore] = useState(false)
  if (!open || !item) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[600px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">装备详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto px-6 py-4">
          {/* 基本信息 */}
          <div className="mb-5">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <div className="h-4 w-1 rounded-full bg-[#1A56DB]" />
              基本信息
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
              <div><div className="text-xs text-[#6B7280]">装备名称</div><div className="mt-0.5 font-medium text-[#1F2937]">{item.name}</div></div>
              <div><div className="text-xs text-[#6B7280]">规格型号</div><div className="mt-0.5 text-[#1F2937]">{item.model}</div></div>
              <div><div className="text-xs text-[#6B7280]">资产编码</div><div className="mt-0.5 font-mono text-[#1F2937]">{item.code}</div></div>
              <div><div className="text-xs text-[#6B7280]">RFID编码</div><div className="mt-0.5 font-mono text-[#1F2937]">{item.rfid}</div></div>
              <div><div className="text-xs text-[#6B7280]">装备分类</div><div className="mt-0.5 text-[#1F2937]">{item.category}</div></div>
              <div><div className="text-xs text-[#6B7280]">当前状态</div><div className="mt-0.5"><StatusBadge status={item.status} /></div></div>
            </div>
          </div>

          {/* 使用信息 */}
          <div className="mb-5">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <div className="h-4 w-1 rounded-full bg-[#10B981]" />
              使用信息
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
              <div><div className="text-xs text-[#6B7280]">使用人</div><div className="mt-0.5 text-[#1F2937]">{item.userName}</div></div>
              <div><div className="text-xs text-[#6B7280]">所属部门</div><div className="mt-0.5 text-[#1F2937]">{item.dept}</div></div>
              <div><div className="text-xs text-[#6B7280]">存放位置</div><div className="mt-0.5 text-[#1F2937]">{item.location}</div></div>
              <div><div className="text-xs text-[#6B7280]">资产来源</div><div className="mt-0.5"><SourceBadge source={item.source} /></div></div>
              <div><div className="text-xs text-[#6B7280]">采购入库日期</div><div className="mt-0.5 text-[#1F2937]">{item.purchaseDate}</div></div>
              <div><div className="text-xs text-[#6B7280]">质保到期日</div><div className="mt-0.5 text-[#1F2937]">{item.warrantyExpiry}</div></div>
              <div><div className="text-xs text-[#6B7280]">下次保养日期</div><div className="mt-0.5"><MaintainWarning dateStr={item.nextMaintain} /></div></div>
              <div><div className="text-xs text-[#6B7280]">最后盘点日期</div><div className="mt-0.5 text-[#1F2937]">{item.lastCheckDate}</div></div>
            </div>
          </div>

          {/* 使用资料 */}
          <div className="mb-5">
            <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <div className="h-4 w-1 rounded-full bg-[#8B5CF6]" />
              使用资料
            </div>
            <div className="flex gap-2">
              {item.hasManual && (
                <button className="inline-flex items-center gap-1.5 rounded-lg border border-[#1A56DB] bg-[#E8F0FE] px-4 py-2 text-sm text-[#1A56DB] transition hover:bg-[#1A56DB] hover:text-white">
                  <BookOpen size={14} /> 使用手册
                </button>
              )}
              {item.hasImage && (
                <button className="inline-flex items-center gap-1.5 rounded-lg border border-[#059669] bg-[#D1FAE5] px-4 py-2 text-sm text-[#059669] transition hover:bg-[#059669] hover:text-white">
                  <Image size={14} /> 操作图片
                </button>
              )}
              {item.hasMedia && (
                <button className="inline-flex items-center gap-1.5 rounded-lg border border-[#D97706] bg-[#FEF3C7] px-4 py-2 text-sm text-[#D97706] transition hover:bg-[#D97706] hover:text-white">
                  <Video size={14} /> 多媒体资料
                </button>
              )}
              {!item.hasManual && !item.hasImage && !item.hasMedia && (
                <span className="text-xs text-[#9CA3AF]">暂无使用资料</span>
              )}
            </div>
          </div>

          {/* 维保历史 */}
          <div className="rounded-lg border border-[#E5E7EB]">
            <button onClick={() => setShowMore(!showMore)} className="flex w-full items-center justify-between px-4 py-3 text-left">
              <span className="text-sm font-medium text-[#374151]">维保历史记录</span>
              {showMore ? <ChevronUp size={16} className="text-[#6B7280]" /> : <ChevronDown size={16} className="text-[#6B7280]" />}
            </button>
            {showMore && (
              <div className="border-t border-[#E5E7EB] px-4 py-3">
                <div className="space-y-3 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-xs text-[#059669]">保养</span>
                    <span className="text-[#6B7280]">2025-11-15</span>
                    <span className="text-[#374151]">常规季度保养，设备状态良好</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-[#DBEAFE] px-2 py-0.5 text-xs text-[#2563EB]">维修</span>
                    <span className="text-[#6B7280]">2025-08-20</span>
                    <span className="text-[#374151]">更换电池组件</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-xs text-[#059669]">保养</span>
                    <span className="text-[#6B7280]">2025-05-10</span>
                    <span className="text-[#374151]">常规季度保养</span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 justify-end border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
        </div>
      </div>
    </div>
  )
}

/* ── main component ── */
export default function MyEquipmentPage() {
  const total = equipmentList.length
  const normalCount = equipmentList.filter((e) => e.status === '正常').length
  const maintainCount = equipmentList.filter((e) => e.status === '待保养').length
  const repairCount = equipmentList.filter((e) => e.status === '报修中').length
  const scrapCount = equipmentList.filter((e) => e.status === '待报废').length

  const [searchText, setSearchText] = useState('')
  const [detailItem, setDetailItem] = useState<Equipment | null>(null)
  const [showDetail, setShowDetail] = useState(false)

  const filteredList = equipmentList.filter(
    (e) =>
      !searchText ||
      e.name.includes(searchText) ||
      e.model.includes(searchText) ||
      e.code.includes(searchText) ||
      e.rfid.includes(searchText)
  )

  const openDetail = (item: Equipment) => { setDetailItem(item); setShowDetail(true) }

  return (
    <div className="space-y-5">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">我的装备</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
          <Download size={14} /> 导出装备卡(PDF)
        </button>
      </div>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#E8F0FE]"><Package size={18} className="text-[#1A56DB]" /></div>
            <div><div className="text-xs text-[#6B7280]">持有总数</div><div className="text-xl font-bold text-[#1A56DB]">{total}</div></div>
          </div>
        </div>
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#D1FAE5]"><CheckCircle size={18} className="text-[#059669]" /></div>
            <div><div className="text-xs text-[#6B7280]">正常</div><div className="text-xl font-bold text-[#059669]">{normalCount}</div></div>
          </div>
        </div>
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FEF3C7]"><Clock size={18} className="text-[#D97706]" /></div>
            <div><div className="text-xs text-[#6B7280]">待保养</div><div className="text-xl font-bold text-[#D97706]">{maintainCount}</div></div>
          </div>
        </div>
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#DBEAFE]"><Wrench size={18} className="text-[#2563EB]" /></div>
            <div><div className="text-xs text-[#6B7280]">报修中</div><div className="text-xl font-bold text-[#2563EB]">{repairCount}</div></div>
          </div>
        </div>
        <div className="rounded-lg bg-white p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#FEE2E2]"><Trash2 size={18} className="text-[#DC2626]" /></div>
            <div><div className="text-xs text-[#6B7280]">待报废</div><div className="text-xl font-bold text-[#DC2626]">{scrapCount}</div></div>
          </div>
        </div>
      </div>

      {/* ── Search & Top Actions ── */}
      <div className="flex items-center justify-between gap-4">
        <div className="relative w-80">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索装备名称、型号、编码、RFID..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
        {/* 顶部操作按钮 */}
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#1A56DB] bg-[#E8F0FE] px-3 text-sm text-[#1A56DB] transition hover:bg-[#1A56DB] hover:text-white">
            <Hand size={14} /> 领用/借用
          </button>
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#D97706] bg-[#FEF3C7] px-3 text-sm text-[#D97706] transition hover:bg-[#D97706] hover:text-white">
            <Wrench size={14} /> 报修
          </button>
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#DC2626] bg-[#FEE2E2] px-3 text-sm text-[#DC2626] transition hover:bg-[#DC2626] hover:text-white">
            <Trash2 size={14} /> 报废
          </button>
          <button className="inline-flex h-9 items-center gap-1.5 rounded-md border border-[#7C3AED] bg-[#EDE9FE] px-3 text-sm text-[#7C3AED] transition hover:bg-[#7C3AED] hover:text-white">
            <MessageSquare size={14} /> 投诉
          </button>
        </div>
      </div>

      {/* ── Equipment List Table ── */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备信息</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">分类</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">资产来源</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存放位置</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">保养提醒</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">使用资料</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredList.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    <Package size={48} className="mx-auto mb-3 opacity-30" />
                    未找到匹配的装备
                  </td>
                </tr>
              )}
              {filteredList.map((eq) => (
                <tr key={eq.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  {/* 装备信息 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
                        style={{ backgroundColor: eq.iconBg, color: eq.iconColor }}
                      >
                        {eq.icon}
                      </div>
                      <div>
                        <div className="font-medium text-[#1F2937]">{eq.name}</div>
                        <div className="text-xs text-[#6B7280]">{eq.model} &middot; {eq.code}</div>
                        <div className="text-[11px] font-mono text-[#9CA3AF]">RFID: {eq.rfid}</div>
                      </div>
                    </div>
                  </td>
                  {/* 分类 */}
                  <td className="px-4 py-3 text-[#374151]">{eq.category}</td>
                  {/* 状态 */}
                  <td className="px-4 py-3"><StatusBadge status={eq.status} /></td>
                  {/* 资产来源 */}
                  <td className="px-4 py-3"><SourceBadge source={eq.source} /></td>
                  {/* 存放位置 */}
                  <td className="px-4 py-3 text-xs text-[#374151]">{eq.location}</td>
                  {/* 保养提醒 */}
                  <td className="px-4 py-3"><MaintainWarning dateStr={eq.nextMaintain} /></td>
                  {/* 使用资料 - 使用手册/操作图片/多媒体资料 */}
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-1">
                      {eq.hasManual && (
                        <button
                          className="inline-flex items-center gap-1 rounded-md bg-[#E8F0FE] px-2 py-1 text-xs text-[#1A56DB] transition hover:bg-[#1A56DB] hover:text-white"
                          title="查看使用手册"
                        >
                          <BookOpen size={10} /> 手册
                        </button>
                      )}
                      {eq.hasImage && (
                        <button
                          className="inline-flex items-center gap-1 rounded-md bg-[#D1FAE5] px-2 py-1 text-xs text-[#059669] transition hover:bg-[#059669] hover:text-white"
                          title="查看操作图片"
                        >
                          <Image size={10} /> 图片
                        </button>
                      )}
                      {eq.hasMedia && (
                        <button
                          className="inline-flex items-center gap-1 rounded-md bg-[#FEF3C7] px-2 py-1 text-xs text-[#D97706] transition hover:bg-[#D97706] hover:text-white"
                          title="查看多媒体资料"
                        >
                          <Video size={10} /> 视频
                        </button>
                      )}
                      {!eq.hasManual && !eq.hasImage && !eq.hasMedia && (
                        <span className="text-xs text-[#9CA3AF]">-</span>
                      )}
                    </div>
                  </td>
                  {/* 操作 - 查看详情 */}
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center">
                      <button
                        onClick={() => openDetail(eq)}
                        className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#1A56DB] px-3 text-xs text-white transition hover:bg-[#153E7E]"
                        title="查看装备详情"
                      >
                        <Eye size={13} /> 查看详情
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredList.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 装备详情弹窗 */}
      <EquipmentDetailModal item={detailItem} open={showDetail} onClose={() => setShowDetail(false)} />
    </div>
  )
}
