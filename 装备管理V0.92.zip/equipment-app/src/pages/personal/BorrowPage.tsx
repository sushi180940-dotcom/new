import { useState } from 'react'
import {
  Plus, Package, CheckCircle, Search, Eye,
  CheckCircle2, XCircle, Clock, ChevronRight, ShieldCheck,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ── types ── */
interface BorrowItem {
  name: string
  spec: string
  quantity: number
  unit: string
  purpose?: string
}

interface BorrowRecord {
  id: string
  type: string
  typeTag: 'info' | 'success' | 'warning' | 'info'
  equipment: BorrowItem[]
  applyTime: string
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'default' | 'danger'
  steps: string[]
  currentStep: number
  applicant: string
  dept: string
}

/* ── step progress bar ── */
function StepProgress({ steps, currentStep }: { steps: string[]; currentStep: number }) {
  return (
    <div className="flex items-center gap-1">
      {steps.map((step, i) => (
        <div key={step} className="flex items-center">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                'flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold',
                i < currentStep && 'bg-[#10B981] text-white',
                i === currentStep && 'bg-[#1A56DB] text-white',
                i > currentStep && 'border border-[#D1D5DB] text-[#9CA3AF]'
              )}
            >
              {i < currentStep ? <CheckCircle size={14} /> : i + 1}
            </div>
            <span className={cn('mt-0.5 whitespace-nowrap text-[10px]', i === currentStep ? 'font-medium text-[#1A56DB]' : 'text-[#9CA3AF]')}>
              {step}
            </span>
          </div>
          {i < steps.length - 1 && (
            <div className={cn('mb-3 ml-0.5 mr-0.5 h-0.5 w-6', i < currentStep ? 'bg-[#10B981]' : 'bg-[#E5E7EB]')} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ── mock data ── */
const ongoingRecords: BorrowRecord[] = [
  {
    id: 'LY2026001', type: '新警配发', typeTag: 'info',
    equipment: [
      { name: '防弹背心 FDY-2R-01', spec: 'FDY-2R/二级', quantity: 1, unit: '件', purpose: '新警入职配发' },
      { name: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G', quantity: 1, unit: '台', purpose: '日常执法使用' },
      { name: '手铐 SK-01', spec: 'SK-STD', quantity: 1, unit: '副', purpose: '执勤携带' },
    ],
    applyTime: '2026-05-28 10:30', status: '审批中', statusColor: 'warning',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 1,
    applicant: '张警官', dept: '刑侦支队',
  },
  {
    id: 'LY2026002', type: '装备更新', typeTag: 'success',
    equipment: [
      { name: '对讲机 GP3688', spec: 'GP3688/UHF', quantity: 2, unit: '台', purpose: '老旧设备更换' },
      { name: '强光手电 SD-01', spec: 'SD-01/1000lm', quantity: 3, unit: '支', purpose: '夜间巡逻使用' },
    ],
    applyTime: '2026-05-25 14:15', status: '待出库', statusColor: 'info',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 2,
    applicant: '刘管理员', dept: '治安大队',
  },
  {
    id: 'LY2026003', type: '损耗补充', typeTag: 'warning',
    equipment: [
      { name: '防割手套 FG-ST01', spec: 'FG-ST5/五级', quantity: 5, unit: '双', purpose: '损耗补充' },
      { name: '急救包 JJ-01', spec: '综合型', quantity: 2, unit: '个', purpose: '过期更换' },
    ],
    applyTime: '2026-05-20 09:00', status: '待确认', statusColor: 'info',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 3,
    applicant: '王警官', dept: '特警支队',
  },
]

const historyRecords: BorrowRecord[] = [
  {
    id: 'LY2025105', type: '新警配发', typeTag: 'info',
    equipment: [
      { name: '防弹背心 FDY-2R-01', spec: 'FDY-2R/二级', quantity: 1, unit: '件', purpose: '新警入职' },
      { name: '执法记录仪 DSJ-A7', spec: 'DSJ-A7/64G', quantity: 1, unit: '台', purpose: '日常执法' },
      { name: '手铐 SK-01', spec: 'SK-STD', quantity: 1, unit: '副', purpose: '执勤' },
      { name: '防刺服 FCF-J-AH01', spec: 'FCF-II', quantity: 1, unit: '件', purpose: '巡逻防护' },
    ],
    applyTime: '2025-08-15 10:00', status: '已完成', statusColor: 'success',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 5,
    applicant: '赵警官', dept: '派出所',
  },
  {
    id: 'LY2025098', type: '临时借用', typeTag: 'info',
    equipment: [
      { name: '反光背心 FG-BX01', spec: 'FG-01/网眼', quantity: 3, unit: '件', purpose: '交通疏导' },
    ],
    applyTime: '2025-07-20 16:30', status: '已归还', statusColor: 'default',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '归还确认'], currentStep: 5,
    applicant: '钱警官', dept: '交警支队',
  },
  {
    id: 'LY2025086', type: '专项任务', typeTag: 'success',
    equipment: [
      { name: '对讲机 GP3688', spec: 'GP3688/UHF', quantity: 2, unit: '台', purpose: '联合行动通讯' },
      { name: '强光手电 SD-01', spec: 'SD-01/1000lm', quantity: 3, unit: '支', purpose: '夜间搜索' },
    ],
    applyTime: '2025-06-10 08:45', status: '已完成', statusColor: 'success',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 5,
    applicant: '孙警官', dept: '反恐支队',
  },
  {
    id: 'LY2025072', type: '损耗补充', typeTag: 'warning',
    equipment: [
      { name: '急救包 JJ-01', spec: '综合型', quantity: 1, unit: '个', purpose: '过期更换' },
    ],
    applyTime: '2025-04-22 11:20', status: '已驳回', statusColor: 'danger',
    steps: ['提交申请', '领导审批'], currentStep: 1,
    applicant: '周警官', dept: '派出所',
  },
]

/* 待审批数据 */
const pendingApprovalRecords: BorrowRecord[] = [
  {
    id: 'LY2026010', type: '任务配发', typeTag: 'success',
    equipment: [
      { name: '防弹头盔 FDT-01', spec: 'FDT-01/三级', quantity: 5, unit: '顶', purpose: '缉毒专项行动' },
      { name: '防弹盾牌 FDP-01', spec: 'FDP-01/手持式', quantity: 3, unit: '面', purpose: '突击组装备' },
    ],
    applyTime: '2026-06-10 09:30', status: '待审批', statusColor: 'warning',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 0,
    applicant: '李队长', dept: '缉毒支队',
  },
  {
    id: 'LY2026011', type: '损耗补充', typeTag: 'warning',
    equipment: [
      { name: '防刺靴 FCX-01', spec: 'FCX-01/防刺', quantity: 8, unit: '双', purpose: '年度损耗更换' },
    ],
    applyTime: '2026-06-09 14:00', status: '待审批', statusColor: 'warning',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 0,
    applicant: '陈警官', dept: '巡逻大队',
  },
  {
    id: 'LY2026012', type: '新警配发', typeTag: 'info',
    equipment: [
      { name: '防弹背心 FDY-2R-01', spec: 'FDY-2R/二级', quantity: 3, unit: '件', purpose: '新警入职配发' },
      { name: '防割手套 FG-ST01', spec: 'FG-ST5/五级', quantity: 3, unit: '双', purpose: '新警入职配发' },
      { name: '警棍 JG-TELE', spec: 'JG-TELE/伸缩', quantity: 3, unit: '根', purpose: '新警入职配发' },
    ],
    applyTime: '2026-06-08 10:15', status: '待审批', statusColor: 'warning',
    steps: ['提交申请', '领导审批', '仓库准备', '领用确认', '完成'], currentStep: 0,
    applicant: '吴管理员', dept: '人事训练处',
  },
]

/* ── record card ── */
function RecordCard({ record, onView }: { record: BorrowRecord; onView?: (r: BorrowRecord) => void }) {
  return (
    <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition hover:shadow-md">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-sm font-medium text-[#1A56DB]">{record.id}</span>
          <Badge variant={record.typeTag}>{record.type}</Badge>
          <Badge variant={record.statusColor === 'info' ? 'info' : record.statusColor}>{record.status}</Badge>
        </div>
        <span className="text-xs text-[#6B7280]">{record.applyTime}</span>
      </div>

      <div className="mt-2 flex items-center gap-2 text-xs text-[#6B7280]">
        <span>申请人: {record.applicant}</span>
        <span>·</span>
        <span>部门: {record.dept}</span>
      </div>

      <div className="mt-3">
        <div className="text-xs font-medium text-[#6B7280]">装备清单：</div>
        <div className="mt-1 flex flex-wrap gap-1">
          {record.equipment.map((eq, i) => (
            <span key={i} className="inline-flex items-center gap-1 rounded-md bg-[#F3F4F6] px-2 py-0.5 text-xs text-[#374151]">
              <Package size={10} /> {eq.name} x{eq.quantity}{eq.unit}
            </span>
          ))}
        </div>
      </div>

      <div className="mt-3 flex items-center justify-between">
        <StepProgress steps={record.steps} currentStep={record.currentStep} />
        {onView && (
          <button onClick={() => onView(record)} className="inline-flex items-center gap-1 rounded-md border border-[#D1D5DB] px-3 py-1 text-xs text-[#374151] hover:bg-[#F3F4F6] transition">
            <Eye size={12} /> 查看
          </button>
        )}
      </div>
    </div>
  )
}

/* ── Approval Detail Modal ── */
function ApprovalModal({ record, onClose, onApprove, onReject }: {
  record: BorrowRecord | null
  onClose: () => void
  onApprove: (id: string, comment: string) => void
  onReject: (id: string, comment: string) => void
}) {
  const [comment, setComment] = useState('')
  const [action, setAction] = useState<'approve' | 'reject' | null>(null)

  if (!record) return null

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[85vh] w-[640px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">审批详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <XCircle size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto p-6 space-y-4">
          {/* 基本信息 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#F9FAFB] p-4">
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div><span className="text-[#6B7280]">申请单号:</span> <span className="font-medium text-[#1F2937]">{record.id}</span></div>
              <div><span className="text-[#6B7280]">申请类型:</span> <span className="font-medium text-[#1F2937]">{record.type}</span></div>
              <div><span className="text-[#6B7280]">申请人:</span> <span className="font-medium text-[#1F2937]">{record.applicant}</span></div>
              <div><span className="text-[#6B7280]">所属部门:</span> <span className="font-medium text-[#1F2937]">{record.dept}</span></div>
              <div><span className="text-[#6B7280]">申请时间:</span> <span className="font-medium text-[#1F2937]">{record.applyTime}</span></div>
              <div><span className="text-[#6B7280]">当前状态:</span> <Badge variant={record.statusColor === 'info' ? 'info' : record.statusColor}>{record.status}</Badge></div>
            </div>
          </div>

          {/* 装备清单 */}
          <div>
            <h3 className="mb-2 text-sm font-semibold text-[#374151]">申请装备清单</h3>
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">数量</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">用途说明</th>
                </tr>
              </thead>
              <tbody>
                {record.equipment.map((eq, i) => (
                  <tr key={i} className="border-b border-[#F3F4F6]">
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{eq.name}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{eq.spec}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{eq.quantity}{eq.unit}</td>
                    <td className="px-3 py-2 text-[11px] text-[#6B7280]">{eq.purpose || '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 审批意见 */}
          {record.status === '待审批' && (
            <div>
              <h3 className="mb-2 text-sm font-semibold text-[#374151]">审批意见</h3>
              <textarea
                value={comment}
                onChange={e => setComment(e.target.value)}
                placeholder="请输入审批意见（可选）..."
                rows={3}
                className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] resize-none"
              />
            </div>
          )}

          {/* 审批流程 */}
          <div>
            <h3 className="mb-2 text-sm font-semibold text-[#374151]">审批流程</h3>
            <StepProgress steps={record.steps} currentStep={record.currentStep} />
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
          {record.status === '待审批' && (
            <>
              <button
                onClick={() => { setAction('reject'); onReject(record.id, comment) }}
                className="h-9 rounded-md border border-[#EF4444] bg-white px-5 text-sm text-[#EF4444] hover:bg-[#FEF2F2]"
              >
                <XCircle size={14} className="inline mr-1" />驳回
              </button>
              <button
                onClick={() => { setAction('approve'); onApprove(record.id, comment) }}
                className="h-9 rounded-md bg-[#10B981] px-5 text-sm text-white hover:bg-[#059669]"
              >
                <CheckCircle2 size={14} className="inline mr-1" />批准
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

/* ── main component ── */
export default function BorrowPage() {
  const [activeTab, setActiveTab] = useState<'ongoing' | 'history' | 'approval'>('ongoing')
  const [searchText, setSearchText] = useState('')
  const [approvalRecord, setApprovalRecord] = useState<BorrowRecord | null>(null)
  const [pendingList, setPendingList] = useState<BorrowRecord[]>(pendingApprovalRecords)

  const getRecords = () => {
    switch (activeTab) {
      case 'ongoing': return ongoingRecords
      case 'history': return historyRecords
      case 'approval': return pendingList
      default: return ongoingRecords
    }
  }

  const records = getRecords()
  const filteredRecords = records.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.equipment.some((e) => e.name.includes(searchText)) ||
      r.applicant.includes(searchText)
  )

  const handleApprove = (id: string, comment: string) => {
    setPendingList(prev => prev.filter(r => r.id !== id))
    setApprovalRecord(null)
    alert(`已批准申请 ${id}${comment ? '，意见: ' + comment : ''}`)
  }

  const handleReject = (id: string, comment: string) => {
    setPendingList(prev => prev.filter(r => r.id !== id))
    setApprovalRecord(null)
    alert(`已驳回申请 ${id}${comment ? '，原因: ' + comment : ''}`)
  }

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">领用管理</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Plus size={16} />
          申请领用
        </button>
      </div>

      {/* ── Tabs ── */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          <button
            onClick={() => setActiveTab('ongoing')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'ongoing' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            进行中 ({ongoingRecords.length})
            {activeTab === 'ongoing' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'history' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            历史记录 ({historyRecords.length})
            {activeTab === 'history' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('approval')}
            className={cn(
              'relative pb-3 text-sm font-medium transition',
              activeTab === 'approval' ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            <span className="flex items-center gap-1.5">
              <ShieldCheck size={14} />
              审批管理
              <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#EF4444] px-1.5 text-[10px] font-bold text-white">
                {pendingList.length}
              </span>
            </span>
            {activeTab === 'approval' && (
              <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
            )}
          </button>
        </div>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、装备名称、申请人..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Records ── */}
      <div className="space-y-3">
        {filteredRecords.map((record) => (
          <RecordCard
            key={record.id}
            record={record}
            onView={activeTab === 'approval' ? setApprovalRecord : undefined}
          />
        ))}
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <Package size={48} className="mx-auto mb-3 opacity-30" />
            暂无记录
          </div>
        )}
      </div>

      {/* Approval Modal */}
      {approvalRecord && (
        <ApprovalModal
          record={approvalRecord}
          onClose={() => setApprovalRecord(null)}
          onApprove={handleApprove}
          onReject={handleReject}
        />
      )}
    </div>
  )
}
