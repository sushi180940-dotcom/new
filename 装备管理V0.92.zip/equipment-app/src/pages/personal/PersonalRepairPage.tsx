import { useState } from 'react'
import {
  Wrench,
  Search,
} from 'lucide-react'
import Badge from '@/components/Badge'

/* ── types ── */
interface RepairRecord {
  id: string
  equipment: string
  model: string
  code: string
  description: string
  time: string
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'danger' | 'default'
}

/* ── mock data ── */
const repairRecords: RepairRecord[] = [
  {
    id: 'BX2026001',
    equipment: '对讲机',
    model: 'GP3688',
    code: 'EQ2024005',
    description: '无法正常开机，充电后仍无反应，可能电池或主板故障',
    time: '2026-05-28 09:15',
    status: '维修中',
    statusColor: 'warning',
  },
  {
    id: 'BX2026002',
    equipment: '执法记录仪',
    model: 'DSJ-A7',
    code: 'EQ2024002',
    description: '录像功能异常，录制视频卡顿且偶尔自动关机',
    time: '2026-05-25 14:30',
    status: '待审批',
    statusColor: 'info',
  },
  {
    id: 'BX2026003',
    equipment: '强光手电',
    model: 'SD-01',
    code: 'EQ2024006',
    description: '开关接触不良，强光模式无法切换',
    time: '2026-05-20 11:00',
    status: '已修好',
    statusColor: 'success',
  },
  {
    id: 'BX2026004',
    equipment: '防弹背心',
    model: 'FDY-2R-01',
    code: 'EQ2024001',
    description: '外表保护层破损，内衬有磨损痕迹，需专业检测',
    time: '2026-05-15 16:45',
    status: '已驳回',
    statusColor: 'danger',
  },
  {
    id: 'BX2026005',
    equipment: '防刺服',
    model: 'FCF-J-AH01',
    code: 'EQ2024004',
    description: '拉链损坏，无法正常穿脱',
    time: '2026-05-10 10:20',
    status: '已修好',
    statusColor: 'success',
  },
  {
    id: 'BX2026006',
    equipment: '警务通',
    model: 'JW-T800',
    code: 'EQ2024010',
    description: '屏幕碎裂，触控失灵，需更换屏幕',
    time: '2026-05-05 13:50',
    status: '维修中',
    statusColor: 'warning',
  },
]

/* ── main component ── */
export default function PersonalRepairPage() {
  const [searchText, setSearchText] = useState('')

  const filteredRecords = repairRecords.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.equipment.includes(searchText) ||
      r.code.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">个人报修</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <Wrench size={16} />
          新增报修
        </button>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、装备名称、编码..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Repair Table ── */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">报修单号</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">故障描述</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">报修时间</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.map((record) => (
              <tr
                key={record.id}
                className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]"
              >
                <td className="px-4 py-3 font-mono text-[13px] font-medium text-[#1A56DB]">
                  {record.id}
                </td>
                <td className="px-4 py-3">
                  <div className="text-[13px] font-medium text-[#1F2937]">{record.equipment}</div>
                  <div className="text-xs text-[#6B7280]">{record.model} · {record.code}</div>
                </td>
                <td className="max-w-xs px-4 py-3 text-[13px] text-[#374151]">
                  <span className="line-clamp-2" title={record.description}>
                    {record.description}
                  </span>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-[13px] text-[#6B7280]">
                  {record.time}
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.statusColor === 'info' ? 'info' : record.statusColor}>{record.status}</Badge>
                </td>
                <td className="px-4 py-3 text-center">
                  <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#1A56DB] px-2.5 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                    <Wrench size={12} /> 详情
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <Wrench size={48} className="mx-auto mb-3 opacity-30" />
            暂无报修记录
          </div>
        )}
      </div>

      {/* ── Legend ── */}
      <div className="flex flex-wrap items-center gap-4 text-xs text-[#6B7280]">
        <span className="font-medium">状态说明：</span>
        <span className="inline-flex items-center gap-1"><Badge variant="info">待审批</Badge> 等待领导审批</span>
        <span className="inline-flex items-center gap-1"><Badge variant="warning">维修中</Badge> 正在维修处理</span>
        <span className="inline-flex items-center gap-1"><Badge variant="success">已修好</Badge> 维修完成待取回</span>
        <span className="inline-flex items-center gap-1"><Badge variant="danger">已驳回</Badge> 报修申请被驳回</span>
      </div>
    </div>
  )
}
