import { useState } from 'react'
import {
  Trash2,
  Search,
} from 'lucide-react'
import Badge from '@/components/Badge'

/* ── types ── */
interface ScrapRecord {
  id: string
  equipment: string
  model: string
  code: string
  reason: string
  typeTag: 'primary' | 'success' | 'warning' | 'danger' | 'info'
  typeLabel: string
  status: string
  statusColor: 'success' | 'warning' | 'info' | 'danger' | 'default'
  applyTime: string
}

/* ── mock data ── */
const scrapRecords: ScrapRecord[] = [
  {
    id: 'BF2026001',
    equipment: '催泪喷射器',
    model: 'OC-500',
    code: 'EQ2024007',
    reason: '已过期失效，超过使用有效期3年，喷射效果大幅下降',
    typeTag: 'warning',
    typeLabel: '过期报废',
    status: '审批中',
    statusColor: 'info',
    applyTime: '2026-05-28 10:00',
  },
  {
    id: 'BF2026002',
    equipment: '防弹背心',
    model: 'FDY-2R-01',
    code: 'EQ2024013',
    reason: '外层破损严重，内衬老化，防护性能下降，经检测不达标',
    typeTag: 'danger',
    typeLabel: '损坏报废',
    status: '待处理',
    statusColor: 'warning',
    applyTime: '2026-05-20 14:30',
  },
  {
    id: 'BF2026003',
    equipment: '对讲机',
    model: 'GP3688',
    code: 'EQ2024014',
    reason: '使用年限超过8年，多次维修仍频繁故障，维修成本过高',
    typeTag: 'primary',
    typeLabel: '年限报废',
    status: '已完成',
    statusColor: 'success',
    applyTime: '2026-04-15 09:15',
  },
  {
    id: 'BF2026004',
    equipment: '手铐',
    model: 'SK-01',
    code: 'EQ2024015',
    reason: '锁芯锈蚀，钥匙无法正常开启，影响执法使用',
    typeTag: 'danger',
    typeLabel: '损坏报废',
    status: '已驳回',
    statusColor: 'danger',
    applyTime: '2026-03-22 11:00',
  },
  {
    id: 'BF2026005',
    equipment: '反光背心',
    model: 'FG-BX01',
    code: 'EQ2024016',
    reason: '反光条脱落严重，达不到夜间安全警示要求',
    typeTag: 'warning',
    typeLabel: '过期报废',
    status: '已完成',
    statusColor: 'success',
    applyTime: '2026-02-10 16:45',
  },
  {
    id: 'BF2026006',
    equipment: '急救包',
    model: 'JJ-01',
    code: 'EQ2024017',
    reason: '内装药品和敷料过期，需整体更换',
    typeTag: 'warning',
    typeLabel: '过期报废',
    status: '审批中',
    statusColor: 'info',
    applyTime: '2026-05-25 08:30',
  },
]

/* ── main component ── */
export default function PersonalScrapPage() {
  const [searchText, setSearchText] = useState('')

  const filteredRecords = scrapRecords.filter(
    (r) =>
      !searchText ||
      r.id.includes(searchText) ||
      r.equipment.includes(searchText) ||
      r.code.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">个人报废</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#EF4444] px-4 text-sm text-white transition hover:bg-[#DC2626]">
          <Trash2 size={16} />
          申请报废
        </button>
      </div>

      {/* ── Search ── */}
      <div className="flex items-center gap-2">
        <div className="relative w-72">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索单号、装备名称、编码..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-9 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Scrap Table ── */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">报废单号</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">报废原因</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">报废类型</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">申请时间</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.map((record) => (
              <tr
                key={record.id}
                className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]"
              >
                <td className="px-4 py-3 font-mono text-[13px] font-medium text-[#1A56DB]">
                  {record.id}
                </td>
                <td className="px-4 py-3">
                  <div className="text-[13px] font-medium text-[#1F2937]">{record.equipment}</div>
                  <div className="text-xs text-[#6B7280]">{record.model} · {record.code}</div>
                </td>
                <td className="max-w-xs px-4 py-3 text-[13px] text-[#374151]">
                  <span className="line-clamp-2" title={record.reason}>
                    {record.reason}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.typeTag}>{record.typeLabel}</Badge>
                </td>
                <td className="whitespace-nowrap px-4 py-3 text-[13px] text-[#6B7280]">
                  {record.applyTime}
                </td>
                <td className="px-4 py-3">
                  <Badge variant={record.statusColor}>{record.status}</Badge>
                </td>
                <td className="px-4 py-3 text-center">
                  <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#1A56DB] px-2.5 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                    查看详情
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredRecords.length === 0 && (
          <div className="py-12 text-center text-sm text-[#9CA3AF]">
            <Trash2 size={48} className="mx-auto mb-3 opacity-30" />
            暂无报废记录
          </div>
        )}
      </div>

      {/* ── Legend ── */}
      <div className="flex flex-wrap items-center gap-4 text-xs text-[#6B7280]">
        <span className="font-medium">类型说明：</span>
        <span className="inline-flex items-center gap-1"><Badge variant="warning">过期报废</Badge> 超过使用有效期</span>
        <span className="inline-flex items-center gap-1"><Badge variant="danger">损坏报废</Badge> 损坏无法修复</span>
        <span className="inline-flex items-center gap-1"><Badge variant="primary">年限报废</Badge> 达到使用年限</span>
      </div>
    </div>
  )
}
