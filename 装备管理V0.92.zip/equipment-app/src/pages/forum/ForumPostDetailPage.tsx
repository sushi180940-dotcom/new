import { useState } from 'react'
import { useParams } from 'react-router-dom'
import {
  ArrowLeft,
  ThumbsUp,
  MessageCircle,
  Star,
  Share2,
  Crown,
  Send,
  ChevronDown,
  ChevronUp,
  Clock,
  MoreHorizontal,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── avatar ── */
function Avatar({ name, color, size = 32 }: { name: string; color: string; size?: number }) {
  return (
    <div
      className="flex shrink-0 items-center justify-center rounded-full text-xs font-bold text-white"
      style={{ backgroundColor: color, width: size, height: size, fontSize: size > 32 ? 16 : 12 }}
    >
      {name[0]}
    </div>
  )
}

/* ── types ── */
interface Comment {
  id: number
  author: string
  avatarColor: string
  unit: string
  content: string
  time: string
  likes: number
  replies: Comment[]
}

/* ── mock post data ── */
const postData = {
  id: 1,
  type: '原创' as const,
  isEssence: true,
  title: '某型号执法记录仪夜间使用技巧分享',
  author: '张警官',
  authorUnit: '某市公安局刑侦支队',
  avatarColor: '#1A56DB',
  time: '2026-06-01 14:30',
  content: `<p>各位战友大家好，最近在使用XX型号执法记录仪进行夜间勘查时，总结了一些曝光参数设置技巧，分享给大家。</p>

<p><strong>一、红外补光设置</strong></p>
<p>夜间环境下，建议开启红外补光功能。根据实际测试，在完全黑暗的环境下，红外补光距离可达15-20米，能够满足大部分夜间执法需求。需要注意的是，红外补光模式下画面为黑白显示，如需彩色录像可关闭红外补光，改用高ISO模式。</p>

<p><strong>二、曝光参数调整</strong></p>
<p>1. 快门速度：建议设置为1/30s以上，避免画面拖影<br>
2. ISO感光度：夜间可提升至3200-6400，过高会产生明显噪点<br>
3. 曝光补偿：根据环境光线适当降低0.3-0.7EV，避免高光过曝</p>

<p><strong>三、实战技巧</strong></p>
<p>在实际执法过程中，建议提前30秒开启设备，让设备自动适应环境光线。同时注意保持设备稳定，夜间录像对抖动更加敏感。可以使用肩夹固定或手持稳定的方式。</p>

<p><strong>四、注意事项</strong></p>
<p>- 定期检查红外灯是否正常工作<br>
- 夜间录像耗电量约为白天的1.5倍，注意电量管理<br>
- 低温环境下电池续航会进一步缩短</p>

<p>以上经验仅供参考，欢迎战友们补充交流！</p>`,
  equipmentTag: '执法记录仪DSJ-A7',
  likes: 128,
  comments: 6,
  saves: 45,
  board: '使用心得',
}

/* ── mock comments ── */
const commentsData: Comment[] = [
  {
    id: 1,
    author: '李警官',
    avatarColor: '#F59E0B',
    unit: '某县局治安大队',
    content: '非常实用的分享！之前夜间巡逻录像总是不清楚，按照这些参数设置后效果提升很多。特别是红外补光的距离确实能达到15米左右，足够用了。',
    time: '2小时前',
    likes: 12,
    replies: [
      {
        id: 11,
        author: '张警官',
        avatarColor: '#1A56DB',
        unit: '某市公安局刑侦支队',
        content: '感谢反馈！如果有其他使用问题欢迎继续交流。',
        time: '1小时前',
        likes: 3,
        replies: [],
      },
    ],
  },
  {
    id: 2,
    author: '王教官',
    avatarColor: '#10B981',
    unit: '省厅警保部',
    content: '写得很好，建议补充一点：在强光环境下（如车灯照射），建议开启WDR宽动态功能，可以有效避免画面过曝和欠曝的问题。另外定期清洁镜头也很重要。',
    time: '3小时前',
    likes: 8,
    replies: [],
  },
  {
    id: 3,
    author: '赵警官',
    avatarColor: '#8B5CF6',
    unit: '某派出所',
    content: '请问DSJ-A7和DSJ-A8在夜间表现上有多大差别？我们单位准备采购新的记录仪，想了解一下。',
    time: '4小时前',
    likes: 5,
    replies: [
      {
        id: 31,
        author: '陈警官',
        avatarColor: '#EF4444',
        unit: '某市公安局特警支队',
        content: 'A8的传感器升级了，暗光表现确实有提升，大概提升了30%左右。不过价格也要贵不少。',
        time: '3小时前',
        likes: 6,
        replies: [
          {
            id: 311,
            author: '赵警官',
            avatarColor: '#8B5CF6',
            unit: '某派出所',
            content: '了解了，谢谢！',
            time: '2小时前',
            likes: 1,
            replies: [],
          },
        ],
      },
    ],
  },
  {
    id: 4,
    author: '刘警官',
    avatarColor: '#06B6D4',
    unit: '某区县分局',
    content: '低温环境下确实续航会短很多，上次冬天出警，录了不到2小时就提示低电量了。建议冬天多带一块备用电池。',
    time: '5小时前',
    likes: 7,
    replies: [],
  },
  {
    id: 5,
    author: '周处',
    avatarColor: '#EC4899',
    unit: '省厅装备处',
    content: '已将该经验整理纳入下个月的培训资料，感谢张警官的分享！希望更多战友能分享自己的使用心得。',
    time: '6小时前',
    likes: 23,
    replies: [],
  },
  {
    id: 6,
    author: '吴警官',
    avatarColor: '#D97706',
    unit: '某市公安局巡警支队',
    content: '补充一个技巧：如果需要在车内录像，注意挡风玻璃的反光问题。建议把记录仪稍微倾斜一定角度，或者用手遮挡一下反光。',
    time: '1天前',
    likes: 4,
    replies: [],
  },
]

/* ── related posts ── */
const relatedPosts = [
  { id: 3, title: '新警装备快速上手指南（2026版）', author: '王教官', likes: 567 },
  { id: 5, title: '手铐日常保养注意事项', author: '陈警官', likes: 234 },
  { id: 8, title: '防刺服选购对比与实测数据', author: '吴警官', likes: 178 },
  { id: 9, title: '关于配备新型执法记录仪的建议', author: '郑警官', likes: 89 },
]

/* ── comment item ── */
function CommentItem({ comment, depth = 0 }: { comment: Comment; depth?: number }) {
  const [showReplies, setShowReplies] = useState(true)
  const hasReplies = comment.replies.length > 0

  return (
    <div className={cn('flex gap-3', depth > 0 && 'mt-2')}>
      <Avatar name={comment.author} color={comment.avatarColor} size={depth > 0 ? 28 : 36} />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[#1F2937]">{comment.author}</span>
          <span className="text-xs text-[#6B7280]">{comment.unit}</span>
          <span className="text-xs text-[#9CA3AF]">{comment.time}</span>
        </div>
        <p className="mt-1 text-sm leading-relaxed text-[#374151]">{comment.content}</p>
        <div className="mt-1 flex items-center gap-3">
          <button className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
            <ThumbsUp size={12} /> {comment.likes}
          </button>
          <button className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
            <MessageCircle size={12} /> 回复
          </button>
        </div>

        {/* Nested replies */}
        {hasReplies && (
          <div className="mt-2">
            {showReplies ? (
              <button
                onClick={() => setShowReplies(false)}
                className="mb-1 inline-flex items-center gap-0.5 text-xs text-[#1A56DB] transition hover:underline"
              >
                <ChevronUp size={12} /> 收起回复
              </button>
            ) : (
              <button
                onClick={() => setShowReplies(true)}
                className="mb-1 inline-flex items-center gap-0.5 text-xs text-[#1A56DB] transition hover:underline"
              >
                <ChevronDown size={12} /> 查看 {comment.replies.length} 条回复
              </button>
            )}
            {showReplies && (
              <div className={cn('space-y-2', depth < 2 && 'border-l-2 border-[#E5E7EB] pl-3')}>
                {comment.replies.map((reply) => (
                  <CommentItem key={reply.id} comment={reply} depth={depth + 1} />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

/* ── main component ── */
export default function ForumPostDetailPage() {
  useParams<{ id: string }>()
  const [commentText, setCommentText] = useState('')
  const [liked, setLiked] = useState(false)
  const [saved, setSaved] = useState(false)
  const [likeCount, setLikeCount] = useState(postData.likes)

  const handleLike = () => {
    setLiked(!liked)
    setLikeCount((prev) => (liked ? prev - 1 : prev + 1))
  }

  return (
    <div className="space-y-5">
      {/* ── Back + Breadcrumb ── */}
      <div className="flex items-center gap-2">
        <a
          href="#/forum"
          className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6] hover:text-[#374151]"
        >
          <ArrowLeft size={16} />
          返回论坛
        </a>
        <span className="text-[#D1D5DB]">/</span>
        <span className="text-sm text-[#6B7280]">{postData.board}</span>
      </div>

      {/* ── Main Content + Sidebar ── */}
      <div className="flex gap-5">
        <div className="min-w-0 flex-1 space-y-4">
          {/* Post Card */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm">
            {/* Type tags */}
            <div className="flex items-center gap-2">
              <span className="inline-block rounded-full bg-[#E8F0FE] px-2.5 py-0.5 text-[11px] font-medium text-[#1A56DB]">
                {postData.type}
              </span>
              {postData.isEssence && (
                <span className="inline-flex items-center gap-1 rounded-full bg-[#FEF3C7] px-2.5 py-0.5 text-[11px] font-medium text-[#D97706]">
                  <Crown size={11} /> 精华
                </span>
              )}
            </div>

            {/* Title */}
            <h1 className="mt-3 text-xl font-bold text-[#1F2937]">{postData.title}</h1>

            {/* Author */}
            <div className="mt-3 flex items-center gap-3">
              <Avatar name={postData.author} color={postData.avatarColor} size={40} />
              <div>
                <div className="text-sm font-medium text-[#374151]">{postData.author}</div>
                <div className="flex items-center gap-2 text-xs text-[#6B7280]">
                  <span>{postData.authorUnit}</span>
                  <span>·</span>
                  <span className="inline-flex items-center gap-0.5">
                    <Clock size={11} />
                    {postData.time}
                  </span>
                </div>
              </div>
            </div>

            {/* Content */}
            <div
              className="prose prose-sm mt-5 max-w-none text-sm leading-relaxed text-[#374151]"
              dangerouslySetInnerHTML={{ __html: postData.content }}
            />

            {/* Equipment Tag */}
            {postData.equipmentTag && (
              <div className="mt-4">
                <span className="inline-flex items-center rounded-full bg-[#E8F0FE] px-3 py-1 text-xs text-[#1A56DB]">
                  关联装备：{postData.equipmentTag}
                </span>
              </div>
            )}

            {/* Interaction Buttons */}
            <div className="mt-5 flex items-center gap-2 border-t border-[#F3F4F6] pt-4">
              <button
                onClick={handleLike}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition',
                  liked
                    ? 'bg-[#E8F0FE] text-[#1A56DB]'
                    : 'bg-[#F3F4F6] text-[#374151] hover:bg-[#E5E7EB]'
                )}
              >
                <ThumbsUp size={16} className={cn(liked && 'fill-[#1A56DB]')} />
                点赞 {likeCount}
              </button>
              <button
                onClick={() => setSaved(!saved)}
                className={cn(
                  'inline-flex items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-medium transition',
                  saved
                    ? 'bg-[#FEF3C7] text-[#D97706]'
                    : 'bg-[#F3F4F6] text-[#374151] hover:bg-[#E5E7EB]'
                )}
              >
                <Star size={16} className={cn(saved && 'fill-[#D97706]')} />
                收藏 {postData.saves}
              </button>
              <button className="inline-flex items-center gap-1.5 rounded-lg bg-[#F3F4F6] px-4 py-2 text-sm font-medium text-[#374151] transition hover:bg-[#E5E7EB]">
                <Share2 size={16} />
                分享
              </button>
              <button className="ml-auto inline-flex items-center gap-1.5 rounded-lg bg-[#F3F4F6] px-4 py-2 text-sm font-medium text-[#374151] transition hover:bg-[#E5E7EB]">
                <MoreHorizontal size={16} />
              </button>
            </div>
          </div>

          {/* ── Comment Section ── */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm">
            <h3 className="mb-4 flex items-center gap-2 text-base font-semibold text-[#1F2937]">
              <MessageCircle size={18} className="text-[#1A56DB]" />
              评论 ({commentsData.length})
            </h3>

            {/* Comment Input */}
            <div className="mb-5 flex gap-3">
              <Avatar name="张" color="#1A56DB" size={36} />
              <div className="min-w-0 flex-1">
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="写下你的评论..."
                  rows={3}
                  className="w-full rounded-lg border border-[#D1D5DB] p-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
                />
                <div className="mt-2 flex justify-end">
                  <button
                    disabled={!commentText.trim()}
                    className={cn(
                      'inline-flex h-9 items-center gap-1.5 rounded-md px-4 text-sm font-medium transition',
                      commentText.trim()
                        ? 'bg-[#1A56DB] text-white hover:bg-[#153E7E]'
                        : 'cursor-not-allowed bg-[#E5E7EB] text-[#9CA3AF]'
                    )}
                  >
                    <Send size={14} />
                    发表评论
                  </button>
                </div>
              </div>
            </div>

            {/* Comment List */}
            <div className="space-y-4">
              {commentsData.map((comment) => (
                <div key={comment.id} className="border-b border-[#F3F4F6] pb-4 last:border-0">
                  <CommentItem comment={comment} />
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Right Sidebar ── */}
        <div className="hidden w-72 shrink-0 space-y-4 lg:block">
          {/* Author Info */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
            <div className="flex items-center gap-3">
              <Avatar name={postData.author} color={postData.avatarColor} size={48} />
              <div>
                <div className="text-sm font-semibold text-[#1F2937]">{postData.author}</div>
                <div className="text-xs text-[#6B7280]">{postData.authorUnit}</div>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2 border-t border-[#F3F4F6] pt-3 text-center">
              <div>
                <div className="text-sm font-bold text-[#1F2937]">43</div>
                <div className="text-[10px] text-[#6B7280]">发帖</div>
              </div>
              <div>
                <div className="text-sm font-bold text-[#1F2937]">1.2k</div>
                <div className="text-[10px] text-[#6B7280]">获赞</div>
              </div>
              <div>
                <div className="text-sm font-bold text-[#1F2937]">89</div>
                <div className="text-[10px] text-[#6B7280]">粉丝</div>
              </div>
            </div>
          </div>

          {/* Related Posts */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
            <h3 className="mb-3 text-sm font-semibold text-[#1F2937]">相关推荐</h3>
            <div className="space-y-3">
              {relatedPosts.map((rp) => (
                <a
                  key={rp.id}
                  href={`#/forum/post/${rp.id}`}
                  className="block rounded-md p-2 transition hover:bg-[#F3F4F6]"
                >
                  <div className="line-clamp-2 text-sm font-medium text-[#374151] transition hover:text-[#1A56DB]">
                    {rp.title}
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-xs text-[#6B7280]">
                    <span>{rp.author}</span>
                    <span>·</span>
                    <span className="inline-flex items-center gap-0.5">
                      <ThumbsUp size={10} /> {rp.likes}
                    </span>
                  </div>
                </a>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
