import { useState } from 'react'
import {
  PenLine,
  Search,
  ThumbsUp,
  MessageCircle,
  Star,
  Share2,
  Crown,
  Flame,
  Clock,
  Award,
  Star as StarIcon,
  Lightbulb,
  HelpCircle,
  ClipboardCheck,
  FileText,
  Award as AwardIcon,
  LayoutGrid,
  Users,
  User,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
type PostType = '原创' | '转载' | '提问' | '分享'

interface Post {
  id: number
  type: PostType
  isEssence: boolean
  title: string
  author: string
  authorUnit: string
  avatarColor: string
  summary: string
  time: string
  likes: number
  comments: number
  saves: number
  equipmentTag: string | null
  board: string
}

/* ── board config ── */
const boards = [
  { key: 'all', label: '全部', icon: <LayoutGrid size={16} />, color: '#1A56DB' },
  { key: 'usage', label: '使用心得', icon: <StarIcon size={16} />, color: '#F59E0B' },
  { key: 'suggestion', label: '新需求建议', icon: <Lightbulb size={16} />, color: '#10B981' },
  { key: 'discussion', label: '问题讨论', icon: <HelpCircle size={16} />, color: '#3B82F6' },
  { key: 'review', label: '装备评测', icon: <ClipboardCheck size={16} />, color: '#8B5CF6' },
  { key: 'policy', label: '政策解读', icon: <FileText size={16} />, color: '#06B6D4' },
  { key: 'case', label: '优秀案例', icon: <AwardIcon size={16} />, color: '#EC4899' },
]

/* ── post type badge ── */
function TypeBadge({ type }: { type: PostType }) {
  const configs: Record<PostType, { bg: string; text: string }> = {
    '原创': { bg: 'bg-[#E8F0FE]', text: 'text-[#1A56DB]' },
    '转载': { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' },
    '提问': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
    '分享': { bg: 'bg-[#D1FAE5]', text: 'text-[#059669]' },
  }
  const c = configs[type]
  return (
    <span className={cn('inline-block rounded-full px-2 py-0.5 text-[11px] font-medium', c.bg, c.text)}>
      {type}
    </span>
  )
}

/* ── avatar ── */
function Avatar({ name, color }: { name: string; color: string }) {
  return (
    <div
      className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white"
      style={{ backgroundColor: color }}
    >
      {name[0]}
    </div>
  )
}

/* ── sort tab ── */
function SortTab({
  active,
  icon,
  label,
  onClick,
}: {
  active: boolean
  icon: React.ReactNode
  label: string
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        'relative inline-flex items-center gap-1 pb-2 text-sm font-medium transition',
        active ? 'text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]'
      )}
    >
      {icon}
      {label}
      {active && <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
    </button>
  )
}

/* ── mock posts ── */
const posts: Post[] = [
  {
    id: 1, type: '原创', isEssence: false, title: '某型号执法记录仪夜间使用技巧分享',
    author: '张警官', authorUnit: '某市公安局刑侦支队', avatarColor: '#1A56DB',
    summary: '最近在使用XX型号执法记录仪进行夜间勘查时，总结了一些曝光参数设置技巧，分享给大家。主要涉及红外补光、曝光时间、ISO设置等关键参数...',
    time: '2小时前', likes: 128, comments: 32, saves: 45, equipmentTag: '执法记录仪', board: 'usage',
  },
  {
    id: 2, type: '提问', isEssence: false, title: '防弹背心到期后如何申请更换？',
    author: '李警官', authorUnit: '某县局治安大队', avatarColor: '#F59E0B',
    summary: '本人持有的防弹背心即将达到使用年限，请问更换流程是怎样的？需要准备哪些材料？审批周期大概多久？',
    time: '5小时前', likes: 45, comments: 28, saves: 12, equipmentTag: '防弹背心', board: 'discussion',
  },
  {
    id: 3, type: '原创', isEssence: true, title: '新警装备快速上手指南（2026版）',
    author: '王教官', authorUnit: '省厅警保部', avatarColor: '#10B981',
    summary: '整理了一份新入职民警装备使用指南，涵盖防弹背心穿戴、执法记录仪操作、对讲机使用等核心装备的快速上手方法...',
    time: '1天前', likes: 567, comments: 89, saves: 234, equipmentTag: null, board: 'case',
  },
  {
    id: 4, type: '分享', isEssence: false, title: '某品牌对讲机使用体验报告',
    author: '赵警官', authorUnit: '某派出所', avatarColor: '#8B5CF6',
    summary: '使用某品牌对讲机3个月后的真实体验报告，包括信号覆盖、续航能力、音质效果等方面的详细评测...',
    time: '2天前', likes: 89, comments: 15, saves: 34, equipmentTag: '对讲机', board: 'review',
  },
  {
    id: 5, type: '原创', isEssence: false, title: '手铐日常保养注意事项',
    author: '陈警官', authorUnit: '某市公安局特警支队', avatarColor: '#EF4444',
    summary: '手铐作为高频使用装备，日常保养尤为重要。本文从清洁、润滑、存放等方面分享保养经验...',
    time: '3天前', likes: 234, comments: 45, saves: 67, equipmentTag: '手铐', board: 'usage',
  },
  {
    id: 6, type: '提问', isEssence: false, title: '强光手电电池续航问题反馈',
    author: '刘警官', authorUnit: '某区县分局', avatarColor: '#06B6D4',
    summary: '最近发现强光手电在高亮模式下续航时间明显缩短，标称3小时实际只有1.5小时左右，想了解一下是普遍现象还是个别问题...',
    time: '4天前', likes: 67, comments: 23, saves: 8, equipmentTag: '强光手电', board: 'discussion',
  },
  {
    id: 7, type: '原创', isEssence: true, title: '2026年警用装备配备标准解读',
    author: '周处', authorUnit: '省厅装备处', avatarColor: '#EC4899',
    summary: '针对最新下发的《2026年警用装备配备标准》进行逐条解读，帮助大家理解新标准的变化要点和执行要求...',
    time: '5天前', likes: 345, comments: 56, saves: 189, equipmentTag: null, board: 'policy',
  },
  {
    id: 8, type: '分享', isEssence: false, title: '防刺服选购对比与实测数据',
    author: '吴警官', authorUnit: '某市公安局巡警支队', avatarColor: '#D97706',
    summary: '对比了市面上主流的三款防刺服产品，从防护等级、舒适度、透气性、重量等维度进行实测对比...',
    time: '1周前', likes: 178, comments: 34, saves: 92, equipmentTag: '防刺服', board: 'review',
  },
  {
    id: 9, type: '原创', isEssence: false, title: '关于配备新型执法记录仪的建议',
    author: '郑警官', authorUnit: '某县公安局', avatarColor: '#3B82F6',
    summary: '建议为基层民警配备具有AI识别功能的4K执法记录仪，可以有效提升执法效率和证据质量。以下是具体的方案建议...',
    time: '1周前', likes: 89, comments: 42, saves: 23, equipmentTag: '执法记录仪', board: 'suggestion',
  },
  {
    id: 10, type: '原创', isEssence: true, title: '急救包使用培训：从理论到实操',
    author: '冯教官', authorUnit: '警校培训部', avatarColor: '#10B981',
    summary: '系统讲解警用急救包内各类物品的使用方法，包括止血、包扎、固定等急救技能的操作要点和注意事项...',
    time: '2周前', likes: 456, comments: 67, saves: 156, equipmentTag: '急救包', board: 'case',
  },
  {
    id: 11, type: '提问', isEssence: false, title: '防毒面具滤芯更换周期问题',
    author: '杨警官', authorUnit: '某区消防大队', avatarColor: '#EF4444',
    summary: '防毒面具滤芯是否有统一的更换周期标准？还是根据实际使用情况判断？目前我们单位没有明确规定...',
    time: '2周前', likes: 34, comments: 19, saves: 7, equipmentTag: '防毒面具', board: 'discussion',
  },
  {
    id: 12, type: '原创', isEssence: false, title: '伸缩警棍实战使用经验分享',
    author: '何警官', authorUnit: '某市公安局特警支队', avatarColor: '#7C3AED',
    summary: '结合多年实战经验，分享伸缩警棍在不同场景下的使用技巧和注意事项，包括握持方式、出击角度、收棍技巧等...',
    time: '3周前', likes: 267, comments: 51, saves: 88, equipmentTag: '伸缩警棍', board: 'usage',
  },
]

/* ── hot topics ── */
const hotTopics = [
  { rank: 1, name: '执法记录仪选购指南', heat: '12.3万' },
  { rank: 2, name: '防弹背心保养周期', heat: '8.7万' },
  { rank: 3, name: '新警装备配备标准', heat: '7.2万' },
  { rank: 4, name: '对讲机信号覆盖优化', heat: '5.6万' },
  { rank: 5, name: '急救包物品清单更新', heat: '4.8万' },
  { rank: 6, name: '防刺服透气性问题', heat: '3.9万' },
  { rank: 7, name: '强光手电续航对比', heat: '3.5万' },
  { rank: 8, name: '手铐润滑保养技巧', heat: '2.8万' },
]

/* ── active users ── */
const activeUsers = [
  { name: '王教官', unit: '省厅警保部', posts: 56, avatarColor: '#10B981', medal: 1 },
  { name: '张警官', unit: '某市公安局', posts: 43, avatarColor: '#1A56DB', medal: 2 },
  { name: '陈警官', unit: '特警支队', posts: 38, avatarColor: '#EF4444', medal: 3 },
  { name: '冯教官', unit: '警校培训部', posts: 31, avatarColor: '#F59E0B', medal: 0 },
  { name: '周处', unit: '省厅装备处', posts: 27, avatarColor: '#EC4899', medal: 0 },
  { name: '何警官', unit: '特警支队', posts: 24, avatarColor: '#7C3AED', medal: 0 },
]

/* ── medal icon ── */
function MedalIcon({ rank }: { rank: number }) {
  if (rank === 1) return <Award size={14} className="text-[#F59E0B]" />
  if (rank === 2) return <Award size={14} className="text-[#9CA3AF]" />
  if (rank === 3) return <Award size={14} className="text-[#B45309]" />
  return null
}

/* ── main component ── */
export default function ForumPage() {
  const [activeBoard, setActiveBoard] = useState('all')
  const [sort, setSort] = useState<'hot' | 'new' | 'essence'>('hot')
  const [searchText, setSearchText] = useState('')

  /* filter by board then sort */
  let filteredPosts = activeBoard === 'all'
    ? [...posts]
    : posts.filter((p) => p.board === activeBoard)

  /* search */
  if (searchText) {
    const q = searchText.toLowerCase()
    filteredPosts = filteredPosts.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.author.toLowerCase().includes(q) ||
        p.summary.toLowerCase().includes(q)
    )
  }

  /* sort */
  if (sort === 'new') {
    // simplified: use time string to approximate
    const timeOrder = ['2小时前', '5小时前', '1天前', '2天前', '3天前', '4天前', '5天前', '1周前', '2周前', '3周前']
    filteredPosts.sort((a, b) => timeOrder.indexOf(a.time) - timeOrder.indexOf(b.time))
  } else if (sort === 'essence') {
    filteredPosts.sort((a, b) => (b.isEssence ? 1 : 0) - (a.isEssence ? 1 : 0))
  } else {
    // hot: by likes
    filteredPosts.sort((a, b) => b.likes - a.likes)
  }

  return (
    <div className="space-y-5">
      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备交流论坛</h1>
        <button className="inline-flex h-9 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
          <PenLine size={16} />
          发布帖子
        </button>
      </div>

      {/* ── Board Navigation ── */}
      <div className="flex flex-wrap gap-2 rounded-lg border border-[#E5E7EB] bg-white p-3 shadow-sm">
        {boards.map((board) => (
          <button
            key={board.key}
            onClick={() => setActiveBoard(board.key)}
            className={cn(
              'inline-flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm transition',
              activeBoard === board.key
                ? 'bg-[#E8F0FE] font-medium text-[#1A56DB]'
                : 'text-[#6B7280] hover:bg-[#F3F4F6]'
            )}
          >
            <span style={{ color: activeBoard === board.key ? '#1A56DB' : board.color }}>
              {board.icon}
            </span>
            {board.label}
            <span className="rounded-full bg-[#F3F4F6] px-1.5 py-0 text-[10px] text-[#6B7280]">
              {board.key === 'all' ? posts.length : posts.filter((p) => p.board === board.key).length}
            </span>
          </button>
        ))}
      </div>

      {/* ── Sort + Search ── */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4">
          <SortTab active={sort === 'hot'} icon={<Flame size={16} />} label="最热" onClick={() => setSort('hot')} />
          <SortTab active={sort === 'new'} icon={<Clock size={16} />} label="最新" onClick={() => setSort('new')} />
          <SortTab active={sort === 'essence'} icon={<Crown size={16} className={sort === 'essence' ? 'text-[#F59E0B]' : undefined} />} label="精华" onClick={() => setSort('essence')} />
        </div>
        <div className="relative w-64">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
          <input
            type="text"
            placeholder="搜索帖子、装备、作者..."
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            className="h-8 w-full rounded-md border border-[#D1D5DB] pl-9 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
          />
        </div>
      </div>

      {/* ── Main Content + Sidebar ── */}
      <div className="flex gap-5">
        {/* Post List */}
        <div className="min-w-0 flex-1 space-y-3">
          {filteredPosts.map((post) => (
            <a
              key={post.id}
              href={`#/forum/post/${post.id}`}
              className="block rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm transition-all duration-100 hover:bg-[#FAFBFC] hover:shadow-md"
            >
              {/* Top row: type + title + time */}
              <div className="flex items-center gap-2">
                <TypeBadge type={post.type} />
                {post.isEssence && (
                  <Crown size={16} className="text-[#F59E0B]" />
                )}
                <h3
                  className="min-w-0 flex-1 truncate text-base font-semibold text-[#1F2937] transition hover:text-[#1A56DB]"
                  title={post.title}
                >
                  {post.title}
                </h3>
                <span className="shrink-0 text-xs text-[#6B7280]">{post.time}</span>
              </div>

              {/* Author */}
              <div className="mt-2 flex items-center gap-2">
                <Avatar name={post.author} color={post.avatarColor} />
                <span className="text-sm font-medium text-[#374151]">{post.author}</span>
                <span className="text-[#D1D5DB]">·</span>
                <span className="text-xs text-[#6B7280]">{post.authorUnit}</span>
              </div>

              {/* Summary */}
              <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-[#374151]">
                {post.summary}
              </p>

              {/* Interaction bar */}
              <div className="mt-3 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <span className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
                    <ThumbsUp size={13} /> {post.likes}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
                    <MessageCircle size={13} /> {post.comments}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
                    <Star size={13} /> {post.saves}
                  </span>
                  <span className="inline-flex items-center gap-1 text-xs text-[#6B7280] transition hover:text-[#1A56DB]">
                    <Share2 size={13} /> 分享
                  </span>
                </div>
                {post.equipmentTag && (
                  <span className="inline-flex items-center rounded-full bg-[#E8F0FE] px-2.5 py-0.5 text-xs text-[#1A56DB]">
                    {post.equipmentTag}
                  </span>
                )}
              </div>
            </a>
          ))}

          {filteredPosts.length === 0 && (
            <div className="py-12 text-center text-sm text-[#9CA3AF]">
              <MessageCircle size={48} className="mx-auto mb-3 opacity-30" />
              暂无匹配的帖子
            </div>
          )}
        </div>

        {/* ── Right Sidebar ── */}
        <div className="hidden w-80 shrink-0 space-y-4 xl:block">
          {/* Hot Topics */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <Flame size={16} className="text-[#F59E0B]" />
              <h3 className="text-sm font-semibold text-[#1F2937]">热门话题</h3>
            </div>
            <div className="space-y-2">
              {hotTopics.map((topic) => (
                <div
                  key={topic.rank}
                  className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 transition hover:bg-[#F3F4F6]"
                >
                  <span
                    className={cn(
                      'flex h-5 w-5 shrink-0 items-center justify-center rounded text-[11px] font-bold',
                      topic.rank <= 3 ? 'bg-[#FEF3C7] text-[#D97706]' : 'bg-[#F3F4F6] text-[#6B7280]'
                    )}
                  >
                    {topic.rank}
                  </span>
                  <span className="min-w-0 flex-1 truncate text-sm text-[#374151]">{topic.name}</span>
                  <span className="shrink-0 text-xs text-[#6B7280]">{topic.heat}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Active Users */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <Users size={16} className="text-[#1A56DB]" />
              <h3 className="text-sm font-semibold text-[#1F2937]">活跃用户</h3>
            </div>
            <div className="space-y-2">
              {activeUsers.map((user, idx) => (
                <div
                  key={idx}
                  className="flex cursor-pointer items-center gap-2 rounded-md px-2 py-1.5 transition hover:bg-[#F3F4F6]"
                >
                  <Avatar name={user.name} color={user.avatarColor} />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1">
                      <span className="truncate text-sm text-[#374151]">{user.name}</span>
                      {user.medal > 0 && <MedalIcon rank={user.medal} />}
                    </div>
                    <div className="truncate text-xs text-[#6B7280]">{user.unit}</div>
                  </div>
                  <span className="shrink-0 text-xs text-[#6B7280]">{user.posts}帖</span>
                </div>
              ))}
            </div>
          </div>

          {/* My Stats */}
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
            <div className="mb-3 flex items-center gap-2">
              <User size={16} className="text-[#3B82F6]" />
              <h3 className="text-sm font-semibold text-[#1F2937]">我的帖子</h3>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-md bg-[#F9FAFB] p-2 text-center">
                <div className="text-lg font-bold text-[#1A56DB]">12</div>
                <div className="text-xs text-[#6B7280]">发帖</div>
              </div>
              <div className="rounded-md bg-[#F9FAFB] p-2 text-center">
                <div className="text-lg font-bold text-[#1A56DB]">345</div>
                <div className="text-xs text-[#6B7280]">获赞</div>
              </div>
              <div className="rounded-md bg-[#F9FAFB] p-2 text-center">
                <div className="text-lg font-bold text-[#1A56DB]">89</div>
                <div className="text-xs text-[#6B7280]">收藏</div>
              </div>
              <div className="rounded-md bg-[#F9FAFB] p-2 text-center">
                <div className="text-lg font-bold text-[#1A56DB]">156</div>
                <div className="text-xs text-[#6B7280]">评论</div>
              </div>
            </div>
            <button className="mt-3 w-full text-center text-xs text-[#1A56DB] transition hover:underline">
              查看我的帖子
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
