import { useState, useMemo } from 'react'
import {
  Search, BarChart3, TrendingUp, ChevronRight, ChevronDown,
  Lightbulb, Info, X, Filter, Star, Award, XCircle, Target,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─── Types ─── */
interface PriceRecord {
  id: string
  date: string
  supplierId: string
  supplierName: string
  supplierRating: number
  equipId: string
  equipName: string
  spec: string
  category: string
  tags: string[]
  unitPrice: number
  quantity: number
  totalPrice: number
  orderNo: string
  unit: string
  ownerUnit: string
  isCurrentUnit: boolean
  deliveryDays: number
}

/* ─── Mock Data ─── */
const TAG_CATEGORIES = [
  { name: '现场检测类', tags: ['电子', '高精度', '便携', '光源', 'LED'] },
  { name: '勘查提取类', tags: ['勘查', '光源', 'LED', '化学'] },
  { name: '防护装备类', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖', '四级防弹', '手持式', '钢制', '观察窗', '二级防弹', '导轨式', '含面罩'] },
  { name: '通用属性', tags: ['RFID', '智能', '物证管理'] },
]

const RECENT_TAGS = ['三级防弹', '软质', '凯夫拉', '全覆盖', '防水']

const HOT_EQUIPMENTS = [
  { name: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建' },
  { name: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖' },
  { name: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg' },
  { name: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg' },
  { name: '现场制卷软件及输出设备', spec: 'A3/激光/彩色' },
  { name: '多波段光源', spec: '多波段' },
  { name: '案件现场计算机绘图系统', spec: '绘图/测量' },
]

const priceRecords: PriceRecord[] = [
  // 现场测记录
  { id: 'r001', date: '2025-01-15', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 28000, quantity: 5, totalPrice: 140000, orderNo: 'HT-2026-001', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 15 },
  { id: 'r002', date: '2025-03-20', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 26500, quantity: 8, totalPrice: 212000, orderNo: 'HT-2026-002', unit: '套', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 12 },
  { id: 'r003', date: '2025-07-08', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 27000, quantity: 3, totalPrice: 81000, orderNo: 'HT-2026-003', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r004', date: '2025-10-15', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 25800, quantity: 6, totalPrice: 154800, orderNo: 'HT-2026-004', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  { id: 'r005', date: '2026-02-10', supplierId: '1', supplierName: '某安防科技有限公司', supplierRating: 4.5, equipId: 'e2101001', equipName: '现场测记录、信息录入及三维重建综合系统', spec: '记录/录入/三维重建', category: '现场检测', tags: ['电子', '高精度', '便携'], unitPrice: 26200, quantity: 4, totalPrice: 104800, orderNo: 'HT-2026-005', unit: '套', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  // 多波段光源
  { id: 'r006', date: '2025-05-10', supplierId: '2', supplierName: '某警用装备有限公司', supplierRating: 4.0, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 14500, quantity: 15, totalPrice: 217500, orderNo: 'HT-2026-006', unit: '台', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 20 },
  { id: 'r007', date: '2025-09-01', supplierId: '2', supplierName: '某警用装备有限公司', supplierRating: 4.0, equipId: 'e2102006', equipName: '多波段光源', spec: '多波段', category: '辅助观测', tags: [], unitPrice: 13800, quantity: 10, totalPrice: 138000, orderNo: 'HT-2026-007', unit: '台', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 18 },
  // 防弹衣
  { id: 'r023', date: '2025-01-20', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3200, quantity: 100, totalPrice: 320000, orderNo: 'HT-2026-023', unit: '件', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 15 },
  { id: 'r024', date: '2025-04-18', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 3100, quantity: 80, totalPrice: 248000, orderNo: 'HT-2026-024', unit: '件', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 12 },
  { id: 'r026', date: '2025-11-05', supplierId: '8', supplierName: 'DD警用防护装备厂', supplierRating: 4.4, equipId: 'e3001001', equipName: '防弹衣 FDY-3R-S', spec: '三级/软质/凯夫拉/全覆盖', category: '防护装备', tags: ['三级防弹', '软质', '凯夫拉', '全覆盖'], unitPrice: 2800, quantity: 60, totalPrice: 168000, orderNo: 'HT-2026-026', unit: '件', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 20 },
  // 防弹头盔
  { id: 'r101', date: '2025-02-10', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101001', equipName: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg', category: '防弹头盔', tags: ['三级防弹', '凯夫拉', '轻型'], unitPrice: 1850, quantity: 50, totalPrice: 92500, orderNo: 'HT-2026-101', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r102', date: '2025-06-18', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101001', equipName: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg', category: '防弹头盔', tags: ['三级防弹', '凯夫拉', '轻型'], unitPrice: 1800, quantity: 80, totalPrice: 144000, orderNo: 'HT-2026-102', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  { id: 'r103', date: '2025-09-22', supplierId: '9', supplierName: 'EE防护科技集团', supplierRating: 4.2, equipId: 'e5101001', equipName: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg', category: '防弹头盔', tags: ['三级防弹', '凯夫拉', '轻型'], unitPrice: 1680, quantity: 40, totalPrice: 67200, orderNo: 'HT-2026-103', unit: '顶', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 15 },
  { id: 'r104', date: '2026-01-08', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101001', equipName: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg', category: '防弹头盔', tags: ['三级防弹', '凯夫拉', '轻型'], unitPrice: 1750, quantity: 60, totalPrice: 105000, orderNo: 'HT-2026-104', unit: '顶', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
  { id: 'r105', date: '2026-04-15', supplierId: '9', supplierName: 'EE防护科技集团', supplierRating: 4.2, equipId: 'e5101001', equipName: '防弹头盔 FDT-01', spec: '三级/凯夫拉/1.2kg', category: '防弹头盔', tags: ['三级防弹', '凯夫拉', '轻型'], unitPrice: 1620, quantity: 30, totalPrice: 48600, orderNo: 'HT-2026-105', unit: '顶', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 18 },
  // 防弹盾牌
  { id: 'r201', date: '2025-03-12', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101002', equipName: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg', category: '防弹盾牌', tags: ['三级防弹', '手持式', '透明'], unitPrice: 7200, quantity: 20, totalPrice: 144000, orderNo: 'HT-2026-201', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 12 },
  { id: 'r202', date: '2025-07-25', supplierId: '10', supplierName: 'FF警用装备厂', supplierRating: 4.5, equipId: 'e5101002', equipName: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg', category: '防弹盾牌', tags: ['三级防弹', '手持式', '透明'], unitPrice: 6800, quantity: 15, totalPrice: 102000, orderNo: 'HT-2026-202', unit: '面', ownerUnit: 'YYY市公安局', isCurrentUnit: false, deliveryDays: 14 },
  { id: 'r203', date: '2025-12-10', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101002', equipName: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg', category: '防弹盾牌', tags: ['三级防弹', '手持式', '透明'], unitPrice: 7000, quantity: 25, totalPrice: 175000, orderNo: 'HT-2026-203', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 8 },
  { id: 'r204', date: '2026-03-05', supplierId: '10', supplierName: 'FF警用装备厂', supplierRating: 4.5, equipId: 'e5101002', equipName: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg', category: '防弹盾牌', tags: ['三级防弹', '手持式', '透明'], unitPrice: 6500, quantity: 10, totalPrice: 65000, orderNo: 'HT-2026-204', unit: '面', ownerUnit: 'ZZZ市交警支队', isCurrentUnit: false, deliveryDays: 20 },
  { id: 'r205', date: '2026-05-20', supplierId: '7', supplierName: 'AA防弹材料有限公司', supplierRating: 4.7, equipId: 'e5101002', equipName: '防弹盾牌 FDP-01', spec: '三级/手持式/5kg', category: '防弹盾牌', tags: ['三级防弹', '手持式', '透明'], unitPrice: 6900, quantity: 18, totalPrice: 124200, orderNo: 'HT-2026-205', unit: '面', ownerUnit: 'XXX省公安厅', isCurrentUnit: true, deliveryDays: 10 },
]

/* ─── Quick date presets ─── */
function getDatePreset(months: number): [string, string] {
  const end = new Date(); const start = new Date(); start.setMonth(start.getMonth() - months)
  return [start.toISOString().slice(0, 10), end.toISOString().slice(0, 10)]
}

const DATE_PRESETS = [
  { label: '近3个月', value: 3 },
  { label: '近6个月', value: 6 },
  { label: '近1年', value: 12 },
  { label: '近2年', value: 24 },
]

const FIELDS = ['保质期剩余', '装备名称', '装备类别', '规格型号', '生产厂家', '单价', '库存数量', '入库时间']
const OPERATORS = ['小于等于', '等于', '不等于', '包含', '不包含', '大于', '介于']

/* ═══════════════════════════════════════════════════
   供应商档案弹窗
   ═══════════════════════════════════════════════════ */
function SupplierModal({ supplierId, supplierName, onClose }: { supplierId: string; supplierName: string; onClose: () => void }) {
  const supplierData: Record<string, { rating: number; contact: string; phone: string; address: string; products: number; orders: number; totalAmount: number; cooperation: string; qualification: string[] }> = {
    '1': { rating: 4.5, contact: '张经理', phone: '138-0013-8001', address: '北京市海淀区中关村科技园8号楼', products: 35, orders: 128, totalAmount: 2860000, cooperation: '3年', qualification: ['ISO9001', '国军标认证', 'AAA信用企业'] },
    '2': { rating: 4.0, contact: '李经理', phone: '139-0023-9002', address: '上海市浦东新区张江高科技园区', products: 22, orders: 86, totalAmount: 1520000, cooperation: '2年', qualification: ['ISO9001', '高新技术企业'] },
    '7': { rating: 4.7, contact: '王总监', phone: '137-0073-7007', address: '广东省深圳市南山区科技园', products: 48, orders: 256, totalAmount: 8900000, cooperation: '5年', qualification: ['ISO9001', '国军标认证', 'AAA信用企业', '专精特新'] },
    '8': { rating: 4.4, contact: '赵经理', phone: '136-0083-6008', address: '浙江省杭州市余杭区未来科技城', products: 18, orders: 64, totalAmount: 980000, cooperation: '2年', qualification: ['ISO9001', 'AAA信用企业'] },
    '9': { rating: 4.2, contact: '陈经理', phone: '135-0093-5009', address: '江苏省南京市江宁区开发区', products: 25, orders: 92, totalAmount: 1680000, cooperation: '3年', qualification: ['ISO9001', '高新技术企业'] },
    '10': { rating: 4.5, contact: '刘总监', phone: '133-0103-3010', address: '湖北省武汉市东湖高新区', products: 30, orders: 112, totalAmount: 2150000, cooperation: '4年', qualification: ['ISO9001', '国军标认证'] },
  }
  const s = supplierData[supplierId] || { rating: 4.0, contact: '-', phone: '-', address: '-', products: 0, orders: 0, totalAmount: 0, cooperation: '-', qualification: [] }

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[560px] max-w-[95vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h3 className="text-lg font-semibold text-[#1F2937]">供应商档案</h3>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="p-6 space-y-5">
          <div className="flex items-center gap-3">
            <div className="flex h-14 w-14 items-center justify-center rounded-full bg-[#E8F0FE]">
              <Award size={24} className="text-[#1A56DB]" />
            </div>
            <div>
              <div className="text-base font-semibold text-[#1F2937]">{supplierName}</div>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex items-center gap-0.5">
                  {[1, 2, 3, 4, 5].map(i => <Star key={i} size={14} className={i <= Math.round(s.rating) ? 'text-[#F59E0B] fill-[#F59E0B]' : 'text-[#D1D5DB]'} />)}
                </div>
                <span className="text-sm font-medium text-[#F59E0B]">{s.rating}</span>
                <span className="text-xs text-[#9CA3AF]">综合评分</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div><label className="text-xs text-[#6B7280]">联系人</label><div className="text-sm text-[#374151] mt-0.5">{s.contact}</div></div>
            <div><label className="text-xs text-[#6B7280]">联系电话</label><div className="text-sm text-[#374151] mt-0.5">{s.phone}</div></div>
            <div className="col-span-2"><label className="text-xs text-[#6B7280]">地址</label><div className="text-sm text-[#374151] mt-0.5">{s.address}</div></div>
            <div><label className="text-xs text-[#6B7280]">供应产品数</label><div className="text-sm text-[#374151] mt-0.5">{s.products} 种</div></div>
            <div><label className="text-xs text-[#6B7280]">历史订单数</label><div className="text-sm text-[#374151] mt-0.5">{s.orders} 笔</div></div>
            <div><label className="text-xs text-[#6B7280]">合作金额</label><div className="text-sm text-[#374151] mt-0.5">¥{(s.totalAmount / 10000).toFixed(1)} 万</div></div>
            <div><label className="text-xs text-[#6B7280]">合作年限</label><div className="text-sm text-[#374151] mt-0.5">{s.cooperation}</div></div>
          </div>

          <div>
            <label className="text-xs text-[#6B7280]">资质认证</label>
            <div className="mt-1.5 flex flex-wrap gap-1.5">
              {s.qualification.map(q => (
                <span key={q} className="rounded-full bg-[#ECFDF5] px-2.5 py-0.5 text-xs text-[#059669]">{q}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════════════
   历史采购价格散点图
   ═══════════════════════════════════════════════════ */
function ScatterChart({ data }: { data: { date: string; price: number; supplier: string; isCurrent: boolean; supplierId: string }[] }) {
  if (data.length === 0) return null
  const prices = data.map(d => d.price)
  const minPrice = Math.min(...prices); const maxPrice = Math.max(...prices)
  const padding = (maxPrice - minPrice) * 0.1 || 1
  const yMin = Math.floor((minPrice - padding) / 100) * 100
  const yMax = Math.ceil((maxPrice + padding) / 100) * 100
  const yRange = yMax - yMin || 1

  const width = 600; const height = 220
  const pLeft = 70; const pTop = 20; const pBottom = 40
  const chartW = width - pLeft - 20; const chartH = height - pTop - pBottom

  // Y axis labels
  const yLabels = Array.from({ length: 5 }, (_, i) => {
    const val = yMin + (yRange / 4) * i
    return { val: Math.round(val), y: pTop + chartH - (i / 4) * chartH }
  })

  // X axis labels (date)
  const xCount = Math.min(data.length, 8)
  const step = Math.max(1, Math.floor(data.length / xCount))
  const xLabels = data.filter((_, i) => i % step === 0 || i === data.length - 1).map((d, _, arr) => {
    const idx = data.indexOf(d)
    return { label: d.date.slice(5), x: pLeft + (idx / (data.length - 1)) * chartW, isCurrent: d.isCurrent }
  })

  return (
    <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ maxHeight: 240 }}>
      {yLabels.map((l, i) => (
        <g key={i}>
          <line x1={pLeft} y1={l.y} x2={width - 20} y2={l.y} stroke="#F3F4F6" strokeWidth={1} />
          <text x={pLeft - 10} y={l.y + 4} textAnchor="end" fontSize={10} fill="#9CA3AF">¥{l.val.toLocaleString()}</text>
        </g>
      ))}
      {xLabels.map((l, i) => (
        <text key={i} x={l.x} y={height - 10} textAnchor="middle" fontSize={10} fill={l.isCurrent ? "#1A56DB" : "#9CA3AF"}>{l.label}</text>
      ))}
      {/* Data points as scatter */}
      {data.map((d, i) => {
        const x = pLeft + (i / (data.length - 1)) * chartW
        const y = pTop + chartH - ((d.price - yMin) / yRange) * chartH
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={5} fill={d.isCurrent ? "#1A56DB" : "#9CA3AF"} opacity={0.8} />
            <circle cx={x} cy={y} r={2} fill="white" />
          </g>
        )
      })}
      {/* Legend */}
      <text x={pLeft} y={14} fontSize={10} fill="#1A56DB"><tspan fill="#1A56DB">●</tspan> 本单位</text>
      <text x={pLeft + 70} y={14} fontSize={10} fill="#9CA3AF"><tspan fill="#9CA3AF">●</tspan> 其他单位</text>
    </svg>
  )
}

/* ═══════════════════════════════════════════════════
   综合评分雷达图
   ═══════════════════════════════════════════════════ */
function RadarChart({ suppliers }: { suppliers: { name: string; score: number[]; color: string }[] }) {
  const labels = ['价格优势', '交付及时', '产品质量', '售后服务', '合作年限']
  const size = 200
  const cx = size / 2; const cy = size / 2
  const radius = 75
  const levels = 5

  // Pentagon points
  const angle = (i: number) => (Math.PI * 2 * i) / 5 - Math.PI / 2
  const point = (i: number, r: number) => ({ x: cx + r * Math.cos(angle(i)), y: cy + r * Math.sin(angle(i)) })

  return (
    <svg viewBox={`0 0 ${size} ${size + 20}`} className="w-full" style={{ maxHeight: 220 }}>
      {/* Grid */}
      {Array.from({ length: levels }, (_, l) => {
        const r = (radius / levels) * (l + 1)
        const pts = Array.from({ length: 5 }, (_, i) => point(i, r))
        return <polygon key={l} points={pts.map(p => `${p.x},${p.y}`).join(' ')} fill="none" stroke="#E5E7EB" strokeWidth={0.5} />
      })}
      {/* Axes */}
      {Array.from({ length: 5 }, (_, i) => {
        const p = point(i, radius)
        return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke="#E5E7EB" strokeWidth={0.5} />
      })}
      {/* Labels */}
      {labels.map((label, i) => {
        const p = point(i, radius + 18)
        return <text key={i} x={p.x} y={p.y + 4} textAnchor="middle" fontSize={9} fill="#6B7280">{label}</text>
      })}
      {/* Data */}
      {suppliers.map((s, si) => {
        const pts = s.score.map((v, i) => point(i, (v / 5) * radius))
        return (
          <g key={si}>
            <polygon points={pts.map(p => `${p.x},${p.y}`).join(' ')} fill={s.color} fillOpacity={0.15} stroke={s.color} strokeWidth={1.5} />
            {pts.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={2.5} fill={s.color} />)}
          </g>
        )
      })}
      {/* Legend */}
      {suppliers.map((s, i) => (
        <g key={i} transform={`translate(${10}, ${size + 8 + i * 12})`}>
          <rect x={0} y={-4} width={8} height={8} rx={2} fill={s.color} />
          <text x={14} y={3} fontSize={9} fill="#374151">{s.name}</text>
        </g>
      ))}
    </svg>
  )
}

/* ═══════════════════════════════════════════════════
   Main Page
   ═══════════════════════════════════════════════════ */
export default function PriceComparisonPage() {
  const [equipNameKeyword, setEquipNameKeyword] = useState('')
  const [specKeyword, setSpecKeyword] = useState('')
  const [selectedTags, setSelectedTags] = useState<string[]>([])
  const [tagMatchMode, setTagMatchMode] = useState<'and' | 'or'>('and')
  const [dateRange, setDateRange] = useState<[string, string]>(['', ''])
  const [activeDatePreset, setActiveDatePreset] = useState<number | null>(null)
  const [unitFilter, setUnitFilter] = useState<'all' | 'current' | 'other'>('all')
  const [expandedCategories, setExpandedCategories] = useState<Set<string>>(new Set())
  const [currentPage, setCurrentPage] = useState(1)
  const [showSupplier, setShowSupplier] = useState<string | null>(null)
  const [showSupplierName, setShowSupplierName] = useState('')
  const pageSize = 10

  const hasFilters = equipNameKeyword || specKeyword || selectedTags.length > 0 || dateRange[0] || dateRange[1] || unitFilter !== 'all'

  const handleDatePreset = (months: number) => { setActiveDatePreset(months); setDateRange(getDatePreset(months)) }

  // NEW: 精确匹配 - 装备名称 + 规格型号
  const filteredRecords = useMemo(() => {
    let result = [...priceRecords]
    // 精确匹配：名称 + 规格型号
    if (equipNameKeyword.trim()) {
      const kw = equipNameKeyword.toLowerCase()
      result = result.filter(r =>
        r.equipName.toLowerCase().includes(kw) || r.spec.toLowerCase().includes(kw)
      )
    }
    if (specKeyword.trim()) {
      const kw = specKeyword.toLowerCase()
      result = result.filter(r => r.spec.toLowerCase().includes(kw))
    }
    if (selectedTags.length > 0) {
      result = result.filter(r => tagMatchMode === 'or'
        ? selectedTags.some(tag => r.tags.includes(tag))
        : selectedTags.every(tag => r.tags.includes(tag))
      )
    }
    if (dateRange[0]) result = result.filter(r => r.date >= dateRange[0])
    if (dateRange[1]) result = result.filter(r => r.date <= dateRange[1])
    if (unitFilter === 'current') result = result.filter(r => r.isCurrentUnit)
    if (unitFilter === 'other') result = result.filter(r => !r.isCurrentUnit)
    return result
  }, [equipNameKeyword, specKeyword, selectedTags, tagMatchMode, dateRange, unitFilter])

  const pagedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize
    return filteredRecords.slice(start, start + pageSize)
  }, [filteredRecords, currentPage])
  const totalPages = Math.ceil(filteredRecords.length / pageSize)

  // Stats - NEW文案
  const stats = useMemo(() => {
    if (filteredRecords.length === 0) return null
    const prices = filteredRecords.map(r => r.unitPrice)
    const uniqueSuppliers = new Set(filteredRecords.map(r => r.supplierId)).size
    const currentRecords = filteredRecords.filter(r => r.isCurrentUnit)
    const otherRecords = filteredRecords.filter(r => !r.isCurrentUnit)
    return {
      recordCount: filteredRecords.length,
      supplierCount: uniqueSuppliers,
      currentCount: currentRecords.length,
      otherCount: otherRecords.length,
      minPrice: Math.min(...prices),
      maxPrice: Math.max(...prices),
    }
  }, [filteredRecords])

  // Scatter data
  const scatterData = useMemo(() => {
    if (!stats) return []
    return [...filteredRecords].sort((a, b) => a.date.localeCompare(b.date)).map(r => ({
      date: r.date, price: r.unitPrice, supplier: r.supplierName, isCurrent: r.isCurrentUnit, supplierId: r.supplierId
    }))
  }, [filteredRecords, stats])

  // Radar data: per supplier avg scores
  const radarSuppliers = useMemo(() => {
    const sMap: Record<string, { name: string; records: PriceRecord[]; color: string }> = {}
    filteredRecords.forEach(r => {
      if (!sMap[r.supplierId]) sMap[r.supplierId] = { name: r.supplierName, records: [], color: '' }
      sMap[r.supplierId].records.push(r)
    })
    const colors = ['#1A56DB', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6']
    return Object.entries(sMap).slice(0, 3).map(([id, s], i) => {
      const prices = s.records.map(r => r.unitPrice)
      const avgPrice = prices.reduce((a, b) => a + b, 0) / prices.length
      const allPrices = filteredRecords.map(r => r.unitPrice)
      const avgAll = allPrices.reduce((a, b) => a + b, 0) / allPrices.length
      const priceScore = Math.min(5, Math.max(1, 5 - (avgPrice / avgAll - 1) * 3)) // lower price = higher score
      const deliveryScore = Math.min(5, Math.max(1, 5 - (s.records.reduce((a, r) => a + r.deliveryDays, 0) / s.records.length) / 5))
      const ratingScore = s.records[0].supplierRating
      const serviceScore = Math.min(5, ratingScore + 0.3)
      const years = Math.min(5, s.records.length * 0.8 + 1)
      return {
        name: s.name.length > 8 ? s.name.slice(0, 8) + '...' : s.name,
        score: [Math.round(priceScore * 10) / 10, Math.round(deliveryScore * 10) / 10, Math.round(ratingScore * 10) / 10, Math.round(serviceScore * 10) / 10, Math.round(years * 10) / 10],
        color: colors[i % colors.length],
      }
    })
  }, [filteredRecords])

  // Insights
  const insights = useMemo(() => {
    if (!stats || filteredRecords.length === 0) return []
    const items: { type: 'success' | 'warning' | 'info'; title: string; desc: string }[] = []
    const prices = filteredRecords.map(r => r.unitPrice)
    const minP = Math.min(...prices); const maxP = Math.max(...prices)
    const minRecord = filteredRecords.find(r => r.unitPrice === minP)
    const maxRecord = filteredRecords.find(r => r.unitPrice === maxP)
    if (stats.otherCount === 0) items.push({ type: 'info', title: '跨单位价格对比', desc: '暂无其他单位数据，无法进行跨单位价格对比' })
    if (minRecord) items.push({ type: 'success', title: '最低单价推荐', desc: `最低单价为 ${minRecord.supplierName} 的 ¥${minP.toLocaleString()}/件（${minRecord.date}），建议参考该价格谈判` })
    if (maxRecord && maxP > minP) items.push({ type: 'warning', title: '最高单价提醒', desc: `最高单价为 ${maxRecord.supplierName} 的 ¥${maxP.toLocaleString()}/件（${maxRecord.date}），较最低价高出 ¥${(maxP - minP).toLocaleString()}/件` })
    const supplierCounts: Record<string, number> = {}; filteredRecords.forEach(r => { supplierCounts[r.supplierName] = (supplierCounts[r.supplierName] || 0) + 1 })
    const topSupplier = Object.entries(supplierCounts).sort((a, b) => b[1] - a[1])[0]
    if (topSupplier) { const pct = Math.round((topSupplier[1] / filteredRecords.length) * 100); items.push({ type: 'info', title: '供应商集中度', desc: `${topSupplier[0]} 占比 ${pct}%（${topSupplier[1]}/${filteredRecords.length}条）` }) }
    return items
  }, [filteredRecords, stats])

  const resetFilters = () => { setEquipNameKeyword(''); setSpecKeyword(''); setSelectedTags([]); setTagMatchMode('and'); setDateRange(['', '']); setActiveDatePreset(null); setUnitFilter('all'); setCurrentPage(1) }

  return (
    <div className="flex gap-4" style={{ minHeight: 'calc(100dvh - 160px)' }}>
      {/* ─── Left: Filter Panel ─── */}
      <div className="w-64 shrink-0 space-y-4">
        <div className="flex items-center gap-1 text-xs text-[#6B7280]">
          <span>首页</span><ChevronRight size={12} /><span>基础信息管理 / 历史比价</span>
        </div>
        <div className="flex items-center gap-2 text-sm font-semibold text-[#374151]">
          <BarChart3 size={16} className="text-[#1A56DB]" />筛选条件
        </div>

        {/* Equipment Name */}
        <div>
          <label className="mb-1.5 block text-xs font-medium text-[#374151]">装备名称</label>
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input value={equipNameKeyword} onChange={e => { setEquipNameKeyword(e.target.value); setCurrentPage(1) }} placeholder="输入装备名称关键词..." className="h-8 w-full rounded-md border border-[#D1D5DB] pl-8 pr-3 text-xs outline-none focus:border-[#1A56DB]" />
          </div>
        </div>

        {/* Spec Model */}
        <div>
          <label className="mb-1.5 block text-xs font-medium text-[#374151]">规格型号</label>
          <div className="relative">
            <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input value={specKeyword} onChange={e => { setSpecKeyword(e.target.value); setCurrentPage(1) }} placeholder="输入规格型号..." className="h-8 w-full rounded-md border border-[#D1D5DB] pl-8 pr-3 text-xs outline-none focus:border-[#1A56DB]" />
          </div>
        </div>

        {/* Tags - AND/OR on right of label */}
        <div>
          <div className="mb-1.5 flex items-center gap-2">
            <label className="text-xs font-medium text-[#374151]">标签 <span className="text-[#9CA3AF] font-normal">(多选)</span></label>
            <span className="ml-auto flex items-center gap-1">
              <span className={cn('text-[10px]', tagMatchMode === 'and' ? 'text-[#1A56DB] font-medium' : 'text-[#9CA3AF]')}>AND</span>
              <button onClick={() => setTagMatchMode(tagMatchMode === 'and' ? 'or' : 'and')} className={cn('relative h-4 w-7 rounded-full transition', tagMatchMode === 'and' ? 'bg-[#1A56DB]' : 'bg-[#D1D5DB]')}>
                <span className={cn('absolute top-0.5 h-3 w-3 rounded-full bg-white shadow transition-transform', tagMatchMode === 'and' ? 'left-0.5' : 'left-[14px]')} />
              </button>
              <span className={cn('text-[10px]', tagMatchMode === 'or' ? 'text-[#1A56DB] font-medium' : 'text-[#9CA3AF]')}>OR</span>
            </span>
          </div>
          <div className="relative mb-2">
            <Search size={12} className="absolute left-2 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input placeholder="搜索标签..." className="h-8 w-full rounded-md border border-[#D1D5DB] pl-7 pr-3 text-xs outline-none focus:border-[#1A56DB]" />
          </div>
          <div className="mb-2">
            <div className="mb-1 flex items-center gap-1 text-[10px] text-[#9CA3AF]"><Info size={10} />最近使用</div>
            <div className="flex flex-wrap gap-1">
              {RECENT_TAGS.map(tag => (
                <button key={tag} onClick={() => { setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]); setCurrentPage(1) }} className={cn('rounded px-1.5 py-0.5 text-[10px] transition', selectedTags.includes(tag) ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]')}>{tag}</button>
              ))}
            </div>
          </div>
          <div className="space-y-0.5">
            {TAG_CATEGORIES.map(cat => (
              <div key={cat.name}>
                <button onClick={() => { const n = new Set(expandedCategories); n.has(cat.name) ? n.delete(cat.name) : n.add(cat.name); setExpandedCategories(n) }} className="flex w-full items-center gap-1 py-1 text-xs text-[#374151] hover:text-[#1A56DB]">
                  {expandedCategories.has(cat.name) ? <ChevronDown size={12} /> : <ChevronRight size={12} />}{cat.name}
                </button>
                {expandedCategories.has(cat.name) && (
                  <div className="flex flex-wrap gap-1 pl-4">
                    {cat.tags.map(tag => (
                      <button key={tag} onClick={() => { setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]); setCurrentPage(1) }} className={cn('rounded px-1.5 py-0.5 text-[10px] transition', selectedTags.includes(tag) ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]')}>{tag}</button>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Time Range */}
        <div>
          <label className="mb-1.5 block text-xs font-medium text-[#374151]">时间范围</label>
          <div className="mb-2 flex flex-wrap gap-1">
            {DATE_PRESETS.map(p => (
              <button key={p.value} onClick={() => handleDatePreset(p.value)} className={cn('rounded px-2 py-0.5 text-[10px] transition', activeDatePreset === p.value ? 'bg-[#1A56DB] text-white' : 'border border-[#D1D5DB] text-[#374151] hover:bg-[#F3F4F6]')}>{p.label}</button>
            ))}
          </div>
          <div className="flex items-center gap-1">
            <input type="date" value={dateRange[0]} onChange={e => { setActiveDatePreset(null); setDateRange([e.target.value, dateRange[1]]) }} className="h-7 flex-1 rounded border border-[#D1D5DB] px-1.5 text-[10px] outline-none" />
            <span className="text-[10px] text-[#9CA3AF]">至</span>
            <input type="date" value={dateRange[1]} onChange={e => { setActiveDatePreset(null); setDateRange([dateRange[0], e.target.value]) }} className="h-7 flex-1 rounded border border-[#D1D5DB] px-1.5 text-[10px] outline-none" />
          </div>
        </div>

        {/* Unit Filter */}
        <div>
          <label className="mb-1.5 block text-xs font-medium text-[#374151]">所属单位</label>
          <div className="space-y-1.5">
            {[
              { v: 'all', label: '全部单位' },
              { v: 'current', label: '本单位（XXX省公安厅）' },
              { v: 'other', label: '其他单位' },
            ].map(o => (
              <label key={o.v} className="flex cursor-pointer items-center gap-2">
                <input type="radio" name="unit" checked={unitFilter === o.v} onChange={() => { setUnitFilter(o.v as any); setCurrentPage(1) }} className="h-3.5 w-3.5 text-[#1A56DB]" />
                <span className="text-xs text-[#374151]">{o.label}</span>
              </label>
            ))}
          </div>
        </div>

        <button onClick={resetFilters} className="w-full rounded-md border border-[#D1D5DB] py-1.5 text-xs text-[#6B7280] hover:bg-[#F3F4F6] transition">重置筛选</button>
      </div>

      {/* ─── Right: Results ─── */}
      <div className="min-w-0 flex-1">
        {/* Empty State */}
        {!hasFilters && (
          <div className="flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-[#E5E7EB] py-20">
            <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-[#F3F4F6]"><Filter size={28} className="text-[#D1D5DB]" /></div>
            <h3 className="mb-2 text-base font-medium text-[#374151]">请输入筛选条件</h3>
            <p className="mb-6 text-xs text-[#9CA3AF]">在左侧输入装备名称、规格型号或选择标签进行比价</p>
            <div className="flex flex-wrap justify-center gap-2">
              {HOT_EQUIPMENTS.map(eq => (
                <button key={eq.name} onClick={() => { setEquipNameKeyword(eq.name); setSpecKeyword(eq.spec); setCurrentPage(1) }} className="rounded-full border border-[#E5E7EB] bg-white px-3 py-1 text-xs text-[#374151] transition hover:border-[#1A56DB] hover:text-[#1A56DB]">{eq.name.length > 15 ? eq.name.slice(0, 15) + '...' : eq.name}</button>
              ))}
            </div>
          </div>
        )}

        {/* Results */}
        {hasFilters && stats && (
          <div className="space-y-4">
            {/* Overview - NEW文案 */}
            <div>
              <div className="mb-3 text-sm text-[#374151]">
                该装备在库内共有 <span className="font-semibold text-[#1A56DB]">{stats.recordCount}</span> 条历史订单，涉及 <span className="font-semibold text-[#1A56DB]">{stats.supplierCount}</span> 家供应商
              </div>
              <div className="grid grid-cols-5 gap-3">
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-3 text-center">
                  <div className="text-xs text-[#6B7280]">历史订单</div>
                  <div className="text-lg font-semibold text-[#1A56DB]">{stats.recordCount}<span className="text-xs font-normal">条</span></div>
                </div>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-3 text-center">
                  <div className="text-xs text-[#6B7280]">本单位</div>
                  <div className="text-lg font-semibold text-[#10B981]">{stats.currentCount}<span className="text-xs font-normal">条</span></div>
                </div>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-3 text-center">
                  <div className="text-xs text-[#6B7280]">其他单位</div>
                  <div className="text-lg font-semibold text-[#F59E0B]">{stats.otherCount}<span className="text-xs font-normal">条</span></div>
                </div>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-3 text-center">
                  <div className="text-xs text-[#6B7280]">供应商</div>
                  <div className="text-lg font-semibold text-[#8B5CF6]">{stats.supplierCount}<span className="text-xs font-normal">家</span></div>
                </div>
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-3 text-center">
                  <div className="text-xs text-[#6B7280]">价格区间</div>
                  <div className="text-sm font-semibold text-[#374151]">¥{stats.minPrice.toLocaleString()}~¥{stats.maxPrice.toLocaleString()}</div>
                </div>
              </div>
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-2 gap-4">
              {/* Scatter Chart */}
              {scatterData.length > 0 && (
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <Target size={14} className="text-[#1A56DB]" />
                    <span className="text-sm font-semibold text-[#374151]">历史采购价格散点图</span>
                  </div>
                  <ScatterChart data={scatterData} />
                </div>
              )}
              {/* Radar Chart */}
              {radarSuppliers.length > 1 && (
                <div className="rounded-lg border border-[#E5E7EB] bg-white p-4">
                  <div className="mb-2 flex items-center gap-2">
                    <Award size={14} className="text-[#F59E0B]" />
                    <span className="text-sm font-semibold text-[#374151]">供应商综合评分对比</span>
                  </div>
                  <div className="flex justify-center">
                    <div className="w-48">
                      <RadarChart suppliers={radarSuppliers} />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Insights */}
            {insights.length > 0 && (
              <div className="rounded-lg border border-[#E5E7EB] bg-white p-4">
                <div className="mb-3 flex items-center gap-2">
                  <Lightbulb size={14} className="text-[#F59E0B]" />
                  <span className="text-sm font-semibold text-[#374151]">智能洞察（共{insights.length}条分析）</span>
                </div>
                <div className="space-y-2">
                  {insights.map((item, i) => (
                    <div key={i} className={cn('rounded-md px-3 py-2', item.type === 'success' && 'bg-[#ECFDF5]', item.type === 'warning' && 'bg-[#FEF3C7]', item.type === 'info' && 'bg-[#F9FAFB]')}>
                      <div className={cn('mb-0.5 text-xs font-medium', item.type === 'success' && 'text-[#059669]', item.type === 'warning' && 'text-[#D97706]', item.type === 'info' && 'text-[#6B7280]')}>
                        {item.type === 'success' && '✓ '}{item.type === 'warning' && '⚠ '}{item.type === 'info' && 'ⓘ '}{item.title}
                      </div>
                      <div className={cn('text-xs', item.type === 'success' && 'text-[#059669]', item.type === 'warning' && 'text-[#B45309]', item.type === 'info' && 'text-[#6B7280]')}>{item.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* History Table */}
            <div className="rounded-lg border border-[#E5E7EB] bg-white">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
                <span className="text-sm font-medium text-[#374151]">历史供货明细</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                      {['供货日期', '供应商', '采购单位', '装备名称', '规格型号', '标签', '单价(元)', '数量', '总价(万)', '订单号'].map(h => (
                        <th key={h} className="whitespace-nowrap px-3 py-2.5 text-left text-[11px] font-semibold text-[#6B7280]">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {pagedRecords.map(r => (
                      <tr key={r.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                        <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{r.date}</td>
                        <td className="whitespace-nowrap px-3 py-2">
                          <button
                            onClick={() => { setShowSupplier(r.supplierId); setShowSupplierName(r.supplierName) }}
                            className="text-xs text-[#1A56DB] transition hover:underline hover:text-[#153E7E]"
                            title="点击查看供应商档案"
                          >
                            {r.supplierName}
                          </button>
                        </td>
                        <td className="whitespace-nowrap px-3 py-2">
                          <span className={cn('rounded px-1.5 py-0.5 text-[10px]', r.isCurrentUnit ? 'bg-[#ECFDF5] text-[#059669]' : 'bg-[#F3F4F6] text-[#6B7280]')}>
                            {r.isCurrentUnit ? 'XXX省公安厅' : r.ownerUnit}
                          </span>
                        </td>
                        <td className="whitespace-nowrap px-3 py-2 font-medium text-[#1F2937]">{r.equipName}</td>
                        <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{r.spec}</td>
                        <td className="whitespace-nowrap px-3 py-2">
                          <div className="flex flex-wrap gap-0.5">
                            {r.tags.map(t => <span key={t} className="rounded bg-[#EFF6FF] px-1 py-0.5 text-[10px] text-[#1A56DB]">{t}</span>)}
                          </div>
                        </td>
                        <td className="whitespace-nowrap px-3 py-2 text-right font-medium text-[#1A56DB]">¥{r.unitPrice.toLocaleString()}</td>
                        <td className="whitespace-nowrap px-3 py-2 text-right">{r.quantity}{r.unit}</td>
                        <td className="whitespace-nowrap px-3 py-2 text-right text-[#374151]">{(r.totalPrice / 10000).toFixed(1)}</td>
                        <td className="whitespace-nowrap px-3 py-2 font-mono text-[#6B7280]">{r.orderNo}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-1 border-t border-[#E5E7EB] px-4 py-3">
                  <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">上一页</button>
                  {Array.from({ length: totalPages }, (_, i) => <button key={i} onClick={() => setCurrentPage(i + 1)} className={cn('h-7 w-7 rounded text-xs', currentPage === i + 1 ? 'bg-[#1A56DB] text-white' : 'border border-[#D1D5DB] text-[#374151]')}>{i + 1}</button>)}
                  <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">下一页</button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Supplier Modal */}
      {showSupplier && (
        <SupplierModal supplierId={showSupplier} supplierName={showSupplierName} onClose={() => setShowSupplier(null)} />
      )}
    </div>
  )
}
