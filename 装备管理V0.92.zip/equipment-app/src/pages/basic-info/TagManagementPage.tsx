import { useState, useMemo } from 'react'
import {
  Plus, Search, ChevronRight, ChevronDown,
  Edit2, Trash2, X, Tag, Check,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─── Types ─── */
interface TagItem {
  id: string
  name: string
  color: string
  status: 'enabled' | 'disabled'
  description: string
  scope: 'global' | 'warehouse'
  parentId: string | null
  level: number
  children?: TagItem[]
}

/* ─── Mock Data ─── */
const TAG_COLORS = [
  { value: '#F59E0B', label: '橙色' },
  { value: '#EF4444', label: '红色' },
  { value: '#1A56DB', label: '蓝色' },
  { value: '#10B981', label: '绿色' },
  { value: '#8B5CF6', label: '紫色' },
  { value: '#EC4899', label: '粉色' },
  { value: '#06B6D4', label: '青色' },
  { value: '#6B7280', label: '灰色' },
]

const initialTags: TagItem[] = [
  {
    id: 't1', name: '状态类', color: '#F59E0B', status: 'enabled', description: '', scope: 'global', parentId: null, level: 0,
    children: [
      { id: 't1-1', name: '临期30天', color: '#F59E0B', status: 'enabled', description: '保质期剩余30天内的装备', scope: 'global', parentId: 't1', level: 1 },
      { id: 't1-2', name: '报废待定', color: '#EF4444', status: 'enabled', description: '待报废处理的装备', scope: 'global', parentId: 't1', level: 1 },
    ]
  },
  {
    id: 't2', name: '活动类', color: '#1A56DB', status: 'enabled', description: '', scope: 'global', parentId: null, level: 0,
    children: [
      { id: 't2-1', name: '双11备货', color: '#1A56DB', status: 'enabled', description: '双十一活动备货装备', scope: 'global', parentId: 't2', level: 1 },
    ]
  },
  {
    id: 't3', name: '品类特征', color: '#10B981', status: 'enabled', description: '', scope: 'global', parentId: null, level: 0,
    children: [
      { id: 't3-1', name: '易碎品', color: '#F59E0B', status: 'enabled', description: '易碎装备', scope: 'global', parentId: 't3', level: 1 },
      { id: 't3-2', name: '贵重仪器', color: '#8B5CF6', status: 'enabled', description: '高价值精密仪器', scope: 'global', parentId: 't3', level: 1 },
    ]
  },
]

/* ─── Helpers ─── */
function findTagById(tags: TagItem[], id: string): TagItem | null {
  for (const t of tags) {
    if (t.id === id) return t
    if (t.children) {
      const found = findTagById(t.children, id)
      if (found) return found
    }
  }
  return null
}

function findParentName(tags: TagItem[], childId: string): string {
  for (const t of tags) {
    if (t.children?.some(c => c.id === childId)) return t.name
    if (t.children) {
      const found = findParentName(t.children, childId)
      if (found) return found
    }
  }
  return '-'
}

function updateTagInTree(tags: TagItem[], id: string, data: Partial<TagItem>): TagItem[] {
  return tags.map(t => {
    if (t.id === id) return { ...t, ...data }
    if (t.children) return { ...t, children: updateTagInTree(t.children, id, data) }
    return t
  })
}

function addChildToTree(tags: TagItem[], parentId: string, child: TagItem): TagItem[] {
  return tags.map(t => {
    if (t.id === parentId) return { ...t, children: [...(t.children || []), child] }
    if (t.children) return { ...t, children: addChildToTree(t.children, parentId, child) }
    return t
  })
}

function removeTagFromTree(tags: TagItem[], id: string): TagItem[] {
  return tags.filter(t => t.id !== id).map(t => ({
    ...t,
    children: t.children ? removeTagFromTree(t.children, id) : undefined,
  }))
}

/* ─── TreeNode Component ─── */
function TreeNode({ tag, selectedId, expandedIds, onSelect, onToggle, onDelete }: {
  tag: TagItem
  selectedId: string | null
  expandedIds: Set<string>
  onSelect: (id: string) => void
  onToggle: (id: string) => void
  onDelete: (id: string) => void
}) {
  const isExpanded = expandedIds.has(tag.id)
  const hasChildren = tag.children && tag.children.length > 0
  const childCount = tag.children?.length || 0
  const isSelected = selectedId === tag.id

  return (
    <div>
      <div
        className={cn(
          'group flex cursor-pointer items-center gap-1.5 rounded-md px-2 py-1.5 transition',
          isSelected ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]'
        )}
        onClick={() => onSelect(tag.id)}
      >
        {hasChildren ? (
          <button onClick={(e) => { e.stopPropagation(); onToggle(tag.id) }} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#9CA3AF] hover:text-[#374151]">
            {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </button>
        ) : <span className="w-4 shrink-0" />}
        <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: tag.color }} />
        <span className={cn('flex-1 truncate text-sm', tag.status === 'disabled' && 'text-[#9CA3AF] line-through')}>
          {tag.name}
        </span>
        {childCount > 0 && <span className="shrink-0 text-xs text-[#9CA3AF]">({childCount})</span>}
        <button onClick={(e) => { e.stopPropagation(); onDelete(tag.id) }} className="shrink-0 rounded p-0.5 text-[#9CA3AF] opacity-0 transition hover:text-[#EF4444] group-hover:opacity-100">
          <Trash2 size={12} />
        </button>
      </div>
      {hasChildren && isExpanded && tag.children!.map(child => (
        <div key={child.id} style={{ paddingLeft: 12 }}>
          <TreeNode tag={child} selectedId={selectedId} expandedIds={expandedIds} onSelect={onSelect} onToggle={onToggle} onDelete={onDelete} />
        </div>
      ))}
    </div>
  )
}

/* ─── Main Page ─── */
export default function TagManagementPage() {
  const [tags, setTags] = useState<TagItem[]>(initialTags)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['t1', 't2', 't3']))
  const [selectedId, setSelectedId] = useState<string | null>('t1-1')
  const [searchText, setSearchText] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [editTag, setEditTag] = useState<TagItem | null>(null)
  const [formData, setFormData] = useState<Partial<TagItem>>({})
  const [parentId, setParentId] = useState<string | null>(null)

  const selectedTag = selectedId ? findTagById(tags, selectedId) : null

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  }
  const handleSelect = (id: string) => { setSelectedId(id); setShowForm(false) }
  const handleDelete = (id: string) => { if (confirm('确定删除该标签吗？')) { setTags(prev => removeTagFromTree(prev, id)); if (selectedId === id) setSelectedId(null) } }

  const openAddRoot = () => { setParentId(null); setFormData({ name: '', color: '#F59E0B', status: 'enabled', description: '', scope: 'global' }); setEditTag(null); setShowForm(true) }
  const openAddChild = () => { if (!selectedId) return; setParentId(selectedId); setFormData({ name: '', color: '#F59E0B', status: 'enabled', description: '', scope: 'global' }); setEditTag(null); setShowForm(true) }
  const openEdit = () => { if (!selectedTag) return; setEditTag(selectedTag); setFormData({ ...selectedTag }); setParentId(null); setShowForm(true) }

  const saveTag = () => {
    if (!formData.name) return
    if (editTag) { setTags(prev => updateTagInTree(prev, editTag.id, formData)) }
    else {
      const newTag: TagItem = { id: `t${Date.now()}`, name: formData.name || '', color: formData.color || '#F59E0B', status: (formData.status as 'enabled' | 'disabled') || 'enabled', description: formData.description || '', scope: (formData.scope as 'global' | 'warehouse') || 'global', parentId, level: parentId ? (findTagById(tags, parentId)?.level ?? 0) + 1 : 0 }
      if (parentId) setTags(prev => addChildToTree(prev, parentId, newTag))
      else setTags(prev => [...prev, newTag])
    }
    setShowForm(false)
  }

  return (
    <div className="flex gap-4" style={{ minHeight: 'calc(100dvh - 200px)' }}>
      {/* Left: Tag Tree */}
      <div className="w-64 shrink-0 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
          <h3 className="text-sm font-semibold text-[#1F2937]">标签树</h3>
          <button onClick={openAddRoot} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2.5 text-xs text-white transition hover:bg-[#153E7E]"><Plus size={12} /> 新建根标签</button>
        </div>
        <div className="p-3">
          <div className="relative mb-3">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input value={searchText} onChange={e => setSearchText(e.target.value)} placeholder="搜索标签..." className="h-8 w-full rounded-md border border-[#D1D5DB] pl-8 pr-3 text-xs outline-none focus:border-[#1A56DB]" />
          </div>
          <div className="space-y-0.5">
            {tags.map(tag => <TreeNode key={tag.id} tag={tag} selectedId={selectedId} expandedIds={expandedIds} onSelect={handleSelect} onToggle={toggleExpand} onDelete={handleDelete} />)}
          </div>
        </div>
      </div>

      {/* Right: Detail */}
      <div className="min-w-0 flex-1">
        {showForm ? (
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-6">
            <div className="mb-5 flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1F2937]">{editTag ? '编辑标签' : parentId ? '新增子标签' : '新建根标签'}</h3>
              <button onClick={() => setShowForm(false)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#374151]">标签名称 <span className="text-[#EF4444]">*</span></label>
                <input value={formData.name || ''} onChange={e => setFormData({ ...formData, name: e.target.value })} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" placeholder="输入标签名称" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#374151]">父标签</label>
                <input value={parentId ? findTagById(tags, parentId)?.name || '' : (editTag?.parentId ? findParentName(tags, editTag.id) : '-')} disabled className="h-8 w-full rounded-md border border-[#D1D5DB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280] outline-none" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#374151]">颜色标记</label>
                <div className="flex flex-wrap gap-2">
                  {TAG_COLORS.map(c => (
                    <button key={c.value} onClick={() => setFormData({ ...formData, color: c.value })} className={cn('flex h-7 items-center gap-1.5 rounded-full border px-2.5 text-xs transition', formData.color === c.value ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]')}><span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: c.value }} />{c.label}</button>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#374151]">状态</label>
                <select value={formData.status || 'enabled'} onChange={e => setFormData({ ...formData, status: e.target.value as 'enabled' | 'disabled' })} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"><option value="enabled">启用</option><option value="disabled">停用</option></select>
              </div>
              <div className="col-span-2">
                <label className="mb-1 block text-xs text-[#374151]">描述</label>
                <textarea value={formData.description || ''} onChange={e => setFormData({ ...formData, description: e.target.value })} rows={2} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB] resize-none" placeholder="标签描述说明..." />
              </div>
            </div>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setShowForm(false)} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] hover:bg-[#F3F4F6]">取消</button>
              <button onClick={saveTag} className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">保存</button>
            </div>
          </div>
        ) : selectedTag ? (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm text-[#6B7280]"><span>装备管理</span><ChevronRight size={14} /><span>标签管理</span><ChevronRight size={14} /><span className="font-medium text-[#374151]">{selectedTag.name}</span></div>
            <div className="rounded-lg border border-[#E5E7EB] bg-white p-5">
              <h3 className="mb-4 flex items-center gap-2 text-sm font-semibold text-[#1F2937]"><span className="h-3.5 w-1 rounded-full bg-[#F59E0B]" />基础信息</h3>
              <div className="grid grid-cols-2 gap-x-8 gap-y-4">
                <div><label className="mb-1 block text-xs text-[#6B7280]">标签名称</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{selectedTag.name}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">父标签</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{selectedTag.parentId ? findParentName(tags, selectedTag.id) : '-'}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">颜色标记</label><div className="flex h-9 items-center gap-2 rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]"><span className="h-3.5 w-3.5 rounded-full" style={{ backgroundColor: selectedTag.color }} />{TAG_COLORS.find(c => c.value === selectedTag.color)?.label || selectedTag.color}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">状态</label><div className="flex h-9 items-center"><button onClick={() => setTags(prev => updateTagInTree(prev, selectedTag.id, { status: selectedTag.status === 'enabled' ? 'disabled' : 'enabled' }))} className={cn('inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium transition', selectedTag.status === 'enabled' ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#F3F4F6] text-[#9CA3AF]')}>{selectedTag.status === 'enabled' ? '启用' : '停用'}</button></div></div>
                <div className="col-span-2"><label className="mb-1 block text-xs text-[#6B7280]">描述</label><div className="min-h-[60px] rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2 text-sm text-[#374151]">{selectedTag.description || '暂无描述'}</div></div>
              </div>
              <div className="mt-3 flex gap-2">
                <button onClick={openEdit} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#D1D5DB] px-3 text-xs text-[#374151] hover:bg-[#F3F4F6]"><Edit2 size={12} /> 编辑</button>
                <button onClick={openAddChild} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#D1D5DB] px-3 text-xs text-[#374151] hover:bg-[#F3F4F6]"><Plus size={12} /> 添加子标签</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center rounded-lg border border-[#E5E7EB] bg-white py-24 text-[#9CA3AF]">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-[#F3F4F6]"><Tag size={28} className="text-[#D1D5DB]" /></div>
            <p className="text-sm">请选择左侧标签查看详情</p>
          </div>
        )}
      </div>
    </div>
  )
}
