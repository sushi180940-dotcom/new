import { useEffect, useRef, useState } from 'react'
import {
  Plus,
  Upload,
  Download,
  Tag,
  Search,
  Edit3,
  Trash2,
  Hash,
} from 'lucide-react'
import * as echarts from 'echarts'
import { cn } from '@/lib/utils'

interface RfidCode {
  id: string
  code: string
  equipName: string
  equipModel: string
  batchNo: string
  status: '已绑定' | '未绑定' | '已注销'
  bindTime?: string
  createTime: string
}

/* ─── 32-bit encoding segments ───
 * Total: 32 bits
 * 标签类别(1) + 分类编码(7) + 型号编码(3) + 生产日期(6) + 有效期(2) + 供应商编码(4) + 流水号(4) + 预留(5)
 */
const encodingSegments = [
  { name: '标签类别', bits: 1, color: '#1A56DB', example: '0' },
  { name: '分类编码', bits: 7, color: '#10B981', example: '4103012' },
  { name: '型号编码', bits: 3, color: '#F59E0B', example: '001' },
  { name: '生产日期', bits: 6, color: '#8B5CF6', example: '241228' },
  { name: '有效期', bits: 2, color: '#EC4899', example: '15' },
  { name: '供应商编码', bits: 4, color: '#06B6D4', example: 'A3B9' },
  { name: '流水号', bits: 4, color: '#F97316', example: '0001' },
  { name: '预留', bits: 5, color: '#94A3B8', example: '00000' },
]

/* ─── Generate random supplier code (4 alphanumeric) ─── */
function generateSupplierCode(): string {
  const chars = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ'
  let result = ''
  for (let i = 0; i < 4; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

const mockSupplierCodes = Array.from({ length: 10 }, () => generateSupplierCode())

const mockCodes: RfidCode[] = [
  /* 0=装备标签, 1=箱标签; 供应商4位; 流水号4位; 预留5位在最后 */
  { id: 'c1', code: `0410301200124122815${mockSupplierCodes[0]}000100000`, equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:30:00', createTime: '2024-01-10' },
  { id: 'c2', code: `0410301200124122815${mockSupplierCodes[1]}000200000`, equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:32:00', createTime: '2024-01-10' },
  { id: 'c3', code: `0410301200124122815${mockSupplierCodes[2]}000300000`, equipName: '防弹背心', equipModel: 'BV-III-A', batchNo: 'B202401', status: '已绑定', bindTime: '2024-01-15 09:35:00', createTime: '2024-01-10' },
  { id: 'c4', code: `0410301200225010210${mockSupplierCodes[3]}000400000`, equipName: '防弹头盔', equipModel: 'MICH2000', batchNo: 'B202402', status: '已绑定', bindTime: '2024-02-01 14:20:00', createTime: '2024-01-20' },
  { id: 'c5', code: `0410301200225010210${mockSupplierCodes[4]}000500000`, equipName: '防弹头盔', equipModel: 'MICH2000', batchNo: 'B202402', status: '未绑定', createTime: '2024-01-20' },
  { id: 'c6', code: `1410301200325030312${mockSupplierCodes[5]}000600000`, equipName: '伸缩警棍', equipModel: 'JG-01', batchNo: 'B202403', status: '已绑定', bindTime: '2024-03-10 10:00:00', createTime: '2024-03-01' },
  { id: 'c7', code: `1410301200425040414${mockSupplierCodes[6]}000700000`, equipName: '手铐', equipModel: 'SK-01', batchNo: 'B202404', status: '已绑定', bindTime: '2024-03-15 11:30:00', createTime: '2024-03-05' },
  { id: 'c8', code: `1410301200425040414${mockSupplierCodes[7]}000800000`, equipName: '手铐', equipModel: 'SK-01', batchNo: 'B202404', status: '已注销', bindTime: '2024-03-15 11:35:00', createTime: '2024-03-05' },
  { id: 'c9', code: `0410301200525050516${mockSupplierCodes[8]}000900000`, equipName: '执法记录仪', equipModel: 'ZF-01', batchNo: 'B202405', status: '已绑定', bindTime: '2024-04-01 08:45:00', createTime: '2024-03-20' },
  { id: 'c10', code: `0410301200525050516${mockSupplierCodes[9]}001000000`, equipName: '执法记录仪', equipModel: 'ZF-01', batchNo: 'B202405', status: '未绑定', createTime: '2024-03-20' },
]

function StatusBadge({ status }: { status: string }) {
  return (
    <span className={cn(
      'inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      status === '已绑定' ? 'bg-[#D1FAE5] text-[#059669]' :
      status === '未绑定' ? 'bg-[#E8F0FE] text-[#1A56DB]' :
      'bg-[#F3F4F6] text-[#6B7280]'
    )}>
      {status}
    </span>
  )
}

export default function RfidPage() {
  const chartRef = useRef<HTMLDivElement>(null)
  const chartInstanceRef = useRef<echarts.ECharts | null>(null)
  const [searchText, setSearchText] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  useEffect(() => {
    if (!chartRef.current) return

    const instance = echarts.init(chartRef.current)
    chartInstanceRef.current = instance

    const statusCounts = [
      { value: mockCodes.filter(c => c.status === '已绑定').length, name: '已绑定' },
      { value: mockCodes.filter(c => c.status === '未绑定').length, name: '未绑定' },
      { value: mockCodes.filter(c => c.status === '已注销').length, name: '已注销' },
    ]

    instance.setOption({
      tooltip: {
        trigger: 'item',
        formatter: '{b}: {c} ({d}%)',
      },
      legend: {
        orient: 'vertical',
        right: 10,
        top: 'center',
        textStyle: { color: '#374151', fontSize: 12 },
      },
      series: [
        {
          name: '编码状态',
          type: 'pie',
          radius: ['40%', '70%'],
          center: ['35%', '50%'],
          avoidLabelOverlap: true,
          itemStyle: {
            borderRadius: 6,
            borderColor: '#fff',
            borderWidth: 2,
          },
          label: { show: false },
          emphasis: {
            label: {
              show: true,
              fontSize: 14,
              fontWeight: 'bold',
            },
          },
          data: statusCounts.map((s) => ({
            ...s,
            itemStyle: {
              color: s.name === '已绑定' ? '#10B981' : s.name === '未绑定' ? '#1A56DB' : '#9CA3AF',
            },
          })),
        },
      ],
    })

    const handleResize = () => instance.resize()
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
      instance.dispose()
    }
  }, [])

  const filtered = mockCodes.filter((c) => {
    if (searchText && !c.code.includes(searchText) && !c.equipName.includes(searchText)) return false
    if (statusFilter && c.status !== statusFilter) return false
    return true
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  /* Parse 32-bit code into segments
   * 标签类别(1) + 分类编码(7) + 型号编码(3) + 生产日期(6) + 有效期(2) + 供应商编码(4) + 流水号(4) + 预留(5)
   */
  const parseCode = (code: string) => {
    if (code.length !== 32) return null
    return [
      { label: '标签类别', value: code.slice(0, 1), color: '#1A56DB' },
      { label: '分类编码', value: code.slice(1, 8), color: '#10B981' },
      { label: '型号编码', value: code.slice(8, 11), color: '#F59E0B' },
      { label: '生产日期', value: code.slice(11, 17), color: '#8B5CF6' },
      { label: '有效期', value: code.slice(17, 19), color: '#EC4899' },
      { label: '供应商编码', value: code.slice(19, 23), color: '#06B6D4' },
      { label: '流水号', value: code.slice(23, 27), color: '#F97316' },
      { label: '预留', value: code.slice(27, 32), color: '#94A3B8' },
    ]
  }

  return (
    <div>
      {/* Page Title */}
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Tag size={22} className="text-[#1A56DB]" />
          <h1 className="text-2xl font-semibold text-[#1F2937]">RFID编码管理</h1>
        </div>
        <div className="flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">
            <Plus size={14} /> 新增编码
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Upload size={14} /> 导入
          </button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Download size={14} /> 导出
          </button>
        </div>
      </div>

      {/* 32-bit Encoding Rule Card */}
      <div className="mb-6 rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#E8F0FE]">
              <Hash size={16} className="text-[#1A56DB]" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-[#1F2937]">警用装备32位编码规则</h3>
              <p className="text-xs text-[#6B7280]">用于警用装备全生命周期管理的标准RFID编码</p>
            </div>
          </div>
          <span className="rounded-md bg-[#E8F0FE] px-2.5 py-1 text-xs font-medium text-[#1A56DB]">
            32位
          </span>
        </div>

        {/* Encoding structure visualization bar */}
        <div className="mb-2">
          <div className="flex h-10 overflow-hidden rounded-lg border border-[#E5E7EB]">
            {encodingSegments.map((seg, idx) => (
              <div
                key={idx}
                className="flex items-center justify-center border-r border-white/30 text-[11px] font-semibold text-white last:border-r-0"
                style={{
                  width: `${(seg.bits / 32) * 100}%`,
                  backgroundColor: seg.color,
                  minWidth: seg.bits * 8,
                }}
                title={`${seg.name}: ${seg.bits}位`}
              >
                {seg.bits >= 4 ? seg.name : ''}
              </div>
            ))}
          </div>
        </div>

        {/* Segment details */}
        <div className="mb-3 grid grid-cols-7 gap-2">
          {encodingSegments.map((seg, idx) => (
            <div key={idx} className="rounded-md border border-[#E5E7EB] p-2 text-center">
              <div className="flex items-center justify-center gap-1">
                <span className="h-2 w-2 rounded-full" style={{ backgroundColor: seg.color }} />
                <span className="text-[11px] font-medium text-[#374151]">{seg.name}</span>
              </div>
              <div className="mt-0.5 text-[11px] text-[#6B7280]">{seg.bits}位</div>
              <div className="font-mono text-[11px] font-semibold" style={{ color: seg.color }}>
                {seg.example}
              </div>
            </div>
          ))}
        </div>

        {/* Full example */}
        <div className="rounded-md bg-[#F9FAFB] p-3">
          <div className="mb-1.5 flex items-center justify-between">
            <span className="text-xs font-medium text-[#6B7280]">编码示例</span>
            <span className="text-[11px] text-[#9CA3AF]">供应商编码4位随机字符，预留5位放在最后</span>
          </div>
          <div className="flex items-center gap-0">
            {(() => {
              const example = '0410301200124122815A3B9000100000'
              const parts = parseCode(example)
              return parts?.map((p, i) => (
                <span
                  key={i}
                  className="inline-block border-r border-[#E5E7EB] px-1.5 py-1 font-mono text-sm font-semibold last:border-r-0"
                  style={{ color: p.color }}
                  title={p.label}
                >
                  {p.value}
                </span>
              ))
            })()}
          </div>
          <div className="mt-2 flex flex-wrap gap-x-3 gap-y-1">
            {[
              { label: '标签类别', desc: '0=装备标签,1=箱标签' },
              { label: '分类编码', desc: '7位分类体系编码' },
              { label: '型号编码', desc: '3位型号序号' },
              { label: '生产日期', desc: 'YYMMDD格式' },
              { label: '有效期', desc: '2位年数' },
              { label: '供应商编码', desc: '4位随机(数字+字母)' },
              { label: '流水号', desc: '4位顺序号' },
              { label: '预留', desc: '5位预留扩展位' },
            ].map((item, i) => (
              <span key={i} className="text-[11px] text-[#6B7280]">
                <strong className="text-[#374151]">{item.label}</strong>: {item.desc}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Pie Chart + Summary */}
      <div className="mb-6 grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm lg:col-span-1">
          <h3 className="mb-3 text-sm font-semibold text-[#1F2937]">编码状态分布</h3>
          <div ref={chartRef} style={{ width: '100%', height: 220 }} />
        </div>
        <div className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-sm lg:col-span-2">
          <h3 className="mb-4 text-sm font-semibold text-[#1F2937]">编码统计概览</h3>
          <div className="grid grid-cols-4 gap-4">
            <div className="rounded-lg bg-[#E8F0FE] p-4 text-center">
              <div className="text-2xl font-bold text-[#1A56DB]">{mockCodes.length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">编码总数</div>
            </div>
            <div className="rounded-lg bg-[#D1FAE5] p-4 text-center">
              <div className="text-2xl font-bold text-[#059669]">{mockCodes.filter(c => c.status === '已绑定').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">已绑定</div>
            </div>
            <div className="rounded-lg bg-[#DBEAFE] p-4 text-center">
              <div className="text-2xl font-bold text-[#2563EB]">{mockCodes.filter(c => c.status === '未绑定').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">未绑定</div>
            </div>
            <div className="rounded-lg bg-[#F3F4F6] p-4 text-center">
              <div className="text-2xl font-bold text-[#6B7280]">{mockCodes.filter(c => c.status === '已注销').length}</div>
              <div className="mt-1 text-xs text-[#6B7280]">已注销</div>
            </div>
          </div>

          {/* Supplier code generation note */}
          <div className="mt-4 rounded-md bg-[#F0FDF4] p-3">
            <h4 className="mb-1 text-xs font-medium text-[#059669]">供应商编码规则</h4>
            <p className="text-xs leading-relaxed text-[#374151]">
              供应商编码由 <strong>4位随机字符</strong>（数字+大写字母，排除I/O易混淆字符）组成，
              系统自动生成。预留5位扩展位放在编码最后。
              示例：{mockSupplierCodes.slice(0, 5).join('、')}
            </p>
          </div>
        </div>
      </div>

      {/* Data Table */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] px-4 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">编码数据</h3>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              <input
                type="text"
                placeholder="搜索编码或装备名称"
                value={searchText}
                onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="h-8 w-52 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
              className="h-8 w-28 rounded-md border border-[#D1D5DB] px-2 text-sm outline-none transition focus:border-[#1A56DB]"
            >
              <option value="">全部状态</option>
              <option value="已绑定">已绑定</option>
              <option value="未绑定">未绑定</option>
              <option value="已注销">已注销</option>
            </select>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">编码</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">型号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">批次号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">绑定时间</th>
                <th className="w-20 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {pageData.map((row) => {
                const parsed = parseCode(row.code)
                return (
                  <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3">
                      <div className="font-mono text-sm font-medium text-[#1A56DB]">
                        {parsed ? (
                          <div className="flex items-center">
                            {parsed.map((p, i) => (
                              <span
                                key={i}
                                className="border-r border-[#E5E7EB] px-0.5 last:border-r-0"
                                style={{ color: p.color }}
                                title={p.label}
                              >
                                {p.value}
                              </span>
                            ))}
                          </div>
                        ) : row.code}
                      </div>
                    </td>
                    <td className="px-4 py-3 text-sm text-[#374151]">{row.equipName}</td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">{row.equipModel}</td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">{row.batchNo}</td>
                    <td className="px-4 py-3"><StatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-sm text-[#6B7280]">{row.bindTime || '-'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]">
                          <Edit3 size={13} />
                        </button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}
              {pageData.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">
                    暂无数据
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {filtered.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
            <span className="text-sm text-[#6B7280]">共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                disabled={currentPage === 1}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &lt;
              </button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button
                  key={p}
                  onClick={() => setCurrentPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              ))}
              <button
                onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                disabled={currentPage === totalPages}
                className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
              >
                &gt;
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
