import { useState } from 'react'
import {
  Plus, Upload, Download, Search, Edit3, Eye, Trash2,
  ChevronRight, ChevronDown, Building2, X, ChevronLeft,
  FileText, Shield, Building, Users, MapPin, GripVertical,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ═══════════════════════════════════════════
   Types
   ═══════════════════════════════════════════ */
interface StandardItem {
  id: string
  projectName: string
  configUnit: string
  measureUnit: string
  quantity: string
  useYears: number
  equipType: '必配' | '选配'
  targetObj: string
  sysEquip: string
  funcDesc: string
  status: '启用' | '停用'
  categoryId: string
  unitId: string
}

interface TreeNode {
  id: string
  label: string
  icon?: React.ReactNode
  children?: TreeNode[]
}

/* 装备库分类 - 大类到品种 */
interface EquipCategory {
  id: string
  name: string
  children?: EquipCategory[]
}

/* ═══════════════════════════════════════════
   Constants
   ═══════════════════════════════════════════ */
const CONFIG_UNITS = ['按单位', '按总队', '按支队', '按大队', '按中队', '按人数']

const equipLibrary: EquipCategory[] = [
  {
    id: 'cat1', name: '防护装备',
    children: [
      { id: 'cat1-1', name: '防弹背心' },
      { id: 'cat1-2', name: '防弹头盔' },
      { id: 'cat1-3', name: '防刺服' },
      { id: 'cat1-4', name: '防暴盾牌' },
      { id: 'cat1-5', name: '防弹盾牌' },
    ],
  },
  {
    id: 'cat2', name: '警械装备',
    children: [
      { id: 'cat2-1', name: '伸缩警棍' },
      { id: 'cat2-2', name: '手铐' },
      { id: 'cat2-3', name: '催泪喷射器' },
      { id: 'cat2-4', name: '约束带' },
    ],
  },
  {
    id: 'cat3', name: '执法装备',
    children: [
      { id: 'cat3-1', name: '执法记录仪' },
      { id: 'cat3-2', name: '对讲机' },
      { id: 'cat3-3', name: '警用强光手电' },
    ],
  },
  {
    id: 'cat4', name: '特种装备',
    children: [
      { id: 'cat4-1', name: '战术背心' },
      { id: 'cat4-2', name: '排爆服' },
      { id: 'cat4-3', name: '急救包' },
    ],
  },
  {
    id: 'cat5', name: '交通装备',
    children: [
      { id: 'cat5-1', name: '反光背心' },
      { id: 'cat5-2', name: '停车示意牌' },
      { id: 'cat5-3', name: '交通指挥棒' },
      { id: 'cat5-4', name: '酒精测试仪' },
    ],
  },
]

/* ═══════════════════════════════════════════
   Tree Data
   ═══════════════════════════════════════════ */
const categoryTree: TreeNode[] = [
  {
    id: 'provincial', label: '省级标准', icon: <Shield size={16} />,
    children: [
      { id: 'provincial-basic', label: '基础配备标准', icon: <FileText size={14} /> },
      { id: 'provincial-special', label: '特种装备标准', icon: <FileText size={14} /> },
      { id: 'provincial-emergency', label: '应急装备标准', icon: <FileText size={14} /> },
      { id: 'provincial-tech', label: '科技信息化标准', icon: <FileText size={14} /> },
    ],
  },
  {
    id: 'municipal', label: '市级标准', icon: <Building2 size={16} />,
    children: [
      { id: 'municipal-basic', label: '基础配备标准', icon: <FileText size={14} /> },
      { id: 'municipal-traffic', label: '交警装备标准', icon: <FileText size={14} /> },
      { id: 'municipal-swat', label: '特警装备标准', icon: <FileText size={14} /> },
      { id: 'municipal-patrol', label: '巡逻装备标准', icon: <FileText size={14} /> },
    ],
  },
  {
    id: 'public', label: '公用标准', icon: <Users size={16} />,
    children: [
      { id: 'public-common', label: '通用装备标准', icon: <FileText size={14} /> },
      { id: 'public-office', label: '办公装备标准', icon: <FileText size={14} /> },
      { id: 'public-vehicle', label: '车载装备标准', icon: <FileText size={14} /> },
    ],
  },
]

const unitTree: TreeNode[] = [
  {
    id: 'province', label: '省厅公安', icon: <Shield size={16} />,
    children: [
      {
        id: 'province-hq', label: '省厅机关', icon: <Building size={14} />,
        children: [
          { id: 'province-hq-office', label: '办公室', icon: <MapPin size={13} /> },
          { id: 'province-hq-equip', label: '装备财务处', icon: <MapPin size={13} /> },
          { id: 'province-hq-tech', label: '科技信息化处', icon: <MapPin size={13} /> },
          { id: 'province-hq-swat', label: '特警总队', icon: <MapPin size={13} /> },
          { id: 'province-hq-traffic', label: '交警总队', icon: <MapPin size={13} /> },
        ],
      },
    ],
  },
  {
    id: 'prefecture', label: '地级市公安局', icon: <Building2 size={16} />,
    children: [
      { id: 'city-nanjing', label: 'YYY市公安局', icon: <MapPin size={14} /> },
      { id: 'city-suzhou', label: 'YYY市公安局', icon: <MapPin size={14} /> },
      { id: 'city-wuxi', label: 'YYY市公安局', icon: <MapPin size={14} /> },
      { id: 'city-changzhou', label: 'YYY市公安局', icon: <MapPin size={14} /> },
      { id: 'city-nantong', label: 'YYY市公安局', icon: <MapPin size={14} /> },
      { id: 'city-xuzhou', label: 'YYY市公安局', icon: <MapPin size={14} /> },
    ],
  },
  {
    id: 'county', label: '区县公安局', icon: <Building size={16} />,
    children: [
      { id: 'county-gulou', label: 'ZZZ区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-jianye', label: 'ZZZ区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-qinhuai', label: '秦淮区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-xuanwu', label: '玄武区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-qixia', label: '栖霞区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-jiangning', label: '江宁区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-pukou', label: '浦口区公安分局', icon: <MapPin size={14} /> },
      { id: 'county-jiangbei', label: '江北新区公安分局', icon: <MapPin size={14} /> },
    ],
  },
]

/* ═══════════════════════════════════════════
   Mock Data
   ═══════════════════════════════════════════ */
const mockStandards: StandardItem[] = [
  { id: '1', projectName: '防弹背心', configUnit: '按人数', measureUnit: '件', quantity: '1/5', useYears: 5, equipType: '必配', targetObj: '一线执勤民警', sysEquip: '单警装备系统', funcDesc: '用于防护枪弹攻击，保护躯干要害部位', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq' },
  { id: '2', projectName: '防弹头盔', configUnit: '按人数', measureUnit: '顶', quantity: '1/1', useYears: 3, equipType: '必配', targetObj: '特警队员', sysEquip: '单警装备系统', funcDesc: '用于防护头部免受弹片、钝器伤害', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq' },
  { id: '3', projectName: '防刺服', configUnit: '按人数', measureUnit: '件', quantity: '1/3', useYears: 5, equipType: '必配', targetObj: '巡逻民警', sysEquip: '单警装备系统', funcDesc: '用于防护锐器刺砍攻击', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq' },
  { id: '4', projectName: '执法记录仪', configUnit: '按人数', measureUnit: '台', quantity: '1/1', useYears: 3, equipType: '必配', targetObj: '全体民警', sysEquip: '执法记录系统', funcDesc: '用于现场执法过程全程记录', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq' },
  { id: '5', projectName: '伸缩警棍', configUnit: '按人数', measureUnit: '根', quantity: '1/1', useYears: 5, equipType: '必配', targetObj: '一线执勤民警', sysEquip: '警械装备系统', funcDesc: '用于近身防卫和控制嫌疑人', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq' },
  { id: '6', projectName: '战术背心', configUnit: '按中队', measureUnit: '件', quantity: '10', useYears: 4, equipType: '选配', targetObj: '特警/SWAT', sysEquip: '战术装备系统', funcDesc: '用于携带战术装备和弹药', status: '启用', categoryId: 'provincial-special', unitId: 'province-hq-swat' },
  { id: '7', projectName: '防暴盾牌', configUnit: '按大队', measureUnit: '面', quantity: '20', useYears: 5, equipType: '选配', targetObj: '防暴处置组', sysEquip: '防暴装备系统', funcDesc: '用于防暴处置中防护和推进', status: '启用', categoryId: 'provincial-special', unitId: 'province-hq-swat' },
  { id: '8', projectName: '防弹盾牌', configUnit: '按支队', measureUnit: '面', quantity: '4', useYears: 5, equipType: '选配', targetObj: '反恐特警', sysEquip: '战术装备系统', funcDesc: '用于高强度防弹防护', status: '启用', categoryId: 'provincial-special', unitId: 'province-hq-swat' },
  { id: '9', projectName: '排爆服', configUnit: '按总队', measureUnit: '套', quantity: '2', useYears: 5, equipType: '选配', targetObj: '排爆组', sysEquip: '排爆装备系统', funcDesc: '用于爆炸物处置时全身防护', status: '启用', categoryId: 'provincial-special', unitId: 'province-hq-swat' },
  { id: '10', projectName: '反光背心', configUnit: '按人数', measureUnit: '件', quantity: '2/1', useYears: 3, equipType: '必配', targetObj: '交警执勤', sysEquip: '交通装备系统', funcDesc: '用于夜间或低能见度环境下提高可见性', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq-traffic' },
  { id: '11', projectName: '交通指挥棒', configUnit: '按人数', measureUnit: '根', quantity: '1/1', useYears: 3, equipType: '必配', targetObj: '交警执勤', sysEquip: '交通装备系统', funcDesc: '用于交通指挥和疏导', status: '启用', categoryId: 'provincial-basic', unitId: 'province-hq-traffic' },
  { id: '12', projectName: '手铐', configUnit: '按人数', measureUnit: '副', quantity: '2/1', useYears: 10, equipType: '必配', targetObj: '全体民警', sysEquip: '警械装备系统', funcDesc: '用于约束控制违法犯罪嫌疑人', status: '启用', categoryId: 'municipal-basic', unitId: 'city-nanjing' },
  { id: '13', projectName: '对讲机', configUnit: '按人数', measureUnit: '台', quantity: '1/2', useYears: 4, equipType: '必配', targetObj: '指挥调度岗位', sysEquip: '通信系统', funcDesc: '用于短距离无线通信联络', status: '启用', categoryId: 'municipal-basic', unitId: 'city-nanjing' },
  { id: '14', projectName: '催泪喷射器', configUnit: '按人数', measureUnit: '罐', quantity: '2/1', useYears: 3, equipType: '必配', targetObj: '一线执勤民警', sysEquip: '警械装备系统', funcDesc: '用于非致命性制服和驱散', status: '启用', categoryId: 'municipal-basic', unitId: 'city-nanjing' },
  { id: '15', projectName: '警用强光手电', configUnit: '按中队', measureUnit: '支', quantity: '6', useYears: 3, equipType: '选配', targetObj: '夜间巡逻民警', sysEquip: '单警装备系统', funcDesc: '用于夜间照明和强光眩目', status: '启用', categoryId: 'municipal-patrol', unitId: 'city-nanjing' },
]

/* ═══════════════════════════════════════════
   Helpers
   ═══════════════════════════════════════════ */
function getLeafIds(node: TreeNode): string[] {
  if (!node.children || node.children.length === 0) return [node.id]
  return node.children.flatMap(getLeafIds)
}

/* ═══════════════════════════════════════════
   Small Components
   ═══════════════════════════════════════════ */
function TypeBadge({ type }: { type: string }) {
  return (
    <span className={cn('inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium',
      type === '必配' ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'bg-[#D1FAE5] text-[#059669]')}>
      {type}
    </span>
  )
}

function TreeView({ nodes, selectedId, onSelect, expandedIds, onToggleExpand, title }: {
  nodes: TreeNode[]; selectedId: string; onSelect: (id: string) => void
  expandedIds: string[]; onToggleExpand: (id: string) => void; title: string
}) {
  const renderNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expandedIds.includes(node.id)
    const isSelected = selectedId === node.id
    const hasChildren = node.children && node.children.length > 0
    const allLeafIds = getLeafIds(node)
    const isParentOfSelected = hasChildren && allLeafIds.includes(selectedId) && !isSelected
    return (
      <div key={node.id}>
        <button onClick={() => { onSelect(node.id); if (hasChildren) onToggleExpand(node.id) }}
          className={cn('flex w-full items-center gap-1.5 rounded-md py-1.5 pr-2 text-left text-[13px] transition',
            isSelected ? 'bg-[#E8F0FE] font-medium text-[#1A56DB]' : isParentOfSelected ? 'text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]',
            depth === 0 ? 'pl-2' : depth === 1 ? 'pl-6' : 'pl-10')}>
          {hasChildren && (
            <span onClick={(e) => { e.stopPropagation(); onToggleExpand(node.id) }} className="flex h-4 w-4 shrink-0 items-center justify-center text-[#9CA3AF]">
              {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
            </span>
          )}
          {!hasChildren && <span className="h-4 w-4 shrink-0" />}
          <span className="shrink-0 text-[#6B7280]">{node.icon}</span>
          <span className="truncate">{node.label}</span>
        </button>
        {hasChildren && isExpanded && <div>{node.children!.map((child) => renderNode(child, depth + 1))}</div>}
      </div>
    )
  }
  return (
    <div className="mb-3">
      <div className="mb-1.5 px-2 text-xs font-semibold uppercase tracking-wider text-[#9CA3AF]">{title}</div>
      <div className="space-y-0.5">{nodes.map((node) => renderNode(node))}</div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   Add Standard Modal
   ═══════════════════════════════════════════ */
interface FormRow {
  id: number
  catId: string
  varId: string
  configUnit: string
  measureUnit: string
  peopleCount: string
  qtyNumber: string
  quantity: string
  useYears: string
  equipType: '必配' | '选配'
  targetObj: string
  sysEquip: string
  funcDesc: string
}

function AddStandardModal({ onClose }: { onClose: () => void }) {
  const [rows, setRows] = useState<FormRow[]>([createEmptyRow(1)])

  function createEmptyRow(id: number): FormRow {
    return { id, catId: '', varId: '', configUnit: '按单位', measureUnit: '件', peopleCount: '', qtyNumber: '', quantity: '', useYears: '', equipType: '必配', targetObj: '', sysEquip: '', funcDesc: '' }
  }

  const addRow = () => setRows((p) => [...p, createEmptyRow(p.length > 0 ? Math.max(...p.map((r) => r.id)) + 1 : 1)])
  const removeRow = (id: number) => { if (rows.length > 1) setRows((p) => p.filter((r) => r.id !== id)) }
  const updateRow = (id: number, patch: Partial<FormRow>) => {
    setRows((p) => p.map((r) => {
      if (r.id !== id) return r
      const updated = { ...r, ...patch }
      // Auto-generate quantity for "按人数"
      if (updated.configUnit === '按人数') {
        const pc = updated.peopleCount || r.peopleCount
        const qn = updated.qtyNumber || r.qtyNumber
        if (pc && qn) updated.quantity = `${qn}/${pc}`
      } else {
        updated.quantity = updated.qtyNumber || r.qtyNumber
      }
      return updated
    }))
  }

  const getSelectedEquipName = (row: FormRow) => {
    if (!row.catId || !row.varId) return ''
    const cat = equipLibrary.find((c) => c.id === row.catId)
    const variety = cat?.children?.find((v) => v.id === row.varId)
    return cat && variety ? `${cat.name} / ${variety.name}` : ''
  }

  const handleSubmit = () => {
    alert('新增配备标准成功！')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
      <div className="max-h-[92vh] w-[900px] overflow-y-auto rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-white px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">新增配备标准</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-lg text-[#9CA3AF] transition hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        <div className="px-6 py-5">
          {/* Rows */}
          <div className="space-y-4">
            {rows.map((row, idx) => (
              <div key={row.id} className="relative rounded-lg border border-[#E5E7EB] p-4">
                {/* Row header */}
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <GripVertical size={16} className="text-[#D1D5DB]" />
                    <span className="text-sm font-medium text-[#374151]">配置项目 #{idx + 1}</span>
                    {getSelectedEquipName(row) && (
                      <span className="rounded bg-[#E8F0FE] px-2 py-0.5 text-xs text-[#1A56DB]">{getSelectedEquipName(row)}</span>
                    )}
                  </div>
                  {rows.length > 1 && (
                    <button onClick={() => removeRow(row.id)} className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={14} /></button>
                  )}
                </div>

                {/* Equipment category cascade */}
                <div className="mb-3 grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">装备大类 <span className="text-[#EF4444]">*</span></label>
                    <select value={row.catId} onChange={(e) => updateRow(row.id, { catId: e.target.value, varId: '' })}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
                      <option value="">请选择大类</option>
                      {equipLibrary.map((c) => (<option key={c.id} value={c.id}>{c.name}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">装备品种 <span className="text-[#EF4444]">*</span></label>
                    <select value={row.varId} onChange={(e) => updateRow(row.id, { varId: e.target.value })}
                      disabled={!row.catId}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] disabled:bg-[#F3F4F6] disabled:text-[#9CA3AF]">
                      <option value="">请选择品种</option>
                      {row.catId && equipLibrary.find((c) => c.id === row.catId)?.children?.map((v) => (
                        <option key={v.id} value={v.id}>{v.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Config unit + measure unit */}
                <div className="mb-3 grid grid-cols-3 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">配置单元 <span className="text-[#EF4444]">*</span></label>
                    <select value={row.configUnit} onChange={(e) => updateRow(row.id, { configUnit: e.target.value })}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
                      {CONFIG_UNITS.map((u) => (<option key={u} value={u}>{u}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">计量单位 <span className="text-[#EF4444]">*</span></label>
                    <select value={row.measureUnit} onChange={(e) => updateRow(row.id, { measureUnit: e.target.value })}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
                      {['件', '顶', '根', '副', '台', '套', '面', '支', '罐', '条'].map((u) => (<option key={u} value={u}>{u}</option>))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">配备类型 <span className="text-[#EF4444]">*</span></label>
                    <select value={row.equipType} onChange={(e) => updateRow(row.id, { equipType: e.target.value as '必配' | '选配' })}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
                      <option value="必配">必配</option>
                      <option value="选配">选配</option>
                    </select>
                  </div>
                </div>

                {/* Quantity - with "按人数" special handling */}
                <div className="mb-3 grid grid-cols-4 gap-3">
                  {row.configUnit === '按人数' ? (
                    <>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">人数 <span className="text-[#EF4444]">*</span></label>
                        <input type="number" min={1} value={row.peopleCount}
                          onChange={(e) => updateRow(row.id, { peopleCount: e.target.value })}
                          placeholder="如: 5"
                          className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">数量 <span className="text-[#EF4444]">*</span></label>
                        <input type="number" min={1} value={row.qtyNumber}
                          onChange={(e) => updateRow(row.id, { qtyNumber: e.target.value })}
                          placeholder="如: 1"
                          className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#6B7280]">自动生成</label>
                        <div className="flex h-9 items-center rounded-md bg-[#F3F4F6] px-3 text-sm font-medium text-[#1A56DB]">
                          {row.quantity || '—'}
                        </div>
                      </div>
                    </>
                  ) : (
                    <div>
                      <label className="mb-1 block text-xs font-medium text-[#374151]">数量 <span className="text-[#EF4444]">*</span></label>
                      <input type="number" min={1} value={row.qtyNumber}
                        onChange={(e) => updateRow(row.id, { qtyNumber: e.target.value, quantity: e.target.value })}
                        placeholder="输入数量"
                        className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                    </div>
                  )}
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">使用年限(年) <span className="text-[#EF4444]">*</span></label>
                    <input type="number" min={1} value={row.useYears}
                      onChange={(e) => updateRow(row.id, { useYears: e.target.value })}
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                </div>

                {/* Target obj */}
                <div className="mb-3 grid grid-cols-1 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">配备对象 <span className="text-[#EF4444]">*</span></label>
                    <input type="text" value={row.targetObj}
                      onChange={(e) => updateRow(row.id, { targetObj: e.target.value })}
                      placeholder="如: 一线执勤民警"
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                </div>

                {/* System equip + func desc */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">系统装备</label>
                    <input type="text" value={row.sysEquip}
                      onChange={(e) => updateRow(row.id, { sysEquip: e.target.value })}
                      placeholder="如: 单警装备系统"
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">功能描述</label>
                    <input type="text" value={row.funcDesc}
                      onChange={(e) => updateRow(row.id, { funcDesc: e.target.value })}
                      placeholder="简述装备功能"
                      className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Add row button */}
          <button onClick={addRow}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-lg border-2 border-dashed border-[#D1D5DB] py-3 text-sm text-[#6B7280] transition hover:border-[#1A56DB] hover:text-[#1A56DB]">
            <Plus size={16} /> 添加配置项目
          </button>

          {/* Actions */}
          <div className="mt-5 flex justify-end gap-2">
            <button onClick={onClose} className="h-9 rounded-lg border border-[#E5E7EB] px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSubmit} className="h-9 rounded-lg bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">提交</button>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   Main Page
   ═══════════════════════════════════════════ */
export default function StandardPage() {
  const [selectedCategoryId, setSelectedCategoryId] = useState('provincial')
  const [selectedUnitId, setSelectedUnitId] = useState('province-hq')
  const [expandedCategoryIds, setExpandedCategoryIds] = useState<string[]>(['provincial', 'municipal', 'public'])
  const [expandedUnitIds, setExpandedUnitIds] = useState<string[]>(['province', 'prefecture', 'county', 'province-hq'])
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [searchText, setSearchText] = useState('')
  const [typeFilter, setTypeFilter] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const [showModal, setShowModal] = useState(false)
  const pageSize = 10

  const getAllLeafIds = (tree: TreeNode[], id: string): string[] => {
    for (const node of tree) {
      if (node.id === id) return getLeafIds(node)
      if (node.children) {
        for (const child of node.children) {
          if (child.id === id) return [child.id]
          if (child.children) {
            for (const grandChild of child.children) {
              if (grandChild.id === id) return [grandChild.id]
            }
          }
        }
      }
    }
    return [id]
  }

  const selectedCategoryLeafIds = getAllLeafIds(categoryTree, selectedCategoryId)
  const selectedUnitLeafIds = getAllLeafIds(unitTree, selectedUnitId)

  const filtered = mockStandards.filter((s) => {
    const matchCategory = selectedCategoryLeafIds.includes(s.categoryId)
    const matchUnit = selectedUnitLeafIds.includes(s.unitId)
    const matchSearch = !searchText || s.projectName.includes(searchText) || s.funcDesc.includes(searchText)
    const matchType = !typeFilter || s.equipType === typeFilter
    const matchStatus = !statusFilter || s.status === statusFilter
    return matchCategory && matchUnit && matchSearch && matchType && matchStatus
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const getName = (tree: TreeNode[], id: string) => {
    for (const node of tree) {
      if (node.id === id) return node.label
      if (node.children) {
        for (const child of node.children) {
          if (child.id === id) return child.label
          if (child.children) {
            for (const gc of child.children) { if (gc.id === id) return gc.label }
          }
        }
      }
    }
    return id
  }

  return (
    <div className="flex h-[calc(100vh-7rem)] gap-4">
      {/* Left Sidebar */}
      <div className={cn('flex shrink-0 flex-col overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm transition-all duration-200', sidebarCollapsed ? 'w-0 opacity-0' : 'w-[260px] opacity-100')}>
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-3 py-2.5">
          <span className="text-sm font-semibold text-[#1F2937]">标准分类导航</span>
          <button onClick={() => setSidebarCollapsed(true)} className="flex h-6 w-6 items-center justify-center rounded text-[#9CA3AF] transition hover:bg-[#F3F4F6]"><ChevronLeft size={16} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-2">
          <TreeView nodes={categoryTree} selectedId={selectedCategoryId} onSelect={setSelectedCategoryId}
            expandedIds={expandedCategoryIds} onToggleExpand={(id) => setExpandedCategoryIds((p) => p.includes(id) ? p.filter((v) => v !== id) : [...p, id])} title="标准分类" />
          <div className="my-2 border-t border-[#E5E7EB]" />
          <TreeView nodes={unitTree} selectedId={selectedUnitId} onSelect={setSelectedUnitId}
            expandedIds={expandedUnitIds} onToggleExpand={(id) => setExpandedUnitIds((p) => p.includes(id) ? p.filter((v) => v !== id) : [...p, id])} title="配置单位" />
        </div>
        <div className="border-t border-[#E5E7EB] bg-[#F9FAFB] px-3 py-2.5">
          <div className="text-[11px] text-[#6B7280]">当前筛选</div>
          <div className="mt-1 flex flex-wrap gap-1">
            <span className="inline-flex items-center rounded bg-[#E8F0FE] px-1.5 py-0.5 text-[11px] text-[#1A56DB]">{getName(categoryTree, selectedCategoryId)}</span>
            <span className="inline-flex items-center rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[11px] text-[#059669]">{getName(unitTree, selectedUnitId)}</span>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex min-w-0 flex-1 flex-col">
        {sidebarCollapsed && (
          <button onClick={() => setSidebarCollapsed(false)} className="mb-2 flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] bg-white text-[#6B7280] shadow-sm transition hover:bg-[#F3F4F6]"><ChevronRight size={16} /></button>
        )}

        {/* Title */}
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h1 className="text-2xl font-semibold text-[#1F2937]">配备标准管理</h1>
            <span className="rounded-md bg-[#E8F0FE] px-2.5 py-1 text-xs font-medium text-[#1A56DB]">{getName(categoryTree, selectedCategoryId)}</span>
            <span className="rounded-md bg-[#D1FAE5] px-2.5 py-1 text-xs font-medium text-[#059669]">{getName(unitTree, selectedUnitId)}</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowModal(true)} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Plus size={14} /> 新增标准</button>
            <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"><Upload size={14} /> 导入</button>
            <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"><Download size={14} /> 导出</button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              <input type="text" placeholder="搜索项目名称或功能描述" value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="h-9 w-60 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10" />
            </div>
            <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setCurrentPage(1) }}
              className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
              <option value="">全部类型</option>
              <option value="必配">必配</option>
              <option value="选配">选配</option>
            </select>
            <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setCurrentPage(1) }}
              className="h-9 w-28 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]">
              <option value="">全部状态</option>
              <option value="启用">启用</option>
              <option value="停用">停用</option>
            </select>
            <button onClick={() => { setSearchText(''); setTypeFilter(''); setStatusFilter(''); setCurrentPage(1) }}
              className="inline-flex h-9 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">重置</button>
          </div>
        </div>

        {/* Table - Fields per screenshot */}
        <div className="flex flex-1 flex-col overflow-hidden rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="flex-1 overflow-auto">
            <table className="w-full">
              <thead className="sticky top-0 z-10">
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配备项目名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配置单元</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计量单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">使用年限</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配备类型</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配备对象</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">系统装备</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">功能描述</th>
                  <th className="w-28 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {pageData.map((row, idx) => (
                  <tr key={row.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', idx % 2 === 1 ? 'bg-[#FAFBFC]' : 'bg-white')}>
                    <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-[#1F2937]">{row.projectName}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#374151]">{row.configUnit}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#374151]">{row.measureUnit}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm font-medium text-[#1A56DB]">{row.quantity}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#374151]">{row.useYears}年</td>
                    <td className="whitespace-nowrap px-4 py-3"><TypeBadge type={row.equipType} /></td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#374151]">{row.targetObj}</td>
                    <td className="whitespace-nowrap px-4 py-3 text-sm text-[#6B7280]">{row.sysEquip}</td>
                    <td className="max-w-[200px] truncate px-4 py-3 text-xs text-[#6B7280]">{row.funcDesc}</td>
                    <td className="whitespace-nowrap px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Edit3 size={13} /></button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={13} /></button>
                        <button className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={13} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
                {pageData.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-4 py-16 text-center">
                      <div className="flex flex-col items-center gap-2 text-[#9CA3AF]">
                        <FileText size={40} strokeWidth={1.5} />
                        <p className="text-sm">暂无匹配数据</p>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {filtered.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
              <span className="text-sm text-[#6B7280]">共 <strong className="text-[#1F2937]">{filtered.length}</strong> 条</span>
              <div className="flex items-center gap-1">
                <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage === 1} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&lt;</button>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                  <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition', p === currentPage ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
                ))}
                <button onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage === totalPages} className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30">&gt;</button>
              </div>
            </div>
          )}
        </div>
      </div>

      {showModal && <AddStandardModal onClose={() => setShowModal(false)} />}
    </div>
  )
}
