import { useState, useCallback } from 'react'
import {
  ArrowLeft, Star, TrendingUp, TrendingDown, Minus, Download,
  FileText, Eye, Plus, X, CheckCircle2, XCircle, Clock, AlertTriangle,
  ChevronRight, BarChart3, Search, Calendar, Building2, Settings,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface DimensionConfig {
  key: string
  label: string
  weight: number        // 权重（0~1）
  score: number         // 该维度原始得分（0~100）
  weightedScore: number // 加权后得分
  indicators: { label: string; value: string }[]
}

interface InterventionRecord {
  id: string
  time: string
  operator: string
  type: 'total' | 'acceptance' | 'complaint' | 'penalty'
  typeLabel: string
  direction: 'add' | 'subtract'
  amount: number
  reason: string
  status: 'pending' | 'approved' | 'rejected'
  reviewer?: string
  reviewTime?: string
}

interface SupplierScore {
  id: string
  supplierId: string
  supplierName: string
  period: string           // 评分周期，如 "2025M3"
  periodLabel: string      // "2025年3月"
  autoScore: number        // 自动计算综合分
  finalScore: number       // 最终得分（含人工干预）
  status: 'auto' | 'adjusted' | 'frozen'
  dimensions: DimensionConfig[]
  interventions: InterventionRecord[]
  calcTime: string         // 自动计算时间
}

/* ═══════════════════════════════════════════
   Mock 数据
   ═══════════════════════════════════════════ */

const suppliers = [
  { id: 'S001', name: '海康威视数字技术股份有限公司' },
  { id: 'S002', name: '烽火通信科技股份有限公司' },
  { id: 'S003', name: '华为技术有限公司' },
  { id: 'S004', name: '中兴通讯股份有限公司' },
  { id: 'S005', name: '大华技术股份有限公司' },
]

function dim(label: string, weight: number, score: number, indicators: { label: string; value: string }[]): DimensionConfig {
  return {
    key: label,
    label,
    weight,
    score,
    weightedScore: Math.round(score * weight * 10) / 10,
    indicators,
  }
}

function intervention(id: string, time: string, operator: string, type: 'total' | 'acceptance' | 'complaint' | 'penalty', typeLabel: string, direction: 'add' | 'subtract', amount: number, reason: string, status: 'pending' | 'approved' | 'rejected', reviewer?: string, reviewTime?: string): InterventionRecord {
  return { id, time, operator, type, typeLabel, direction, amount, reason, status, reviewer, reviewTime }
}

const mockScores: SupplierScore[] = [
  {
    id: 'SC-202503-001',
    supplierId: 'S001', supplierName: '海康威视数字技术股份有限公司',
    period: '2025M3', periodLabel: '2025年3月',
    autoScore: 96.3, finalScore: 99.3, status: 'adjusted',
    calcTime: '2025-04-01 02:00',
    dimensions: [
      dim('验收', 0.5, 98.5, [{ label: '验收合格率', value: '98.5%' }, { label: '准时交付率', value: '99.2%' }]),
      dim('投诉', 0.3, 90, [{ label: '投诉次数', value: '2次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 100, [{ label: '违规次数', value: '0次' }]),
    ],
    interventions: [
      intervention('INT-001', '2025-03-05 10:30', '管理员A', 'total', '总分', 'add', 3.0, '项目额外贡献，配合度极高', 'approved', '审核人B', '2025-03-06 09:00'),
      intervention('INT-002', '2025-03-02 14:20', '管理员C', 'complaint', '投诉分', 'subtract', 5.0, '投诉误判，客户撤诉', 'rejected', '审核人D', '2025-03-03 11:00'),
    ],
  },
  {
    id: 'SC-202503-002',
    supplierId: 'S002', supplierName: '烽火通信科技股份有限公司',
    period: '2025M3', periodLabel: '2025年3月',
    autoScore: 88.5, finalScore: 88.5, status: 'auto',
    calcTime: '2025-04-01 02:00',
    dimensions: [
      dim('验收', 0.5, 92, [{ label: '验收合格率', value: '92%' }, { label: '准时交付率', value: '95%' }]),
      dim('投诉', 0.3, 85, [{ label: '投诉次数', value: '3次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 90, [{ label: '违规次数', value: '1次(一般)' }]),
    ],
    interventions: [],
  },
  {
    id: 'SC-202503-003',
    supplierId: 'S003', supplierName: '华为技术有限公司',
    period: '2025M3', periodLabel: '2025年3月',
    autoScore: 94.0, finalScore: 94.0, status: 'auto',
    calcTime: '2025-04-01 02:00',
    dimensions: [
      dim('验收', 0.5, 96, [{ label: '验收合格率', value: '96%' }, { label: '准时交付率', value: '97%' }]),
      dim('投诉', 0.3, 95, [{ label: '投诉次数', value: '1次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 90, [{ label: '违规次数', value: '1次(一般)' }]),
    ],
    interventions: [],
  },
  {
    id: 'SC-202503-004',
    supplierId: 'S004', supplierName: '中兴通讯股份有限公司',
    period: '2025M3', periodLabel: '2025年3月',
    autoScore: 78.2, finalScore: 78.2, status: 'auto',
    calcTime: '2025-04-01 02:00',
    dimensions: [
      dim('验收', 0.5, 88, [{ label: '验收合格率', value: '88%' }, { label: '准时交付率', value: '85%' }]),
      dim('投诉', 0.3, 70, [{ label: '投诉次数', value: '5次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 80, [{ label: '违规次数', value: '2次(一般)' }]),
    ],
    interventions: [],
  },
  {
    id: 'SC-202503-005',
    supplierId: 'S005', supplierName: '大华技术股份有限公司',
    period: '2025M3', periodLabel: '2025年3月',
    autoScore: 82.0, finalScore: 85.0, status: 'adjusted',
    calcTime: '2025-04-01 02:00',
    dimensions: [
      dim('验收', 0.5, 90, [{ label: '验收合格率', value: '90%' }, { label: '准时交付率', value: '92%' }]),
      dim('投诉', 0.3, 80, [{ label: '投诉次数', value: '4次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 70, [{ label: '违规次数', value: '3次(一般)' }]),
    ],
    interventions: [
      intervention('INT-003', '2025-03-10 09:15', '管理员E', 'acceptance', '验收分', 'add', 3.0, '额外完成紧急订单，质量优秀', 'approved', '审核人F', '2025-03-11 10:00'),
    ],
  },
  // 2月数据
  {
    id: 'SC-202502-001',
    supplierId: 'S001', supplierName: '海康威视数字技术股份有限公司',
    period: '2025M2', periodLabel: '2025年2月',
    autoScore: 94.5, finalScore: 94.5, status: 'frozen',
    calcTime: '2025-03-01 02:00',
    dimensions: [
      dim('验收', 0.5, 97, [{ label: '验收合格率', value: '97%' }, { label: '准时交付率', value: '96%' }]),
      dim('投诉', 0.3, 90, [{ label: '投诉次数', value: '2次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 95, [{ label: '违规次数', value: '1次(一般)' }]),
    ],
    interventions: [],
  },
  {
    id: 'SC-202502-002',
    supplierId: 'S002', supplierName: '烽火通信科技股份有限公司',
    period: '2025M2', periodLabel: '2025年2月',
    autoScore: 85.0, finalScore: 85.0, status: 'frozen',
    calcTime: '2025-03-01 02:00',
    dimensions: [
      dim('验收', 0.5, 90, [{ label: '验收合格率', value: '90%' }, { label: '准时交付率', value: '88%' }]),
      dim('投诉', 0.3, 80, [{ label: '投诉次数', value: '4次' }, { label: '容忍值', value: '2次' }]),
      dim('处罚', 0.2, 85, [{ label: '违规次数', value: '1次(一般)+1次(严重)' }]),
    ],
    interventions: [],
  },
]

// 自动计算频率类型
type CalcTriggerType = 'scheduled' | 'event'

// 评价规则配置（可完整配置业务规则）
interface EvaluationRuleConfig {
  maxScore: number         // 满分（默认100）
  minScore: number         // 最低分（默认0）
  weights: {
    acceptance: number     // 验收权重
    complaint: number      // 投诉权重
    penalty: number        // 处罚权重
  }
  acceptanceRule: {
    targetRate: number     // 验收合格率目标值（%）
    deductPerPoint: number // 低于目标每百分点扣几分
  }
  complaintRule: {
    tolerance: number      // 容忍值（次数）
    deductPerExcess: number// 超出每次扣几分
  }
  penaltyRule: {
    normalDeduct: number   // 一般违规每次扣几分
    seriousDeduct: number  // 严重违规每次扣几分
  }
  autoCalcFrequency: {
    type: CalcTriggerType   // 触发方式：scheduled 定时 / event 事件
    scheduledTime?: string  // 定时触发时机（如"月底"、"月初"）
    eventType?: string      // 事件触发类型（如"新投诉录入"、"验收完成"）
  }
}

const defaultRuleConfig: EvaluationRuleConfig = {
  maxScore: 100,
  minScore: 0,
  weights: { acceptance: 0.5, complaint: 0.3, penalty: 0.2 },
  acceptanceRule: { targetRate: 95, deductPerPoint: 2 },
  complaintRule: { tolerance: 2, deductPerExcess: 5 },
  penaltyRule: { normalDeduct: 10, seriousDeduct: 30 },
  autoCalcFrequency: { type: 'scheduled', scheduledTime: '月底' },
}

/* ═══════════════════════════════════════════
   辅助组件
   ═══════════════════════════════════════════ */

function ScoreBadge({ score }: { score: number }) {
  if (score >= 90) return <Badge variant="success">{score} 优秀</Badge>
  if (score >= 80) return <Badge variant="warning">{score} 良好</Badge>
  if (score >= 60) return <Badge variant="default">{score} 合格</Badge>
  return <Badge variant="danger">{score} 不合格</Badge>
}

function StatusBadge({ status }: { status: SupplierScore['status'] }) {
  switch (status) {
    case 'auto': return <Badge variant="info" dot>自动计算</Badge>
    case 'adjusted': return <Badge variant="primary" dot>已调整</Badge>
    case 'frozen': return <Badge variant="default">已冻结</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function InterventionStatusBadge({ status }: { status: InterventionRecord['status'] }) {
  switch (status) {
    case 'pending': return <Badge variant="warning" dot>待审核</Badge>
    case 'approved': return <Badge variant="success">已生效</Badge>
    case 'rejected': return <Badge variant="danger">已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function TrendIcon({ autoScore, finalScore }: { autoScore: number; finalScore: number }) {
  const diff = finalScore - autoScore
  if (diff > 0) return <span className="inline-flex items-center text-[10px] text-[#059669]"><TrendingUp size={10} className="mr-0.5" />+{diff.toFixed(1)}</span>
  if (diff < 0) return <span className="inline-flex items-center text-[10px] text-[#DC2626]"><TrendingDown size={10} className="mr-0.5" />{diff.toFixed(1)}</span>
  return <span className="inline-flex items-center text-[10px] text-[#6B7280]"><Minus size={10} className="mr-0.5" />0</span>
}

/* ═══════════════════════════════════════════
   人工干预申请弹窗
   ═══════════════════════════════════════════ */

function InterventionModal({ open, score, onClose, onSubmit }: {
  open: boolean; score: SupplierScore | null; onClose: () => void; onSubmit: (record: InterventionRecord) => void
}) {
  const [type, setType] = useState<'total' | 'acceptance' | 'complaint' | 'penalty'>('total')
  const [direction, setDirection] = useState<'add' | 'subtract'>('add')
  const [amount, setAmount] = useState('')
  const [reason, setReason] = useState('')

  if (!open || !score) return null

  const typeOptions = [
    { value: 'total', label: '总分' },
    { value: 'acceptance', label: '验收分' },
    { value: 'complaint', label: '投诉分' },
    { value: 'penalty', label: '处罚分' },
  ]

  const handleSubmit = () => {
    const amt = parseFloat(amount)
    if (isNaN(amt) || amt <= 0) { alert('请输入有效的调整幅度'); return }
    if (amt > 10) { alert('单次调整幅度不能超过10分'); return }
    if (!reason.trim()) { alert('请填写调整原因'); return }

    const rec: InterventionRecord = {
      id: `INT-${Date.now()}`,
      time: new Date().toLocaleString('zh-CN', { hour12: false }),
      operator: '当前管理员',
      type,
      typeLabel: typeOptions.find(o => o.value === type)?.label || type,
      direction,
      amount: amt,
      reason: reason.trim(),
      status: 'pending',
    }
    onSubmit(rec)
    // reset
    setType('total')
    setDirection('add')
    setAmount('')
    setReason('')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[460px] max-w-[90vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">申请人工干预</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="space-y-4 p-6">
          {/* 当前评分信息 */}
          <div className="rounded-lg bg-[#FAFBFC] p-3 text-xs">
            <div className="mb-1 text-[#6B7280]">当前自动评分：<span className="font-semibold text-[#1A56DB]">{score.autoScore}</span></div>
            <div className="text-[#6B7280]">评价对象：{score.supplierName}</div>
            <div className="text-[#6B7280]">评分周期：{score.periodLabel}</div>
          </div>

          {/* 调整类型 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">调整类型</label>
            <select value={type} onChange={e => setType(e.target.value as typeof type)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
              {typeOptions.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          </div>

          {/* 调整方向 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">调整方向</label>
            <div className="flex gap-3">
              <button onClick={() => setDirection('add')} className={cn('flex h-9 flex-1 items-center justify-center gap-1 rounded-md border text-sm', direction === 'add' ? 'border-[#059669] bg-[#F0FDF4] text-[#059669]' : 'border-[#D1D5DB] text-[#374151]')}>
                <TrendingUp size={14} /> 加分
              </button>
              <button onClick={() => setDirection('subtract')} className={cn('flex h-9 flex-1 items-center justify-center gap-1 rounded-md border text-sm', direction === 'subtract' ? 'border-[#DC2626] bg-[#FEE2E2] text-[#DC2626]' : 'border-[#D1D5DB] text-[#374151]')}>
                <TrendingDown size={14} /> 减分
              </button>
            </div>
          </div>

          {/* 调整幅度 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">调整幅度 <span className="text-[#9CA3AF]">(0~10分)</span></label>
            <input type="number" value={amount} onChange={e => setAmount(e.target.value)} min={0.1} max={10} step={0.1} placeholder="请输入调整幅度" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
          </div>

          {/* 调整原因 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">调整原因 <span className="text-[#EF4444]">*</span></label>
            <textarea value={reason} onChange={e => setReason(e.target.value)} rows={3} placeholder="请详细说明调整原因..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
          </div>
        </div>
        <div className="flex items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">取消</button>
          <button onClick={handleSubmit} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white">提交申请</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   评价规则配置弹窗
   ═══════════════════════════════════════════ */

function EvaluationRuleModal({ open, config, onClose, onSave }: {
  open: boolean; config: EvaluationRuleConfig; onClose: () => void; onSave: (c: EvaluationRuleConfig) => void
}) {
  const [accW, setAccW] = useState(Math.round(config.weights.acceptance * 100))
  const [compW, setCompW] = useState(Math.round(config.weights.complaint * 100))
  const [penW, setPenW] = useState(Math.round(config.weights.penalty * 100))
  const [accTarget, setAccTarget] = useState(config.acceptanceRule.targetRate)
  const [accDeduct, setAccDeduct] = useState(config.acceptanceRule.deductPerPoint)
  const [compTol, setCompTol] = useState(config.complaintRule.tolerance)
  const [compDeduct, setCompDeduct] = useState(config.complaintRule.deductPerExcess)
  const [penNormal, setPenNormal] = useState(config.penaltyRule.normalDeduct)
  const [penSerious, setPenSerious] = useState(config.penaltyRule.seriousDeduct)
  const [maxScore, setMaxScore] = useState(config.maxScore)
  const [minScore, setMinScore] = useState(config.minScore)
  const [triggerType, setTriggerType] = useState<CalcTriggerType>(config.autoCalcFrequency.type)
  const [scheduledTime, setScheduledTime] = useState(config.autoCalcFrequency.scheduledTime || '月底')
  const [eventType, setEventType] = useState(config.autoCalcFrequency.eventType || '新投诉录入')

  const weightTotal = accW + compW + penW
  const isWeightValid = weightTotal === 100

  const handleSave = () => {
    if (!isWeightValid) { alert(`当前权重总和为 ${weightTotal}%，必须为 100%`); return }
    if (maxScore <= minScore) { alert('满分必须大于最低分'); return }
    onSave({
      maxScore, minScore,
      weights: { acceptance: accW / 100, complaint: compW / 100, penalty: penW / 100 },
      acceptanceRule: { targetRate: accTarget, deductPerPoint: accDeduct },
      complaintRule: { tolerance: compTol, deductPerExcess: compDeduct },
      penaltyRule: { normalDeduct: penNormal, seriousDeduct: penSerious },
      autoCalcFrequency: {
        type: triggerType,
        ...(triggerType === 'scheduled' ? { scheduledTime } : { scheduledTime: undefined }),
        ...(triggerType === 'event' ? { eventType } : { eventType: undefined }),
      },
    })
    onClose()
  }

  const handleClose = () => {
    // 恢复原始值
    setAccW(Math.round(config.weights.acceptance * 100))
    setCompW(Math.round(config.weights.complaint * 100))
    setPenW(Math.round(config.weights.penalty * 100))
    setAccTarget(config.acceptanceRule.targetRate)
    setAccDeduct(config.acceptanceRule.deductPerPoint)
    setCompTol(config.complaintRule.tolerance)
    setCompDeduct(config.complaintRule.deductPerExcess)
    setPenNormal(config.penaltyRule.normalDeduct)
    setPenSerious(config.penaltyRule.seriousDeduct)
    setMaxScore(config.maxScore)
    setMinScore(config.minScore)
    setTriggerType(config.autoCalcFrequency.type)
    setScheduledTime(config.autoCalcFrequency.scheduledTime || '月底')
    setEventType(config.autoCalcFrequency.eventType || '新投诉录入')
    onClose()
  }

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative z-10 w-[520px] max-w-[94vw] max-h-[90vh] flex flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">评价规则配置</h2>
          <button onClick={handleClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-auto space-y-5 p-6">

          {/* 基础分设置 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 text-xs font-semibold text-[#374151]">基础分设置</div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">满分</label>
                <input type="number" value={maxScore} onChange={e => setMaxScore(Number(e.target.value))} min={1} max={200} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">最低分</label>
                <input type="number" value={minScore} onChange={e => setMinScore(Number(e.target.value))} min={0} max={99} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
          </div>

          {/* 维度权重 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 text-xs font-semibold text-[#374151]">维度权重配置</div>
            <div className="space-y-3">
              {/* 验收 */}
              <div>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-[#374151]">验收维度</span>
                  <span className="font-mono font-semibold text-[#1A56DB]">{accW}%</span>
                </div>
                <input type="range" min={0} max={100} value={accW} onChange={e => setAccW(Number(e.target.value))} className="h-2 w-full accent-[#1A56DB]" />
              </div>
              {/* 投诉 */}
              <div>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-[#374151]">投诉维度</span>
                  <span className="font-mono font-semibold text-[#1A56DB]">{compW}%</span>
                </div>
                <input type="range" min={0} max={100} value={compW} onChange={e => setCompW(Number(e.target.value))} className="h-2 w-full accent-[#1A56DB]" />
              </div>
              {/* 处罚 */}
              <div>
                <div className="mb-1 flex items-center justify-between text-xs">
                  <span className="text-[#374151]">处罚维度</span>
                  <span className="font-mono font-semibold text-[#1A56DB]">{penW}%</span>
                </div>
                <input type="range" min={0} max={100} value={penW} onChange={e => setPenW(Number(e.target.value))} className="h-2 w-full accent-[#1A56DB]" />
              </div>
            </div>
            <div className={cn('mt-2 rounded px-3 py-1.5 text-center text-xs', isWeightValid ? 'bg-[#F0FDF4] text-[#059669]' : 'bg-[#FEE2E2] text-[#DC2626]')}>
              权重总和：<span className="font-mono font-bold">{weightTotal}%</span>
              {isWeightValid ? ' ✓' : ` ✗ 需=${100 - weightTotal}%`}
            </div>
          </div>

          {/* 验收维度规则 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-[#374151]">
              <CheckCircle2 size={13} className="text-[#059669]" />
              验收维度计分规则
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">合格率目标值(%)</label>
                <input type="number" value={accTarget} onChange={e => setAccTarget(Number(e.target.value))} min={50} max={100} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">每百分点扣分</label>
                <input type="number" value={accDeduct} onChange={e => setAccDeduct(Number(e.target.value))} min={0.5} max={10} step={0.5} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
            <div className="mt-1 text-[10px] text-[#9CA3AF]">
              例：目标{accTarget}%，合格率94%时得分=100-({accTarget}-94)×{accDeduct}={100 - Math.max(0, accTarget - 94) * accDeduct}分
            </div>
          </div>

          {/* 投诉维度规则 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-[#374151]">
              <AlertTriangle size={13} className="text-[#D97706]" />
              投诉维度计分规则
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">容忍值(次)</label>
                <input type="number" value={compTol} onChange={e => setCompTol(Number(e.target.value))} min={0} max={10} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">超出每次扣分</label>
                <input type="number" value={compDeduct} onChange={e => setCompDeduct(Number(e.target.value))} min={1} max={20} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
            <div className="mt-1 text-[10px] text-[#9CA3AF]">
              ≤{compTol}次不扣分，超出每次扣{compDeduct}分，扣完为止
            </div>
          </div>

          {/* 处罚维度规则 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-[#374151]">
              <XCircle size={13} className="text-[#DC2626]" />
              处罚维度计分规则
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">一般违规扣分(分/次)</label>
                <input type="number" value={penNormal} onChange={e => setPenNormal(Number(e.target.value))} min={1} max={50} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">严重违规扣分(分/次)</label>
                <input type="number" value={penSerious} onChange={e => setPenSerious(Number(e.target.value))} min={1} max={100} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
            </div>
            <div className="mt-1 text-[10px] text-[#9CA3AF]">
              一般违规扣{penNormal}分/次，严重违规扣{penSerious}分/次，累积扣除，该项最低0分
            </div>
          </div>

          {/* 自动计算频率配置 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-[#374151]">
              <Clock size={13} className="text-[#1A56DB]" />
              自动计算频率
            </div>
            <div className="mb-2 flex gap-3">
              <button
                onClick={() => setTriggerType('scheduled')}
                className={cn('flex h-8 flex-1 items-center justify-center gap-1 rounded-md border text-xs', triggerType === 'scheduled' ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151]')}
              >
                <Calendar size={12} /> 定时触发
              </button>
              <button
                onClick={() => setTriggerType('event')}
                className={cn('flex h-8 flex-1 items-center justify-center gap-1 rounded-md border text-xs', triggerType === 'event' ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151]')}
              >
                <AlertTriangle size={12} /> 事件触发
              </button>
            </div>
            {triggerType === 'scheduled' ? (
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">定时时机</label>
                <select value={scheduledTime} onChange={e => setScheduledTime(e.target.value)} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  <option value="月初">月初（每月1日）</option>
                  <option value="月中">月中（每月15日）</option>
                  <option value="月底">月底（每月最后一日）</option>
                  <option value="季度初">季度初（每季度首月1日）</option>
                  <option value="季度末">季度末（每季度末月最后一日）</option>
                </select>
                <div className="mt-1 text-[10px] text-[#9CA3AF]">系统将在{scheduledTime}自动从各数据源抽取并重新计算评分</div>
              </div>
            ) : (
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">触发事件</label>
                <select value={eventType} onChange={e => setEventType(e.target.value)} className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  <option value="新投诉录入">新投诉录入</option>
                  <option value="验收完成">验收完成</option>
                  <option value="处罚记录新增">处罚记录新增</option>
                  <option value="人工干预审批通过">人工干预审批通过</option>
                </select>
                <div className="mt-1 text-[10px] text-[#9CA3AF]">当{eventType}时，系统将自动重新计算相关供应商评分</div>
              </div>
            )}
          </div>

          {/* 生效提示 */}
          <div className="rounded-lg border border-[#F59E0B]/30 bg-[#FFF7ED] px-3 py-2 text-xs text-[#D97706]">
            <Clock size={12} className="mr-1 inline" />
            修改后仅对<strong>新生成评分</strong>生效，已生成的评分不受影响
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={handleClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">取消</button>
          <button onClick={handleSave} className={cn('h-9 rounded-md px-5 text-sm text-white', isWeightValid ? 'bg-[#1A56DB]' : 'cursor-not-allowed bg-[#9CA3AF]')}>保存配置</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   评分详情视图
   ═══════════════════════════════════════════ */

function ScoreDetailView({ score, onBack, onIntervention }: {
  score: SupplierScore; onBack: () => void; onIntervention: (s: SupplierScore) => void
}) {
  return (
    <div>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <ArrowLeft size={18} />
          </button>
          <h1 className="text-xl font-semibold text-[#1F2937]">评分详情</h1>
        </div>
        <button onClick={onBack} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">返回列表</button>
      </div>

      {/* 基本信息 */}
      <div className="mb-6 rounded-lg border border-[#E5E7EB] bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm text-[#374151]">
              <Building2 size={16} className="text-[#1A56DB]" />
              <span className="font-medium">评价对象：</span>
              <span>{score.supplierName}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-[#374151]">
              <Calendar size={16} className="text-[#6B7280]" />
              <span className="font-medium">评分周期：</span>
              <span>{score.periodLabel}</span>
            </div>
          </div>
          <StatusBadge status={score.status} />
        </div>

        {/* 自动计算评分 */}
        <div className="mb-4">
          <div className="mb-2 flex items-center gap-2 text-sm font-medium text-[#374151]">
            <BarChart3 size={16} className="text-[#1A56DB]" />
            自动计算评分
            <span className="text-xs text-[#9CA3AF]">({score.calcTime})</span>
          </div>
          <div className="overflow-hidden rounded-lg border border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-[#F9FAFB]">
                  <th className="px-4 py-2.5 text-left text-xs font-semibold text-[#6B7280]">维度</th>
                  <th className="px-4 py-2.5 text-center text-xs font-semibold text-[#6B7280]">权重</th>
                  <th className="px-4 py-2.5 text-left text-xs font-semibold text-[#6B7280]">指标值</th>
                  <th className="px-4 py-2.5 text-right text-xs font-semibold text-[#6B7280]">得分</th>
                </tr>
              </thead>
              <tbody>
                {score.dimensions.map(d => (
                  <tr key={d.key} className="border-t border-[#F3F4F6]">
                    <td className="px-4 py-2.5 font-medium text-[#374151]">{d.label}</td>
                    <td className="px-4 py-2.5 text-center text-[#6B7280]">{(d.weight * 100).toFixed(0)}%</td>
                    <td className="px-4 py-2.5 text-xs text-[#6B7280]">
                      {d.indicators.map((ind, i) => (
                        <span key={i} className="mr-2">{ind.label}：{ind.value}</span>
                      ))}
                    </td>
                    <td className="px-4 py-2.5 text-right">
                      <span className="font-mono font-medium text-[#374151]">{d.score}</span>
                      <span className="ml-1 text-xs text-[#9CA3AF]">×{d.weight}=</span>
                      <span className="ml-1 font-mono font-semibold text-[#1A56DB]">{d.weightedScore.toFixed(1)}</span>
                    </td>
                  </tr>
                ))}
                <tr className="border-t border-[#E5E7EB] bg-[#F9FAFB]">
                  <td colSpan={3} className="px-4 py-2.5 text-right text-sm font-semibold text-[#374151]">综合得分</td>
                  <td className="px-4 py-2.5 text-right">
                    <span className="font-mono text-lg font-bold text-[#1A56DB]">{score.autoScore}</span>
                    <span className="ml-1 rounded bg-[#E8F0FE] px-1.5 py-0.5 text-[10px] text-[#1A56DB]">自动评分</span>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* 人工干预记录 */}
        <div>
          <div className="mb-2 flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm font-medium text-[#374151]">
              <FileText size={16} className="text-[#D97706]" />
              人工干预记录
              {score.interventions.length > 0 && <span className="rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[10px] text-[#D97706]">{score.interventions.length}条</span>}
            </div>
            {score.status !== 'frozen' && (
              <button onClick={() => onIntervention(score)} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#D97706] px-3 text-xs text-white hover:bg-[#B45309]">
                <Plus size={12} /> 申请人工干预
              </button>
            )}
          </div>

          {score.interventions.length === 0 ? (
            <div className="rounded-lg border border-dashed border-[#D1D5DB] py-6 text-center text-sm text-[#9CA3AF]">暂无人工干预记录</div>
          ) : (
            <div className="overflow-hidden rounded-lg border border-[#E5E7EB]">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-[#F9FAFB]">
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">干预时间</th>
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">调整项</th>
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">幅度</th>
                    <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">原因</th>
                    <th className="px-3 py-2.5 text-center text-xs font-semibold text-[#6B7280]">状态</th>
                  </tr>
                </thead>
                <tbody>
                  {score.interventions.map(intv => (
                    <tr key={intv.id} className="border-t border-[#F3F4F6]">
                      <td className="px-3 py-2.5 text-xs text-[#374151]">{intv.time}</td>
                      <td className="px-3 py-2.5 text-xs font-medium text-[#374151]">{intv.typeLabel}</td>
                      <td className="px-3 py-2.5">
                        <span className={cn('font-mono text-xs font-medium', intv.direction === 'add' ? 'text-[#059669]' : 'text-[#DC2626]')}>
                          {intv.direction === 'add' ? '+' : '-'}{intv.amount.toFixed(1)}
                        </span>
                      </td>
                      <td className="max-w-[200px] px-3 py-2.5 text-xs text-[#374151]">{intv.reason}</td>
                      <td className="px-3 py-2.5 text-center"><InterventionStatusBadge status={intv.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* 最终评分 */}
          {score.interventions.length > 0 && (
            <div className="mt-3 flex items-center justify-end gap-2 rounded-lg bg-[#F0FDF4] px-4 py-2.5">
              <span className="text-xs text-[#6B7280]">自动评分 {score.autoScore}</span>
              {score.interventions.filter(i => i.status === 'approved').map(i => (
                <span key={i.id} className={cn('text-xs font-medium', i.direction === 'add' ? 'text-[#059669]' : 'text-[#DC2626]')}>
                  {i.direction === 'add' ? '+' : '-'}{i.amount.toFixed(1)}
                </span>
              ))}
              <ChevronRight size={14} className="text-[#9CA3AF]" />
              <span className="text-sm font-semibold text-[#059669]">当前最终评分 = {score.finalScore.toFixed(1)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   评分列表视图
   ═══════════════════════════════════════════ */

function ScoreListView({ scores, ruleConfig, onViewDetail, onIntervention, onOpenConfig }: {
  scores: SupplierScore[]; ruleConfig: EvaluationRuleConfig; onViewDetail: (s: SupplierScore) => void; onIntervention: (s: SupplierScore) => void; onOpenConfig: () => void
}) {
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})
  const handleSearch = () => {}

  const filtered = scores.filter(s => {
    if (filterValues.supplier && !s.supplierName.includes(filterValues.supplier)) return false
    if (filterValues.period && !s.period.includes(filterValues.period)) return false
    if (filterValues.status && s.status !== filterValues.status) return false
    return true
  })

  const filterFields = [
    { key: 'supplier', label: '供应商', type: 'input' as const, placeholder: '请输入供应商名称' },
    { key: 'period', label: '评分周期', type: 'input' as const, placeholder: '如：2025M3' },
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '自动计算', value: 'auto' },
      { label: '已调整', value: 'adjusted' },
      { label: '已冻结', value: 'frozen' },
    ]},
  ]

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">供应商评价</h1>
        <div className="flex gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">
            <Download size={14} /> 导出报表
          </button>
        </div>
      </div>

      {/* 评价规则配置 */}
      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-medium text-[#374151]">
            <BarChart3 size={16} className="text-[#1A56DB]" />
            评价规则配置
          </div>
          <button onClick={onOpenConfig} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151] hover:bg-[#F3F4F6]">
            <Settings size={12} /> 配置
          </button>
        </div>
        <div className="mt-2 grid grid-cols-4 gap-4 text-xs text-[#6B7280]">
          <div>
            <div className="mb-1 font-medium text-[#374151]">维度权重</div>
            <div>验收 {(ruleConfig.weights.acceptance * 100).toFixed(0)}%</div>
            <div>投诉 {(ruleConfig.weights.complaint * 100).toFixed(0)}%</div>
            <div>处罚 {(ruleConfig.weights.penalty * 100).toFixed(0)}%</div>
          </div>
          <div>
            <div className="mb-1 font-medium text-[#374151]">验收规则</div>
            <div>目标值 ≥{ruleConfig.acceptanceRule.targetRate}%</div>
            <div>每低1%扣{ruleConfig.acceptanceRule.deductPerPoint}分</div>
          </div>
          <div>
            <div className="mb-1 font-medium text-[#374151]">投诉/处罚规则</div>
            <div>投诉容忍 ≤{ruleConfig.complaintRule.tolerance}次</div>
            <div>超出扣{ruleConfig.complaintRule.deductPerExcess}分/次</div>
            <div>一般违规扣{ruleConfig.penaltyRule.normalDeduct}分</div>
            <div>严重违规扣{ruleConfig.penaltyRule.seriousDeduct}分</div>
          </div>
          <div>
            <div className="mb-1 font-medium text-[#374151]">自动计算频率</div>
            <div>{ruleConfig.autoCalcFrequency.type === 'scheduled' ? '定时触发' : '事件触发'}</div>
            <div className="text-[#1A56DB]">
              {ruleConfig.autoCalcFrequency.type === 'scheduled'
                ? ruleConfig.autoCalcFrequency.scheduledTime
                : ruleConfig.autoCalcFrequency.eventType}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-4">
        <FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} />
      </div>

      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">评分编号</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">评分周期</th>
                <th className="px-3 py-3 text-right text-xs font-semibold text-[#6B7280]">自动评分</th>
                <th className="px-3 py-3 text-right text-xs font-semibold text-[#6B7280]">最终评分</th>
                <th className="px-3 py-3 text-center text-xs font-semibold text-[#6B7280]">变动</th>
                <th className="px-3 py-3 text-center text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-44 px-3 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filtered.map(row => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-3 py-3 font-mono text-[13px] text-[#1A56DB]">{row.id}</td>
                  <td className="px-3 py-3 text-[13px] text-[#374151]">{row.supplierName}</td>
                  <td className="px-3 py-3 text-[13px] text-[#374151]">{row.periodLabel}</td>
                  <td className="px-3 py-3 text-right font-mono text-[13px] text-[#6B7280]">{row.autoScore.toFixed(1)}</td>
                  <td className="px-3 py-3 text-right"><ScoreBadge score={row.finalScore} /></td>
                  <td className="px-3 py-3 text-center"><TrendIcon autoScore={row.autoScore} finalScore={row.finalScore} /></td>
                  <td className="px-3 py-3 text-center"><StatusBadge status={row.status} /></td>
                  <td className="px-3 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button onClick={() => onViewDetail(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] hover:bg-[#E8F0FE]" title="详情"><Eye size={14} /></button>
                      {row.status !== 'frozen' && (
                        <button onClick={() => onIntervention(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#D97706] px-2 text-[11px] text-white hover:bg-[#B45309]" title="人工干预"><Plus size={12} />干预</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filtered.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">下一页</button>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function SupplierEvaluationPage() {
  const [scores, setScores] = useState<SupplierScore[]>(mockScores)
  const [view, setView] = useState<'list' | 'detail'>('list')
  const [detailScore, setDetailScore] = useState<SupplierScore | null>(null)
  const [interventionScore, setInterventionScore] = useState<SupplierScore | null>(null)
  const [showInterventionModal, setShowInterventionModal] = useState(false)
  const [ruleConfig, setRuleConfig] = useState<EvaluationRuleConfig>(defaultRuleConfig)
  const [showRuleModal, setShowRuleModal] = useState(false)

  const handleViewDetail = useCallback((score: SupplierScore) => {
    setDetailScore(score)
    setView('detail')
  }, [])

  const handleBack = useCallback(() => {
    setView('list')
    setDetailScore(null)
  }, [])

  const handleIntervention = useCallback((score: SupplierScore) => {
    setInterventionScore(score)
    setShowInterventionModal(true)
  }, [])

  const handleSubmitIntervention = useCallback((record: InterventionRecord) => {
    if (!interventionScore) return
    const updatedInterventions = [...interventionScore.interventions, record]
    // 重新计算最终得分：自动分 + 所有已生效干预的代数和
    const approvedTotal = updatedInterventions
      .filter(i => i.status === 'approved')
      .reduce((sum, i) => sum + (i.direction === 'add' ? i.amount : -i.amount), 0)
    const newFinal = Math.round((interventionScore.autoScore + approvedTotal) * 10) / 10

    const updated: SupplierScore = {
      ...interventionScore,
      interventions: updatedInterventions,
      finalScore: newFinal,
      status: newFinal !== interventionScore.autoScore ? 'adjusted' : interventionScore.status,
    }

    setScores(prev => prev.map(s => s.id === updated.id ? updated : s))
    setDetailScore(updated)
    setInterventionScore(updated)
  }, [interventionScore])

  return (
    <div>
      {view === 'list' && (
        <ScoreListView
          scores={scores}
          ruleConfig={ruleConfig}
          onViewDetail={handleViewDetail}
          onIntervention={handleIntervention}
          onOpenConfig={() => setShowRuleModal(true)}
        />
      )}
      {view === 'detail' && detailScore && (
        <ScoreDetailView score={detailScore} onBack={handleBack} onIntervention={handleIntervention} />
      )}
      <InterventionModal
        open={showInterventionModal}
        score={interventionScore}
        onClose={() => setShowInterventionModal(false)}
        onSubmit={handleSubmitIntervention}
      />
      <EvaluationRuleModal
        open={showRuleModal}
        config={ruleConfig}
        onClose={() => setShowRuleModal(false)}
        onSave={setRuleConfig}
      />
    </div>
  )
}
