import { useState, useRef, useEffect } from 'react'
import {
  Plus, Upload, Eye, Printer, PackageCheck, FileInput, History, ArrowLeftRight,
  RotateCcw, MoreHorizontal, ChevronDown, ChevronRight, X, AlertCircle,
  ScanLine, FileSpreadsheet, Camera, Wifi, Check, Trash2, Edit3, Warehouse,
  Layers, Grid3x3, Search, Building2, Users,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface OrgNode { id: string; name: string; level: number; children?: OrgNode[] }

interface ShelfItem { id: string; name: string; code: string; shelfType: string; capacity: number; zoneName: string }
interface ZoneItem { id: string; name: string; code: string; zoneType: string; shelves: ShelfItem[] }
interface WarehouseItem { id: string; code: string; name: string; address: string; orgUnit: string; orgLevel: string; status: string; zones: ZoneItem[] }

/* ─── 到货签收信息 ─── */
interface ReceiptInfo {
  receiverName: string
  receiveTime: string
}

/* ─── 处置分配项 ─── */
interface DisposalItem {
  id: string
  type: 'inbound' | 'delivery'
  quantity: number
  targetUnit?: string
  targetObject?: string
  storageLocation?: string
}

interface EquipmentDetail {
  id: string
  name: string; model: string; code: string; unit: string
  isWholeBox: boolean; boxCode: string; rfidCodes: string[]
  actualRfidCodes: string[]
  purchaseQty: number; deliveryQty: number
  actualQty?: number
  unitPrice: number; totalAmount: number
  productionDate: string; validityMonths: number; expiryDate: string
  category1: string; category2: string; category3: string
  qualifiedQty: number | null; unqualifiedQty: number | null
  inspectionOpinion: string; inspectionPhotos: string[]
  inspectionStatus: 'pending' | 'qualified' | 'unqualified' | 'return' | 'exchange'
  receiptInfo?: ReceiptInfo
  disposals?: DisposalItem[]
}

interface PurchaseReceipt {
  id: string; orderName: string; contractNo: string
  supplier: string; enterpriseCode: string
  equipmentSummary: string; deliveryDate: string; receiver: string
  status: 'pending-receipt' | 'inspected'
  warehouseId: string | null; warehouseName: string | null
  storageLocation: string | null
  equipments: EquipmentDetail[]
}

interface BaseInboundRecord {
  id: string
  source: string
  storageLocation: string
  equipmentName: string
  model: string
  quantity: number
  inboundDate: string
  inboundBy: string
  status: 'recorded' | 'stored'
}

interface InitialRecord extends BaseInboundRecord {
  materialSource: string
}

interface TransferRecord extends BaseInboundRecord {
  materialSource: string
  transferOrderNo: string
  senderUnit: string
}

interface ReturnRecord extends BaseInboundRecord {
  materialSource: string
  borrower: string
  borrowDate: string
  expectedReturnDate: string
  borrowOrderNo: string
}

interface OtherRecord extends BaseInboundRecord {
  materialSource: string
}

/* ═══════════════════════════════════════════
   组织架构 & 仓库数据（来自仓库信息模块）
   ═══════════════════════════════════════════ */

const orgTree: OrgNode[] = [{
  id: 'h1', name: 'XXX省公安厅', level: 0,
  children: [
    { id: 'c1', name: 'YYY市公安局', level: 1, children: [
      { id: 'd1', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's1', name: 'AAA派出所', level: 3 }, { id: 's2', name: 'AAA派出所', level: 3 }] },
      { id: 'd2', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's3', name: 'AAA派出所', level: 3 }] },
      { id: 'd3', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's4', name: 'AAA派出所', level: 3 }] }
    ]},
    { id: 'c2', name: 'YYY市公安局', level: 1, children: [{ id: 'd4', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's5', name: 'AAA派出所', level: 3 }] }] },
    { id: 'c3', name: 'YYY市公安局', level: 1, children: [{ id: 'd5', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's6', name: 'AAA派出所', level: 3 }] }] },
    { id: 'c4', name: 'YYY市公安局', level: 1, children: [{ id: 'd6', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's7', name: 'AAA派出所', level: 3 }] }] },
    { id: 'c5', name: 'YYY市公安局', level: 1, children: [{ id: 'd7', name: 'ZZZ区公安分局', level: 2, children: [{ id: 's8', name: 'AAA派出所', level: 3 }] }] }
  ]
}]

const warehouseList: WarehouseItem[] = [
  { id: '1', code: 'CK-2024-001', name: '省厅主装备仓库', address: 'YYY市ZZZ区某路1号', orgUnit: 'XXX省公安厅', orgLevel: '省', status: '启用', zones: [
    { id: 'z1', name: '收货区', code: 'FQ-SH-001', zoneType: '收货区', shelves: [{ id: 's1', name: '收货货架A', code: 'HJ-SH-A01', shelfType: '中型货架', capacity: 200, zoneName: '收货区' }, { id: 's2', name: '收货货架B', code: 'HJ-SH-B01', shelfType: '中型货架', capacity: 200, zoneName: '收货区' }] },
    { id: 'z2', name: '存储区', code: 'FQ-CC-001', zoneType: '存储区', shelves: [{ id: 's3', name: '存储货架A01', code: 'HJ-CC-A01', shelfType: '重型货架', capacity: 500, zoneName: '存储区' }, { id: 's4', name: '存储货架A02', code: 'HJ-CC-A02', shelfType: '重型货架', capacity: 500, zoneName: '存储区' }, { id: 's5', name: '存储货架B01', code: 'HJ-CC-B01', shelfType: '中型货架', capacity: 300, zoneName: '存储区' }] },
    { id: 'z3', name: '拣货区', code: 'FQ-JH-001', zoneType: '拣货区', shelves: [{ id: 's6', name: '拣货货架A', code: 'HJ-JH-A01', shelfType: '轻型货架', capacity: 150, zoneName: '拣货区' }] },
  ]},
  { id: '2', code: 'CK-2024-002', name: '省厅应急物资仓库', address: 'YYY市ZZZ区某路22号', orgUnit: 'XXX省公安厅', orgLevel: '省', status: '启用', zones: [
    { id: 'z4', name: '存储区', code: 'FQ-CC-002', zoneType: '存储区', shelves: [{ id: 's7', name: '应急货架A', code: 'HJ-YJ-A01', shelfType: '重型货架', capacity: 400, zoneName: '存储区' }] },
  ]},
  { id: '3', code: 'CK-2024-003', name: 'YYY市局装备仓库', address: 'YYY市ZZZ区某路88号', orgUnit: 'YYY市公安局', orgLevel: '市', status: '启用', zones: [
    { id: 'z5', name: '收货区', code: 'FQ-SH-003', zoneType: '收货区', shelves: [{ id: 's8', name: '收货货架', code: 'HJ-SH-001', shelfType: '中型货架', capacity: 200, zoneName: '收货区' }] },
    { id: 'z6', name: '存储区', code: 'FQ-CC-003', zoneType: '存储区', shelves: [{ id: 's9', name: '存储货架A', code: 'HJ-CC-A01', shelfType: '重型货架', capacity: 500, zoneName: '存储区' }, { id: 's10', name: '存储货架B', code: 'HJ-CC-B01', shelfType: '重型货架', capacity: 500, zoneName: '存储区' }] },
  ]},
  { id: '4', code: 'CK-2024-004', name: 'YYY市局城南分库', address: 'YYY市ZZZ区某路45号', orgUnit: 'YYY市公安局', orgLevel: '市', status: '启用', zones: [] },
  { id: '5', code: 'CK-2024-005', name: 'ZZZ区分局仓库', address: 'YYY市ZZZ区某路120号', orgUnit: 'ZZZ区公安分局', orgLevel: '县', status: '启用', zones: [
    { id: 'z7', name: '综合区', code: 'FQ-ZH-005', zoneType: '存储区', shelves: [{ id: 's11', name: '综合货架', code: 'HJ-ZH-001', shelfType: '中型货架', capacity: 300, zoneName: '综合区' }] },
  ]},
  { id: '6', code: 'CK-2024-006', name: 'ZZZ区分局仓库', address: 'YYY市ZZZ区某路66号', orgUnit: 'ZZZ区公安分局', orgLevel: '县', status: '启用', zones: [] },
  { id: '7', code: 'CK-2024-007', name: 'YYY市局装备仓库', address: 'YYY市ZZZ区某路258号', orgUnit: 'YYY市公安局', orgLevel: '市', status: '启用', zones: [
    { id: 'z8', name: '存储区', code: 'FQ-CC-007', zoneType: '存储区', shelves: [{ id: 's12', name: '主货架A', code: 'HJ-ZH-A01', shelfType: '重型货架', capacity: 600, zoneName: '存储区' }] },
  ]},
  { id: '8', code: 'CK-2024-009', name: 'YYY市局装备仓库', address: 'YYY市ZZZ区某路88号', orgUnit: 'YYY市公安局', orgLevel: '市', status: '启用', zones: [] },
  { id: '9', code: 'CK-2024-010', name: 'YYY市局装备仓库', address: 'YYY市ZZZ区某路112号', orgUnit: 'YYY市公安局', orgLevel: '市', status: '启用', zones: [] },
]

/* ═══════════════════════════════════════════
   常量
   ═══════════════════════════════════════════ */

const inboundTypes = [
  { key: 'purchase', label: '到货验收', icon: PackageCheck },
  { key: 'initial', label: '期初入库', icon: History },
  { key: 'transfer', label: '仓库调拨入库', icon: ArrowLeftRight },
  { key: 'return', label: '归还入库', icon: RotateCcw },
  { key: 'other', label: '其他入库', icon: MoreHorizontal },
]

const purchaseTabs: { key: string; label: string; badge: number; badgeVariant: string }[] = [
  { key: 'pending-receipt', label: '待收货', badge: 5, badgeVariant: 'danger' },
  { key: 'inspected', label: '已验收', badge: 3, badgeVariant: 'warning' },
]

function InboundStatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'recorded': return <Badge variant="warning" dot>已录入</Badge>
    case 'stored': return <Badge variant="success" dot>已入库</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   Mock 数据：采购收货单
   ═══════════════════════════════════════════ */

const purchaseReceipts: PurchaseReceipt[] = [
  {
    id: 'FH20260603001', orderName: '2026年防弹背心采购订单', contractNo: 'HT-2026-001',
    supplier: '某省安防科技有限公司', enterpriseCode: '91320000132234567X',
    equipmentSummary: '防弹背心x50, 手铐x100, 执法记录仪x30',
    deliveryDate: '2026-06-03', receiver: 'XXX省公安厅装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ001', category1: '防护装备', category2: '防弹装备', category3: '防弹背心', name: '防弹背心', model: 'FD-BX-III', code: 'ZB-001-001', unit: '件', isWholeBox: true, boxCode: 'BX-202606-001', rfidCodes: ['RFID-BX-001','RFID-BX-002','RFID-BX-003','RFID-BX-004','RFID-BX-005','RFID-BX-006','RFID-BX-007','RFID-BX-008','RFID-BX-009','RFID-BX-010','RFID-BX-011','RFID-BX-012','RFID-BX-013','RFID-BX-014','RFID-BX-015','RFID-BX-016','RFID-BX-017','RFID-BX-018','RFID-BX-019','RFID-BX-020','RFID-BX-021','RFID-BX-022','RFID-BX-023','RFID-BX-024','RFID-BX-025','RFID-BX-026','RFID-BX-027','RFID-BX-028','RFID-BX-029','RFID-BX-030','RFID-BX-031','RFID-BX-032','RFID-BX-033','RFID-BX-034','RFID-BX-035','RFID-BX-036','RFID-BX-037','RFID-BX-038','RFID-BX-039','RFID-BX-040','RFID-BX-041','RFID-BX-042','RFID-BX-043','RFID-BX-044','RFID-BX-045','RFID-BX-046','RFID-BX-047','RFID-BX-048','RFID-BX-049','RFID-BX-050'], actualRfidCodes: [], purchaseQty: 200, deliveryQty: 50, unitPrice: 1200, totalAmount: 60000, productionDate: '2026-03-15', validityMonths: 60, expiryDate: '2031-03-14', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
      { id: 'EQ002', category1: '警械装备', category2: '约束装备', category3: '手铐', name: '手铐', model: 'SK-STD', code: 'ZB-002-001', unit: '副', isWholeBox: true, boxCode: 'BX-202606-002', rfidCodes: ['RFID-SK-001','RFID-SK-002','RFID-SK-003','RFID-SK-004','RFID-SK-005','RFID-SK-006','RFID-SK-007','RFID-SK-008','RFID-SK-009','RFID-SK-010','RFID-SK-011','RFID-SK-012','RFID-SK-013','RFID-SK-014','RFID-SK-015','RFID-SK-016','RFID-SK-017','RFID-SK-018','RFID-SK-019','RFID-SK-020','RFID-SK-021','RFID-SK-022','RFID-SK-023','RFID-SK-024','RFID-SK-025','RFID-SK-026','RFID-SK-027','RFID-SK-028','RFID-SK-029','RFID-SK-030','RFID-SK-031','RFID-SK-032','RFID-SK-033','RFID-SK-034','RFID-SK-035','RFID-SK-036','RFID-SK-037','RFID-SK-038','RFID-SK-039','RFID-SK-040','RFID-SK-041','RFID-SK-042','RFID-SK-043','RFID-SK-044','RFID-SK-045','RFID-SK-046','RFID-SK-047','RFID-SK-048','RFID-SK-049','RFID-SK-050','RFID-SK-051','RFID-SK-052','RFID-SK-053','RFID-SK-054','RFID-SK-055','RFID-SK-056','RFID-SK-057','RFID-SK-058','RFID-SK-059','RFID-SK-060','RFID-SK-061','RFID-SK-062','RFID-SK-063','RFID-SK-064','RFID-SK-065','RFID-SK-066','RFID-SK-067','RFID-SK-068','RFID-SK-069','RFID-SK-070','RFID-SK-071','RFID-SK-072','RFID-SK-073','RFID-SK-074','RFID-SK-075','RFID-SK-076','RFID-SK-077','RFID-SK-078','RFID-SK-079','RFID-SK-080','RFID-SK-081','RFID-SK-082','RFID-SK-083','RFID-SK-084','RFID-SK-085','RFID-SK-086','RFID-SK-087','RFID-SK-088','RFID-SK-089','RFID-SK-090','RFID-SK-091','RFID-SK-092','RFID-SK-093','RFID-SK-094','RFID-SK-095','RFID-SK-096','RFID-SK-097','RFID-SK-098','RFID-SK-099','RFID-SK-100'], actualRfidCodes: [], purchaseQty: 500, deliveryQty: 100, unitPrice: 85, totalAmount: 8500, productionDate: '2026-02-20', validityMonths: 120, expiryDate: '2036-02-19', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
      { id: 'EQ003', category1: '通信装备', category2: '记录装备', category3: '执法记录仪', name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-003-001', unit: '台', isWholeBox: false, boxCode: '', rfidCodes: ['RFID-DSJ-001','RFID-DSJ-002','RFID-DSJ-003','RFID-DSJ-004','RFID-DSJ-005','RFID-DSJ-006','RFID-DSJ-007','RFID-DSJ-008','RFID-DSJ-009','RFID-DSJ-010','RFID-DSJ-011','RFID-DSJ-012','RFID-DSJ-013','RFID-DSJ-014','RFID-DSJ-015','RFID-DSJ-016','RFID-DSJ-017','RFID-DSJ-018','RFID-DSJ-019','RFID-DSJ-020','RFID-DSJ-021','RFID-DSJ-022','RFID-DSJ-023','RFID-DSJ-024','RFID-DSJ-025','RFID-DSJ-026','RFID-DSJ-027','RFID-DSJ-028','RFID-DSJ-029','RFID-DSJ-030'], actualRfidCodes: [], purchaseQty: 150, deliveryQty: 30, unitPrice: 2800, totalAmount: 84000, productionDate: '2026-04-01', validityMonths: 36, expiryDate: '2029-03-31', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603002', orderName: '2026年防刺服采购订单', contractNo: 'HT-2026-002',
    supplier: '某市警用装备厂', enterpriseCode: '91110000123456789X',
    equipmentSummary: '防刺服x80, 警棍x200',
    deliveryDate: '2026-06-03', receiver: 'YYY市公安局装备处',
    status: 'inspected', warehouseId: '3', warehouseName: 'YYY市局装备仓库', storageLocation: 'XXX省公安厅/YYY市公安局',
    equipments: [
      { id: 'EQ004', category1: '防护装备', category2: '防刺装备', category3: '防刺服', name: '防刺服', model: 'FCF-II', code: 'ZB-001-002', unit: '件', isWholeBox: true, boxCode: 'BX-202606-003', rfidCodes: ['RFID-FCF-001','RFID-FCF-002','RFID-FCF-003','RFID-FCF-004','RFID-FCF-005','RFID-FCF-006','RFID-FCF-007','RFID-FCF-008','RFID-FCF-009','RFID-FCF-010','RFID-FCF-011','RFID-FCF-012','RFID-FCF-013','RFID-FCF-014','RFID-FCF-015','RFID-FCF-016','RFID-FCF-017','RFID-FCF-018','RFID-FCF-019','RFID-FCF-020','RFID-FCF-021','RFID-FCF-022','RFID-FCF-023','RFID-FCF-024','RFID-FCF-025','RFID-FCF-026','RFID-FCF-027','RFID-FCF-028','RFID-FCF-029','RFID-FCF-030','RFID-FCF-031','RFID-FCF-032','RFID-FCF-033','RFID-FCF-034','RFID-FCF-035','RFID-FCF-036','RFID-FCF-037','RFID-FCF-038','RFID-FCF-039','RFID-FCF-040','RFID-FCF-041','RFID-FCF-042','RFID-FCF-043','RFID-FCF-044','RFID-FCF-045','RFID-FCF-046','RFID-FCF-047','RFID-FCF-048','RFID-FCF-049','RFID-FCF-050','RFID-FCF-051','RFID-FCF-052','RFID-FCF-053','RFID-FCF-054','RFID-FCF-055','RFID-FCF-056','RFID-FCF-057','RFID-FCF-058','RFID-FCF-059','RFID-FCF-060','RFID-FCF-061','RFID-FCF-062','RFID-FCF-063','RFID-FCF-064','RFID-FCF-065','RFID-FCF-066','RFID-FCF-067','RFID-FCF-068','RFID-FCF-069','RFID-FCF-070','RFID-FCF-071','RFID-FCF-072','RFID-FCF-073','RFID-FCF-074','RFID-FCF-075','RFID-FCF-076','RFID-FCF-077','RFID-FCF-078','RFID-FCF-079','RFID-FCF-080'], actualRfidCodes: ['RFID-FCF-001','RFID-FCF-002','RFID-FCF-003','RFID-FCF-004','RFID-FCF-005','RFID-FCF-006','RFID-FCF-007','RFID-FCF-008','RFID-FCF-009','RFID-FCF-010','RFID-FCF-011','RFID-FCF-012','RFID-FCF-013','RFID-FCF-014','RFID-FCF-015','RFID-FCF-016','RFID-FCF-017','RFID-FCF-018','RFID-FCF-019','RFID-FCF-020','RFID-FCF-021','RFID-FCF-022','RFID-FCF-023','RFID-FCF-024','RFID-FCF-025','RFID-FCF-026','RFID-FCF-027','RFID-FCF-028','RFID-FCF-029','RFID-FCF-030','RFID-FCF-031','RFID-FCF-032','RFID-FCF-033','RFID-FCF-034','RFID-FCF-035','RFID-FCF-036','RFID-FCF-037','RFID-FCF-038','RFID-FCF-039','RFID-FCF-040','RFID-FCF-041','RFID-FCF-042','RFID-FCF-043','RFID-FCF-044','RFID-FCF-045','RFID-FCF-046','RFID-FCF-047','RFID-FCF-048','RFID-FCF-049','RFID-FCF-050','RFID-FCF-051','RFID-FCF-052','RFID-FCF-053','RFID-FCF-054','RFID-FCF-055','RFID-FCF-056','RFID-FCF-057','RFID-FCF-058','RFID-FCF-059','RFID-FCF-060','RFID-FCF-061','RFID-FCF-062','RFID-FCF-063','RFID-FCF-064','RFID-FCF-065','RFID-FCF-066','RFID-FCF-067','RFID-FCF-068','RFID-FCF-069','RFID-FCF-070','RFID-FCF-071','RFID-FCF-072','RFID-FCF-073','RFID-FCF-074','RFID-FCF-075','RFID-FCF-076','RFID-FCF-077','RFID-FCF-078'], purchaseQty: 300, deliveryQty: 80, unitPrice: 450, totalAmount: 36000, productionDate: '2026-01-10', validityMonths: 48, expiryDate: '2030-01-09', qualifiedQty: 78, unqualifiedQty: 2, inspectionOpinion: '2件有轻微磨损', inspectionPhotos: ['照片1'], inspectionStatus: 'unqualified' },
      { id: 'EQ005', category1: '警械装备', category2: '执勤装备', category3: '警棍', name: '警棍', model: 'JG-TELE', code: 'ZB-002-002', unit: '根', isWholeBox: true, boxCode: 'BX-202606-004', rfidCodes: ['RFID-JG-001','RFID-JG-002','RFID-JG-003','RFID-JG-004','RFID-JG-005','RFID-JG-006','RFID-JG-007','RFID-JG-008','RFID-JG-009','RFID-JG-010','RFID-JG-011','RFID-JG-012','RFID-JG-013','RFID-JG-014','RFID-JG-015','RFID-JG-016','RFID-JG-017','RFID-JG-018','RFID-JG-019','RFID-JG-020','RFID-JG-021','RFID-JG-022','RFID-JG-023','RFID-JG-024','RFID-JG-025','RFID-JG-026','RFID-JG-027','RFID-JG-028','RFID-JG-029','RFID-JG-030','RFID-JG-031','RFID-JG-032','RFID-JG-033','RFID-JG-034','RFID-JG-035','RFID-JG-036','RFID-JG-037','RFID-JG-038','RFID-JG-039','RFID-JG-040','RFID-JG-041','RFID-JG-042','RFID-JG-043','RFID-JG-044','RFID-JG-045','RFID-JG-046','RFID-JG-047','RFID-JG-048','RFID-JG-049','RFID-JG-050','RFID-JG-051','RFID-JG-052','RFID-JG-053','RFID-JG-054','RFID-JG-055','RFID-JG-056','RFID-JG-057','RFID-JG-058','RFID-JG-059','RFID-JG-060','RFID-JG-061','RFID-JG-062','RFID-JG-063','RFID-JG-064','RFID-JG-065','RFID-JG-066','RFID-JG-067','RFID-JG-068','RFID-JG-069','RFID-JG-070','RFID-JG-071','RFID-JG-072','RFID-JG-073','RFID-JG-074','RFID-JG-075','RFID-JG-076','RFID-JG-077','RFID-JG-078','RFID-JG-079','RFID-JG-080','RFID-JG-081','RFID-JG-082','RFID-JG-083','RFID-JG-084','RFID-JG-085','RFID-JG-086','RFID-JG-087','RFID-JG-088','RFID-JG-089','RFID-JG-090','RFID-JG-091','RFID-JG-092','RFID-JG-093','RFID-JG-094','RFID-JG-095','RFID-JG-096','RFID-JG-097','RFID-JG-098','RFID-JG-099','RFID-JG-100','RFID-JG-101','RFID-JG-102','RFID-JG-103','RFID-JG-104','RFID-JG-105','RFID-JG-106','RFID-JG-107','RFID-JG-108','RFID-JG-109','RFID-JG-110','RFID-JG-111','RFID-JG-112','RFID-JG-113','RFID-JG-114','RFID-JG-115','RFID-JG-116','RFID-JG-117','RFID-JG-118','RFID-JG-119','RFID-JG-120','RFID-JG-121','RFID-JG-122','RFID-JG-123','RFID-JG-124','RFID-JG-125','RFID-JG-126','RFID-JG-127','RFID-JG-128','RFID-JG-129','RFID-JG-130','RFID-JG-131','RFID-JG-132','RFID-JG-133','RFID-JG-134','RFID-JG-135','RFID-JG-136','RFID-JG-137','RFID-JG-138','RFID-JG-139','RFID-JG-140','RFID-JG-141','RFID-JG-142','RFID-JG-143','RFID-JG-144','RFID-JG-145','RFID-JG-146','RFID-JG-147','RFID-JG-148','RFID-JG-149','RFID-JG-150','RFID-JG-151','RFID-JG-152','RFID-JG-153','RFID-JG-154','RFID-JG-155','RFID-JG-156','RFID-JG-157','RFID-JG-158','RFID-JG-159','RFID-JG-160','RFID-JG-161','RFID-JG-162','RFID-JG-163','RFID-JG-164','RFID-JG-165','RFID-JG-166','RFID-JG-167','RFID-JG-168','RFID-JG-169','RFID-JG-170','RFID-JG-171','RFID-JG-172','RFID-JG-173','RFID-JG-174','RFID-JG-175','RFID-JG-176','RFID-JG-177','RFID-JG-178','RFID-JG-179','RFID-JG-180','RFID-JG-181','RFID-JG-182','RFID-JG-183','RFID-JG-184','RFID-JG-185','RFID-JG-186','RFID-JG-187','RFID-JG-188','RFID-JG-189','RFID-JG-190','RFID-JG-191','RFID-JG-192','RFID-JG-193','RFID-JG-194','RFID-JG-195','RFID-JG-196','RFID-JG-197','RFID-JG-198','RFID-JG-199','RFID-JG-200'], actualRfidCodes: ['RFID-JG-001','RFID-JG-002','RFID-JG-003','RFID-JG-004','RFID-JG-005','RFID-JG-006','RFID-JG-007','RFID-JG-008','RFID-JG-009','RFID-JG-010','RFID-JG-011','RFID-JG-012','RFID-JG-013','RFID-JG-014','RFID-JG-015','RFID-JG-016','RFID-JG-017','RFID-JG-018','RFID-JG-019','RFID-JG-020','RFID-JG-021','RFID-JG-022','RFID-JG-023','RFID-JG-024','RFID-JG-025','RFID-JG-026','RFID-JG-027','RFID-JG-028','RFID-JG-029','RFID-JG-030','RFID-JG-031','RFID-JG-032','RFID-JG-033','RFID-JG-034','RFID-JG-035','RFID-JG-036','RFID-JG-037','RFID-JG-038','RFID-JG-039','RFID-JG-040','RFID-JG-041','RFID-JG-042','RFID-JG-043','RFID-JG-044','RFID-JG-045','RFID-JG-046','RFID-JG-047','RFID-JG-048','RFID-JG-049','RFID-JG-050','RFID-JG-051','RFID-JG-052','RFID-JG-053','RFID-JG-054','RFID-JG-055','RFID-JG-056','RFID-JG-057','RFID-JG-058','RFID-JG-059','RFID-JG-060','RFID-JG-061','RFID-JG-062','RFID-JG-063','RFID-JG-064','RFID-JG-065','RFID-JG-066','RFID-JG-067','RFID-JG-068','RFID-JG-069','RFID-JG-070','RFID-JG-071','RFID-JG-072','RFID-JG-073','RFID-JG-074','RFID-JG-075','RFID-JG-076','RFID-JG-077','RFID-JG-078','RFID-JG-079','RFID-JG-080','RFID-JG-081','RFID-JG-082','RFID-JG-083','RFID-JG-084','RFID-JG-085','RFID-JG-086','RFID-JG-087','RFID-JG-088','RFID-JG-089','RFID-JG-090','RFID-JG-091','RFID-JG-092','RFID-JG-093','RFID-JG-094','RFID-JG-095','RFID-JG-096','RFID-JG-097','RFID-JG-098','RFID-JG-099','RFID-JG-100','RFID-JG-101','RFID-JG-102','RFID-JG-103','RFID-JG-104','RFID-JG-105','RFID-JG-106','RFID-JG-107','RFID-JG-108','RFID-JG-109','RFID-JG-110','RFID-JG-111','RFID-JG-112','RFID-JG-113','RFID-JG-114','RFID-JG-115','RFID-JG-116','RFID-JG-117','RFID-JG-118','RFID-JG-119','RFID-JG-120','RFID-JG-121','RFID-JG-122','RFID-JG-123','RFID-JG-124','RFID-JG-125','RFID-JG-126','RFID-JG-127','RFID-JG-128','RFID-JG-129','RFID-JG-130','RFID-JG-131','RFID-JG-132','RFID-JG-133','RFID-JG-134','RFID-JG-135','RFID-JG-136','RFID-JG-137','RFID-JG-138','RFID-JG-139','RFID-JG-140','RFID-JG-141','RFID-JG-142','RFID-JG-143','RFID-JG-144','RFID-JG-145','RFID-JG-146','RFID-JG-147','RFID-JG-148','RFID-JG-149','RFID-JG-150','RFID-JG-151','RFID-JG-152','RFID-JG-153','RFID-JG-154','RFID-JG-155','RFID-JG-156','RFID-JG-157','RFID-JG-158','RFID-JG-159','RFID-JG-160','RFID-JG-161','RFID-JG-162','RFID-JG-163','RFID-JG-164','RFID-JG-165','RFID-JG-166','RFID-JG-167','RFID-JG-168','RFID-JG-169','RFID-JG-170','RFID-JG-171','RFID-JG-172','RFID-JG-173','RFID-JG-174','RFID-JG-175','RFID-JG-176','RFID-JG-177','RFID-JG-178','RFID-JG-179','RFID-JG-180','RFID-JG-181','RFID-JG-182','RFID-JG-183','RFID-JG-184','RFID-JG-185','RFID-JG-186','RFID-JG-187','RFID-JG-188','RFID-JG-189','RFID-JG-190','RFID-JG-191','RFID-JG-192','RFID-JG-193','RFID-JG-194','RFID-JG-195','RFID-JG-196','RFID-JG-197','RFID-JG-198','RFID-JG-199','RFID-JG-200'], purchaseQty: 500, deliveryQty: 200, unitPrice: 120, totalAmount: 24000, productionDate: '2026-02-15', validityMonths: 72, expiryDate: '2032-02-14', qualifiedQty: 200, unqualifiedQty: 0, inspectionOpinion: '全部合格', inspectionPhotos: [], inspectionStatus: 'qualified' },
    ],
  },
  {
    id: 'FH20260603003', orderName: '2026年头盔采购订单', contractNo: 'HT-2026-003',
    supplier: '某市防护科技集团', enterpriseCode: '91310000567890123X',
    equipmentSummary: '头盔x120, 反光背心x300',
    deliveryDate: '2026-06-04', receiver: 'YYY市公安局装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ006', category1: '防护装备', category2: '头部防护', category3: '头盔', name: '头盔', model: 'TK-M1', code: 'ZB-001-003', unit: '顶', isWholeBox: true, boxCode: 'BX-202606-005', rfidCodes: ['RFID-TK-001','RFID-TK-002','RFID-TK-003','RFID-TK-004','RFID-TK-005','RFID-TK-006','RFID-TK-007','RFID-TK-008','RFID-TK-009','RFID-TK-010','RFID-TK-011','RFID-TK-012','RFID-TK-013','RFID-TK-014','RFID-TK-015','RFID-TK-016','RFID-TK-017','RFID-TK-018','RFID-TK-019','RFID-TK-020','RFID-TK-021','RFID-TK-022','RFID-TK-023','RFID-TK-024','RFID-TK-025','RFID-TK-026','RFID-TK-027','RFID-TK-028','RFID-TK-029','RFID-TK-030','RFID-TK-031','RFID-TK-032','RFID-TK-033','RFID-TK-034','RFID-TK-035','RFID-TK-036','RFID-TK-037','RFID-TK-038','RFID-TK-039','RFID-TK-040','RFID-TK-041','RFID-TK-042','RFID-TK-043','RFID-TK-044','RFID-TK-045','RFID-TK-046','RFID-TK-047','RFID-TK-048','RFID-TK-049','RFID-TK-050','RFID-TK-051','RFID-TK-052','RFID-TK-053','RFID-TK-054','RFID-TK-055','RFID-TK-056','RFID-TK-057','RFID-TK-058','RFID-TK-059','RFID-TK-060','RFID-TK-061','RFID-TK-062','RFID-TK-063','RFID-TK-064','RFID-TK-065','RFID-TK-066','RFID-TK-067','RFID-TK-068','RFID-TK-069','RFID-TK-070','RFID-TK-071','RFID-TK-072','RFID-TK-073','RFID-TK-074','RFID-TK-075','RFID-TK-076','RFID-TK-077','RFID-TK-078','RFID-TK-079','RFID-TK-080','RFID-TK-081','RFID-TK-082','RFID-TK-083','RFID-TK-084','RFID-TK-085','RFID-TK-086','RFID-TK-087','RFID-TK-088','RFID-TK-089','RFID-TK-090','RFID-TK-091','RFID-TK-092','RFID-TK-093','RFID-TK-094','RFID-TK-095','RFID-TK-096','RFID-TK-097','RFID-TK-098','RFID-TK-099','RFID-TK-100','RFID-TK-101','RFID-TK-102','RFID-TK-103','RFID-TK-104','RFID-TK-105','RFID-TK-106','RFID-TK-107','RFID-TK-108','RFID-TK-109','RFID-TK-110','RFID-TK-111','RFID-TK-112','RFID-TK-113','RFID-TK-114','RFID-TK-115','RFID-TK-116','RFID-TK-117','RFID-TK-118','RFID-TK-119','RFID-TK-120'], actualRfidCodes: [], purchaseQty: 400, deliveryQty: 120, unitPrice: 680, totalAmount: 81600, productionDate: '2026-03-20', validityMonths: 60, expiryDate: '2031-03-19', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603004', orderName: '执法记录仪补货订单', contractNo: 'HT-2026-004',
    supplier: '某市智能装备有限公司', enterpriseCode: '91440000876543210X',
    equipmentSummary: '执法记录仪x50, 对讲机x80',
    deliveryDate: '2026-06-02', receiver: 'YYY市公安局装备处',
    status: 'inspected', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ008', category1: '通信装备', category2: '记录装备', category3: '执法记录仪', name: '执法记录仪', model: 'DSJ-A7', code: 'ZB-003-001', unit: '台', isWholeBox: false, boxCode: '', rfidCodes: ['RFID-DSJ-101','RFID-DSJ-102','RFID-DSJ-103','RFID-DSJ-104','RFID-DSJ-105','RFID-DSJ-106','RFID-DSJ-107','RFID-DSJ-108','RFID-DSJ-109','RFID-DSJ-110','RFID-DSJ-111','RFID-DSJ-112','RFID-DSJ-113','RFID-DSJ-114','RFID-DSJ-115','RFID-DSJ-116','RFID-DSJ-117','RFID-DSJ-118','RFID-DSJ-119','RFID-DSJ-120','RFID-DSJ-121','RFID-DSJ-122','RFID-DSJ-123','RFID-DSJ-124','RFID-DSJ-125','RFID-DSJ-126','RFID-DSJ-127','RFID-DSJ-128','RFID-DSJ-129','RFID-DSJ-130','RFID-DSJ-131','RFID-DSJ-132','RFID-DSJ-133','RFID-DSJ-134','RFID-DSJ-135','RFID-DSJ-136','RFID-DSJ-137','RFID-DSJ-138','RFID-DSJ-139','RFID-DSJ-140','RFID-DSJ-141','RFID-DSJ-142','RFID-DSJ-143','RFID-DSJ-144','RFID-DSJ-145','RFID-DSJ-146','RFID-DSJ-147','RFID-DSJ-148','RFID-DSJ-149','RFID-DSJ-150'], actualRfidCodes: [], purchaseQty: 100, deliveryQty: 50, unitPrice: 2800, totalAmount: 140000, productionDate: '2026-04-01', validityMonths: 36, expiryDate: '2029-03-31', qualifiedQty: 0, unqualifiedQty: 50, inspectionOpinion: '批次存在严重质量问题', inspectionPhotos: ['照片1','照片2'], inspectionStatus: 'return' },
    ],
  },
  {
    id: 'FH20260603006', orderName: '2026年约束带采购订单', contractNo: 'HT-2026-006',
    supplier: '某省警用器材厂', enterpriseCode: '91330000456789012X',
    equipmentSummary: '约束带x500, 警示桩x200',
    deliveryDate: '2026-06-04', receiver: 'YYY市公安局装备处',
    status: 'inspected', warehouseId: '9', warehouseName: 'YYY市局装备仓库', storageLocation: 'XXX省公安厅/YYY市公安局/ZZZ区公安分局',
    equipments: [
      { id: 'EQ011', category1: '警械装备', category2: '约束装备', category3: '约束带', name: '约束带', model: 'YS-D500', code: 'ZB-002-003', unit: '条', isWholeBox: true, boxCode: 'BX-202606-008', rfidCodes: ['RFID-YS-001','RFID-YS-002','RFID-YS-003','RFID-YS-004','RFID-YS-005','RFID-YS-006','RFID-YS-007','RFID-YS-008','RFID-YS-009','RFID-YS-010','RFID-YS-011','RFID-YS-012','RFID-YS-013','RFID-YS-014','RFID-YS-015','RFID-YS-016','RFID-YS-017','RFID-YS-018','RFID-YS-019','RFID-YS-020','RFID-YS-021','RFID-YS-022','RFID-YS-023','RFID-YS-024','RFID-YS-025','RFID-YS-026','RFID-YS-027','RFID-YS-028','RFID-YS-029','RFID-YS-030','RFID-YS-031','RFID-YS-032','RFID-YS-033','RFID-YS-034','RFID-YS-035','RFID-YS-036','RFID-YS-037','RFID-YS-038','RFID-YS-039','RFID-YS-040','RFID-YS-041','RFID-YS-042','RFID-YS-043','RFID-YS-044','RFID-YS-045','RFID-YS-046','RFID-YS-047','RFID-YS-048','RFID-YS-049','RFID-YS-050','RFID-YS-051','RFID-YS-052','RFID-YS-053','RFID-YS-054','RFID-YS-055','RFID-YS-056','RFID-YS-057','RFID-YS-058','RFID-YS-059','RFID-YS-060','RFID-YS-061','RFID-YS-062','RFID-YS-063','RFID-YS-064','RFID-YS-065','RFID-YS-066','RFID-YS-067','RFID-YS-068','RFID-YS-069','RFID-YS-070','RFID-YS-071','RFID-YS-072','RFID-YS-073','RFID-YS-074','RFID-YS-075','RFID-YS-076','RFID-YS-077','RFID-YS-078','RFID-YS-079','RFID-YS-080','RFID-YS-081','RFID-YS-082','RFID-YS-083','RFID-YS-084','RFID-YS-085','RFID-YS-086','RFID-YS-087','RFID-YS-088','RFID-YS-089','RFID-YS-090','RFID-YS-091','RFID-YS-092','RFID-YS-093','RFID-YS-094','RFID-YS-095','RFID-YS-096','RFID-YS-097','RFID-YS-098','RFID-YS-099','RFID-YS-100','RFID-YS-101','RFID-YS-102','RFID-YS-103','RFID-YS-104','RFID-YS-105','RFID-YS-106','RFID-YS-107','RFID-YS-108','RFID-YS-109','RFID-YS-110','RFID-YS-111','RFID-YS-112','RFID-YS-113','RFID-YS-114','RFID-YS-115','RFID-YS-116','RFID-YS-117','RFID-YS-118','RFID-YS-119','RFID-YS-120','RFID-YS-121','RFID-YS-122','RFID-YS-123','RFID-YS-124','RFID-YS-125','RFID-YS-126','RFID-YS-127','RFID-YS-128','RFID-YS-129','RFID-YS-130','RFID-YS-131','RFID-YS-132','RFID-YS-133','RFID-YS-134','RFID-YS-135','RFID-YS-136','RFID-YS-137','RFID-YS-138','RFID-YS-139','RFID-YS-140','RFID-YS-141','RFID-YS-142','RFID-YS-143','RFID-YS-144','RFID-YS-145','RFID-YS-146','RFID-YS-147','RFID-YS-148','RFID-YS-149','RFID-YS-150','RFID-YS-151','RFID-YS-152','RFID-YS-153','RFID-YS-154','RFID-YS-155','RFID-YS-156','RFID-YS-157','RFID-YS-158','RFID-YS-159','RFID-YS-160','RFID-YS-161','RFID-YS-162','RFID-YS-163','RFID-YS-164','RFID-YS-165','RFID-YS-166','RFID-YS-167','RFID-YS-168','RFID-YS-169','RFID-YS-170','RFID-YS-171','RFID-YS-172','RFID-YS-173','RFID-YS-174','RFID-YS-175','RFID-YS-176','RFID-YS-177','RFID-YS-178','RFID-YS-179','RFID-YS-180','RFID-YS-181','RFID-YS-182','RFID-YS-183','RFID-YS-184','RFID-YS-185','RFID-YS-186','RFID-YS-187','RFID-YS-188','RFID-YS-189','RFID-YS-190','RFID-YS-191','RFID-YS-192','RFID-YS-193','RFID-YS-194','RFID-YS-195','RFID-YS-196','RFID-YS-197','RFID-YS-198','RFID-YS-199','RFID-YS-200','RFID-YS-201','RFID-YS-202','RFID-YS-203','RFID-YS-204','RFID-YS-205','RFID-YS-206','RFID-YS-207','RFID-YS-208','RFID-YS-209','RFID-YS-210','RFID-YS-211','RFID-YS-212','RFID-YS-213','RFID-YS-214','RFID-YS-215','RFID-YS-216','RFID-YS-217','RFID-YS-218','RFID-YS-219','RFID-YS-220','RFID-YS-221','RFID-YS-222','RFID-YS-223','RFID-YS-224','RFID-YS-225','RFID-YS-226','RFID-YS-227','RFID-YS-228','RFID-YS-229','RFID-YS-230','RFID-YS-231','RFID-YS-232','RFID-YS-233','RFID-YS-234','RFID-YS-235','RFID-YS-236','RFID-YS-237','RFID-YS-238','RFID-YS-239','RFID-YS-240','RFID-YS-241','RFID-YS-242','RFID-YS-243','RFID-YS-244','RFID-YS-245','RFID-YS-246','RFID-YS-247','RFID-YS-248','RFID-YS-249','RFID-YS-250','RFID-YS-251','RFID-YS-252','RFID-YS-253','RFID-YS-254','RFID-YS-255','RFID-YS-256','RFID-YS-257','RFID-YS-258','RFID-YS-259','RFID-YS-260','RFID-YS-261','RFID-YS-262','RFID-YS-263','RFID-YS-264','RFID-YS-265','RFID-YS-266','RFID-YS-267','RFID-YS-268','RFID-YS-269','RFID-YS-270','RFID-YS-271','RFID-YS-272','RFID-YS-273','RFID-YS-274','RFID-YS-275','RFID-YS-276','RFID-YS-277','RFID-YS-278','RFID-YS-279','RFID-YS-280','RFID-YS-281','RFID-YS-282','RFID-YS-283','RFID-YS-284','RFID-YS-285','RFID-YS-286','RFID-YS-287','RFID-YS-288','RFID-YS-289','RFID-YS-290','RFID-YS-291','RFID-YS-292','RFID-YS-293','RFID-YS-294','RFID-YS-295','RFID-YS-296','RFID-YS-297','RFID-YS-298','RFID-YS-299','RFID-YS-300','RFID-YS-301','RFID-YS-302','RFID-YS-303','RFID-YS-304','RFID-YS-305','RFID-YS-306','RFID-YS-307','RFID-YS-308','RFID-YS-309','RFID-YS-310','RFID-YS-311','RFID-YS-312','RFID-YS-313','RFID-YS-314','RFID-YS-315','RFID-YS-316','RFID-YS-317','RFID-YS-318','RFID-YS-319','RFID-YS-320','RFID-YS-321','RFID-YS-322','RFID-YS-323','RFID-YS-324','RFID-YS-325','RFID-YS-326','RFID-YS-327','RFID-YS-328','RFID-YS-329','RFID-YS-330','RFID-YS-331','RFID-YS-332','RFID-YS-333','RFID-YS-334','RFID-YS-335','RFID-YS-336','RFID-YS-337','RFID-YS-338','RFID-YS-339','RFID-YS-340','RFID-YS-341','RFID-YS-342','RFID-YS-343','RFID-YS-344','RFID-YS-345','RFID-YS-346','RFID-YS-347','RFID-YS-348','RFID-YS-349','RFID-YS-350','RFID-YS-351','RFID-YS-352','RFID-YS-353','RFID-YS-354','RFID-YS-355','RFID-YS-356','RFID-YS-357','RFID-YS-358','RFID-YS-359','RFID-YS-360','RFID-YS-361','RFID-YS-362','RFID-YS-363','RFID-YS-364','RFID-YS-365','RFID-YS-366','RFID-YS-367','RFID-YS-368','RFID-YS-369','RFID-YS-370','RFID-YS-371','RFID-YS-372','RFID-YS-373','RFID-YS-374','RFID-YS-375','RFID-YS-376','RFID-YS-377','RFID-YS-378','RFID-YS-379','RFID-YS-380','RFID-YS-381','RFID-YS-382','RFID-YS-383','RFID-YS-384','RFID-YS-385','RFID-YS-386','RFID-YS-387','RFID-YS-388','RFID-YS-389','RFID-YS-390','RFID-YS-391','RFID-YS-392','RFID-YS-393','RFID-YS-394','RFID-YS-395','RFID-YS-396','RFID-YS-397','RFID-YS-398','RFID-YS-399','RFID-YS-400','RFID-YS-401','RFID-YS-402','RFID-YS-403','RFID-YS-404','RFID-YS-405','RFID-YS-406','RFID-YS-407','RFID-YS-408','RFID-YS-409','RFID-YS-410','RFID-YS-411','RFID-YS-412','RFID-YS-413','RFID-YS-414','RFID-YS-415','RFID-YS-416','RFID-YS-417','RFID-YS-418','RFID-YS-419','RFID-YS-420','RFID-YS-421','RFID-YS-422','RFID-YS-423','RFID-YS-424','RFID-YS-425','RFID-YS-426','RFID-YS-427','RFID-YS-428','RFID-YS-429','RFID-YS-430','RFID-YS-431','RFID-YS-432','RFID-YS-433','RFID-YS-434','RFID-YS-435','RFID-YS-436','RFID-YS-437','RFID-YS-438','RFID-YS-439','RFID-YS-440','RFID-YS-441','RFID-YS-442','RFID-YS-443','RFID-YS-444','RFID-YS-445','RFID-YS-446','RFID-YS-447','RFID-YS-448','RFID-YS-449','RFID-YS-450','RFID-YS-451','RFID-YS-452','RFID-YS-453','RFID-YS-454','RFID-YS-455','RFID-YS-456','RFID-YS-457','RFID-YS-458','RFID-YS-459','RFID-YS-460','RFID-YS-461','RFID-YS-462','RFID-YS-463','RFID-YS-464','RFID-YS-465','RFID-YS-466','RFID-YS-467','RFID-YS-468','RFID-YS-469','RFID-YS-470','RFID-YS-471','RFID-YS-472','RFID-YS-473','RFID-YS-474','RFID-YS-475','RFID-YS-476','RFID-YS-477','RFID-YS-478','RFID-YS-479','RFID-YS-480','RFID-YS-481','RFID-YS-482','RFID-YS-483','RFID-YS-484','RFID-YS-485','RFID-YS-486','RFID-YS-487','RFID-YS-488','RFID-YS-489','RFID-YS-490','RFID-YS-491','RFID-YS-492','RFID-YS-493','RFID-YS-494','RFID-YS-495','RFID-YS-496','RFID-YS-497','RFID-YS-498','RFID-YS-499','RFID-YS-500'], actualRfidCodes: ['RFID-YS-001','RFID-YS-002','RFID-YS-003','RFID-YS-004','RFID-YS-005','RFID-YS-006','RFID-YS-007','RFID-YS-008','RFID-YS-009','RFID-YS-010','RFID-YS-011','RFID-YS-012','RFID-YS-013','RFID-YS-014','RFID-YS-015','RFID-YS-016','RFID-YS-017','RFID-YS-018','RFID-YS-019','RFID-YS-020','RFID-YS-021','RFID-YS-022','RFID-YS-023','RFID-YS-024','RFID-YS-025','RFID-YS-026','RFID-YS-027','RFID-YS-028','RFID-YS-029','RFID-YS-030','RFID-YS-031','RFID-YS-032','RFID-YS-033','RFID-YS-034','RFID-YS-035','RFID-YS-036','RFID-YS-037','RFID-YS-038','RFID-YS-039','RFID-YS-040','RFID-YS-041','RFID-YS-042','RFID-YS-043','RFID-YS-044','RFID-YS-045','RFID-YS-046','RFID-YS-047','RFID-YS-048','RFID-YS-049','RFID-YS-050','RFID-YS-051','RFID-YS-052','RFID-YS-053','RFID-YS-054','RFID-YS-055','RFID-YS-056','RFID-YS-057','RFID-YS-058','RFID-YS-059','RFID-YS-060','RFID-YS-061','RFID-YS-062','RFID-YS-063','RFID-YS-064','RFID-YS-065','RFID-YS-066','RFID-YS-067','RFID-YS-068','RFID-YS-069','RFID-YS-070','RFID-YS-071','RFID-YS-072','RFID-YS-073','RFID-YS-074','RFID-YS-075','RFID-YS-076','RFID-YS-077','RFID-YS-078','RFID-YS-079','RFID-YS-080','RFID-YS-081','RFID-YS-082','RFID-YS-083','RFID-YS-084','RFID-YS-085','RFID-YS-086','RFID-YS-087','RFID-YS-088','RFID-YS-089','RFID-YS-090','RFID-YS-091','RFID-YS-092','RFID-YS-093','RFID-YS-094','RFID-YS-095','RFID-YS-096','RFID-YS-097','RFID-YS-098','RFID-YS-099','RFID-YS-100','RFID-YS-101','RFID-YS-102','RFID-YS-103','RFID-YS-104','RFID-YS-105','RFID-YS-106','RFID-YS-107','RFID-YS-108','RFID-YS-109','RFID-YS-110','RFID-YS-111','RFID-YS-112','RFID-YS-113','RFID-YS-114','RFID-YS-115','RFID-YS-116','RFID-YS-117','RFID-YS-118','RFID-YS-119','RFID-YS-120','RFID-YS-121','RFID-YS-122','RFID-YS-123','RFID-YS-124','RFID-YS-125','RFID-YS-126','RFID-YS-127','RFID-YS-128','RFID-YS-129','RFID-YS-130','RFID-YS-131','RFID-YS-132','RFID-YS-133','RFID-YS-134','RFID-YS-135','RFID-YS-136','RFID-YS-137','RFID-YS-138','RFID-YS-139','RFID-YS-140','RFID-YS-141','RFID-YS-142','RFID-YS-143','RFID-YS-144','RFID-YS-145','RFID-YS-146','RFID-YS-147','RFID-YS-148','RFID-YS-149','RFID-YS-150','RFID-YS-151','RFID-YS-152','RFID-YS-153','RFID-YS-154','RFID-YS-155','RFID-YS-156','RFID-YS-157','RFID-YS-158','RFID-YS-159','RFID-YS-160','RFID-YS-161','RFID-YS-162','RFID-YS-163','RFID-YS-164','RFID-YS-165','RFID-YS-166','RFID-YS-167','RFID-YS-168','RFID-YS-169','RFID-YS-170','RFID-YS-171','RFID-YS-172','RFID-YS-173','RFID-YS-174','RFID-YS-175','RFID-YS-176','RFID-YS-177','RFID-YS-178','RFID-YS-179','RFID-YS-180','RFID-YS-181','RFID-YS-182','RFID-YS-183','RFID-YS-184','RFID-YS-185','RFID-YS-186','RFID-YS-187','RFID-YS-188','RFID-YS-189','RFID-YS-190','RFID-YS-191','RFID-YS-192','RFID-YS-193','RFID-YS-194','RFID-YS-195','RFID-YS-196','RFID-YS-197','RFID-YS-198','RFID-YS-199','RFID-YS-200','RFID-YS-201','RFID-YS-202','RFID-YS-203','RFID-YS-204','RFID-YS-205','RFID-YS-206','RFID-YS-207','RFID-YS-208','RFID-YS-209','RFID-YS-210','RFID-YS-211','RFID-YS-212','RFID-YS-213','RFID-YS-214','RFID-YS-215','RFID-YS-216','RFID-YS-217','RFID-YS-218','RFID-YS-219','RFID-YS-220','RFID-YS-221','RFID-YS-222','RFID-YS-223','RFID-YS-224','RFID-YS-225','RFID-YS-226','RFID-YS-227','RFID-YS-228','RFID-YS-229','RFID-YS-230','RFID-YS-231','RFID-YS-232','RFID-YS-233','RFID-YS-234','RFID-YS-235','RFID-YS-236','RFID-YS-237','RFID-YS-238','RFID-YS-239','RFID-YS-240','RFID-YS-241','RFID-YS-242','RFID-YS-243','RFID-YS-244','RFID-YS-245','RFID-YS-246','RFID-YS-247','RFID-YS-248','RFID-YS-249','RFID-YS-250','RFID-YS-251','RFID-YS-252','RFID-YS-253','RFID-YS-254','RFID-YS-255','RFID-YS-256','RFID-YS-257','RFID-YS-258','RFID-YS-259','RFID-YS-260','RFID-YS-261','RFID-YS-262','RFID-YS-263','RFID-YS-264','RFID-YS-265','RFID-YS-266','RFID-YS-267','RFID-YS-268','RFID-YS-269','RFID-YS-270','RFID-YS-271','RFID-YS-272','RFID-YS-273','RFID-YS-274','RFID-YS-275','RFID-YS-276','RFID-YS-277','RFID-YS-278','RFID-YS-279','RFID-YS-280','RFID-YS-281','RFID-YS-282','RFID-YS-283','RFID-YS-284','RFID-YS-285','RFID-YS-286','RFID-YS-287','RFID-YS-288','RFID-YS-289','RFID-YS-290','RFID-YS-291','RFID-YS-292','RFID-YS-293','RFID-YS-294','RFID-YS-295'], purchaseQty: 1000, deliveryQty: 500, unitPrice: 35, totalAmount: 17500, productionDate: '2026-02-01', validityMonths: 36, expiryDate: '2029-01-31', qualifiedQty: 495, unqualifiedQty: 5, inspectionOpinion: '5条有轻微色差', inspectionPhotos: [], inspectionStatus: 'unqualified' },
    ],
  },
  {
    id: 'FH20260603007', orderName: '2026年防暴装备采购订单', contractNo: 'HT-2026-007',
    supplier: '某市安防设备公司', enterpriseCode: '91500000345678901X',
    equipmentSummary: '防弹盾牌x30, 防暴服x40',
    deliveryDate: '2026-06-06', receiver: 'XXX省公安厅装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ013', category1: '防护装备', category2: '防暴装备', category3: '防弹盾牌', name: '防弹盾牌', model: 'FD-DP30', code: 'ZB-001-004', unit: '面', isWholeBox: true, boxCode: 'BX-202606-010', rfidCodes: ['RFID-FD-001','RFID-FD-002','RFID-FD-003','RFID-FD-004','RFID-FD-005','RFID-FD-006','RFID-FD-007','RFID-FD-008','RFID-FD-009','RFID-FD-010','RFID-FD-011','RFID-FD-012','RFID-FD-013','RFID-FD-014','RFID-FD-015','RFID-FD-016','RFID-FD-017','RFID-FD-018','RFID-FD-019','RFID-FD-020','RFID-FD-021','RFID-FD-022','RFID-FD-023','RFID-FD-024','RFID-FD-025','RFID-FD-026','RFID-FD-027','RFID-FD-028','RFID-FD-029','RFID-FD-030'], actualRfidCodes: [], purchaseQty: 100, deliveryQty: 30, unitPrice: 3500, totalAmount: 105000, productionDate: '2026-04-15', validityMonths: 72, expiryDate: '2032-04-14', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
  {
    id: 'FH20260603008', orderName: '2026年防护用品采购订单', contractNo: 'HT-2026-008',
    supplier: '某市防护用品有限公司', enterpriseCode: '91120000234567890X',
    equipmentSummary: '防割手套x300, 警用腰带x250',
    deliveryDate: '2026-06-02', receiver: 'YYY市公安局装备处',
    status: 'pending-receipt', warehouseId: null, warehouseName: null, storageLocation: null,
    equipments: [
      { id: 'EQ014', category1: '防护装备', category2: '手部防护', category3: '防割手套', name: '防割手套', model: 'FG-ST5', code: 'ZB-001-005', unit: '双', isWholeBox: true, boxCode: 'BX-202606-011', rfidCodes: ['RFID-FG-001','RFID-FG-002','RFID-FG-003','RFID-FG-004','RFID-FG-005','RFID-FG-006','RFID-FG-007','RFID-FG-008','RFID-FG-009','RFID-FG-010','RFID-FG-011','RFID-FG-012','RFID-FG-013','RFID-FG-014','RFID-FG-015','RFID-FG-016','RFID-FG-017','RFID-FG-018','RFID-FG-019','RFID-FG-020','RFID-FG-021','RFID-FG-022','RFID-FG-023','RFID-FG-024','RFID-FG-025','RFID-FG-026','RFID-FG-027','RFID-FG-028','RFID-FG-029','RFID-FG-030','RFID-FG-031','RFID-FG-032','RFID-FG-033','RFID-FG-034','RFID-FG-035','RFID-FG-036','RFID-FG-037','RFID-FG-038','RFID-FG-039','RFID-FG-040','RFID-FG-041','RFID-FG-042','RFID-FG-043','RFID-FG-044','RFID-FG-045','RFID-FG-046','RFID-FG-047','RFID-FG-048','RFID-FG-049','RFID-FG-050','RFID-FG-051','RFID-FG-052','RFID-FG-053','RFID-FG-054','RFID-FG-055','RFID-FG-056','RFID-FG-057','RFID-FG-058','RFID-FG-059','RFID-FG-060','RFID-FG-061','RFID-FG-062','RFID-FG-063','RFID-FG-064','RFID-FG-065','RFID-FG-066','RFID-FG-067','RFID-FG-068','RFID-FG-069','RFID-FG-070','RFID-FG-071','RFID-FG-072','RFID-FG-073','RFID-FG-074','RFID-FG-075','RFID-FG-076','RFID-FG-077','RFID-FG-078','RFID-FG-079','RFID-FG-080','RFID-FG-081','RFID-FG-082','RFID-FG-083','RFID-FG-084','RFID-FG-085','RFID-FG-086','RFID-FG-087','RFID-FG-088','RFID-FG-089','RFID-FG-090','RFID-FG-091','RFID-FG-092','RFID-FG-093','RFID-FG-094','RFID-FG-095','RFID-FG-096','RFID-FG-097','RFID-FG-098','RFID-FG-099','RFID-FG-100','RFID-FG-101','RFID-FG-102','RFID-FG-103','RFID-FG-104','RFID-FG-105','RFID-FG-106','RFID-FG-107','RFID-FG-108','RFID-FG-109','RFID-FG-110','RFID-FG-111','RFID-FG-112','RFID-FG-113','RFID-FG-114','RFID-FG-115','RFID-FG-116','RFID-FG-117','RFID-FG-118','RFID-FG-119','RFID-FG-120','RFID-FG-121','RFID-FG-122','RFID-FG-123','RFID-FG-124','RFID-FG-125','RFID-FG-126','RFID-FG-127','RFID-FG-128','RFID-FG-129','RFID-FG-130','RFID-FG-131','RFID-FG-132','RFID-FG-133','RFID-FG-134','RFID-FG-135','RFID-FG-136','RFID-FG-137','RFID-FG-138','RFID-FG-139','RFID-FG-140','RFID-FG-141','RFID-FG-142','RFID-FG-143','RFID-FG-144','RFID-FG-145','RFID-FG-146','RFID-FG-147','RFID-FG-148','RFID-FG-149','RFID-FG-150','RFID-FG-151','RFID-FG-152','RFID-FG-153','RFID-FG-154','RFID-FG-155','RFID-FG-156','RFID-FG-157','RFID-FG-158','RFID-FG-159','RFID-FG-160','RFID-FG-161','RFID-FG-162','RFID-FG-163','RFID-FG-164','RFID-FG-165','RFID-FG-166','RFID-FG-167','RFID-FG-168','RFID-FG-169','RFID-FG-170','RFID-FG-171','RFID-FG-172','RFID-FG-173','RFID-FG-174','RFID-FG-175','RFID-FG-176','RFID-FG-177','RFID-FG-178','RFID-FG-179','RFID-FG-180','RFID-FG-181','RFID-FG-182','RFID-FG-183','RFID-FG-184','RFID-FG-185','RFID-FG-186','RFID-FG-187','RFID-FG-188','RFID-FG-189','RFID-FG-190','RFID-FG-191','RFID-FG-192','RFID-FG-193','RFID-FG-194','RFID-FG-195','RFID-FG-196','RFID-FG-197','RFID-FG-198','RFID-FG-199','RFID-FG-200','RFID-FG-201','RFID-FG-202','RFID-FG-203','RFID-FG-204','RFID-FG-205','RFID-FG-206','RFID-FG-207','RFID-FG-208','RFID-FG-209','RFID-FG-210','RFID-FG-211','RFID-FG-212','RFID-FG-213','RFID-FG-214','RFID-FG-215','RFID-FG-216','RFID-FG-217','RFID-FG-218','RFID-FG-219','RFID-FG-220','RFID-FG-221','RFID-FG-222','RFID-FG-223','RFID-FG-224','RFID-FG-225','RFID-FG-226','RFID-FG-227','RFID-FG-228','RFID-FG-229','RFID-FG-230','RFID-FG-231','RFID-FG-232','RFID-FG-233','RFID-FG-234','RFID-FG-235','RFID-FG-236','RFID-FG-237','RFID-FG-238','RFID-FG-239','RFID-FG-240','RFID-FG-241','RFID-FG-242','RFID-FG-243','RFID-FG-244','RFID-FG-245','RFID-FG-246','RFID-FG-247','RFID-FG-248','RFID-FG-249','RFID-FG-250','RFID-FG-251','RFID-FG-252','RFID-FG-253','RFID-FG-254','RFID-FG-255','RFID-FG-256','RFID-FG-257','RFID-FG-258','RFID-FG-259','RFID-FG-260','RFID-FG-261','RFID-FG-262','RFID-FG-263','RFID-FG-264','RFID-FG-265','RFID-FG-266','RFID-FG-267','RFID-FG-268','RFID-FG-269','RFID-FG-270','RFID-FG-271','RFID-FG-272','RFID-FG-273','RFID-FG-274','RFID-FG-275','RFID-FG-276','RFID-FG-277','RFID-FG-278','RFID-FG-279','RFID-FG-280','RFID-FG-281','RFID-FG-282','RFID-FG-283','RFID-FG-284','RFID-FG-285','RFID-FG-286','RFID-FG-287','RFID-FG-288','RFID-FG-289','RFID-FG-290','RFID-FG-291','RFID-FG-292','RFID-FG-293','RFID-FG-294','RFID-FG-295','RFID-FG-296','RFID-FG-297','RFID-FG-298','RFID-FG-299','RFID-FG-300'], actualRfidCodes: [], purchaseQty: 600, deliveryQty: 300, unitPrice: 128, totalAmount: 38400, productionDate: '2026-03-01', validityMonths: 36, expiryDate: '2029-02-28', qualifiedQty: null, unqualifiedQty: null, inspectionOpinion: '', inspectionPhotos: [], inspectionStatus: 'pending' },
    ],
  },
]

/* ═══════════════════════════════════════════
   Mock 数据：期初入库
   ═══════════════════════════════════════════ */

const initialData: InitialRecord[] = [
  { id: 'QC20260601001', source: '期初入库', materialSource: '历史库存导入', storageLocation: 'XXX省公安厅', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 200, inboundDate: '2026-06-01', inboundBy: '王管理员', status: 'stored' },
  { id: 'QC20260601002', source: '期初入库', materialSource: '历史库存导入', storageLocation: 'YYY市公安局', equipmentName: '手铐', model: 'SK-STD', quantity: 500, inboundDate: '2026-06-01', inboundBy: '李管理员', status: 'stored' },
  { id: 'QC20260601003', source: '期初入库', materialSource: '手动录入', storageLocation: 'YYY市公安局', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 150, inboundDate: '2026-06-03', inboundBy: '张管理员', status: 'recorded' },
  { id: 'QC20260601004', source: '期初入库', materialSource: '历史库存导入', storageLocation: 'ZZZ区公安分局', equipmentName: '防刺服', model: 'FCF-II', quantity: 300, inboundDate: '2026-06-01', inboundBy: '赵管理员', status: 'stored' },
  { id: 'QC20260601005', source: '期初入库', materialSource: '手动录入', storageLocation: 'ZZZ区公安分局', equipmentName: '警棍', model: 'JG-TELE', quantity: 800, inboundDate: '2026-06-03', inboundBy: '刘管理员', status: 'recorded' },
  { id: 'QC20260601006', source: '期初入库', materialSource: '历史库存导入', storageLocation: 'YYY市公安局', equipmentName: '头盔', model: 'TK-M1', quantity: 400, inboundDate: '2026-06-02', inboundBy: '陈管理员', status: 'stored' },
]

/* ═══════════════════════════════════════════
   Mock 数据：仓库调拨入库
   ═══════════════════════════════════════════ */

const transferData: TransferRecord[] = [
  { id: 'DB20260603001', source: '仓库调拨入库', materialSource: '同步订单', transferOrderNo: 'DD20260601001', senderUnit: '某市总仓', storageLocation: 'XXX省公安厅', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 100, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'DB20260603002', source: '仓库调拨入库', materialSource: '手动添加', transferOrderNo: 'DD20260601002', senderUnit: '某市分仓', storageLocation: 'YYY市公安局', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 50, inboundDate: '2026-06-03', inboundBy: '李管理员', status: 'recorded' },
  { id: 'DB20260603003', source: '仓库调拨入库', materialSource: '同步订单', transferOrderNo: 'DD20260601003', senderUnit: '某市分仓', storageLocation: 'YYY市公安局', equipmentName: '防刺服', model: 'FCF-II', quantity: 80, inboundDate: '2026-06-02', inboundBy: '张管理员', status: 'stored' },
  { id: 'DB20260603004', source: '仓库调拨入库', materialSource: '手动添加', transferOrderNo: '-', senderUnit: '某市分仓', storageLocation: 'YYY市公安局', equipmentName: '警棍', model: 'JG-TELE', quantity: 200, inboundDate: '2026-06-04', inboundBy: '赵管理员', status: 'recorded' },
]

/* ═══════════════════════════════════════════
   Mock 数据：归还入库
   ═══════════════════════════════════════════ */

const returnData: ReturnRecord[] = [
  { id: 'GH20260603001', source: '归还入库', materialSource: '借用归还', borrower: '张警官/刑侦支队', borrowDate: '2026-05-20', expectedReturnDate: '2026-06-20', borrowOrderNo: 'JY20260601001', storageLocation: 'XXX省公安厅', equipmentName: '执法记录仪', model: 'DSJ-A7', quantity: 2, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'GH20260603002', source: '归还入库', materialSource: '借用归还', borrower: '李警官/交警支队', borrowDate: '2026-05-25', expectedReturnDate: '2026-06-25', borrowOrderNo: 'JY20260601002', storageLocation: 'YYY市公安局', equipmentName: '对讲机', model: 'DJ-T80', quantity: 5, inboundDate: '2026-06-03', inboundBy: '李管理员', status: 'stored' },
  { id: 'GH20260603003', source: '归还入库', materialSource: '借用归还', borrower: '王警官/治安支队', borrowDate: '2026-05-28', expectedReturnDate: '2026-06-28', borrowOrderNo: 'JY20260601003', storageLocation: 'YYY市公安局', equipmentName: '防弹背心', model: 'FD-BX-III', quantity: 10, inboundDate: '2026-06-04', inboundBy: '张管理员', status: 'recorded' },
  { id: 'GH20260603004', source: '归还入库', materialSource: '借用归还', borrower: '赵警官/特警支队', borrowDate: '2026-05-30', expectedReturnDate: '2026-06-30', borrowOrderNo: 'JY20260601004', storageLocation: 'YYY市公安局', equipmentName: '头盔', model: 'TK-M1', quantity: 15, inboundDate: '2026-06-04', inboundBy: '赵管理员', status: 'recorded' },
]

/* ═══════════════════════════════════════════
   Mock 数据：其他入库
   ═══════════════════════════════════════════ */

const otherData: OtherRecord[] = [
  { id: 'QT20260603001', source: '其他入库', materialSource: '捐赠', storageLocation: 'XXX省公安厅', equipmentName: '应急照明灯', model: 'YD-ZM100', quantity: 50, inboundDate: '2026-06-03', inboundBy: '王管理员', status: 'stored' },
  { id: 'QT20260603002', source: '其他入库', materialSource: '调配', storageLocation: 'YYY市公安局', equipmentName: '急救包', model: 'JJ-B20', quantity: 100, inboundDate: '2026-06-04', inboundBy: '李管理员', status: 'recorded' },
  { id: 'QT20260603003', source: '其他入库', materialSource: '自制', storageLocation: 'YYY市公安局', equipmentName: '喊话器', model: 'HH-Q50', quantity: 30, inboundDate: '2026-06-02', inboundBy: '张管理员', status: 'stored' },
]

/* ═══════════════════════════════════════════
   组织架构树组件
   ═══════════════════════════════════════════ */

function OrgTreeNode({ node, selectedId, onSelect, expandedIds, onToggleExpand }: { node: OrgNode; selectedId: string | null; onSelect: (id: string) => void; expandedIds: Set<string>; onToggleExpand: (id: string) => void }) {
  const isExpanded = expandedIds.has(node.id), hasChildren = node.children && node.children.length > 0
  const levelNames = ['省', '市', '县', '所'], levelColors = ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6']
  return <div><div className={cn('flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition', selectedId === node.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')} style={{ paddingLeft: `${8 + node.level * 16}px` }} onClick={() => { onSelect(node.id); if (hasChildren) onToggleExpand(node.id) }}>{hasChildren ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />) : <span className="w-3.5" />}<span className="mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white" style={{ backgroundColor: levelColors[node.level] || '#6B7280' }}>{levelNames[node.level] || '?'}</span><span className="truncate">{node.name}</span></div>{hasChildren && isExpanded && <div>{node.children!.map((c) => <OrgTreeNode key={c.id} node={c} selectedId={selectedId} onSelect={onSelect} expandedIds={expandedIds} onToggleExpand={onToggleExpand} />)}</div>}</div>
}

/* ═══════════════════════════════════════════
   存储位置选择组件
   ═══════════════════════════════════════════ */

function StorageLocationSelector({ value, onChange }: { value: string | null; onChange: (loc: string) => void }) {
  const [showPicker, setShowPicker] = useState(false)
  const [selectedOrgId, setSelectedOrgId] = useState<string | null>(null)
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['h1']))
  const [selectedWhId, setSelectedWhId] = useState<string | null>(null)
  const [selectedZoneId, setSelectedZoneId] = useState<string | null>(null)
  const [zoneExpandedIds, setZoneExpandedIds] = useState<Set<string>>(new Set())

  const toggleExpand = (id: string) => { setExpandedIds(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n }) }
  const toggleZoneExpand = (id: string) => { setZoneExpandedIds(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n }) }

  const getOrgPath = (nodes: OrgNode[], targetId: string, path: string[] = []): string[] | null => {
    for (const n of nodes) {
      if (n.id === targetId) return [...path, n.name]
      if (n.children) {
        const result = getOrgPath(n.children, targetId, [...path, n.name])
        if (result) return result
      }
    }
    return null
  }

  const selectedOrgPath = selectedOrgId ? getOrgPath(orgTree, selectedOrgId) : null
  const selectedWh = selectedWhId ? warehouseList.find(w => w.id === selectedWhId) : null
  const selectedZone = selectedWh?.zones?.find(z => z.id === selectedZoneId)

  const displayText = value || (selectedWh ? (selectedZone ? `${selectedWh.name} / ${selectedZone.name}` : selectedWh.name) : (selectedOrgPath ? selectedOrgPath.join('/') : '')) || '请选择存储位置'

  const handleConfirm = () => {
    if (selectedWh) {
      const loc = selectedZone ? `${selectedWh.name} / ${selectedZone.name}` : selectedWh.name
      onChange(loc)
    } else if (selectedOrgPath) {
      onChange(selectedOrgPath.join('/'))
    }
    setShowPicker(false)
  }

  const handleSelectWh = (whId: string) => {
    setSelectedWhId(selectedWhId === whId ? null : whId)
    setSelectedZoneId(null)
    setZoneExpandedIds(new Set())
  }

  const filteredWarehouses = warehouseList.filter(w => {
    if (!selectedOrgId) return true
    const orgPath = getOrgPath(orgTree, selectedOrgId)
    if (!orgPath) return true
    return orgPath.some(p => w.orgUnit.includes(p) || p.includes(w.orgUnit))
  })

  return (
    <div className="relative">
      <button onClick={() => setShowPicker(!showPicker)} className="flex h-9 w-full items-center gap-2 rounded-md border border-[#D1D5DB] bg-white px-3 text-left text-sm outline-none transition focus:border-[#1A56DB]">
        <Warehouse size={14} className="text-[#6B7280] shrink-0" />
        <span className={cn('truncate', !value && !selectedOrgPath && !selectedWh && 'text-[#9CA3AF]')}>{displayText}</span>
        <ChevronDown size={14} className={cn('ml-auto text-[#6B7280] transition', showPicker && 'rotate-180')} />
      </button>
      {showPicker && (
        <div className="absolute z-50 mt-1 w-[640px] max-w-[95vw] rounded-lg border border-[#E5E7EB] bg-white shadow-lg">
          <div className="flex">
            {/* 组织树 */}
            <div className="w-44 shrink-0 border-r border-[#E5E7EB] p-2">
              <div className="mb-2 text-xs font-semibold text-[#6B7280]">组织架构</div>
              {orgTree.map(n => <OrgTreeNode key={n.id} node={n} selectedId={selectedOrgId} onSelect={setSelectedOrgId} expandedIds={expandedIds} onToggleExpand={toggleExpand} />)}
            </div>
            {/* 仓库列表 */}
            <div className="w-48 shrink-0 border-r border-[#E5E7EB] p-2">
              <div className="mb-2 text-xs font-semibold text-[#6B7280]">仓库</div>
              {filteredWarehouses.map(w => (
                <button key={w.id} onClick={() => handleSelectWh(w.id)} className={cn('flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition hover:bg-[#F9FAFB]', selectedWhId === w.id && 'bg-[#EFF6FF]')}>
                  <div className={cn('flex h-4 w-4 shrink-0 items-center justify-center rounded-full border', selectedWhId === w.id ? 'border-[#1A56DB] bg-[#1A56DB]' : 'border-[#D1D5DB]')}>
                    {selectedWhId === w.id && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
                  </div>
                  <div>
                    <div className="text-[13px] text-[#374151]">{w.name}</div>
                    <div className="text-[11px] text-[#6B7280]">{w.code}</div>
                  </div>
                </button>
              ))}
              {filteredWarehouses.length === 0 && <div className="py-4 text-center text-xs text-[#9CA3AF]">该组织下暂无仓库</div>}
            </div>
            {/* 分区货架 */}
            <div className="flex-1 p-2">
              <div className="mb-2 text-xs font-semibold text-[#6B7280]">分区 / 货架</div>
              {selectedWh ? (
                selectedWh.zones && selectedWh.zones.length > 0 ? (
                  <div className="space-y-1">
                    {selectedWh.zones.map(z => {
                      const isZExpanded = zoneExpandedIds.has(z.id)
                      return (
                        <div key={z.id}>
                          <button onClick={() => { setSelectedZoneId(selectedZoneId === z.id ? null : z.id); toggleZoneExpand(z.id) }} className={cn('flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-sm transition', selectedZoneId === z.id ? 'bg-[#EFF6FF]' : 'hover:bg-[#F9FAFB]')}>
                            {z.shelves.length > 0 ? (isZExpanded ? <ChevronDown size={12} className="text-[#6B7280] shrink-0" /> : <ChevronRight size={12} className="text-[#6B7280] shrink-0" />) : <span className="w-3 shrink-0" />}
                            <Layers size={12} className="text-[#1A56DB] shrink-0" />
                            <span className="text-[13px] text-[#374151]">{z.name}</span>
                            <span className="ml-auto text-[10px] text-[#6B7280]">{z.shelves.length}货架</span>
                          </button>
                          {isZExpanded && z.shelves.length > 0 && (
                            <div className="ml-4 space-y-0.5 border-l border-[#E5E7EB] pl-2">
                              {z.shelves.map(s => (
                                <div key={s.id} className="flex items-center gap-1.5 rounded px-2 py-1 text-[12px] text-[#374151]">
                                  <Grid3x3 size={10} className="text-[#10B981] shrink-0" />
                                  <span>{s.name}</span>
                                  <span className="text-[10px] text-[#6B7280]">{s.code}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                ) : <div className="py-4 text-center text-xs text-[#9CA3AF]">该仓库暂无分区</div>
              ) : <div className="py-4 text-center text-xs text-[#9CA3AF]">请先选择仓库</div>}
            </div>
          </div>
          <div className="flex items-center justify-between border-t border-[#E5E7EB] px-3 py-2">
            <span className="text-[11px] text-[#9CA3AF]">3层：组织 → 仓库 → 分区/货架</span>
            <div className="flex items-center gap-2">
              <button onClick={() => setShowPicker(false)} className="h-7 rounded border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151]">取消</button>
              <button onClick={handleConfirm} className="h-7 rounded bg-[#1A56DB] px-3 text-xs text-white">确定</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ═══════════════════════════════════════════
   人员数据（关联组织架构）
   ═══════════════════════════════════════════ */

interface Person {
  id: string
  name: string
  title: string
  orgId: string
  orgName: string
  orgLevel: number
  phone: string
}

const personList: Person[] = [
  { id: 'p01', name: '王建国', title: '王建国警官', orgId: 'h1', orgName: 'XXX省公安厅', orgLevel: 0, phone: '138****0001' },
  { id: 'p02', name: '李明辉', title: '李明辉警官', orgId: 'h1', orgName: 'XXX省公安厅', orgLevel: 0, phone: '138****0002' },
  { id: 'p03', name: '赵志强', title: '赵志强警官', orgId: 'h1', orgName: 'XXX省公安厅', orgLevel: 0, phone: '138****0003' },
  { id: 'p04', name: '张小龙', title: '张小龙警官', orgId: 'h1', orgName: 'XXX省公安厅', orgLevel: 0, phone: '138****0004' },
  { id: 'p05', name: '陈建国', title: '陈建国警官', orgId: 'c1', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****1001' },
  { id: 'p06', name: '刘向东', title: '刘向东警官', orgId: 'c1', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****1002' },
  { id: 'p07', name: '周伟强', title: '周伟强警官', orgId: 'c1', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****1003' },
  { id: 'p08', name: '孙海涛', title: '孙海涛警官', orgId: 'c1', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****1004' },
  { id: 'p09', name: '吴大军', title: '吴大军警官', orgId: 'c2', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****2001' },
  { id: 'p10', name: '郑光明', title: '郑光明警官', orgId: 'c2', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****2002' },
  { id: 'p11', name: '杨立新', title: '杨立新警官', orgId: 'c2', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****2003' },
  { id: 'p12', name: '马建国', title: '马建国警官', orgId: 'd1', orgName: 'ZZZ区公安分局', orgLevel: 2, phone: '137****3001' },
  { id: 'p13', name: '黄志强', title: '黄志强警官', orgId: 'd1', orgName: 'ZZZ区公安分局', orgLevel: 2, phone: '137****3002' },
  { id: 'p14', name: '林晓东', title: '林晓东警官', orgId: 'd1', orgName: 'ZZZ区公安分局', orgLevel: 2, phone: '137****3003' },
  { id: 'p15', name: '何伟', title: '何伟警官', orgId: 's1', orgName: 'AAA派出所', orgLevel: 3, phone: '136****4001' },
  { id: 'p16', name: '罗文强', title: '罗文强警官', orgId: 's1', orgName: 'AAA派出所', orgLevel: 3, phone: '136****4002' },
  { id: 'p17', name: '谢明辉', title: '谢明辉警官', orgId: 's1', orgName: 'AAA派出所', orgLevel: 3, phone: '136****4003' },
  { id: 'p18', name: '范国强', title: '范国强警官', orgId: 'c3', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****5001' },
  { id: 'p19', name: '田大伟', title: '田大伟警官', orgId: 'c3', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****5002' },
  { id: 'p20', name: '吕小芳', title: '吕小芳警官', orgId: 'c3', orgName: 'YYY市公安局', orgLevel: 1, phone: '139****5003' },
]

/* ═══════════════════════════════════════════
   可搜索下拉框组件
   ═══════════════════════════════════════════ */

function SearchableDropdown({
  value,
  onChange,
  options,
  placeholder = '请选择',
  searchPlaceholder = '输入关键词搜索...',
  renderOption,
  renderValue,
  emptyText = '无匹配结果',
}: {
  value: string
  onChange: (val: string) => void
  options: { id: string; label: string; searchText: string }[]
  placeholder?: string
  searchPlaceholder?: string
  renderOption?: (opt: { id: string; label: string }) => React.ReactNode
  renderValue?: (val: string) => string
  emptyText?: string
}) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false)
        setSearch('')
      }
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  const filtered = search.trim()
    ? options.filter(o => o.searchText.toLowerCase().includes(search.toLowerCase()))
    : options

  const displayLabel = value
    ? (renderValue ? renderValue(value) : options.find(o => o.id === value)?.label || value)
    : ''

  return (
    <div ref={containerRef} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className={cn('flex h-7 w-full items-center gap-1.5 rounded-md border px-2 text-left text-xs outline-none transition focus:border-[#1A56DB]', value ? 'border-[#D1D5DB] text-[#374151]' : 'border-[#D1D5DB] text-[#9CA3AF]')}
      >
        <Search size={10} className="shrink-0 text-[#9CA3AF]" />
        <span className="truncate flex-1">{displayLabel || placeholder}</span>
        <ChevronDown size={12} className={cn('shrink-0 text-[#6B7280] transition', open && 'rotate-180')} />
      </button>
      {open && (
        <div className="absolute z-[60] mt-1 w-full min-w-[200px] rounded-lg border border-[#E5E7EB] bg-white shadow-lg">
          <div className="border-b border-[#F3F4F6] p-2">
            <div className="flex items-center gap-1.5 rounded-md border border-[#D1D5DB] px-2 py-1">
              <Search size={12} className="text-[#9CA3AF]" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={searchPlaceholder}
                className="w-full bg-transparent text-xs outline-none"
                autoFocus
              />
              {search && (
                <button onClick={() => setSearch('')} className="text-[#9CA3AF] hover:text-[#374151]"><X size={12} /></button>
              )}
            </div>
          </div>
          <div className="max-h-[200px] overflow-auto py-1">
            {filtered.length === 0 && (
              <div className="px-3 py-3 text-center text-xs text-[#9CA3AF]">{emptyText}</div>
            )}
            {filtered.map(opt => (
              <button
                key={opt.id}
                onClick={() => { onChange(opt.id); setOpen(false); setSearch('') }}
                className={cn('flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs transition hover:bg-[#F3F4F6]', value === opt.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151]')}
              >
                {renderOption ? renderOption(opt) : <span className="truncate">{opt.label}</span>}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

/* ═══════════════════════════════════════════
   到货处置区域组件
   ═══════════════════════════════════════════ */

/* ─── Modal Storage Location Selector (for DisposalSection) ─── */
function ModalStorageSelector({ open, value, onConfirm, onClose }: { open: boolean; value: string | null; onConfirm: (loc: string) => void; onClose: () => void }) {
  const [selOrgId, setSelOrgId] = useState<string | null>(null)
  const [selWhId, setSelWhId] = useState<string | null>(null)
  const [selZoneId, setSelZoneId] = useState<string | null>(null)
  const [expOrgIds, setExpOrgIds] = useState<Set<string>>(new Set(['h1']))
  const [expZoneIds, setExpZoneIds] = useState<Set<string>>(new Set())

  useEffect(() => {
    if (open) { setSelOrgId(null); setSelWhId(null); setSelZoneId(null); setExpOrgIds(new Set(['h1'])); setExpZoneIds(new Set()) }
  }, [open])

  if (!open) return null

  const toggleOrg = (id: string) => setExpOrgIds(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n })
  const toggleZone = (id: string) => setExpZoneIds(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n })

  const getOrgPath = (nodes: OrgNode[], targetId: string, path: string[] = []): string[] | null => {
    for (const n of nodes) { if (n.id === targetId) return [...path, n.name]; if (n.children) { const r = getOrgPath(n.children, targetId, [...path, n.name]); if (r) return r } }
    return null
  }
  const selectedOrgPath = selOrgId ? getOrgPath(orgTree, selOrgId) : null
  const selectedWh = selWhId ? warehouseList.find(w => w.id === selWhId) : null
  const selectedZone = selectedWh?.zones?.find(z => z.id === selZoneId)

  const displayPath = selectedZone ? `${selectedWh!.name} / ${selectedZone.name}` : selectedWh ? selectedWh.name : selectedOrgPath ? selectedOrgPath.join(' / ') : value || ''

  const handleConfirm = () => {
    if (displayPath) onConfirm(displayPath)
    onClose()
  }

  const filteredWarehouses = warehouseList.filter(w => {
    if (!selOrgId) return true
    const orgPath = getOrgPath(orgTree, selOrgId)
    if (!orgPath) return true
    return orgPath.some(p => w.orgUnit.includes(p) || p.includes(w.orgUnit))
  })

  const levelColors = ['#1A56DB', '#10B981', '#F59E0B', '#8B5CF6']

  const renderOrgTree = (nodes: OrgNode[]) => nodes.map(n => {
    const isExp = expOrgIds.has(n.id)
    const hasChildren = n.children && n.children.length > 0
    return (
      <div key={n.id}>
        <div className={cn('flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition', selOrgId === n.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')} style={{ paddingLeft: `${8 + n.level * 16}px` }} onClick={() => { setSelOrgId(n.id); setSelWhId(null); setSelZoneId(null); if (hasChildren) toggleOrg(n.id) }}>
          {hasChildren ? (isExp ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />) : <span className="w-3.5" />}
          <span className="mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white" style={{ backgroundColor: levelColors[n.level] || '#6B7280' }}>{['省', '市', '县', '所'][n.level] || '?'}</span>
          <span className="truncate">{n.name}</span>
        </div>
        {hasChildren && isExp && renderOrgTree(n.children!)}
      </div>
    )
  })

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl" style={{ maxHeight: '85vh' }}>
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-5 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">选择入库位置</h3>
          <button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
        </div>
        {/* Selected path */}
        <div className="border-b border-[#E5E7EB] bg-[#F8FAFF] px-5 py-2">
          <div className="flex items-center gap-2 text-sm">
            <Warehouse size={14} className="text-[#1A56DB]" />
            <span className="text-[#6B7280]">已选：</span>
            <span className="font-medium text-[#374151]">{displayPath || '请选择'}</span>
          </div>
        </div>
        {/* Three columns */}
        <div className="flex overflow-auto" style={{ maxHeight: 'calc(85vh - 120px)' }}>
          {/* Org Tree */}
          <div className="w-44 shrink-0 border-r border-[#E5E7EB] p-2">
            <div className="mb-2 text-xs font-semibold text-[#6B7280]">组织架构</div>
            {renderOrgTree(orgTree)}
          </div>
          {/* Warehouse */}
          <div className="w-48 shrink-0 border-r border-[#E5E7EB] p-2">
            <div className="mb-2 text-xs font-semibold text-[#6B7280]">仓库</div>
            {filteredWarehouses.map(w => (
              <button key={w.id} onClick={() => { setSelWhId(selWhId === w.id ? null : w.id); setSelZoneId(null); setExpZoneIds(new Set()) }} className={cn('flex w-full items-center gap-2 rounded-md px-2 py-1.5 text-left text-sm transition hover:bg-[#F9FAFB]', selWhId === w.id && 'bg-[#EFF6FF]')}>
                <div className={cn('flex h-4 w-4 shrink-0 items-center justify-center rounded-full border', selWhId === w.id ? 'border-[#1A56DB] bg-[#1A56DB]' : 'border-[#D1D5DB]')}>
                  {selWhId === w.id && <div className="h-1.5 w-1.5 rounded-full bg-white" />}
                </div>
                <div><div className="text-[13px] text-[#374151]">{w.name}</div><div className="text-[11px] text-[#6B7280]">{w.code}</div></div>
              </button>
            ))}
            {filteredWarehouses.length === 0 && <div className="py-4 text-center text-xs text-[#9CA3AF]">该组织下暂无仓库</div>}
          </div>
          {/* Zone/Shelf */}
          <div className="flex-1 p-2">
            <div className="mb-2 text-xs font-semibold text-[#6B7280]">分区 / 货架</div>
            {selectedWh ? (selectedWh.zones && selectedWh.zones.length > 0 ? (
              <div className="space-y-1">
                {selectedWh.zones.map(z => {
                  const isZExp = expZoneIds.has(z.id)
                  return (
                    <div key={z.id}>
                      <button onClick={() => { setSelZoneId(selZoneId === z.id ? null : z.id); toggleZone(z.id) }} className={cn('flex w-full items-center gap-1.5 rounded-md px-2 py-1.5 text-left text-sm transition', selZoneId === z.id ? 'bg-[#EFF6FF]' : 'hover:bg-[#F9FAFB]')}>
                        {z.shelves.length > 0 ? (isZExp ? <ChevronDown size={12} className="text-[#6B7280] shrink-0" /> : <ChevronRight size={12} className="text-[#6B7280] shrink-0" />) : <span className="w-3 shrink-0" />}
                        <Layers size={12} className="text-[#1A56DB] shrink-0" /><span className="text-[13px] text-[#374151]">{z.name}</span><span className="ml-auto text-[10px] text-[#6B7280]">{z.shelves.length}货架</span>
                      </button>
                      {isZExp && z.shelves.length > 0 && (
                        <div className="ml-4 space-y-0.5 border-l border-[#E5E7EB] pl-2">
                          {z.shelves.map(s => <div key={s.id} className="flex items-center gap-1.5 rounded px-2 py-1 text-[12px] text-[#374151]"><Grid3x3 size={10} className="text-[#10B981] shrink-0" /><span>{s.name}</span><span className="text-[10px] text-[#6B7280]">{s.code}</span></div>)}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            ) : <div className="py-4 text-center text-xs text-[#9CA3AF]">该仓库暂无分区</div>) : <div className="py-4 text-center text-xs text-[#9CA3AF]">请先选择仓库</div>}
          </div>
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-[#E5E7EB] px-5 py-3">
          <button onClick={onClose} className="h-8 rounded border border-[#D1D5DB] bg-white px-4 text-xs text-[#374151]">取消</button>
          <button onClick={handleConfirm} className="h-8 rounded bg-[#1A56DB] px-4 text-xs text-white">确定</button>
        </div>
      </div>
    </div>
  )
}

/* ─── Global org options (used by modals & DisposalSection) ─── */
const collectOrgsGlobal = (nodes: OrgNode[]): { id: string; name: string; level: number }[] => {
  const result: { id: string; name: string; level: number }[] = []
  for (const n of nodes) {
    result.push({ id: n.id, name: n.name, level: n.level })
    if (n.children) result.push(...collectOrgsGlobal(n.children))
  }
  return result
}
const orgOptions = collectOrgsGlobal(orgTree)

/* ─── Unit Selector Modal (Tree) ─── */
function UnitSelectorModal({ open, value, onConfirm, onClose }: { open: boolean; value: string; onConfirm: (val: string) => void; onClose: () => void }) {
  const [search, setSearch] = useState('')
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['h1']))
  useEffect(() => { if (open) { setSearch(''); setExpandedIds(new Set(['h1'])) } }, [open])
  if (!open) return null

  const levelLabel = ['省', '市', '县', '所']
  const searchText = search.trim().toLowerCase()

  // Filter: if searching, find matching orgs and include their ancestors
  let showIds = new Set<string>()
  if (searchText) {
    const findPath = (nodes: OrgNode[], target: string, path: string[] = []): string[] | null => {
      for (const n of nodes) {
        const label = `${levelLabel[n.level]}-${n.name}`.toLowerCase()
        const current = [...path, n.id]
        if (label.includes(target)) return current
        if (n.children) {
          const found = findPath(n.children, target, current)
          if (found) return found
        }
      }
      return null
    }
    orgTree.forEach(root => {
      const path = findPath([root], searchText)
      if (path) path.forEach(id => showIds.add(id))
    })
  }

  const toggleExpand = (id: string) => setExpandedIds(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n })

  const renderOrgTree = (nodes: OrgNode[]) => nodes.map(n => {
    // When searching, only show matching nodes and their descendants
    if (searchText && !showIds.has(n.id)) return null
    const isExpanded = expandedIds.has(n.id)
    const hasChildren = n.children && n.children.length > 0
    const isSelected = value === `${levelLabel[n.level]}-${n.name}`
    return (
      <div key={n.id}>
        <div className={cn('flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition', isSelected ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]')} style={{ paddingLeft: `${8 + n.level * 16}px` }} onClick={() => { onConfirm(`${levelLabel[n.level]}-${n.name}`); onClose() }}>
          {hasChildren ? (
            <span onClick={(e) => { e.stopPropagation(); toggleExpand(n.id) }}>
              {isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />}
            </span>
          ) : <span className="w-3.5" />}
          <span className={cn('mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white', n.level === 0 ? 'bg-[#1A56DB]' : n.level === 1 ? 'bg-[#10B981]' : n.level === 2 ? 'bg-[#F59E0B]' : 'bg-[#8B5CF6]')}>{levelLabel[n.level]}</span>
          <span className="truncate">{n.name}</span>
        </div>
        {hasChildren && (isExpanded || searchText) && renderOrgTree(n.children!)}
      </div>
    )
  })

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex w-[480px] max-w-[90vw] flex-col rounded-xl bg-white shadow-2xl" style={{ maxHeight: '70vh' }}>
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-5 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">选择使用单位</h3>
          <button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
        </div>
        <div className="border-b border-[#E5E7EB] bg-[#F8FAFF] px-5 py-2">
          <div className="flex items-center gap-2 text-sm">
            <Building2 size={14} className="text-[#1A56DB]" />
            <span className="text-[#6B7280]">已选：</span>
            <span className="font-medium text-[#374151]">{value || '请选择'}</span>
          </div>
        </div>
        <div className="p-3">
          <div className="mb-2 flex items-center gap-1.5 rounded-md border border-[#D1D5DB] px-3 py-1.5">
            <Search size={14} className="text-[#9CA3AF]" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="输入关键词搜索单位..." className="w-full bg-transparent text-sm outline-none" autoFocus />
            {search && <button onClick={() => setSearch('')} className="text-[#9CA3AF] hover:text-[#374151]"><X size={12} /></button>}
          </div>
        </div>
        <div className="flex-1 overflow-auto px-3 pb-3" style={{ maxHeight: 'calc(70vh - 150px)' }}>
          {renderOrgTree(orgTree)}
          {searchText && showIds.size === 0 && <div className="py-4 text-center text-xs text-[#9CA3AF]">无匹配结果</div>}
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-[#E5E7EB] px-5 py-3">
          <button onClick={onClose} className="h-8 rounded border border-[#D1D5DB] bg-white px-4 text-xs text-[#374151]">取消</button>
        </div>
      </div>
    </div>
  )
}

/* ─── Person Selector Modal (Tree) ─── */
function PersonSelectorModal({ open, value, unitFilter, onConfirm, onClose }: { open: boolean; value: string; unitFilter: string; onConfirm: (val: string) => void; onClose: () => void }) {
  const [search, setSearch] = useState('')
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['h1']))
  useEffect(() => { if (open) { setSearch(''); setExpandedIds(new Set(['h1'])) } }, [open])
  if (!open) return null

  const levelLabel = ['省', '市', '县', '所']
  const searchText = search.trim().toLowerCase()

  // Get persons under an org (by orgId or orgName)
  const getOrgPersons = (orgId: string, orgName: string) => {
    const list = searchText
      ? personList.filter(p => p.orgId === orgId && `${p.name} ${p.title}`.toLowerCase().includes(searchText))
      : personList.filter(p => p.orgId === orgId)
    // If unitFilter is set, also filter by matching org
    if (unitFilter && !searchText) {
      const filterMatch = orgOptions.find(o => `${levelLabel[o.level]}-${o.name}` === unitFilter)
      if (filterMatch) {
        return list.filter(p => p.orgId === filterMatch.id || p.orgName === filterMatch.name)
      }
    }
    return list
  }

  // When searching, find which org nodes have matching persons
  const findOrgsWithPersons = (nodes: OrgNode[]): Set<string> => {
    const result = new Set<string>()
    for (const n of nodes) {
      if (getOrgPersons(n.id, n.name).length > 0) result.add(n.id)
      if (n.children) {
        const childIds = findOrgsWithPersons(n.children)
        childIds.forEach(id => result.add(id))
      }
    }
    return result
  }
  const orgsWithPersons = searchText ? findOrgsWithPersons(orgTree) : null

  // Filter: if searching by person name, find matching persons and show their orgs
  if (searchText && !orgsWithPersons?.size) {
    // Try broader search: any person match
    const matchingPersons = personList.filter(p => `${p.name} ${p.title}`.toLowerCase().includes(searchText))
    if (matchingPersons.length > 0) {
      matchingPersons.forEach(p => { if (orgsWithPersons) orgsWithPersons.add(p.orgId) })
    }
  }

  const toggleExpand = (id: string) => setExpandedIds(p => { const n = new Set(p); n.has(id) ? n.delete(id) : n.add(id); return n })

  const renderOrgTreeWithPersons = (nodes: OrgNode[]) => nodes.map(n => {
    const persons = getOrgPersons(n.id, n.name)
    const hasChildren = n.children && n.children.length > 0
    const isExpanded = expandedIds.has(n.id)
    const hasMatchingDescendants = searchText ? (orgsWithPersons?.has(n.id) || false) : true

    // When searching, hide nodes with no matching persons and no matching descendants
    if (searchText && persons.length === 0 && !hasMatchingDescendants) return null

    return (
      <div key={n.id}>
        {/* Org node header */}
        <div className="flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm text-[#374151] hover:bg-[#F3F4F6]" style={{ paddingLeft: `${8 + n.level * 16}px` }} onClick={() => { if (hasChildren) toggleExpand(n.id) }}>
          {hasChildren ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />) : <span className="w-3.5" />}
          <span className={cn('mr-1 flex h-4 min-w-4 items-center justify-center rounded px-1 text-[10px] font-bold text-white', n.level === 0 ? 'bg-[#1A56DB]' : n.level === 1 ? 'bg-[#10B981]' : n.level === 2 ? 'bg-[#F59E0B]' : 'bg-[#8B5CF6]')}>{levelLabel[n.level]}</span>
          <span className="truncate font-medium">{n.name}</span>
          {persons.length > 0 && <span className="ml-1 text-[10px] text-[#9CA3AF]">({persons.length}人)</span>}
        </div>
        {/* Persons under this org */}
        {(isExpanded || searchText) && persons.length > 0 && (
          <div>
            {persons.map(p => {
              const displayVal = `${p.name}（${p.title}）`
              const isSelected = value === displayVal
              return (
                <button key={p.id} onClick={() => { onConfirm(displayVal); onClose() }}
                  className={cn('flex w-full items-center gap-2 rounded-md py-1.5 text-left text-sm transition hover:bg-[#F3F4F6]', isSelected ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151]')}
                  style={{ paddingLeft: `${24 + n.level * 16}px` }}>
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-[#E8F0FE]"><span className="text-[10px] font-bold text-[#1A56DB]">{p.name.charAt(0)}</span></div>
                  <span className="truncate">{p.name} <span className="text-[#6B7280]">({p.title})</span></span>
                  <span className="ml-auto text-[10px] text-[#9CA3AF]">{p.phone}</span>
                </button>
              )
            })}
          </div>
        )}
        {/* Children orgs */}
        {hasChildren && (isExpanded || searchText) && renderOrgTreeWithPersons(n.children!)}
      </div>
    )
  })

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex w-[520px] max-w-[90vw] flex-col rounded-xl bg-white shadow-2xl" style={{ maxHeight: '70vh' }}>
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-5 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">选择使用对象</h3>
          <button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
        </div>
        <div className="border-b border-[#E5E7EB] bg-[#F8FAFF] px-5 py-2">
          <div className="flex items-center gap-2 text-sm">
            <Users size={14} className="text-[#10B981]" />
            <span className="text-[#6B7280]">已选：</span>
            <span className="font-medium text-[#374151]">{value || '请选择'}</span>
          </div>
        </div>
        <div className="p-3">
          <div className="mb-2 flex items-center gap-1.5 rounded-md border border-[#D1D5DB] px-3 py-1.5">
            <Search size={14} className="text-[#9CA3AF]" />
            <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="输入姓名搜索..." className="w-full bg-transparent text-sm outline-none" autoFocus />
            {search && <button onClick={() => setSearch('')} className="text-[#9CA3AF] hover:text-[#374151]"><X size={12} /></button>}
          </div>
        </div>
        <div className="flex-1 overflow-auto px-3 pb-3" style={{ maxHeight: 'calc(70vh - 150px)' }}>
          {renderOrgTreeWithPersons(orgTree)}
          {(() => {
            let total = 0
            const count = (nodes: OrgNode[]) => { for (const n of nodes) { total += getOrgPersons(n.id, n.name).length; if (n.children) count(n.children) } }
            count(orgTree)
            return total === 0 && <div className="py-4 text-center text-xs text-[#9CA3AF]">{unitFilter ? '该单位下暂无人员' : '无匹配结果'}</div>
          })()}
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-[#E5E7EB] px-5 py-3">
          <button onClick={onClose} className="h-8 rounded border border-[#D1D5DB] bg-white px-4 text-xs text-[#374151]">取消</button>
        </div>
      </div>
    </div>
  )
}

function DisposalSection({
  equipments, setEquipments, expandedDisposalId, setExpandedDisposalId,
}: {
  equipments: EquipmentDetail[]
  setEquipments: React.Dispatch<React.SetStateAction<EquipmentDetail[]>>
  expandedDisposalId: string | null
  setExpandedDisposalId: (id: string | null) => void
}) {
  const [modalFor, setModalFor] = useState<{ eqId: string; dspId: string } | null>(null)
  const [unitModalFor, setUnitModalFor] = useState<{ eqId: string; dspId: string } | null>(null)
  const [personModalFor, setPersonModalFor] = useState<{ eqId: string; dspId: string } | null>(null)

  const addDisposal = (eqId: string) => {
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      const disposals = e.disposals ?? []
      const usedQty = disposals.reduce((s, d) => s + d.quantity, 0)
      const remain = (e.qualifiedQty || 0) - usedQty
      if (remain <= 0) return e
      return { ...e, disposals: [...disposals, { id: `dsp-${eqId}-${Date.now()}`, type: 'inbound' as const, quantity: remain }] }
    }))
  }

  const removeDisposal = (eqId: string, dspId: string) => {
    setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, disposals: (e.disposals ?? []).filter(d => d.id !== dspId) } : e))
  }

  const updateDisposal = (eqId: string, dspId: string, patch: Partial<DisposalItem>) => {
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      return { ...e, disposals: (e.disposals ?? []).map(d => d.id === dspId ? { ...d, ...patch } : d) }
    }))
  }

  const quickAllInbound = (eqId: string) => {
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      return { ...e, disposals: [{ id: `dsp-${eqId}-all`, type: 'inbound' as const, quantity: e.qualifiedQty || 0 }] }
    }))
  }

  const quickAllDelivery = (eqId: string) => {
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      return { ...e, disposals: [{ id: `dsp-${eqId}-all`, type: 'delivery' as const, quantity: e.qualifiedQty || 0 }] }
    }))
  }

  const levelLabel = ['省', '市', '县', '所']

  const activeModalDsp = modalFor ? (equipments.find(e => e.id === modalFor.eqId)?.disposals ?? []).find(d => d.id === modalFor.dspId) : null

  return (
    <div className="rounded-lg border border-[#F97316]/30 bg-[#FFF7ED]">
      <div className="flex items-center gap-2 border-b border-[#F97316]/20 bg-[#F97316]/5 px-4 py-2.5">
        <div className="flex h-5 w-5 items-center justify-center rounded bg-[#F97316] text-[10px] font-bold text-white">置</div>
        <span className="text-sm font-semibold text-[#EA580C]">到货处置</span>
        <span className="ml-2 text-[11px] text-[#9CA3AF]">合格装备可分配至入库或直接交付使用单位</span>
      </div>
      <div className="p-4 space-y-3">
        {equipments.map(eq => {
          const isExpanded = expandedDisposalId === eq.id
          const hasQualified = (eq.qualifiedQty || 0) > 0
          const disposals = eq.disposals ?? []
          const usedQty = disposals.reduce((s, d) => s + d.quantity, 0)
          const remain = (eq.qualifiedQty || 0) - usedQty
          const isBalanced = remain === 0 && hasQualified

          if (!hasQualified) return null

          return (
            <div key={`dsp-${eq.id}`} className="rounded-lg border border-[#E5E7EB] bg-white overflow-hidden">
              {/* Header */}
              <button
                onClick={() => setExpandedDisposalId(isExpanded ? null : eq.id)}
                className="flex w-full items-center gap-2 px-4 py-2.5 text-left transition hover:bg-[#FAFBFC]"
              >
                {isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />}
                <span className="text-sm font-medium text-[#374151]">{eq.name}</span>
                <span className="text-xs text-[#6B7280]">({eq.model})</span>
                <span className="ml-2 text-xs text-[#1A56DB]">合格 {eq.qualifiedQty}{eq.unit}</span>
                <span className="ml-auto flex items-center gap-1.5">
                  {isBalanced ? (
                    <span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-[10px] text-[#059669]">已分配 {usedQty}{eq.unit}</span>
                  ) : (
                    <span className="rounded bg-[#FEE2E2] px-2 py-0.5 text-[10px] text-[#DC2626]">待分配 {remain}{eq.unit}</span>
                  )}
                </span>
              </button>

              {/* Expanded content */}
              {isExpanded && (
                <div className="border-t border-[#F3F4F6] px-4 py-3 space-y-3">
                  {/* Quick actions */}
                  <div className="flex items-center gap-2">
                    <button onClick={() => quickAllInbound(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2.5 text-xs text-[#374151] hover:bg-[#F3F4F6]">
                      <Warehouse size={12} className="text-[#1A56DB]" /> 全部入库
                    </button>
                    <button onClick={() => quickAllDelivery(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2.5 text-xs text-[#374151] hover:bg-[#F3F4F6]">
                      <PackageCheck size={12} className="text-[#10B981]" /> 全部交付
                    </button>
                  </div>

                  {/* Disposal rows */}
                  {disposals.map((dsp, idx) => (
                    <div key={dsp.id} className="grid grid-cols-12 gap-2 items-end rounded-md border border-[#F3F4F6] bg-[#FAFBFC] p-3">
                      <div className="col-span-1">
                        <label className="mb-1 block text-[10px] text-[#6B7280]">序号</label>
                        <div className="flex h-7 items-center text-xs text-[#6B7280]">{idx + 1}</div>
                      </div>
                      <div className="col-span-2">
                        <label className="mb-1 block text-[10px] text-[#6B7280]">处置方式</label>
                        <div className="flex h-7 gap-1">
                          {([{ k: 'inbound', label: '入库', icon: Warehouse, c: '#1A56DB' }, { k: 'delivery', label: '交付', icon: PackageCheck, c: '#10B981' }] as const).map(t => {
                            const Icon = t.icon
                            return (
                              <button key={t.k} onClick={() => updateDisposal(eq.id, dsp.id, { type: t.k, targetUnit: undefined, storageLocation: undefined })}
                                className={cn('flex flex-1 items-center justify-center gap-0.5 rounded border text-[10px] font-medium transition', dsp.type === t.k ? 'border-[t.c] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#6B7280] hover:border-[#9CA3AF]')}>
                                <Icon size={10} />{t.label}
                              </button>
                            )
                          })}
                        </div>
                      </div>
                      <div className="col-span-2">
                        <label className="mb-1 block text-[10px] text-[#6B7280]">数量 ({eq.unit})</label>
                        <input type="number" min={1} max={eq.qualifiedQty || 0} value={dsp.quantity} onChange={(e) => updateDisposal(eq.id, dsp.id, { quantity: Math.max(1, parseInt(e.target.value) || 0) })} className="h-7 w-full rounded-md border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]" />
                      </div>
                      {dsp.type === 'inbound' ? (
                        <div className="col-span-6">
                          <label className="mb-1 block text-[10px] text-[#6B7280]">入库位置</label>
                          <button onClick={() => setModalFor({ eqId: eq.id, dspId: dsp.id })} className={cn('flex h-7 w-full items-center gap-2 rounded-md border px-3 text-left text-xs', dsp.storageLocation ? 'border-[#D1D5DB] text-[#374151]' : 'border-[#D1D5DB] text-[#9CA3AF]')}>
                            <Warehouse size={12} className="shrink-0" />
                            <span className="truncate">{dsp.storageLocation || '请选择存储位置'}</span>
                            <ChevronDown size={12} className="ml-auto shrink-0 text-[#6B7280]" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <div className="col-span-3">
                            <label className="mb-1 block text-[10px] text-[#6B7280]">使用单位</label>
                            <button onClick={() => setUnitModalFor({ eqId: eq.id, dspId: dsp.id })} className={cn('flex h-7 w-full items-center gap-2 rounded-md border px-3 text-left text-xs', dsp.targetUnit ? 'border-[#D1D5DB] text-[#374151]' : 'border-[#D1D5DB] text-[#9CA3AF]')}>
                              <Building2 size={12} className="shrink-0" />
                              <span className="truncate">{dsp.targetUnit || '请选择使用单位'}</span>
                              <ChevronDown size={12} className="ml-auto shrink-0 text-[#6B7280]" />
                            </button>
                          </div>
                          <div className="col-span-3">
                            <label className="mb-1 block text-[10px] text-[#6B7280]">使用对象</label>
                            <button onClick={() => setPersonModalFor({ eqId: eq.id, dspId: dsp.id })} className={cn('flex h-7 w-full items-center gap-2 rounded-md border px-3 text-left text-xs', dsp.targetObject ? 'border-[#D1D5DB] text-[#374151]' : 'border-[#D1D5DB] text-[#9CA3AF]')}>
                              <Users size={12} className="shrink-0" />
                              <span className="truncate">{dsp.targetObject || '请选择使用对象'}</span>
                              <ChevronDown size={12} className="ml-auto shrink-0 text-[#6B7280]" />
                            </button>
                          </div>
                        </>
                      )}
                      <div className="col-span-1 flex justify-end">
                        <button onClick={() => removeDisposal(eq.id, dsp.id)} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#FEE2E2] hover:text-[#EF4444]"><Trash2 size={12} /></button>
                      </div>
                    </div>
                  ))}

                  {/* Add button */}
                  {remain > 0 && (
                    <button onClick={() => addDisposal(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-dashed border-[#D1D5DB] px-3 text-xs text-[#6B7280] hover:border-[#1A56DB] hover:text-[#1A56DB]">
                      <Plus size={12} /> 添加处置
                    </button>
                  )}

                  {/* Summary */}
                  <div className="flex items-center gap-3 text-[11px]">
                    <span className="text-[#6B7280]">已分配：<span className={cn('font-medium', isBalanced ? 'text-[#059669]' : 'text-[#DC2626]')}>{usedQty}</span> / {eq.qualifiedQty} {eq.unit}</span>
                    {!isBalanced && <span className="text-[#DC2626]">（还需分配 {remain} {eq.unit}）</span>}
                  </div>
                </div>
              )}
            </div>
          )
        })}

        {equipments.filter(e => (e.qualifiedQty || 0) > 0).length === 0 && (
          <div className="py-6 text-center text-sm text-[#9CA3AF]">暂无合格装备需要处置，请在上方验收中填写合格数量</div>
        )}
      </div>

      {/* Modal Storage Selector */}
      <ModalStorageSelector
        open={!!modalFor}
        value={activeModalDsp?.storageLocation || null}
        onConfirm={(loc) => {
          if (modalFor) updateDisposal(modalFor.eqId, modalFor.dspId, { storageLocation: loc })
        }}
        onClose={() => setModalFor(null)}
      />
      {/* Modal Unit Selector */}
      <UnitSelectorModal
        open={!!unitModalFor}
        value={activeModalDsp?.targetUnit || ''}
        onConfirm={(val) => {
          if (unitModalFor) updateDisposal(unitModalFor.eqId, unitModalFor.dspId, { targetUnit: val, targetObject: '' })
        }}
        onClose={() => setUnitModalFor(null)}
      />
      {/* Modal Person Selector */}
      <PersonSelectorModal
        open={!!personModalFor}
        value={activeModalDsp?.targetObject || ''}
        unitFilter={personModalFor ? (equipments.find(e => e.id === personModalFor.eqId)?.disposals ?? []).find(d => d.id === personModalFor.dspId)?.targetUnit || '' : ''}
        onConfirm={(val) => {
          if (personModalFor) updateDisposal(personModalFor.eqId, personModalFor.dspId, { targetObject: val })
        }}
        onClose={() => setPersonModalFor(null)}
      />
    </div>
  )
}

/* ═══════════════════════════════════════════
   验收对话框组件 - 三区域：发货内容 / 到货验收 / 到货处置
   ═══════════════════════════════════════════ */

function InspectionDialog({ receipt, open, onClose, onSave }: { receipt: PurchaseReceipt | null; open: boolean; onClose: () => void; onSave: (updated: PurchaseReceipt) => void }) {
  const [equipments, setEquipments] = useState<EquipmentDetail[]>([])
  const [expandedEqId, setExpandedEqId] = useState<string | null>(null)
  const [expandedDisposalId, setExpandedDisposalId] = useState<string | null>(null)
  const [showRfidCompareFor, setShowRfidCompareFor] = useState<string | null>(null)
  const [photoText, setPhotoText] = useState('')
  const [photoFor, setPhotoFor] = useState<string | null>(null)
  const [receiverName, setReceiverName] = useState('')
  const [receiveTime, setReceiveTime] = useState('')
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (receipt) {
      setEquipments(receipt.equipments.map(e => {
        const actualQty = e.actualQty ?? e.deliveryQty
        const qualifiedQty = e.qualifiedQty
        const disposals = e.disposals?.length ? e.disposals : (qualifiedQty && qualifiedQty > 0 ? [{ id: `dsp-${e.id}-1`, type: 'inbound' as const, quantity: qualifiedQty }] : [])
        return {
          ...e,
          actualQty,
          receiptInfo: e.receiptInfo ?? { receiverName: '', receiveTime: '' },
          disposals,
        }
      }))
      setExpandedEqId(null)
      setExpandedDisposalId(null)
      setReceiverName('')
      setReceiveTime(new Date().toLocaleString('zh-CN', { hour12: false }))
    }
  }, [receipt])

  if (!open || !receipt) return null

  const totalDeliveryAmount = equipments.reduce((sum, e) => sum + e.totalAmount, 0)

  const handleQtyChange = (eqId: string, val: string) => {
    const num = val === '' ? null : Math.max(0, parseInt(val) || 0)
    setEquipments(prev => prev.map(e => {
      if (e.id !== eqId) return e
      const eq = { ...e, qualifiedQty: num }
      if (num !== null) {
        eq.unqualifiedQty = (e.actualQty ?? e.deliveryQty) - num
        if (num === 0) eq.inspectionStatus = 'return'
        else if (eq.unqualifiedQty > 0) eq.inspectionStatus = 'unqualified'
        else eq.inspectionStatus = 'qualified'
        // Auto-generate default disposals (all to inbound) when qualified qty changes
        eq.disposals = [{ id: `dsp-${eqId}-auto`, type: 'inbound' as const, quantity: num }]
      }
      return eq
    }))
  }

  const handleOpinionChange = (eqId: string, val: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionOpinion: val } : e)) }
  const handleAddPhoto = (eqId: string, desc: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionPhotos: [...e.inspectionPhotos, desc] } : e)) }
  const handleRemovePhoto = (eqId: string, idx: number) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, inspectionPhotos: e.inspectionPhotos.filter((_, i) => i !== idx) } : e)) }
  /* 退货/换货处理已移除 */
  const handleActualRfidScan = (eqId: string) => {
    const eq = equipments.find(e => e.id === eqId)
    if (!eq) return
    const nextIdx = eq.actualRfidCodes.length + 1
    const prefix = eq.rfidCodes[0]?.split('-').slice(0, 2).join('-') || 'RFID'
    const newRfid = `${prefix}-${String(nextIdx).padStart(3, '0')}`
    setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, actualRfidCodes: [...e.actualRfidCodes, newRfid] } : e))
  }
  const handleClearActualRfid = (eqId: string) => { setEquipments(prev => prev.map(e => e.id === eqId ? { ...e, actualRfidCodes: [] } : e)) }

  const getStatusBadge = (eq: EquipmentDetail) => {
    if (eq.qualifiedQty === null) return <Badge variant="warning">待填写</Badge>
    if (eq.inspectionStatus === 'return') return <Badge variant="danger">退货</Badge>
    if (eq.inspectionStatus === 'exchange') return <Badge variant="danger">换货</Badge>
    if (eq.inspectionStatus === 'qualified') return <Badge variant="success">全部合格</Badge>
    if (eq.inspectionStatus === 'unqualified') return <Badge variant="warning">部分合格</Badge>
    return <Badge variant="default">-</Badge>
  }

  const handleSave = () => {
    // Validate receipt info
    if (!receiverName.trim()) { alert('请填写收货人'); return }
    if (!receiveTime.trim()) { alert('请填写收货时间'); return }
    const allInspected = equipments.every(e => e.qualifiedQty !== null)
    if (!allInspected) { alert('请完成所有装备的合格数量填写'); return }
    // Validate disposals: sum of disposals must equal qualified qty
    for (const eq of equipments) {
      if ((eq.qualifiedQty || 0) > 0) {
        const totalDisposal = (eq.disposals ?? []).reduce((sum, d) => sum + d.quantity, 0)
        if (totalDisposal !== eq.qualifiedQty) {
          alert(`装备"${eq.name}"的处置分配数量（${totalDisposal}）不等于合格数量（${eq.qualifiedQty}），请调整`)
          return
        }
      }
    }
    const updatedEquipments = equipments.map(e => ({
      ...e,
      receiptInfo: { receiverName, receiveTime },
    }))
    onSave({ ...receipt, equipments: updatedEquipments, status: 'inspected', storageLocation: updatedEquipments[0]?.disposals?.find(d => d.type === 'inbound')?.storageLocation || '' })
    setEquipments([]); setExpandedEqId(null); setExpandedDisposalId(null)
    setReceiverName(''); setReceiveTime('')
    onClose()
  }

  const handleCancel = () => { setEquipments([]); setExpandedEqId(null); setExpandedDisposalId(null); setReceiverName(''); setReceiveTime(''); onClose() }

  const getRfidCompareResult = (eq: EquipmentDetail) => {
    if (eq.actualRfidCodes.length === 0) return { matched: 0, unmatched: 0, missing: eq.rfidCodes.length, extra: 0 }
    const deliverySet = new Set(eq.rfidCodes)
    const actualSet = new Set(eq.actualRfidCodes)
    const matched = eq.actualRfidCodes.filter(r => deliverySet.has(r)).length
    const extra = eq.actualRfidCodes.filter(r => !deliverySet.has(r)).length
    const missing = eq.rfidCodes.filter(r => !actualSet.has(r)).length
    return { matched, unmatched: eq.rfidCodes.length - matched, missing, extra }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleCancel} />
      <div className="relative z-10 flex max-h-[92vh] w-[1100px] max-w-[96vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">装备验收</h2>
            <p className="mt-1 text-xs text-[#6B7280]">发货单：{receipt.id} · 供应商：{receipt.supplier} · 合同：{receipt.contractNo}</p>
          </div>
          <button onClick={handleCancel} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        <div className="flex-1 overflow-auto px-6 py-4 space-y-4">
          <div className="rounded-lg border border-[#1A56DB]/30 bg-[#F8FAFF]">
            <div className="flex items-center gap-2 border-b border-[#1A56DB]/20 bg-[#1A56DB]/5 px-4 py-2.5">
              <div className="flex h-5 w-5 items-center justify-center rounded bg-[#1A56DB] text-[10px] font-bold text-white">发</div>
              <span className="text-sm font-semibold text-[#1A56DB]">发货内容</span>
              <span className="ml-auto text-xs text-[#6B7280]">发货单号：{receipt.id}</span>
            </div>
            <div className="p-4 space-y-4">
              <div className="grid grid-cols-4 gap-3">
                <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                  <div className="text-[11px] text-[#6B7280]">供应商</div>
                  <div className="mt-0.5 text-sm font-medium text-[#374151] truncate" title={receipt.supplier}>{receipt.supplier}</div>
                </div>
                <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                  <div className="text-[11px] text-[#6B7280]">关联合同</div>
                  <div className="mt-0.5 text-sm font-medium text-[#1A56DB]">{receipt.contractNo}</div>
                </div>
                <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                  <div className="text-[11px] text-[#6B7280]">订单名称</div>
                  <div className="mt-0.5 text-sm font-medium text-[#374151] truncate" title={receipt.orderName}>{receipt.orderName}</div>
                </div>
                <div className="rounded-md border border-[#E5E7EB] bg-white p-3">
                  <div className="text-[11px] text-[#6B7280]">预计送货日期</div>
                  <div className="mt-0.5 text-sm font-medium text-[#374151]">{receipt.deliveryDate}</div>
                </div>
              </div>
              <div className="rounded-md border border-[#E5E7EB] bg-white px-3 py-2">
                <div className="flex items-center gap-1.5">
                  <Warehouse size={13} className="text-[#1A56DB]" />
                  <span className="text-xs font-semibold text-[#374151]">收货地址：</span>
                  <span className="text-xs text-[#374151]">{receipt.receiver}</span>
                </div>
              </div>
              <div className="rounded-lg border border-[#E5E7EB] overflow-hidden bg-white">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#E5E7EB] bg-[#F0F5FF]">
                      <th className="w-8 px-2 py-2"></th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">型号</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">整箱</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">箱体码</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">发货RFID</th>
                      <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">采购数量</th>
                      <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">本次发货</th>
                      <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价(元)</th>
                      <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">金额(元)</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期至</th>
                    </tr>
                  </thead>
                  <tbody>
                    {equipments.map((eq) => (
                      <>
                        <tr key={eq.id} className="border-b border-[#F3F4F6] hover:bg-[#FAFBFC]">
                          <td className="px-2 py-2 text-center">
                            <button onClick={() => setExpandedEqId(expandedEqId === eq.id ? null : eq.id)} className="text-[#6B7280] hover:text-[#1A56DB]">
                              {expandedEqId === eq.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                            </button>
                          </td>
                          <td className="px-2 py-2 font-medium text-[#1F2937]">{eq.name}</td>
                          <td className="px-2 py-2 text-[#6B7280] text-[11px]">{eq.model}</td>
                          <td className="px-2 py-2 text-[#6B7280] text-[11px]">{eq.code}</td>
                          <td className="px-2 py-2 text-[#374151] text-[11px]">{eq.unit}</td>
                          <td className="px-2 py-2 text-[11px]">{eq.isWholeBox ? <span className="rounded bg-[#DBEAFE] px-1.5 py-0.5 text-[11px] text-[#1A56DB]">是</span> : <span className="text-[#6B7280] text-[11px]">否</span>}</td>
                          <td className="px-2 py-2 text-[#1A56DB] text-[11px] font-mono">{eq.isWholeBox ? eq.boxCode : '-'}</td>
                          <td className="px-2 py-2">
                            <button onClick={() => setShowRfidCompareFor(eq.id)} className="text-[11px] text-[#1A56DB] hover:underline">
                              {eq.rfidCodes.length > 0 ? `共${eq.rfidCodes.length}个` : '-'}
                            </button>
                          </td>
                          <td className="px-2 py-2 text-right text-[#374151] text-[11px]">{eq.purchaseQty}</td>
                          <td className="px-2 py-2 text-right font-medium text-[#1A56DB] text-[11px]">{eq.deliveryQty}</td>
                          <td className="px-2 py-2 text-right text-[#374151] text-[11px]">{eq.unitPrice.toLocaleString()}</td>
                          <td className="px-2 py-2 text-right font-medium text-[#374151] text-[11px]">{eq.totalAmount.toLocaleString()}</td>
                          <td className="px-2 py-2 text-[#374151] text-[11px]">{eq.productionDate}</td>
                          <td className="px-2 py-2 text-[#374151] text-[11px]">{eq.expiryDate}</td>
                        </tr>
                        {expandedEqId === eq.id && (
                          <tr>
                            <td colSpan={14} className="border-b border-[#E5E7EB] bg-[#FAFBFC] px-4 py-3">
                              <div className="grid grid-cols-3 gap-4">
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">发货RFID编码 ({eq.rfidCodes.length}个)</label>
                                  <div className="max-h-[120px] overflow-auto rounded-md border border-[#E5E7EB] bg-white p-2">
                                    <div className="flex flex-wrap gap-1">
                                      {eq.rfidCodes.map((code, idx) => (
                                        <span key={idx} className="rounded bg-[#EFF6FF] px-1.5 py-0.5 text-[10px] font-mono text-[#1A56DB]">{code}</span>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">验收意见</label>
                                  <textarea value={eq.inspectionOpinion} onChange={(e) => handleOpinionChange(eq.id, e.target.value)} rows={4} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" placeholder="填写合格/不合格原因..." />
                                </div>
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">验收照片</label>
                                  <div className="flex flex-wrap gap-1.5">
                                    {eq.inspectionPhotos.map((photo, idx) => (
                                      <div key={idx} className="relative h-12 w-12 rounded border border-[#E5E7EB] bg-[#F9FAFB] overflow-hidden">
                                        <div className="flex h-full w-full items-center justify-center text-[9px] text-[#6B7280] text-center leading-tight px-0.5">{photo}</div>
                                        <button onClick={() => handleRemovePhoto(eq.id, idx)} className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#EF4444] text-white"><X size={8} /></button>
                                      </div>
                                    ))}
                                    <button onClick={() => setPhotoFor(eq.id)} className="flex h-12 w-12 flex-col items-center justify-center rounded border border-dashed border-[#D1D5DB] text-[#9CA3AF] hover:border-[#1A56DB] hover:text-[#1A56DB]"><Camera size={12} /><span className="text-[9px]">照片</span></button>
                                  </div>
                                </div>
                              </div>
                              <div className="mt-3 flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-white px-3 py-2">
                                <span className="text-xs font-medium text-[#374151]">实物RFID比对：</span>
                                <span className="text-[11px] text-[#6B7280]">已扫 {eq.actualRfidCodes.length} / {eq.rfidCodes.length}</span>
                                {eq.actualRfidCodes.length > 0 && (() => {
                                  const r = getRfidCompareResult(eq)
                                  return (
                                    <>
                                      <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[10px] text-[#059669]">匹配 {r.matched}</span>
                                      {r.missing > 0 && <span className="rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[10px] text-[#DC2626]">缺失 {r.missing}</span>}
                                      {r.extra > 0 && <span className="rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[10px] text-[#D97706]">多出 {r.extra}</span>}
                                    </>
                                  )
                                })()}
                                <div className="ml-auto flex items-center gap-2">
                                  <button onClick={() => handleActualRfidScan(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2 text-xs text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={11} /> 扫描实物</button>
                                  {eq.actualRfidCodes.length > 0 && (
                                    <button onClick={() => handleClearActualRfid(eq.id)} className="text-[11px] text-[#6B7280] hover:text-[#EF4444]">清空</button>
                                  )}
                                  <button onClick={() => setShowRfidCompareFor(eq.id)} className="text-[11px] text-[#1A56DB] hover:underline">详细对比</button>
                                </div>
                              </div>
                              {/* 合格数量为0时的处理提示已移除 */}
                            </td>
                          </tr>
                        )}
                      </>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="border-t border-[#E5E7EB] bg-[#F0F5FF]">
                      <td colSpan={11} className="px-2 py-2 text-right text-[11px] font-semibold text-[#374151]">合计</td>
                      <td className="px-2 py-2 text-right text-[11px] font-bold text-[#1A56DB]">{totalDeliveryAmount.toLocaleString()}</td>
                      <td colSpan={2}></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          </div>

          {/* ═══ 区域2：到货验收 ═══ */}
          <div className="rounded-lg border border-[#10B981]/30 bg-[#F0FDF4]">
            <div className="flex items-center gap-2 border-b border-[#10B981]/20 bg-[#10B981]/5 px-4 py-2.5">
              <div className="flex h-5 w-5 items-center justify-center rounded bg-[#10B981] text-[10px] font-bold text-white">验</div>
              <span className="text-sm font-semibold text-[#059669]">到货验收</span>
            </div>
            <div className="p-4 space-y-4">
              {/* 收货信息 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#374151]">收货人 <span className="text-[#EF4444]">*</span></label>
                  <input type="text" value={receiverName} onChange={e => setReceiverName(e.target.value)} placeholder="请输入收货人姓名" className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-semibold text-[#374151]">收货时间 <span className="text-[#EF4444]">*</span></label>
                  <input type="text" value={receiveTime} onChange={e => setReceiveTime(e.target.value)} placeholder="YYYY-MM-DD HH:mm" className="h-8 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
              </div>
              {/* 工具栏 */}
              <div className="flex items-center gap-2">
                <button onClick={() => fileRef.current?.click()} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileSpreadsheet size={14} /> 导入Excel批量验收</button>
                <button onClick={() => alert('RFID扫描验收：请将RFID读写器靠近装备标签进行批量扫描验收')} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={14} /> RFID扫描验收</button>
                <button onClick={() => alert('连接设备：正在搜索附近的RFID读写器设备...')} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Wifi size={14} /> 连接设备</button>
                <input ref={fileRef} type="file" accept=".xlsx,.xls" className="hidden" onChange={() => alert('Excel导入功能演示')} />
              </div>
              {/* 验收表格（带展开编辑） */}
              <div className="rounded-lg border border-[#E5E7EB] overflow-hidden bg-white">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#E5E7EB] bg-[#ECFDF5]">
                      <th className="w-8 px-2 py-2"></th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">型号</th>
                      <th className="px-2 py-2 text-right text-[11px] font-semibold text-[#6B7280]">本次发货</th>
                      <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">实际到货</th>
                      <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">合格数量</th>
                      <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">不合格</th>
                      <th className="px-2 py-2 text-center text-[11px] font-semibold text-[#6B7280]">状态</th>
                      <th className="px-2 py-2 text-left text-[11px] font-semibold text-[#6B7280]">验收意见</th>
                    </tr>
                  </thead>
                  <tbody>
                    {equipments.map((eq) => (
                      <>
                        <tr key={`ins-${eq.id}`} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                          <td className="px-2 py-2 text-center">
                            <button onClick={() => setExpandedEqId(expandedEqId === eq.id ? null : eq.id)} className="text-[#6B7280] hover:text-[#1A56DB]">
                              {expandedEqId === eq.id ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                            </button>
                          </td>
                          <td className="px-2 py-2 font-medium text-[#1F2937] text-[11px]">{eq.name}</td>
                          <td className="px-2 py-2 text-[#6B7280] text-[11px]">{eq.model}</td>
                          <td className="px-2 py-2 text-right font-medium text-[#1A56DB] text-[11px]">{eq.deliveryQty} {eq.unit}</td>
                          <td className="px-2 py-2 text-center">
                            <input type="number" min={0} max={eq.deliveryQty} value={eq.actualQty} onChange={(e) => { const v = Math.max(0, Math.min(eq.deliveryQty, parseInt(e.target.value) || 0)); setEquipments(prev => prev.map(ee => ee.id === eq.id ? { ...ee, actualQty: v } : ee)) }} className="h-7 w-16 rounded-md border border-[#D1D5DB] px-1 text-center text-sm outline-none focus:border-[#1A56DB]" placeholder="0" />
                          </td>
                          <td className="px-2 py-2 text-center">
                            <input type="number" min={0} max={eq.actualQty} value={eq.qualifiedQty ?? ''} onChange={(e) => handleQtyChange(eq.id, e.target.value)} className={cn('h-7 w-16 rounded-md border px-1 text-center text-sm outline-none', eq.qualifiedQty !== null && eq.qualifiedQty === 0 ? 'border-[#EF4444] bg-[#FEE2E2]' : 'border-[#D1D5DB] focus:border-[#1A56DB]')} placeholder="0" />
                          </td>
                          <td className="px-2 py-2 text-center text-[11px]">{eq.unqualifiedQty ?? '-'}</td>
                          <td className="px-2 py-2 text-center">{getStatusBadge(eq)}</td>
                          <td className="px-2 py-2 text-[11px] text-[#374151] max-w-[160px] truncate" title={eq.inspectionOpinion}>{eq.inspectionOpinion || '-'}</td>
                        </tr>
                        {expandedEqId === eq.id && (
                          <tr>
                            <td colSpan={9} className="border-b border-[#E5E7EB] bg-[#FAFBFC] px-4 py-3">
                              <div className="grid grid-cols-3 gap-4">
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">发货RFID编码 ({eq.rfidCodes.length}个)</label>
                                  <div className="max-h-[120px] overflow-auto rounded-md border border-[#E5E7EB] bg-white p-2">
                                    <div className="flex flex-wrap gap-1">
                                      {eq.rfidCodes.map((code, idx) => (
                                        <span key={idx} className="rounded bg-[#EFF6FF] px-1.5 py-0.5 text-[10px] font-mono text-[#1A56DB]">{code}</span>
                                      ))}
                                    </div>
                                  </div>
                                </div>
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">验收意见</label>
                                  <textarea value={eq.inspectionOpinion} onChange={(e) => handleOpinionChange(eq.id, e.target.value)} rows={4} className="w-full rounded-md border border-[#D1D5DB] px-2 py-1.5 text-xs outline-none focus:border-[#1A56DB]" placeholder="填写合格/不合格原因..." />
                                </div>
                                <div>
                                  <label className="mb-1 block text-xs font-medium text-[#374151]">验收照片</label>
                                  <div className="flex flex-wrap gap-1.5">
                                    {eq.inspectionPhotos.map((photo, idx) => (
                                      <div key={idx} className="relative h-12 w-12 rounded border border-[#E5E7EB] bg-[#F9FAFB] overflow-hidden">
                                        <div className="flex h-full w-full items-center justify-center text-[9px] text-[#6B7280] text-center leading-tight px-0.5">{photo}</div>
                                        <button onClick={() => handleRemovePhoto(eq.id, idx)} className="absolute -right-1 -top-1 flex h-3.5 w-3.5 items-center justify-center rounded-full bg-[#EF4444] text-white"><X size={8} /></button>
                                      </div>
                                    ))}
                                    <button onClick={() => setPhotoFor(eq.id)} className="flex h-12 w-12 flex-col items-center justify-center rounded border border-dashed border-[#D1D5DB] text-[#9CA3AF] hover:border-[#1A56DB] hover:text-[#1A56DB]"><Camera size={12} /><span className="text-[9px]">照片</span></button>
                                  </div>
                                </div>
                              </div>
                              <div className="mt-3 flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-white px-3 py-2">
                                <span className="text-xs font-medium text-[#374151]">实物RFID比对：</span>
                                <span className="text-[11px] text-[#6B7280]">已扫 {eq.actualRfidCodes.length} / {eq.rfidCodes.length}</span>
                                {eq.actualRfidCodes.length > 0 && (() => {
                                  const r = getRfidCompareResult(eq)
                                  return (
                                    <>
                                      <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[10px] text-[#059669]">匹配 {r.matched}</span>
                                      {r.missing > 0 && <span className="rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[10px] text-[#DC2626]">缺失 {r.missing}</span>}
                                      {r.extra > 0 && <span className="rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[10px] text-[#D97706]">多出 {r.extra}</span>}
                                    </>
                                  )
                                })()}
                                <div className="ml-auto flex items-center gap-2">
                                  <button onClick={() => handleActualRfidScan(eq.id)} className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-2 text-xs text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={11} /> 扫描实物</button>
                                  {eq.actualRfidCodes.length > 0 && (
                                    <button onClick={() => handleClearActualRfid(eq.id)} className="text-[11px] text-[#6B7280] hover:text-[#EF4444]">清空</button>
                                  )}
                                  <button onClick={() => setShowRfidCompareFor(eq.id)} className="text-[11px] text-[#1A56DB] hover:underline">详细对比</button>
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          {/* ═══ 区域3：到货处置 ═══ */}
          <DisposalSection
            equipments={equipments}
            setEquipments={setEquipments}
            expandedDisposalId={expandedDisposalId}
            setExpandedDisposalId={setExpandedDisposalId}
          />
        </div>

        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={handleCancel} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">确认验收</button>
        </div>
      </div>

      {showRfidCompareFor && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => setShowRfidCompareFor(null)} />
          <div className="relative z-10 w-[700px] max-w-[90vw] rounded-xl bg-white p-6 shadow-2xl max-h-[80vh] flex flex-col">
            {(() => {
              const eq = equipments.find(e => e.id === showRfidCompareFor)
              if (!eq) return null
              const r = getRfidCompareResult(eq)
              const actualSet = new Set(eq.actualRfidCodes)
              return (
                <>
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-semibold text-[#1F2937]">RFID编码对比 — {eq.name}</h3>
                      <p className="mt-1 text-xs text-[#6B7280]">
                        <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[#059669]">匹配 {r.matched}</span>
                        <span className="ml-2 rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[#DC2626]">缺失 {r.missing}</span>
                        <span className="ml-2 rounded bg-[#FEF3C7] px-1.5 py-0.5 text-[#D97706]">多出 {r.extra}</span>
                      </p>
                    </div>
                    <button onClick={() => setShowRfidCompareFor(null)} className="text-[#6B7280] hover:text-[#EF4444]"><X size={16} /></button>
                  </div>
                  <div className="flex-1 overflow-auto space-y-4">
                    <div>
                      <h4 className="mb-2 text-xs font-semibold text-[#1A56DB]">发货RFID编码 ({eq.rfidCodes.length}个)</h4>
                      <div className="flex flex-wrap gap-1.5">
                        {eq.rfidCodes.map((code, idx) => {
                          const isMatched = actualSet.has(code)
                          return (
                            <span key={idx} className={cn('rounded px-2 py-1 text-[11px] font-mono', isMatched ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#FEE2E2] text-[#DC2626]')}>{code}</span>
                          )
                        })}
                      </div>
                    </div>
                    <div>
                      <div className="mb-2 flex items-center justify-between">
                        <h4 className="text-xs font-semibold text-[#059669]">实物RFID编码 ({eq.actualRfidCodes.length}个)</h4>
                        <div className="flex items-center gap-2">
                          <button onClick={() => handleActualRfidScan(eq.id)} className="inline-flex h-6 items-center gap-1 rounded border border-[#E5E7EB] px-2 text-[11px] text-[#374151] hover:bg-[#F3F4F6]"><ScanLine size={10} /> 扫描</button>
                          {eq.actualRfidCodes.length > 0 && <button onClick={() => handleClearActualRfid(eq.id)} className="text-[11px] text-[#6B7280] hover:text-[#EF4444]">清空</button>}
                        </div>
                      </div>
                      {eq.actualRfidCodes.length > 0 ? (
                        <div className="flex flex-wrap gap-1.5">
                          {eq.actualRfidCodes.map((code, idx) => {
                            const isInDelivery = eq.rfidCodes.includes(code)
                            return (
                              <span key={idx} className={cn('rounded px-2 py-1 text-[11px] font-mono', isInDelivery ? 'bg-[#D1FAE5] text-[#059669]' : 'bg-[#FEF3C7] text-[#D97706]')}>{code}</span>
                            )
                          })}
                        </div>
                      ) : (
                        <div className="rounded-md border border-dashed border-[#D1D5DB] py-6 text-center text-xs text-[#9CA3AF]">尚未扫描实物RFID编码，点击"扫描"按钮开始扫描</div>
                      )}
                    </div>
                  </div>
                </>
              )
            })()}
          </div>
        </div>
      )}

      {photoFor && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/30" onClick={() => { setPhotoFor(null); setPhotoText('') }} />
          <div className="relative z-10 w-[380px] max-w-[90vw] rounded-xl bg-white p-5 shadow-2xl">
            <div className="mb-3 flex items-center justify-between"><h3 className="text-base font-semibold text-[#1F2937]">添加验收照片</h3><button onClick={() => { setPhotoFor(null); setPhotoText('') }} className="text-[#6B7280] hover:text-[#EF4444]"><X size={16} /></button></div>
            <input type="text" value={photoText} onChange={(e) => setPhotoText(e.target.value)} placeholder="输入照片描述..." className="mb-3 w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
            <div className="flex justify-end gap-2">
              <button onClick={() => { setPhotoFor(null); setPhotoText('') }} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">取消</button>
              <button onClick={() => { if (photoText.trim()) { handleAddPhoto(photoFor, photoText.trim()); setPhotoText('') } setPhotoFor(null) }} className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">添加</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

/* ═══════════════════════════════════════════
   打印模态框组件
   ═══════════════════════════════════════════ */

function PrintModal({ receipt, open, onClose }: { receipt: PurchaseReceipt | null; open: boolean; onClose: () => void }) {
  const [printType, setPrintType] = useState<'receipt' | 'return' | 'inbound'>('receipt')
  if (!open || !receipt) return null

  const printContent = () => {
    switch (printType) {
      case 'receipt': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#1F2937]">收货单</h2><p className="text-sm text-[#6B7280]">NO. {receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">订单名称：</span>{receipt.orderName}</div><div><span className="text-[#6B7280]">关联合同：</span>{receipt.contractNo}</div><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div><div><span className="text-[#6B7280]">企业编码：</span>{receipt.enterpriseCode}</div><div><span className="text-[#6B7280]">预计送货日期：</span>{receipt.deliveryDate}</div><div><span className="text-[#6B7280]">收货对象：</span>{receipt.receiver}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#F9FAFB]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-left">装备编码</th><th className="px-3 py-2 text-right">本次发货</th></tr></thead><tbody>{receipt.equipments.map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2">{eq.code}</td><td className="px-3 py-2 text-right">{eq.deliveryQty} {eq.unit}</td></tr>)}</tbody></table></div>
      case 'return': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#DC2626]">退货单</h2><p className="text-sm text-[#6B7280]">原发货单号：{receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div><div><span className="text-[#6B7280]">合同：</span>{receipt.contractNo}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#FEE2E2]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-right">退货数量</th><th className="px-3 py-2 text-left">退货原因</th></tr></thead><tbody>{receipt.equipments.filter(e => e.inspectionStatus === 'return' || e.inspectionStatus === 'exchange').map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2 text-right">{eq.deliveryQty} {eq.unit}</td><td className="px-3 py-2">{eq.inspectionOpinion || '质量不合格'}</td></tr>)}</tbody></table></div>
      case 'inbound': return <div className="space-y-4"><div className="text-center"><h2 className="text-xl font-bold text-[#059669]">入库单</h2><p className="text-sm text-[#6B7280]">关联发货单：{receipt.id}</p></div><div className="grid grid-cols-2 gap-3 text-sm"><div><span className="text-[#6B7280]">入库仓库：</span>{receipt.warehouseName || '-'}</div><div><span className="text-[#6B7280]">存储位置：</span>{receipt.storageLocation || '-'}</div><div><span className="text-[#6B7280]">供应商：</span>{receipt.supplier}</div></div><table className="w-full border-collapse text-sm"><thead><tr className="border-y border-[#E5E7EB] bg-[#D1FAE5]"><th className="px-3 py-2 text-left">装备名称</th><th className="px-3 py-2 text-left">型号</th><th className="px-3 py-2 text-right">合格数量</th><th className="px-3 py-2 text-right">不合格数量</th></tr></thead><tbody>{receipt.equipments.filter(e => (e.qualifiedQty || 0) > 0).map(eq => <tr key={eq.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2">{eq.name}</td><td className="px-3 py-2">{eq.model}</td><td className="px-3 py-2 text-right">{eq.qualifiedQty} {eq.unit}</td><td className="px-3 py-2 text-right">{eq.unqualifiedQty || 0} {eq.unit}</td></tr>)}</tbody></table></div>
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[720px] max-w-[95vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">打印单据</h2>
          <button onClick={onClose} className="text-[#6B7280] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        <div className="px-6 py-4">
          <div className="mb-4 flex gap-2">
            {[{ key: 'receipt' as const, label: '收货单' }, { key: 'return' as const, label: '退货单' }, { key: 'inbound' as const, label: '入库单' }].map(t => <button key={t.key} onClick={() => setPrintType(t.key)} className={cn('rounded-md px-3 py-1.5 text-sm transition', printType === t.key ? 'bg-[#1A56DB] text-white' : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB]')}>{t.label}</button>)}
          </div>
          <div className="rounded-lg border border-[#E5E7EB] bg-white p-6">{printContent()}</div>
        </div>
        <div className="flex justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">关闭</button>
          <button onClick={() => alert('打印功能演示')} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Printer size={14} className="mr-1 inline" /> 打印</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   通用操作按钮组件
   ═══════════════════════════════════════════ */

function RowActions({ status, onConfirm, onEdit, onDetail, onDelete }: { status: string; onConfirm?: () => void; onEdit?: () => void; onDetail: () => void; onDelete: () => void }) {
  return (
    <div className="flex items-center justify-center gap-1">
      {status === 'recorded' && onConfirm && (
        <button onClick={onConfirm} className="flex h-7 items-center gap-0.5 rounded-md bg-[#10B981] px-2 text-[11px] text-white hover:bg-[#059669]" title="确认"><Check size={11} />确认</button>
      )}
      {status === 'recorded' && onEdit && (
        <button onClick={onEdit} className="flex h-7 w-7 items-center justify-center rounded-md text-[#F59E0B] hover:bg-[#FEF3C7]" title="修改"><Edit3 size={13} /></button>
      )}
      <button onClick={onDetail} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] hover:bg-[#E8F0FE]" title="详情"><Eye size={14} /></button>
      <button onClick={onDelete} className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
    </div>
  )
}

/* ═══════════════════════════════════════════
   到货验收主模块
   ═══════════════════════════════════════════ */

function PurchaseInboundModule() {
  const [activePurchaseTab, setActivePurchaseTab] = useState('pending-receipt')
  const [receipts, setReceipts] = useState<PurchaseReceipt[]>(purchaseReceipts)
  const [expandedRowId, setExpandedRowId] = useState<string | null>(null)
  const [inspectionReceipt, setInspectionReceipt] = useState<PurchaseReceipt | null>(null)
  const [showInspection, setShowInspection] = useState(false)
  const [printReceipt, setPrintReceipt] = useState<PurchaseReceipt | null>(null)
  const [showPrint, setShowPrint] = useState(false)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleReset = () => setFilterValues({})
  const handleInspect = (receipt: PurchaseReceipt) => { setInspectionReceipt(receipt); setShowInspection(true) }
  const handleSaveInspection = (updated: PurchaseReceipt) => { setReceipts(prev => prev.map(r => r.id === updated.id ? updated : r)) }
  const handlePrint = (receipt: PurchaseReceipt) => { setPrintReceipt(receipt); setShowPrint(true) }
  const filteredData = receipts.filter(row => row.status === activePurchaseTab)

  const pendingFilterFields = [
    { key: 'receiptNo', label: '发货单号', type: 'input' as const, placeholder: '请输入发货单号' },
    { key: 'orderName', label: '订单名称', type: 'input' as const, placeholder: '请输入订单名称' },
    { key: 'contractNo', label: '关联合同', type: 'input' as const, placeholder: '请输入合同号' },
    { key: 'supplier', label: '供应商', type: 'select' as const, options: [{ label: '某省安防科技有限公司', value: 'YYY省安防' }, { label: '某市警用装备厂', value: 'YYY警用' }, { label: '某市防护科技集团', value: 'YYY防护' }, { label: '某市智能装备有限公司', value: 'YYY智能' }, { label: '某市视讯安防股份', value: 'YYY视讯' }, { label: '某省警用器材厂', value: 'YYY省警用' }, { label: '某市安防设备公司', value: 'YYY安防' }, { label: '某市防护用品有限公司', value: 'YYY防护' }] },
    { key: 'receiver', label: '收货对象', type: 'select' as const, options: [{ label: 'XXX省公安厅装备处', value: 'XXX省公安厅装备处' }, { label: 'YYY市公安局装备处', value: 'YYY市公安局装备处' }, { label: 'YYY市公安局装备处', value: 'YYY市公安局装备处' }, { label: 'YYY市公安局装备处', value: 'YYY市公安局装备处' }, { label: 'YYY市公安局装备处', value: 'YYY市公安局装备处' }, { label: 'YYY市公安局装备处', value: 'YYY市公安局装备处' }] },
    { key: 'deliveryStart', label: '送货日期（起）', type: 'date' as const },
    { key: 'deliveryEnd', label: '送货日期（止）', type: 'date' as const },
  ]

  const inspectedFilterFields = [
    { key: 'receiptNo', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'orderName', label: '采购项目', type: 'input' as const, placeholder: '请输入采购项目' },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: 'XXX省公安厅', value: 'XXX省公安厅' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }] },
  ]

  return (
    <>
      {/* 子标签 */}
      <div className="mt-4 border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {purchaseTabs.map((tab) => (
            <button key={tab.key} onClick={() => setActivePurchaseTab(tab.key)} className={cn('relative flex h-10 items-center gap-1.5 text-sm transition', activePurchaseTab === tab.key ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]')}>
              {tab.label}
              {tab.badge > 0 && <span className={`flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[11px] font-bold text-white ${tab.badgeVariant === 'danger' ? 'bg-[#EF4444]' : tab.badgeVariant === 'warning' ? 'bg-[#F59E0B]' : tab.badgeVariant === 'success' ? 'bg-[#10B981]' : 'bg-[#9CA3AF]'}`}>{tab.badge}</span>}
              {activePurchaseTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
            </button>
          ))}
        </div>
      </div>

      {/* 操作按钮 */}
      {activePurchaseTab === 'pending-receipt' && (
        <div className="mt-4 flex items-center gap-2">
          <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Plus size={14} /> 手工入库</button>
          <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"><Upload size={14} /> 导入</button>
        </div>
      )}

      {/* 筛选 */}
      <div className="mt-4">
        <FilterPanel
          fields={activePurchaseTab === 'pending-receipt' ? pendingFilterFields : inspectedFilterFields}
          values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset}
        />
      </div>

      {/* 待收货表格 */}
      {activePurchaseTab === 'pending-receipt' && (
        <div className="mt-4">
          <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                    <th className="w-10 px-2 py-3"></th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发货单号</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">订单名称</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">关联合同</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">供应商</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">企业编码</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备清单</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预计送货日期</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">收货对象</th>
                    <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.map((row) => (
                    <>
                      <tr key={row.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', expandedRowId === row.id && 'bg-[#F9FAFB]')}>
                        <td className="px-2 py-3 text-center"><button onClick={() => setExpandedRowId(expandedRowId === row.id ? null : row.id)} className="text-[#6B7280] hover:text-[#1A56DB]">{expandedRowId === row.id ? <ChevronDown size={16} /> : <ChevronRight size={16} />}</button></td>
                        <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.orderName}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.contractNo}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.supplier}</td>
                        <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.enterpriseCode}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentSummary}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.deliveryDate}</td>
                        <td className="px-4 py-3 text-[13px] text-[#374151]">{row.receiver}</td>
                        <td className="px-4 py-3 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button onClick={() => handleInspect(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white hover:bg-[#059669]"><PackageCheck size={12} /> 验收</button>
                            <button onClick={() => handlePrint(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><Printer size={14} /></button>
                          </div>
                        </td>
                      </tr>
                      {expandedRowId === row.id && (
                        <tr>
                          <td colSpan={10} className="border-b border-[#E5E7EB] bg-[#FAFBFC] px-4 py-4">
                            <div className="mb-2 text-xs font-semibold text-[#6B7280]">装备明细</div>
                            <table className="w-full border-collapse">
                              <thead>
                                <tr className="border-y border-[#E5E7EB] bg-[#F3F4F6]">
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">一级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">二级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">三级分类</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">型号</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">整箱</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">箱体码</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">发货RFID</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">采购数量</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">本次发货</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价(元)</th>
                                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">金额(元)</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期至</th>
                                </tr>
                              </thead>
                              <tbody>
                                {row.equipments.map((eq) => (
                                  <tr key={eq.id} className="border-b border-[#F3F4F6]">
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category1}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category2}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.category3}</td>
                                    <td className="px-3 py-2 text-[12px] font-medium text-[#1F2937]">{eq.name}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.model}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{eq.code}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.unit}</td>
                                    <td className="px-3 py-2 text-[12px]">{eq.isWholeBox ? <Badge variant="primary">是</Badge> : <span className="text-[#6B7280]">否</span>}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#1A56DB] font-mono">{eq.isWholeBox ? eq.boxCode : '-'}</td>
                                    <td className="px-3 py-2 text-[12px]"><span className="text-[#6B7280]">共{eq.rfidCodes.length}个</span></td>
                                    <td className="px-3 py-2 text-right text-[12px] text-[#374151]">{eq.purchaseQty}</td>
                                    <td className="px-3 py-2 text-right text-[12px] font-medium text-[#1A56DB]">{eq.deliveryQty}</td>
                                    <td className="px-3 py-2 text-right text-[12px] text-[#374151]">{eq.unitPrice.toLocaleString()}</td>
                                    <td className="px-3 py-2 text-right text-[12px] font-medium text-[#374151]">{eq.totalAmount.toLocaleString()}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.productionDate}</td>
                                    <td className="px-3 py-2 text-[12px] text-[#374151]">{eq.expiryDate}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 已验收表格 */}
      {activePurchaseTab === 'inspected' && (
        <div className="mt-4">
          <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">采购项目</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">采购日期</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                    <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">合格数量</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">处置详情</th>
                    <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">收货人/时间</th>
                    <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredData.flatMap((row) =>
                    row.equipments.filter(e => (e.qualifiedQty || 0) > 0).map((eq, idx) => {
                      const receiptName = eq.receiptInfo?.receiverName || '-'
                      const receiptTime = eq.receiptInfo?.receiveTime || '-'
                      return (
                        <tr key={`${row.id}-${eq.id}`} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                          <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{idx === 0 ? row.id : ''}</td>
                          <td className="px-4 py-3 text-[13px] text-[#374151]">{idx === 0 ? row.orderName : ''}</td>
                          <td className="px-4 py-3 text-[13px] text-[#374151]">{idx === 0 ? row.deliveryDate : ''}</td>
                          <td className="px-4 py-3 text-[13px] text-[#374151]">{eq.name}</td>
                          <td className="px-4 py-3 text-[13px] text-[#6B7280]">{eq.model}</td>
                          <td className="px-4 py-3 text-right text-[13px] font-medium text-[#1A56DB]">{eq.qualifiedQty} {eq.unit}</td>
                          <td className="px-4 py-3 text-[12px]">
                            {eq.disposals?.length ? (
                              <div className="space-y-0.5">
                                {eq.disposals.map((dsp, i) => (
                                  <div key={i} className="flex items-center gap-1">
                                    {dsp.type === 'inbound' ? (
                                      <><span className="rounded bg-[#DBEAFE] px-1 py-0.5 text-[10px] text-[#1A56DB]">入库</span><span className="text-[#374151] truncate max-w-[120px]" title={dsp.storageLocation}>{dsp.storageLocation || '-'}</span><span className="text-[#6B7280]">{dsp.quantity}{eq.unit}</span></>
                                    ) : (
                                      <><span className="rounded bg-[#D1FAE5] px-1 py-0.5 text-[10px] text-[#059669]">交付</span><span className="text-[#374151]">{dsp.targetUnit || '-'}</span>{dsp.targetObject && <span className="text-[#6B7280]">({dsp.targetObject})</span>}<span className="text-[#6B7280]">{dsp.quantity}{eq.unit}</span></>
                                    )}
                                  </div>
                                ))}
                              </div>
                            ) : '-'}
                          </td>
                          <td className="px-4 py-3 text-[12px] text-[#374151]">
                            <div className="flex flex-col">
                              <span>{receiptName}</span>
                              <span className="text-[10px] text-[#6B7280]">{receiptTime}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-center">
                            <div className="flex items-center justify-center gap-1">
                              <button onClick={() => handleInspect(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white hover:bg-[#153E7E]"><Eye size={12} /> 查看</button>
                              <button onClick={() => handlePrint(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><Printer size={14} /></button>
                            </div>
                          </td>
                        </tr>
                      )
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      <InspectionDialog receipt={inspectionReceipt} open={showInspection} onClose={() => { setShowInspection(false); setInspectionReceipt(null) }} onSave={handleSaveInspection} />
      <PrintModal receipt={printReceipt} open={showPrint} onClose={() => { setShowPrint(false); setPrintReceipt(null) }} />
    </>
  )
}

/* ═══════════════════════════════════════════
   期初入库模块
   ═══════════════════════════════════════════ */

function InitialInboundModule() {
  const [data, setData] = useState<InitialRecord[]>(initialData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '历史库存导入', value: '历史库存导入' }, { label: '手动录入', value: '手动录入' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: 'XXX省公安厅', value: 'XXX省公安厅' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'ZZZ区公安分局', value: 'ZZZ区公安分局' }, { label: 'ZZZ区公安分局', value: 'ZZZ区公安分局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }] },
    { key: 'equipmentName', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Upload size={14} /> 导入历史库存</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">入库数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-36 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onEdit={row.status === 'recorded' ? () => alert(`修改 ${row.id}`) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   调拨入库模块
   ═══════════════════════════════════════════ */

function TransferInboundModule() {
  const [data, setData] = useState<TransferRecord[]>(transferData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '同步订单', value: '同步订单' }, { label: '手动添加', value: '手动添加' }] },
    { key: 'transferOrderNo', label: '调拨单号', type: 'input' as const, placeholder: '请输入调拨单号' },
    { key: 'senderUnit', label: '发物单位', type: 'select' as const, options: [{ label: '某市总仓', value: '某市总仓' }, { label: '某市分仓', value: '某市分仓' }, { label: '某市分仓', value: '某市分仓' }, { label: '某市分仓', value: '某市分仓' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: 'XXX省公安厅', value: 'XXX省公安厅' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }] },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileInput size={14} /> 选择同步订单</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调拨单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">发物单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">调拨数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.transferOrderNo}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.senderUnit}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   归还入库模块
   ═══════════════════════════════════════════ */

function ReturnInboundModule() {
  const [data, setData] = useState<ReturnRecord[]>(returnData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'borrower', label: '借用人/单位', type: 'input' as const, placeholder: '请输入借用人/单位' },
    { key: 'borrowOrderNo', label: '借用单号', type: 'input' as const, placeholder: '请输入借用单号' },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: 'XXX省公安厅', value: 'XXX省公安厅' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }] },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><FileInput size={14} /> 选择同步订单</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用人/单位</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">预计归还</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">借用单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">借用数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-32 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.borrower}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.borrowDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.expectedReturnDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.borrowOrderNo}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   其他入库模块
   ═══════════════════════════════════════════ */

function OtherInboundModule() {
  const [data, setData] = useState<OtherRecord[]>(otherData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleReset = () => setFilterValues({})

  const handleConfirm = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'stored' as const } : d)) }
  const handleDelete = (id: string) => { if (confirm('确定删除该记录？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filterFields = [
    { key: 'id', label: '入库单号', type: 'input' as const, placeholder: '请输入入库单号' },
    { key: 'materialSource', label: '物资来源', type: 'select' as const, options: [{ label: '捐赠', value: '捐赠' }, { label: '调配', value: '调配' }, { label: '自制', value: '自制' }] },
    { key: 'storageLocation', label: '存储位置', type: 'select' as const, options: [{ label: 'XXX省公安厅', value: 'XXX省公安厅' }, { label: 'YYY市公安局', value: 'YYY市公安局' }, { label: 'YYY市公安局', value: 'YYY市公安局' }] },
    { key: 'equipmentName', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
    { key: 'status', label: '状态', type: 'select' as const, options: [{ label: '已录入', value: 'recorded' }, { label: '已入库', value: 'stored' }] },
  ]

  return (
    <>
      <div className="mt-4 flex items-center gap-2">
        <button className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><Plus size={14} /> 手动添加</button>
      </div>
      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={() => {}} onReset={handleReset} /></div>
      <div className="mt-4">
        <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库单号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资来源</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">存储位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">入库数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库时间</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">入库人</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                  <th className="w-36 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row) => (
                  <tr key={row.id} className="border-b border-[#F3F4F6] hover:bg-[#F9FAFB]">
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.materialSource}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.storageLocation}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.equipmentName}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{row.model}</td>
                    <td className="px-4 py-3 text-right text-[13px] text-[#374151]">{row.quantity}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundDate}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{row.inboundBy}</td>
                    <td className="px-4 py-3"><InboundStatusBadge status={row.status} /></td>
                    <td className="px-4 py-3 text-center">
                      <RowActions
                        status={row.status}
                        onConfirm={row.status === 'recorded' ? () => handleConfirm(row.id) : undefined}
                        onEdit={row.status === 'recorded' ? () => alert(`修改 ${row.id}`) : undefined}
                        onDetail={() => alert(`详情 ${row.id}`)}
                        onDelete={() => handleDelete(row.id)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面组件
   ═══════════════════════════════════════════ */

export default function InboundPage() {
  const [activeType, setActiveType] = useState('purchase')

  const renderContent = () => {
    switch (activeType) {
      case 'purchase': return <PurchaseInboundModule />
      case 'initial': return <InitialInboundModule />
      case 'transfer': return <TransferInboundModule />
      case 'return': return <ReturnInboundModule />
      case 'other': return <OtherInboundModule />
      default: return null
    }
  }

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">入库管理</h1>
      </div>
      <div className="grid grid-cols-5 gap-3">
        {inboundTypes.map((type) => {
          const Icon = type.icon
          const isActive = activeType === type.key
          return (
            <button key={type.key} onClick={() => setActiveType(type.key)} className={cn('flex flex-col items-center gap-2 rounded-lg border p-4 transition', isActive ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB] shadow-sm' : 'border-[#E5E7EB] bg-white text-[#6B7280] hover:border-[#D1D5DB] hover:bg-[#F9FAFB]')}>
              <Icon size={24} />
              <span className={cn('text-sm font-medium', isActive && 'text-[#1A56DB]')}>{type.label}</span>
            </button>
          )
        })}
      </div>
      {renderContent()}
    </div>
  )
}
