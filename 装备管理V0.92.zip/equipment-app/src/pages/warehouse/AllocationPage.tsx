import { useState } from 'react'
import { Plus, Eye, Edit, Trash2, X, Package, RotateCcw, CheckCircle, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
}

interface SelectedEquipment {
  equip: StockEquipment
  qty: number
}

interface AllocRecord {
  id: string
  fromWarehouse: string
  toUnit: string
  items: string
  qty: number
  applicant: string
  time: string
  status: 'draft' | 'pending-approve' | 'approved' | 'rejected' | 'picking' | 'ready' | 'outbound' | 'delivered' | 'confirmed'
  equipments: SelectedEquipment[]
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级/L', remaining: 180, unit: '件', price: 2800, code: '0101P00300', supplier: '华为技术有限公司' },
  { id: '2', name: '执法记录仪 DSJ-A7', category: '执法设备', model: 'DSJ-A7/64G/高清', remaining: 145, unit: '台', price: 1800, code: '0101P00200', supplier: '海康威视数字技术股份有限公司' },
  { id: '3', name: '对讲机 PD780G', category: '通信装备', model: 'PD780G/U段', remaining: 95, unit: '台', price: 1200, code: '0101P00500', supplier: '烽火通信科技股份有限公司' },
  { id: '4', name: '防刺服 FCF-J', category: '防护装备', model: 'FCF-J/软质', remaining: 480, unit: '件', price: 2200, code: '0101P00400', supplier: '中兴通讯股份有限公司' },
  { id: '5', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', remaining: 280, unit: '顶', price: 1500, code: '0101P00600', supplier: '华为技术有限公司' },
  { id: '6', name: '手铐 SK-01', category: '警械装备', model: 'SK-01/不锈钢', remaining: 500, unit: '副', price: 80, code: '0101P00700', supplier: '大华技术股份有限公司' },
  { id: '7', name: '警棍 G-01', category: '警械装备', model: 'G-01/伸缩', remaining: 420, unit: '根', price: 120, code: '0101P00800', supplier: '大华技术股份有限公司' },
  { id: '8', name: '防割手套 FG-ST01', category: '防护装备', model: 'FG-ST01/五级', remaining: 260, unit: '双', price: 65, code: '0101P00900', supplier: '华为技术有限公司' },
]

/* ═══════════════════════════════════════════
   Mock 数据：配发记录
   ═══════════════════════════════════════════ */

const initialData: AllocRecord[] = [
  { id: 'PF20260603001', fromWarehouse: '省厅主仓库A区', toUnit: 'ZZZ分局巡特警大队', items: '防弹背心x20, 防刺服x20, 头盔x20', qty: 60, applicant: '王警官', time: '2026-06-03 09:00', status: 'draft', equipments: [] },
  { id: 'PF20260603002', fromWarehouse: '省厅主仓库B区', toUnit: 'ZZZ分局治安大队', items: '执法记录仪x30, 对讲机x30', qty: 60, applicant: '李警官', time: '2026-06-02 14:30', status: 'pending-approve', equipments: [] },
  { id: 'PF20260603003', fromWarehouse: '省厅主仓库A区', toUnit: 'ZZZ分局刑警大队', items: '手铐x50, 防割手套x50', qty: 100, applicant: '张警官', time: '2026-06-02 10:00', status: 'approved', equipments: [] },
  { id: 'PF20260603004', fromWarehouse: '省厅主仓库C区', toUnit: 'ZZZ分局交警大队', items: '反光背心x100', qty: 100, applicant: '赵警官', time: '2026-06-01 16:00', status: 'rejected', equipments: [] },
  { id: 'PF20260603005', fromWarehouse: '省厅主仓库A区', toUnit: '栖霞分局派出所', items: '防弹背心x10, 防刺服x10', qty: 20, applicant: '刘警官', time: '2026-06-01 09:00', status: 'picking', equipments: [] },
  { id: 'PF20260603006', fromWarehouse: '省厅主仓库B区', toUnit: 'ZZZ分局特警大队', items: '防暴服x20, 防弹盾牌x10', qty: 30, applicant: '陈警官', time: '2026-05-31 11:30', status: 'ready', equipments: [] },
  { id: 'PF20260603007', fromWarehouse: '省厅主仓库A区', toUnit: 'ZZZ分局指挥中心', items: '对讲机x20, 执法记录仪x10', qty: 30, applicant: '杨警官', time: '2026-05-30 15:00', status: 'outbound', equipments: [] },
  { id: 'PF20260603008', fromWarehouse: '省厅主仓库C区', toUnit: 'ZZZ分局治安大队', items: '警棍x30, 手铐x30', qty: 60, applicant: '周警官', time: '2026-05-29 10:00', status: 'delivered', equipments: [] },
  { id: 'PF20260603009', fromWarehouse: '省厅主仓库B区', toUnit: 'ZZZ分局巡警大队', items: '防弹背心x15, 头盔x15', qty: 30, applicant: '吴警官', time: '2026-05-28 14:00', status: 'confirmed', equipments: [] },
  { id: 'PF20260603010', fromWarehouse: '省厅主仓库A区', toUnit: 'ZZZ分局特警大队', items: '防刺服x30, 防割手套x30', qty: 60, applicant: '郑警官', time: '2026-05-27 09:30', status: 'pending-approve', equipments: [] },
]

/* ═══════════════════════════════════════════
   Status badge
   ═══════════════════════════════════════════ */

function AllocStatus({ status }: { status: string }) {
  switch (status) {
    case 'draft': return <Badge variant="default">草稿</Badge>
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'approved': return <Badge variant="success" dot>已通过</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    case 'picking': return <Badge variant="info" dot>拣货中</Badge>
    case 'ready': return <Badge variant="primary" dot>待出库</Badge>
    case 'outbound': return <Badge variant="info" dot>运输中</Badge>
    case 'delivered': return <Badge variant="primary" dot>已送达</Badge>
    case 'confirmed': return <Badge variant="success" dot>已确认</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   装备选择弹窗（参考报修管理）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedEquipment[]) => void
}) {
  const [selected, setSelected] = useState<SelectedEquipment[]>([])
  const [searchName, setSearchName] = useState('')

  if (!open) return null

  const filteredStock = stockEquipments.filter(e =>
    searchName ? e.name.includes(searchName) || e.code.includes(searchName) : true
  )

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, qty: 1 }]
    })
  }

  const updateQty = (id: string, qty: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, qty: Math.max(1, Math.min(qty, s.equip.remaining)) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"><option>全部位置</option><option>A区</option><option>B区</option><option>C区</option></select>
          <input type="text" value={searchName} onChange={e => setSearchName(e.target.value)} placeholder="物资名称..." className="h-8 w-40 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"><option>全部类别</option><option>防护装备</option><option>执法设备</option><option>通信装备</option><option>警械装备</option></select>
          <button className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">查询</button>
        </div>
        <div className="flex flex-1 overflow-hidden">
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map(equip => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center"><input type="checkbox" checked={isChecked(equip.id)} onChange={() => toggleEquip(equip)} className="h-4 w-4 rounded border-[#D1D5DB]" /></td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-right font-medium text-[#059669]">{equip.remaining}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.unit}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{equip.price.toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{equip.code}</td>
                    <td className="px-3 py-2 text-[11px] text-[#374151]">{equip.supplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">已选择装备 ({selected.length})</div>
            {selected.length === 0 && <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]"><Package size={32} className="mb-2 opacity-50" /><p className="text-xs">请从左侧选择装备</p></div>}
            {selected.map(s => (
              <div key={s.equip.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-2 flex items-center justify-between"><span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span><button onClick={() => removeSelected(s.equip.id)} className="text-xs text-[#EF4444] hover:underline">删除</button></div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-[#6B7280]"><span>类别: {s.equip.category}</span><span>规格: {s.equip.model}</span><span>编码: {s.equip.code}</span><span>余量: {s.equip.remaining}</span></div>
                <div className="mt-2 flex items-center gap-2"><span className="text-[11px] text-[#6B7280]">数量:</span><input type="number" min={1} max={s.equip.remaining} value={s.qty} onChange={e => updateQty(s.equip.id, parseInt(e.target.value) || 1)} className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-center text-sm outline-none focus:border-[#1A56DB]" /><span className="text-[11px] text-[#6B7280]">单价: &yen;{s.equip.price.toLocaleString()}</span></div>
              </div>
            ))}
          </div>
        </div>
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={() => { onConfirm(selected); setSelected([]); setSearchName('') }} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">确认添加</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   新增配发弹窗
   ═══════════════════════════════════════════ */

function CreateAllocModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (record: AllocRecord) => void
}) {
  const [showEquipSelect, setShowEquipSelect] = useState(false)
  const [selectedEquipments, setSelectedEquipments] = useState<SelectedEquipment[]>([])
  const [fromWarehouse, setFromWarehouse] = useState('')
  const [toUnit, setToUnit] = useState('')
  const [applicant, setApplicant] = useState('')

  if (!open) return null

  const allocNo = `PF${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`
  const items = selectedEquipments.map(s => `${s.equip.name}x${s.qty}`).join(', ')
  const totalQty = selectedEquipments.reduce((sum, s) => sum + s.qty, 0)
  const warehouseOptions = ['请选择', '省厅主仓库A区', '省厅主仓库B区', '省厅主仓库C区']

  const handleConfirmEquip = (selected: SelectedEquipment[]) => {
    setSelectedEquipments(selected)
    setShowEquipSelect(false)
  }

  const handleSave = () => {
    if (!fromWarehouse) { alert('请选择调出仓库'); return }
    if (!toUnit.trim()) { alert('请输入配发单位'); return }
    if (!applicant.trim()) { alert('请输入配发人员'); return }
    if (selectedEquipments.length === 0) { alert('请添加装备'); return }

    onSave({
      id: allocNo,
      fromWarehouse,
      toUnit,
      items,
      qty: totalQty,
      applicant,
      time: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status: 'draft',
      equipments: selectedEquipments,
    })
    setSelectedEquipments([])
    setFromWarehouse('')
    setToUnit('')
    setApplicant('')
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">新增配发申请</h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
          </div>
          <div className="flex-1 overflow-auto px-6 py-4 space-y-4">
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]"><div className="h-4 w-1 rounded-full bg-[#059669]" />基本信息</div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="mb-1 block text-xs text-[#6B7280]">配发单号</label><input type="text" value={allocNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" /></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">调出仓库 <span className="text-[#EF4444]">*</span></label><select value={fromWarehouse} onChange={e => setFromWarehouse(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">{warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}</select></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">配发单位 <span className="text-[#EF4444]">*</span></label><input type="text" value={toUnit} onChange={e => setToUnit(e.target.value)} placeholder="请输入配发单位" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" /></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">配发人员 <span className="text-[#EF4444]">*</span></label><input type="text" value={applicant} onChange={e => setApplicant(e.target.value)} placeholder="请输入配发人员姓名" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" /></div>
              </div>
            </div>
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#D97706]"><div className="h-4 w-1 rounded-full bg-[#D97706]" />装备明细 <span className="text-[#EF4444]">*</span><span className="text-xs font-normal text-[#6B7280]">({selectedEquipments.length} 种)</span></div>
                <button onClick={() => setShowEquipSelect(true)} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"><Plus size={14} /> 添加装备</button>
              </div>
              {selectedEquipments.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-10 text-[#9CA3AF]"><Package size={36} className="mb-2 opacity-40" /><p className="text-sm">暂无装备，请点击上方按钮添加</p></div>
              ) : (
                <div className="space-y-2">
                  {selectedEquipments.map(s => (
                    <div key={s.equip.id} className="flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-[#FAFBFC] px-3 py-2">
                      <div className="flex-1"><div className="text-sm font-medium text-[#1F2937]">{s.equip.name}</div><div className="text-[11px] text-[#6B7280]">{s.equip.code} · {s.equip.model} · 数量: {s.qty}{s.equip.unit}</div></div>
                      <button onClick={() => setSelectedEquipments(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">提交申请</button>
          </div>
        </div>
      </div>
      <EquipmentSelectModal open={showEquipSelect} onClose={() => setShowEquipSelect(false)} onConfirm={handleConfirmEquip} />
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function AllocationPage() {
  const [activeTab, setActiveTab] = useState('apply')
  const [data, setData] = useState<AllocRecord[]>(initialData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleSave = (record: AllocRecord) => { setData(prev => [record, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该配发单？')) setData(prev => prev.filter(d => d.id !== id)) }
  const handleWithdraw = (id: string) => { if (confirm('确定撤回该申请？')) setData(prev => prev.map(d => d.id === id ? { ...d, status: 'draft' as const } : d)) }
  const handleApprove = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'approved' as const } : d)) }
  const handleReject = (id: string) => { setData(prev => prev.map(d => d.id === id ? { ...d, status: 'rejected' as const } : d)) }
  const handleNext = (id: string) => {
    const nextMap: Record<string, string> = { approved: 'picking', picking: 'ready', ready: 'outbound', outbound: 'delivered', delivered: 'confirmed' }
    setData(prev => prev.map(d => d.id === id ? { ...d, status: (nextMap[d.status] || d.status) as any } : d))
  }

  const filteredData = data.filter(row => {
    if (activeTab === 'apply') return ['draft', 'pending-approve', 'approved'].includes(row.status)
    if (activeTab === 'approve') return ['pending-approve', 'approved', 'rejected'].includes(row.status)
    if (activeTab === 'outbound') return ['approved', 'picking', 'ready', 'outbound'].includes(row.status)
    if (activeTab === 'confirm') return ['outbound', 'delivered', 'confirmed'].includes(row.status)
    return true
  })

  const tabs = [
    { key: 'apply', label: '装备申请', count: data.filter(d => ['draft', 'pending-approve', 'approved'].includes(d.status)).length },
    { key: 'approve', label: '配发审批', count: data.filter(d => ['pending-approve', 'approved', 'rejected'].includes(d.status)).length },
    { key: 'outbound', label: '配发出库', count: data.filter(d => ['approved', 'picking', 'ready', 'outbound'].includes(d.status)).length },
    { key: 'confirm', label: '接收确认', count: data.filter(d => ['outbound', 'delivered', 'confirmed'].includes(d.status)).length },
  ]

  const filterFields = [
    { key: 'allocNo', label: '配发单号', type: 'input' as const, placeholder: '请输入配发单号' },
    { key: 'toUnit', label: '配发单位', type: 'input' as const, placeholder: '请输入配发单位' },
    { key: 'applicant', label: '配发人员', type: 'input' as const, placeholder: '请输入配发人员' },
    { key: 'dateStart', label: '申请时间（起）', type: 'date' as const },
    { key: 'dateEnd', label: '申请时间（止）', type: 'date' as const },
  ]

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">所队装备配发</h1>
        <button onClick={() => setShowCreateModal(true)} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"><Plus size={14} /> 新建配发申请</button>
      </div>

      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map(tab => (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)} className={cn('relative flex h-10 items-center gap-1.5 text-sm transition', activeTab === tab.key ? 'font-medium text-[#1A56DB]' : 'text-[#6B7280] hover:text-[#374151]')}>
              {tab.label}
              {tab.count > 0 && <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">{tab.count}</span>}
              {activeTab === tab.key && <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4"><FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} /></div>

      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配发单号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">调出仓库</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配发单位</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">装备清单</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-[#6B7280]">数量</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">配发人员</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>}
              {filteredData.map(row => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.fromWarehouse}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.toUnit}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[220px] truncate" title={row.items}>{row.items}</td>
                  <td className="px-4 py-3 text-right text-[13px] font-medium text-[#1A56DB]">{row.qty}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.applicant}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.time}</td>
                  <td className="px-4 py-3"><AllocStatus status={row.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1 flex-wrap">
                      <button onClick={() => alert(`配发单详情：${row.id}\n调出仓库：${row.fromWarehouse}\n配发单位：${row.toUnit}\n装备清单：${row.items}\n数量：${row.qty}\n配发人员：${row.applicant}\n申请时间：${row.time}\n状态：${row.status}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="查看"><Eye size={12} /> 查看</button>
                      {/* 草稿：编辑、删除 */}
                      {row.status === 'draft' && <><button className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]" title="编辑"><Edit size={12} /> 编辑</button><button onClick={() => handleDelete(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#EF4444] transition hover:bg-[#FEE2E2]" title="删除"><Trash2 size={12} /> 删除</button></>}
                      {/* 待审批：撤回 */}
                      {row.status === 'pending-approve' && <button onClick={() => handleWithdraw(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6]" title="撤回"><RotateCcw size={12} /> 撤回</button>}
                      {/* 配发审批页签：通过/驳回 */}
                      {activeTab === 'approve' && row.status === 'pending-approve' && <><button onClick={() => handleApprove(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white transition hover:bg-[#059669]"><CheckCircle size={12} /> 通过</button><button onClick={() => handleReject(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#EF4444] transition hover:bg-[#FEE2E2]"><X size={12} /> 驳回</button></>}
                      {/* 配发出库页签：下一步操作 */}
                      {activeTab === 'outbound' && row.status !== 'outbound' && <button onClick={() => handleNext(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white transition hover:bg-[#153E7E]"><ArrowRight size={12} /> {row.status === 'approved' ? '开始拣货' : row.status === 'picking' ? '准备出库' : '确认出库'}</button>}
                      {/* 接收确认页签：确认接收 */}
                      {activeTab === 'confirm' && row.status === 'delivered' && <button onClick={() => handleNext(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white transition hover:bg-[#059669]"><CheckCircle size={12} /> 确认接收</button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      <CreateAllocModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSave} />
    </div>
  )
}
