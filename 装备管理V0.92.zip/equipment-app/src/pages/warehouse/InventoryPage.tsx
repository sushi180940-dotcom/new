import { useState } from 'react'
import {
  Plus, Eye, Edit, Trash2, X, Play, RotateCcw, ClipboardCheck,
  Package, ScanLine, FileSpreadsheet, Upload, CheckCircle2, XCircle, MinusCircle,
  ArrowDownToLine, ArrowUpFromLine, FileText, AlertTriangle,
  LayoutGrid, Columns2, Table2, ListOrdered, User, Warehouse, Check, ChevronDown, Clock,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface InventoryEquipment {
  id: string
  code: string
  name: string
  category1: string
  category2: string
  category3: string
  model: string
  unit: string
  stockQty: number
  rfidCodes: string[]
  warehouse: string
}

/* ─── 盘点差异处理状态 ─── */
type VarianceStatus = 'normal' | 'gain_pending' | 'gain_approved' | 'gain_inbounded' | 'loss_pending' | 'loss_approved' | 'loss_outbounded'

interface InventoryItem {
  equip: InventoryEquipment
  checkQty: number | null
  remark: string
  scannedRfidCodes?: string[]
  varianceStatus?: VarianceStatus
  varianceDoc?: string
  varianceDocName?: string
  auditComment?: string
}

interface InventoryTask {
  id: string
  name: string
  warehouse: string
  cycle: '期初盘点' | '存货盘点' | '期末盘点'
  startDate: string
  endDate: string
  assignee: string
  status: 'planned' | 'ongoing' | 'completed'
  items: InventoryItem[]
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备（含完整分类和RFID）
   ═══════════════════════════════════════════ */

const allEquipments: InventoryEquipment[] = [
  { id: '1', code: 'ZB-2024-001', name: '手持终端 XT-2000', category1: '通信设备', category2: '移动终端', category3: '手持式', model: 'XT-2000/黑色/128G', unit: '台', stockQty: 50, rfidCodes: ['RFID001001', 'RFID001002', 'RFID001003'], warehouse: '省厅主仓库' },
  { id: '2', code: 'ZB-2024-002', name: '执法记录仪 DSJ-A7', category1: '记录设备', category2: '视频记录', category3: '便携式', model: 'DSJ-A7/64G/高清', unit: '台', stockQty: 30, rfidCodes: ['RFID002001', 'RFID002002'], warehouse: '省厅主仓库' },
  { id: '3', code: 'ZB-2024-003', name: '防弹背心 FDY-3R', category1: '防护装备', category2: '身体防护', category3: '背心式', model: 'FDY-3R/三级/L', unit: '件', stockQty: 35, rfidCodes: ['RFID003001', 'RFID003002', 'RFID003003'], warehouse: 'A区仓库' },
  { id: '4', code: 'ZB-2024-004', name: '对讲机 PD780G', category1: '通信设备', category2: '无线对讲', category3: '手持式', model: 'PD780G/U段', unit: '台', stockQty: 52, rfidCodes: ['RFID004001', 'RFID004002'], warehouse: 'B区仓库' },
  { id: '5', code: 'ZB-2024-005', name: '强光手电 QG-500', category1: '照明设备', category2: '手持照明', category3: '充电式', model: 'QG-500/充电款', unit: '支', stockQty: 86, rfidCodes: ['RFID005001', 'RFID005002', 'RFID005003', 'RFID005004'], warehouse: 'C区仓库' },
  { id: '6', code: 'ZB-2024-006', name: '应急照明灯 YD-100', category1: '照明设备', category2: '应急照明', category3: '固定式', model: 'YD-100/LED', unit: '台', stockQty: 60, rfidCodes: ['RFID006001', 'RFID006002'], warehouse: 'A区仓库' },
  { id: '7', code: 'ZB-2024-007', name: '战术头盔 MICH-2000', category1: '防护装备', category2: '头部防护', category3: '头盔式', model: 'MICH-2000/L号', unit: '顶', stockQty: 40, rfidCodes: ['RFID007001', 'RFID007002'], warehouse: 'B区仓库' },
  { id: '8', code: 'ZB-2024-008', name: '防弹盾牌 FDP-3S', category1: '防护装备', category2: '身体防护', category3: '手持式', model: 'FDP-3S/手持型', unit: '面', stockQty: 15, rfidCodes: ['RFID008001', 'RFID008002'], warehouse: '省厅主仓库' },
  { id: '9', code: 'ZB-2024-009', name: '警用伸缩棍 ZG-600', category1: '警械装备', category2: '约束制服', category3: '伸缩式', model: 'ZG-600/钛合金', unit: '根', stockQty: 100, rfidCodes: ['RFID009001'], warehouse: 'C区仓库' },
  { id: '10', code: 'ZB-2024-010', name: '防刺手套 FC-800', category1: '防护装备', category2: '手部防护', category3: '手套式', model: 'FC-800/凯夫拉', unit: '副', stockQty: 45, rfidCodes: ['RFID010001', 'RFID010002'], warehouse: 'A区仓库' },
]

/* ═══════════════════════════════════════════
   Mock 数据：盘点任务
   ═══════════════════════════════════════════ */

const initialTasks: InventoryTask[] = [
  { id: 'PD20260603001', name: '2026年第二季度全面盘点', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-06-15', endDate: '2026-06-20', assignee: '张管理员', status: 'planned', items: [] },
  { id: 'PD20260603002', name: 'A区防护装备专项盘点', warehouse: 'A区仓库', cycle: '期初盘点', startDate: '2026-06-10', endDate: '2026-06-12', assignee: '李管理员', status: 'planned', items: [] },
  { id: 'PD20260603003', name: '执法装备月度抽盘', warehouse: 'C区仓库', cycle: '期末盘点', startDate: '2026-06-05', endDate: '2026-06-05', assignee: '王警官', status: 'planned', items: [] },
  { id: 'PD20260603004', name: '2026年5月月度盘点', warehouse: '省厅主仓库', cycle: '存货盘点', startDate: '2026-05-25', endDate: '2026-05-28', assignee: '赵管理员', status: 'ongoing', items: allEquipments.filter(e => e.warehouse === '省厅主仓库').map(e => ({ equip: e, checkQty: null, remark: '' })) },
  { id: 'PD20260603005', name: 'B区通信设备盘点', warehouse: 'B区仓库', cycle: '期初盘点', startDate: '2026-05-28', endDate: '2026-05-30', assignee: '刘警官', status: 'ongoing', items: allEquipments.filter(e => e.warehouse === 'B区仓库').map(e => ({ equip: e, checkQty: null, remark: '' })) },
  { id: 'PD20260603006', name: '2026年第一季度全面盘点', warehouse: '省厅主仓库', cycle: '期末盘点', startDate: '2026-03-15', endDate: '2026-03-22', assignee: '张管理员', status: 'completed', items: allEquipments.slice(0, 4).map(e => ({ equip: e, checkQty: e.stockQty, remark: '' })) },
]

const warehouseOptions = ['请选择', '省厅主仓库', 'A区仓库', 'B区仓库', 'C区仓库']

/* ═══════════════════════════════════════════
   分类数据（一级 → 二级 → 三级）
   ═══════════════════════════════════════════ */

const categoryTree: Record<string, Record<string, string[]>> = {
  '通信设备': {
    '移动终端': ['手持式', '车载式'],
    '无线对讲': ['手持式', '基地式'],
  },
  '记录设备': {
    '视频记录': ['便携式', '固定式'],
    '音频记录': ['便携式', '固定式'],
  },
  '防护装备': {
    '身体防护': ['背心式', '手持式'],
    '头部防护': ['头盔式', '帽式'],
    '手部防护': ['手套式', '护腕式'],
  },
  '照明设备': {
    '手持照明': ['充电式', '电池式'],
    '应急照明': ['固定式', '便携式'],
  },
  '警械装备': {
    '约束制服': ['伸缩式', '固定式'],
  },
}

/* ═══════════════════════════════════════════
   辅助函数
   ═══════════════════════════════════════════ */

function generateTaskNo() {
  return `PD${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`
}

function getEquipmentsByWarehouse(warehouse: string): InventoryEquipment[] {
  if (!warehouse || warehouse === '请选择') return []
  return allEquipments.filter(e => e.warehouse === warehouse)
}

function getCategory1Options() {
  return Object.keys(categoryTree)
}

function getCategory2Options(c1: string) {
  if (!c1) return []
  return Object.keys(categoryTree[c1] || {})
}

function getCategory3Options(c1: string, c2: string) {
  if (!c1 || !c2) return []
  return (categoryTree[c1]?.[c2]) || []
}

function filterEquipmentsByCategory(c1: string, c2: string, c3: string): InventoryEquipment[] {
  return allEquipments.filter(e => {
    if (c1 && e.category1 !== c1) return false
    if (c2 && e.category2 !== c2) return false
    if (c3 && e.category3 !== c3) return false
    return true
  })
}

/* ═══════════════════════════════════════════
   盘点统计
   ═══════════════════════════════════════════ */

function calcInventoryStats(items: InventoryItem[]) {
  const total = items.length
  const noDiff = items.filter(i => i.checkQty !== null && i.checkQty === i.equip.stockQty).length
  const loss = items.filter(i => i.checkQty !== null && i.checkQty < i.equip.stockQty).length
  const gain = items.filter(i => i.checkQty !== null && i.checkQty > i.equip.stockQty).length
  return { total, noDiff, loss, gain }
}

/* ═══════════════════════════════════════════
   状态标签
   ═══════════════════════════════════════════ */

function InventoryStatus({ status }: { status: string }) {
  switch (status) {
    case 'planned': return <Badge variant="default">计划中</Badge>
    case 'ongoing': return <Badge variant="info" dot>进行中</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

function CycleBadge({ cycle }: { cycle: string }) {
  switch (cycle) {
    case '期初盘点': return <Badge variant="info">期初盘点</Badge>
    case '存货盘点': return <Badge variant="primary">存货盘点</Badge>
    case '期末盘点': return <Badge variant="warning">期末盘点</Badge>
    default: return <Badge variant="default">{cycle}</Badge>
  }
}

/* ═══════════════════════════════════════════
   差异计算
   ═══════════════════════════════════════════ */

function calcVarianceSummary(items: InventoryItem[]) {
  let hasVariance = false
  let totalDiff = 0
  items.forEach(i => {
    if (i.checkQty !== null) {
      const diff = i.checkQty - i.equip.stockQty
      if (diff !== 0) hasVariance = true
      totalDiff += Math.abs(diff)
    }
  })
  if (!hasVariance) return '无差异'
  return `差异${totalDiff}件`
}

function calcItemDiff(item: InventoryItem): number | null {
  if (item.checkQty === null) return null
  return item.checkQty - item.equip.stockQty
}

/* ─── 差异状态判断 ─── */
function getVarianceType(item: InventoryItem): 'none' | 'gain' | 'loss' {
  const diff = calcItemDiff(item)
  if (diff === null || diff === 0) return 'none'
  return diff > 0 ? 'gain' : 'loss'
}

function getVarianceStatusLabel(status?: VarianceStatus): string {
  const map: Record<string, string> = {
    normal: '无差异',
    gain_pending: '盘盈-待入库',
    gain_approved: '盘盈-已批准',
    gain_inbounded: '盘盈-已入库',
    loss_pending: '盘亏-待审核',
    loss_approved: '盘亏-已批准',
    loss_outbounded: '盘亏-已出库',
  }
  return map[status || ''] || '待处理'
}

/* ═══════════════════════════════════════════
   导出CSV辅助函数
   ═══════════════════════════════════════════ */

function exportToCSV(items: InventoryItem[], taskName: string) {
  const headers = ['装备编码', '装备名称', '一级分类', '二级分类', '三级分类', '规格型号', '单位', 'RFID编号', '库存数量', '盘点数量', '盈亏', '备注']
  const rows = items.map(i => [
    i.equip.code,
    i.equip.name,
    i.equip.category1,
    i.equip.category2,
    i.equip.category3,
    i.equip.model,
    i.equip.unit,
    i.equip.rfidCodes.join(';'),
    String(i.equip.stockQty),
    i.checkQty !== null ? String(i.checkQty) : '',
    i.checkQty !== null ? String(i.checkQty - i.equip.stockQty) : '',
    i.remark,
  ])
  const csv = [headers.join(','), ...rows.map(r => r.map(c => `"${c}"`).join(','))].join('\n')
  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = `${taskName}_盘点明细.csv`
  link.click()
  URL.revokeObjectURL(link.href)
}

/* ═══════════════════════════════════════════
   装备选择弹窗（支持仓库选择和分类选择两种模式）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: InventoryEquipment[]) => void
}) {
  const [mode, setMode] = useState<'warehouse' | 'category'>('warehouse')
  const [selWarehouse, setSelWarehouse] = useState('')
  const [c1, setC1] = useState('')
  const [c2, setC2] = useState('')
  const [c3, setC3] = useState('')
  const [selected, setSelected] = useState<InventoryEquipment[]>([])

  if (!open) return null

  const displayedEquips = mode === 'warehouse'
    ? getEquipmentsByWarehouse(selWarehouse)
    : filterEquipmentsByCategory(c1, c2, c3)

  const isChecked = (id: string) => selected.some(s => s.id === id)

  const toggleEquip = (equip: InventoryEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.id === equip.id)
      if (exists) return prev.filter(s => s.id !== equip.id)
      return [...prev, equip]
    })
  }

  const handleConfirm = () => {
    onConfirm(selected)
    setSelected([])
    setSelWarehouse('')
    setC1(''); setC2(''); setC3('')
    setMode('warehouse')
  }

  const handleClose = () => {
    setSelected([])
    setSelWarehouse('')
    setC1(''); setC2(''); setC3('')
    setMode('warehouse')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">选择装备</h2>
          <button onClick={handleClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 模式切换 + 筛选 */}
        <div className="shrink-0 border-b border-[#E5E7EB] px-6 py-3">
          <div className="mb-3 flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="selectMode"
                checked={mode === 'warehouse'}
                onChange={() => { setMode('warehouse'); setC1(''); setC2(''); setC3('') }}
                className="h-4 w-4"
              />
              按仓库选择
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input
                type="radio"
                name="selectMode"
                checked={mode === 'category'}
                onChange={() => { setMode('category'); setSelWarehouse('') }}
                className="h-4 w-4"
              />
              按分类选择
            </label>
          </div>

          {mode === 'warehouse' ? (
            <select
              value={selWarehouse}
              onChange={e => setSelWarehouse(e.target.value)}
              className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
            >
              {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
            </select>
          ) : (
            <div className="flex items-center gap-3">
              <select value={c1} onChange={e => { setC1(e.target.value); setC2(''); setC3('') }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">一级分类</option>
                {getCategory1Options().map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={c2} onChange={e => { setC2(e.target.value); setC3('') }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">二级分类</option>
                {getCategory2Options(c1).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select value={c3} onChange={e => setC3(e.target.value)} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">三级分类</option>
                {getCategory3Options(c1, c2).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          )}
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">一级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">二级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">三级分类</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">库存数量</th>
                </tr>
              </thead>
              <tbody>
                {displayedEquips.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-3 py-8 text-center text-sm text-[#9CA3AF]">
                      {mode === 'warehouse' ? '请选择仓库' : '请选择分类'}
                    </td>
                  </tr>
                )}
                {displayedEquips.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input type="checkbox" checked={isChecked(equip.id)} onChange={() => toggleEquip(equip)} className="h-4 w-4 rounded border-[#D1D5DB]" />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{equip.code}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category1}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category2}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category3}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-right text-[#1A56DB]">{equip.stockQty}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[260px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">已选择装备 ({selected.length})</div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-1 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.name}</span>
                  <button onClick={() => setSelected(prev => prev.filter(p => p.id !== s.id))} className="text-[#EF4444] hover:text-[#DC2626]">
                    <X size={14} />
                  </button>
                </div>
                <div className="text-[11px] text-[#6B7280]">编码：{s.code}</div>
                <div className="text-[11px] text-[#6B7280]">库存：{s.stockQty} {s.unit}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={handleClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">关闭</button>
          <button onClick={handleConfirm} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">确定</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   创建盘点任务弹窗
   ═══════════════════════════════════════════ */

function CreateInventoryModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (task: InventoryTask) => void
}) {
  const [taskName, setTaskName] = useState('')
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [cycle, setCycle] = useState<'期初盘点' | '存货盘点' | '期末盘点'>('存货盘点')
  const [assignee, setAssignee] = useState('')
  const [warehouse, setWarehouse] = useState('')
  const [items, setItems] = useState<InventoryItem[]>([])
  const [showEquipSelect, setShowEquipSelect] = useState(false)

  if (!open) return null

  const taskNo = generateTaskNo()

  // 选择仓库后自动加载该仓库装备
  const handleWarehouseChange = (value: string) => {
    setWarehouse(value)
    if (value && value !== '请选择') {
      const equips = getEquipmentsByWarehouse(value)
      setItems(equips.map(e => ({ equip: e, checkQty: null, remark: '' })))
    } else {
      setItems([])
    }
  }

  const handleConfirmEquip = (selected: InventoryEquipment[]) => {
    setItems(prev => {
      const merged = [...prev]
      selected.forEach(equip => {
        if (!merged.some(m => m.equip.id === equip.id)) {
          merged.push({ equip, checkQty: null, remark: '' })
        }
      })
      return merged
    })
    setShowEquipSelect(false)
  }

  const handleExport = () => {
    if (items.length === 0) { alert('暂无装备可导出'); return }
    exportToCSV(items, taskName || taskNo)
  }

  const handleLoadToRFID = () => {
    if (items.length === 0) { alert('暂无装备可加载'); return }
    alert(`已将 ${items.length} 条装备数据加载到RFID盘点设备`)
  }

  const handleSave = () => {
    if (!taskName.trim()) { alert('请输入盘点单号'); return }
    if (!startDate) { alert('请选择盘点时间'); return }
    if (!assignee.trim()) { alert('请输入经办人'); return }
    if (!warehouse) { alert('请选择仓库'); return }

    onSave({
      id: taskNo,
      name: taskName,
      warehouse,
      cycle,
      startDate,
      endDate: endDate || startDate,
      assignee,
      status: 'planned',
      items,
    })
    // Reset
    setTaskName('')
    setStartDate('')
    setEndDate('')
    setCycle('存货盘点')
    setAssignee('')
    setWarehouse('')
    setItems([])
    onClose()
  }

  const handleClose = () => {
    setTaskName('')
    setStartDate('')
    setEndDate('')
    setCycle('存货盘点')
    setAssignee('')
    setWarehouse('')
    setItems([])
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[1000px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">创建盘点任务</h2>
            <button onClick={handleClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 grid grid-cols-3 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点单号 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={taskNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点时间 <span className="text-[#EF4444]">*</span></label>
                <input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">盘点类型 <span className="text-[#EF4444]">*</span></label>
                <select value={cycle} onChange={e => setCycle(e.target.value as any)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                  <option value="期初盘点">期初盘点</option>
                  <option value="存货盘点">存货盘点</option>
                  <option value="期末盘点">期末盘点</option>
                </select>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">经办人 <span className="text-[#EF4444]">*</span></label>
                <input type="text" value={assignee} onChange={e => setAssignee(e.target.value)} placeholder="请输入经办人姓名" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">仓库 <span className="text-[#EF4444]">*</span></label>
                <select
                  value={warehouse}
                  onChange={e => handleWarehouseChange(e.target.value)}
                  className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
                >
                  {warehouseOptions.map(o => <option key={o} value={o === '请选择' ? '' : o}>{o}</option>)}
                </select>
              </div>
            </div>

            {/* 装备盘点明细 */}
            <div>
              <div className="mb-3 flex items-center justify-between">
                <div className="text-sm font-semibold text-[#374151]">
                  盘点明细 <span className="text-xs font-normal text-[#6B7280]">（共 {items.length} 件）</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleExport}
                    className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"
                  >
                    <FileSpreadsheet size={13} /> 导出Excel
                  </button>
                  <button
                    onClick={handleLoadToRFID}
                    className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]"
                  >
                    <ScanLine size={13} /> 加载到RFID设备
                  </button>
                  <button
                    onClick={() => setShowEquipSelect(true)}
                    className="inline-flex h-8 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-sm text-white hover:bg-[#153E7E]"
                  >
                    <Plus size={13} /> 新增装备
                  </button>
                </div>
              </div>

              {items.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-8 text-[#9CA3AF]">
                  <p className="text-sm">暂无装备明细</p>
                  <p className="mt-1 text-xs">选择仓库后自动加载装备数据，或点击「新增装备」手动添加</p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-lg border border-[#E5E7EB]">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                        <th className="w-8 px-2 py-2"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">序号</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备类别</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                        <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">库存数量</th>
                        <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">RFID编号</th>
                        <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
                      </tr>
                    </thead>
                    <tbody>
                      {items.map((s, idx) => (
                        <tr key={s.equip.id} className="border-b border-[#F3F4F6]">
                          <td className="px-2 py-2 text-center"><input type="checkbox" className="h-4 w-4 rounded border-[#D1D5DB]" /></td>
                          <td className="px-3 py-2 text-[#6B7280]">{idx + 1}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#374151]">{s.equip.code}</td>
                          <td className="px-3 py-2 font-medium text-[#1F2937]">{s.equip.name}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.category1}/{s.equip.category2}</td>
                          <td className="px-3 py-2 text-[12px] text-[#6B7280]">{s.equip.model}</td>
                          <td className="px-3 py-2 text-[#374151]">{s.equip.unit}</td>
                          <td className="px-3 py-2 text-right text-[#1A56DB]">{s.equip.stockQty}</td>
                          <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{s.equip.rfidCodes.join(', ')}</td>
                          <td className="px-3 py-2 text-center">
                            <button onClick={() => setItems(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={handleClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-6 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSave} className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]">创建盘点任务</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   盘盈/盘亏处理弹窗
   ═══════════════════════════════════════════ */

function VarianceActionModal({
  item, onClose, onConfirm,
}: {
  item: InventoryItem
  onClose: () => void
  onConfirm: (itemId: string, status: VarianceStatus, docName?: string) => void
}) {
  const [docName, setDocName] = useState('')
  const [uploaded, setUploaded] = useState(false)

  const diff = (item.checkQty || 0) - item.equip.stockQty
  const isGain = diff > 0

  const handleUpload = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.pdf,.doc,.docx,.jpg,.png'
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) { setDocName(file.name); setUploaded(true) }
    }
    input.click()
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[480px] max-w-[90vw] rounded-xl bg-white shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-5 py-3">
          <h3 className="text-base font-semibold text-[#1F2937]">{isGain ? '盘盈入库' : '盘亏出库'}</h3>
          <button onClick={onClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
        </div>
        <div className="p-5 space-y-4">
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="text-sm font-medium text-[#374151]">{item.equip.name}</div>
            <div className="text-xs text-[#6B7280]">编码：{item.equip.code} | 型号：{item.equip.model}</div>
            <div className="mt-1 flex items-center gap-3 text-xs">
              <span>库存：<b>{item.equip.stockQty}</b> {item.equip.unit}</span>
              <span>盘点：<b>{item.checkQty}</b> {item.equip.unit}</span>
              <span className={isGain ? 'text-[#1A56DB]' : 'text-[#DC2626]'}>{isGain ? `盘盈 +${diff}` : `盘亏 ${diff}`}</span>
            </div>
          </div>
          {isGain ? (
            <div className="rounded-md bg-[#E8F0FE]/50 p-3 text-sm text-[#374151]">
              <div className="flex items-center gap-2 text-[#1A56DB]"><CheckCircle2 size={16} /><span className="font-medium">盘盈入库</span></div>
              <p className="mt-1 text-xs text-[#6B7280]">盘盈 {diff} {item.equip.unit}，确认后将自动执行入库操作。</p>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="rounded-md bg-[#FEE2E2]/50 p-3 text-sm text-[#374151]">
                <div className="flex items-center gap-2 text-[#DC2626]"><AlertTriangle size={16} /><span className="font-medium">盘亏出库 - 需上传说明材料</span></div>
                <p className="mt-1 text-xs text-[#6B7280]">盘亏 {Math.abs(diff)} {item.equip.unit}，需上传说明材料，待审核通过后方可出库。</p>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-medium text-[#374151]">说明材料 <span className="text-[#EF4444]">*</span></label>
                <button onClick={handleUpload} className={cn('flex h-9 w-full items-center gap-2 rounded-lg border px-3 text-sm transition', uploaded ? 'border-[#10B981] bg-[#D1FAE5] text-[#059669]' : 'border-dashed border-[#D1D5DB] text-[#6B7280] hover:border-[#1A56DB]')}>
                  <Upload size={14} />{uploaded ? docName : '点击上传说明材料（PDF/Word/图片）'}
                </button>
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center justify-end gap-2 border-t border-[#E5E7EB] px-5 py-3">
          <button onClick={onClose} className="h-8 rounded border border-[#D1D5DB] bg-white px-4 text-xs text-[#374151]">取消</button>
          {isGain ? (
            <button onClick={() => onConfirm(item.equip.id, 'gain_inbounded')} className="h-8 rounded bg-[#1A56DB] px-4 text-xs text-white">确认入库</button>
          ) : (
            <button onClick={() => { if (!uploaded) { alert('请上传说明材料'); return } onConfirm(item.equip.id, 'loss_pending', docName) }} className="h-8 rounded bg-[#DC2626] px-4 text-xs text-white">提交审核</button>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   录入盘点结果弹窗（左右分栏布局）
   ═══════════════════════════════════════════ */

function EnterResultModal({
  open,
  onClose,
  task,
  onSave,
}: {
  open: boolean
  onClose: () => void
  task: InventoryTask | null
  onSave: (task: InventoryTask) => void
}) {
  const [items, setItems] = useState<InventoryItem[]>([])
  const [selectedEquipId, setSelectedEquipId] = useState<string | null>(null)
  const [handleType, setHandleType] = useState<'盘盈入库' | '盘亏出库'>('盘亏出库')
  const [handleRemark, setHandleRemark] = useState('')
  const [lossDocName, setLossDocName] = useState('')
  const [lossDocUploaded, setLossDocUploaded] = useState(false)

  if (!open || !task) return null

  const currentItems = items.length > 0 ? items : task.items
  const stats = calcInventoryStats(currentItems)

  const hasUnprocessedVariance = currentItems.some(item => {
    const vType = getVarianceType(item)
    if (vType === 'none') return false
    if (vType === 'gain') return item.varianceStatus !== 'gain_inbounded'
    return item.varianceStatus !== 'loss_outbounded'
  })

  const selectedItem = currentItems.find(i => i.equip.id === selectedEquipId) || currentItems[0]

  const handleUpdateQty = (id: string, qty: number) => {
    setItems(prev => {
      const base = prev.length > 0 ? prev : task.items
      return base.map(e => e.equip.id === id ? { ...e, checkQty: qty } : e)
    })
  }

  const handleRFIDScanImport = () => {
    setItems(prev => {
      const base = prev.length > 0 ? prev : [...task.items]
      return base.map(item => {
        const random = Math.random()
        let checkQty: number
        let scannedRfids: string[] = []
        if (random > 0.85) {
          checkQty = item.equip.stockQty + Math.floor(Math.random() * 3) + 1
          scannedRfids = [...item.equip.rfidCodes, `RFID-NEW-${Math.floor(Math.random() * 999)}`]
        } else if (random > 0.55) {
          const lossCount = Math.floor(Math.random() * Math.min(3, item.equip.stockQty)) + 1
          checkQty = Math.max(0, item.equip.stockQty - lossCount)
          scannedRfids = item.equip.rfidCodes.slice(0, Math.max(0, item.equip.rfidCodes.length - lossCount))
        } else {
          checkQty = item.equip.stockQty
          scannedRfids = [...item.equip.rfidCodes]
        }
        return { ...item, checkQty, scannedRfidCodes: scannedRfids }
      })
    })
    alert('RFID扫描导入完成！已比对数量和RFID编码，差异项请处理')
  }

  const handleImportExcel = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.csv,.xlsx,.xls'
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) {
        alert(`已选择文件：${file.name}，将解析并填充盘点数据`)
        setItems(prev => {
          const base = prev.length > 0 ? prev : [...task.items]
          return base.map(item => ({ ...item, checkQty: item.equip.stockQty + Math.floor(Math.random() * 5) - 2 }))
        })
      }
    }
    input.click()
  }

  const handleSave = (asDraft: boolean) => {
    if (!asDraft && hasUnprocessedVariance) {
      alert('存在未处理的盘点差异，请先处理盘盈/盘亏项')
      return
    }
    onSave({ ...task, items: currentItems, status: asDraft ? 'ongoing' : 'completed' })
    setItems([])
    onClose()
  }

  const VarianceLabel = ({ item }: { item: InventoryItem }) => {
    const vType = getVarianceType(item)
    if (vType === 'gain') return <span className="rounded-full bg-[#E8F0FE] px-2 py-0.5 text-[10px] text-[#1A56DB]">盘盈</span>
    if (vType === 'loss') return <span className="rounded-full bg-[#FEE2E2] px-2 py-0.5 text-[10px] text-[#DC2626]">盘亏</span>
    return <span className="rounded-full bg-[#D1FAE5] px-2 py-0.5 text-[10px] text-[#059669]">无差异</span>
  }

  // 统计RFID匹配情况
  const calcRfidMatchStats = (item: InventoryItem) => {
    const stock = item.equip.rfidCodes
    const scanned = item.scannedRfidCodes || []
    const matched = scanned.filter(r => stock.includes(r))
    const extra = scanned.filter(r => !stock.includes(r))
    const missing = stock.filter(r => !scanned.includes(r))
    return { matched, extra, missing, matchCount: matched.length, extraCount: extra.length, missingCount: missing.length }
  }

  // 盘亏出库：上传说明材料
  const handleUploadLossDoc = () => {
    const input = document.createElement('input')
    input.type = 'file'
    input.accept = '.pdf,.doc,.docx,.jpg,.png'
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0]
      if (file) { setLossDocName(file.name); setLossDocUploaded(true) }
    }
    input.click()
  }

  // 确认差异处理
  const handleConfirmVariance = () => {
    const vType = getVarianceType(selectedItem)
    if (vType === 'gain') {
      // 盘盈入库直接生效
      setItems(prev => prev.map(e => e.equip.id === selectedItem.equip.id ? { ...e, varianceStatus: 'gain_inbounded' as VarianceStatus } : e))
      alert('盘盈入库处理已确认')
    } else if (vType === 'loss') {
      // 盘亏出库：必须上传说明材料
      if (!lossDocUploaded) { alert('请上传说明材料'); return }
      // 提交审核，状态为待审核
      setItems(prev => prev.map(e => e.equip.id === selectedItem.equip.id ? { ...e, varianceStatus: 'loss_pending' as VarianceStatus, varianceDocName: lossDocName } : e))
      setLossDocName('')
      setLossDocUploaded(false)
      setHandleRemark('')
      alert('盘亏出库申请已提交审核')
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[94vh] w-[1100px] max-w-[96vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#1A56DB]">
              <ClipboardCheck size={18} className="text-white" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-[#1F2937]">盘点录入</h2>
              <div className="text-xs text-[#6B7280]">{task.name} · {task.id}</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-1 text-xs text-[#6B7280]"><User size={13} /> {task.assignee}</div>
            <div className="flex items-center gap-1 text-xs text-[#6B7280]"><Warehouse size={13} /> {task.warehouse}</div>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
          </div>
        </div>

        {/* 统计卡片 */}
        <div className="shrink-0 grid grid-cols-4 gap-4 px-6 py-4">
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] px-4 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#EFF6FF]"><Package size={16} className="text-[#1A56DB]" /></div>
            <div><div className="text-xl font-bold text-[#1F2937]">{stats.total}</div><div className="text-xs text-[#6B7280]">装备总数</div></div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] px-4 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#F0FDF4]"><Check size={16} className="text-[#059669]" /></div>
            <div><div className="text-xl font-bold text-[#1F2937]">{stats.noDiff}</div><div className="text-xs text-[#6B7280]">无差异</div></div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] px-4 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#FEF2F2]"><MinusCircle size={16} className="text-[#DC2626]" /></div>
            <div><div className="text-xl font-bold text-[#1F2937]">{stats.loss}</div><div className="text-xs text-[#6B7280]">盘亏</div></div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-[#E5E7EB] px-4 py-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-[#EFF6FF]"><Plus size={16} className="text-[#1A56DB]" /></div>
            <div><div className="text-xl font-bold text-[#1F2937]">{stats.gain}</div><div className="text-xs text-[#6B7280]">盘盈</div></div>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="shrink-0 flex items-center gap-2 px-6 pb-3">
          <button onClick={handleRFIDScanImport} className="inline-flex h-8 items-center gap-1.5 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]"><ScanLine size={14} /> RFID扫描导入</button>
          <button onClick={handleImportExcel} className="inline-flex h-8 items-center gap-1.5 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]"><Upload size={14} /> 导入Excel</button>
        </div>

        {/* 左右分栏主体 */}
        <div className="flex flex-1 overflow-hidden border-t border-[#E5E7EB]">
          {/* 左侧：装备列表 */}
          <div className="w-[320px] shrink-0 overflow-auto border-r border-[#E5E7EB] bg-[#FAFBFC]">
            {/* 差异装备汇总 */}
            {(stats.loss > 0 || stats.gain > 0) && (
              <div className="border-b border-[#E5E7EB] bg-white px-4 py-3">
                <div className="mb-2 text-xs font-semibold text-[#374151]">差异装备汇总</div>
                <div className="space-y-1.5">
                  {stats.loss > 0 && (
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 text-[#DC2626]"><MinusCircle size={12} />盘亏装备</span>
                      <span className="font-bold text-[#DC2626]">{stats.loss} 种</span>
                    </div>
                  )}
                  {stats.gain > 0 && (
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 text-[#1A56DB]"><Plus size={12} />盘盈装备</span>
                      <span className="font-bold text-[#1A56DB]">{stats.gain} 种</span>
                    </div>
                  )}
                  <div className="border-t border-[#F3F4F6] pt-1.5">
                    {currentItems.filter(i => getVarianceType(i) !== 'none').map(item => (
                      <div key={item.equip.id} className="flex items-center justify-between py-0.5 text-[11px]">
                        <span className="truncate text-[#6B7280]" style={{ maxWidth: '180px' }}>{item.equip.name}</span>
                        <span className={cn('shrink-0 font-mono font-medium', (calcItemDiff(item) || 0) < 0 ? 'text-[#DC2626]' : 'text-[#1A56DB]')}>
                          {(calcItemDiff(item) || 0) > 0 ? '+' : ''}{calcItemDiff(item)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-[#F9FAFB] px-4 py-2 text-xs">
              <span className="font-medium text-[#374151]">装备列表</span>
              <span className="text-[#6B7280]">盈亏状态</span>
            </div>
            {currentItems.map(item => {
              const diff = calcItemDiff(item)
              const isActive = selectedItem?.equip.id === item.equip.id
              const vType = getVarianceType(item)
              return (
                <button key={item.equip.id} onClick={() => setSelectedEquipId(item.equip.id)}
                  className={cn('flex w-full items-center justify-between border-b border-[#F3F4F6] px-4 py-3 text-left transition hover:bg-[#F3F4F6]', isActive && 'bg-[#E8F0FE]')}>
                  <div>
                    <div className="text-sm font-medium text-[#1F2937]">{item.equip.name}</div>
                    <div className="mt-0.5 font-mono text-[11px] text-[#6B7280]">{item.equip.code}</div>
                  </div>
                  <div className="text-right">
                    <div className="mb-1"><VarianceLabel item={item} /></div>
                    {diff !== null && (
                      <div className={cn('text-xs', vType === 'loss' ? 'text-[#DC2626]' : vType === 'gain' ? 'text-[#1A56DB]' : 'text-[#059669]')}>
                        {item.equip.stockQty} → {item.checkQty}
                      </div>
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {/* 右侧：详情面板 */}
          <div className="flex-1 overflow-auto p-5">
            {selectedItem && (
              <div className="space-y-5">
                {/* 装备基本信息 */}
                <div className="flex items-start gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[#EFF6FF] text-lg font-bold text-[#1A56DB]">
                    {currentItems.indexOf(selectedItem) + 1}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-semibold text-[#1F2937]">{selectedItem.equip.name}</span>
                      <VarianceLabel item={selectedItem} />
                    </div>
                    <div className="mt-0.5 text-xs text-[#6B7280]">{selectedItem.equip.code} · {selectedItem.equip.category1}/{selectedItem.equip.category2}</div>
                  </div>
                </div>

                {/* 规格型号 + 计量单位 */}
                <div className="grid grid-cols-2 gap-4 rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
                  <div>
                    <div className="text-xs text-[#6B7280]">规格型号</div>
                    <div className="mt-0.5 text-sm text-[#374151]">{selectedItem.equip.model}</div>
                  </div>
                  <div>
                    <div className="text-xs text-[#6B7280]">计量单位</div>
                    <div className="mt-0.5 text-sm text-[#374151]">{selectedItem.equip.unit}</div>
                  </div>
                </div>

                {/* RFID编码列表（支持大量RFID滚动） */}
                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-semibold text-[#374151]">RFID编码列表</span>
                    <span className="text-xs text-[#6B7280]">
                      {(() => {
                        const s = calcRfidMatchStats(selectedItem)
                        return <>共 {selectedItem.equip.rfidCodes.length} 个 · <span className="text-[#059669]">匹配 {s.matchCount}</span> · <span className="text-[#DC2626]">缺失 {s.missingCount}</span></>
                      })()}
                    </span>
                  </div>
                  <div className="max-h-[240px] overflow-auto rounded-lg border border-[#E5E7EB]">
                    <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[#E5E7EB] bg-[#F9FAFB] px-3 py-1.5 text-[11px] text-[#6B7280]">
                      <span>RFID编码</span>
                      <span>匹配状态</span>
                    </div>
                    {selectedItem.equip.rfidCodes.map(rfid => {
                      const scanned = selectedItem.scannedRfidCodes || []
                      const isMatched = scanned.includes(rfid)
                      return (
                        <div key={rfid} className="flex items-center justify-between border-b border-[#F3F4F6] px-3 py-1.5 last:border-0">
                          <span className="font-mono text-xs text-[#374151]">{rfid}</span>
                          {isMatched
                            ? <span className="inline-flex items-center gap-0.5 rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[10px] text-[#059669]"><Check size={10} /> 匹配</span>
                            : <span className="inline-flex items-center rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[10px] text-[#DC2626]">缺失</span>
                          }
                        </div>
                      )
                    })}
                  </div>
                </div>

                {/* 数量对比 */}
                <div>
                  <div className="mb-2 text-sm font-semibold text-[#374151]">数量对比</div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#6B7280]">库存数量</span>
                      <span className="font-medium text-[#374151]">{selectedItem.equip.stockQty}</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-[#E5E7EB]"><div className="h-2 rounded-full bg-[#9CA3AF]" style={{ width: '100%' }} /></div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#6B7280]">盘点数量</span>
                      <span className="font-medium text-[#374151]">{selectedItem.checkQty ?? '--'}</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-[#E5E7EB]">
                      <div className={cn('h-2 rounded-full', getVarianceType(selectedItem) === 'loss' ? 'bg-[#DC2626]' : getVarianceType(selectedItem) === 'gain' ? 'bg-[#1A56DB]' : 'bg-[#059669]')}
                        style={{ width: `${selectedItem.checkQty !== null ? (selectedItem.checkQty / Math.max(selectedItem.equip.stockQty, 1) * 100) : 0}%` }} />
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-[#6B7280]">盈亏数量</span>
                      <span className={cn('font-bold', (calcItemDiff(selectedItem) || 0) < 0 ? 'text-[#DC2626]' : (calcItemDiff(selectedItem) || 0) > 0 ? 'text-[#1A56DB]' : 'text-[#059669]')}>
                        {calcItemDiff(selectedItem) ?? '--'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 盘点数量输入（始终可编辑） */}
                <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
                  <label className="mb-1 block text-xs text-[#6B7280]">盘点数量 <span className="text-[#EF4444]">*</span></label>
                  <div className="flex items-center gap-2">
                    <input type="number" min={0}
                      value={selectedItem.checkQty ?? ''}
                      onChange={e => handleUpdateQty(selectedItem.equip.id, Number(e.target.value))}
                      placeholder="输入盘点数量..."
                      className="h-9 flex-1 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                    <span className="text-xs text-[#6B7280]">{selectedItem.equip.unit}</span>
                  </div>
                </div>

                {/* 差异处理（仅对有差异且已录入数量的装备显示） */}
                {getVarianceType(selectedItem) !== 'none' && selectedItem.checkQty !== null && (
                  <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
                    <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
                      {getVarianceType(selectedItem) === 'gain' ? (
                        <><Plus size={14} className="text-[#1A56DB]" />盘盈入库处理</>
                      ) : (
                        <><ArrowDownToLine size={14} className="text-[#DC2626]" />盘亏出库处理</>
                      )}
                    </div>

                    {/* 盘亏出库：必须上传说明材料 */}
                    {getVarianceType(selectedItem) === 'loss' && (
                      <>
                        <div className="mb-3 rounded-md border border-[#FEF3C7] bg-[#FFFBEB] p-2.5 text-xs text-[#D97706]">
                          <AlertTriangle size={12} className="mr-1 inline" />
                          盘亏出库需提交说明材料，经审核通过后方可完成出库
                        </div>
                        <div className="mb-3">
                          <label className="mb-1 block text-xs text-[#6B7280]">说明材料 <span className="text-[#EF4444]">*</span></label>
                          <button onClick={handleUploadLossDoc}
                            className={cn('flex h-9 w-full items-center gap-2 rounded-lg border px-3 text-sm transition', lossDocUploaded ? 'border-[#10B981] bg-[#D1FAE5] text-[#059669]' : 'border-dashed border-[#D1D5DB] text-[#6B7280] hover:border-[#1A56DB]')}>
                            <Upload size={14} />{lossDocUploaded ? lossDocName : '点击上传说明材料（PDF/Word/图片）'}
                          </button>
                        </div>
                      </>
                    )}

                    <div className="mb-3">
                      <label className="mb-1 block text-xs text-[#6B7280]">备注说明</label>
                      <textarea value={handleRemark} onChange={e => setHandleRemark(e.target.value)}
                        rows={2} placeholder="填写差异原因..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                    </div>

                    {/* 显示当前差异处理状态 */}
                    {selectedItem.varianceStatus === 'gain_inbounded' && (
                      <div className="mb-2 rounded-md bg-[#D1FAE5] px-3 py-2 text-xs text-[#059669]"><Check size={12} className="inline" /> 已入库</div>
                    )}
                    {selectedItem.varianceStatus === 'loss_pending' && (
                      <div className="mb-2 rounded-md bg-[#FEF3C7] px-3 py-2 text-xs text-[#D97706]"><Clock size={12} className="inline" /> 待审核（已提交说明材料）</div>
                    )}
                    {selectedItem.varianceStatus === 'loss_outbounded' && (
                      <div className="mb-2 rounded-md bg-[#D1FAE5] px-3 py-2 text-xs text-[#059669]"><Check size={12} className="inline" /> 已出库（审核通过）</div>
                    )}

                    {/* 手动操作按钮 */}
                    {(!selectedItem.varianceStatus || selectedItem.varianceStatus === 'normal') && (
                      <div className="flex gap-2">
                        {getVarianceType(selectedItem) === 'gain' ? (
                          <button onClick={() => {
                            setItems(prev => prev.map(e => e.equip.id === selectedItem.equip.id ? { ...e, varianceStatus: 'gain_inbounded' as VarianceStatus } : e))
                            alert('盘盈入库处理已确认')
                          }} className="h-9 flex-1 rounded-md bg-[#1A56DB] text-sm text-white hover:bg-[#153E7E]">
                            <Plus size={14} className="mr-1 inline" />确认盘盈入库
                          </button>
                        ) : (
                          <button onClick={() => {
                            if (!lossDocUploaded) { alert('请上传说明材料'); return }
                            setItems(prev => prev.map(e => e.equip.id === selectedItem.equip.id ? { ...e, varianceStatus: 'loss_pending' as VarianceStatus, varianceDocName: lossDocName } : e))
                            setLossDocName(''); setLossDocUploaded(false); setHandleRemark('')
                            alert('盘亏出库申请已提交审核')
                          }} className="h-9 flex-1 rounded-md bg-[#DC2626] text-sm text-white hover:bg-[#B91C1C]">
                            <ArrowDownToLine size={14} className="mr-1 inline" />提交盘亏出库申请
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-between border-t border-[#E5E7EB] px-6 py-4">
          {hasUnprocessedVariance ? (
            <span className="flex items-center gap-1 text-xs text-[#D97706]"><AlertTriangle size={14} /> 存在未处理的盘点差异项，请先处理后再提交</span>
          ) : <span />}
          <div className="flex items-center gap-3">
            <button onClick={() => { setItems([]); onClose() }} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151]">取消</button>
            <button onClick={() => handleSave(true)} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151]">暂存</button>
            <button onClick={() => handleSave(false)} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white">提交盘点结果</button>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function InventoryPage() {
  const [activeTab, setActiveTab] = useState('planned')
  const [tasks, setTasks] = useState<InventoryTask[]>(initialTasks)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showResultModal, setShowResultModal] = useState(false)
  const [currentTask, setCurrentTask] = useState<InventoryTask | null>(null)

  const handleFilterChange = (key: string, value: string) => { setFilterValues(p => ({ ...p, [key]: value })) }
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleSaveTask = (task: InventoryTask) => { setTasks(prev => [task, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该盘点任务？')) setTasks(prev => prev.filter(d => d.id !== id)) }
  const handleStart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleRestart = (id: string) => { setTasks(prev => prev.map(t => t.id === id ? { ...t, status: 'ongoing' as const } : t)) }
  const handleSaveResult = (task: InventoryTask) => { setTasks(prev => prev.map(t => t.id === task.id ? task : t)) }

  const filteredData = tasks.filter((row) => {
    if (activeTab === 'planned') return row.status === 'planned'
    if (activeTab === 'ongoing') return row.status === 'ongoing'
    if (activeTab === 'completed') return row.status === 'completed'
    return true
  })

  const tabs = [
    { key: 'planned', label: '计划中', count: tasks.filter(t => t.status === 'planned').length },
    { key: 'ongoing', label: '进行中', count: tasks.filter(t => t.status === 'ongoing').length },
    { key: 'completed', label: '已完成', count: tasks.filter(t => t.status === 'completed').length },
  ]

  const filterFields = [
    { key: 'planNo', label: '盘点计划编号', type: 'input' as const, placeholder: '请输入盘点计划编号' },
    { key: 'name', label: '计划名称', type: 'input' as const, placeholder: '请输入计划名称' },
    { key: 'cycle', label: '盘点周期', type: 'select' as const, options: [
      { label: '期初盘点', value: '期初盘点' },
      { label: '存货盘点', value: '存货盘点' },
      { label: '期末盘点', value: '期末盘点' },
    ]},
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '计划中', value: 'planned' },
      { label: '进行中', value: 'ongoing' },
      { label: '已完成', value: 'completed' },
    ]},
    { key: 'assignee', label: '负责人', type: 'input' as const, placeholder: '请输入负责人' },
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">装备盘点</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
        >
          <Plus size={14} /> 新建盘点计划
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Inventory table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划编号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">计划名称</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点仓库</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点周期</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">负责人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">盘点差异</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-48 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={9} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#1F2937]">{row.name}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.warehouse}</td>
                  <td className="px-4 py-3"><CycleBadge cycle={row.cycle} /></td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.startDate} ~ {row.endDate}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.assignee}</td>
                  <td className="px-4 py-3 text-[13px]">
                    <span className={cn(row.status === 'completed' ? 'text-[#059669]' : 'text-[#9CA3AF]')}>
                      {row.status === 'completed' ? calcVarianceSummary(row.items) : '待盘点'}
                    </span>
                  </td>
                  <td className="px-4 py-3"><InventoryStatus status={row.status} /></td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-center gap-1">
                      {row.status === 'planned' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n周期：${row.cycle}\n时间：${row.startDate} ~ ${row.endDate}\n负责人：${row.assignee}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><Edit size={12} /> 修改</button>
                          <button onClick={() => handleDelete(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#EF4444] transition hover:bg-[#FEE2E2]"><Trash2 size={12} /> 删除</button>
                          <button onClick={() => handleStart(row.id)} className="flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2 text-xs text-white transition hover:bg-[#059669]"><Play size={12} /> 开始盘点</button>
                        </>
                      )}
                      {row.status === 'ongoing' && (
                        <>
                          <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n已盘点：${row.items.length}种装备`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                          <button onClick={() => { setCurrentTask(row); setShowResultModal(true) }} className="flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-2 text-xs text-white transition hover:bg-[#153E7E]"><ClipboardCheck size={12} /> 录入结果</button>
                          <button onClick={() => handleRestart(row.id)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#D97706] transition hover:bg-[#FEF3C7]"><RotateCcw size={12} /> 重新盘点</button>
                        </>
                      )}
                      {row.status === 'completed' && (
                        <button onClick={() => alert(`查看：${row.name}\n仓库：${row.warehouse}\n差异：${calcVarianceSummary(row.items)}`)} className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 创建盘点任务弹窗 */}
      <CreateInventoryModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveTask} />

      {/* 录入结果弹窗 */}
      <EnterResultModal open={showResultModal} onClose={() => setShowResultModal(false)} task={currentTask} onSave={handleSaveResult} />
    </div>
  )
}
