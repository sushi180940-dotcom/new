import { useState } from 'react'
import { Plus, Eye, Trash2, X, Package, FileText } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ─── Tabs ─── */
const tabs = [
  { key: 'pending-approve', label: '待审批', count: 4 },
  { key: 'approving', label: '审批中', count: 2 },
  { key: 'pending-dispose', label: '待处置', count: 3 },
  { key: 'completed', label: '已完成', count: 0 },
]

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
}

interface SelectedEquipment {
  equip: StockEquipment
  qty: number
}

interface ScrapRecord {
  id: string
  reason: string
  handler: string
  materialList: string
  applicant: string
  dept: string
  time: string
  status: 'pending-approve' | 'approving' | 'pending-dispose' | 'completed'
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '手持终端 XT-2000', category: '通信装备', model: 'XT-2000/黑色', productionDate: '2024-01-15', expiryDate: '2029-01-14', remaining: 50, unit: '台', price: 3200, code: '0101P00100', supplier: '华为技术有限公司' },
  { id: '2', name: '执法记录仪 DSJ-A7', category: '执法设备', model: 'DSJ-A7/64G', productionDate: '2024-02-20', expiryDate: '2029-02-19', remaining: 30, unit: '台', price: 1800, code: '0101P00200', supplier: '海康威视数字技术股份有限公司' },
  { id: '3', name: '对讲机 PD780G', category: '通信装备', model: 'PD780G/U段', productionDate: '2024-01-20', expiryDate: '2029-01-19', remaining: 100, unit: '台', price: 1200, code: '0101P00500', supplier: '烽火通信科技股份有限公司' },
  { id: '4', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级', productionDate: '2023-11-10', expiryDate: '2033-11-09', remaining: 20, unit: '件', price: 2800, code: '0101P00300', supplier: '华为技术有限公司' },
  { id: '5', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', productionDate: '2023-12-05', expiryDate: '2033-12-04', remaining: 40, unit: '顶', price: 1500, code: '0101P00400', supplier: '中兴通讯股份有限公司' },
  { id: '6', name: '应急照明灯 YD-100', category: '照明设备', model: 'YD-100/LED', productionDate: '2024-01-25', expiryDate: '2029-01-24', remaining: 60, unit: '台', price: 680, code: '0101P00600', supplier: '海康威视数字技术股份有限公司' },
  { id: '7', name: '防弹盾牌 FDP-3S', category: '防护装备', model: 'FDP-3S/三级', productionDate: '2024-03-01', expiryDate: '2034-02-29', remaining: 15, unit: '面', price: 2200, code: '0101P00700', supplier: '华为技术有限公司' },
  { id: '8', name: '催泪喷射器 CL-200', category: '警械装备', model: 'CL-200/200ml', productionDate: '2024-01-10', expiryDate: '2029-01-09', remaining: 100, unit: '支', price: 150, code: '0101P00800', supplier: '大华技术股份有限公司' },
]

/* ═══════════════════════════════════════════
   Mock 数据：报废记录
   ═══════════════════════════════════════════ */

const initialScrapData: ScrapRecord[] = [
  { id: 'BF20260603001', reason: '红外功能完全失效，核心部件停产无法维修，已超期服役3年', handler: '赵管理员', materialList: '夜视仪 YSY-NV20 x1', applicant: '赵管理员', dept: '装备管理处', time: '2026-06-03 09:00', status: 'pending-approve' },
  { id: 'BF20260603002', reason: '多次维修仍读数不准，主板老化，维修成本超过新品价格70%', handler: '刘警官', materialList: '测速仪 CS-LS30 x1', applicant: '刘警官', dept: '交警大队', time: '2026-06-02 14:30', status: 'approving' },
  { id: 'BF20260603003', reason: '型号已停产，配件无法采购，通讯协议与现有系统不兼容', handler: '李管理员', materialList: '对讲机 DJ-8800 x1', applicant: '李管理员', dept: '通信科', time: '2026-06-02 10:00', status: 'pending-dispose' },
  { id: 'BF20260603004', reason: '训练中使用磨损严重，防护等级已不符合现行标准', handler: '张警官', materialList: '战术背心 ZS-FDY02 x1', applicant: '张警官', dept: '特警支队', time: '2026-06-01 16:00', status: 'pending-approve' },
  { id: 'BF20260603005', reason: '进水导致主板腐蚀，屏幕和存储均无法修复', handler: '王警官', materialList: '执法记录仪 DSJ-K8 x1', applicant: '王警官', dept: '刑侦支队', time: '2026-06-01 09:30', status: 'approving' },
  { id: 'BF20260603006', reason: '在一次处突行动中被利器割破，防护层受损无法修复', handler: '吴警官', materialList: '防暴服 FB-FB01 x1', applicant: '吴警官', dept: '防暴大队', time: '2026-05-31 11:00', status: 'pending-dispose' },
  { id: 'BF20260603007', reason: '库存超过有效期，材质老化变脆，防护性能下降', handler: '钱管理员', materialList: '腿套 TT-TT01 x1', applicant: '钱管理员', dept: '装备仓库', time: '2026-05-30 15:00', status: 'pending-approve' },
  { id: 'BF20260603008', reason: '被车辆碾压损毁，外壳和内部元件全部损坏', handler: '孙警官', materialList: '测速仪 CS-LS30 x1', applicant: '孙警官', dept: '交警大队', time: '2026-05-29 10:00', status: 'completed' },
]

/* ─── Scrap status badge ─── */
function ScrapStatus({ status }: { status: string }) {
  switch (status) {
    case 'pending-approve': return <Badge variant="warning" dot>待审批</Badge>
    case 'approving': return <Badge variant="info" dot>审批中</Badge>
    case 'pending-dispose': return <Badge variant="primary" dot>待处置</Badge>
    case 'completed': return <Badge variant="success" dot>已完成</Badge>
    case 'rejected': return <Badge variant="danger" dot>已驳回</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   库存装备选择弹窗（与报修管理一致）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({
  open,
  onClose,
  onConfirm,
}: {
  open: boolean
  onClose: () => void
  onConfirm: (selected: SelectedEquipment[]) => void
}) {
  const [selected, setSelected] = useState<SelectedEquipment[]>([])
  const [searchName, setSearchName] = useState('')

  if (!open) return null

  const filteredStock = stockEquipments.filter(e =>
    searchName ? e.name.includes(searchName) || e.code.includes(searchName) : true
  )

  const isChecked = (id: string) => selected.some(s => s.equip.id === id)

  const toggleEquip = (equip: StockEquipment) => {
    setSelected(prev => {
      const exists = prev.find(s => s.equip.id === equip.id)
      if (exists) return prev.filter(s => s.equip.id !== equip.id)
      return [...prev, { equip, qty: 1 }]
    })
  }

  const updateQty = (id: string, qty: number) => {
    setSelected(prev => prev.map(s => s.equip.id === id ? { ...s, qty: Math.max(1, Math.min(qty, s.equip.remaining)) } : s))
  }

  const removeSelected = (id: string) => {
    setSelected(prev => prev.filter(s => s.equip.id !== id))
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-[640px] w-[960px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">库存装备信息</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
            <X size={18} />
          </button>
        </div>

        {/* 筛选 */}
        <div className="shrink-0 flex items-center gap-3 border-b border-[#E5E7EB] px-6 py-3">
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部位置</option>
            <option>省厅仓库1层</option>
            <option>省厅仓库2层</option>
            <option>省厅仓库3层</option>
          </select>
          <input
            type="text"
            value={searchName}
            onChange={e => setSearchName(e.target.value)}
            placeholder="物资名称..."
            className="h-8 w-40 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]"
          />
          <select className="h-8 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
            <option>全部类别</option>
            <option>通信装备</option>
            <option>执法设备</option>
            <option>防护装备</option>
            <option>照明设备</option>
            <option>警械装备</option>
          </select>
          <button className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">查询</button>
        </div>

        {/* 内容区域 */}
        <div className="flex flex-1 overflow-hidden">
          {/* 左侧：库存装备列表 */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB]">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="w-10 px-3 py-2"></th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资名称</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">物资类别</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">规格型号</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">生产日期</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">有效期</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">剩余</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">单位</th>
                  <th className="px-3 py-2 text-right text-[11px] font-semibold text-[#6B7280]">单价</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备编码</th>
                  <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">供应商</th>
                </tr>
              </thead>
              <tbody>
                {filteredStock.map((equip) => (
                  <tr key={equip.id} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', isChecked(equip.id) && 'bg-[#EFF6FF]')}>
                    <td className="px-3 py-2 text-center">
                      <input
                        type="checkbox"
                        checked={isChecked(equip.id)}
                        onChange={() => toggleEquip(equip)}
                        className="h-4 w-4 rounded border-[#D1D5DB]"
                      />
                    </td>
                    <td className="px-3 py-2 font-medium text-[#1F2937]">{equip.name}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.category}</td>
                    <td className="px-3 py-2 text-[12px] text-[#6B7280]">{equip.model}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.productionDate}</td>
                    <td className="px-3 py-2 text-[12px] text-[#374151]">{equip.expiryDate}</td>
                    <td className="px-3 py-2 text-right font-medium text-[#059669]">{equip.remaining}</td>
                    <td className="px-3 py-2 text-[#374151]">{equip.unit}</td>
                    <td className="px-3 py-2 text-right text-[#374151]">{equip.price.toLocaleString()}</td>
                    <td className="px-3 py-2 font-mono text-[11px] text-[#6B7280]">{equip.code}</td>
                    <td className="px-3 py-2 text-[11px] text-[#374151]">{equip.supplier}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* 右侧：已选择装备 */}
          <div className="w-[280px] shrink-0 bg-[#F9FAFB] p-4 overflow-auto">
            <div className="mb-3 text-sm font-semibold text-[#374151]">
              已选择装备 ({selected.length})
            </div>
            {selected.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8 text-[#9CA3AF]">
                <Package size={32} className="mb-2 opacity-50" />
                <p className="text-xs">请从左侧选择装备</p>
              </div>
            )}
            {selected.map((s) => (
              <div key={s.equip.id} className="mb-2 rounded-lg border border-[#E5E7EB] bg-white p-3">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-sm font-medium text-[#1F2937]">{s.equip.name}</span>
                  <button onClick={() => removeSelected(s.equip.id)} className="text-xs text-[#EF4444] hover:underline">删除</button>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-[#6B7280]">
                  <span>类别: {s.equip.category}</span>
                  <span>规格: {s.equip.model}</span>
                  <span>编码: {s.equip.code}</span>
                  <span>余量: {s.equip.remaining}</span>
                </div>
                <div className="mt-2 flex items-center gap-2">
                  <span className="text-[11px] text-[#6B7280]">数量:</span>
                  <input
                    type="number"
                    min={1}
                    max={s.equip.remaining}
                    value={s.qty}
                    onChange={(e) => updateQty(s.equip.id, parseInt(e.target.value) || 1)}
                    className="h-7 w-16 rounded-md border border-[#D1D5DB] px-2 text-center text-sm outline-none focus:border-[#1A56DB]"
                  />
                  <span className="text-[11px] text-[#6B7280]">单价: &yen;{s.equip.price.toLocaleString()}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button
            onClick={() => { onConfirm(selected); setSelected([]); setSearchName('') }}
            className="h-9 rounded-md bg-[#1A56DB] px-6 text-sm text-white hover:bg-[#153E7E]"
          >
            确认添加
          </button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   发起报废弹窗
   ═══════════════════════════════════════════ */

function CreateScrapModal({
  open,
  onClose,
  onSave,
}: {
  open: boolean
  onClose: () => void
  onSave: (record: ScrapRecord) => void
}) {
  const [showEquipSelect, setShowEquipSelect] = useState(false)
  const [selectedEquipments, setSelectedEquipments] = useState<SelectedEquipment[]>([])
  const [reason, setReason] = useState('')
  const [handler, setHandler] = useState('')

  if (!open) return null

  const scrapNo = `BF${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const materialList = selectedEquipments.map(s => `${s.equip.name} x${s.qty}`).join(', ')

  const handleConfirmEquip = (selected: SelectedEquipment[]) => {
    setSelectedEquipments(selected)
    setShowEquipSelect(false)
  }

  const handleSave = (saveStatus: 'draft' | 'submitted') => {
    if (!reason.trim()) { alert('请填写报废原因'); return }
    if (!handler.trim()) { alert('请填写经办人'); return }
    if (selectedEquipments.length === 0) { alert('请添加物资'); return }

    onSave({
      id: scrapNo,
      reason,
      handler,
      materialList,
      applicant: handler,
      dept: '装备管理处',
      time: new Date().toISOString().slice(0, 16).replace('T', ' '),
      status: saveStatus === 'submitted' ? 'pending-approve' : 'pending-approve',
    })
    // 重置
    setSelectedEquipments([])
    setReason('')
    setHandler('')
    onClose()
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          {/* Header */}
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">发起报废</h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]">
              <X size={18} />
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-auto px-6 py-4">
            {/* 基本信息 */}
            <div className="mb-5 rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#059669]">
                <div className="h-4 w-1 rounded-full bg-[#059669]" />
                基本信息
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">报废单号 <span className="text-[#9CA3AF]">#</span></label>
                  <input type="text" value={scrapNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">报废原因 <span className="text-[#EF4444]">*</span></label>
                  <input type="text" value={reason} onChange={e => setReason(e.target.value)} placeholder="请输入报废原因" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
                <div>
                  <label className="mb-1 block text-xs text-[#6B7280]">经办人 <span className="text-[#9CA3AF]">#</span></label>
                  <input type="text" value={handler} onChange={e => setHandler(e.target.value)} placeholder="请输入经办人" className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
              </div>
            </div>

            {/* 物资明细 */}
            <div className="rounded-lg border border-[#E5E7EB] p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#D97706]">
                  <div className="h-4 w-1 rounded-full bg-[#D97706]" />
                  物资明细 <span className="text-[#EF4444]">*</span>
                  <span className="text-xs font-normal text-[#6B7280]">({selectedEquipments.length} 种)</span>
                </div>
                <button
                  onClick={() => setShowEquipSelect(true)}
                  className="inline-flex h-8 items-center gap-1 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
                >
                  <Plus size={14} /> 添加物资
                </button>
              </div>

              {selectedEquipments.length === 0 ? (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-10 text-[#9CA3AF]">
                  <Package size={36} className="mb-2 opacity-40" />
                  <p className="text-sm">暂无物资，请点击上方按钮添加</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedEquipments.map((s) => (
                    <div key={s.equip.id} className="flex items-center gap-3 rounded-md border border-[#E5E7EB] bg-[#FAFBFC] px-3 py-2">
                      <div className="flex-1">
                        <div className="text-sm font-medium text-[#1F2937]">{s.equip.name}</div>
                        <div className="text-[11px] text-[#6B7280]">{s.equip.code} &middot; {s.equip.model} &middot; 数量: {s.qty}{s.equip.unit}</div>
                      </div>
                      <button onClick={() => setSelectedEquipments(prev => prev.filter(p => p.equip.id !== s.equip.id))} className="text-xs text-[#EF4444] hover:underline">删除</button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Footer */}
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
            <button onClick={() => handleSave('draft')} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151] hover:bg-[#F3F4F6]">保存草稿</button>
            <button onClick={() => handleSave('submitted')} className="h-9 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">提交</button>
          </div>
        </div>
      </div>

      {/* 装备选择弹窗 */}
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        onConfirm={handleConfirmEquip}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function ScrapPage() {
  const [activeTab, setActiveTab] = useState('pending-approve')
  const [data, setData] = useState<ScrapRecord[]>(initialScrapData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)

  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const handleSaveScrap = (record: ScrapRecord) => { setData(prev => [record, ...prev]) }
  const handleDelete = (id: string) => { if (confirm('确定删除该报废单？')) setData(prev => prev.filter(d => d.id !== id)) }

  const filteredData = data.filter((row) => {
    if (activeTab === 'all') return true
    return row.status === activeTab
  })

  const filterFields = [
    { key: 'scrapNo', label: '报废单号', type: 'input' as const, placeholder: '请输入报废单号' },
    { key: 'equipment', label: '装备名称', type: 'input' as const, placeholder: '请输入装备名称' },
    { key: 'applicant', label: '申请人', type: 'input' as const, placeholder: '请输入申请人' },
    { key: 'dateStart', label: '申请时间（起）', type: 'date' as const },
    { key: 'dateEnd', label: '申请时间（止）', type: 'date' as const },
  ]

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">报废管理</h1>
        <button
          onClick={() => setShowCreateModal(true)}
          className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
        >
          <FileText size={14} /> 新建报废申请
        </button>
      </div>

      {/* Tabs */}
      <div className="border-b border-[#E5E7EB]">
        <div className="flex gap-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'relative flex h-10 items-center gap-1.5 text-sm transition',
                activeTab === tab.key
                  ? 'font-medium text-[#1A56DB]'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
              {tab.count > 0 && (
                <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#9CA3AF] px-1.5 text-[11px] font-bold text-white">
                  {tab.count}
                </span>
              )}
              {activeTab === tab.key && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-full bg-[#1A56DB]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Filter panel */}
      <div className="mt-4">
        <FilterPanel
          fields={filterFields}
          values={filterValues}
          onChange={handleFilterChange}
          onSearch={handleSearch}
          onReset={handleReset}
        />
      </div>

      {/* Scrap table */}
      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">报废单号</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">物资清单</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">报废原因</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">经办人</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请人/部门</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">申请时间</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={8} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-4 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[200px] truncate" title={row.materialList}>{row.materialList}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151] max-w-[220px] truncate" title={row.reason}>{row.reason}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.handler}</td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">
                    <div>{row.applicant}</div>
                    <div className="text-xs text-[#6B7280]">{row.dept}</div>
                  </td>
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{row.time}</td>
                  <td className="px-4 py-3"><ScrapStatus status={row.status} /></td>
                  <td className="px-4 py-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => alert(`报废单详情：${row.id}\n\n物资清单：${row.materialList}\n报废原因：${row.reason}\n经办人：${row.handler}\n申请人：${row.applicant}\n部门：${row.dept}\n申请时间：${row.time}\n状态：${row.status}`)}
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] transition hover:bg-[#E8F0FE]"
                        title="详情"
                      >
                        <Eye size={14} />
                      </button>
                      <button
                        onClick={() => handleDelete(row.id)}
                        className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] transition hover:bg-[#FEE2E2]"
                        title="删除"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151] hover:bg-[#F3F4F6]">下一页</button>
          </div>
        </div>
      </div>

      {/* 发起报废弹窗 */}
      <CreateScrapModal open={showCreateModal} onClose={() => setShowCreateModal(false)} onSave={handleSaveScrap} />
    </div>
  )
}
