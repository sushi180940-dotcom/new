import { useState, useMemo } from 'react'
import {
  Plus, X, Eye, Edit3, Trash2, ChevronLeft, ChevronRight,
  Wrench, Clock, CheckCircle, Package, AlertCircle,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

type MaintenanceType = '定期保养' | '日常巡检' | '故障修复' | '换季保养'
type MaintenanceStatus = '待保养' | '保养中' | '已完成'
type EquipStatus = '良好' | '一般' | '较差'

interface MaintenanceEquip {
  id: string
  name: string
  spec: string
  code: string
  unit: string
  quantity: number
}

interface MaintenanceRecord {
  id: string
  code: string
  type: MaintenanceType
  cycle: number
  cycleUnit: '天' | '月' | '年'
  maintTime: string
  handler: string
  nextTime: string
  equips: MaintenanceEquip[]
  equipStatus: EquipStatus
  problems: string
  result: string
  status: MaintenanceStatus
}

/* ═══════════════════════════════════════════
   Mock 数据
   ═══════════════════════════════════════════ */

const mockData: MaintenanceRecord[] = [
  {
    id: '1', code: 'BY-2024-001', type: '定期保养', cycle: 6, cycleUnit: '月',
    maintTime: '2024-06-15', handler: '张警官', nextTime: '2024-12-15',
    equips: [
      { id: 'e1', name: '防弹背心', spec: 'FDY-3R/三级', code: 'ZB-001-001', unit: '件', quantity: 50 },
      { id: 'e2', name: '警用头盔', spec: 'MICH2000/L号', code: 'ZB-005-001', unit: '顶', quantity: 30 },
    ],
    equipStatus: '良好', problems: '部分魔术贴有轻微磨损', result: '已更换魔术贴，装备状态恢复良好',
    status: '已完成',
  },
  {
    id: '2', code: 'BY-2024-002', type: '日常巡检', cycle: 1, cycleUnit: '月',
    maintTime: '2024-07-01', handler: '李警官', nextTime: '2024-08-01',
    equips: [
      { id: 'e3', name: '执法记录仪', spec: 'DSJ-A7/64G', code: 'ZB-003-001', unit: '台', quantity: 20 },
    ],
    equipStatus: '一般', problems: '3台电池续航下降', result: '已更换电池模块，建议下次重点关注',
    status: '已完成',
  },
  {
    id: '3', code: 'BY-2024-003', type: '定期保养', cycle: 3, cycleUnit: '月',
    maintTime: '', handler: '', nextTime: '',
    equips: [
      { id: 'e4', name: '对讲机', spec: 'DJ-8800', code: 'ZB-004-001', unit: '台', quantity: 15 },
      { id: 'e5', name: '强光手电', spec: 'QG-LED', code: 'ZB-006-001', unit: '支', quantity: 10 },
    ],
    equipStatus: '良好', problems: '', result: '',
    status: '待保养',
  },
  {
    id: '4', code: 'BY-2024-004', type: '故障修复', cycle: 0, cycleUnit: '天',
    maintTime: '2024-07-05', handler: '王警官', nextTime: '',
    equips: [
      { id: 'e6', name: '防弹盾牌', spec: 'FDP-3S', code: 'ZB-007-001', unit: '面', quantity: 2 },
    ],
    equipStatus: '较差', problems: '观察窗出现裂纹，把手松动', result: '已更换观察窗，紧固把手',
    status: '已完成',
  },
  {
    id: '5', code: 'BY-2024-005', type: '换季保养', cycle: 12, cycleUnit: '月',
    maintTime: '', handler: '', nextTime: '',
    equips: [
      { id: 'e7', name: '防刺服', spec: 'FCF-II', code: 'ZB-001-002', unit: '件', quantity: 40 },
      { id: 'e8', name: '防割手套', spec: 'FG-ST5', code: 'ZB-001-005', unit: '双', quantity: 60 },
    ],
    equipStatus: '良好', problems: '', result: '',
    status: '待保养',
  },
  {
    id: '6', code: 'BY-2024-006', type: '定期保养', cycle: 6, cycleUnit: '月',
    maintTime: '2024-07-10', handler: '赵警官', nextTime: '2025-01-10',
    equips: [
      { id: 'e9', name: '手铐', spec: 'SK-STD', code: 'ZB-002-001', unit: '副', quantity: 100 },
    ],
    equipStatus: '一般', problems: '15副锁芯有卡滞现象', result: '已清洗润滑锁芯，功能恢复正常',
    status: '已完成',
  },
]

/* ═══════════════════════════════════════════
   辅助函数：计算下次保养时间
   ═══════════════════════════════════════════ */

function calcNextTime(maintTime: string, cycle: number, cycleUnit: '天' | '月' | '年'): string {
  if (!maintTime || cycle <= 0) return ''
  const d = new Date(maintTime)
  switch (cycleUnit) {
    case '天': d.setDate(d.getDate() + cycle); break
    case '月': d.setMonth(d.getMonth() + cycle); break
    case '年': d.setFullYear(d.getFullYear() + cycle); break
  }
  return d.toISOString().slice(0, 10)
}

/* ═══════════════════════════════════════════
   状态徽章
   ═══════════════════════════════════════════ */

function statusBadge(status: MaintenanceStatus) {
  const map: Record<MaintenanceStatus, { variant: string; label: string }> = {
    '待保养': { variant: 'warning', label: '待保养' },
    '保养中': { variant: 'info', label: '保养中' },
    '已完成': { variant: 'success', label: '已完成' },
  }
  const s = map[status]
  return <Badge variant={s.variant as any}>{s.label}</Badge>
}

function equipStatusBadge(status: EquipStatus) {
  const map: Record<EquipStatus, { variant: string; label: string }> = {
    '良好': { variant: 'success', label: '良好' },
    '一般': { variant: 'warning', label: '一般' },
    '较差': { variant: 'danger', label: '较差' },
  }
  const s = map[status]
  return <Badge variant={s.variant as any}>{s.label}</Badge>
}

/* ═══════════════════════════════════════════
   表单弹窗
   ═══════════════════════════════════════════ */

function MaintenanceForm({
  open, record, onClose, onSave,
}: {
  open: boolean
  record: MaintenanceRecord | null
  onClose: () => void
  onSave: (r: MaintenanceRecord) => void
}) {
  const [code, setCode] = useState('')
  const [type, setType] = useState<MaintenanceType>('定期保养')
  const [cycle, setCycle] = useState('6')
  const [cycleUnit, setCycleUnit] = useState<'天' | '月' | '年'>('月')
  const [maintTime, setMaintTime] = useState('')
  const [handler, setHandler] = useState('')
  const [equips, setEquips] = useState<MaintenanceEquip[]>([])
  const [equipStatus, setEquipStatus] = useState<EquipStatus>('良好')
  const [problems, setProblems] = useState('')
  const [result, setResult] = useState('')
  const [status, setStatus] = useState<MaintenanceStatus>('待保养')
  const [errors, setErrors] = useState<Record<string, boolean>>({})

  // 弹窗打开/编辑时重置表单
  useState(() => {
    if (record) {
      setCode(record.code)
      setType(record.type)
      setCycle(String(record.cycle))
      setCycleUnit(record.cycleUnit)
      setMaintTime(record.maintTime)
      setHandler(record.handler)
      setEquips([...record.equips])
      setEquipStatus(record.equipStatus)
      setProblems(record.problems)
      setResult(record.result)
      setStatus(record.status)
    } else {
      setCode(`BY-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`)
      setType('定期保养')
      setCycle('6')
      setCycleUnit('月')
      setMaintTime('')
      setHandler('')
      setEquips([])
      setEquipStatus('良好')
      setProblems('')
      setResult('')
      setStatus('待保养')
    }
    setErrors({})
  })

  // 自动计算下次保养时间
  const nextTime = useMemo(() => calcNextTime(maintTime, parseInt(cycle) || 0, cycleUnit), [maintTime, cycle, cycleUnit])

  const addEquip = () => {
    setEquips(prev => [...prev, { id: `eq-${Date.now()}`, name: '', spec: '', code: '', unit: '件', quantity: 1 }])
  }
  const updateEquip = (idx: number, key: keyof MaintenanceEquip, val: string | number) => {
    setEquips(prev => prev.map((e, i) => i === idx ? { ...e, [key]: val } : e))
  }
  const removeEquip = (idx: number) => {
    setEquips(prev => prev.filter((_, i) => i !== idx))
  }

  const validate = () => {
    const newErrors: Record<string, boolean> = {}
    if (!handler.trim()) newErrors.handler = true
    if (equips.length === 0 || equips.some(e => !e.name.trim())) newErrors.equips = true
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = () => {
    if (!validate()) { alert('请填写必填项'); return }
    const newRecord: MaintenanceRecord = {
      id: record?.id || Date.now().toString(),
      code,
      type,
      cycle: parseInt(cycle) || 0,
      cycleUnit,
      maintTime,
      handler: handler.trim(),
      nextTime: status === '已完成' ? nextTime : '',
      equips: equips.map(e => ({ ...e })),
      equipStatus,
      problems: problems.trim(),
      result: result.trim(),
      status,
    }
    onSave(newRecord)
    onClose()
  }

  const fieldClass = (key: string) => cn(
    'w-full rounded-md border px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB]',
    errors[key] ? 'border-[#EF4444] bg-[#FFF5F5]' : 'border-[#D1D5DB]'
  )

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex max-h-[90vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">{record ? '编辑保养记录' : '新增保养登记'}</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]">
            <X size={18} />
          </button>
        </div>

        <div className="flex-1 overflow-auto px-6 py-5">
          <div className="space-y-5">
            {/* ─── 基本信息 ─── */}
            <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
              <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-[#374151]">
                <Wrench size={14} className="text-[#1A56DB]" />基本信息
              </h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">保养编号</label>
                  <input type="text" value={code} readOnly className="w-full rounded-md border border-[#E5E7EB] bg-[#F3F4F6] px-3 py-2 text-sm text-[#6B7280]" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">保养类型 <span className="text-[#EF4444]">*</span></label>
                  <select value={type} onChange={e => setType(e.target.value as MaintenanceType)} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                    <option>定期保养</option>
                    <option>日常巡检</option>
                    <option>故障修复</option>
                    <option>换季保养</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">保养周期</label>
                  <div className="flex gap-2">
                    <input type="number" min={0} value={cycle} onChange={e => setCycle(e.target.value)} className="h-9 flex-1 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
                    <select value={cycleUnit} onChange={e => setCycleUnit(e.target.value as '天' | '月' | '年')} className="h-9 w-20 rounded-md border border-[#D1D5DB] px-2 text-sm outline-none">
                      <option>天</option>
                      <option>月</option>
                      <option>年</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">保养时间</label>
                  <input type="date" value={maintTime} onChange={e => setMaintTime(e.target.value)} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">经办人 <span className="text-[#EF4444]">*</span></label>
                  <input type="text" value={handler} onChange={e => setHandler(e.target.value)} placeholder="请输入经办人" className={fieldClass('handler')} />
                </div>
                <div>
                  <label className="mb-1.5 flex items-center gap-1 text-sm text-[#374151]">
                    <Clock size={13} className="text-[#10B981]" />下次保养时间
                  </label>
                  <input type="text" value={nextTime} readOnly className={cn(
                    'w-full rounded-md border px-3 py-2 text-sm',
                    nextTime ? 'border-[#10B981] bg-[#ECFDF5] text-[#059669]' : 'border-[#E5E7EB] bg-[#F3F4F6] text-[#9CA3AF]'
                  )} placeholder={status === '已完成' ? '保存后自动计算' : '完成后自动生成'} />
                </div>
              </div>
            </div>

            {/* ─── 物资明细 ─── */}
            <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
              <div className="mb-3 flex items-center justify-between">
                <h3 className="flex items-center gap-1.5 text-sm font-semibold text-[#374151]">
                  <Package size={14} className="text-[#D97706]" />物资明细
                </h3>
                <button onClick={addEquip} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white hover:bg-[#153E7E]">
                  <Plus size={13} /> 添加装备
                </button>
              </div>
              {equips.length > 0 ? (
                <div className="space-y-2">
                  {equips.map((eq, idx) => (
                    <div key={eq.id} className="grid grid-cols-12 gap-2 rounded-md border border-[#E5E7EB] bg-white p-2">
                      <div className="col-span-3">
                        <input type="text" value={eq.name} onChange={e => updateEquip(idx, 'name', e.target.value)} placeholder="装备名称" className="w-full rounded border border-[#D1D5DB] px-2 py-1 text-xs outline-none" />
                      </div>
                      <div className="col-span-3">
                        <input type="text" value={eq.spec} onChange={e => updateEquip(idx, 'spec', e.target.value)} placeholder="规格型号" className="w-full rounded border border-[#D1D5DB] px-2 py-1 text-xs outline-none" />
                      </div>
                      <div className="col-span-2">
                        <input type="text" value={eq.code} onChange={e => updateEquip(idx, 'code', e.target.value)} placeholder="装备编码" className="w-full rounded border border-[#D1D5DB] px-2 py-1 text-xs outline-none" />
                      </div>
                      <div className="col-span-2">
                        <input type="number" min={1} value={eq.quantity} onChange={e => updateEquip(idx, 'quantity', parseInt(e.target.value) || 1)} className="w-full rounded border border-[#D1D5DB] px-2 py-1 text-xs outline-none" />
                      </div>
                      <div className="col-span-1 flex items-center justify-center">
                        <button onClick={() => removeEquip(idx)} className="rounded p-1 text-[#EF4444] hover:bg-[#FEE2E2]"><Trash2 size={12} /></button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] py-8 text-[#9CA3AF]">
                  <Package size={32} className="mb-2 opacity-40" />
                  <p className="text-sm">暂无装备，请点击上方按钮添加</p>
                </div>
              )}
            </div>

            {/* ─── 保养结果 ─── */}
            <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
              <h3 className="mb-3 flex items-center gap-1.5 text-sm font-semibold text-[#374151]">
                <CheckCircle size={14} className="text-[#10B981]" />保养结果
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-[#374151]">装备状态</label>
                  <div className="flex items-center gap-3">
                    {(['良好', '一般', '较差'] as EquipStatus[]).map(s => (
                      <button key={s} onClick={() => setEquipStatus(s)} className={cn(
                        'flex h-9 items-center gap-1.5 rounded-md border px-4 text-sm transition',
                        equipStatus === s ? (s === '良好' ? 'border-[#10B981] bg-[#ECFDF5] text-[#10B981]' : s === '一般' ? 'border-[#F59E0B] bg-[#FEF3C7] text-[#F59E0B]' : 'border-[#EF4444] bg-[#FEE2E2] text-[#EF4444]') : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]'
                      )}>
                        {s === '良好' ? <CheckCircle size={14} /> : s === '一般' ? <AlertCircle size={14} /> : <AlertCircle size={14} />}{s}
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">现存问题</label>
                  <textarea value={problems} onChange={e => setProblems(e.target.value)} placeholder="描述检查中发现的问题..." rows={2} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] resize-none" />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm text-[#374151]">处理结果</label>
                  <textarea value={result} onChange={e => setResult(e.target.value)} placeholder="填写处理措施和结果..." rows={2} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] resize-none" />
                </div>
                <div>
                  <label className="mb-2 block text-sm text-[#374151]">保养状态</label>
                  <div className="flex items-center gap-3">
                    {(['待保养', '保养中', '已完成'] as MaintenanceStatus[]).map(s => (
                      <button key={s} onClick={() => setStatus(s)} className={cn(
                        'flex h-9 items-center gap-1.5 rounded-md border px-4 text-sm transition',
                        status === s ? 'border-[#1A56DB] bg-[#EFF6FF] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]'
                      )}>
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151] hover:bg-[#F3F4F6]">取消</button>
          <button onClick={handleSubmit} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white hover:bg-[#153E7E]">保存</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   详情弹窗
   ═══════════════════════════════════════════ */

function MaintenanceDetail({ record, onClose }: { record: MaintenanceRecord | null; onClose: () => void }) {
  if (!record) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[640px] max-w-[95vw] rounded-xl bg-white shadow-2xl max-h-[90vh] flex flex-col">
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">保养记录详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        <div className="flex-1 overflow-auto px-6 py-5 space-y-4">
          {/* 基本信息 */}
          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">保养编号</label><div className="text-sm font-medium text-[#1A56DB]">{record.code}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">保养类型</label><div className="text-sm font-medium text-[#374151]">{record.type}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">保养周期</label><div className="text-sm font-medium text-[#374151]">{record.cycle}{record.cycleUnit}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">保养时间</label><div className="text-sm font-medium text-[#374151]">{record.maintTime || '-'}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">经办人</label><div className="text-sm font-medium text-[#374151]">{record.handler || '-'}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><label className="text-xs text-[#6B7280]">下次保养</label><div className={cn('text-sm font-medium', record.nextTime ? 'text-[#10B981]' : 'text-[#9CA3AF]')}>{record.nextTime || '未完成'}</div></div>
          </div>
          {/* 物资明细 */}
          <div className="rounded-lg border border-[#E5E7EB]">
            <div className="border-b border-[#E5E7EB] px-4 py-2 text-sm font-medium text-[#374151]">物资明细（{record.equips.length}项）</div>
            <table className="w-full text-sm">
              <thead><tr className="border-b border-[#F3F4F6] bg-[#F9FAFB]"><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">装备名称</th><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">规格型号</th><th className="px-3 py-2 text-left text-[11px] text-[#6B7280]">装备编码</th><th className="px-3 py-2 text-right text-[11px] text-[#6B7280]">数量</th></tr></thead>
              <tbody>{record.equips.map(e => <tr key={e.id} className="border-b border-[#F3F4F6]"><td className="px-3 py-2 font-medium text-[#1F2937]">{e.name}</td><td className="px-3 py-2 text-[11px] text-[#6B7280]">{e.spec}</td><td className="px-3 py-2 text-[11px] text-[#6B7280] font-mono">{e.code}</td><td className="px-3 py-2 text-right font-medium text-[#1A56DB]">{e.quantity} {e.unit}</td></tr>)}</tbody>
            </table>
          </div>
          {/* 保养结果 */}
          <div className="rounded-lg border border-[#E5E7EB] p-4">
            <h4 className="mb-2 text-sm font-medium text-[#374151]">保养结果</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2"><span className="text-xs text-[#6B7280]">装备状态:</span>{equipStatusBadge(record.equipStatus)}</div>
              {record.problems && <div><span className="text-xs text-[#6B7280]">现存问题:</span><p className="mt-0.5 text-sm text-[#374151]">{record.problems}</p></div>}
              {record.result && <div><span className="text-xs text-[#6B7280]">处理结果:</span><p className="mt-0.5 text-sm text-[#374151]">{record.result}</p></div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function MaintenancePage() {
  const [records, setRecords] = useState<MaintenanceRecord[]>(mockData)
  const [showForm, setShowForm] = useState(false)
  const [editingRecord, setEditingRecord] = useState<MaintenanceRecord | null>(null)
  const [detailRecord, setDetailRecord] = useState<MaintenanceRecord | null>(null)
  const [searchText, setSearchText] = useState('')
  const [filterStatus, setFilterStatus] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  const pageSize = 10

  let filtered = records
  if (searchText) filtered = filtered.filter(r => r.code.includes(searchText) || r.handler.includes(searchText))
  if (filterStatus) filtered = filtered.filter(r => r.status === filterStatus)

  const totalPages = Math.ceil(filtered.length / pageSize)
  const pageData = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  const handleSave = (r: MaintenanceRecord) => {
    if (editingRecord) {
      setRecords(prev => prev.map(item => item.id === r.id ? r : item))
    } else {
      setRecords(prev => [r, ...prev])
    }
  }
  const handleDelete = (id: string) => {
    if (!confirm('确定删除该保养记录？')) return
    setRecords(prev => prev.filter(r => r.id !== id))
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">保养登记</h1>
        <button onClick={() => { setEditingRecord(null); setShowForm(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">
          <Plus size={14} /> 新增保养
        </button>
      </div>

      <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white p-4 shadow-sm">
        <div className="flex flex-wrap items-center gap-3">
          <input type="text" placeholder="搜索保养编号/经办人" value={searchText} onChange={e => { setSearchText(e.target.value); setCurrentPage(1) }} className="h-9 w-64 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB]" />
          <select value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setCurrentPage(1) }} className="h-9 rounded-md border border-[#D1D5DB] px-3 text-sm outline-none">
            <option value="">全部状态</option>
            <option value="待保养">待保养</option>
            <option value="保养中">保养中</option>
            <option value="已完成">已完成</option>
          </select>
          <span className="text-xs text-[#6B7280]">共 {filtered.length} 条</span>
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">保养编号</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">保养类型</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">保养周期</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">保养时间</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">经办人</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">下次保养</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">装备状态</th>
              <th className="px-3 py-3 text-left text-[11px] font-semibold text-[#6B7280]">状态</th>
              <th className="px-3 py-3 text-center text-[11px] font-semibold text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {pageData.map(r => (
              <tr key={r.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                <td className="px-3 py-3 font-medium text-[#1A56DB] text-[11px]">{r.code}</td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.type}</td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.cycle}{r.cycleUnit}</td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.maintTime || '-'}</td>
                <td className="px-3 py-3 text-[11px] text-[#374151]">{r.handler || '-'}</td>
                <td className="px-3 py-3">
                  {r.nextTime ? <span className="text-[11px] font-medium text-[#10B981]">{r.nextTime}</span> : <span className="text-[11px] text-[#9CA3AF]">-</span>}
                </td>
                <td className="px-3 py-3">{equipStatusBadge(r.equipStatus)}</td>
                <td className="px-3 py-3">{statusBadge(r.status)}</td>
                <td className="px-3 py-3">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => setDetailRecord(r)} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#1A56DB]" title="详情"><Eye size={14} /></button>
                    <button onClick={() => { setEditingRecord(r); setShowForm(true) }} className="flex h-7 w-7 items-center justify-center rounded text-[#1A56DB] hover:bg-[#E8F0FE]" title="编辑"><Edit3 size={14} /></button>
                    <button onClick={() => handleDelete(r.id)} className="flex h-7 w-7 items-center justify-center rounded text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {pageData.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无数据</div>}
      </div>

      {totalPages > 1 && (
        <div className="mt-4 flex items-center justify-between">
          <div className="text-xs text-[#6B7280]">第 {currentPage} / {totalPages} 页，共 {filtered.length} 条</div>
          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentPage(Math.max(1, currentPage - 1))} disabled={currentPage <= 1} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronLeft size={14} /></button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(p => (
              <button key={p} onClick={() => setCurrentPage(p)} className={cn('flex h-8 min-w-8 items-center justify-center rounded border text-xs transition', currentPage === p ? 'border-[#1A56DB] bg-[#1A56DB] text-white' : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]')}>{p}</button>
            ))}
            <button onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))} disabled={currentPage >= totalPages} className="flex h-8 w-8 items-center justify-center rounded border border-[#E5E7EB] text-[#6B7280] hover:bg-[#F3F4F6] disabled:opacity-30"><ChevronRight size={14} /></button>
          </div>
        </div>
      )}

      <MaintenanceForm open={showForm} record={editingRecord} onClose={() => { setShowForm(false); setEditingRecord(null) }} onSave={handleSave} />
      <MaintenanceDetail record={detailRecord} onClose={() => setDetailRecord(null)} />
    </div>
  )
}
