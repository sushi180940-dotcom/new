import { useState, useCallback, useEffect } from 'react'
import {
  FileText, Eye, Trash2, X, Plus, Package, CheckCircle2, Star,
  Clock, AlertTriangle, ChevronRight, ChevronLeft,
  User, ThumbsUp, Search, CheckSquare, Square, XCircle, Info, Minus, Edit3,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import FilterPanel from '@/components/FilterPanel'

/* ═══════════════════════════════════════════
   类型定义
   ═══════════════════════════════════════════ */

type RepairStatus = 'draft' | 'submitted' | 'processing' | 'completed' | 'accepted' | 'reopened' | 'auto_accepted'
type UserRole = 'officer' | 'admin'

interface StockEquipment {
  id: string
  name: string
  category: string
  model: string
  productionDate: string
  expiryDate: string
  warrantyMonths: number
  remaining: number
  unit: string
  price: number
  code: string
  supplier: string
  supplierContact: string
  supplierPhone: string
}

// 报修装备项（支持多装备 + 多数量）
interface RepairEquipItem {
  equip: StockEquipment
  faultDesc: string
  quantity: number       // 报修数量
}

interface RepairRecord {
  id: string
  items: RepairEquipItem[]           // 多个报修装备
  source: 'in-use' | 'in-stock'
  applicant: string
  applyTime: string
  status: RepairStatus
  submittedTime?: string             // 提交给供应商的时间
  completedTime?: string             // 维修完成时间
  acceptStatus?: 'pending' | 'passed' | 'reopened'
  rating?: number
  review?: string
  reopenReason?: string
  autoAcceptTime?: string            // 自动验收日期（YYYY-MM-DD）
  notifyTime?: string                // 15天通知时间
}

/* ═══════════════════════════════════════════
   Mock 数据：库存装备
   ═══════════════════════════════════════════ */

const stockEquipments: StockEquipment[] = [
  { id: '1', name: '执法记录仪 DSJ-A7', category: '执法设备', model: 'DSJ-A7/64G', productionDate: '2024-02-20', expiryDate: '2029-02-19', warrantyMonths: 24, remaining: 30, unit: '台', price: 1800, code: 'DSJ-A7-001', supplier: '海康威视数字技术股份有限公司', supplierContact: '李卫国', supplierPhone: '13800138002' },
  { id: '2', name: '对讲机 PD780G', category: '通信装备', model: 'PD780G/U段', productionDate: '2024-01-20', expiryDate: '2029-01-19', warrantyMonths: 12, remaining: 100, unit: '台', price: 1200, code: 'PD780G-001', supplier: '烽火通信科技股份有限公司', supplierContact: '王建国', supplierPhone: '13800138001' },
  { id: '3', name: '防弹背心 FDY-3R', category: '防护装备', model: 'FDY-3R/三级', productionDate: '2023-11-10', expiryDate: '2033-11-09', warrantyMonths: 36, remaining: 20, unit: '件', price: 2800, code: 'FDY-3R-001', supplier: '华为技术有限公司', supplierContact: '赵明辉', supplierPhone: '13800138003' },
  { id: '4', name: '战术头盔 MICH-2000', category: '防护装备', model: 'MICH-2000/L号', productionDate: '2023-12-05', expiryDate: '2033-12-04', warrantyMonths: 36, remaining: 40, unit: '顶', price: 1500, code: 'MICH-2000-001', supplier: '中兴通讯股份有限公司', supplierContact: '赵明辉', supplierPhone: '13800138003' },
  { id: '5', name: '应急照明灯 YD-100', category: '照明设备', model: 'YD-100/LED', productionDate: '2024-01-25', expiryDate: '2029-01-24', warrantyMonths: 12, remaining: 60, unit: '台', price: 680, code: 'YD-100-001', supplier: '海康威视数字技术股份有限公司', supplierContact: '李卫国', supplierPhone: '13800138002' },
  { id: '6', name: '防弹盾牌 FDP-3S', category: '防护装备', model: 'FDP-3S/三级', productionDate: '2024-03-01', expiryDate: '2034-02-29', warrantyMonths: 36, remaining: 15, unit: '面', price: 2200, code: 'FDP-3S-001', supplier: '华为技术有限公司', supplierContact: '赵明辉', supplierPhone: '13800138003' },
  { id: '7', name: '催泪喷射器 CL-200', category: '警械装备', model: 'CL-200/200ml', productionDate: '2024-01-10', expiryDate: '2029-01-09', warrantyMonths: 12, remaining: 100, unit: '支', price: 150, code: 'CL-200-001', supplier: '大华技术股份有限公司', supplierContact: '陈建华', supplierPhone: '13800138004' },
  { id: '8', name: '手持终端 XT-2000', category: '通信装备', model: 'XT-2000/黑色', productionDate: '2024-01-15', expiryDate: '2029-01-14', warrantyMonths: 24, remaining: 50, unit: '台', price: 3200, code: 'XT-2000-001', supplier: '华为技术有限公司', supplierContact: '王建国', supplierPhone: '13800138001' },
]

/* ═══════════════════════════════════════════
   Mock 数据：报修记录（多装备支持）
   ═══════════════════════════════════════════ */

function nowStr(offsetMin = 0): string {
  const d = new Date(Date.now() - offsetMin * 60000)
  return d.toLocaleString('zh-CN', { hour12: false })
}

function dateStr(daysAgo = 0): string {
  const d = new Date(Date.now() - daysAgo * 86400000)
  return d.toISOString().slice(0, 10)
}

const currentUser = { name: '张警官', role: 'officer' as UserRole }

const initialRepairData: RepairRecord[] = [
  {
    id: 'BX20260603001',
    items: [{ equip: stockEquipments[0], faultDesc: '电池无法充电，续航不足1小时；摄像头偶尔黑屏', quantity: 2 }],
    source: 'in-use', applicant: '张警官', applyTime: nowStr(360), status: 'submitted',
  },
  {
    id: 'BX20260603002',
    items: [{ equip: stockEquipments[1], faultDesc: '电源按键失灵，无法正常开关机', quantity: 1 }],
    source: 'in-use', applicant: '李警官', applyTime: nowStr(1200), status: 'processing',
    submittedTime: nowStr(1100),
  },
  {
    id: 'BX20260603003',
    items: [
      { equip: stockEquipments[2], faultDesc: '魔术贴老化脱落，无法正常固定', quantity: 3 },
      { equip: stockEquipments[3], faultDesc: '内衬脱落，佩戴不稳固', quantity: 2 },
    ],
    source: 'in-use', applicant: '赵警官', applyTime: nowStr(2400), status: 'processing',
    submittedTime: nowStr(2300),
  },
  {
    id: 'BX20260603004',
    items: [{ equip: stockEquipments[4], faultDesc: 'LED灯珠部分不亮，照明亮度不足', quantity: 1 }],
    source: 'in-use', applicant: '陈警官', applyTime: nowStr(5000),
    status: 'completed', completedTime: nowStr(1440),
    acceptStatus: 'pending', autoAcceptTime: dateStr(2),
  },
  {
    id: 'BX20260603005',
    items: [{ equip: stockEquipments[5], faultDesc: '观察窗出现裂纹，影响视线', quantity: 1 }],
    source: 'in-use', applicant: '王警官', applyTime: nowStr(8000),
    status: 'accepted', completedTime: nowStr(5000),
    acceptStatus: 'passed', rating: 5, review: '维修及时，服务态度好',
  },
  {
    id: 'BX20260603006',
    items: [{ equip: stockEquipments[7], faultDesc: '屏幕触摸失灵，系统卡顿严重', quantity: 1 }],
    source: 'in-use', applicant: '刘警官', applyTime: nowStr(10000),
    status: 'reopened', completedTime: nowStr(8000),
    acceptStatus: 'reopened', reopenReason: '系统重装后仍然卡顿，问题未解决',
  },
  {
    id: 'BX20260603007',
    items: [{ equip: stockEquipments[3], faultDesc: '内衬脱落，佩戴不稳固', quantity: 1 }],
    source: 'in-use', applicant: '周警官', applyTime: nowStr(15000),
    status: 'auto_accepted', completedTime: nowStr(13000),
    acceptStatus: 'passed', rating: 4,
  },
  {
    id: 'BX20260603008',
    items: [{ equip: stockEquipments[6], faultDesc: '喷嘴堵塞，喷射压力不足', quantity: 5 }],
    source: 'in-stock', applicant: '管理员', applyTime: nowStr(2000), status: 'draft',
  },
]

/* ═══════════════════════════════════════════
   辅助函数
   ═══════════════════════════════════════════ */

function getStatusLabel(status: RepairStatus): string {
  const map: Record<string, string> = {
    draft: '草稿', submitted: '已提交', processing: '维修中',
    completed: '待验收', accepted: '已完结', reopened: '已重开',
    auto_accepted: '自动完结',
  }
  return map[status] || status
}

function isInWarranty(equip: StockEquipment): boolean {
  const prod = new Date(equip.productionDate)
  const warrantyEnd = new Date(prod.getTime() + equip.warrantyMonths * 30 * 86400000)
  return new Date() < warrantyEnd
}

function daysUntil(dateStr: string): number {
  const target = new Date(dateStr)
  const now = new Date()
  const diff = target.getTime() - now.getTime()
  return Math.ceil(diff / 86400000)
}

// 计算距离15天通知还剩多少天
function daysUntilNotify(submittedTime?: string): number | null {
  if (!submittedTime) return null
  const submitted = new Date(submittedTime).getTime()
  const notifyAt = submitted + 15 * 86400000
  const diff = notifyAt - Date.now()
  return Math.ceil(diff / 86400000)
}

/* ═══════════════════════════════════════════
   Status Badge
   ═══════════════════════════════════════════ */

function RepairStatusBadge({ status }: { status: RepairStatus }) {
  switch (status) {
    case 'draft': return <Badge variant="warning" dot>草稿</Badge>
    case 'submitted': return <Badge variant="info" dot>已提交</Badge>
    case 'processing': return <Badge variant="primary" dot>维修中</Badge>
    case 'completed': return <Badge variant="success" dot>待验收</Badge>
    case 'accepted': return <Badge variant="success">已完结</Badge>
    case 'auto_accepted': return <Badge variant="default">自动完结</Badge>
    case 'reopened': return <Badge variant="danger">已重开</Badge>

    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ═══════════════════════════════════════════
   装备档案卡片
   ═══════════════════════════════════════════ */

function EquipmentProfileCard({ equip }: { equip: StockEquipment }) {
  const warranty = isInWarranty(equip)
  return (
    <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
        <Package size={16} className="text-[#1A56DB]" />
        设备档案
        {warranty ? (
          <span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-[10px] text-[#059669]">质保期内</span>
        ) : (
          <span className="rounded bg-[#FEE2E2] px-2 py-0.5 text-[10px] text-[#DC2626]">已过质保</span>
        )}
      </div>
      <div className="grid grid-cols-3 gap-3 text-xs">
        <div><span className="text-[#6B7280]">装备名称：</span><span className="font-medium text-[#374151]">{equip.name}</span></div>
        <div><span className="text-[#6B7280]">规格型号：</span><span className="text-[#374151]">{equip.model}</span></div>
        <div><span className="text-[#6B7280]">装备编码：</span><span className="font-mono text-[#374151]">{equip.code}</span></div>
        <div><span className="text-[#6B7280]">生产日期：</span><span className="text-[#374151]">{equip.productionDate}</span></div>
        <div><span className="text-[#6B7280]">有效期至：</span><span className="text-[#374151]">{equip.expiryDate}</span></div>
        <div><span className="text-[#6B7280]">质保期：</span><span className={warranty ? 'text-[#059669]' : 'text-[#DC2626]'}>{equip.warrantyMonths}个月</span></div>
        <div className="col-span-2"><span className="text-[#6B7280]">供应商：</span><span className="font-medium text-[#1A56DB]">{equip.supplier}</span></div>
        <div><span className="text-[#6B7280]">联系人：</span><span className="text-[#374151]">{equip.supplierContact} {equip.supplierPhone}</span></div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   装备选择弹窗（左列表 + 右已选面板，多选）
   ═══════════════════════════════════════════ */

function EquipmentSelectModal({ open, onClose, onConfirm, initialItems = [] }: { open: boolean; onClose: () => void; onConfirm: (items: RepairEquipItem[]) => void; initialItems?: RepairEquipItem[] }) {
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState<RepairEquipItem[]>(initialItems)

  if (!open) return null

  const filtered = stockEquipments.filter(e =>
    search ? e.name.includes(search) || e.code.includes(search) || e.supplier.includes(search) || e.category.includes(search) : true
  )

  const isSelected = (equipId: string) => selected.some(s => s.equip.id === equipId)

  const toggleSelect = (equip: StockEquipment) => {
    if (isSelected(equip.id)) {
      setSelected(prev => prev.filter(s => s.equip.id !== equip.id))
    } else {
      setSelected(prev => [...prev, { equip, faultDesc: '', quantity: 1 }])
    }
  }

  const updateQuantity = (equipId: string, delta: number) => {
    setSelected(prev => prev.map(s => {
      if (s.equip.id !== equipId) return s
      const newQty = Math.max(1, Math.min(s.equip.remaining, s.quantity + delta))
      return { ...s, quantity: newQty }
    }))
  }

  const handleConfirm = () => {
    if (selected.length === 0) { alert('请至少选择一个装备'); return }
    onConfirm(selected)
    setSearch('')
    onClose()
  }

  const handleClose = () => {
    setSearch('')
    onClose()
  }

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={handleClose} />
      <div className="relative z-10 flex h-[620px] w-[900px] max-w-[96vw] flex-col rounded-xl bg-white shadow-2xl">
        {/* Header */}
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-5 py-3">
          <h2 className="text-base font-semibold text-[#1F2937]">选择报修装备</h2>
          <button onClick={handleClose} className="flex h-7 w-7 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={16} /></button>
        </div>

        {/* Search */}
        <div className="shrink-0 border-b border-[#E5E7EB] px-5 py-2">
          <div className="flex items-center gap-2 rounded-md border border-[#D1D5DB] px-3">
            <Search size={14} className="text-[#9CA3AF]" />
            <input
              type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="搜索装备名称、编码、分类或供应商..."
              className="h-8 flex-1 text-sm outline-none"
            />
          </div>
        </div>

        {/* Body: Left list + Right selected */}
        <div className="flex flex-1 overflow-hidden">
          {/* Left: Equipment list */}
          <div className="flex-1 overflow-auto border-r border-[#E5E7EB] p-3">
            <div className="mb-2 text-xs font-medium text-[#6B7280]">可选装备（{filtered.length}）</div>
            <div className="space-y-1.5">
              {filtered.map(equip => {
                const sel = isSelected(equip.id)
                return (
                  <div
                    key={equip.id}
                    onClick={() => toggleSelect(equip)}
                    className={cn(
                      'flex cursor-pointer items-start gap-3 rounded-lg border p-2.5 transition',
                      sel ? 'border-[#1A56DB] bg-[#EFF6FF]' : 'border-[#E5E7EB] hover:border-[#1A56DB] hover:bg-[#F8FAFF]'
                    )}
                  >
                    <div className="mt-0.5 shrink-0" onClick={e => { e.stopPropagation(); toggleSelect(equip) }}>
                      {sel ? <CheckSquare size={18} className="text-[#1A56DB]" /> : <Square size={18} className="text-[#D1D5DB]" />}
                    </div>
                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-[#E8F0FE]"><Package size={16} className="text-[#1A56DB]" /></div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-[#1F2937]">{equip.name}</span>
                        <span className="font-mono text-[10px] text-[#6B7280]">{equip.code}</span>
                        {isInWarranty(equip) ? <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[10px] text-[#059669]">质保内</span> : <span className="rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[10px] text-[#DC2626]">过保</span>}
                      </div>
                      <div className="mt-0.5 text-[11px] text-[#6B7280]">{equip.model} | {equip.category} | 供应商：{equip.supplier}</div>
                    </div>
                  </div>
                )
              })}
              {filtered.length === 0 && <div className="py-8 text-center text-sm text-[#9CA3AF]">无匹配装备</div>}
            </div>
          </div>

          {/* Right: Selected panel */}
          <div className="flex w-[340px] flex-col overflow-hidden bg-[#FAFBFC]">
            <div className="shrink-0 border-b border-[#E5E7EB] px-4 py-2.5">
              <div className="text-sm font-medium text-[#374151]">已选装备</div>
              <div className="mt-0.5 text-xs text-[#6B7280]">{selected.length} 种装备，可调整数量</div>
            </div>
            <div className="flex-1 overflow-auto p-3">
              {selected.length === 0 && (
                <div className="flex h-full flex-col items-center justify-center text-[#9CA3AF]">
                  <Package size={32} className="mb-2 opacity-40" />
                  <span className="text-xs">请从左侧选择装备</span>
                </div>
              )}
              <div className="space-y-3">
                {selected.map(item => (
                  <div key={item.equip.id} className="rounded-lg border border-[#E5E7EB] bg-white p-3">
                    <div className="mb-1.5 flex items-center justify-between">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <span className="truncate text-sm font-medium text-[#1F2937]">{item.equip.name}</span>
                        <span className="shrink-0 font-mono text-[10px] text-[#6B7280]">{item.equip.code}</span>
                      </div>
                      <button onClick={() => toggleSelect(item.equip)} className="shrink-0 text-[#EF4444] hover:bg-[#FEE2E2] rounded p-0.5"><XCircle size={14} /></button>
                    </div>
                    {/* 数量调整 */}
                    <div className="mb-1.5 flex items-center gap-2">
                      <span className="text-xs text-[#6B7280]">报修数量：</span>
                      <div className="flex items-center rounded-md border border-[#D1D5DB] overflow-hidden">
                        <button onClick={() => updateQuantity(item.equip.id, -1)} className="flex h-6 w-6 items-center justify-center bg-[#F9FAFB] hover:bg-[#F3F4F6]"><Minus size={12} /></button>
                        <span className="flex h-6 w-8 items-center justify-center border-x border-[#D1D5DB] text-xs font-medium">{item.quantity}</span>
                        <button onClick={() => updateQuantity(item.equip.id, 1)} className="flex h-6 w-6 items-center justify-center bg-[#F9FAFB] hover:bg-[#F3F4F6]"><Plus size={12} /></button>
                      </div>
                      <span className="text-[10px] text-[#9CA3AF]">库存{item.equip.remaining}{item.equip.unit}</span>
                    </div>

                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex shrink-0 items-center justify-end gap-2 border-t border-[#E5E7EB] px-5 py-3">
          <button onClick={handleClose} className="h-8 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">取消</button>
          <button onClick={handleConfirm} className="h-8 rounded-md bg-[#1A56DB] px-5 text-sm text-white">确认 ({selected.length})</button>
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   发起报修弹窗（多装备）
   ═══════════════════════════════════════════ */

// 设备档案卡片（新建报修用，参考截图样式）
function EquipProfileCardCompact({ item, index, onFaultChange }: { item: RepairEquipItem; index: number; onFaultChange?: (equipId: string, desc: string) => void }) {
  const equip = item.equip
  const warranty = isInWarranty(equip)
  return (
    <div className="space-y-3">
      {/* 设备档案 */}
      <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-4">
        <div className="mb-3 flex items-center gap-2 text-sm font-semibold text-[#374151]">
          <Package size={16} className="text-[#1A56DB]" />
          设备档案
          {warranty ? (
            <span className="rounded bg-[#D1FAE5] px-2 py-0.5 text-[10px] text-[#059669]">质保期内</span>
          ) : (
            <span className="rounded bg-[#FEE2E2] px-2 py-0.5 text-[10px] text-[#DC2626]">已过质保</span>
          )}
        </div>
        <div className="grid grid-cols-3 gap-3 text-xs">
          <div><span className="text-[#6B7280]">装备名称：</span><span className="font-medium text-[#374151]">{equip.name}</span></div>
          <div><span className="text-[#6B7280]">规格型号：</span><span className="text-[#374151]">{equip.model}</span></div>
          <div><span className="text-[#6B7280]">装备编码：</span><span className="font-mono text-[#374151]">{equip.code}</span></div>
          <div><span className="text-[#6B7280]">生产日期：</span><span className="text-[#374151]">{equip.productionDate}</span></div>
          <div><span className="text-[#6B7280]">有效期至：</span><span className="text-[#374151]">{equip.expiryDate}</span></div>
          <div><span className="text-[#6B7280]">质保期：</span><span className={warranty ? 'font-semibold text-[#DC2626]' : 'text-[#DC2626]'}>{equip.warrantyMonths}个月</span></div>
          <div className="col-span-2"><span className="text-[#6B7280]">供应商：</span><span className="font-medium text-[#1A56DB]">{equip.supplier}</span></div>
          <div><span className="text-[#6B7280]">联系人：</span><span className="text-[#374151]">{equip.supplierContact} {equip.supplierPhone}</span></div>
        </div>
        {/* 数量 */}
        <div className="mt-2 border-t border-[#E5E7EB] pt-2 text-xs">
          <span className="text-[#6B7280]">报修数量：</span>
          <span className="font-medium text-[#1A56DB]">{item.quantity}{equip.unit}</span>
        </div>
      </div>
      {/* 故障描述 */}
      {onFaultChange && (
        <div>
          <label className="mb-1 block text-xs text-[#6B7280]">故障描述 <span className="text-[#EF4444]">*</span></label>
          <textarea
            value={item.faultDesc}
            onChange={e => onFaultChange(equip.id, e.target.value)}
            rows={3}
            placeholder="请详细描述故障现象，如：无法开机、屏幕黑屏、按键失灵等..."
            className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]"
          />
        </div>
      )}
    </div>
  )
}

function CreateRepairModal({ open, onClose, onSave, editingRecord }: { open: boolean; onClose: () => void; onSave: (record: RepairRecord) => void; editingRecord?: RepairRecord | null }) {
  const isEdit = !!editingRecord
  const [selectedItems, setSelectedItems] = useState<RepairEquipItem[]>([])
  const [showEquipSelect, setShowEquipSelect] = useState(false)

  // 当弹窗打开或编辑记录变化时，同步选中数据
  useEffect(() => {
    if (open && editingRecord) {
      setSelectedItems(editingRecord.items)
    } else if (open && !editingRecord) {
      setSelectedItems([])
    }
  }, [open, editingRecord])

  if (!open) return null

  const source: 'in-use' | 'in-stock' = currentUser.role === 'admin' ? 'in-stock' : 'in-use'

  const repairNo = isEdit && editingRecord ? editingRecord.id : `BX${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`

  const handleSave = (status: 'draft' | 'submitted') => {
    if (selectedItems.length === 0) { alert('请选择报修装备'); return }
    const emptyItems = selectedItems.filter(i => !i.faultDesc.trim())
    if (emptyItems.length > 0) { alert(`还有 ${emptyItems.length} 个装备未填写故障描述`); return }

    const now = new Date().toLocaleString('zh-CN', { hour12: false })
    const record: RepairRecord = {
      id: repairNo,
      items: selectedItems,
      source,
      applicant: currentUser.name,
      applyTime: isEdit && editingRecord ? editingRecord.applyTime : now,
      status,
    }
    onSave(record)
    // reset
    setSelectedItems([])
    onClose()
  }

  const updateItemFaultDesc = (equipId: string, desc: string) => {
    setSelectedItems(prev => prev.map(item =>
      item.equip.id === equipId ? { ...item, faultDesc: desc } : item
    ))
  }

  const removeItem = (equipId: string) => {
    setSelectedItems(prev => prev.filter(item => item.equip.id !== equipId))
  }

  return (
    <>
      <div className="fixed inset-0 z-50 flex items-center justify-center">
        <div className="absolute inset-0 bg-black/40" onClick={onClose} />
        <div className="relative z-10 flex max-h-[92vh] w-[720px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl">
          <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
            <h2 className="text-lg font-semibold text-[#1F2937]">{isEdit ? '编辑报修' : '发起报修'}</h2>
            <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
          </div>
          <div className="flex-1 overflow-auto px-6 py-5 space-y-5">
            {/* 报修单号 + 报修人 */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">报修单号</label>
                <input type="text" value={repairNo} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#6B7280]" />
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">报修人</label>
                <input type="text" value={currentUser.name} readOnly className="h-9 w-full rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]" />
              </div>
            </div>

            {/* 时限说明 */}
            <div className="rounded-md border border-[#F59E0B]/30 bg-[#FFF7ED] px-3 py-2.5">
              <div className="flex items-start gap-2 text-xs text-[#D97706]">
                <Clock size={14} className="mt-0.5 shrink-0" />
                <div className="space-y-0.5">
                  <div className="font-medium">时限说明</div>
                  <div>提交后15天后，系统将发送通知，3天内未处理系统将自动验收通过。</div>
                </div>
              </div>
            </div>

            {/* 选择装备 */}
            <div>
              <div className="mb-1.5 flex items-center justify-between">
                <label className="text-xs text-[#6B7280]">报修装备 <span className="text-[#EF4444]">*</span></label>
                <button onClick={() => setShowEquipSelect(true)} className="inline-flex items-center gap-1 rounded-md bg-[#1A56DB] px-3 py-1 text-xs text-white hover:bg-[#153E7E]">
                  <Plus size={12} /> {selectedItems.length > 0 ? '添加更多' : '添加装备'}
                </button>
              </div>

              {selectedItems.length === 0 ? (
                <button onClick={() => setShowEquipSelect(true)} className="flex h-14 w-full items-center justify-center gap-2 rounded-lg border border-dashed border-[#D1D5DB] text-sm text-[#6B7280] hover:border-[#1A56DB] hover:text-[#1A56DB] transition">
                  <Plus size={16} /> 点击添加报修装备（可多选）
                </button>
              ) : (
                <div className="space-y-5">
                  {selectedItems.map((item, idx) => (
                    <div key={item.equip.id} className="relative">
                      <div className="absolute -right-1 -top-1 z-10">
                        <button onClick={() => removeItem(item.equip.id)} className="flex h-5 w-5 items-center justify-center rounded-full bg-[#EF4444] text-white shadow-sm hover:bg-[#DC2626]"><X size={12} /></button>
                      </div>
                      <EquipProfileCardCompact item={item} index={idx} onFaultChange={updateItemFaultDesc} />
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex shrink-0 items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
            <button onClick={onClose} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">取消</button>
            <button onClick={() => handleSave('draft')} className="h-9 rounded-md border border-[#D1D5DB] bg-white px-4 text-sm text-[#374151]">保存草稿</button>
            <button onClick={() => handleSave('submitted')} className="h-9 rounded-md bg-[#1A56DB] px-5 text-sm text-white">{isEdit ? '保存并提交' : '提交报修'}</button>
          </div>
        </div>
      </div>
      <EquipmentSelectModal
        open={showEquipSelect}
        onClose={() => setShowEquipSelect(false)}
        initialItems={selectedItems}
        onConfirm={(items) => {
          // 合并已有和新增，保留故障描述
          const existingMap = new Map(selectedItems.map(i => [i.equip.id, i]))
          const merged = items.map(item => {
            const existing = existingMap.get(item.equip.id)
            return existing ? { ...item, faultDesc: existing.faultDesc } : item
          })
          setSelectedItems(merged)
        }}
      />
    </>
  )
}

/* ═══════════════════════════════════════════
   民警验收弹窗（多装备）
   ═══════════════════════════════════════════ */

function AcceptModal({ record, onClose, onUpdate }: { record: RepairRecord | null; onClose: () => void; onUpdate: (r: RepairRecord) => void }) {
  const [rating, setRating] = useState(0)
  const [review, setReview] = useState('')
  const [reopenReason, setReopenReason] = useState('')
  const [showReopen, setShowReopen] = useState(false)

  if (!record) return null

  const autoAcceptDays = record.autoAcceptTime ? daysUntil(record.autoAcceptTime) : null

  const handleAccept = () => {
    if (rating === 0) { alert('请评分'); return }
    onUpdate({ ...record, acceptStatus: 'passed', rating, review: review.trim() || undefined, status: 'accepted' })
    onClose()
  }

  const handleReopen = () => {
    if (!reopenReason.trim()) { alert('请填写重开原因'); return }
    onUpdate({ ...record, acceptStatus: 'reopened', reopenReason: reopenReason.trim(), status: 'reopened' })
    onClose()
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[520px] max-w-[90vw] rounded-xl bg-white shadow-2xl" style={{ maxHeight: '92vh' }}>
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">维修验收</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="overflow-auto p-6 space-y-4" style={{ maxHeight: 'calc(92vh - 70px)' }}>
          {/* 自动验收提示 */}
          {autoAcceptDays !== null && autoAcceptDays > 0 && (
            <div className="rounded-md border border-[#F59E0B]/30 bg-[#FFF7ED] p-3">
              <div className="flex items-center gap-2 text-xs text-[#D97706]">
                <Clock size={14} />
                <span>系统提示：若{autoAcceptDays}天内未验收，将自动完成验收</span>
              </div>
            </div>
          )}

          {/* 维修装备列表 */}
          <div className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
            <div className="mb-2 text-xs font-medium text-[#374151]">维修装备（{record.items.length}种，共{record.items.reduce((s, i) => s + i.quantity, 0)}件）</div>
            <div className="space-y-2">
              {record.items.map((item, idx) => (
                <div key={item.equip.id} className="flex items-center gap-2 rounded-md bg-white p-2">
                  <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-[#E8F0FE] text-[10px] font-bold text-[#1A56DB]">{idx + 1}</span>
                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-medium text-[#374151]">{item.equip.name} <span className="text-[#1A56DB]">×{item.quantity}{item.equip.unit}</span></div>
                    <div className="text-[11px] text-[#6B7280]">{item.equip.code} | {item.equip.model}</div>
                  </div>
                </div>
              ))}
            </div>
            {record.completedTime && <div className="mt-2 border-t border-[#E5E7EB] pt-2 text-xs text-[#6B7280]">完成时间：{record.completedTime}</div>}
          </div>

          {!showReopen ? (
            <>
              {/* Rating */}
              <div>
                <label className="mb-2 block text-sm font-medium text-[#374151]">服务评分 <span className="text-[#EF4444]">*</span></label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button key={star} onClick={() => setRating(star)} className="transition hover:scale-110">
                      <Star size={28} className={star <= rating ? 'fill-[#F59E0B] text-[#F59E0B]' : 'text-[#D1D5DB]'} />
                    </button>
                  ))}
                </div>
                <div className="mt-1 text-xs text-[#6B7280]">{rating > 0 && ['', '很差', '较差', '一般', '满意', '非常满意'][rating]}</div>
              </div>
              {/* Review */}
              <div>
                <label className="mb-1 block text-sm font-medium text-[#374151]">评价</label>
                <textarea value={review} onChange={e => setReview(e.target.value)} rows={2} placeholder="对维修服务的评价（可选）..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowReopen(true)} className="h-9 flex-1 rounded-md border border-[#EF4444] bg-white text-sm text-[#EF4444]">问题未解决，重开</button>
                <button onClick={handleAccept} className="h-9 flex-1 rounded-md bg-[#059669] text-sm text-white">确认修复</button>
              </div>
            </>
          ) : (
            <>
              <div>
                <label className="mb-1 block text-sm font-medium text-[#374151]">重开原因 <span className="text-[#EF4444]">*</span></label>
                <textarea value={reopenReason} onChange={e => setReopenReason(e.target.value)} rows={3} placeholder="请说明问题未解决的具体情况..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => setShowReopen(false)} className="h-9 flex-1 rounded-md border border-[#D1D5DB] bg-white text-sm text-[#374151]">返回</button>
                <button onClick={handleReopen} className="h-9 flex-1 rounded-md bg-[#DC2626] text-sm text-white">确认重开</button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   详情弹窗（多装备展示）
   ═══════════════════════════════════════════ */

function RepairDetailModal({ record, onClose }: { record: RepairRecord | null; onClose: () => void }) {
  if (!record) return null

  const autoAcceptDays = record.autoAcceptTime ? daysUntil(record.autoAcceptTime) : null
  const notifyDays = daysUntilNotify(record.submittedTime)

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 w-[640px] max-w-[95vw] rounded-xl bg-white shadow-2xl" style={{ maxHeight: '92vh' }}>
        <div className="flex shrink-0 items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h2 className="text-lg font-semibold text-[#1F2937]">报修单详情</h2>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>
        <div className="overflow-auto p-6 space-y-5" style={{ maxHeight: 'calc(92vh - 70px)' }}>
          {/* 自动验收提示 */}
          {record.status === 'completed' && autoAcceptDays !== null && autoAcceptDays > 0 && (
            <div className="rounded-md border border-[#F59E0B]/30 bg-[#FFF7ED] p-3">
              <div className="flex items-center gap-2 text-sm text-[#D97706]">
                <Clock size={16} />
                <span>系统将在{autoAcceptDays}天后自动完成验收</span>
              </div>
            </div>
          )}

          {/* 基本信息 */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">报修单号</div><div className="text-sm font-medium text-[#1A56DB]">{record.id}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">状态</div><div className="text-sm"><RepairStatusBadge status={record.status} /></div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">报修人</div><div className="text-sm text-[#374151]">{record.applicant}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">申请时间</div><div className="text-sm text-[#374151]">{record.applyTime}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">报修来源</div><div className="text-sm">{record.source === 'in-use' ? '在用装备' : '在库装备'}</div></div>
            <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">装备数量</div><div className="text-sm text-[#374151]">{record.items.length} 件</div></div>
            {record.submittedTime && (
              <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">提交供应商</div><div className="text-sm text-[#374151]">{record.submittedTime}</div></div>
            )}
            {record.completedTime && (
              <div className="rounded-lg border border-[#E5E7EB] p-3"><div className="text-xs text-[#6B7280]">完成时间</div><div className="text-sm text-[#374151]">{record.completedTime}</div></div>
            )}
          </div>

          {/* 报修装备列表 */}
          <div>
            <div className="mb-2 flex items-center gap-2 text-sm font-semibold text-[#374151]">
              <Package size={16} className="text-[#1A56DB]" />
              报修装备清单
            </div>
            <div className="space-y-3">
              {record.items.map((item, idx) => (
                <div key={item.equip.id} className="rounded-lg border border-[#E5E7EB] bg-[#FAFBFC] p-3">
                  <div className="mb-2 flex items-center gap-2">
                    <span className="flex h-5 w-5 items-center justify-center rounded-full bg-[#1A56DB] text-[10px] font-bold text-white">{idx + 1}</span>
                    <span className="text-sm font-medium text-[#1F2937]">{item.equip.name}</span>
                    <span className="font-mono text-[10px] text-[#6B7280]">{item.equip.code}</span>
                    <span className="rounded bg-[#E8F0FE] px-1.5 py-0.5 text-[10px] text-[#1A56DB]">{item.quantity}{item.equip.unit}</span>
                    {isInWarranty(item.equip) ? <span className="rounded bg-[#D1FAE5] px-1.5 py-0.5 text-[10px] text-[#059669]">质保内</span> : <span className="rounded bg-[#FEE2E2] px-1.5 py-0.5 text-[10px] text-[#DC2626]">过保</span>}
                  </div>
                  <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-[#6B7280]">
                    <div>装备编码：{item.equip.code}</div>
                    <div>型号：{item.equip.model}</div>
                    <div>分类：{item.equip.category}</div>
                    <div>生产日期：{item.equip.productionDate}</div>
                    <div>有效期至：{item.equip.expiryDate}</div>
                    <div>质保期：{item.equip.warrantyMonths}个月</div>
                    <div className="col-span-2">供应商：{item.equip.supplier}</div>
                    <div>联系人：{item.equip.supplierContact} {item.equip.supplierPhone}</div>
                  </div>
                  <div className="mt-2 rounded-md border border-[#E5E7EB] bg-white p-2">
                    <div className="text-[10px] text-[#6B7280]">故障描述</div>
                    <div className="mt-0.5 text-xs text-[#374151]">{item.faultDesc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 验收信息 */}
          {record.acceptStatus && (
            <div className={cn(
              'rounded-lg border p-3',
              record.acceptStatus === 'passed' || record.status === 'auto_accepted' ? 'border-[#10B981]/30 bg-[#F0FDF4]' :
              record.acceptStatus === 'reopened' ? 'border-[#EF4444]/30 bg-[#FEE2E2]' : 'border-[#E5E7EB]'
            )}>
              <div className="text-xs font-medium text-[#374151]">验收信息</div>
              {record.status === 'auto_accepted' && (
                <div className="mt-1 text-sm text-[#6B7280]">系统自动验收通过</div>
              )}
              {record.acceptStatus === 'passed' && (
                <>
                  <div className="mt-1 text-sm text-[#059669]">验收通过</div>
                  {record.rating && (
                    <div className="mt-1 flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map(s => <Star key={s} size={14} className={s <= record.rating! ? 'fill-[#F59E0B] text-[#F59E0B]' : 'text-[#D1D5DB]'} />)}
                    </div>
                  )}
                  {record.review && <div className="mt-1 text-xs text-[#6B7280]">{record.review}</div>}
                </>
              )}
              {record.acceptStatus === 'reopened' && (
                <>
                  <div className="mt-1 text-sm text-[#DC2626]">已重开</div>
                  {record.reopenReason && <div className="mt-1 text-xs text-[#374151]">原因：{record.reopenReason}</div>}
                </>
              )}
              {record.acceptStatus === 'pending' && (
                <>
                  <div className="mt-1 text-sm text-[#D97706]">待验收</div>
                  {autoAcceptDays !== null && autoAcceptDays > 0 && (
                    <div className="mt-1 text-xs text-[#D97706]">{autoAcceptDays}天后自动验收</div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ═══════════════════════════════════════════
   主页面
   ═══════════════════════════════════════════ */

export default function RepairPage() {
  const [data, setData] = useState<RepairRecord[]>(initialRepairData)
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [detailRecord, setDetailRecord] = useState<RepairRecord | null>(null)
  const [acceptRecord, setAcceptRecord] = useState<RepairRecord | null>(null)
  const [editingRecord, setEditingRecord] = useState<RepairRecord | null>(null)

  const handleFilterChange = (key: string, value: string) => setFilterValues(p => ({ ...p, [key]: value }))
  const handleSearch = () => {}
  const handleReset = () => setFilterValues({})

  const handleDelete = (id: string) => { if (confirm('确定删除该报修单？')) setData(prev => prev.filter(d => d.id !== id)) }

  const handleSaveRepair = useCallback((record: RepairRecord) => {
    setData(prev => {
      const exists = prev.some(d => d.id === record.id)
      if (exists) {
        return prev.map(d => d.id === record.id ? record : d)
      }
      return [record, ...prev]
    })
  }, [])

  const handleUpdateRecord = useCallback((record: RepairRecord) => {
    setData(prev => prev.map(d => d.id === record.id ? record : d))
  }, [])

  const filteredData = data.filter(r => {
    if (filterValues.repairNo && !r.id.includes(filterValues.repairNo)) return false
    if (filterValues.status && r.status !== filterValues.status) return false
    return true
  })

  const filterFields = [
    { key: 'repairNo', label: '报修单号', type: 'input' as const, placeholder: '请输入报修单号' },
    { key: 'status', label: '状态', type: 'select' as const, options: [
      { label: '草稿', value: 'draft' }, { label: '已提交', value: 'submitted' },
      { label: '维修中', value: 'processing' }, { label: '待验收', value: 'completed' },
      { label: '已重开', value: 'reopened' },
      { label: '已完结', value: 'accepted' }, { label: '自动完结', value: 'auto_accepted' },
    ]},
  ]

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">报修管理</h1>
        <button onClick={() => { setEditingRecord(null); setShowCreateModal(true) }} className="inline-flex h-9 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white hover:bg-[#153E7E]">
          <FileText size={14} /> 新建报修
        </button>
      </div>

      <div className="mt-4">
        <FilterPanel fields={filterFields} values={filterValues} onChange={handleFilterChange} onSearch={handleSearch} onReset={handleReset} />
      </div>

      <div className="mt-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">报修单号</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">装备</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">报修人</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">状态</th>
                <th className="px-3 py-3 text-left text-xs font-semibold text-[#6B7280]">申请时间</th>
                <th className="w-48 px-3 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 && (
                <tr><td colSpan={6} className="px-4 py-12 text-center text-sm text-[#9CA3AF]">暂无数据</td></tr>
              )}
              {filteredData.map((row) => {
                const autoAcceptDays = row.autoAcceptTime ? daysUntil(row.autoAcceptTime) : null
                return (
                  <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                    <td className="px-3 py-3 text-[13px] font-medium text-[#1A56DB]">{row.id}</td>
                    <td className="px-3 py-3 text-[13px] text-[#374151]">
                      <div className="font-medium">
                        {row.items.length === 1
                          ? `${row.items[0].equip.name} ×${row.items[0].quantity}${row.items[0].equip.unit}`
                          : `${row.items[0].equip.name} 等 ${row.items.reduce((sum, i) => sum + i.quantity, 0)}${row.items[0].equip.unit}`
                        }
                      </div>
                      <div className="text-[11px] text-[#6B7280]">
                        {row.items.length === 1 ? row.items[0].equip.code : `共 ${row.items.length} 种装备`}
                      </div>
                    </td>
                    <td className="px-3 py-3 text-[13px] text-[#374151]">{row.applicant}</td>
                    <td className="px-3 py-3">
                      <RepairStatusBadge status={row.status} />
                      {row.status === 'completed' && autoAcceptDays !== null && autoAcceptDays > 0 && (
                        <div className="mt-0.5 text-[10px] text-[#D97706]">{autoAcceptDays}天后自动验收</div>
                      )}
                    </td>
                    <td className="px-3 py-3 text-[12px] text-[#374151]">{row.applyTime}</td>
                    <td className="px-3 py-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button onClick={() => setDetailRecord(row)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#1A56DB] hover:bg-[#E8F0FE]" title="查看"><Eye size={14} /></button>
                        {/* 草稿状态：编辑 */}
                        {row.status === 'draft' && (
                          <button onClick={() => { setEditingRecord(row); setShowCreateModal(true) }} className="flex h-7 w-7 items-center justify-center rounded-md text-[#D97706] hover:bg-[#FEF3C7]" title="编辑"><Edit3 size={14} /></button>
                        )}
                        {/* 待验收状态 */}
                        {row.status === 'completed' && (
                          <button onClick={() => setAcceptRecord(row)} className="flex h-7 items-center gap-1 rounded-md bg-[#059669] px-2 text-[11px] text-white hover:bg-[#047857]" title="验收"><ThumbsUp size={12} />验收</button>
                        )}
                        <button onClick={() => handleDelete(row.id)} className="flex h-7 w-7 items-center justify-center rounded-md text-[#EF4444] hover:bg-[#FEE2E2]" title="删除"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-3">
          <span className="text-sm text-[#6B7280]">共 {filteredData.length} 条记录</span>
          <div className="flex items-center gap-1">
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">上一页</button>
            <button className="h-8 rounded-md bg-[#1A56DB] px-3 text-sm text-white">1</button>
            <button className="h-8 rounded-md border border-[#D1D5DB] bg-white px-3 text-sm text-[#374151]">下一页</button>
          </div>
        </div>
      </div>

      <CreateRepairModal open={showCreateModal} onClose={() => { setShowCreateModal(false); setEditingRecord(null) }} onSave={handleSaveRepair} editingRecord={editingRecord} />
      <RepairDetailModal record={detailRecord} onClose={() => setDetailRecord(null)} />
      <AcceptModal record={acceptRecord} onClose={() => setAcceptRecord(null)} onUpdate={handleUpdateRecord} />
    </div>
  )
}