import { useState } from 'react'
import {
  UserCheck,
  ArrowRightLeft,
  Truck,
  Wrench,
  Trash2,
  Zap,
  Eye,
  Edit,
  CheckCircle,
  X,
  Plus,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import DataTable from '@/components/DataTable'
import FilterPanel from '@/components/FilterPanel'

/* ─── Outbound types config ─── */
const outboundTypes = [
  { key: 'issue', label: '个人领用出库', icon: <UserCheck size={22} />, color: '#1A56DB', bg: '#E8F0FE', desc: '个人领用装备' },
  { key: 'allocate', label: '配发出库', icon: <Truck size={22} />, color: '#10B981', bg: '#D1FAE5', desc: '所队配发装备' },
  { key: 'transfer', label: '调拨出库', icon: <ArrowRightLeft size={22} />, color: '#8B5CF6', bg: '#EDE9FE', desc: '跨仓库调拨' },
  { key: 'repair', label: '报修出库', icon: <Wrench size={22} />, color: '#F59E0B', bg: '#FEF3C7', desc: '送修装备出库' },
  { key: 'scrap', label: '报废出库', icon: <Trash2 size={22} />, color: '#EF4444', bg: '#FEE2E2', desc: '报废装备处置' },
  { key: 'emergency', label: '紧急出库', icon: <Zap size={22} />, color: '#DC2626', bg: '#FECACA', desc: '紧急状况出库' },
]

/* ─── Type badge helper ─── */
function TypeBadge({ type }: { type: string }) {
  const config: Record<string, { label: string; variant: string }> = {
    issue: { label: '个人领用出库', variant: 'primary' },
    allocate: { label: '配发出库', variant: 'success' },
    transfer: { label: '调拨出库', variant: 'info' },
    repair: { label: '报修出库', variant: 'warning' },
    scrap: { label: '报废出库', variant: 'danger' },
    emergency: { label: '紧急出库', variant: 'danger' },
  }
  const c = config[type] || { label: type, variant: 'default' }
  return <Badge variant={c.variant as any}>{c.label}</Badge>
}

/* ─── Status badge helper ─── */
function StatusBadge({ status }: { status: string }) {
  switch (status) {
    case 'pending': return <Badge variant="warning" dot>待出库</Badge>
    case 'completed': return <Badge variant="success" dot>已出库</Badge>
    default: return <Badge variant="default">{status}</Badge>
  }
}

/* ─── Mock data for each type ─── */

// 1. 领用出库: 出库单号、出库类型、申请人/申请单、是否借用、归还时间、调出仓库、装备数量、出库日期、状态、备注
const issueData = [
  { id: 'LY20260604001', type: 'issue', applicant: '王警官', isBorrow: '是', returnTime: '2026-07-04', warehouse: 'A区主仓库', qty: 5, date: '2026-06-04', status: 'pending', remark: '巡逻装备领用', items: '防弹背心x1,手铐x2,执法记录仪x1,警棍x1' },
  { id: 'LY20260604002', type: 'issue', applicant: '李警官', isBorrow: '否', returnTime: '-', warehouse: 'B区仓库', qty: 3, date: '2026-06-04', status: 'completed', remark: '新警入职配发', items: '防弹背心x1,头盔x1,防割手套x1' },
  { id: 'LY20260603001', type: 'issue', applicant: '张警官', isBorrow: '是', returnTime: '2026-06-17', warehouse: 'A区主仓库', qty: 2, date: '2026-06-03', status: 'pending', remark: '临时任务借用', items: '夜视仪x1,对讲机x1' },
  { id: 'LY20260603002', type: 'issue', applicant: '赵警官', isBorrow: '否', returnTime: '-', warehouse: 'C区仓库', qty: 8, date: '2026-06-03', status: 'completed', remark: '常规装备更换', items: '执法记录仪x2,手铐x4,警棍x2' },
  { id: 'LY20260602001', type: 'issue', applicant: '刘警官', isBorrow: '是', returnTime: '2026-06-09', warehouse: 'A区主仓库', qty: 1, date: '2026-06-02', status: 'pending', remark: '演练装备借用', items: '防弹盾牌x1' },
]

// 2. 配发出库: 出库单号、出库类型、申请人/申请单位、调出仓库、配发单位、剩余数量、装备数量、出库日期、状态、备注
const allocateData = [
  { id: 'PF20260604001', type: 'allocate', applicant: '张队长', warehouse: 'A区主仓库', allocateUnit: '刑警支队', remainingQty: 230, qty: 120, date: '2026-06-04', status: 'pending', remark: '季度装备配发', items: '防刺服x40,头盔x40,反光背心x40' },
  { id: 'PF20260604002', type: 'allocate', applicant: '李所长', warehouse: 'B区仓库', allocateUnit: '派出所A', remainingQty: 85, qty: 15, date: '2026-06-04', status: 'completed', remark: '新所开业配发', items: '电脑x5,打印机x2,对讲机x8' },
  { id: 'PF20260603001', type: 'allocate', applicant: '王科长', warehouse: 'A区主仓库', allocateUnit: '特警大队', remainingQty: 180, qty: 80, date: '2026-06-03', status: 'pending', remark: '特警装备补充', items: '执法记录仪x40,对讲机x40' },
  { id: 'PF20260602001', type: 'allocate', applicant: '赵主任', warehouse: 'C区仓库', allocateUnit: '交警大队', remainingQty: 56, qty: 44, date: '2026-06-02', status: 'completed', remark: '交警夏季装备', items: '反光背心x44' },
  { id: 'PF20260601001', type: 'allocate', applicant: '钱队长', warehouse: 'A区主仓库', allocateUnit: '治安大队', remainingQty: 320, qty: 60, date: '2026-06-01', status: 'completed', remark: '常规装备配发', items: '手铐x30,警棍x30' },
]

// 3. 调拨出库: 出库单号、出库类型、发物单位、收物单位、申请人/申请单位、调出仓库、装备数量、出库日期、状态、备注
const transferData = [
  { id: 'DB20260604001', type: 'transfer', fromUnit: 'A区主仓库', toUnit: 'B区仓库', applicant: '李管理员', warehouse: 'A区主仓库', qty: 50, date: '2026-06-04', status: 'pending', remark: '库存平衡调拨', items: '防弹背心x50' },
  { id: 'DB20260604002', type: 'transfer', fromUnit: 'B区仓库', toUnit: 'C区仓库', applicant: '王管理员', warehouse: 'B区仓库', qty: 200, date: '2026-06-04', status: 'completed', remark: '支援C区装备', items: '手铐x200' },
  { id: 'DB20260603001', type: 'transfer', fromUnit: 'A区主仓库', toUnit: 'D区仓库', applicant: '赵管理员', warehouse: 'A区主仓库', qty: 30, date: '2026-06-03', status: 'pending', remark: '新仓库 initialization', items: '对讲机x30' },
  { id: 'DB20260602001', type: 'transfer', fromUnit: 'C区仓库', toUnit: 'A区主仓库', applicant: '刘管理员', warehouse: 'C区仓库', qty: 100, date: '2026-06-02', status: 'completed', remark: '回收盘点调拨', items: '执法记录仪x100' },
  { id: 'DB20260601001', type: 'transfer', fromUnit: 'A区主仓库', toUnit: 'B区仓库', applicant: '李管理员', warehouse: 'A区主仓库', qty: 25, date: '2026-06-01', status: 'completed', remark: '常规补货调拨', items: '头盔x25' },
]

// 4. 报修出库: 出库单号、出库类型、申请人/申请单位、调出仓库、装备数量、出库日期、状态、备注
const repairData = [
  { id: 'BX20260604001', type: 'repair', applicant: '赵管理员', warehouse: 'A区主仓库', qty: 12, date: '2026-06-04', status: 'pending', remark: '批量故障送修', items: '执法记录仪x8,对讲机x4' },
  { id: 'BX20260604002', type: 'repair', applicant: '钱警官', warehouse: 'B区仓库', qty: 6, date: '2026-06-04', status: 'completed', remark: '电池老化更换', items: '对讲机x6' },
  { id: 'BX20260603001', type: 'repair', applicant: '孙管理员', warehouse: 'C区仓库', qty: 3, date: '2026-06-03', status: 'pending', remark: '屏幕损坏维修', items: '执法记录仪x3' },
  { id: 'BX20260602001', type: 'repair', applicant: '周警官', warehouse: 'A区主仓库', qty: 1, date: '2026-06-02', status: 'completed', remark: '镜头故障送修', items: '夜视仪x1' },
  { id: 'BX20260601001', type: 'repair', applicant: '吴管理员', warehouse: 'B区仓库', qty: 5, date: '2026-06-01', status: 'completed', remark: '按键失灵维修', items: '对讲机x5' },
]

// 5. 报废出库: 出库单号、出库类型、申请人/申请单位、调出仓库、装备数量、出库日期、状态、备注
const scrapData = [
  { id: 'BF20260604001', type: 'scrap', applicant: '刘警官', warehouse: 'A区主仓库', qty: 3, date: '2026-06-04', status: 'pending', remark: '超期服役报废', items: '夜视仪x2,测速仪x1' },
  { id: 'BF20260604002', type: 'scrap', applicant: '陈管理员', warehouse: 'B区仓库', qty: 15, date: '2026-06-04', status: 'completed', remark: '批量到期报废', items: '防弹背心x15' },
  { id: 'BF20260603001', type: 'scrap', applicant: '杨警官', warehouse: 'C区仓库', qty: 8, date: '2026-06-03', status: 'pending', remark: '损坏无法修复', items: '执法记录仪x8' },
  { id: 'BF20260602001', type: 'scrap', applicant: '黄管理员', warehouse: 'A区主仓库', qty: 20, date: '2026-06-02', status: 'completed', remark: '标准更新淘汰', items: '手铐x20' },
  { id: 'BF20260601001', type: 'scrap', applicant: '徐警官', warehouse: 'B区仓库', qty: 5, date: '2026-06-01', status: 'completed', remark: '电池鼓包报废', items: '对讲机电池x5' },
]

// 6. 紧急出库: 出库单号、出库类型、是否借用、归还时间、申请人/申请单位、调出仓库、装备数量、出库日期、状态、备注
const emergencyData = [
  { id: 'JJ20260604001', type: 'emergency', isBorrow: '是', returnTime: '2026-06-11', applicant: '指挥中心', warehouse: 'A区主仓库', qty: 30, date: '2026-06-04', status: 'pending', remark: '突发事件应急处置', items: '防弹背心x10,头盔x10,防暴盾牌x10' },
  { id: 'JJ20260604002', type: 'emergency', isBorrow: '否', returnTime: '-', applicant: '特警大队', warehouse: 'A区主仓库', qty: 50, date: '2026-06-04', status: 'completed', remark: '反恐演练紧急调用', items: '破门锤x5,催泪弹x20,闪光弹x15,防毒面具x10' },
  { id: 'JJ20260603001', type: 'emergency', isBorrow: '是', returnTime: '2026-06-05', applicant: '交警支队', warehouse: 'B区仓库', qty: 20, date: '2026-06-03', status: 'pending', remark: '重大交通事故现场', items: '反光锥x20' },
  { id: 'JJ20260602001', type: 'emergency', isBorrow: '否', returnTime: '-', applicant: '消防联动', warehouse: 'C区仓库', qty: 10, date: '2026-06-02', status: 'completed', remark: '火灾救援支援', items: '强光手电x10' },
  { id: 'JJ20260601001', type: 'emergency', isBorrow: '是', returnTime: '2026-06-08', applicant: '治安大队', warehouse: 'A区主仓库', qty: 15, date: '2026-06-01', status: 'completed', remark: '大型活动安保', items: '对讲机x15' },
]

/* ─── Column definitions for each type ─── */

// 公共操作列
function ActionButtons({ status, onDetail, onConfirm, onEdit }: {
  status: string
  onDetail: () => void
  onConfirm: () => void
  onEdit: () => void
}) {
  if (status === 'pending') {
    return (
      <div className="flex items-center justify-center gap-1">
        <button
          onClick={onDetail}
          className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"
          title="详情"
        >
          <Eye size={13} /> 详情
        </button>
        <button
          onClick={onConfirm}
          className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#10B981] transition hover:bg-[#D1FAE5]"
          title="确认出库"
        >
          <CheckCircle size={13} /> 确认出库
        </button>
        <button
          onClick={onEdit}
          className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#F59E0B] transition hover:bg-[#FEF3C7]"
          title="编辑"
        >
          <Edit size={13} /> 编辑
        </button>
      </div>
    )
  }
  return (
    <div className="flex items-center justify-center gap-1">
      <button
        onClick={onDetail}
        className="flex h-7 items-center gap-1 rounded-md px-2 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"
        title="详情"
      >
        <Eye size={13} /> 详情
      </button>
    </div>
  )
}

// 1. 领用出库列
const issueColumns = [
  { key: 'id', title: '出库单号', width: '145px' },
  { key: 'type', title: '出库类型', width: '90px', render: (row: any) => <TypeBadge type={row.type} /> },
  { key: 'applicant', title: '申请人', width: '85px' },
  { key: 'isBorrow', title: '是否借用', width: '80px', render: (row: any) => row.isBorrow === '是' ? <Badge variant="warning">是</Badge> : <Badge variant="default">否</Badge> },
  { key: 'returnTime', title: '归还时间', width: '100px' },
  { key: 'warehouse', title: '调出仓库', width: '105px' },
  { key: 'qty', title: '装备数量', width: '75px', render: (row: any) => <span className="font-medium">{row.qty}</span> },
  { key: 'date', title: '出库日期', width: '100px' },
  { key: 'status', title: '状态', width: '85px', render: (row: any) => <StatusBadge status={row.status} /> },
  { key: 'remark', title: '备注', width: '130px' },
]

// 2. 配发出库列
const allocateColumns = [
  { key: 'id', title: '出库单号', width: '145px' },
  { key: 'type', title: '出库类型', width: '90px', render: (row: any) => <TypeBadge type={row.type} /> },
  { key: 'applicant', title: '申请人', width: '85px' },
  { key: 'warehouse', title: '调出仓库', width: '105px' },
  { key: 'allocateUnit', title: '配发单位', width: '100px' },
  { key: 'remainingQty', title: '剩余数量', width: '80px', render: (row: any) => <span className="font-medium text-[#1A56DB]">{row.remainingQty}</span> },
  { key: 'qty', title: '装备数量', width: '75px', render: (row: any) => <span className="font-medium">{row.qty}</span> },
  { key: 'date', title: '出库日期', width: '100px' },
  { key: 'status', title: '状态', width: '85px', render: (row: any) => <StatusBadge status={row.status} /> },
  { key: 'remark', title: '备注', width: '130px' },
]

// 3. 调拨出库列
const transferColumns = [
  { key: 'id', title: '出库单号', width: '145px' },
  { key: 'type', title: '出库类型', width: '90px', render: (row: any) => <TypeBadge type={row.type} /> },
  { key: 'fromUnit', title: '发物单位', width: '100px' },
  { key: 'toUnit', title: '收物单位', width: '100px' },
  { key: 'applicant', title: '申请人', width: '85px' },
  { key: 'warehouse', title: '调出仓库', width: '105px' },
  { key: 'qty', title: '装备数量', width: '75px', render: (row: any) => <span className="font-medium">{row.qty}</span> },
  { key: 'date', title: '出库日期', width: '100px' },
  { key: 'status', title: '状态', width: '85px', render: (row: any) => <StatusBadge status={row.status} /> },
  { key: 'remark', title: '备注', width: '130px' },
]

// 4. 报修出库列
const repairColumns = [
  { key: 'id', title: '出库单号', width: '145px' },
  { key: 'type', title: '出库类型', width: '90px', render: (row: any) => <TypeBadge type={row.type} /> },
  { key: 'applicant', title: '申请人', width: '85px' },
  { key: 'warehouse', title: '调出仓库', width: '105px' },
  { key: 'qty', title: '装备数量', width: '75px', render: (row: any) => <span className="font-medium">{row.qty}</span> },
  { key: 'date', title: '出库日期', width: '100px' },
  { key: 'status', title: '状态', width: '85px', render: (row: any) => <StatusBadge status={row.status} /> },
  { key: 'remark', title: '备注', width: '200px' },
]

// 5. 报废出库列 (同报修)
const scrapColumns = repairColumns

// 6. 紧急出库列
const emergencyColumns = [
  { key: 'id', title: '出库单号', width: '145px' },
  { key: 'type', title: '出库类型', width: '90px', render: (row: any) => <TypeBadge type={row.type} /> },
  { key: 'isBorrow', title: '是否借用', width: '80px', render: (row: any) => row.isBorrow === '是' ? <Badge variant="warning">是</Badge> : <Badge variant="default">否</Badge> },
  { key: 'returnTime', title: '归还时间', width: '100px' },
  { key: 'applicant', title: '申请单位', width: '95px' },
  { key: 'warehouse', title: '调出仓库', width: '105px' },
  { key: 'qty', title: '装备数量', width: '75px', render: (row: any) => <span className="font-medium">{row.qty}</span> },
  { key: 'date', title: '出库日期', width: '100px' },
  { key: 'status', title: '状态', width: '85px', render: (row: any) => <StatusBadge status={row.status} /> },
  { key: 'remark', title: '备注', width: '130px' },
]

/* ─── Filter fields ─── */
const filterFields = [
  { key: 'outboundNo', label: '出库单号', type: 'input' as const, placeholder: '请输入出库单号' },
  { key: 'type', label: '出库类型', type: 'select' as const, options: [
    { label: '个人领用出库', value: 'issue' },
    { label: '配发出库', value: 'allocate' },
    { label: '调拨出库', value: 'transfer' },
    { label: '报修出库', value: 'repair' },
    { label: '报废出库', value: 'scrap' },
    { label: '紧急出库', value: 'emergency' },
  ]},
  { key: 'dateStart', label: '出库日期（起）', type: 'date' as const },
  { key: 'dateEnd', label: '出库日期（止）', type: 'date' as const },
  { key: 'status', label: '状态', type: 'select' as const, options: [
    { label: '待出库', value: 'pending' },
    { label: '已出库', value: 'completed' },
  ]},
]

/* ─── Data & Columns map ─── */
const dataMap: Record<string, any[]> = {
  issue: issueData,
  allocate: allocateData,
  transfer: transferData,
  repair: repairData,
  scrap: scrapData,
  emergency: emergencyData,
}

const columnsMap: Record<string, any[]> = {
  issue: issueColumns,
  allocate: allocateColumns,
  transfer: transferColumns,
  repair: repairColumns,
  scrap: scrapColumns,
  emergency: emergencyColumns,
}

export default function OutboundPage() {
  const [activeType, setActiveType] = useState('issue')
  const [filterValues, setFilterValues] = useState<Record<string, string>>({})
  
  const handleFilterChange = (key: string, value: string) => {
    setFilterValues((prev) => ({ ...prev, [key]: value }))
  }
  const handleSearch = () => { /* mock */ }
  const handleReset = () => setFilterValues({})

  const currentData = dataMap[activeType] || []
  const currentColumns = columnsMap[activeType] || []

  return (
    <div>
      {/* Page header */}
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">出库管理</h1>
      </div>

      {/* Quick access type cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {outboundTypes.map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveType(t.key)}
            className={`group flex items-center gap-3 rounded-lg border p-4 shadow-sm transition hover:shadow-md ${
              activeType === t.key
                ? 'border-[#1A56DB] bg-[#E8F0FE] ring-1 ring-[#1A56DB]'
                : 'border-[#E5E7EB] bg-white'
            }`}
          >
            <div
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full"
              style={{ backgroundColor: t.bg }}
            >
              <span style={{ color: t.color }}>{t.icon}</span>
            </div>
            <div className="text-left">
              <p className={`text-sm font-semibold ${activeType === t.key ? 'text-[#1A56DB]' : 'text-[#1F2937]'}`}>
                {t.label}
              </p>
              <p className="text-xs text-[#6B7280]">{t.desc}</p>
            </div>
          </button>
        ))}
      </div>

      {/* Filter panel */}
      <FilterPanel
        fields={filterFields}
        values={filterValues}
        onChange={handleFilterChange}
        onSearch={handleSearch}
        onReset={handleReset}
      />

      {/* Outbound table */}
      <div className="mt-4">
        <DataTable
          title={`${outboundTypes.find(t => t.key === activeType)?.label}单据列表`}
          columns={currentColumns}
          data={currentData}
          pageSize={10}
          onAdd={undefined}
          onDelete={() => {}}
          onExport={() => {}}
          rowActions={(row: any) => (
            <ActionButtons
              status={row.status}
              onDetail={() => {}}
              onConfirm={() => {}}
              onEdit={() => {}}
            />
          )}
        />
      </div>

    </div>
  )
}

/* ═══════════════════════════════════════════
   新增个人领用出库表单弹窗
   ═══════════════════════════════════════════ */

interface IssueItem {
  id: string
  name: string
  qty: number
  unit: string
  remark: string
}

function NewIssueForm({ onClose }: { onClose: () => void }) {
  const [applicant, setApplicant] = useState('')
  const [isBorrow, setIsBorrow] = useState<'是' | '否'>('否')
  const [returnTime, setReturnTime] = useState('')
  const [warehouse, setWarehouse] = useState('')
  const [items, setItems] = useState<IssueItem[]>([{ id: '1', name: '', qty: 1, unit: '件', remark: '' }])
  const [remark, setRemark] = useState('')

  const addItem = () => setItems(prev => [...prev, { id: Date.now().toString(), name: '', qty: 1, unit: '件', remark: '' }])
  const removeItem = (id: string) => setItems(prev => prev.length > 1 ? prev.filter(i => i.id !== id) : prev)
  const updateItem = (id: string, patch: Partial<IssueItem>) => setItems(prev => prev.map(i => i.id === id ? { ...i, ...patch } : i))

  const handleSubmit = () => {
    if (!applicant.trim()) { alert('请填写申请人'); return }
    if (!warehouse) { alert('请选择调出仓库'); return }
    if (isBorrow === '是' && !returnTime) { alert('请填写归还时间'); return }
    if (items.some(i => !i.name.trim())) { alert('请填写所有装备名称'); return }
    alert(`个人领用出库单创建成功！\n申请人：${applicant}\n装备数：${items.reduce((s, i) => s + i.qty, 0)}件`)
    onClose()
  }

  const warehouseOptions = ['A区主仓库', 'B区仓库', 'C区仓库', 'D区仓库']

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex w-[640px] max-w-[95vw] flex-col rounded-xl bg-white shadow-2xl" style={{ maxHeight: '90vh' }}>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <h3 className="text-lg font-semibold text-[#1F2937]">新增个人领用出库单</h3>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
        </div>

        {/* Form */}
        <div className="flex-1 overflow-auto p-6 space-y-5">
          {/* 申请人 + 是否借用 */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="mb-1.5 block text-sm font-medium text-[#374151]">申请人 <span className="text-[#EF4444]">*</span></label>
              <input type="text" value={applicant} onChange={e => setApplicant(e.target.value)} placeholder="请输入申请人姓名" className="h-9 w-full rounded-lg border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
            </div>
            <div>
              <label className="mb-1.5 block text-sm font-medium text-[#374151]">是否借用</label>
              <div className="flex h-9 gap-2">
                {(['否', '是'] as const).map(opt => (
                  <button key={opt} onClick={() => setIsBorrow(opt)} className={cn('flex flex-1 items-center justify-center gap-1.5 rounded-lg border text-sm font-medium transition', isBorrow === opt ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]')}>
                    {isBorrow === opt && <CheckCircle size={14} />}{opt}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* 归还时间（借用时显示） */}
          {isBorrow === '是' && (
            <div>
              <label className="mb-1.5 block text-sm font-medium text-[#374151]">归还时间 <span className="text-[#EF4444]">*</span></label>
              <input type="date" value={returnTime} onChange={e => setReturnTime(e.target.value)} className="h-9 w-full rounded-lg border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]" />
            </div>
          )}

          {/* 调出仓库 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">调出仓库 <span className="text-[#EF4444]">*</span></label>
            <div className="grid grid-cols-4 gap-2">
              {warehouseOptions.map(w => (
                <button key={w} onClick={() => setWarehouse(w)} className={cn('h-9 rounded-lg border text-sm transition', warehouse === w ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB] font-medium' : 'border-[#D1D5DB] text-[#374151] hover:border-[#9CA3AF]')}>{w}</button>
              ))}
            </div>
          </div>

          {/* 装备明细 */}
          <div>
            <div className="mb-2 flex items-center justify-between">
              <label className="text-sm font-medium text-[#374151]">装备明细</label>
              <button onClick={addItem} className="inline-flex h-7 items-center gap-1 rounded-md border border-dashed border-[#D1D5DB] px-2 text-xs text-[#6B7280] hover:border-[#1A56DB] hover:text-[#1A56DB]"><Plus size={12} /> 添加装备</button>
            </div>
            <div className="rounded-lg border border-[#E5E7EB] overflow-hidden">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                    <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">序号</th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">装备名称 <span className="text-[#EF4444]">*</span></th>
                    <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">数量</th>
                    <th className="px-3 py-2 text-center text-[11px] font-semibold text-[#6B7280]">单位</th>
                    <th className="px-3 py-2 text-left text-[11px] font-semibold text-[#6B7280]">备注</th>
                    <th className="w-10 px-2 py-2"></th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((item, idx) => (
                    <tr key={item.id} className="border-b border-[#F3F4F6]">
                      <td className="px-3 py-2 text-xs text-[#6B7280]">{idx + 1}</td>
                      <td className="px-3 py-2">
                        <input type="text" value={item.name} onChange={e => updateItem(item.id, { name: e.target.value })} placeholder="装备名称" className="h-7 w-full rounded border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]" />
                      </td>
                      <td className="px-3 py-2">
                        <input type="number" min={1} value={item.qty} onChange={e => updateItem(item.id, { qty: Math.max(1, parseInt(e.target.value) || 1) })} className="h-7 w-16 rounded border border-[#D1D5DB] px-1 text-center text-xs outline-none focus:border-[#1A56DB]" />
                      </td>
                      <td className="px-3 py-2">
                        <select value={item.unit} onChange={e => updateItem(item.id, { unit: e.target.value })} className="h-7 rounded border border-[#D1D5DB] px-1 text-xs outline-none">
                          {['件', '台', '套', '个', '副', '把', '支', '块', '条', '瓶', '盒'].map(u => <option key={u} value={u}>{u}</option>)}
                        </select>
                      </td>
                      <td className="px-3 py-2">
                        <input type="text" value={item.remark} onChange={e => updateItem(item.id, { remark: e.target.value })} placeholder="备注" className="h-7 w-full rounded border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]" />
                      </td>
                      <td className="px-2 py-2">
                        <button onClick={() => removeItem(item.id)} className="flex h-6 w-6 items-center justify-center rounded text-[#6B7280] hover:bg-[#FEE2E2] hover:text-[#EF4444]"><Trash2 size={12} /></button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 备注 */}
          <div>
            <label className="mb-1.5 block text-sm font-medium text-[#374151]">备注</label>
            <textarea value={remark} onChange={e => setRemark(e.target.value)} rows={2} placeholder="填写备注信息..." className="w-full rounded-lg border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 border-t border-[#E5E7EB] px-6 py-4">
          <button onClick={onClose} className="h-9 rounded-lg border border-[#D1D5DB] bg-white px-5 text-sm text-[#374151]">取消</button>
          <button onClick={handleSubmit} className="h-9 rounded-lg bg-[#1A56DB] px-5 text-sm text-white">确认创建</button>
        </div>
      </div>
    </div>
  )
}
