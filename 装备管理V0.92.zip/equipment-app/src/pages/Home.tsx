import { useState, useEffect, useRef, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Package,
  Archive,
  Users,
  ArrowDownCircle,
  ArrowUpCircle,
  AlertTriangle,
  ClipboardCheck,
  ClipboardList,
  Target,
  Hand,
  Wrench,
  ArrowLeftRight,
  Settings as SettingsIcon,
  ChevronRight,
  Pin,
  Bell,
  Clipboard,
  Clock,
  CheckCircle2,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import StatCard from '@/components/StatCard'
import Badge from '@/components/Badge'

type CarouselTab = 'notice' | 'todo' | 'warning'
const CAROUSEL_TABS: CarouselTab[] = ['notice', 'todo', 'warning']
const TAB_LABELS: Record<CarouselTab, string> = {
  notice: '通知公告',
  todo: '待办事项',
  warning: '预警记录',
}
const TAB_ICONS: Record<CarouselTab, React.ReactNode> = {
  notice: <Bell size={16} />,
  todo: <Clipboard size={16} />,
  warning: <AlertTriangle size={16} />,
}

/* ─── Mock Data ─── */
const statCards = [
  { icon: <Package size={18} />, iconBg: '#E8F0FE', iconColor: '#1A56DB', title: '装备总数', value: 1256830, trend: 5.2, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/ledger' },
  { icon: <Archive size={18} />, iconBg: '#D1FAE5', iconColor: '#10B981', title: '在库数量', value: 486520, trend: 3.1, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/ledger' },
  { icon: <Users size={18} />, iconBg: '#E0E7FF', iconColor: '#8B5CF6', title: '在用数量', value: 698310, trend: 8.4, trendType: 'up' as const, trendColor: 'green' as const, link: '/personal/my-equipment' },
  { icon: <ArrowDownCircle size={18} />, iconBg: '#DBEAFE', iconColor: '#3B82F6', title: '本月入库', value: 12560, trend: 2.3, trendType: 'down' as const, trendColor: 'red' as const, link: '/warehouse/inbound' },
  { icon: <ArrowUpCircle size={18} />, iconBg: '#FEF3C7', iconColor: '#F59E0B', title: '本月出库', value: 9840, trend: 12.1, trendType: 'up' as const, trendColor: 'green' as const, link: '/warehouse/outbound' },
  { icon: <AlertTriangle size={18} />, iconBg: '#FEE2E2', iconColor: '#EF4444', title: '预警数量', value: 156, trendLabel: '含12条紧急', trendType: 'up' as const, trendColor: 'danger' as const, link: '/supervision/warning-records' },
]

const quickFunctions = [
  { icon: <ArrowDownCircle size={22} />, name: '装备入库', desc: '登记新入库装备信息', link: '/warehouse/inbound', color: '#1A56DB', bg: '#E8F0FE' },
  { icon: <ClipboardCheck size={22} />, name: '出库审批', desc: '审核装备出库申请', link: '/warehouse/outbound', color: '#10B981', bg: '#D1FAE5' },
  { icon: <ClipboardList size={22} />, name: '盘点管理', desc: '定期盘点库存装备', link: '/warehouse/inventory', color: '#8B5CF6', bg: '#E0E7FF' },
  { icon: <AlertTriangle size={22} />, name: '预警查看', desc: '查看装备预警信息', link: '/supervision/warning-records', color: '#EF4444', bg: '#FEE2E2' },
  { icon: <Target size={22} />, name: '配备标准', desc: '查看装备配备标准', link: '/basic-info/standard', color: '#F59E0B', bg: '#FEF3C7' },
  { icon: <Hand size={22} />, name: '领用申请', desc: '申请领用装备', link: '/personal/borrow', color: '#06B6D4', bg: '#CFFAFE' },
  { icon: <Wrench size={22} />, name: '报修登记', desc: '登记装备维修信息', link: '/personal/repair', color: '#EC4899', bg: '#FCE7F3' },
  { icon: <ArrowLeftRight size={22} />, name: '调拨申请', desc: '申请装备调拨转移', link: '/warehouse/transfer', color: '#84CC16', bg: '#ECFCCB' },
]

interface TodoItem {
  priority: '紧急' | '较急' | '常规'
  type: string
  title: string
  submitter: string
  time: string
  result?: '通过' | '驳回'
  processTime?: string
}

const todoPending: TodoItem[] = [
  { priority: '紧急', type: '调拨审批', title: '防弹背心紧急调拨申请', submitter: '王警官', time: '10分钟前' },
  { priority: '较急', type: '报废审批', title: '防弹背心报废申请-编号EQ2024001', submitter: '李警官', time: '1小时前' },
  { priority: '常规', type: '领用审批', title: '新警装备配发申请-张警官', submitter: '张警官', time: '2小时前' },
  { priority: '常规', type: '供应商审核', title: '某安防科技有限公司资质审核', submitter: '赵管理员', time: '3小时前' },
  { priority: '常规', type: '装备审核', title: '执法记录仪型号变更审核', submitter: '钱管理员', time: '5小时前' },
]

const todoDone: TodoItem[] = [
  { priority: '常规', type: '调拨审批', title: '防刺服调拨申请-城南分局', submitter: '孙警官', time: '1天前', result: '通过', processTime: '耗时2小时' },
  { priority: '常规', type: '领用审批', title: '手电装备领用申请-赵警官', submitter: '赵警官', time: '1天前', result: '通过', processTime: '耗时30分钟' },
  { priority: '紧急', type: '报废审批', title: '过期防弹头盔报废申请', submitter: '周警官', time: '2天前', result: '驳回', processTime: '耗时1小时' },
  { priority: '较急', type: '装备审核', title: '执法记录仪 firmware 升级审核', submitter: '吴管理员', time: '2天前', result: '通过', processTime: '耗时4小时' },
  { priority: '常规', type: '供应商审核', title: 'XX科技供应商资质年审', submitter: '郑管理员', time: '3天前', result: '通过', processTime: '耗时1天' },
]

const priorityColor: Record<string, string> = {
  紧急: '#EF4444',
  较急: '#F59E0B',
  常规: '#9CA3AF',
}

const priorityBgColor: Record<string, string> = {
  紧急: '#FEE2E2',
  较急: '#FEF3C7',
  常规: '#F3F4F6',
}

const notices = [
  { type: '政策法规', title: '关于加强警用装备管理的通知', publisher: '省公安厅警保部', time: '2026-06-01', pinned: true, read: false },
  { type: '业务通知', title: '关于开展装备盘点工作的通知', publisher: '装备管理处', time: '2026-05-28', pinned: false, read: false },
  { type: '系统公告', title: '系统升级维护通知（6月5日）', publisher: '系统管理员', time: '2026-05-25', pinned: false, read: true },
  { type: '业务通知', title: '第二季度装备采购计划提报', publisher: '采购中心', time: '2026-05-20', pinned: false, read: true },
  { type: '政策法规', title: '警用防弹衣配备标准更新说明', publisher: '标准化办公室', time: '2026-05-18', pinned: false, read: true },
]

interface WarningItem {
  level: '提醒' | '警告' | '紧急'
  title: string
  association: string
  time: string
  status: '待处理' | '处理中' | '已处理' | '已忽略'
  detail?: string
  days?: string
}

const warnings: WarningItem[] = [
  { level: '紧急', title: '防弹背心库存严重不足', association: 'A区仓库-防弹背心', time: '5分钟前', status: '待处理', detail: '库存低于安全线 20%', days: '紧急' },
  { level: '警告', title: '执法记录仪质保即将到期', association: 'B区仓库-执法记录仪', time: '2小时前', status: '处理中', detail: '剩余 3 天', days: '提醒' },
  { level: '提醒', title: '装备保养周期提醒', association: 'C区仓库-防刺服', time: '1天前', status: '待处理', detail: '保养期剩余 15 天', days: '普通' },
  { level: '警告', title: '某供应商资质即将到期', association: '供应商管理', time: '2天前', status: '已处理', detail: '资质剩余 7 天', days: '提醒' },
  { level: '紧急', title: '手电筒电池过期预警', association: 'D区仓库-手电筒', time: '3天前', status: '已忽略', detail: '已过期 2 天', days: '紧急' },
]

const levelDotColor: Record<string, string> = {
  提醒: '#3B82F6',
  警告: '#F59E0B',
  紧急: '#EF4444',
}

const warningCardBg: Record<string, string> = {
  紧急: 'bg-[#FEF2F2] border-[#FECACA]',
  警告: 'bg-[#FFFBEB] border-[#FDE68A]',
  提醒: 'bg-[#EFF6FF] border-[#BFDBFE]',
}

const statusBadgeVariant: Record<string, 'warning' | 'success' | 'danger' | 'default' | 'info'> = {
  待处理: 'warning',
  处理中: 'info',
  已处理: 'success',
  已忽略: 'default',
}

const statusBtnColor: Record<string, string> = {
  待处理: 'bg-[#1A56DB] hover:bg-[#153E7E]',
  处理中: 'bg-[#3B82F6] hover:bg-[#2563EB]',
  已处理: 'bg-[#10B981] hover:bg-[#059669]',
  已忽略: 'bg-[#EF4444] hover:bg-[#DC2626]',
}

/* ─── Carousel Card Sub-Components ─── */
function NoticePanel({ navigate }: { navigate: ReturnType<typeof useNavigate> }) {
  const [noticeTab, setNoticeTab] = useState('政策法规')
  const noticeTypes = ['政策法规', '业务通知', '系统公告']
  const filteredNotices = notices.filter((n) => n.type === noticeTab)

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <div className="flex gap-1 rounded-lg bg-[#F3F4F6] p-1">
          {noticeTypes.map((type) => (
            <button
              key={type}
              onClick={() => setNoticeTab(type)}
              className={cn(
                'rounded-md px-3 py-1.5 text-sm transition',
                noticeTab === type
                  ? 'bg-white font-medium text-[#1A56DB] shadow-sm'
                  : 'text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {type}
            </button>
          ))}
        </div>
        <button
          onClick={() => navigate('/forum')}
          className="flex items-center gap-0.5 text-[13px] text-[#1A56DB] transition hover:underline"
        >
          更多 <ChevronRight size={14} />
        </button>
      </div>
      <div className="max-h-[420px] space-y-2 overflow-y-auto">
        {filteredNotices.map((notice, i) => (
          <div
            key={i}
            className={cn(
              'group rounded-lg border border-[#E5E7EB] bg-white p-4 transition hover:shadow-sm',
              !notice.read && 'border-l-4 border-l-[#1A56DB]'
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <p className={cn('text-sm', notice.read ? 'text-[#374151]' : 'font-medium text-[#1F2937]')}>
                  {notice.pinned && (
                    <span className="mr-1.5 inline-flex items-center gap-0.5 rounded-full bg-[#FEF3C7] px-2 py-0.5 text-[11px] font-medium text-[#D97706]">
                      <Pin size={10} /> 置顶
                    </span>
                  )}
                  {notice.title}
                </p>
                <div className="mt-2 flex items-center gap-3">
                  <span className="rounded bg-[#F3F4F6] px-2 py-0.5 text-[11px] text-[#6B7280]">{notice.type}</span>
                  <span className="text-xs text-[#6B7280]">{notice.publisher}</span>
                  <span className="flex items-center gap-1 text-xs text-[#9CA3AF]">
                    <Clock size={11} />{notice.time}
                  </span>
                </div>
              </div>
              {!notice.read && <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-[#1A56DB]" />}
            </div>
          </div>
        ))}
        {filteredNotices.length === 0 && (
          <div className="py-8 text-center text-sm text-[#9CA3AF]">暂无该类公告</div>
        )}
      </div>
    </div>
  )
}

function TodoPanel() {
  const [todoTab, setTodoTab] = useState<'pending' | 'done'>('pending')
  const items = todoTab === 'pending' ? todoPending : todoDone

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <div className="flex gap-1 rounded-lg bg-[#F3F4F6] p-1">
          <button
            onClick={() => setTodoTab('pending')}
            className={cn(
              'rounded-md px-3 py-1.5 text-sm transition',
              todoTab === 'pending' ? 'bg-white font-medium text-[#1A56DB] shadow-sm' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            待办
          </button>
          <button
            onClick={() => setTodoTab('done')}
            className={cn(
              'rounded-md px-3 py-1.5 text-sm transition',
              todoTab === 'done' ? 'bg-white font-medium text-[#1A56DB] shadow-sm' : 'text-[#6B7280] hover:text-[#374151]'
            )}
          >
            已办
          </button>
        </div>
        <span className="text-xs text-[#9CA3AF]">共 {items.length} 条</span>
      </div>
      <div className="max-h-[420px] space-y-2 overflow-y-auto">
        {items.map((item, i) => (
          <div
            key={i}
            className="rounded-lg border border-[#E5E7EB] bg-white p-4 transition hover:shadow-sm"
            style={{ borderLeftWidth: 3, borderLeftColor: priorityColor[item.priority] }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span
                    className="rounded px-2 py-0.5 text-[11px] font-medium"
                    style={{ backgroundColor: priorityBgColor[item.priority], color: priorityColor[item.priority] }}
                  >
                    {item.priority}
                  </span>
                  <span className="rounded bg-[#E8F0FE] px-2 py-0.5 text-[11px] text-[#1A56DB]">{item.type}</span>
                </div>
                <p className="mt-2 text-sm font-medium text-[#1F2937]">{item.title}</p>
                <div className="mt-2 flex items-center gap-3">
                  <span className="text-xs text-[#6B7280]">{item.submitter}</span>
                  <span className="flex items-center gap-1 text-xs text-[#9CA3AF]">
                    <Clock size={11} />{item.time}
                  </span>
                </div>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-2">
                {todoTab === 'pending' ? (
                  <button className="rounded-md bg-[#1A56DB] px-4 py-1.5 text-xs text-white transition hover:bg-[#153E7E]">
                    处理
                  </button>
                ) : item.result ? (
                  <span className="flex items-center gap-1">
                    {item.result === '通过' ? (
                      <CheckCircle2 size={14} className="text-[#10B981]" />
                    ) : (
                      <AlertTriangle size={14} className="text-[#EF4444]" />
                    )}
                    <span className={cn('text-xs font-medium', item.result === '通过' ? 'text-[#10B981]' : 'text-[#EF4444]')}>{item.result}</span>
                  </span>
                ) : null}
                {item.processTime && (
                  <span className="text-[11px] text-[#9CA3AF]">{item.processTime}</span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function WarningPanel({ navigate }: { navigate: ReturnType<typeof useNavigate> }) {
  const [warningFilter, setWarningFilter] = useState('全部')
  const warningLevelOptions = ['全部', '提醒', '警告', '紧急']
  const filteredWarnings = warningFilter === '全部'
    ? warnings
    : warnings.filter((w) => w.level === warningFilter)

  return (
    <div>
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs text-[#9CA3AF]">按紧急度排序</span>
        <select
          value={warningFilter}
          onChange={(e) => setWarningFilter(e.target.value)}
          className="h-8 rounded-lg border border-[#D1D5DB] bg-white px-3 text-xs text-[#374151] outline-none"
        >
          {warningLevelOptions.map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      </div>
      <div className="max-h-[420px] space-y-3 overflow-y-auto">
        {filteredWarnings.map((w, i) => (
          <div
            key={i}
            className={cn(
              'rounded-xl border p-4 transition hover:shadow-md',
              warningCardBg[w.level]
            )}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span
                    className="h-2.5 w-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: levelDotColor[w.level] }}
                  />
                  <p className="text-sm font-semibold text-[#1F2937]">{w.title}</p>
                </div>
                <p className="mt-1.5 text-xs text-[#6B7280]">{w.association} · {w.time}</p>
                {w.detail && (
                  <p className="mt-1.5 text-xs font-medium" style={{ color: levelDotColor[w.level] }}>
                    {w.detail}
                  </p>
                )}
              </div>
              <div className="flex shrink-0 flex-col items-end gap-2">
                <Badge variant={w.level === '紧急' ? 'danger' : w.level === '警告' ? 'warning' : 'info'} className="text-[10px]">
                  {w.days}
                </Badge>
                <Badge variant={statusBadgeVariant[w.status] ?? 'default'} className="text-[10px]">{w.status}</Badge>
              </div>
            </div>
            <div className="mt-3 flex justify-end">
              <button
                onClick={() => navigate('/supervision/warning-records')}
                className={cn(
                  'rounded-lg px-4 py-1.5 text-xs text-white transition',
                  statusBtnColor[w.status]
                )}
              >
                {w.status === '已处理' ? '查看' : w.status === '已忽略' ? '详情' : '处理'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

/* ─── Page Component ─── */
export default function Home() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState<CarouselTab>('notice')
  const [isHovered, setIsHovered] = useState(false)
  const [fadeKey, setFadeKey] = useState(0)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // 徽标数字：通知未读、待办、预警待处理
  const badgeCounts: Record<CarouselTab, number> = {
    notice: notices.filter((n) => !n.read).length,
    todo: todoPending.length,
    warning: warnings.filter((w) => w.status === '待处理').length,
  }

  const switchToNextTab = useCallback(() => {
    setActiveTab((prev) => {
      const idx = CAROUSEL_TABS.indexOf(prev)
      const next = CAROUSEL_TABS[(idx + 1) % CAROUSEL_TABS.length]
      return next
    })
    setFadeKey((k) => k + 1)
  }, [])

  const handleTabClick = (tab: CarouselTab) => {
    setActiveTab(tab)
    setFadeKey((k) => k + 1)
  }

  // 自动轮播
  useEffect(() => {
    if (isHovered) {
      if (intervalRef.current) clearInterval(intervalRef.current)
      return
    }
    intervalRef.current = setInterval(switchToNextTab, 5000)
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [isHovered, switchToNextTab])

  return (
    <div className="space-y-6">
      {/* ── Row 1: Stat Cards ── */}
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6">
        {statCards.map((card, i) => (
          <StatCard
            key={i}
            icon={card.icon}
            iconBg={card.iconBg}
            iconColor={card.iconColor}
            title={card.title}
            value={card.value}
            trend={card.trend}
            trendType={card.trendType}
            trendLabel={card.trend ? '较上月' : undefined}
            trendColor={card.trendColor}
            delay={i * 80}
            onClick={() => navigate(card.link)}
          />
        ))}
      </div>

      {/* ── Row 2: Quick Functions (left) + Carousel Card (right) ── */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-5">
        {/* 常用功能入口 — 竖向列表 */}
        <div className="rounded-xl bg-white p-5 shadow-sm lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="text-base font-semibold text-[#1F2937]">常用功能</h3>
            <button className="flex h-8 w-8 items-center justify-center rounded-lg text-[#9CA3AF] transition hover:bg-[#F3F4F6] hover:text-[#1A56DB]">
              <SettingsIcon size={16} />
            </button>
          </div>
          <div className="space-y-1">
            {quickFunctions.map((fn, i) => (
              <button
                key={i}
                onClick={() => navigate(fn.link)}
                className="group flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left transition hover:bg-[#F9FAFB]"
              >
                <div
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition group-hover:scale-105"
                  style={{ backgroundColor: fn.bg }}
                >
                  <span style={{ color: fn.color }}>{fn.icon}</span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-[#1F2937]">{fn.name}</p>
                  <p className="text-[11px] text-[#9CA3AF]">{fn.desc}</p>
                </div>
                <ChevronRight size={16} className="shrink-0 text-[#D1D5DB] transition group-hover:text-[#1A56DB]" />
              </button>
            ))}
          </div>
        </div>

        {/* 三合一轮播卡片 */}
        <div
          className="rounded-xl bg-white p-5 shadow-sm lg:col-span-3"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* 顶部横向按钮页签 */}
          <div className="mb-4 flex gap-2">
            {CAROUSEL_TABS.map((tab) => {
              const count = badgeCounts[tab]
              const isActive = activeTab === tab
              return (
                <button
                  key={tab}
                  onClick={() => handleTabClick(tab)}
                  className={cn(
                    'relative flex flex-1 items-center justify-center gap-2 rounded-xl px-4 py-3 text-sm font-medium transition',
                    isActive
                      ? 'bg-[#1A56DB] text-white shadow-md'
                      : 'bg-[#F3F4F6] text-[#6B7280] hover:bg-[#E5E7EB] hover:text-[#374151]'
                  )}
                >
                  {TAB_ICONS[tab]}
                  {TAB_LABELS[tab]}
                  {count > 0 && (
                    <span className={cn(
                      'flex h-5 min-w-5 items-center justify-center rounded-full px-1 text-[11px] font-bold',
                      isActive ? 'bg-white text-[#1A56DB]' : 'bg-[#EF4444] text-white'
                    )}>
                      {count}
                    </span>
                  )}
                </button>
              )
            })}
          </div>

          {/* 内容区域 —— 淡入淡出 */}
          <div key={fadeKey} className="animate-fadeIn">
            {activeTab === 'notice' && <NoticePanel navigate={navigate} />}
            {activeTab === 'todo' && <TodoPanel />}
            {activeTab === 'warning' && <WarningPanel navigate={navigate} />}
          </div>
        </div>
      </div>
    </div>
  )
}
