import { GitBranch, Copy, Eye, Users } from 'lucide-react'

/* ── mock data ── */
const templates = [
  { id: 1, name: '标准调拨流程', scenario: '常规装备调拨审批', nodes: 6, usage: 328, description: '适用于装备在各级单位间的常规调拨，包含所队审批、县局审批、市局审批等多级审批节点', category: '调拨' },
  { id: 2, name: '快速领用流程', scenario: '简化领用审批', nodes: 4, usage: 567, description: '针对常用装备的快速领用场景，简化审批环节，提高领用效率', category: '领用' },
  { id: 3, name: '标准报修流程', scenario: '完整报修处理', nodes: 7, usage: 234, description: '覆盖装备报修全流程，从故障申报、维修评估到维修完成确认', category: '报修' },
  { id: 4, name: '紧急报废流程', scenario: '紧急装备报废', nodes: 5, usage: 89, description: '针对过期、损坏严重或技术淘汰装备的紧急报废处理', category: '报废' },
  { id: 5, name: '新警配发流程', scenario: '新警员装备配发', nodes: 6, usage: 156, description: '新入职警员的装备首次配发流程，包含资格审核和装备配置', category: '配发' },
  { id: 6, name: '供应商准入审核', scenario: '供应商资质审核', nodes: 8, usage: 78, description: '新供应商进入供应商库的完整审核流程', category: '审核' },
  { id: 7, name: '装备采购审批', scenario: '装备采购申请', nodes: 5, usage: 245, description: '装备采购申请的标准审批流程', category: '采购' },
  { id: 8, name: '装备借用流程', scenario: '临时借用装备', nodes: 4, usage: 189, description: '短期装备借用的简化流程，适用于培训、演练等场景', category: '借用' },
]

const categoryColors: Record<string, string> = {
  '调拨': '#1A56DB',
  '领用': '#10B981',
  '报修': '#F59E0B',
  '报废': '#EF4444',
  '配发': '#8B5CF6',
  '审核': '#06B6D4',
  '采购': '#EC4899',
  '借用': '#84CC16',
}

export default function WorkflowTemplatesPage() {
  return (
    <div>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">流程模板</h1>
          <p className="mt-1 text-sm text-[#6B7280]">流程模板库，基于模板快速创建新流程</p>
        </div>
      </div>

      {/* Template Cards Grid */}
      <div className="grid grid-cols-3 gap-4">
        {templates.map((t) => {
          const color = categoryColors[t.category] || '#6B7280'
          return (
            <div
              key={t.id}
              className="group rounded-lg border border-[#E5E7EB] bg-white p-5 transition hover:border-[#1A56DB] hover:shadow-md"
            >
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ background: color + '15' }}>
                    <GitBranch size={16} style={{ color }} />
                  </div>
                  <div>
                    <h3 className="text-sm font-semibold text-[#1F2937]">{t.name}</h3>
                    <span className="text-xs text-[#6B7280]">{t.scenario}</span>
                  </div>
                </div>
                <span className="rounded-full px-2 py-0.5 text-[10px] font-medium" style={{ background: color + '15', color }}>{t.category}</span>
              </div>

              {/* Description */}
              <p className="mt-3 text-xs leading-relaxed text-[#6B7280]">{t.description}</p>

              {/* Meta */}
              <div className="mt-4 flex items-center gap-4 text-xs text-[#6B7280]">
                <span className="flex items-center gap-1">
                  <GitBranch size={12} /> {t.nodes}个节点
                </span>
                <span className="flex items-center gap-1">
                  <Users size={12} /> 已使用{t.usage}次
                </span>
              </div>

              {/* Actions */}
              <div className="mt-4 flex items-center gap-2 border-t border-[#F3F4F6] pt-3">
                <button className="flex flex-1 items-center justify-center gap-1.5 rounded-md bg-[#1A56DB] px-3 py-2 text-xs font-medium text-white transition hover:bg-[#153E7E]">
                  <Copy size={12} /> 基于此创建
                </button>
                <button className="flex items-center gap-1.5 rounded-md border border-[#D1D5DB] px-3 py-2 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
                  <Eye size={12} /> 预览
                </button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
