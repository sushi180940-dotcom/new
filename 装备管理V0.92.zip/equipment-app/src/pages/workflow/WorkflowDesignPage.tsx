import { useRef, useState, useCallback } from 'react'
import { GitBranch, Plus, Play, UserCheck, Cog, Square, Trash2, ChevronRight, BarChart3, Save, ZoomIn, ZoomOut, Maximize } from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
interface FlowNode {
  id: string
  type: 'start' | 'approve' | 'condition' | 'auto' | 'end'
  title: string
  summary: string
  x: number
  y: number
  width: number
  height: number
}

interface FlowEdge {
  id: string
  from: string
  to: string
  label?: string
}

/* ── node config ── */
const nodeConfig: Record<string, { color: string; icon: React.ElementType; label: string }> = {
  start: { color: '#10B981', icon: Play, label: '开始' },
  approve: { color: '#1A56DB', icon: UserCheck, label: '审批' },
  condition: { color: '#F59E0B', icon: GitBranch, label: '条件' },
  auto: { color: '#8B5CF6', icon: Cog, label: '自动' },
  end: { color: '#EF4444', icon: Square, label: '结束' },
}

const flowTypes = [
  { key: 'transfer', name: '调拨流程', icon: GitBranch },
  { key: 'request', name: '领用流程', icon: UserCheck },
  { key: 'repair', name: '报修流程', icon: Cog },
  { key: 'scrap', name: '报废流程', icon: Trash2 },
  { key: 'allocate', name: '配发流程', icon: Plus },
  { key: 'supplier', name: '供应商审核', icon: UserCheck },
  { key: 'equipment', name: '装备审核', icon: UserCheck },
]

/* ── 调拨流程 mock data ── */
const defaultNodes: FlowNode[] = [
  { id: 'start1', type: 'start', title: '开始', summary: '发起调拨申请', x: 100, y: 200, width: 56, height: 56 },
  { id: 'app1', type: 'approve', title: '所队领导审批', summary: '审批人: 所队长', x: 250, y: 184, width: 140, height: 64 },
  { id: 'cond1', type: 'condition', title: '金额>10万?', summary: '条件判断', x: 500, y: 192, width: 80, height: 80 },
  { id: 'app2', type: 'approve', title: '县局领导审批', summary: '审批人: 县局长', x: 700, y: 120, width: 140, height: 64 },
  { id: 'cond2', type: 'condition', title: '金额>50万?', summary: '条件判断', x: 700, y: 320, width: 80, height: 80 },
  { id: 'auto1', type: 'auto', title: '自动生成调拨单', summary: '系统操作', x: 500, y: 400, width: 140, height: 56 },
  { id: 'app3', type: 'approve', title: '市局领导审批', summary: '审批人: 市局长', x: 920, y: 120, width: 140, height: 64 },
  { id: 'auto2', type: 'auto', title: '自动出库确认', summary: '系统操作', x: 920, y: 332, width: 140, height: 56 },
  { id: 'end1', type: 'end', title: '结束', summary: '流程结束', x: 1140, y: 312, width: 56, height: 56 },
]

const defaultEdges: FlowEdge[] = [
  { id: 'e1', from: 'start1', to: 'app1' },
  { id: 'e2', from: 'app1', to: 'cond1' },
  { id: 'e3', from: 'cond1', to: 'app2', label: '是' },
  { id: 'e4', from: 'cond1', to: 'auto1', label: '否' },
  { id: 'e5', from: 'app2', to: 'cond2' },
  { id: 'e6', from: 'cond2', to: 'app3', label: '是' },
  { id: 'e7', from: 'cond2', to: 'auto2', label: '否' },
  { id: 'e8', from: 'app3', to: 'auto2' },
  { id: 'e9', from: 'auto1', to: 'auto2' },
  { id: 'e10', from: 'auto2', to: 'end1' },
]

export default function WorkflowDesignPage() {
  const [activeFlow, setActiveFlow] = useState('transfer')
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const [nodes] = useState<FlowNode[]>(defaultNodes)
  const [edges] = useState<FlowEdge[]>(defaultEdges)
  const canvasRef = useRef<HTMLDivElement>(null)
  const [zoom, setZoom] = useState(1)

  // Canvas connection lines (SVG)
  const getEdgePath = useCallback((edge: FlowEdge) => {
    const from = nodes.find((n) => n.id === edge.from)
    const to = nodes.find((n) => n.id === edge.to)
    if (!from || !to) return ''

    // Calculate edge points (from right side of source to left side of target)
    const sx = from.x + from.width
    const sy = from.y + from.height / 2
    const tx = to.x
    const ty = to.y + to.height / 2

    const midX = (sx + tx) / 2
    return `M ${sx} ${sy} C ${midX} ${sy}, ${midX} ${ty}, ${tx} ${ty}`
  }, [nodes])

  const handleNodeClick = (nodeId: string) => {
    setSelectedNode(nodeId === selectedNode ? null : nodeId)
  }

  const selectedNodeData = nodes.find((n) => n.id === selectedNode)

  return (
    <div>
      {/* Page Header */}
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">流程设计</h1>
          <p className="mt-1 text-sm text-[#6B7280]">可视化流程设计与节点配置</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="flex items-center gap-2 rounded-md bg-[#1A56DB] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#153E7E]">
            <Plus size={16} /> 新建流程
          </button>
          <button className="flex items-center gap-2 rounded-md border border-[#D1D5DB] bg-white px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
            <Save size={16} /> 保存
          </button>
        </div>
      </div>

      <div className="flex gap-4" style={{ height: 'calc(100vh - 200px)' }}>
        {/* Left Panel: Flow Types */}
        <div className="w-[240px] shrink-0 rounded-lg border border-[#E5E7EB] bg-white p-3">
          <h3 className="mb-2 px-2 text-xs font-semibold uppercase text-[#9CA3AF]">流程类型</h3>
          {flowTypes.map((ft) => (
            <button
              key={ft.key}
              onClick={() => setActiveFlow(ft.key)}
              className={cn(
                'mb-1 flex w-full items-center gap-2 rounded-md px-3 py-2.5 text-sm transition',
                activeFlow === ft.key
                  ? 'bg-[#E8F0FE] text-[#1A56DB]'
                  : 'text-[#374151] hover:bg-[#F3F4F6]'
              )}
            >
              <ft.icon size={16} />
              <span className="flex-1 text-left">{ft.name}</span>
              <ChevronRight size={14} className="text-[#6B7280]" />
            </button>
          ))}

          <div className="mt-6 border-t border-[#E5E7EB] pt-4">
            <button className="mb-2 flex w-full items-center gap-2 px-2 py-1.5 text-sm text-[#6B7280] transition hover:text-[#1A56DB]">
              <BarChart3 size={16} /> 流程监控看板
            </button>
            <button className="flex w-full items-center gap-2 px-2 py-1.5 text-sm text-[#6B7280] transition hover:text-[#1A56DB]">
              <GitBranch size={16} /> 版本管理
            </button>
          </div>
        </div>

        {/* Right: Canvas */}
        <div className="relative flex-1 overflow-hidden rounded-lg border border-[#E5E7EB] bg-[#FAFBFC]">
          {/* Grid background */}
          <div
            className="absolute inset-0"
            style={{
              backgroundImage: 'radial-gradient(circle, #E5E7EB 1px, transparent 1px)',
              backgroundSize: '20px 20px',
            }}
          />

          {/* Canvas Controls */}
          <div className="absolute right-4 top-4 z-10 flex items-center gap-1 rounded-md border border-[#E5E7EB] bg-white p-1 shadow-sm">
            <button onClick={() => setZoom((z) => Math.min(z + 0.1, 2))} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6]">
              <ZoomIn size={14} />
            </button>
            <span className="px-1 text-xs text-[#6B7280]">{Math.round(zoom * 100)}%</span>
            <button onClick={() => setZoom((z) => Math.max(z - 0.1, 0.5))} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6]">
              <ZoomOut size={14} />
            </button>
            <button onClick={() => setZoom(1)} className="flex h-7 w-7 items-center justify-center rounded text-[#6B7280] hover:bg-[#F3F4F6]">
              <Maximize size={14} />
            </button>
          </div>

          {/* Node Palette */}
          <div className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-md border border-[#E5E7EB] bg-white p-2 shadow-sm">
            {Object.entries(nodeConfig).map(([key, cfg]) => {
              const Icon = cfg.icon
              return (
                <div
                  key={key}
                  className="flex cursor-grab items-center gap-1.5 rounded-md px-2.5 py-1.5 text-xs transition hover:bg-[#F3F4F6]"
                  title={cfg.label}
                >
                  <Icon size={14} style={{ color: cfg.color }} />
                  <span className="text-[#374151]">{cfg.label}</span>
                </div>
              )
            })}
          </div>

          {/* Canvas Content */}
          <div
            ref={canvasRef}
            className="relative h-full w-full"
            style={{ transform: `scale(${zoom})`, transformOrigin: 'top left' }}
          >
            {/* SVG Connections */}
            <svg className="absolute inset-0 h-full w-full" style={{ overflow: 'visible' }}>
              <defs>
                <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="8" refY="3" orient="auto">
                  <polygon points="0 0, 8 3, 0 6" fill="#6B7280" />
                </marker>
              </defs>
              {edges.map((edge) => (
                <g key={edge.id}>
                  <path
                    d={getEdgePath(edge)}
                    fill="none"
                    stroke="#6B7280"
                    strokeWidth="2"
                    markerEnd="url(#arrowhead)"
                  />
                  {edge.label && (
                    <text
                      x={(function () {
                        const from = nodes.find((n) => n.id === edge.from)
                        const to = nodes.find((n) => n.id === edge.to)
                        if (!from || !to) return 0
                        return (from.x + from.width + to.x) / 2
                      })()}
                      y={(function () {
                        const from = nodes.find((n) => n.id === edge.from)
                        const to = nodes.find((n) => n.id === edge.to)
                        if (!from || !to) return 0
                        return (from.y + from.height / 2 + to.y + to.height / 2) / 2 - 6
                      })()}
                      textAnchor="middle"
                      className="text-[11px]"
                      fill="#6B7280"
                    >
                      {edge.label}
                    </text>
                  )}
                </g>
              ))}
            </svg>

            {/* Nodes */}
            {nodes.map((node) => {
              const cfg = nodeConfig[node.type]
              const Icon = cfg.icon
              const isSelected = selectedNode === node.id

              return (
                <div
                  key={node.id}
                  onClick={() => handleNodeClick(node.id)}
                  className={cn('absolute cursor-pointer transition-shadow', isSelected && 'z-10')}
                  style={{
                    left: node.x,
                    top: node.y,
                    width: node.width,
                    height: node.height,
                    filter: isSelected ? `drop-shadow(0 0 4px ${cfg.color}40)` : 'none',
                  }}
                >
                  {/* Node Shape */}
                  {node.type === 'start' || node.type === 'end' ? (
                    <div
                      className="flex flex-col items-center justify-center rounded-full border-2"
                      style={{
                        width: node.width,
                        height: node.height,
                        borderColor: cfg.color,
                        background: isSelected ? cfg.color + '20' : '#fff',
                      }}
                    >
                      <Icon size={16} style={{ color: cfg.color }} />
                      <span className="mt-0.5 text-[10px] font-medium" style={{ color: cfg.color }}>{node.title}</span>
                    </div>
                  ) : node.type === 'condition' ? (
                    <div
                      className="flex flex-col items-center justify-center"
                      style={{
                        width: node.width,
                        height: node.height,
                        transform: 'rotate(45deg)',
                        border: `2px solid ${cfg.color}`,
                        borderRadius: 4,
                        background: isSelected ? cfg.color + '20' : '#fff',
                      }}
                    >
                      <div style={{ transform: 'rotate(-45deg)' }} className="flex flex-col items-center">
                        <Icon size={14} style={{ color: cfg.color }} />
                        <span className="mt-0.5 text-[9px] font-medium" style={{ color: cfg.color }}>{node.title}</span>
                      </div>
                    </div>
                  ) : (
                    <div
                      className="flex flex-col overflow-hidden rounded-lg border-2"
                      style={{
                        width: node.width,
                        height: node.height,
                        borderColor: cfg.color,
                        background: isSelected ? cfg.color + '10' : '#fff',
                      }}
                    >
                      {/* Header */}
                      <div className="flex items-center gap-1 px-2 py-1" style={{ background: cfg.color }}>
                        <Icon size={12} className="text-white" />
                        <span className="text-[11px] font-medium text-white">{node.title}</span>
                      </div>
                      {/* Body */}
                      <div className="flex flex-1 items-center px-2 py-1">
                        <span className="truncate text-[10px] text-[#6B7280]">{node.summary}</span>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>

          {/* Config Panel (right slide-out) */}
          {selectedNodeData && (
            <div className="absolute bottom-0 right-0 top-0 z-20 w-[360px] border-l border-[#E5E7EB] bg-white shadow-xl">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] p-4">
                <div className="flex items-center gap-2">
                  {(() => {
                    const cfg = nodeConfig[selectedNodeData.type]
                    const Icon = cfg.icon
                    return <><Icon size={16} style={{ color: cfg.color }} /><span className="text-sm font-semibold text-[#1F2937]">{selectedNodeData.title}</span></>
                  })()}
                </div>
                <button onClick={() => setSelectedNode(null)} className="text-[#6B7280] hover:text-[#EF4444]">
                  <Trash2 size={16} />
                </button>
              </div>
              <div className="p-4">
                <div className="space-y-4">
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">节点名称</label>
                    <input type="text" defaultValue={selectedNodeData.title} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                  </div>
                  <div>
                    <label className="mb-1 block text-xs font-medium text-[#374151]">配置摘要</label>
                    <input type="text" defaultValue={selectedNodeData.summary} className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                  </div>
                  {selectedNodeData.type === 'approve' && (
                    <>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">审批人选择</label>
                        <select className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                          <option>指定角色</option>
                          <option>指定人员</option>
                          <option>指定岗位</option>
                        </select>
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">处理时限</label>
                        <div className="flex gap-2">
                          <input type="number" defaultValue={24} className="w-20 rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                          <select className="rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                            <option>小时</option>
                            <option>天</option>
                          </select>
                        </div>
                      </div>
                    </>
                  )}
                  {selectedNodeData.type === 'condition' && (
                    <>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">条件字段</label>
                        <select className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                          <option>金额</option>
                          <option>数量</option>
                          <option>装备类型</option>
                        </select>
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">运算符</label>
                        <select className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                          <option>大于</option>
                          <option>小于</option>
                          <option>等于</option>
                        </select>
                      </div>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">条件值</label>
                        <input type="text" defaultValue="100000" className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
                      </div>
                    </>
                  )}
                  {selectedNodeData.type === 'auto' && (
                    <>
                      <div>
                        <label className="mb-1 block text-xs font-medium text-[#374151]">自动操作类型</label>
                        <select className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]">
                          <option>生成单据</option>
                          <option>发送通知</option>
                          <option>更新库存状态</option>
                        </select>
                      </div>
                    </>
                  )}
                  <div className="border-t border-[#E5E7EB] pt-4">
                    <button className="w-full rounded-md bg-[#EF4444] px-4 py-2 text-sm font-medium text-white transition hover:bg-[#DC2626]">
                      删除节点
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
