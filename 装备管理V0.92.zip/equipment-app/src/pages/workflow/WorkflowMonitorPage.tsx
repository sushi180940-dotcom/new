import { useEffect, useRef } from 'react'
import { Activity, CheckCircle, XCircle, Clock, AlertTriangle, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'
import * as echarts from 'echarts'

/* ── mock data ── */
const stats = [
  { label: '运行中', value: 128, icon: Activity, color: '#3B82F6', bgColor: '#DBEAFE' },
  { label: '已完成', value: 2856, icon: CheckCircle, color: '#10B981', bgColor: '#D1FAE5' },
  { label: '已驳回', value: 156, icon: XCircle, color: '#EF4444', bgColor: '#FEE2E2' },
  { label: '超时', value: 23, icon: Clock, color: '#F59E0B', bgColor: '#FEF3C7' },
]

const nodeEfficiency = [
  { node: '发起申请', avgTime: 0.5 },
  { node: '所队审批', avgTime: 4.2 },
  { node: '县局审批', avgTime: 8.6 },
  { node: '市局审批', avgTime: 16.3 },
  { node: '自动处理', avgTime: 0.1 },
  { node: '条件判断', avgTime: 0.2 },
  { node: '出库确认', avgTime: 2.1 },
  { node: '归档完成', avgTime: 0.8 },
]

const passRateMonths = ['8月', '9月', '10月', '11月', '12月', '1月', '2月', '3月']
const passRateData = [92.5, 93.1, 91.8, 94.2, 93.5, 95.1, 94.8, 95.6]

const backlogWarnings = [
  { node: '县局审批', count: 18, avgTime: 18.5, level: '严重' as const },
  { node: '市局审批', count: 12, avgTime: 28.2, level: '严重' as const },
  { node: '所队审批', count: 15, avgTime: 8.6, level: '一般' as const },
  { node: '出库确认', count: 8, avgTime: 4.2, level: '一般' as const },
  { node: '装备质检', count: 6, avgTime: 12.3, level: '注意' as const },
  { node: '供应商审核', count: 5, avgTime: 22.1, level: '注意' as const },
  { node: '归档完成', count: 3, avgTime: 2.5, level: '正常' as const },
  { node: '自动处理', count: 1, avgTime: 0.5, level: '正常' as const },
]

const levelVariant = (l: string) => l === '严重' ? 'danger' as const : l === '一般' ? 'warning' as const : l === '注意' ? 'info' as const : 'success' as const

export default function WorkflowMonitorPage() {
  const efficiencyRef = useRef<HTMLDivElement>(null)
  const passRateRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const cleanups: (() => void)[] = []

    if (efficiencyRef.current) {
      const chart = echarts.init(efficiencyRef.current)
      chart.setOption({
        title: { text: '各节点处理时效', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '平均处理时长(小时)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', formatter: '{b}: {c}小时' },
        grid: { left: 80, right: 40, top: 60, bottom: 30 },
        xAxis: { type: 'value', axisLabel: { fontSize: 10, color: '#6B7280' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        yAxis: { type: 'category', data: nodeEfficiency.map((n) => n.node).reverse(), axisLabel: { fontSize: 10, color: '#374151' } },
        series: [{
          type: 'bar', data: nodeEfficiency.map((n) => n.avgTime).reverse(), barWidth: '50%',
          itemStyle: {
            color: (p: any) => { const v = p.value; return v >= 24 ? '#EF4444' : v >= 8 ? '#F59E0B' : '#10B981' },
            borderRadius: [0, 4, 4, 0],
          },
          label: { show: true, position: 'right', fontSize: 10, formatter: '{c}h' },
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(efficiencyRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    if (passRateRef.current) {
      const chart = echarts.init(passRateRef.current)
      chart.setOption({
        title: { text: '流程通过率趋势', left: 0, top: 0, textStyle: { fontSize: 14, fontWeight: 'bold', color: '#1F2937' }, subtext: '月度通过率变化(%)', subtextStyle: { fontSize: 11, color: '#6B7280' } },
        tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
        grid: { left: 50, right: 20, top: 60, bottom: 30 },
        xAxis: { type: 'category', data: passRateMonths, axisLabel: { fontSize: 10, color: '#6B7280' } },
        yAxis: { type: 'value', min: 85, max: 100, axisLabel: { fontSize: 10, color: '#6B7280', formatter: '{value}%' }, splitLine: { lineStyle: { color: '#F3F4F6' } } },
        series: [{
          type: 'line', data: passRateData, smooth: true,
          lineStyle: { width: 2, color: '#1A56DB' }, itemStyle: { color: '#1A56DB' },
          areaStyle: { color: { type: 'linear', x: 0, y: 0, x2: 0, y2: 1, colorStops: [{ offset: 0, color: 'rgba(26,86,219,0.2)' }, { offset: 1, color: 'rgba(26,86,219,0)' }] } },
          symbol: 'circle', symbolSize: 6,
        }],
        animationDuration: 1000,
      } as echarts.EChartsOption)
      const ro = new ResizeObserver(() => chart.resize())
      ro.observe(passRateRef.current)
      cleanups.push(() => { ro.disconnect(); chart.dispose() })
    }

    return () => cleanups.forEach((fn) => fn())
  }, [])

  return (
    <div>
      {/* Page Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[#1F2937]">流程监控看板</h1>
          <p className="mt-1 text-sm text-[#6B7280]">流程实例监控、节点时效分析与待办预警</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="mb-6 grid grid-cols-4 gap-4">
        {stats.map((s, i) => {
          const Icon = s.icon
          return (
            <div key={i} className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[13px] text-[#6B7280]">{s.label}</span>
                  <div className="mt-1 text-[28px] font-bold text-[#1F2937]">{s.value.toLocaleString()}</div>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-full" style={{ background: s.bgColor }}>
                  <Icon size={22} style={{ color: s.color }} />
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {/* Charts Row */}
      <div className="mb-6 grid grid-cols-2 gap-4">
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={efficiencyRef} style={{ width: '100%', height: 340 }} />
        </div>
        <div className="rounded-lg bg-white p-5 shadow-md">
          <div ref={passRateRef} style={{ width: '100%', height: 340 }} />
        </div>
      </div>

      {/* Backlog Warning Table */}
      <div className="rounded-lg bg-white p-5 shadow-md">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle size={16} className="text-[#F59E0B]" />
            <h3 className="text-base font-semibold text-[#1F2937]">待办积压预警</h3>
          </div>
          <span className="text-xs text-[#6B7280]">共 {backlogWarnings.length} 个节点</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['节点名称', '积压数量', '平均处理时长', '预警级别', '状态', '操作'].map((h) => (
                  <th key={h} className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {backlogWarnings.map((row, i) => (
                <tr key={i} className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', i % 2 === 0 ? 'bg-white' : 'bg-[#FAFBFC]')}>
                  <td className="px-3 py-3 font-medium text-[#1F2937]">{row.node}</td>
                  <td className="px-3 py-3">
                    <span className={cn('font-bold', row.count >= 15 ? 'text-[#EF4444]' : row.count >= 5 ? 'text-[#F59E0B]' : 'text-[#10B981]')}>{row.count}件</span>
                  </td>
                  <td className="px-3 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-[#F3F4F6]">
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${Math.min(row.avgTime / 30 * 100, 100)}%`,
                            background: row.avgTime >= 24 ? '#EF4444' : row.avgTime >= 8 ? '#F59E0B' : '#10B981',
                          }}
                        />
                      </div>
                      <span className="text-[#374151]">{row.avgTime}h</span>
                    </div>
                  </td>
                  <td className="px-3 py-3"><Badge variant={levelVariant(row.level)}>{row.level}</Badge></td>
                  <td className="px-3 py-3">
                    <span className={cn('flex items-center gap-1 text-xs', row.count >= 15 ? 'text-[#EF4444]' : 'text-[#6B7280]')}>
                      {row.count >= 15 && <TrendingUp size={12} />}
                      {row.count >= 15 ? '积压严重' : row.count >= 5 ? '需关注' : '正常'}
                    </span>
                  </td>
                  <td className="px-3 py-3"><button className="text-xs text-[#1A56DB] hover:underline">查看详情</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
