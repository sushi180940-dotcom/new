import { useState } from 'react'
import {
  Zap,
  Mountain,
  Waves,
  Shield,
  Flame,
  FlaskConical,
  Car,
  Users,
  HelpCircle,
  ChevronRight,
  ChevronLeft,
  Check,
  Package,
  AlertTriangle,
  MapPin,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ── types ── */
interface Plan {
  id: string
  name: string
  icon: React.ReactNode
  iconColor: string
  iconBg: string
  scenario: string
  count: number
}

interface Equipment {
  id: number
  name: string
  model: string
  standardQty: number
  availableQty: number
  confirmQty: number
  location: string
  status: string
}

/* ── mock plans ── */
const plans: Plan[] = [
  { id: 'earthquake', name: '地震救援', icon: <Mountain size={28} />, iconColor: '#DC2626', iconBg: '#FEE2E2', scenario: '地震灾害现场救援', count: 156 },
  { id: 'flood', name: '洪涝抢险', icon: <Waves size={28} />, iconColor: '#2563EB', iconBg: '#DBEAFE', scenario: '洪涝灾害抢险救援', count: 128 },
  { id: 'counter-terror', name: '反恐处突', icon: <Shield size={28} />, iconColor: '#7C3AED', iconBg: '#EDE9FE', scenario: '反恐处突行动', count: 89 },
  { id: 'fire', name: '火灾处置', icon: <Flame size={28} />, iconColor: '#EA580C', iconBg: '#FFEDD5', scenario: '火灾现场处置', count: 67 },
  { id: 'chemical', name: '化学泄漏', icon: <FlaskConical size={28} />, iconColor: '#059669', iconBg: '#D1FAE5', scenario: '化学泄漏处置', count: 45 },
  { id: 'traffic', name: '交通事故', icon: <Car size={28} />, iconColor: '#D97706', iconBg: '#FEF3C7', scenario: '交通事故处置', count: 78 },
  { id: 'mass', name: '群体性事件', icon: <Users size={28} />, iconColor: '#0891B2', iconBg: '#CFFAFE', scenario: '群体性事件处置', count: 34 },
  { id: 'other', name: '其他', icon: <HelpCircle size={28} />, iconColor: '#6B7280', iconBg: '#F3F4F6', scenario: '自定义装备清单', count: 0 },
]

/* ── mock equipment per plan ── */
const planEquipmentMap: Record<string, Equipment[]> = {
  earthquake: [
    { id: 1, name: '液压破拆钳', model: 'PCQ-100', standardQty: 10, availableQty: 10, confirmQty: 10, location: 'A区-03架', status: '正常' },
    { id: 2, name: '生命探测仪', model: 'SM-T01', standardQty: 6, availableQty: 5, confirmQty: 5, location: 'A区-01架', status: '正常' },
    { id: 3, name: '救生绳索(100m)', model: 'JS-100', standardQty: 20, availableQty: 18, confirmQty: 18, location: 'B区-05架', status: '正常' },
    { id: 4, name: '强光手电', model: 'SD-LED500', standardQty: 50, availableQty: 50, confirmQty: 50, location: 'C区-02架', status: '正常' },
    { id: 5, name: '急救包', model: 'JJ-A01', standardQty: 30, availableQty: 28, confirmQty: 28, location: 'D区-01架', status: '正常' },
    { id: 6, name: '对讲机', model: 'DJ-8800', standardQty: 40, availableQty: 40, confirmQty: 40, location: 'C区-04架', status: '正常' },
  ],
  flood: [
    { id: 1, name: '救生衣', model: 'JSY-A01', standardQty: 50, availableQty: 48, confirmQty: 48, location: 'B区-01架', status: '正常' },
    { id: 2, name: '橡皮艇', model: 'XP-T4', standardQty: 8, availableQty: 8, confirmQty: 8, location: 'E区-01位', status: '正常' },
    { id: 3, name: '救生绳索(50m)', model: 'JS-50', standardQty: 20, availableQty: 20, confirmQty: 20, location: 'B区-05架', status: '正常' },
    { id: 4, name: '抽水泵', model: 'CB-3KW', standardQty: 6, availableQty: 5, confirmQty: 5, location: 'E区-03位', status: '正常' },
    { id: 5, name: '应急照明灯', model: 'YZM-LED500', standardQty: 15, availableQty: 15, confirmQty: 15, location: 'C区-02架', status: '正常' },
    { id: 6, name: '对讲机', model: 'DJ-8800', standardQty: 30, availableQty: 30, confirmQty: 30, location: 'C区-04架', status: '正常' },
  ],
  'counter-terror': [
    { id: 1, name: '防弹背心', model: 'FDY-2R-01', standardQty: 20, availableQty: 20, confirmQty: 20, location: 'A区-06架', status: '正常' },
    { id: 2, name: '防弹头盔', model: 'FDK-01', standardQty: 20, availableQty: 20, confirmQty: 20, location: 'A区-06架', status: '正常' },
    { id: 3, name: '防爆盾牌', model: 'FBDP-5', standardQty: 15, availableQty: 15, confirmQty: 15, location: 'A区-04架', status: '正常' },
    { id: 4, name: '防暴叉', model: 'FB-C01', standardQty: 10, availableQty: 10, confirmQty: 10, location: 'A区-04架', status: '正常' },
    { id: 5, name: '催泪喷射器', model: 'OC-500', standardQty: 24, availableQty: 24, confirmQty: 24, location: 'F区-01架', status: '正常' },
  ],
  fire: [
    { id: 1, name: '灭火器', model: 'MFZ-ABC4', standardQty: 30, availableQty: 30, confirmQty: 30, location: 'G区-01架', status: '正常' },
    { id: 2, name: '消防水带', model: 'XF-SD65', standardQty: 20, availableQty: 20, confirmQty: 20, location: 'G区-02架', status: '正常' },
    { id: 3, name: '防火服', model: 'FH-F01', standardQty: 12, availableQty: 12, confirmQty: 12, location: 'G区-03架', status: '正常' },
    { id: 4, name: '防毒面具', model: 'MF-11B', standardQty: 5, availableQty: 5, confirmQty: 5, location: 'G区-04架', status: '正常' },
  ],
}

/* ── step indicator ── */
function StepIndicator({ currentStep }: { currentStep: number }) {
  const steps = ['选择方案', '确认清单', '出库完成']
  return (
    <div className="mb-6 flex items-center justify-center gap-2">
      {steps.map((s, i) => (
        <div key={s} className="flex items-center gap-2">
          <div className="flex flex-col items-center">
            <div
              className={cn(
                'flex h-8 w-8 items-center justify-center rounded-full text-sm font-semibold',
                i < currentStep && 'bg-[#10B981] text-white',
                i === currentStep && 'bg-[#DC2626] text-white',
                i > currentStep && 'border-2 border-[#D1D5DB] text-[#9CA3AF]'
              )}
            >
              {i < currentStep ? <Check size={16} /> : i + 1}
            </div>
            <span className={cn('mt-1 text-xs', i === currentStep ? 'font-medium text-[#DC2626]' : 'text-[#6B7280]')}>{s}</span>
          </div>
          {i < steps.length - 1 && (
            <div className={cn('mb-4 h-0.5 w-16', i < currentStep ? 'bg-[#10B981]' : 'bg-[#E5E7EB]')} />
          )}
        </div>
      ))}
    </div>
  )
}

/* ── main component ── */
export default function EmergencyQuickOutboundPage() {
  const [step, setStep] = useState(1)
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null)
  const [equipmentList, setEquipmentList] = useState<Equipment[]>([])
  const [showSuccess, setShowSuccess] = useState(false)

  const handleSelectPlan = (plan: Plan) => {
    setSelectedPlan(plan)
    const list = planEquipmentMap[plan.id] || []
    setEquipmentList(list.map((e) => ({ ...e })))
  }

  const handleConfirmQtyChange = (id: number, val: number) => {
    setEquipmentList((prev) =>
      prev.map((e) => (e.id === id ? { ...e, confirmQty: Math.max(0, Math.min(val, e.availableQty)) } : e))
    )
  }

  const totalConfirmQty = equipmentList.reduce((sum, e) => sum + e.confirmQty, 0)

  const handleNext = () => {
    if (step === 1 && selectedPlan) setStep(2)
    else if (step === 2) {
      setStep(3)
      setShowSuccess(true)
    }
  }

  const handleBack = () => {
    if (step === 2) {
      setStep(1)
      setSelectedPlan(null)
    }
  }

  const handleReset = () => {
    setStep(1)
    setSelectedPlan(null)
    setEquipmentList([])
    setShowSuccess(false)
  }

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      {/* ── Emergency Banner ── */}
      <div
        className="relative flex h-10 items-center justify-center gap-2 overflow-hidden rounded-lg text-sm font-semibold text-white"
        style={{
          background: 'linear-gradient(90deg, #DC2626, #B91C1C)',
          backgroundSize: '200% 100%',
          animation: 'shimmer 3s linear infinite',
        }}
      >
        <Zap size={18} className="text-white" />
        <span
          className="inline-block h-2.5 w-2.5 rounded-full bg-white"
          style={{ animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' }}
        />
        应急装备管理专区 — 一键快速出库
      </div>

      {/* ── Page Title ── */}
      <div className="text-center">
        <h1 className="text-2xl font-semibold text-[#1F2937]">应急一键出库</h1>
        <p className="mt-1 text-sm text-[#6B7280]">选择应急响应方案，快速完成装备出库</p>
      </div>

      {/* ── Step Indicator ── */}
      <StepIndicator currentStep={step - 1} />

      {/* ── Step 1: Plan Selection ── */}
      {step === 1 && (
        <div>
          <h2 className="mb-4 text-lg font-semibold text-[#1F2937]">选择应急响应方案</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {plans.map((plan) => (
              <button
                key={plan.id}
                onClick={() => handleSelectPlan(plan)}
                className={cn(
                  'relative flex flex-col items-center rounded-lg border-2 bg-white p-5 text-center transition-all duration-150 hover:shadow-lg',
                  selectedPlan?.id === plan.id
                    ? 'border-[#DC2626] shadow-lg'
                    : 'border-[#E5E7EB] hover:border-[#DC2626] hover:scale-[1.02]'
                )}
              >
                {selectedPlan?.id === plan.id && (
                  <div className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full bg-[#DC2626]">
                    <Check size={14} className="text-white" />
                  </div>
                )}
                <div
                  className="flex h-14 w-14 items-center justify-center rounded-full"
                  style={{ backgroundColor: plan.iconBg, color: plan.iconColor }}
                >
                  {plan.icon}
                </div>
                <h3 className="mt-3 text-base font-semibold text-[#1F2937]">{plan.name}</h3>
                <p className="mt-1 text-xs text-[#6B7280]">{plan.scenario}</p>
                {plan.count > 0 && (
                  <div className="mt-2 inline-flex items-center gap-1 rounded-full bg-[#E8F0FE] px-2.5 py-0.5 text-xs text-[#1A56DB]">
                    <Package size={12} />
                    包含 {plan.count} 件装备
                  </div>
                )}
              </button>
            ))}
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={handleNext}
              disabled={!selectedPlan}
              className={cn(
                'inline-flex h-11 items-center gap-2 rounded-lg px-6 text-sm font-medium transition',
                selectedPlan
                  ? 'bg-[#DC2626] text-white hover:bg-[#B91C1C]'
                  : 'cursor-not-allowed bg-[#E5E7EB] text-[#9CA3AF]'
              )}
            >
              下一步：确认清单
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      )}

      {/* ── Step 2: Confirm List ── */}
      {step === 2 && selectedPlan && (
        <div>
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold text-[#1F2937]">
                {selectedPlan.name} — 装备清单确认
              </h2>
              <p className="mt-1 text-sm text-[#6B7280]">{selectedPlan.scenario}</p>
            </div>
            <div className="rounded-lg bg-[#E8F0FE] px-4 py-2 text-sm text-[#1A56DB]">
              合计：<span className="text-lg font-bold">{totalConfirmQty}</span> 件
            </div>
          </div>

          <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备名称</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">型号</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">标准数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">可用数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">确认数量</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">存放位置</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
                </tr>
              </thead>
              <tbody>
                {equipmentList.map((eq) => (
                  <tr
                    key={eq.id}
                    className={cn(
                      'border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]',
                      eq.confirmQty > eq.availableQty && 'bg-[#FEE2E2]'
                    )}
                  >
                    <td className="px-4 py-3 text-[13px] font-medium text-[#1F2937]">{eq.name}</td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">{eq.model}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{eq.standardQty}</td>
                    <td className="px-4 py-3 text-[13px] text-[#374151]">{eq.availableQty}</td>
                    <td className="px-4 py-3">
                      <input
                        type="number"
                        min={0}
                        max={eq.availableQty}
                        value={eq.confirmQty}
                        onChange={(e) => handleConfirmQtyChange(eq.id, parseInt(e.target.value) || 0)}
                        className={cn(
                          'h-8 w-20 rounded-md border px-2 text-center text-sm outline-none transition',
                          eq.confirmQty > eq.availableQty
                            ? 'border-[#EF4444] bg-[#FEE2E2]'
                            : 'border-[#D1D5DB] focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10'
                        )}
                      />
                      {eq.confirmQty > eq.availableQty && (
                        <span className="ml-2 text-xs text-[#EF4444]">
                          <AlertTriangle size={12} className="inline" /> 超出可用
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-[13px] text-[#6B7280]">
                      <span className="inline-flex items-center gap-1">
                        <MapPin size={12} />
                        {eq.location}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-flex items-center gap-1 rounded-full bg-[#D1FAE5] px-2 py-0.5 text-xs text-[#059669]">
                        <Check size={12} />
                        {eq.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="mt-6 flex justify-between">
            <button
              onClick={handleBack}
              className="inline-flex h-11 items-center gap-2 rounded-lg border border-[#E5E7EB] bg-white px-5 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
            >
              <ChevronLeft size={16} />
              上一步
            </button>
            <button
              onClick={handleNext}
              disabled={equipmentList.some((e) => e.confirmQty > e.availableQty) || totalConfirmQty === 0}
              className={cn(
                'inline-flex h-12 items-center gap-2 rounded-lg px-8 text-base font-medium text-white transition hover:scale-105',
                equipmentList.some((e) => e.confirmQty > e.availableQty) || totalConfirmQty === 0
                  ? 'cursor-not-allowed bg-[#9CA3AF]'
                  : 'bg-[#DC2626] shadow-lg hover:bg-[#B91C1C]'
              )}
              style={
                !(equipmentList.some((e) => e.confirmQty > e.availableQty) || totalConfirmQty === 0)
                  ? { animation: 'pulse-shadow 2s infinite' }
                  : undefined
              }
            >
              <Zap size={18} />
              确认出库
            </button>
          </div>
        </div>
      )}

      {/* ── Step 3: Success ── */}
      {step === 3 && showSuccess && (
        <div className="py-12 text-center">
          <div
            className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-[#D1FAE5]"
            style={{ animation: 'scale-in 0.3s ease-out' }}
          >
            <Check size={40} className="text-[#10B981]" />
          </div>
          <h2 className="mt-4 text-2xl font-semibold text-[#1F2937]">应急出库成功</h2>
          <p className="mt-2 text-sm text-[#6B7280]">
            出库单号：<span className="font-mono font-medium text-[#1A56DB]">CK{Date.now().toString().slice(-12)}</span>
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-lg bg-[#E8F0FE] px-4 py-2 text-sm text-[#1A56DB]">
            <Package size={16} />
            共出库 <span className="text-lg font-bold">{totalConfirmQty}</span> 件装备
          </div>
          <div className="mt-8 flex justify-center gap-4">
            <button
              onClick={handleReset}
              className="inline-flex h-11 items-center gap-2 rounded-lg border border-[#E5E7EB] bg-white px-6 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
            >
              返回重新选择
            </button>
            <a
              href="#/emergency/overview"
              className="inline-flex h-11 items-center gap-2 rounded-lg bg-[#1A56DB] px-6 text-sm text-white transition hover:bg-[#153E7E]"
            >
              返回应急概览
            </a>
          </div>
        </div>
      )}

      {/* ── Styles ── */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
        @keyframes pulse-shadow {
          0%, 100% { box-shadow: 0 10px 15px rgba(220, 38, 38, 0.3); }
          50% { box-shadow: 0 10px 25px rgba(220, 38, 38, 0.5); }
        }
        @keyframes scale-in {
          0% { transform: scale(0); opacity: 0; }
          80% { transform: scale(1.1); opacity: 1; }
          100% { transform: scale(1); opacity: 1; }
        }
      `}</style>
    </div>
  )
}
