import {
  Shield,
  Zap,
  PackageCheck,
  Package,
  BookOpen,
  Truck,
  Wrench,
  Hammer,
  Trash2,
  ArrowLeftRight,
  Send,
  ClipboardCheck,
  DoorOpen,
  AlertTriangle,
  Clock,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import DataTable from '@/components/DataTable'

/* ── pulse dot ── */
function PulseDot({ color = '#DC2626' }: { color?: string }) {
  return (
    <span
      className="inline-block h-2.5 w-2.5 rounded-full"
      style={{
        backgroundColor: color,
        animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }}
    />
  )
}

/* ── emergency level badge ── */
function EmergencyLevelBadge({ level }: { level: string }) {
  const configs: Record<string, { bg: string; text: string; pulse?: boolean }> = {
    '一级战备': { bg: 'bg-[#DC2626]', text: 'text-white', pulse: true },
    '二级战备': { bg: 'bg-[#F59E0B]', text: 'text-white' },
    '三级战备': { bg: 'bg-[#FBBF24]', text: '[#1F2937]' },
  }
  const c = configs[level] || { bg: 'bg-[#6B7280]', text: 'text-white' }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        c.bg,
        c.text
      )}
    >
      {c.pulse && <PulseDot color="#fff" />}
      {level}
    </span>
  )
}

/* ── event type tag ── */
function EventTag({ type }: { type: string }) {
  const colors: Record<string, { bg: string; text: string }> = {
    '自然灾害': { bg: 'bg-[#FEE2E2]', text: 'text-[#DC2626]' },
    '事故灾难': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
    '公共卫生': { bg: 'bg-[#D1FAE5]', text: 'text-[#059669]' },
    '社会安全': { bg: 'bg-[#DBEAFE]', text: 'text-[#2563EB]' },
    '恐怖袭击': { bg: 'bg-[#FEE2E2]', text: 'text-[#991B1B]' },
    '重大安保': { bg: 'bg-[#E8F0FE]', text: 'text-[#1A56DB]' },
  }
  const c = colors[type] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span className={cn('mr-1 inline-block rounded-full px-2 py-0.5 text-[11px]', c.bg, c.text)}>
      {type}
    </span>
  )
}

/* ── readiness status ── */
function ReadinessStatus({ status }: { status: string }) {
  const configs: Record<string, { bg: string; text: string; pulse?: boolean }> = {
    '战备在库': { bg: 'bg-[#DC2626]', text: 'text-white', pulse: true },
    '应急出动': { bg: 'bg-[#F59E0B]', text: 'text-white', pulse: true },
    '检测中': { bg: 'bg-[#3B82F6]', text: 'text-white' },
    '维护中': { bg: 'bg-[#6B7280]', text: 'text-white' },
  }
  const c = configs[status] || { bg: 'bg-[#F3F4F6]', text: 'text-[#6B7280]' }
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        c.bg,
        c.text
      )}
    >
      {c.pulse && <PulseDot color="#fff" />}
      {status}
    </span>
  )
}

/* ── 功能按钮卡片 ── */
const actionButtons = [
  { label: '入库管理', icon: PackageCheck, href: '#/warehouse/inbound', color: '#1A56DB', bg: '#EFF6FF' },
  { label: '装备领用', icon: Package, href: '#/warehouse/pickup', color: '#059669', bg: '#D1FAE5' },
  { label: '仓库台账', icon: BookOpen, href: '#/warehouse/ledger', color: '#7C3AED', bg: '#EDE9FE' },
  { label: '出库管理', icon: Truck, href: '#/warehouse/outbound', color: '#D97706', bg: '#FEF3C7' },
  { label: '保养登记', icon: Wrench, href: '#/warehouse/maintenance', color: '#2563EB', bg: '#DBEAFE' },
  { label: '报修管理', icon: Hammer, href: '#/warehouse/repair', color: '#DC2626', bg: '#FEE2E2' },
  { label: '报废管理', icon: Trash2, href: '#/warehouse/scrap', color: '#6B7280', bg: '#F3F4F6' },
  { label: '调拨管理', icon: ArrowLeftRight, href: '#/warehouse/transfer', color: '#0891B2', bg: '#CFFAFE' },
  { label: '配发管理', icon: Send, href: '#/warehouse/allocation', color: '#059669', bg: '#D1FAE5' },
  { label: '盘点管理', icon: ClipboardCheck, href: '#/warehouse/inventory', color: '#7C3AED', bg: '#EDE9FE' },
  { label: '通道记录', icon: DoorOpen, href: '#/warehouse/channel', color: '#2563EB', bg: '#DBEAFE' },
]

/* ── mock data ── */
const equipmentData = [
  { id: 1, name: '防弹背心', model: 'FDY-2R-01', warehouse: '应急仓库A', level: '一级战备', responseTime: '15分钟', events: ['恐怖袭击', '重大安保'], lastCheck: '2026-05-01', nextCheck: '2026-07-01', status: '战备在库' },
  { id: 2, name: '防毒面具', model: 'MF-11B', warehouse: '应急仓库B', level: '一级战备', responseTime: '10分钟', events: ['公共卫生', '事故灾难'], lastCheck: '2026-04-20', nextCheck: '2026-06-18', status: '战备在库' },
  { id: 3, name: '破拆工具组', model: 'PC-200', warehouse: '应急仓库A', level: '二级战备', responseTime: '20分钟', events: ['自然灾害', '事故灾难'], lastCheck: '2026-05-10', nextCheck: '2026-06-10', status: '检测中' },
  { id: 4, name: '应急照明灯', model: 'YZM-LED500', warehouse: '应急仓库C', level: '三级战备', responseTime: '30分钟', events: ['自然灾害', '事故灾难'], lastCheck: '2026-03-15', nextCheck: '2026-06-12', status: '战备在库' },
  { id: 5, name: '救生绳索', model: 'JS-100M', warehouse: '应急仓库B', level: '二级战备', responseTime: '20分钟', events: ['自然灾害'], lastCheck: '2026-05-20', nextCheck: '2026-08-20', status: '维护中' },
  { id: 6, name: '防爆盾牌', model: 'FBDP-5', warehouse: '应急仓库A', level: '一级战备', responseTime: '10分钟', events: ['恐怖袭击', '社会安全'], lastCheck: '2026-04-10', nextCheck: '2026-06-08', status: '战备在库' },
  { id: 7, name: '急救医疗包', model: 'JJ-YL01', warehouse: '应急仓库C', level: '二级战备', responseTime: '15分钟', events: ['公共卫生', '事故灾难'], lastCheck: '2026-05-25', nextCheck: '2026-06-25', status: '检测中' },
  { id: 8, name: '对讲机(应急)', model: 'DJ-8800E', warehouse: '应急仓库A', level: '一级战备', responseTime: '5分钟', events: ['重大安保', '社会安全'], lastCheck: '2026-05-28', nextCheck: '2026-06-28', status: '战备在库' },
]

/* ── main component ── */
export default function EmergencyOverviewPage() {
  const columns = [
    { key: 'name', title: '装备名称' },
    { key: 'model', title: '型号' },
    { key: 'warehouse', title: '所属仓库' },
    {
      key: 'level',
      title: '应急等级',
      render: (row: typeof equipmentData[0]) => <EmergencyLevelBadge level={row.level} />,
    },
    {
      key: 'responseTime',
      title: '响应时间',
      render: (row: typeof equipmentData[0]) => (
        <span className="inline-flex items-center gap-1 text-[13px]">
          <Clock size={13} className="text-[#6B7280]" />
          {row.responseTime}
        </span>
      ),
    },
    {
      key: 'events',
      title: '适用突发事件',
      render: (row: typeof equipmentData[0]) => (
        <div className="flex flex-wrap gap-y-1">
          {row.events.map((e) => <EventTag key={e} type={e} />)}
        </div>
      ),
    },
    { key: 'lastCheck', title: '上次检测' },
    {
      key: 'nextCheck',
      title: '下次检测',
      render: (row: typeof equipmentData[0]) => {
        const daysLeft = Math.ceil((new Date(row.nextCheck).getTime() - Date.now()) / 86400000)
        return (
          <span className={cn(
            'text-[13px]',
            daysLeft < 3 ? 'font-semibold text-[#DC2626]' : daysLeft < 7 ? 'text-[#D97706]' : 'text-[#374151]'
          )}>
            {daysLeft < 3 && <AlertTriangle size={13} className="mr-1 inline text-[#DC2626]" />}
            {row.nextCheck}
          </span>
        )
      },
    },
    {
      key: 'status',
      title: '战备状态',
      render: (row: typeof equipmentData[0]) => <ReadinessStatus status={row.status} />,
    },
  ]

  return (
    <div className="space-y-6">
      {/* ── Emergency Banner ── */}
      <div
        className="relative flex h-10 items-center justify-center gap-2 overflow-hidden rounded-lg text-sm font-semibold text-white"
        style={{
          background: 'linear-gradient(90deg, #DC2626, #B91C1C)',
          backgroundSize: '200% 100%',
          animation: 'shimmer 3s linear infinite',
        }}
      >
        <Zap size={18} className="text-white" />
        <PulseDot color="#fff" />
        应急装备管理专区
      </div>

      {/* ── Page Title ── */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-[#1F2937]">应急仓库管理</h1>
      </div>

      {/* ── 功能按钮区 ── */}
      <div className="rounded-lg border border-[#E5E7EB] bg-white p-5 shadow-md">
        <div className="mb-3 flex items-center gap-2 text-sm font-medium text-[#6B7280]">
          <Shield size={16} className="text-[#1A56DB]" />
          <span>功能导航</span>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {actionButtons.map((btn) => {
            const Icon = btn.icon
            return (
              <a
                key={btn.label}
                href={btn.href}
                className="group flex flex-col items-center gap-2 rounded-lg border border-[#E5E7EB] p-4 transition-all hover:shadow-md active:scale-[0.98]"
                style={{ '--hover-bg': btn.bg, '--hover-color': btn.color } as React.CSSProperties}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = btn.bg
                  e.currentTarget.style.borderColor = btn.color + '40'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = ''
                  e.currentTarget.style.borderColor = ''
                }}
              >
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-full transition-transform group-hover:scale-110"
                  style={{ backgroundColor: btn.bg, color: btn.color }}
                >
                  <Icon size={20} />
                </div>
                <span className="text-[13px] font-medium text-[#374151] group-hover:text-[#1F2937]">
                  {btn.label}
                </span>
              </a>
            )
          })}
        </div>
      </div>

      {/* ── Equipment Table ── */}
      <DataTable
        columns={columns}
        data={equipmentData}
        title="应急装备清单"
        pageSize={10}
      />

      {/* ── Custom keyframes (scoped style) ── */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
      `}</style>
    </div>
  )
}
