import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  Package, UserCheck, BookOpen, ArrowRightLeft,
  Wrench, Trash2, Settings, ClipboardList,
  DoorOpen, Search, RotateCw, SlidersHorizontal,
  Zap, Eye,
} from 'lucide-react'
import { cn } from '@/lib/utils'

/* ─── Types ─── */
interface EmergencyItem {
  id: string
  category: string
  name: string
  spec: string
  qty: number
  unit: string
  location: string
  produceDate: string
  validDate: string
  maintainDate: string
  unitPrice: number
  totalPrice: number
  supplier: string
  status: 'normal' | 'expired' | 'maintenance' | 'low'
  lastOpTime: string
}

/* ─── Navigation Cards ─── */
const navCards = [
  { key: 'inbound', label: '入库管理', icon: <Package size={22} />, color: '#1A56DB', bg: '#EFF6FF', border: '#DBEAFE', path: '/warehouse/inbound' },
  { key: 'pickup', label: '装备领用', icon: <UserCheck size={22} />, color: '#10B981', bg: '#ECFDF5', border: '#D1FAE5', path: '/warehouse/pickup' },
  { key: 'ledger', label: '仓库台账', icon: <BookOpen size={22} />, color: '#8B5CF6', bg: '#F5F3FF', border: '#EDE9FE', path: '/warehouse/ledger' },
  { key: 'outbound', label: '出库管理', icon: <ArrowRightLeft size={22} />, color: '#F59E0B', bg: '#FFFBEB', border: '#FEF3C7', path: '/warehouse/outbound' },
  { key: 'maintenance', label: '保养登记', icon: <Wrench size={22} />, color: '#1A56DB', bg: '#EFF6FF', border: '#DBEAFE', path: '/warehouse/maintenance' },
  { key: 'repair', label: '报修管理', icon: <Settings size={22} />, color: '#EF4444', bg: '#FEF2F2', border: '#FEE2E2', path: '/warehouse/repair' },
  { key: 'scrap', label: '报废管理', icon: <Trash2 size={22} />, color: '#6B7280', bg: '#F3F4F6', border: '#E5E7EB', path: '/warehouse/scrap' },
  { key: 'transfer', label: '调拨管理', icon: <SlidersHorizontal size={22} />, color: '#06B6D4', bg: '#ECFEFF', border: '#CFFAFE', path: '/warehouse/transfer' },
  { key: 'allocation', label: '配发管理', icon: <Package size={22} />, color: '#10B981', bg: '#ECFDF5', border: '#D1FAE5', path: '/warehouse/allocation' },
  { key: 'inventory-check', label: '盘点管理', icon: <ClipboardList size={22} />, color: '#8B5CF6', bg: '#F5F3FF', border: '#EDE9FE', path: '/warehouse/inventory' },
  { key: 'channel', label: '通道记录', icon: <DoorOpen size={22} />, color: '#1A56DB', bg: '#EFF6FF', border: '#DBEAFE', path: '/warehouse/channel' },
]

/* ─── Mock Data ─── */
const emergencyData: EmergencyItem[] = [
  { id: 'E001', category: '防护装备', name: '防弹背心', spec: 'FDY-3R-S/三级/软质/凯夫拉', qty: 120, unit: '件', location: '应急库A区-01-03', produceDate: '2024-03-15', validDate: '2029-03-14', maintainDate: '2026-09-15', unitPrice: 3200, totalPrice: 384000, supplier: 'AA防弹材料有限公司', status: 'normal', lastOpTime: '2026-06-10 14:32' },
  { id: 'E002', category: '防护装备', name: '防弹头盔', spec: 'M-88/二级/导轨式/含面罩', qty: 85, unit: '顶', location: '应急库A区-01-05', produceDate: '2024-05-20', validDate: '2029-05-19', maintainDate: '2026-11-20', unitPrice: 1800, totalPrice: 153000, supplier: 'BB安防设备有限公司', status: 'normal', lastOpTime: '2026-06-08 09:15' },
  { id: 'E003', category: '通信装备', name: '对讲机', spec: 'GP-338D+/数字/防爆', qty: 60, unit: '台', location: '应急库B区-02-01', produceDate: '2023-08-10', validDate: '2028-08-09', maintainDate: '2026-08-10', unitPrice: 4500, totalPrice: 270000, supplier: 'CC通信技术有限公司', status: 'maintenance', lastOpTime: '2026-06-05 16:48' },
  { id: 'E004', category: '照明装备', name: '强光手电', spec: 'TX-8000/800流明/防水', qty: 200, unit: '支', location: '应急库B区-02-04', produceDate: '2024-01-08', validDate: '2027-01-07', maintainDate: '2026-07-08', unitPrice: 280, totalPrice: 56000, supplier: 'DD照明器材厂', status: 'normal', lastOpTime: '2026-06-11 11:22' },
  { id: 'E005', category: '救援装备', name: '急救包', spec: 'JJ-III型/野战/含止血带', qty: 50, unit: '个', location: '应急库C区-03-02', produceDate: '2025-02-18', validDate: '2027-02-17', maintainDate: '2026-08-18', unitPrice: 350, totalPrice: 17500, supplier: 'EE医疗器械公司', status: 'expired', lastOpTime: '2026-06-01 08:30' },
  { id: 'E006', category: '防暴装备', name: '防暴盾牌', spec: 'FBDP-5/长方形/PC材质', qty: 40, unit: '面', location: '应急库A区-01-08', produceDate: '2024-06-22', validDate: '2029-06-21', maintainDate: '2026-12-22', unitPrice: 650, totalPrice: 26000, supplier: 'FF警用装备厂', status: 'normal', lastOpTime: '2026-06-09 15:45' },
  { id: 'E007', category: '侦测装备', name: '生命探测仪', spec: 'DOL-1/雷达式/穿墙', qty: 8, unit: '台', location: '应急库D区-04-01', produceDate: '2023-11-05', validDate: '2028-11-04', maintainDate: '2026-11-05', unitPrice: 120000, totalPrice: 960000, supplier: 'GG电子科技集团', status: 'normal', lastOpTime: '2026-06-07 10:18' },
  { id: 'E008', category: '照明装备', name: '便携式发电机', spec: 'EF-2000i/2KW/静音', qty: 12, unit: '台', location: '应急库D区-04-03', produceDate: '2024-04-12', validDate: '2029-04-11', maintainDate: '2026-10-12', unitPrice: 8500, totalPrice: 102000, supplier: 'HH动力设备有限公司', status: 'low', lastOpTime: '2026-06-04 13:55' },
  { id: 'E009', category: '防护装备', name: '防毒面具', spec: 'MF-22/全面罩/滤毒罐', qty: 100, unit: '个', location: '应急库A区-01-10', produceDate: '2025-01-20', validDate: '2030-01-19', maintainDate: '2026-07-20', unitPrice: 420, totalPrice: 42000, supplier: 'II特种防护用品厂', status: 'normal', lastOpTime: '2026-06-11 09:40' },
  { id: 'E010', category: '通信装备', name: '卫星电话', spec: 'Iridium-9575/全球覆盖', qty: 6, unit: '台', location: '应急库B区-02-06', produceDate: '2024-09-01', validDate: '2029-08-31', maintainDate: '2026-12-01', unitPrice: 15000, totalPrice: 90000, supplier: 'JJ卫星通信公司', status: 'normal', lastOpTime: '2026-06-06 17:22' },
  { id: 'E011', category: '救援装备', name: '液压破拆工具组', spec: 'BE-DJ-6/双输出/含扩张钳', qty: 4, unit: '套', location: '应急库C区-03-05', produceDate: '2023-07-15', validDate: '2028-07-14', maintainDate: '2026-07-15', unitPrice: 68000, totalPrice: 272000, supplier: 'KK消防救援设备厂', status: 'maintenance', lastOpTime: '2026-05-28 14:10' },
  { id: 'E012', category: '侦测装备', name: '热成像仪', spec: 'FLIR-E75/384x288/WiFi', qty: 10, unit: '台', location: '应急库D区-04-02', produceDate: '2024-02-28', validDate: '2029-02-27', maintainDate: '2026-08-28', unitPrice: 28000, totalPrice: 280000, supplier: 'LL光电仪器公司', status: 'normal', lastOpTime: '2026-06-10 16:30' },
]

/* ─── Status badge ─── */
function StatusBadge({ status }: { status: EmergencyItem['status'] }) {
  const config: Record<string, { label: string; cls: string }> = {
    normal: { label: '正常', cls: 'bg-[#ECFDF5] text-[#059669]' },
    expired: { label: '已过期', cls: 'bg-[#FEE2E2] text-[#EF4444]' },
    maintenance: { label: '待保养', cls: 'bg-[#FEF3C7] text-[#D97706]' },
    low: { label: '库存不足', cls: 'bg-[#DBEAFE] text-[#1A56DB]' },
  }
  const c = config[status] || config.normal
  return <span className={cn('inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium', c.cls)}>{c.label}</span>
}

/* ─── Main Page ─── */
export default function EmergencyManagePage() {
  const navigate = useNavigate()
  const [searchText, setSearchText] = useState('')
  const [catFilter, setCatFilter] = useState('全部')
  const [statusFilter, setStatusFilter] = useState('全部')
  const [currentPage, setCurrentPage] = useState(1)
  const pageSize = 10

  const categories = ['全部', ...Array.from(new Set(emergencyData.map(d => d.category)))]
  const statuses = ['全部', '正常', '已过期', '待保养', '库存不足']

  const filtered = emergencyData.filter(d => {
    const matchText = !searchText || d.name.includes(searchText) || d.spec.includes(searchText) || d.supplier.includes(searchText)
    const matchCat = catFilter === '全部' || d.category === catFilter
    const matchStatus = statusFilter === '全部' ||
      (statusFilter === '正常' && d.status === 'normal') ||
      (statusFilter === '已过期' && d.status === 'expired') ||
      (statusFilter === '待保养' && d.status === 'maintenance') ||
      (statusFilter === '库存不足' && d.status === 'low')
    return matchText && matchCat && matchStatus
  })

  const totalPages = Math.ceil(filtered.length / pageSize)
  const paged = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize)

  return (
    <div className="space-y-4">
      {/* Red Banner */}
      <div className="flex items-center justify-center rounded-lg bg-[#DC2626] py-2.5 text-sm font-medium text-white">
        <Zap size={16} className="mr-1.5" /><span className="mr-1">●</span>应急装备管理专区
      </div>

      <h1 className="text-xl font-semibold text-[#1F2937]">应急仓库管理</h1>

      {/* Function Navigation */}
      <div className="rounded-xl border border-[#E5E7EB] bg-white p-5">
        <div className="mb-4 flex items-center gap-2 text-sm font-medium text-[#374151]">
          <Zap size={14} className="text-[#9CA3AF]" />功能导航
        </div>
        <div className="grid grid-cols-6 gap-3">
          {navCards.map(card => (
            <button key={card.key} onClick={() => navigate(card.path)} className="group flex flex-col items-center gap-2.5 rounded-xl border border-[#E5E7EB] bg-white py-5 transition hover:shadow-md hover:border-[#D1D5DB]">
              <div className="flex h-11 w-11 items-center justify-center rounded-full transition-transform group-hover:scale-110" style={{ backgroundColor: card.bg, border: `1px solid ${card.border}` }}>
                <span style={{ color: card.color }}>{card.icon}</span>
              </div>
              <span className="text-xs text-[#374151]">{card.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Equipment List */}
      <div className="rounded-xl border border-[#E5E7EB] bg-white p-5">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-[#1F2937]">应急装备清单</h2>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              <input value={searchText} onChange={e => { setSearchText(e.target.value); setCurrentPage(1) }} placeholder="搜索..." className="h-8 w-48 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-xs outline-none focus:border-[#1A56DB]" />
            </div>
            <select value={catFilter} onChange={e => { setCatFilter(e.target.value); setCurrentPage(1) }} className="h-8 rounded-md border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]">{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
            <select value={statusFilter} onChange={e => { setStatusFilter(e.target.value); setCurrentPage(1) }} className="h-8 rounded-md border border-[#D1D5DB] px-2 text-xs outline-none focus:border-[#1A56DB]">{statuses.map(s => <option key={s} value={s}>{s}</option>)}</select>
            <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#D1D5DB] text-[#6B7280] hover:bg-[#F3F4F6]"><RotateCw size={13} /></button>
            <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#D1D5DB] text-[#6B7280] hover:bg-[#F3F4F6]"><SlidersHorizontal size={13} /></button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                {['物资类别', '装备名称', '规格型号', '数量', '单位', '存储位置', '生产日期', '有效期', '保养期', '单价', '总价', '供应商', '状态', '最后操作时间', '操作'].map((h, i) => (
                  <th key={i} className="whitespace-nowrap px-3 py-2.5 text-left text-[11px] font-semibold text-[#6B7280]">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paged.map(row => (
                <tr key={row.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="whitespace-nowrap px-3 py-2 text-[#374151]">{row.category}</td>
                  <td className="whitespace-nowrap px-3 py-2 font-medium text-[#1F2937]">{row.name}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.spec}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right font-medium text-[#374151]">{row.qty}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.unit}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.location}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.produceDate}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.validDate}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.maintainDate}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right text-[#1A56DB]">¥{row.unitPrice.toLocaleString()}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right font-medium text-[#374151]">¥{row.totalPrice.toLocaleString()}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#6B7280]">{row.supplier}</td>
                  <td className="whitespace-nowrap px-3 py-2"><StatusBadge status={row.status} /></td>
                  <td className="whitespace-nowrap px-3 py-2 text-[#9CA3AF]">{row.lastOpTime}</td>
                  <td className="whitespace-nowrap px-3 py-2">
                    <button className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs text-[#1A56DB] transition hover:bg-[#E8F0FE]"><Eye size={12} /> 查看</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {totalPages > 1 && (
          <div className="mt-4 flex items-center justify-end gap-1">
            <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">上一页</button>
            {Array.from({ length: totalPages }, (_, i) => <button key={i} onClick={() => setCurrentPage(i + 1)} className={cn('h-7 w-7 rounded text-xs', currentPage === i + 1 ? 'bg-[#1A56DB] text-white' : 'border border-[#D1D5DB] text-[#374151]')}>{i + 1}</button>)}
            <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="h-7 rounded border border-[#D1D5DB] px-3 text-xs disabled:opacity-50">下一页</button>
          </div>
        )}
      </div>
    </div>
  )
}
