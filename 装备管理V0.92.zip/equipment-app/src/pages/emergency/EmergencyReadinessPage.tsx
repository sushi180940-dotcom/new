import { useState, useEffect, useRef } from 'react'
import {
  Shield,
  Search,
  Wrench,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  Check,
  MapPin,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import Badge from '@/components/Badge'

/* ── count-up helper ── */
function useCountUp(target: number, duration = 800, delay = 0) {
  const [count, setCount] = useState(0)
  const rafRef = useRef<number>(0)
  const startRef = useRef<number>(0)

  useEffect(() => {
    const timer = setTimeout(() => {
      startRef.current = 0
      const step = (ts: number) => {
        if (!startRef.current) startRef.current = ts
        const p = Math.min((ts - startRef.current) / duration, 1)
        const eased = 1 - Math.pow(1 - p, 3)
        setCount(Math.floor(eased * target))
        if (p < 1) rafRef.current = requestAnimationFrame(step)
      }
      rafRef.current = requestAnimationFrame(step)
    }, delay)
    return () => {
      clearTimeout(timer)
      cancelAnimationFrame(rafRef.current)
    }
  }, [target, duration, delay])

  return count
}

/* ── pulse dot ── */
function PulseDot({ color = '#DC2626' }: { color?: string }) {
  return (
    <span
      className="inline-block h-2 w-2 rounded-full"
      style={{
        backgroundColor: color,
        animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      }}
    />
  )
}

/* ── readiness status badge ── */
function ReadinessBadge({ status }: { status: string }) {
  const configs: Record<string, { variant: 'success' | 'warning' | 'danger' | 'info' | 'default'; label: string }> = {
    '战备在库': { variant: 'success', label: '战备在库' },
    '合格': { variant: 'success', label: '合格' },
    '检测中': { variant: 'info', label: '检测中' },
    '即将到期': { variant: 'warning', label: '即将到期' },
    '已过期': { variant: 'danger', label: '已过期' },
    '维护中': { variant: 'default', label: '维护中' },
    '不合格': { variant: 'danger', label: '不合格' },
  }
  const c = configs[status] || { variant: 'default', label: status }
  return <Badge variant={c.variant}>{c.label}</Badge>
}

/* ── check result buttons ── */
function CheckResultButtons({
  status,
  onPass,
  onFail,
}: {
  status: string
  onPass: () => void
  onFail: () => void
}) {
  if (status === '合格' || status === '不合格') {
    return (
      <span className={cn('text-xs font-medium', status === '合格' ? 'text-[#10B981]' : 'text-[#EF4444]')}>
        {status === '合格' && <CheckCircle size={14} className="mr-1 inline" />}
        {status === '不合格' && <XCircle size={14} className="mr-1 inline" />}
        {status}
      </span>
    )
  }
  return (
    <div className="flex items-center gap-2">
      <button
        onClick={onPass}
        className="inline-flex h-7 items-center gap-1 rounded-md bg-[#10B981] px-2.5 text-xs text-white transition hover:bg-[#059669]"
      >
        <Check size={12} />
        合格
      </button>
      <button
        onClick={onFail}
        className="inline-flex h-7 items-center gap-1 rounded-md bg-[#EF4444] px-2.5 text-xs text-white transition hover:bg-[#DC2626]"
      >
        <XCircle size={12} />
        不合格
      </button>
    </div>
  )
}

/* ── mock data ── */
interface CheckRecord {
  id: number
  name: string
  model: string
  code: string
  warehouse: string
  lastCheck: string
  nextCheck: string
  status: string
  result: string
}

const initialRecords: CheckRecord[] = [
  { id: 1, name: '防弹背心', model: 'FDY-2R-01', code: 'EQ2024001', warehouse: '应急仓库A', lastCheck: '2026-05-01', nextCheck: '2026-07-01', status: '战备在库', result: '待检查' },
  { id: 2, name: '防毒面具', model: 'MF-11B', code: 'EQ2024002', warehouse: '应急仓库B', lastCheck: '2026-04-20', nextCheck: '2026-06-18', status: '即将到期', result: '待检查' },
  { id: 3, name: '破拆工具组', model: 'PC-200', code: 'EQ2024003', warehouse: '应急仓库A', lastCheck: '2026-05-10', nextCheck: '2026-06-10', status: '检测中', result: '待检查' },
  { id: 4, name: '应急照明灯', model: 'YZM-LED500', code: 'EQ2024004', warehouse: '应急仓库C', lastCheck: '2026-03-15', nextCheck: '2026-06-12', status: '即将到期', result: '待检查' },
  { id: 5, name: '救生绳索', model: 'JS-100M', code: 'EQ2024005', warehouse: '应急仓库B', lastCheck: '2026-05-20', nextCheck: '2026-06-05', status: '已过期', result: '待检查' },
  { id: 6, name: '防爆盾牌', model: 'FBDP-5', code: 'EQ2024006', warehouse: '应急仓库A', lastCheck: '2026-04-10', nextCheck: '2026-08-10', status: '战备在库', result: '合格' },
  { id: 7, name: '急救医疗包', model: 'JJ-YL01', code: 'EQ2024007', warehouse: '应急仓库C', lastCheck: '2026-05-25', nextCheck: '2026-06-25', status: '检测中', result: '待检查' },
  { id: 8, name: '对讲机(应急)', model: 'DJ-8800E', code: 'EQ2024008', warehouse: '应急仓库A', lastCheck: '2026-05-28', nextCheck: '2026-06-28', status: '战备在库', result: '待检查' },
  { id: 9, name: '强光手电', model: 'SD-LED500', code: 'EQ2024009', warehouse: '应急仓库B', lastCheck: '2026-04-15', nextCheck: '2026-06-08', status: '即将到期', result: '待检查' },
  { id: 10, name: '灭火毯', model: 'MT-1.2x1.8', code: 'EQ2024010', warehouse: '应急仓库C', lastCheck: '2026-02-01', nextCheck: '2026-06-01', status: '已过期', result: '不合格' },
]

/* ── date helper ── */
function getDaysUntil(dateStr: string): number {
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86400000)
}

function getRowHighlight(nextCheck: string): string {
  const days = getDaysUntil(nextCheck)
  if (days < 3) return 'bg-[#FEE2E2]'
  if (days < 7) return 'bg-[#FEF3C7]'
  return ''
}

/* ── main component ── */
export default function EmergencyReadinessPage() {
  const [records, setRecords] = useState<CheckRecord[]>(initialRecords)
  const [searchText, setSearchText] = useState('')

  const goodCount = useCountUp(2560, 800, 0)
  const checkCount = useCountUp(45, 800, 100)
  const maintainCount = useCountUp(23, 800, 200)
  const faultCount = useCountUp(8, 800, 300)

  const setResult = (id: number, result: string) => {
    setRecords((prev) => prev.map((r) => (r.id === id ? { ...r, result } : r)))
  }

  const filteredRecords = records.filter(
    (r) =>
      !searchText ||
      r.name.includes(searchText) ||
      r.model.includes(searchText) ||
      r.code.includes(searchText)
  )

  return (
    <div className="space-y-6">
      {/* ── Emergency Banner ── */}
      <div
        className="relative flex h-10 items-center justify-center gap-2 overflow-hidden rounded-lg text-sm font-semibold text-white"
        style={{
          background: 'linear-gradient(90deg, #DC2626, #B91C1C)',
          backgroundSize: '200% 100%',
          animation: 'shimmer 3s linear infinite',
        }}
      >
        <AlertTriangle size={18} className="text-white" />
        <span
          className="inline-block h-2.5 w-2.5 rounded-full bg-white"
          style={{ animation: 'pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite' }}
        />
        应急装备管理专区 — 战备状态检查
      </div>

      {/* ── Page Title ── */}
      <h1 className="text-2xl font-semibold text-[#1F2937]">战备状态检查</h1>

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div
          className="rounded-lg border-2 border-[#10B981] bg-white p-5 shadow-md transition hover:shadow-lg"
          style={{ animation: 'border-pulse 2s infinite' }}
        >
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE2E2]">
              <Shield size={20} className="text-[#DC2626]" />
            </div>
            <span className="text-sm text-[#6B7280]">完好待用</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#10B981]">{goodCount.toLocaleString()}</div>
          <div className="mt-1 flex items-center gap-1.5">
            <PulseDot color="#10B981" />
            <span className="text-xs text-[#10B981]">战备合格</span>
          </div>
        </div>

        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEF3C7]">
              <Search size={20} className="text-[#F59E0B]" />
            </div>
            <span className="text-sm text-[#6B7280]">检测中</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#F59E0B]">{checkCount}</div>
          <div className="mt-1 text-xs text-[#6B7280]">正在检测</div>
        </div>

        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#DBEAFE]">
              <Wrench size={20} className="text-[#3B82F6]" />
            </div>
            <span className="text-sm text-[#6B7280]">维护中</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#3B82F6]">{maintainCount}</div>
          <div className="mt-1 text-xs text-[#6B7280]">定期保养</div>
        </div>

        <div className="rounded-lg bg-white p-5 shadow-md transition hover:shadow-lg">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-[#FEE2E2]">
              <AlertTriangle size={20} className="text-[#EF4444]" />
            </div>
            <span className="text-sm text-[#6B7280]">故障待修</span>
          </div>
          <div className="mt-3 text-[28px] font-bold text-[#EF4444]">{faultCount}</div>
          <div className="mt-1 text-xs text-[#EF4444]">需紧急处理</div>
        </div>
      </div>

      {/* ── Toolbar ── */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#E5E7EB] bg-white px-4 py-3 shadow-sm">
        <h3 className="text-base font-semibold text-[#1F2937]">检查清单</h3>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
            <input
              type="text"
              placeholder="搜索装备名称、型号、编码..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              className="h-8 w-64 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
            />
          </div>
        </div>
      </div>

      {/* ── Check Table ── */}
      <div className="overflow-x-auto rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备信息</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">所属仓库</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">上次检测</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">下次检测</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">到期提醒</th>
              <th className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">战备状态</th>
              <th className="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-[#6B7280]">检查结果确认</th>
            </tr>
          </thead>
          <tbody>
            {filteredRecords.map((record) => {
              const daysLeft = getDaysUntil(record.nextCheck)
              const rowClass = getRowHighlight(record.nextCheck)
              return (
                <tr
                  key={record.id}
                  className={cn('border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]', rowClass)}
                >
                  {/* Equipment Info */}
                  <td className="px-4 py-3">
                    <div className="text-[13px] font-medium text-[#1F2937]">{record.name}</div>
                    <div className="text-xs text-[#6B7280]">{record.model} · {record.code}</div>
                  </td>
                  {/* Warehouse */}
                  <td className="px-4 py-3 text-[13px] text-[#6B7280]">
                    <span className="inline-flex items-center gap-1">
                      <MapPin size={12} />
                      {record.warehouse}
                    </span>
                  </td>
                  {/* Last Check */}
                  <td className="px-4 py-3 text-[13px] text-[#374151]">{record.lastCheck}</td>
                  {/* Next Check */}
                  <td className="px-4 py-3 text-[13px] font-medium text-[#374151]">
                    {record.nextCheck}
                  </td>
                  {/* Expiry Alert */}
                  <td className="px-4 py-3">
                    {daysLeft < 0 && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-[#DC2626]">
                        <AlertTriangle size={12} />
                        已过期 {-daysLeft} 天
                      </span>
                    )}
                    {daysLeft >= 0 && daysLeft < 3 && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-[#DC2626]">
                        <AlertTriangle size={12} />
                        剩 {daysLeft} 天
                      </span>
                    )}
                    {daysLeft >= 3 && daysLeft < 7 && (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-[#D97706]">
                        <Clock size={12} />
                        剩 {daysLeft} 天
                      </span>
                    )}
                    {daysLeft >= 7 && (
                      <span className="text-xs text-[#6B7280]">
                        剩 {daysLeft} 天
                      </span>
                    )}
                  </td>
                  {/* Status */}
                  <td className="px-4 py-3">
                    <ReadinessBadge status={record.status} />
                  </td>
                  {/* Check Result */}
                  <td className="px-4 py-3 text-center">
                    <CheckResultButtons
                      status={record.result}
                      onPass={() => setResult(record.id, '合格')}
                      onFail={() => setResult(record.id, '不合格')}
                    />
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {/* ── Legend ── */}
      <div className="flex flex-wrap items-center gap-4 rounded-lg border border-[#E5E7EB] bg-white px-4 py-3 text-xs text-[#6B7280]">
        <span className="font-medium">图例说明：</span>
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-3 w-3 rounded bg-[#FEE2E2]" /> 已过期（&lt;3天）
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-3 w-3 rounded bg-[#FEF3C7]" /> 即将到期（3-7天）
        </span>
        <span className="inline-flex items-center gap-1">
          <span className="inline-block h-3 w-3 rounded bg-white border border-[#E5E7EB]" /> 正常
        </span>
      </div>

      {/* ── Styles ── */}
      <style>{`
        @keyframes shimmer {
          0% { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
        @keyframes border-pulse {
          0%, 100% { border-color: rgba(16, 185, 129, 0.6); }
          50% { border-color: rgba(16, 185, 129, 1); }
        }
      `}</style>
    </div>
  )
}
