import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import Header from './Header'
import Sidebar from './Sidebar'

const breadcrumbMap: Record<string, string> = {
  '/dashboard': '首页工作台',
  '/basic-info/supplier': '基础信息管理 / 供应商管理',
  '/basic-info/warehouse': '基础信息管理 / 仓库信息',
  '/basic-info/equipment-lib': '基础信息管理 / 装备库',
  '/basic-info/standard': '基础信息管理 / 配备标准',
  '/basic-info/rfid': '基础信息管理 / RFID管理',
  '/supervision/warning-rules': '装备监督管理 / 预警规则',
  '/supervision/warning-records': '装备监督管理 / 预警记录',
  '/supervision/equipment-control': '装备监督管理 / 装备管控',
  '/warehouse/inbound': '仓库管理 / 入库管理',
  '/warehouse/ledger': '仓库管理 / 仓库台账',
  '/warehouse/outbound': '仓库管理 / 出库管理',
  '/warehouse/repair': '仓库管理 / 报修管理',
  '/warehouse/scrap': '仓库管理 / 报废管理',
  '/warehouse/transfer': '仓库管理 / 调拨管理',
  '/warehouse/allocation': '仓库管理 / 配发管理',
  '/warehouse/inventory': '仓库管理 / 盘点管理',
  '/warehouse/channel': '仓库管理 / 通道记录',
  '/emergency/overview': '应急仓库管理 / 应急概览',
  '/emergency/quick-outbound': '应急仓库管理 / 一键出库',
  '/emergency/readiness': '应急仓库管理 / 战备检查',
  '/personal/my-equipment': '个人中心 / 我的装备',
  '/personal/borrow': '个人中心 / 领用管理',
  '/personal/repair': '个人中心 / 报修申请',
  '/personal/scrap': '个人中心 / 报废申请',
  '/personal/handover': '个人中心 / 交接记录',
  '/personal/complaint': '个人中心 / 我的投诉',
  '/analysis/procurement': '装备研判分析 / 采购分析',
  '/analysis/allocation': '装备研判分析 / 配备分析',
  '/analysis/aftersales': '装备研判分析 / 售后分析',
  '/analysis/supplier': '装备研判分析 / 供应商分析',
  '/analysis/quality': '装备研判分析 / 质量分析',
  '/analysis/distribution': '装备研判分析 / 分布分析',
  '/training/materials': '应用技能培训 / 培训资料',
  '/training/process': '应用技能培训 / 培训过程',
  '/forum': '交流论坛',
  '/workflow/design': '流程管理 / 流程设计',
  '/workflow/templates': '流程管理 / 流程模板',
  '/workflow/monitor': '流程管理 / 流程监控',
}

export default function Layout({ children }: { children: React.ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const location = useLocation()

  const breadcrumbText = breadcrumbMap[location.pathname] || ''

  return (
    <div className="min-h-[100dvh]">
      <Header
        onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
        sidebarCollapsed={sidebarCollapsed}
      />
      <Sidebar collapsed={sidebarCollapsed} />
      <main
        className="min-h-[calc(100dvh-3.5rem)] bg-[#F3F4F6] pt-14 transition-all duration-200"
        style={{
          marginLeft: sidebarCollapsed ? '64px' : '220px',
        }}
      >
        {/* Breadcrumb */}
        <div className="px-6 pt-4">
          <nav className="flex items-center gap-2 text-[13px] text-[#6B7280]">
            <span>首页</span>
            {breadcrumbText && (
              <>
                <span className="text-[#D1D5DB]">/</span>
                <span className="font-medium text-[#1F2937]">{breadcrumbText}</span>
              </>
            )}
          </nav>
        </div>
        {/* Page Content */}
        <div className="p-6">{children}</div>
      </main>
    </div>
  )
}
