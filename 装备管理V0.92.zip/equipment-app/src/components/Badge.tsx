import { cn } from '@/lib/utils'

type BadgeVariant = 'primary' | 'success' | 'warning' | 'danger' | 'info' | 'default'

const variantMap: Record<BadgeVariant, string> = {
  primary: 'bg-[#E8F0FE] text-[#1A56DB]',
  success: 'bg-[#D1FAE5] text-[#059669]',
  warning: 'bg-[#FEF3C7] text-[#D97706]',
  danger: 'bg-[#FEE2E2] text-[#DC2626]',
  info: 'bg-[#DBEAFE] text-[#2563EB]',
  default: 'bg-[#F3F4F6] text-[#6B7280]',
}

interface BadgeProps {
  variant?: BadgeVariant
  children: React.ReactNode
  className?: string
  dot?: boolean
}

export default function Badge({ variant = 'default', children, className, dot = false }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium',
        variantMap[variant],
        className
      )}
    >
      {dot && (
        <span className={cn('h-2 w-2 rounded-full', {
          'bg-[#1A56DB]': variant === 'primary',
          'bg-[#059669]': variant === 'success',
          'bg-[#D97706]': variant === 'warning',
          'bg-[#DC2626]': variant === 'danger',
          'bg-[#2563EB]': variant === 'info',
          'bg-[#6B7280]': variant === 'default',
        })} />
      )}
      {children}
    </span>
  )
}
