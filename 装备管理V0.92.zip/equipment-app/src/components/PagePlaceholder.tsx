import { useEffect, useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { ArrowLeft, Construction } from 'lucide-react'

const routeNames: Record<string, string> = {
  '/basic-info/supplier': '供应商管理',
  '/basic-info/warehouse': '仓库信息',
  '/basic-info/equipment-lib': '装备库',
  '/basic-info/standard': '配备标准',
  '/basic-info/rfid': 'RFID管理',
  '/supervision/warning-rules': '预警规则',
  '/supervision/warning-records': '预警记录',
  '/supervision/equipment-control': '装备管控',
  '/warehouse/inbound': '入库管理',
  '/warehouse/ledger': '仓库台账',
  '/warehouse/outbound': '出库管理',
  '/warehouse/repair': '报修管理',
  '/warehouse/scrap': '报废管理',
  '/warehouse/transfer': '调拨管理',
  '/warehouse/allocation': '配发管理',
  '/warehouse/inventory': '盘点管理',
  '/warehouse/channel': '通道记录',
  '/emergency/overview': '应急概览',
  '/emergency/quick-outbound': '一键出库',
  '/emergency/readiness': '战备检查',
  '/personal/my-equipment': '我的装备',
  '/personal/borrow': '领用管理',
  '/personal/repair': '报修申请',
  '/personal/scrap': '报废申请',
  '/personal/handover': '交接记录',
  '/personal/complaint': '我的投诉',
  '/analysis/procurement': '采购分析',
  '/analysis/allocation': '配备分析',
  '/analysis/aftersales': '售后分析',
  '/analysis/supplier': '供应商分析',
  '/analysis/quality': '质量分析',
  '/analysis/distribution': '分布分析',
  '/training/materials': '培训资料',
  '/training/process': '培训过程',
  '/forum': '交流论坛',
  '/workflow/design': '流程设计',
  '/workflow/templates': '流程模板',
  '/workflow/monitor': '流程监控',
}

export default function PagePlaceholder() {
  const navigate = useNavigate()
  const location = useLocation()
  const [mounted, setMounted] = useState(false)
  const pageName = routeNames[location.pathname] || '页面'

  useEffect(() => {
    const t = setTimeout(() => setMounted(true), 50)
    return () => clearTimeout(t)
  }, [])

  return (
    <div
      className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed border-[#D1D5DB] bg-white py-24"
      style={{
        opacity: mounted ? 1 : 0,
        transform: mounted ? 'translateY(0)' : 'translateY(16px)',
        transition: 'opacity 200ms ease, transform 200ms ease',
      }}
    >
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-[#E8F0FE]">
        <Construction size={36} className="text-[#1A56DB]" />
      </div>
      <h3 className="mt-6 text-lg font-medium text-[#1F2937]">{pageName}</h3>
      <p className="mt-2 text-sm text-[#6B7280]">该页面正在开发中，敬请期待</p>
      <button
        onClick={() => navigate('/dashboard')}
        className="mt-6 inline-flex items-center gap-2 rounded-md border border-[#E5E7EB] bg-white px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
      >
        <ArrowLeft size={16} />
        返回首页
      </button>
    </div>
  )
}
