import { useState } from 'react'
import { ChevronDown, ChevronUp, Search, RotateCcw } from 'lucide-react'

export interface FilterField {
  key: string
  label: string
  type: 'input' | 'select' | 'date'
  placeholder?: string
  options?: { label: string; value: string }[]
}

interface FilterPanelProps {
  fields: FilterField[]
  values: Record<string, string>
  onChange: (key: string, value: string) => void
  onSearch: () => void
  onReset: () => void
  defaultExpanded?: boolean
}

export default function FilterPanel({
  fields,
  values,
  onChange,
  onSearch,
  onReset,
  defaultExpanded = false,
}: FilterPanelProps) {
  const [expanded, setExpanded] = useState(defaultExpanded)

  const activeFilterCount = Object.values(values).filter((v) => v !== '').length

  return (
    <div className="mb-4 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex w-full items-center justify-between px-4 py-3 text-sm text-[#374151] transition hover:bg-[#F9FAFB]"
      >
        <div className="flex items-center gap-2">
          {expanded ? <ChevronUp size={16} className="text-[#6B7280]" /> : <ChevronDown size={16} className="text-[#6B7280]" />}
          <span className="font-medium">{expanded ? '收起筛选' : '展开筛选'}</span>
          {activeFilterCount > 0 && (
            <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-[#1A56DB] px-1.5 text-[11px] font-bold text-white">
              {activeFilterCount}
            </span>
          )}
        </div>
      </button>

      {expanded && (
        <div className="border-t border-[#E5E7EB] px-4 py-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {fields.map((field) => (
              <div key={field.key}>
                <label className="mb-1.5 block text-xs text-[#6B7280]">{field.label}</label>
                {field.type === 'select' ? (
                  <select
                    value={values[field.key] || ''}
                    onChange={(e) => onChange(field.key, e.target.value)}
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
                  >
                    <option value="">全部</option>
                    {field.options?.map((opt) => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    type={field.type === 'date' ? 'date' : 'text'}
                    placeholder={field.placeholder || `请输入${field.label}`}
                    value={values[field.key] || ''}
                    onChange={(e) => onChange(field.key, e.target.value)}
                    className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
                  />
                )}
              </div>
            ))}
          </div>

          {/* Active filter tags */}
          {activeFilterCount > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {fields
                .filter((f) => values[f.key])
                .map((f) => (
                  <span
                    key={f.key}
                    className="inline-flex items-center gap-1 rounded-full bg-[#E8F0FE] px-2.5 py-1 text-xs text-[#1A56DB]"
                  >
                    {f.label}: {values[f.key]}
                    <button
                      onClick={() => onChange(f.key, '')}
                      className="ml-1 text-[#1A56DB] hover:text-[#153E7E]"
                    >
                      x
                    </button>
                  </span>
                ))}
            </div>
          )}

          <div className="mt-4 flex justify-end gap-2">
            <button
              onClick={onReset}
              className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-4 text-sm text-[#374151] transition hover:bg-[#F3F4F6]"
            >
              <RotateCcw size={14} /> 重置
            </button>
            <button
              onClick={onSearch}
              className="inline-flex h-8 items-center gap-1 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]"
            >
              <Search size={14} /> 查询
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
