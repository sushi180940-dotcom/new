import { useEffect, useState, useRef } from 'react'
import { TrendingUp, TrendingDown, ArrowRight } from 'lucide-react'
import { cn } from '@/lib/utils'

interface StatCardProps {
  icon: React.ReactNode
  iconBg: string
  iconColor: string
  title: string
  value: number
  trend?: number
  trendType?: 'up' | 'down'
  trendLabel?: string
  trendColor?: 'green' | 'red' | 'danger'
  delay?: number
  onClick?: () => void
}

export default function StatCard({
  icon,
  iconBg,
  iconColor,
  title,
  value,
  trend,
  trendType = 'up',
  trendLabel = '较上月',
  trendColor = 'green',
  delay = 0,
  onClick,
}: StatCardProps) {
  const [count, setCount] = useState(0)
  const [mounted, setMounted] = useState(false)
  const rafRef = useRef<number>(0)
  const startTimeRef = useRef<number>(0)

  useEffect(() => {
    const timer = setTimeout(() => setMounted(true), delay)
    return () => clearTimeout(timer)
  }, [delay])

  useEffect(() => {
    if (!mounted) return
    const duration = 800
    const startValue = 0

    const animate = (timestamp: number) => {
      if (!startTimeRef.current) startTimeRef.current = timestamp
      const elapsed = timestamp - startTimeRef.current
      const progress = Math.min(elapsed / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3)
      setCount(Math.floor(startValue + (value - startValue) * eased))
      if (progress < 1) {
        rafRef.current = requestAnimationFrame(animate)
      }
    }

    rafRef.current = requestAnimationFrame(animate)
    return () => cancelAnimationFrame(rafRef.current)
  }, [mounted, value])

  const formattedValue = count.toLocaleString('zh-CN')

  return (
    <div
      className={cn(
        'relative cursor-pointer rounded-lg bg-white p-5 shadow-md transition-all duration-150 hover:shadow-lg',
        mounted ? 'translate-y-0 opacity-100' : 'translate-y-5 opacity-0'
      )}
      style={{ transitionDelay: `${delay}ms`, transitionDuration: '300ms' }}
      onClick={onClick}
    >
      {/* Top hover line */}
      <div className="absolute left-0 right-0 top-0 h-0.5 rounded-t-lg bg-[#1A56DB] opacity-0 transition-opacity group-hover:opacity-100" />

      <div className="flex items-start justify-between">
        <div className="flex items-center gap-3">
          <div
            className="flex h-10 w-10 items-center justify-center rounded-full"
            style={{ backgroundColor: iconBg }}
          >
            <span style={{ color: iconColor }}>{icon}</span>
          </div>
          <span className="text-sm text-[#6B7280]">{title}</span>
        </div>
        <ArrowRight size={16} className="text-[#D1D5DB]" />
      </div>

      <div className="mt-3">
        <span className="text-[28px] font-bold leading-10 text-[#1F2937]">{formattedValue}</span>
      </div>

      <div className="mt-2 flex items-center gap-1.5">
        {trend !== undefined && trendType === 'up' && (
          <TrendingUp size={14} className={cn(trendColor === 'red' ? 'text-[#EF4444]' : 'text-[#10B981]')} />
        )}
        {trend !== undefined && trendType === 'down' && (
          <TrendingDown size={14} className={cn(trendColor === 'green' ? 'text-[#10B981]' : 'text-[#EF4444]')} />
        )}
        {trend !== undefined && (
          <span
            className={cn(
              'text-[13px] font-medium',
              trendColor === 'red' || trendColor === 'danger' ? 'text-[#EF4444]' : 'text-[#10B981]'
            )}
          >
            {trend}%
          </span>
        )}
        {!trend && trendLabel && (
          <span className="text-[#EF4444]">{trendLabel}</span>
        )}
        <span className="text-xs text-[#6B7280]">{trend !== undefined ? trendLabel : ''}</span>
      </div>
    </div>
  )
}
