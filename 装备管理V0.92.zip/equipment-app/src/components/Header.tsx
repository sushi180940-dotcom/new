import { useState, useRef, useEffect } from 'react'
import {
  Menu,
  Search,
  Bell,
  Maximize,
  Minimize,
  ChevronDown,
  Shield,
  LogOut,
  User,
  Settings,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface HeaderProps {
  onToggleSidebar: () => void
  sidebarCollapsed: boolean
}

export default function Header({ onToggleSidebar }: HeaderProps) {
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [notifOpen, setNotifOpen] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const userMenuRef = useRef<HTMLDivElement>(null)
  const notifRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target as Node)) {
        setUserMenuOpen(false)
      }
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false)
      }
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const notifications = [
    { id: 1, title: '防弹背心库存严重不足', time: '5分钟前', read: false },
    { id: 2, title: '执法记录仪质保即将到期', time: '2小时前', read: false },
    { id: 3, title: '新警装备配发申请待审批', time: '3小时前', read: true },
    { id: 4, title: '系统升级维护通知', time: '1天前', read: true },
  ]

  const unreadCount = notifications.filter((n) => !n.read).length

  return (
    <header
      className="fixed left-0 right-0 top-0 z-50 flex h-14 items-center justify-between px-4"
      style={{ background: 'linear-gradient(90deg, #153E7E, #1A56DB)' }}
    >
      {/* Left: Logo + Toggle */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="flex h-8 w-8 items-center justify-center rounded-md text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          <Menu size={20} />
        </button>
        <div className="flex items-center gap-2">
          <Shield size={22} className="text-white" />
          <span className="text-lg font-bold text-white">警用装备管理系统</span>
        </div>
      </div>

      {/* Center: Search */}
      <div className="hidden md:flex md:w-[400px]">
        <div className="relative w-full">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/50" />
          <input
            type="text"
            placeholder="搜索装备、仓库、单据..."
            className="h-9 w-full rounded-full border-0 bg-white/15 pl-9 pr-4 text-sm text-white placeholder-white/50 outline-none transition focus:bg-white/25"
          />
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-1">
        {/* Notification */}
        <div className="relative" ref={notifRef}>
          <button
            onClick={() => setNotifOpen(!notifOpen)}
            className="relative flex h-8 w-8 items-center justify-center rounded-md text-white/80 transition hover:bg-white/10 hover:text-white"
          >
            <Bell size={18} />
            {unreadCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#EF4444] px-1 text-[10px] font-bold text-white">
                {unreadCount}
              </span>
            )}
          </button>
          {notifOpen && (
            <div className="absolute right-0 top-10 w-80 rounded-lg border border-[#E5E7EB] bg-white shadow-xl">
              <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
                <span className="text-sm font-semibold text-[#1F2937]">通知</span>
                <span className="cursor-pointer text-xs text-[#1A56DB]">全部已读</span>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {notifications.map((n) => (
                  <div
                    key={n.id}
                    className={cn(
                      'cursor-pointer border-b border-[#F3F4F6] px-4 py-3 transition hover:bg-[#F9FAFB]',
                      !n.read && 'bg-[#E8F0FE]/30'
                    )}
                  >
                    <p className={cn('text-sm', !n.read ? 'font-medium text-[#1F2937]' : 'text-[#374151]')}>{n.title}</p>
                    <p className="mt-1 text-xs text-[#6B7280]">{n.time}</p>
                  </div>
                ))}
              </div>
              <div className="px-4 py-2 text-center">
                <span className="cursor-pointer text-xs text-[#1A56DB]">查看全部</span>
              </div>
            </div>
          )}
        </div>

        {/* Fullscreen */}
        <button
          onClick={toggleFullscreen}
          className="flex h-8 w-8 items-center justify-center rounded-md text-white/80 transition hover:bg-white/10 hover:text-white"
        >
          {isFullscreen ? <Minimize size={18} /> : <Maximize size={18} />}
        </button>

        {/* User */}
        <div className="relative" ref={userMenuRef}>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="ml-1 flex items-center gap-2 rounded-md px-2 py-1 text-white transition hover:bg-white/10"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-white/20 text-sm font-bold text-white">
              张
            </div>
            <span className="hidden text-sm font-medium md:inline">张警官</span>
            <ChevronDown size={14} className="text-white/70" />
          </button>
          {userMenuOpen && (
            <div className="absolute right-0 top-11 w-44 rounded-lg border border-[#E5E7EB] bg-white py-1 shadow-xl">
              <div className="border-b border-[#E5E7EB] px-4 py-2">
                <p className="text-sm font-medium text-[#1F2937]">张警官</p>
                <p className="text-xs text-[#6B7280]">装备管理处 · 管理员</p>
              </div>
              <a href="#/personal/my-equipment" className="flex items-center gap-2 px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
                <User size={14} /> 个人中心
              </a>
              <a href="#" className="flex items-center gap-2 px-4 py-2 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
                <Settings size={14} /> 系统设置
              </a>
              <div className="border-t border-[#E5E7EB]">
                <button className="flex w-full items-center gap-2 px-4 py-2 text-sm text-[#EF4444] transition hover:bg-[#FEE2E2]">
                  <LogOut size={14} /> 退出登录
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
