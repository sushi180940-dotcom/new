import { useState } from 'react'
import {
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Search,
  Filter,
  RefreshCw,
  Settings2,
  Plus,
  Trash2,
  Upload,
  Download,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface Column<T> {
  key: string
  title: string
  width?: string
  render?: (row: T) => React.ReactNode
}

interface DataTableProps<T> {
  columns: Column<T>[]
  data: T[]
  title?: string
  searchable?: boolean
  pageSize?: number
  pageSizeOptions?: number[]
  onAdd?: () => void
  onDelete?: () => void
  onImport?: () => void
  onExport?: () => void
  rowActions?: (row: T) => React.ReactNode
}

export default function DataTable<T extends Record<string, unknown>>({
  columns,
  data,
  title,
  searchable = true,
  pageSize: defaultPageSize = 10,
  pageSizeOptions = [10, 20, 50, 100],
  onAdd,
  onDelete,
  onImport,
  onExport,
  rowActions,
}: DataTableProps<T>) {
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(defaultPageSize)
  const [searchText, setSearchText] = useState('')

  const filteredData = searchText
    ? data.filter((row) =>
        columns.some((col) => {
          const val = (row as Record<string, unknown>)[col.key]
          return val != null && String(val).toLowerCase().includes(searchText.toLowerCase())
        })
      )
    : data

  const totalPages = Math.max(1, Math.ceil(filteredData.length / pageSize))
  const safePage = Math.min(currentPage, totalPages)
  const startIdx = (safePage - 1) * pageSize
  const pageData = filteredData.slice(startIdx, startIdx + pageSize)

  const goPage = (p: number) => {
    if (p >= 1 && p <= totalPages) setCurrentPage(p)
  }

  const getPageNumbers = () => {
    const pages: (number | string)[] = []
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i)
    } else {
      pages.push(1)
      if (safePage > 3) pages.push('...')
      const start = Math.max(2, safePage - 1)
      const end = Math.min(totalPages - 1, safePage + 1)
      for (let i = start; i <= end; i++) pages.push(i)
      if (safePage < totalPages - 2) pages.push('...')
      pages.push(totalPages)
    }
    return pages
  }

  return (
    <div className="rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#E5E7EB] px-4 py-3">
        <div className="flex items-center gap-2">
          {title && <h3 className="mr-2 text-base font-semibold text-[#1F2937]">{title}</h3>}
          {onAdd && (
            <button onClick={onAdd} className="inline-flex h-8 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-sm text-white transition hover:bg-[#153E7E]">
              <Plus size={14} /> 新增
            </button>
          )}
          {onDelete && (
            <button onClick={onDelete} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
              <Trash2 size={14} /> 批量删除
            </button>
          )}
          {onImport && (
            <button onClick={onImport} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
              <Upload size={14} /> 导入
            </button>
          )}
          {onExport && (
            <button onClick={onExport} className="inline-flex h-8 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-sm text-[#374151] transition hover:bg-[#F3F4F6]">
              <Download size={14} /> 导出
            </button>
          )}
        </div>
        <div className="flex items-center gap-2">
          {searchable && (
            <div className="relative">
              <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[#9CA3AF]" />
              <input
                type="text"
                placeholder="搜索..."
                value={searchText}
                onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="h-8 w-44 rounded-md border border-[#D1D5DB] pl-8 pr-3 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-2 focus:ring-[#1A56DB]/10"
              />
            </div>
          )}
          <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] text-[#6B7280] transition hover:bg-[#F3F4F6]">
            <Filter size={14} />
          </button>
          <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] text-[#6B7280] transition hover:bg-[#F3F4F6]">
            <RefreshCw size={14} />
          </button>
          <button className="flex h-8 w-8 items-center justify-center rounded-md border border-[#E5E7EB] text-[#6B7280] transition hover:bg-[#F3F4F6]">
            <Settings2 size={14} />
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]"
                  style={col.width ? { width: col.width } : undefined}
                >
                  {col.title}
                </th>
              ))}
              {rowActions && <th className="w-24 px-4 py-3 text-center text-xs font-semibold text-[#6B7280]">操作</th>}
            </tr>
          </thead>
          <tbody>
            {pageData.length === 0 && (
              <tr>
                <td
                  colSpan={columns.length + (rowActions ? 1 : 0)}
                  className="px-4 py-12 text-center text-sm text-[#9CA3AF]"
                >
                  <img src="./empty-data.svg" alt="No data" className="mx-auto mb-3 h-24 w-24 opacity-50" />
                  暂无数据
                </td>
              </tr>
            )}
            {pageData.map((row, idx) => (
              <tr
                key={idx}
                className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]"
              >
                {columns.map((col) => (
                  <td key={col.key} className="px-4 py-3 text-[13px] text-[#374151]">
                    {col.render ? col.render(row) : String((row as Record<string, unknown>)[col.key] ?? '')}
                  </td>
                ))}
                {rowActions && (
                  <td className="px-4 py-3 text-center">{rowActions(row)}</td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {filteredData.length > 0 && (
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-[#E5E7EB] px-4 py-3">
          <div className="flex items-center gap-3 text-sm text-[#6B7280]">
            <span>共 {filteredData.length} 条</span>
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setCurrentPage(1) }}
              className="h-7 rounded border border-[#D1D5DB] px-2 text-xs outline-none"
            >
              {pageSizeOptions.map((s) => (
                <option key={s} value={s}>每页 {s} 条</option>
              ))}
            </select>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => goPage(1)}
              disabled={safePage === 1}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
            >
              <ChevronsLeft size={14} />
            </button>
            <button
              onClick={() => goPage(safePage - 1)}
              disabled={safePage === 1}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
            >
              <ChevronLeft size={14} />
            </button>
            {getPageNumbers().map((p, i) =>
              typeof p === 'string' ? (
                <span key={i} className="px-1 text-[#9CA3AF]">...</span>
              ) : (
                <button
                  key={p}
                  onClick={() => goPage(p)}
                  className={cn(
                    'flex h-7 min-w-7 items-center justify-center rounded border px-1.5 text-xs transition',
                    p === safePage
                      ? 'border-[#1A56DB] bg-[#1A56DB] text-white'
                      : 'border-[#E5E7EB] text-[#374151] hover:bg-[#F3F4F6]'
                  )}
                >
                  {p}
                </button>
              )
            )}
            <button
              onClick={() => goPage(safePage + 1)}
              disabled={safePage === totalPages}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
            >
              <ChevronRight size={14} />
            </button>
            <button
              onClick={() => goPage(totalPages)}
              disabled={safePage === totalPages}
              className="flex h-7 w-7 items-center justify-center rounded border border-[#E5E7EB] text-[#374151] transition hover:bg-[#F3F4F6] disabled:opacity-30"
            >
              <ChevronsRight size={14} />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
