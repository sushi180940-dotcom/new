declare module 'react-echarts-core' {
  import type { CSSProperties, ReactNode } from 'react';
  import type { EChartsCoreOption } from 'echarts';

  interface ReactEChartsCoreProps {
    echarts: typeof import('echarts');
    option: EChartsCoreOption;
    style?: CSSProperties;
    className?: string;
    notMerge?: boolean;
    lazyUpdate?: boolean;
    theme?: string | object;
    onChartReady?: (instance: unknown) => void;
    onEvents?: Record<string, (params: unknown) => void>;
    opts?: {
      devicePixelRatio?: number;
      renderer?: 'canvas' | 'svg';
      width?: number | string | null;
      height?: number | string | null;
    };
    showLoading?: boolean;
    loadingOption?: object;
    autoResize?: boolean;
  }

  export default function ReactEChartsCore(props: ReactEChartsCoreProps): ReactNode;
}
