import { memo, useRef, useEffect } from 'react';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';

interface TrendChartProps {
  title: string;
  data: number[];
  months: string[];
  yMax: number;
  warningZone: [number, number];
  warningLabel: string;
  alertLine: number;
  alertLabel: string;
  lineColor: string;
  areaColorStart: string;
  delay?: number;
}

const TrendChart = memo(function TrendChart({
  title,
  data,
  months,
  yMax,
  warningZone,
  warningLabel,
  alertLine,
  alertLabel,
  lineColor,
  areaColorStart,
  delay = 0,
}: TrendChartProps) {
  const chartRef = useRef<HTMLDivElement>(null);
  const chartInstance = useRef<echarts.ECharts | null>(null);

  useEffect(() => {
    if (!chartRef.current) return;

    const instance = echarts.init(chartRef.current);
    chartInstance.current = instance;

    const option: EChartsOption = {
      backgroundColor: 'transparent',
      animation: true,
      animationDuration: 1000,
      animationDelay: delay,
      animationEasing: 'cubicOut',
      grid: {
        top: 40,
        right: 20,
        bottom: 30,
        left: 50,
      },
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: {
          color: '#d8dce6',
          fontSize: 12,
          fontFamily: 'JetBrains Mono',
        },
        formatter: (params: unknown) => {
          const p = params as Array<{ axisValue: string; value: number; dataIndex: number }>;
          const item = p[0];
          const val = typeof item.value === 'number' ? item.value.toFixed(1) : item.value;
          let status = '正常';
          const v = Number(item.value);
          if (alertLine > 0) {
            if (v > alertLine) status = '警戒';
            else if (v > warningZone[0]) status = '关注';
          } else {
            if (v < Math.abs(alertLine)) status = '警戒';
            else if (v < warningZone[1]) status = '关注';
          }
          return `<div style="font-weight:600;margin-bottom:4px">${item.axisValue}</div>
                  <div style="display:flex;align-items:center;gap:6px">
                    <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${lineColor}"></span>
                    <span>${val}%</span>
                    <span style="color:#6b7fa3;margin-left:4px">${status}</span>
                  </div>`;
        },
      },
      xAxis: {
        type: 'category',
        data: months,
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisTick: { show: false },
        axisLabel: {
          color: '#6b7fa3',
          fontSize: 11,
          fontFamily: 'JetBrains Mono',
        },
      },
      yAxis: {
        type: 'value',
        max: yMax,
        axisLine: { show: false },
        axisTick: { show: false },
        splitLine: { lineStyle: { color: '#1e2a45', type: 'dashed' } },
        axisLabel: {
          color: '#6b7fa3',
          fontSize: 11,
          fontFamily: 'JetBrains Mono',
          formatter: '{value}%',
        },
      },
      series: [
        {
          type: 'line',
          data,
          smooth: true,
          symbol: 'circle',
          symbolSize: 6,
          showSymbol: false,
          lineStyle: {
            color: lineColor,
            width: 2,
          },
          itemStyle: {
            color: lineColor,
            borderWidth: 2,
            borderColor: '#050810',
          },
          areaStyle: {
            color: {
              type: 'linear',
              x: 0, y: 0, x2: 0, y2: 1,
              colorStops: [
                { offset: 0, color: areaColorStart },
                { offset: 1, color: 'rgba(0,0,0,0)' },
              ],
            },
          },
          emphasis: {
            focus: 'series',
            itemStyle: { borderWidth: 3 },
          },
          markArea: {
            silent: true,
            data: [
              [
                {
                  yAxis: warningZone[1],
                  itemStyle: { color: 'rgba(255,209,102,0.08)' },
                  label: {
                    show: true,
                    position: 'insideTopRight',
                    formatter: warningLabel,
                    color: 'rgba(255,209,102,0.5)',
                    fontSize: 10,
                  },
                },
                { yAxis: warningZone[0] },
              ],
            ],
          },
          markLine: {
            silent: true,
            symbol: 'none',
            data: [
              {
                yAxis: alertLine,
                lineStyle: { color: '#ffd166', type: 'dashed', width: 1 },
                label: {
                  show: true,
                  position: 'insideEndTop',
                  formatter: alertLabel,
                  color: '#ffd166',
                  fontSize: 10,
                  fontFamily: 'JetBrains Mono',
                },
              },
            ],
          },
        },
      ],
    };

    instance.setOption(option);

    const handleResize = () => instance.resize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      instance.dispose();
    };
  }, [data, months, yMax, warningZone, warningLabel, alertLine, alertLabel, lineColor, areaColorStart, delay]);

  return (
    <div className="bg-abyss border border-border-dim rounded-xl p-5 flex flex-col flex-1 min-w-0">
      <h3 className="text-h3 text-text-primary mb-4">{title}</h3>
      <div ref={chartRef} className="flex-1" style={{ minHeight: 200 }} />
    </div>
  );
});

export default TrendChart;
