import { useState, useMemo, useCallback, useEffect, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  BarChart3,
  Wallet,
  TrendingUp,
  Package,
  AlertTriangle,
  ArrowUpDown,
  Search,
  Download,
  X,
} from 'lucide-react';
import DataCard from '@/components/DataCard';
import ColorScaleCell from '@/components/ColorScaleCell';
import DetailPopup from './financial/DetailPopup';
import TrendChart from './financial/TrendChart';
import {
  units,
  financialData,
  assetData,
  panoramaOverview,
} from '@/data/mockData';
import type { Unit, FinancialData } from '@/data/mockData';

// ============================================================
// Types
// ============================================================

type SortColumn = 'debtToAsset' | 'currentRatio' | 'incomeExpense' | 'renewalRate';
type SortDirection = 'asc' | 'desc';
type UnitTypeFilter = 'all' | '总队' | '支队' | '大队';

interface UnitRow {
  unit: Unit;
  financial: FinancialData;
  incomeExpenseRatio: number;
  fixedAssetRenewal: number;
}

// ============================================================
// Derived Metric Computation
// ============================================================

function computeIncomeExpenseRatio(fd: FinancialData): number {
  // Synthetic metric correlated with financial health
  return Math.round(
    Math.max(5, fd.debtToAssetRatio * 0.42 + Math.max(0, fd.debtToAssetChange) * 0.6) * 10,
  ) / 10;
}

function computeFixedAssetRenewal(unitId: string): number {
  const ad = assetData[unitId];
  if (!ad) return 60;
  return Math.round(
    Math.min(95, Math.max(35, ad.utilizationRate * 0.8 + 5 + ad.assetValueChange * 0.5)) * 10,
  ) / 10;
}

// ============================================================
// Status Helpers
// ============================================================

function getDebtStatus(v: number) {
  if (v < 40) return { color: '#00f5a0', label: '健康' };
  if (v < 55) return { color: '#ffd166', label: '关注' };
  return { color: '#ff4757', label: '风险' };
}

function getCashRatioStatus(v: number) {
  if (v >= 1.0) return { color: '#00f5a0', label: '健康' };
  if (v >= 0.7) return { color: '#ffd166', label: '关注' };
  return { color: '#ff4757', label: '风险' };
}

function getCurrentRatioStatus(v: number) {
  if (v >= 1.5) return { color: '#00f5a0', label: '健康' };
  if (v >= 1.0) return { color: '#ffd166', label: '关注' };
  return { color: '#ff4757', label: '风险' };
}

function getRenewalStatus(v: number) {
  if (v > 70) return { color: '#00f5a0', label: '健康' };
  if (v >= 50) return { color: '#ffd166', label: '关注' };
  return { color: '#ff4757', label: '风险' };
}

function getIncomeExpenseStatus(v: number) {
  if (v < 15) return { color: '#00f5a0', label: '健康' };
  if (v < 25) return { color: '#ffd166', label: '关注' };
  return { color: '#ff4757', label: '风险' };
}

function getCompositeRisk(row: UnitRow) {
  const reds = [
    row.financial.debtToAssetRatio >= 55,
    row.financial.currentRatio < 1.0,
    row.incomeExpenseRatio >= 25,
    row.fixedAssetRenewal < 50,
  ].filter(Boolean).length;
  const yellows = [
    row.financial.debtToAssetRatio >= 40 && row.financial.debtToAssetRatio < 55,
    row.financial.currentRatio >= 1.0 && row.financial.currentRatio < 1.5,
    row.incomeExpenseRatio >= 15 && row.incomeExpenseRatio < 25,
    row.fixedAssetRenewal >= 50 && row.fixedAssetRenewal <= 70,
  ].filter(Boolean).length;

  if (reds >= 2 || (reds >= 1 && yellows >= 2)) return { label: '高', color: '#ff4757' };
  if (reds === 1 || yellows >= 2) return { label: '中', color: '#ffd166' };
  return { label: '低', color: '#00f5a0' };
}

// ============================================================
// Trend Data Generation
// ============================================================

function generateTrend(endValue: number, variance: number, count: number = 12): number[] {
  const data: number[] = [];
  let v = endValue;
  for (let i = count - 1; i >= 0; i--) {
    data.unshift(v);
    const change = (Math.sin(i * 0.7 + endValue * 0.1) * variance);
    v = Math.max(0.1, v - change);
  }
  return data;
}

const months12 = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

// ============================================================
// Financial Panorama Page
// ============================================================

const FinancialPanorama = memo(function FinancialPanorama() {
  // -- State --
  const [sortColumn, setSortColumn] = useState<SortColumn>('debtToAsset');
  const [sortDirection, setSortDirection] = useState<SortDirection>('desc');
  const [searchText, setSearchText] = useState('');
  const [unitTypeFilter, setUnitTypeFilter] = useState<UnitTypeFilter>('all');
  const [selectedUnit, setSelectedUnit] = useState<Unit | null>(null);
  const [sortToast, setSortToast] = useState<string | null>(null);
  const [clickedCard, setClickedCard] = useState<string | null>(null);

  // -- Computed Data --
  const unitRows: UnitRow[] = useMemo(() => {
    return units
      .filter(u => !!financialData[u.id])
      .map(unit => {
        const fd = financialData[unit.id];
        return {
          unit,
          financial: fd,
          incomeExpenseRatio: computeIncomeExpenseRatio(fd),
          fixedAssetRenewal: computeFixedAssetRenewal(unit.id),
        };
      });
  }, []);

  const filteredRows = useMemo(() => {
    return unitRows.filter(row => {
      const matchesSearch = row.unit.name.toLowerCase().includes(searchText.toLowerCase());
      const matchesType = unitTypeFilter === 'all' || row.unit.type === unitTypeFilter;
      return matchesSearch && matchesType;
    });
  }, [unitRows, searchText, unitTypeFilter]);

  const sortedRows = useMemo(() => {
    const sorted = [...filteredRows];
    sorted.sort((a, b) => {
      let aVal: number;
      let bVal: number;
      switch (sortColumn) {
        case 'debtToAsset':
          aVal = a.financial.debtToAssetRatio;
          bVal = b.financial.debtToAssetRatio;
          break;
        case 'currentRatio':
          aVal = a.financial.currentRatio;
          bVal = b.financial.currentRatio;
          break;
        case 'incomeExpense':
          aVal = a.incomeExpenseRatio;
          bVal = b.incomeExpenseRatio;
          break;
        case 'renewalRate':
          aVal = a.fixedAssetRenewal;
          bVal = b.fixedAssetRenewal;
          break;
      }
      return sortDirection === 'asc' ? aVal - bVal : bVal - aVal;
    });
    return sorted;
  }, [filteredRows, sortColumn, sortDirection]);

  // Averages
  const avgValues = useMemo(() => {
    const debtAvg = unitRows.reduce((s, r) => s + r.financial.debtToAssetRatio, 0) / unitRows.length;
    const crAvg = unitRows.reduce((s, r) => s + r.financial.currentRatio, 0) / unitRows.length;
    const ieAvg = unitRows.reduce((s, r) => s + r.incomeExpenseRatio, 0) / unitRows.length;
    const rrAvg = unitRows.reduce((s, r) => s + r.fixedAssetRenewal, 0) / unitRows.length;
    return {
      debtToAsset: Math.round(debtAvg * 10) / 10,
      currentRatio: Math.round(crAvg * 100) / 100,
      incomeExpense: Math.round(ieAvg * 10) / 10,
      renewalRate: Math.round(rrAvg * 10) / 10,
    };
  }, [unitRows]);

  // Overview sparklines (available for future use)

  // Generate card sparklines
  const cardSparklines = useMemo(() => {
    const debtSL = generateTrend(avgValues.debtToAsset, 0.4, 7);
    const cashSL = generateTrend(
      unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length,
      0.05, 7,
    );
    const currentSL = generateTrend(avgValues.currentRatio, 0.06, 7);
    const renewalSL = generateTrend(avgValues.renewalRate, 1.5, 7);
    const ieSL = generateTrend(avgValues.incomeExpense, 0.8, 7);
    return { debtSL, cashSL, currentSL, renewalSL, ieSL };
  }, [avgValues, unitRows]);

  // 12-month chart data
  const debtChartData = useMemo(() => generateTrend(avgValues.debtToAsset, 0.5, 12), [avgValues.debtToAsset]);
  const ieChartData = useMemo(() => generateTrend(avgValues.incomeExpense, 0.8, 12), [avgValues.incomeExpense]);

  // Selected unit's computed data for popup
  const selectedUnitData = useMemo(() => {
    if (!selectedUnit) return null;
    const fd = financialData[selectedUnit.id];
    if (!fd) return null;
    return {
      financial: fd,
      incomeExpenseRatio: computeIncomeExpenseRatio(fd),
      fixedAssetRenewal: computeFixedAssetRenewal(selectedUnit.id),
    };
  }, [selectedUnit]);

  // -- Handlers --
  const handleSort = useCallback((column: SortColumn) => {
    setSortColumn(prev => {
      if (prev === column) {
        setSortDirection(d => d === 'asc' ? 'desc' : 'asc');
        return prev;
      }
      setSortDirection('desc');
      return column;
    });
  }, []);

  const handleCardClick = useCallback((column: SortColumn) => {
    setClickedCard(column);
    setTimeout(() => setClickedCard(null), 200);
    handleSort(column);
    const labels: Record<string, string> = {
      debtToAsset: '资产负债率',
      currentRatio: '流动比率',
      incomeExpense: '收入费用率',
      renewalRate: '成新率',
    };
    setSortToast(`已按${labels[column]}降序排列`);
    setTimeout(() => setSortToast(null), 2300);
  }, [handleSort]);

  // Toast auto-dismiss
  useEffect(() => {
    if (!sortToast) return;
    const t = setTimeout(() => setSortToast(null), 2300);
    return () => clearTimeout(t);
  }, [sortToast]);

  // Column header sort labels
  const sortLabelMap: Record<SortColumn, string> = {
    debtToAsset: '资产负债率',
    currentRatio: '流动比率',
    incomeExpense: '收入费用率',
    renewalRate: '成新率',
  };

  // Sort button active state
  const isSortActive = (col: SortColumn) => sortColumn === col;

  // -- Render Helpers --
  const renderCellValue = (value: number, suffix: string, decimals: number) => (
    <span className="font-mono text-mono-md text-text-primary">
      {value.toFixed(decimals)}{suffix}
    </span>
  );

  const renderColorBar = (value: number, min: number, max: number, lowIsGood: boolean) => {
    const clamped = Math.max(min, Math.min(max, value));
    const ratio = (clamped - min) / (max - min);
    let r: number, g: number, b: number;
    if (lowIsGood) {
      if (ratio <= 0.5) {
        const t = ratio * 2;
        r = Math.round(0 + (255 - 0) * t);
        g = Math.round(245 + (209 - 245) * t);
        b = Math.round(160 + (102 - 160) * t);
      } else {
        const t = (ratio - 0.5) * 2;
        r = 255;
        g = Math.round(209 + (71 - 209) * t);
        b = Math.round(102 + (87 - 102) * t);
      }
    } else {
      if (ratio <= 0.5) {
        const t = ratio * 2;
        r = Math.round(255 + (255 - 255) * t);
        g = Math.round(71 + (209 - 71) * t);
        b = Math.round(87 + (102 - 87) * t);
      } else {
        const t = (ratio - 0.5) * 2;
        r = Math.round(255 + (0 - 255) * t);
        g = Math.round(209 + (245 - 209) * t);
        b = Math.round(102 + (160 - 102) * t);
      }
    }
    const barWidth = Math.round(ratio * 80);
    return (
      <div className="flex items-center gap-2 mt-1">
        <div className="w-20 h-1.5 rounded-full" style={{ backgroundColor: '#101628' }}>
          <div
            className="h-full rounded-full"
            style={{ width: barWidth, backgroundColor: `rgb(${r},${g},${b})` }}
          />
        </div>
      </div>
    );
  };

  // -- Render --
  return (
    <div className="min-h-[100dvh] flex flex-col" style={{ backgroundColor: '#02040a' }}>
      {/* ============================================================
          Upper Half — Financial Dashboard
      ============================================================ */}
      <div className="flex-shrink-0 px-5 pt-[72px] pb-4" style={{ height: '50vh', minHeight: 420 }}>
        {/* Row 1: 5 Indicator Cards */}
        <div className="flex gap-3 mb-4" style={{ height: '55%' }}>
          {/* Card 1: 资产负债率 */}
          <motion.div
            animate={clickedCard === 'debtToAsset' ? { scale: [1, 1.03, 1] } : {}}
            transition={{ duration: 0.2 }}
            className="flex-1 min-w-0"
          >
            <DataCard
              title="资产负债率"
              value={avgValues.debtToAsset}
              suffix="%"
              decimals={1}
              icon={BarChart3}
              iconColor="#2151f5"
              trend={panoramaOverview.financial.trend[0] - avgValues.debtToAsset}
              trendLabel="同比"
              sparkline={cardSparklines.debtSL}
              sparklineColor="#2151f5"
              delay={0.4}
              className="h-full cursor-pointer hover:border-border hover:shadow-card transition-all"
              onClick={() => handleCardClick('debtToAsset')}
            >
              <div className="mt-1 flex items-center gap-2">
                <span className="text-small text-text-tertiary">警戒线: 50%</span>
                <span
                  className="text-small font-medium px-2 py-0.5 rounded"
                  style={{ backgroundColor: `${getDebtStatus(avgValues.debtToAsset).color}20`, color: getDebtStatus(avgValues.debtToAsset).color }}
                >
                  {getDebtStatus(avgValues.debtToAsset).label}
                </span>
              </div>
            </DataCard>
          </motion.div>

          {/* Card 2: 现金比率 */}
          <motion.div
            animate={clickedCard === 'cashRatio' ? { scale: [1, 1.03, 1] } : {}}
            transition={{ duration: 0.2 }}
            className="flex-1 min-w-0"
          >
            <DataCard
              title="现金比率"
              value={unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length}
              suffix=""
              decimals={2}
              icon={Wallet}
              iconColor="#00e5ff"
              trend={0.08}
              trendLabel="同比"
              sparkline={cardSparklines.cashSL}
              sparklineColor="#00e5ff"
              delay={0.46}
              className="h-full cursor-pointer hover:border-border hover:shadow-card transition-all"
              onClick={() => handleCardClick('currentRatio')}
            >
              <div className="mt-1 flex items-center gap-2">
                <span className="text-small text-text-tertiary">参考值: &gt;= 1.0</span>
                <span
                  className="text-small font-medium px-2 py-0.5 rounded"
                  style={{
                    backgroundColor: `${getCashRatioStatus(unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length).color}20`,
                    color: getCashRatioStatus(unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length).color,
                  }}
                >
                  {getCashRatioStatus(unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length).label}
                </span>
              </div>
            </DataCard>
          </motion.div>

          {/* Card 3: 流动比率 */}
          <motion.div
            animate={clickedCard === 'currentRatio' ? { scale: [1, 1.03, 1] } : {}}
            transition={{ duration: 0.2 }}
            className="flex-1 min-w-0"
          >
            <DataCard
              title="流动比率"
              value={avgValues.currentRatio}
              suffix=""
              decimals={2}
              icon={TrendingUp}
              iconColor="#a855f7"
              trend={0.15}
              trendLabel="同比"
              sparkline={cardSparklines.currentSL}
              sparklineColor="#a855f7"
              delay={0.52}
              className="h-full cursor-pointer hover:border-border hover:shadow-card transition-all"
              onClick={() => handleCardClick('currentRatio')}
            >
              <div className="mt-1 flex items-center gap-2">
                <span className="text-small text-text-tertiary">参考值: &gt;= 1.5</span>
                <span
                  className="text-small font-medium px-2 py-0.5 rounded"
                  style={{ backgroundColor: `${getCurrentRatioStatus(avgValues.currentRatio).color}20`, color: getCurrentRatioStatus(avgValues.currentRatio).color }}
                >
                  {getCurrentRatioStatus(avgValues.currentRatio).label}
                </span>
              </div>
            </DataCard>
          </motion.div>

          {/* Card 4: 固定资产成新率 */}
          <motion.div
            animate={clickedCard === 'renewalRate' ? { scale: [1, 1.03, 1] } : {}}
            transition={{ duration: 0.2 }}
            className="flex-1 min-w-0"
          >
            <DataCard
              title="固定资产成新率"
              value={avgValues.renewalRate}
              suffix="%"
              decimals={1}
              icon={Package}
              iconColor="#00e5ff"
              trend={-3.2}
              trendLabel="同比"
              sparkline={cardSparklines.renewalSL}
              sparklineColor="#00e5ff"
              delay={0.58}
              className="h-full cursor-pointer hover:border-border hover:shadow-card transition-all"
              onClick={() => handleCardClick('renewalRate')}
            >
              <div className="mt-1 flex items-center gap-2">
                <span className="text-small text-text-tertiary">参考值: &gt;= 70%</span>
                <span
                  className="text-small font-medium px-2 py-0.5 rounded"
                  style={{ backgroundColor: `${getRenewalStatus(avgValues.renewalRate).color}20`, color: getRenewalStatus(avgValues.renewalRate).color }}
                >
                  {getRenewalStatus(avgValues.renewalRate).label}
                </span>
              </div>
            </DataCard>
          </motion.div>

          {/* Card 5: 收入费用率 */}
          <motion.div
            animate={clickedCard === 'incomeExpense' ? { scale: [1, 1.03, 1] } : {}}
            transition={{ duration: 0.2 }}
            className="flex-1 min-w-0"
          >
            <DataCard
              title="收入费用率"
              value={avgValues.incomeExpense}
              suffix="%"
              decimals={1}
              icon={AlertTriangle}
              iconColor="#f97316"
              trend={-1.5}
              trendLabel="同比"
              sparkline={cardSparklines.ieSL}
              sparklineColor="#f97316"
              delay={0.64}
              className="h-full cursor-pointer hover:border-border hover:shadow-card transition-all"
              onClick={() => handleCardClick('incomeExpense')}
            >
              <div className="mt-1 flex items-center gap-2">
                <span className="text-small text-text-tertiary">警戒线: 20%</span>
                <span
                  className="text-small font-medium px-2 py-0.5 rounded"
                  style={{ backgroundColor: `${getIncomeExpenseStatus(avgValues.incomeExpense).color}20`, color: getIncomeExpenseStatus(avgValues.incomeExpense).color }}
                >
                  {getIncomeExpenseStatus(avgValues.incomeExpense).label}
                </span>
              </div>
            </DataCard>
          </motion.div>
        </div>

        {/* Row 2: Trend Charts */}
        <div className="flex gap-4" style={{ height: '40%' }}>
          <TrendChart
            title="资产负债率趋势 (近12个月)"
            data={debtChartData}
            months={months12}
            yMax={80}
            warningZone={[40, 50]}
            warningLabel="关注区间"
            alertLine={50}
            alertLabel="警戒线 50%"
            lineColor="#2151f5"
            areaColorStart="rgba(33,81,245,0.15)"
            delay={700}
          />
          <TrendChart
            title="收入费用率趋势 (近12个月)"
            data={ieChartData}
            months={months12}
            yMax={40}
            warningZone={[20, 25]}
            warningLabel="关注区间"
            alertLine={20}
            alertLabel="警戒线 20%"
            lineColor="#f97316"
            areaColorStart="rgba(249,115,22,0.15)"
            delay={700}
          />
        </div>
      </div>

      {/* ============================================================
          Lower Half — Comparison Matrix
      ============================================================ */}
      <div className="flex-1 flex flex-col px-5 pb-4" style={{ backgroundColor: '#0a0e1a', minHeight: 0 }}>
        {/* Toolbar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.0, duration: 0.3 }}
          className="flex items-center justify-between py-3 flex-shrink-0"
        >
          {/* Sort controls */}
          <div className="flex items-center gap-2">
            <span className="text-small text-text-tertiary mr-1">排序方式:</span>
            {(Object.keys(sortLabelMap) as SortColumn[]).map(col => (
              <button
                key={col}
                onClick={() => handleSort(col)}
                className={`px-3 py-1.5 rounded-md text-small font-medium transition-all flex items-center gap-1 ${
                  isSortActive(col)
                    ? 'bg-accent-blue text-white'
                    : 'bg-surface text-text-secondary hover:text-text-primary'
                }`}
              >
                {sortLabelMap[col]}
                {isSortActive(col) && (
                  <ArrowUpDown className="w-3 h-3" />
                )}
              </button>
            ))}
          </div>

          {/* Right: Search + Filter + Export */}
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-text-tertiary" />
              <input
                type="text"
                placeholder="搜索单位..."
                value={searchText}
                onChange={e => setSearchText(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-md bg-surface border border-border-dim text-small text-text-primary placeholder:text-text-tertiary focus:outline-none focus:border-border-bright w-44"
              />
              {searchText && (
                <button
                  onClick={() => setSearchText('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-text-tertiary hover:text-text-primary"
                >
                  <X className="w-3 h-3" />
                </button>
              )}
            </div>

            <select
              value={unitTypeFilter}
              onChange={e => setUnitTypeFilter(e.target.value as UnitTypeFilter)}
              className="px-3 py-1.5 rounded-md bg-surface border border-border-dim text-small text-text-primary focus:outline-none focus:border-border-bright cursor-pointer"
            >
              <option value="all">全部单位</option>
              <option value="总队">总队</option>
              <option value="支队">支队</option>
              <option value="大队">大队</option>
            </select>

            <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-small text-text-secondary hover:text-text-primary hover:bg-surface transition-all">
              <Download className="w-3.5 h-3.5" />
              <span>导出</span>
            </button>
          </div>
        </motion.div>

        {/* Toast notification */}
        <AnimatePresence>
          {sortToast && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-2 left-1/2 -translate-x-1/2 z-20 px-4 py-2 rounded-lg text-small"
              style={{
                backgroundColor: '#151d32',
                border: '1px solid #2a3a5c',
                color: '#d8dce6',
              }}
            >
              {sortToast}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Table */}
        <div className="flex-1 overflow-auto rounded-xl border border-border-dim" style={{ minHeight: 0 }}>
          <table className="w-full">
            {/* Table Header */}
            <thead className="sticky top-0 z-10">
              <tr className="bg-surface">
                <th className="text-left px-4 py-2.5 text-small font-semibold text-text-secondary w-[180px]">
                  单位名称
                </th>
                <th
                  className={`text-left px-4 py-2.5 text-small font-semibold cursor-pointer transition-colors hover:text-text-primary w-[140px] ${
                    sortColumn === 'debtToAsset' ? 'text-accent-blue' : 'text-text-secondary'
                  }`}
                  onClick={() => handleSort('debtToAsset')}
                >
                  <span className="flex items-center gap-1">
                    资产负债率
                    {sortColumn === 'debtToAsset' && (
                      <ArrowUpDown className="w-3 h-3" />
                    )}
                  </span>
                </th>
                <th className="text-left px-4 py-2.5 text-small font-semibold text-text-secondary w-[100px]">
                  现金比率
                </th>
                <th
                  className={`text-left px-4 py-2.5 text-small font-semibold cursor-pointer transition-colors hover:text-text-primary w-[100px] ${
                    sortColumn === 'currentRatio' ? 'text-accent-blue' : 'text-text-secondary'
                  }`}
                  onClick={() => handleSort('currentRatio')}
                >
                  <span className="flex items-center gap-1">
                    流动比率
                    {sortColumn === 'currentRatio' && (
                      <ArrowUpDown className="w-3 h-3" />
                    )}
                  </span>
                </th>
                <th
                  className={`text-left px-4 py-2.5 text-small font-semibold cursor-pointer transition-colors hover:text-text-primary w-[140px] ${
                    sortColumn === 'incomeExpense' ? 'text-accent-blue' : 'text-text-secondary'
                  }`}
                  onClick={() => handleSort('incomeExpense')}
                >
                  <span className="flex items-center gap-1">
                    收入费用率
                    {sortColumn === 'incomeExpense' && (
                      <ArrowUpDown className="w-3 h-3" />
                    )}
                  </span>
                </th>
                <th
                  className={`text-left px-4 py-2.5 text-small font-semibold cursor-pointer transition-colors hover:text-text-primary w-[140px] ${
                    sortColumn === 'renewalRate' ? 'text-accent-blue' : 'text-text-secondary'
                  }`}
                  onClick={() => handleSort('renewalRate')}
                >
                  <span className="flex items-center gap-1">
                    固定资产成新率
                    {sortColumn === 'renewalRate' && (
                      <ArrowUpDown className="w-3 h-3" />
                    )}
                  </span>
                </th>
                <th className="text-left px-4 py-2.5 text-small font-semibold text-text-secondary w-[80px]">
                  综合风险
                </th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody>
              <AnimatePresence mode="popLayout">
                {sortedRows.map((row, index) => {
                  const risk = getCompositeRisk(row);
                  const borderLeftColor =
                    row.financial.debtToAssetRatio >= 55 ? '#ff4757' :
                    row.financial.debtToAssetRatio >= 40 ? '#ffd166' : '#00f5a0';

                  return (
                    <motion.tr
                      key={row.unit.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      transition={{
                        layout: { type: 'spring', stiffness: 300, damping: 30 },
                        opacity: { duration: 0.3 },
                        delay: Math.min(index * 0.03, 0.3),
                      }}
                      className="border-b border-border-dim cursor-pointer transition-colors hover:bg-surface group"
                      style={{
                        borderLeft: `3px solid ${borderLeftColor}`,
                        backgroundColor: index % 2 === 0 ? 'transparent' : 'rgba(10,14,26,0.5)',
                      }}
                      onClick={() => setSelectedUnit(row.unit)}
                    >
                      {/* Unit Name */}
                      <td className="px-4 py-3">
                        <div className="text-body text-text-primary font-medium">{row.unit.name}</div>
                        <span
                          className="text-small px-1.5 py-0.5 rounded-sm mt-0.5 inline-block"
                          style={{ backgroundColor: '#101628', color: '#6b7fa3' }}
                        >
                          {row.unit.type}
                        </span>
                      </td>

                      {/* 资产负债率 */}
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          {renderCellValue(row.financial.debtToAssetRatio, '%', 1)}
                          {renderColorBar(row.financial.debtToAssetRatio, 30, 65, true)}
                        </div>
                      </td>

                      {/* 现金比率 */}
                      <td className="px-4 py-3">
                        <ColorScaleCell
                          value={row.financial.quickRatio}
                          min={0.2}
                          max={2.0}
                          lowIsGood={false}
                          decimals={2}
                        />
                      </td>

                      {/* 流动比率 */}
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          {renderCellValue(row.financial.currentRatio, '', 2)}
                          {renderColorBar(row.financial.currentRatio, 0.5, 2.5, false)}
                        </div>
                      </td>

                      {/* 收入费用率 */}
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          {renderCellValue(row.incomeExpenseRatio, '%', 1)}
                          {renderColorBar(row.incomeExpenseRatio, 5, 35, true)}
                        </div>
                      </td>

                      {/* 固定资产成新率 */}
                      <td className="px-4 py-3">
                        <div className="flex flex-col">
                          {renderCellValue(row.fixedAssetRenewal, '%', 1)}
                          {renderColorBar(row.fixedAssetRenewal, 35, 90, false)}
                        </div>
                      </td>

                      {/* 综合风险 */}
                      <td className="px-4 py-3">
                        <span
                          className="inline-flex items-center px-3 py-1 rounded text-small font-semibold"
                          style={{
                            backgroundColor: `${risk.color}20`,
                            color: risk.color,
                          }}
                        >
                          {risk.label}
                        </span>
                      </td>
                    </motion.tr>
                  );
                })}
              </AnimatePresence>
            </tbody>

            {/* Summary Footer */}
            <tfoot>
              <tr className="bg-surface border-t-2 border-border">
                <td className="px-4 py-3 text-small font-semibold text-text-primary">
                  全厅平均值
                </td>
                <td className="px-4 py-3 font-mono text-mono-sm font-semibold text-text-primary">
                  {avgValues.debtToAsset.toFixed(1)}%
                </td>
                <td className="px-4 py-3 font-mono text-mono-sm font-semibold text-text-primary">
                  {(unitRows.reduce((s, r) => s + r.financial.quickRatio, 0) / unitRows.length).toFixed(2)}
                </td>
                <td className="px-4 py-3 font-mono text-mono-sm font-semibold text-text-primary">
                  {avgValues.currentRatio.toFixed(2)}
                </td>
                <td className="px-4 py-3 font-mono text-mono-sm font-semibold text-text-primary">
                  {avgValues.incomeExpense.toFixed(1)}%
                </td>
                <td className="px-4 py-3 font-mono text-mono-sm font-semibold text-text-primary">
                  {avgValues.renewalRate.toFixed(1)}%
                </td>
                <td className="px-4 py-3">
                  <span
                    className="inline-flex items-center px-3 py-1 rounded text-small font-semibold"
                    style={{
                      backgroundColor: '#00f5a020',
                      color: '#00f5a0',
                    }}
                  >
                    低
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* ============================================================
          Detail Popup
      ============================================================ */}
      <DetailPopup
        isOpen={!!selectedUnit}
        unit={selectedUnit}
        financialData={selectedUnitData?.financial ?? null}
        incomeExpenseRatio={selectedUnitData?.incomeExpenseRatio ?? 0}
        fixedAssetRenewal={selectedUnitData?.fixedAssetRenewal ?? 0}
        avgValues={avgValues}
        onClose={() => setSelectedUnit(null)}
      />
    </div>
  );
});

export default FinancialPanorama;
