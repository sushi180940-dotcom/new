import { useState, useCallback, useMemo, useRef, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';
import {
  Wallet, BarChart3, TrendingUp, AlertTriangle,
  Plus, Minus, RotateCcw, ChevronRight,
} from 'lucide-react';
import DataCard from '@/components/DataCard';
import ProvinceMap from '@/components/ProvinceMap';
import SidePanel from '@/components/SidePanel';
import {
  units, economicData, getUnitById, type Unit,
} from '@/data/mockData';
import {
  aggregateExpenditure,
  aggregateMonthlyExecution,
  allProjects,
  getAggregateStats,
  getExecutionColor,
  getRevenueSparkline,
  getExpenditureSparkline,
  getTopUnitsByCategory,
  sequentialProgressRate,
  type ProjectItem,
} from './economic/dataGenerators';
import TabBudgetExecution from './economic/TabBudgetExecution';
import TabExpenditureStructure from './economic/TabExpenditureStructure';
import TabProjectsDepartments from './economic/TabProjectsDepartments';

// ============================================================
// Chart Option Generators
// ============================================================

const expenditurePieOption: EChartsOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'item',
    backgroundColor: '#0a0e1a',
    borderColor: '#2a3a5c',
    borderWidth: 1,
    textStyle: { color: '#d8dce6', fontSize: 12 },
    formatter: (params: any) => `${params.name}<br/><span style="font-weight:600;color:${params.color}">${(params.value / 10000).toFixed(2)}亿</span> (${params.percent}%)`,
  },
  series: [{
    type: 'pie',
    radius: ['42%', '68%'],
    center: ['50%', '50%'],
    avoidLabelOverlap: true,
    itemStyle: {
      borderRadius: 5,
      borderColor: '#0a0e1a',
      borderWidth: 3,
    },
    label: {
      show: true,
      color: '#d8dce6',
      formatter: '{b}\n{d}%',
      fontSize: 11,
      lineHeight: 16,
    },
    labelLine: {
      lineStyle: { color: '#2a3a5c' },
      length: 12,
      length2: 8,
    },
    emphasis: {
      scaleSize: 8,
      label: { fontSize: 13, fontWeight: 'bold' },
      itemStyle: { shadowBlur: 20 },
    },
    data: aggregateExpenditure.map(item => ({
      value: item.value,
      name: item.name,
      itemStyle: { color: item.color },
    })),
    animationType: 'expansion',
    animationEasing: 'cubicOut',
    animationDuration: 800,
  }],
  graphic: [
    {
      type: 'text',
      left: 'center',
      top: '40%',
      style: {
        text: '9.4亿',
        fill: '#d8dce6',
        fontSize: 18,
        fontWeight: 600,
        fontFamily: 'JetBrains Mono, monospace',
      },
    },
    {
      type: 'text',
      left: 'center',
      top: '53%',
      style: {
        text: '总支出',
        fill: '#6b7fa3',
        fontSize: 12,
      },
    },
  ],
};

const executionTrendOption: EChartsOption = {
  backgroundColor: 'transparent',
  tooltip: {
    trigger: 'axis',
    backgroundColor: '#0a0e1a',
    borderColor: '#2a3a5c',
    borderWidth: 1,
    textStyle: { color: '#d8dce6', fontSize: 12 },
    formatter: (params: any) => {
      const val = params[0]?.value ?? 0;
      const dev = (val - sequentialProgressRate).toFixed(1);
      const devColor = Number(dev) >= 0 ? '#00f5a0' : '#ff4757';
      return `<div style="font-weight:600;margin-bottom:4px">${params[0]?.axisValue}</div>
              <div>执行率: <span style="color:#4f8af7;font-weight:600">${val}%</span></div>
              <div>偏差序时: <span style="color:${devColor}">${Number(dev) >= 0 ? '+' : ''}${dev}%</span></div>`;
    },
  },
  grid: { top: 25, right: 20, bottom: 30, left: 50 },
  xAxis: {
    type: 'category',
    data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
    axisLine: { lineStyle: { color: '#1e2a45' } },
    axisLabel: { color: '#6b7fa3', fontSize: 10 },
    axisTick: { show: false },
  },
  yAxis: {
    type: 'value',
    min: 0,
    max: 100,
    axisLine: { show: false },
    axisLabel: { color: '#6b7fa3', fontSize: 10, formatter: '{value}%' },
    splitLine: { lineStyle: { color: 'rgba(30, 42, 69, 0.5)' } },
  },
  series: [
    {
      type: 'line',
      data: aggregateMonthlyExecution,
      smooth: true,
      symbol: 'circle',
      symbolSize: 6,
      showSymbol: false,
      lineStyle: { color: '#2151f5', width: 2.5 },
      itemStyle: { color: '#2151f5' },
      areaStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
          { offset: 0, color: 'rgba(33, 81, 245, 0.2)' },
          { offset: 1, color: 'rgba(33, 81, 245, 0)' },
        ]),
      },
    },
    {
      type: 'line',
      markLine: {
        silent: true,
        symbol: 'none',
        data: [{ yAxis: sequentialProgressRate }],
        lineStyle: { color: '#ffd166', type: 'dashed', width: 1 },
        label: {
          formatter: '序时进度 {c}%',
          color: '#ffd166',
          fontSize: 10,
          position: 'insideEndTop',
        },
      },
    },
  ],
  animationEasing: 'cubicOut',
  animationDuration: 1000,
};

// Mini gauge option for budget execution card
function createMiniGaugeOption(value: number): EChartsOption {
  const color = getExecutionColor(value);
  return {
    backgroundColor: 'transparent',
    series: [{
      type: 'gauge',
      startAngle: 200,
      endAngle: -20,
      radius: '90%',
      center: ['50%', '55%'],
      min: 0,
      max: 100,
      splitNumber: 1,
      axisLine: {
        lineStyle: {
          width: 5,
          color: [
            [value / 100, color],
            [1, '#1e2a45'],
          ],
        },
      },
      pointer: { show: false },
      axisTick: { show: false },
      splitLine: { show: false },
      axisLabel: { show: false },
      detail: { show: false },
    }],
  };
}

// ============================================================
// Main Component
// ============================================================

const EconomicPanorama = memo(function EconomicPanorama() {
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState('budget');
  const [panelOpen, setPanelOpen] = useState(false);
  const [hoveredUnit, setHoveredUnit] = useState<Unit | null>(null);
  const [mapScale, setMapScale] = useState(1);
  const [flashUnitId, setFlashUnitId] = useState<string | null>(null);
  const [highlightedCategory, setHighlightedCategory] = useState<string | null>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);

  const selectedUnit = useMemo(() =>
    selectedUnitId ? getUnitById(selectedUnitId) ?? null : null,
    [selectedUnitId],
  );

  const stats = useMemo(() => getAggregateStats(), []);

  // Tabs for side panel
  const tabs = useMemo(() => [
    {
      id: 'budget',
      label: '预算执行与预决算',
      content: selectedUnitId ? <TabBudgetExecution unitId={selectedUnitId} /> : null,
    },
    {
      id: 'structure',
      label: '经费结构与趋势',
      content: selectedUnitId ? <TabExpenditureStructure unitId={selectedUnitId} /> : null,
    },
    {
      id: 'projects',
      label: '项目与部门',
      content: selectedUnitId ? <TabProjectsDepartments unitId={selectedUnitId} /> : null,
    },
  ], [selectedUnitId]);

  // Handlers
  const handleUnitClick = useCallback((unit: Unit) => {
    setFlashUnitId(unit.id);
    setTimeout(() => setFlashUnitId(null), 400);
    setSelectedUnitId(unit.id);
    setActiveTab('budget');
    setPanelOpen(true);
  }, []);

  const handleUnitHover = useCallback((unit: Unit | null) => {
    setHoveredUnit(unit);
  }, []);

  const handleClosePanel = useCallback(() => {
    setPanelOpen(false);
    setHighlightedCategory(null);
  }, []);

  const handlePieSectorClick = useCallback((params: any) => {
    const categoryName = params?.name as string;
    if (!categoryName) return;

    setHighlightedCategory(categoryName);

    // Find top unit by this category
    const topUnits = getTopUnitsByCategory(categoryName);
    if (topUnits.length > 0) {
      const topUnit = topUnits[0];
      // Flash and select after delay
      setTimeout(() => {
        setSelectedUnitId(topUnit.unit.id);
        setActiveTab('structure');
        setPanelOpen(true);
      }, 300);
    }

    // Clear highlight after animation
    setTimeout(() => setHighlightedCategory(null), 2000);
  }, []);

  const handleProjectClick = useCallback((project: ProjectItem) => {
    setSelectedUnitId(project.unitId);
    setActiveTab('projects');
    setPanelOpen(true);
  }, []);

  const handleZoomIn = useCallback(() => {
    setMapScale(prev => Math.min(prev + 0.25, 3));
  }, []);

  const handleZoomOut = useCallback(() => {
    setMapScale(prev => Math.max(prev - 0.25, 0.5));
  }, []);

  const handleResetView = useCallback(() => {
    setMapScale(1);
  }, []);

  // Map tooltip position
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  const handleMapMouseMove = useCallback((e: React.MouseEvent) => {
    if (mapContainerRef.current) {
      const rect = mapContainerRef.current.getBoundingClientRect();
      setTooltipPos({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  }, []);

  // Extended handler for pie click
  const handlePieEvents = useMemo(() => ({
    click: handlePieSectorClick,
  }), [handlePieSectorClick]);

  return (
    <div
      className="fixed inset-0 pt-[56px] flex"
      style={{ backgroundColor: '#02040a' }}
    >
      {/* LEFT PANEL — Overview */}
      <div className="flex flex-col gap-3 p-4 overflow-y-auto" style={{ width: '55%' }}>
        {/* Row 1: KPI Cards */}
        <div className="flex gap-3">
          {/* Card 1: 收入规模 */}
          <DataCard
            title="收入规模"
            value={12.8}
            suffix="亿"
            decimals={1}
            icon={Wallet}
            iconColor="#2151f5"
            trend={5.2}
            trendLabel="同比"
            sparkline={getRevenueSparkline()}
            sparklineColor="#2151f5"
            delay={0.4}
            className="flex-1 min-w-0"
          />

          {/* Card 2: 支出结构 */}
          <DataCard
            title="支出结构"
            value={9.4}
            suffix="亿"
            decimals={1}
            icon={BarChart3}
            iconColor="#00e5ff"
            trend={3.8}
            trendLabel="同比"
            sparkline={getExpenditureSparkline()}
            sparklineColor="#00e5ff"
            delay={0.46}
            className="flex-1 min-w-0"
          />

          {/* Card 3: 预算执行总进度 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.4,
              delay: 0.52,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            className="flex-1 min-w-0 bg-abyss border border-border-dim rounded-xl p-4 transition-all duration-300 hover:border-border hover:shadow-card"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-accent-green" />
                <span className="text-h4 text-text-primary">预算执行率</span>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="flex-1">
                <div className="font-mono text-mono-lg" style={{ color: getExecutionColor(stats.avgExecutionRate) }}>
                  {stats.avgExecutionRate}%
                </div>
                <div className="text-small mt-1">
                  <span className="text-text-secondary">序时进度: </span>
                  <span style={{ color: '#ffd166' }}>{sequentialProgressRate}%</span>
                </div>
                <div className="text-small">
                  <span className="text-text-secondary">偏差: </span>
                  <span style={{ color: stats.avgExecutionRate >= sequentialProgressRate ? '#00f5a0' : '#ff4757' }}>
                    {(stats.avgExecutionRate - sequentialProgressRate) >= 0 ? '+' : ''}
                    {(stats.avgExecutionRate - sequentialProgressRate).toFixed(1)}%
                  </span>
                </div>
              </div>
              <div className="w-[60px] h-[36px]">
                <ReactEChartsCore
                  echarts={echarts}
                  option={createMiniGaugeOption(stats.avgExecutionRate)}
                  style={{ width: '100%', height: '100%' }}
                />
              </div>
            </div>
          </motion.div>

          {/* Card 4: 三公经费 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.4,
              delay: 0.58,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            className="flex-1 min-w-0 bg-abyss border border-border-dim rounded-xl p-4 transition-all duration-300 hover:border-border hover:shadow-card"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-accent-yellow" />
                <span className="text-h4 text-text-primary">三公经费</span>
              </div>
            </div>
            <div className="font-mono text-mono-lg" style={{ color: '#ffd166' }}>
              {stats.threePublicRate}%
            </div>
            <div className="flex items-center gap-1 mt-1">
              <span className="text-small text-accent-green">↓ 8.3%</span>
              <span className="text-small text-text-tertiary">同比压减</span>
            </div>
            <div className="text-small text-text-tertiary mt-1">
              公务车: 45万 | 接待: 12万 | 出国: 0
            </div>
          </motion.div>
        </div>

        {/* Row 2: Charts */}
        <div className="flex gap-3">
          {/* Panel A: Expenditure Pie */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.5,
              delay: 0.6,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            className="flex-1 bg-abyss border border-border-dim rounded-xl p-5"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-h3 text-text-primary">全厅支出结构</h3>
              <span className="text-small text-text-tertiary bg-surface px-2 py-0.5 rounded">
                2025年度
              </span>
            </div>
            <div className="h-[220px]">
              <ReactEChartsCore
                echarts={echarts}
                option={expenditurePieOption}
                style={{ width: '100%', height: '100%' }}
                onEvents={handlePieEvents}
              />
            </div>
            {/* Legend */}
            <div className="flex justify-center gap-4 mt-2">
              {aggregateExpenditure.map(item => (
                <div key={item.name} className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-small text-text-secondary">{item.name}</span>
                  <span className="text-small text-text-tertiary">
                    {((item.value / aggregateExpenditure.reduce((s, i) => s + i.value, 0)) * 100).toFixed(0)}%
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Panel B: Budget Execution Trend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.5,
              delay: 0.7,
              ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
            }}
            className="flex-1 bg-abyss border border-border-dim rounded-xl p-5"
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-h3 text-text-primary">预算执行趋势</h3>
              <span className="text-small text-text-tertiary bg-surface px-2 py-0.5 rounded">
                近12个月
              </span>
            </div>
            <div className="h-[220px]">
              <ReactEChartsCore
                echarts={echarts}
                option={executionTrendOption}
                style={{ width: '100%', height: '100%' }}
              />
            </div>
          </motion.div>
        </div>

        {/* Row 3: Key Projects Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{
            duration: 0.5,
            delay: 0.8,
            ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
          }}
          className="bg-abyss border border-border-dim rounded-xl p-5 flex-1 min-h-0"
        >
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-3">
              <h3 className="text-h3 text-text-primary">当年重点项目</h3>
              <span className="text-small text-text-tertiary bg-surface px-2 py-0.5 rounded">
                共 {allProjects.length} 个项目
              </span>
            </div>
            <span className="text-small text-text-link flex items-center gap-0.5 cursor-pointer hover:underline">
              查看全部 <ChevronRight className="w-3.5 h-3.5" />
            </span>
          </div>
          <div className="overflow-y-auto" style={{ maxHeight: 'calc(100% - 40px)' }}>
            <table className="w-full">
              <thead>
                <tr className="text-small text-text-secondary border-b border-border-dim">
                  <th className="text-left py-2 px-2 font-medium">项目名称</th>
                  <th className="text-left py-2 px-2 font-medium">承担单位</th>
                  <th className="text-right py-2 px-2 font-medium">预算(万元)</th>
                  <th className="text-right py-2 px-2 font-medium">执行(万元)</th>
                  <th className="text-left py-2 px-2 font-medium w-[140px]">执行进度</th>
                  <th className="text-left py-2 px-2 font-medium">状态</th>
                </tr>
              </thead>
              <tbody>
                {allProjects.slice(0, 8).map((project, i) => (
                  <motion.tr
                    key={project.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3, delay: 0.8 + i * 0.04 }}
                    className="border-b border-border-dim hover:bg-surface cursor-pointer transition-colors duration-150"
                    onClick={() => handleProjectClick(project)}
                  >
                    <td className="py-2.5 px-2 text-small text-text-primary max-w-[180px] truncate">
                      {project.name}
                    </td>
                    <td className="py-2.5 px-2 text-small text-text-secondary">
                      {project.unitName}
                    </td>
                    <td className="py-2.5 px-2 text-mono-sm text-text-primary text-right">
                      {project.budget.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2 text-mono-sm text-text-primary text-right">
                      {project.executed.toLocaleString()}
                    </td>
                    <td className="py-2.5 px-2">
                      <div className="flex items-center gap-2">
                        <div className="w-[80px] h-1.5 bg-surface rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{
                              width: `${project.progress}%`,
                              backgroundColor: project.status === 'normal' ? '#00f5a0' : project.status === 'warning' ? '#ffd166' : '#ff4757',
                            }}
                          />
                        </div>
                        <span className="text-mono-sm text-text-secondary">{project.progress}%</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-2">
                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-1.5 h-1.5 rounded-full"
                          style={{
                            backgroundColor: project.status === 'normal' ? '#00f5a0' : project.status === 'warning' ? '#ffd166' : '#ff4757',
                          }}
                        />
                        <span
                          className="text-small"
                          style={{
                            color: project.status === 'normal' ? '#00f5a0' : project.status === 'warning' ? '#ffd166' : '#ff4757',
                          }}
                        >
                          {project.statusLabel}
                        </span>
                      </div>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      {/* RIGHT PANEL — Map */}
      <div
        ref={mapContainerRef}
        className="relative flex flex-col border-l border-border-dim"
        style={{ width: '45%' }}
        onMouseMove={handleMapMouseMove}
      >
        {/* Map Header */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex items-center justify-between px-4 py-3 border-b border-border-dim"
        >
          <h3 className="text-h3 text-text-primary">单位分布图</h3>
          <div className="flex items-center gap-3">
            {/* Legend */}
            <div className="flex items-center gap-3 mr-2">
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-accent-green" />
                <span className="text-small text-text-secondary">正常</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-accent-yellow" />
                <span className="text-small text-text-secondary">预警</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-accent-red" />
                <span className="text-small text-text-secondary">告警</span>
              </div>
            </div>
            {/* Zoom controls */}
            <button
              onClick={handleZoomIn}
              className="w-7 h-7 flex items-center justify-center rounded bg-surface hover:bg-panel transition-colors text-text-secondary hover:text-text-primary"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={handleZoomOut}
              className="w-7 h-7 flex items-center justify-center rounded bg-surface hover:bg-panel transition-colors text-text-secondary hover:text-text-primary"
            >
              <Minus className="w-4 h-4" />
            </button>
            <button
              onClick={handleResetView}
              className="w-7 h-7 flex items-center justify-center rounded bg-surface hover:bg-panel transition-colors text-text-secondary hover:text-text-primary"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </motion.div>

        {/* Map Area */}
        <div
          className="flex-1 relative overflow-hidden"
          style={{
            backgroundColor: '#0a0e1a',
            cursor: hoveredUnit ? 'pointer' : 'grab',
          }}
        >
          {/* Map SVG with transform */}
          <motion.div
            className="w-full h-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            style={{
              transform: `scale(${mapScale})`,
              transformOrigin: 'center center',
              transition: 'transform 0.3s cubic-bezier(0.16, 1, 0.3, 1)',
            }}
          >
            <ProvinceMap
              units={units.map(u => ({
                ...u,
                status: (() => {
                  const rate = economicData[u.id]?.budgetExecutionRate ?? 0;
                  if (rate >= sequentialProgressRate) return 'normal' as const;
                  if (rate >= sequentialProgressRate - 5) return 'warning' as const;
                  return 'critical' as const;
                })(),
              }))}
              selectedUnitId={selectedUnitId ?? undefined}
              onUnitClick={handleUnitClick}
              onUnitHover={handleUnitHover}
            />
          </motion.div>

          {/* Category highlight overlay */}
          <AnimatePresence>
            {highlightedCategory && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 pointer-events-none"
                style={{ backgroundColor: 'rgba(33, 81, 245, 0.05)' }}
              />
            )}
          </AnimatePresence>

          {/* Flash effect for clicked unit */}
          <AnimatePresence>
            {flashUnitId && (() => {
              const unit = getUnitById(flashUnitId);
              if (!unit) return null;
              return (
                <motion.div
                  initial={{ opacity: 0.8, scale: 1 }}
                  animate={{ opacity: 0, scale: 2.5 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.4 }}
                  className="absolute pointer-events-none"
                  style={{
                    left: `${unit.x}%`,
                    top: `${unit.y}%`,
                    width: 16,
                    height: 16,
                    marginLeft: -8,
                    marginTop: -8,
                    borderRadius: '50%',
                    border: '2px solid #00e5ff',
                  }}
                />
              );
            })()}
          </AnimatePresence>

          {/* Tooltip */}
          <AnimatePresence>
            {hoveredUnit && (() => {
              const ed = economicData[hoveredUnit.id];
              if (!ed) return null;
              const color = getExecutionColor(ed.budgetExecutionRate);
              return (
                <motion.div
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 5 }}
                  transition={{ duration: 0.15, delay: 0.1 }}
                  className="absolute z-20 pointer-events-none"
                  style={{
                    left: Math.min(tooltipPos.x + 16, (mapContainerRef.current?.clientWidth ?? 400) - 220),
                    top: tooltipPos.y - 10,
                    backgroundColor: '#0a0e1a',
                    border: '1px solid #2a3a5c',
                    borderRadius: '8px',
                    padding: '12px 16px',
                    boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
                    minWidth: 180,
                  }}
                >
                  <div className="text-h4 text-text-primary font-medium mb-2">
                    {hoveredUnit.name}
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-small text-text-secondary">预算执行率</span>
                      <span className="text-data-sm font-medium" style={{ color }}>
                        {ed.budgetExecutionRate}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-small text-text-secondary">在岗人数</span>
                      <span className="text-mono-sm text-text-primary">{ed.personnelCount}人</span>
                    </div>
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-small text-text-secondary">重点项目</span>
                      <span className="text-mono-sm text-text-primary">{ed.keyProjects}个</span>
                    </div>
                  </div>
                  <div className="mt-2 pt-2 border-t border-border-dim">
                    <span className="text-small text-text-link">展开详情 →</span>
                  </div>
                </motion.div>
              );
            })()}
          </AnimatePresence>

          {/* Data update timestamp */}
          <div className="absolute bottom-3 right-3 text-small text-text-tertiary">
            数据更新于 14:30
          </div>
        </div>
      </div>

      {/* SIDE PANEL */}
      <SidePanel
        isOpen={panelOpen}
        unit={selectedUnit}
        tabs={tabs}
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onClose={handleClosePanel}
      />
    </div>
  );
});

export default EconomicPanorama;
