import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router';
import {
  TrendingUp,
  BarChart3,
  Map,
  Users,
  ArrowRight,
} from 'lucide-react';
import { panoramaOverview } from '@/data/mockData';

const easeOut = [0.16, 1, 0.3, 1] as [number, number, number, number];

const panoramaCards = [
  {
    id: 'economic',
    title: '经济运行全景',
    subtitle: '预算执行 · 预决算对比 · 项目运行 · 经费趋势',
    icon: TrendingUp,
    iconColor: '#00f5a0',
    iconBorderColor: 'rgba(0,245,160,0.2)',
    accentColor: '#00f5a0',
    route: '/panorama/economic',
    stat: 87.3,
    statSuffix: '%',
    statLabel: '平均执行率',
    trend: panoramaOverview.economic.trend,
  },
  {
    id: 'financial',
    title: '财务全景',
    subtitle: '资产负债率 · 流动比率 · 收入费用率 · 跨单位对比',
    icon: BarChart3,
    iconColor: '#2151f5',
    iconBorderColor: 'rgba(33,81,245,0.2)',
    accentColor: '#2151f5',
    route: '/panorama/financial',
    stat: 38.2,
    statSuffix: '%',
    statLabel: '平均资产负债率',
    trend: panoramaOverview.financial.trend,
  },
  {
    id: 'asset',
    title: '资产全景',
    subtitle: '装备分布 · 应急物资 · 办公设备 · 资产热力',
    icon: Map,
    iconColor: '#00e5ff',
    iconBorderColor: 'rgba(0,229,255,0.2)',
    accentColor: '#00e5ff',
    route: '/panorama/asset',
    stat: 4285,
    statSuffix: '万',
    statLabel: '资产总值',
    trend: panoramaOverview.asset.trend.map(v => v / 1000),
  },
  {
    id: 'personnel',
    title: '人员结构与配置全景',
    subtitle: '编制配置 · 年龄结构 · 重点岗位 · 跨单位对比',
    icon: Users,
    iconColor: '#a855f7',
    iconBorderColor: 'rgba(168,85,247,0.2)',
    accentColor: '#a855f7',
    route: '/panorama/personnel',
    stat: 94.6,
    statSuffix: '%',
    statLabel: '整体配置率',
    trend: panoramaOverview.personnel.trend,
  },
];

function MiniSparkline({ data, color, isHovered }: { data: number[]; color: string; isHovered: boolean }) {
  if (data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const w = 280;
  const h = 40;
  const padding = 4;
  const points = data.map((v, i) => ({
    x: padding + (i / (data.length - 1)) * (w - padding * 2),
    y: padding + h - padding * 2 - ((v - min) / range) * (h - padding * 2),
  }));
  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${points[points.length - 1].x} ${h} L ${points[0].x} ${h} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full flex-shrink-0" style={{ height: 36 }} preserveAspectRatio="none">
      <defs>
        <linearGradient id={`spark-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.25" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={areaPath} fill={`url(#spark-${color.replace('#', '')})`} />
      <path d={linePath} fill="none" stroke={color} strokeWidth={isHovered ? 3 : 2} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function PanoramaCard({ card, index }: { card: typeof panoramaCards[number]; index: number }) {
  const navigate = useNavigate();
  const [isHovered, setIsHovered] = useState(false);
  const Icon = card.icon;

  const handleClick = useCallback(() => {
    navigate(card.route);
  }, [navigate, card.route]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 24, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.5 + index * 0.08, ease: easeOut }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      className="relative rounded-xl p-5 cursor-pointer overflow-hidden transition-all duration-300 flex flex-col"
      style={{
        width: 360,
        height: 210,
        backgroundColor: '#050810',
        border: `1px solid ${isHovered ? '#3d5296' : '#1e2a45'}`,
        transform: isHovered ? 'translateY(-4px)' : 'translateY(0)',
        boxShadow: isHovered ? `0 12px 40px ${card.accentColor}18` : 'none',
      }}
    >
      <div
        className="absolute inset-0 transition-opacity duration-300 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 50% 50%, ${card.accentColor}08, transparent 70%)`,
          opacity: isHovered ? 1 : 0,
        }}
      />

      <div className="relative flex items-start justify-between flex-shrink-0">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: '#101628', border: `1px solid ${card.iconBorderColor}` }}>
          <Icon className="w-5 h-5" style={{ color: card.iconColor }} />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-75" style={{ backgroundColor: card.accentColor }} />
            <span className="relative inline-flex rounded-full h-2 w-2" style={{ backgroundColor: card.accentColor }} />
          </span>
          <span className="text-[11px] text-text-tertiary">实时</span>
        </div>
      </div>

      <h3 className="relative text-h3 text-text-primary mt-4 leading-tight flex-shrink-0">{card.title}</h3>
      <p className="relative text-small text-text-secondary mt-1.5 line-clamp-1 flex-shrink-0">{card.subtitle}</p>

      <div className="relative mt-3 flex-shrink-0">
        <MiniSparkline data={card.trend} color={card.accentColor} isHovered={isHovered} />
      </div>

      <div className="relative flex items-center justify-between mt-auto pt-2 flex-shrink-0">
        <div className="flex items-baseline gap-1.5">
          <span className="font-mono text-mono-md font-semibold" style={{ color: card.accentColor }}>
            {card.stat.toLocaleString()}{card.statSuffix}
          </span>
          <span className="text-[12px] text-text-tertiary">{card.statLabel}</span>
        </div>
        <span className="flex items-center gap-1 text-[12px] transition-transform duration-200" style={{ color: '#4f8af7', transform: isHovered ? 'translateX(3px)' : 'translateX(0)' }}>
          进入全景 <ArrowRight className="w-3.5 h-3.5" />
        </span>
      </div>
    </motion.div>
  );
}

export default function Home() {
  return (
    <div className="h-full w-full flex flex-col relative overflow-hidden" style={{ backgroundColor: '#02040a' }}>
      {/* Background layers */}
      <div className="absolute inset-0 z-0 pointer-events-none">
        <img src="/hero-bg-particles.jpg" alt="" className="absolute inset-0 w-full h-full object-cover opacity-35" />
        <div className="absolute inset-0 grid-overlay opacity-35" />
        <div className="absolute inset-0 vignette" />
      </div>

      {/* Main content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center min-h-0">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2, ease: easeOut }}
          className="text-center flex-shrink-0 mb-6"
        >
          <h1 className="text-h1 text-text-primary font-bold" style={{ fontSize: 'clamp(28px, 3.2vw, 40px)' }}>
            警保数据资源中心
          </h1>
          <div className="w-20 h-0.5 mx-auto mt-3" style={{ background: 'linear-gradient(90deg, #2151f5, #00e5ff)' }} />
          <p className="text-body text-text-secondary mt-4 tracking-[0.06em]">
            一屏观全厅 · 一键达基层 · 一数知全局
          </p>
        </motion.div>

        {/* Card Grid */}
        <div className="grid grid-cols-2 gap-5 flex-shrink-0">
          {panoramaCards.map((card, index) => (
            <PanoramaCard key={card.id} card={card} index={index} />
          ))}
        </div>
      </div>
    </div>
  );
}
