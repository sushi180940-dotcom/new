import { memo, useState, useCallback } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { motion } from 'framer-motion';
import { X, Plus } from 'lucide-react';
import { units } from '@/data/mockData';
import { radarMetrics, getRadarData } from './dataHelpers';

const unitColors = ['#2151f5', '#00e5ff', '#a855f7', '#00f5a0', '#f97316'];

interface CrossUnitComparisonProps {
  currentUnitId: string;
}

export const CrossUnitComparison = memo(function CrossUnitComparison({ currentUnitId }: CrossUnitComparisonProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([currentUnitId]);
  const [showAddDropdown, setShowAddDropdown] = useState(false);
  const [chartMode, setChartMode] = useState<'radar' | 'bar'>('radar');

  const toggleUnit = (id: string) => {
    setSelectedIds(prev => {
      if (prev.includes(id)) return prev.filter(u => u !== id);
      if (prev.length >= 5) return prev;
      return [...prev, id];
    });
  };

  const removeUnit = (id: string) => {
    setSelectedIds(prev => prev.filter(u => u !== id));
  };

  const radarData = getRadarData(selectedIds.length > 0 ? selectedIds : [currentUnitId]);

  const radarOption: EChartsOption = {
    tooltip: {
      trigger: 'item',
      backgroundColor: '#0a0e1a',
      borderColor: '#2a3a5c',
      textStyle: { color: '#d8dce6', fontSize: 12 },
    },
    legend: {
      bottom: 0,
      data: radarData.map(d => d.name),
      textStyle: { color: '#6b7fa3', fontSize: 11 },
      itemWidth: 12, itemHeight: 12, itemGap: 16,
    },
    radar: {
      indicator: radarMetrics.map(m => ({ name: m, max: m === '平均年龄' ? 55 : m === '警保岗位人员占比' ? 25 : 100 })),
      shape: 'polygon',
      splitNumber: 4,
      axisName: { color: '#6b7fa3', fontSize: 11 },
      splitLine: { lineStyle: { color: '#1e2a45' } },
      splitArea: { show: true, areaStyle: { color: ['rgba(5,8,16,0.5)', 'rgba(5,8,16,0.3)'] } },
      axisLine: { lineStyle: { color: '#1e2a45' } },
    },
    series: [{
      type: 'radar',
      data: radarData.map((d, i) => ({
        name: d.name,
        value: d.value,
        areaStyle: { color: unitColors[i % unitColors.length], opacity: 0.15 },
        lineStyle: { color: unitColors[i % unitColors.length], width: 2 },
        itemStyle: { color: unitColors[i % unitColors.length] },
        symbol: 'circle',
        symbolSize: 6,
      })),
      animationDuration: 600,
    }],
  };

  const barOption: EChartsOption = {
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#0a0e1a',
      borderColor: '#2a3a5c',
      textStyle: { color: '#d8dce6', fontSize: 12 },
    },
    legend: {
      bottom: 0,
      data: radarData.map(d => d.name),
      textStyle: { color: '#6b7fa3', fontSize: 11 },
      itemWidth: 12, itemHeight: 12, itemGap: 16,
    },
    grid: { left: 80, right: 20, top: 10, bottom: 40 },
    xAxis: {
      type: 'value',
      axisLabel: { color: '#3d4f70', fontSize: 10 },
      axisLine: { show: false },
      splitLine: { lineStyle: { color: '#1e2a45', type: 'dashed' } },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'category',
      data: radarMetrics,
      axisLabel: { color: '#6b7fa3', fontSize: 11 },
      axisLine: { lineStyle: { color: '#1e2a45' } },
      axisTick: { show: false },
    },
    series: radarData.map((d, i) => ({
      name: d.name,
      type: 'bar',
      data: d.value,
      itemStyle: { color: unitColors[i % unitColors.length], borderRadius: [0, 4, 4, 0] },
      barWidth: 12,
      label: { show: true, position: 'right', color: '#6b7fa3', fontSize: 10, formatter: (p: unknown) => Number((p as { value: unknown }).value).toFixed(1) },
      animationDuration: 400,
      animationDelay: (idx: number) => (idx as number) * 50,
    })),
  };

  const getOption = useCallback(() => chartMode === 'radar' ? radarOption : barOption, [chartMode, radarOption, barOption]);

  // Comparison table data
  const tableMetrics = radarMetrics;

  return (
    <div className="space-y-4">
      {/* Unit selector chips */}
      <div className="flex flex-wrap items-center gap-2">
        {selectedIds.map((id, i) => {
          const unit = units.find(u => u.id === id);
          if (!unit) return null;
          return (
            <motion.div
              key={id}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-small"
              style={{ borderColor: unitColors[i % unitColors.length], color: '#d8dce6', backgroundColor: `${unitColors[i % unitColors.length]}15` }}
            >
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: unitColors[i % unitColors.length] }} />
              {unit.name}
              <button onClick={() => removeUnit(id)} className="ml-1 hover:text-accent-red transition-colors">
                <X className="w-3 h-3" />
              </button>
            </motion.div>
          );
        })}
        {selectedIds.length < 5 && (
          <div className="relative">
            <button
              onClick={() => setShowAddDropdown(v => !v)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-border text-text-secondary hover:text-text-primary hover:border-border-bright transition-colors text-small"
            >
              <Plus className="w-3 h-3" />添加单位
            </button>
            {showAddDropdown && (
              <div className="absolute top-full left-0 mt-1 bg-deep border border-border rounded-lg shadow-lg z-20 py-1 min-w-[140px] max-h-48 overflow-auto">
                {units.filter(u => !selectedIds.includes(u.id)).map(u => (
                  <button
                    key={u.id}
                    className="w-full text-left px-3 py-1.5 text-small text-text-secondary hover:bg-surface hover:text-text-primary transition-colors"
                    onClick={() => { toggleUnit(u.id); setShowAddDropdown(false); }}
                  >
                    {u.name}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        <div className="flex-1" />
        <button
          onClick={() => setChartMode(m => m === 'radar' ? 'bar' : 'radar')}
          className="text-small text-text-link hover:underline"
        >
          切换为{chartMode === 'radar' ? '平行条形图' : '雷达图'}
        </button>
      </div>

      {/* Chart */}
      <div className="bg-abyss border border-border-dim rounded-xl p-4">
        <ReactEChartsCore
          option={getOption()}
          style={{ height: chartMode === 'radar' ? 380 : 320, width: '100%' }}
          opts={{ renderer: 'canvas' }}
        />
      </div>

      {/* Comparison table */}
      <div className="bg-abyss border border-border-dim rounded-xl overflow-auto">
        <table className="w-full text-small">
          <thead>
            <tr className="bg-surface" style={{ height: 36 }}>
              <th className="text-left px-3 text-text-secondary font-semibold sticky left-0 bg-surface">指标</th>
              {radarData.map((d, i) => (
                <th key={d.name} className="text-center px-3 font-semibold" style={{ color: unitColors[i % unitColors.length] }}>{d.name}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {tableMetrics.map((metric, mi) => (
              <tr key={metric} className="border-b border-border-dim" style={{ height: 36 }}>
                <td className="px-3 text-text-secondary font-medium sticky left-0 bg-abyss">{metric}</td>
                {radarData.map((d) => {
                  const val = d.value[mi];
                  const isGood = mi === 0 ? val >= 95 : mi === 1 ? val <= 5 : mi === 2 ? val >= 35 && val <= 40 : mi === 3 ? val >= 70 : mi === 4 ? val >= 90 : val >= 10;
                  return (
                    <td key={d.name} className="px-3 text-center font-mono" style={{ color: isGood ? '#00f5a0' : '#ff4757' }}>
                      {typeof val === 'number' ? val.toFixed(1) : val}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
});
