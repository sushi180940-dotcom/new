import { memo, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Award } from 'lucide-react';
import { getPersonnelDetailList } from './dataHelpers';
import type { Unit } from '@/data/mockData';

interface PersonnelPopupProps {
  unit: Unit | null;
  onClose: () => void;
}

export const PersonnelPopup = memo(function PersonnelPopup({ unit, onClose }: PersonnelPopupProps) {
  const [search, setSearch] = useState('');
  const [eduFilter, setEduFilter] = useState('全部');

  const allList = useMemo(() => unit ? getPersonnelDetailList(unit.id) : [], [unit]);

  const filtered = useMemo(() => {
    return allList.filter(p => {
      const matchSearch = !search || p.name.includes(search);
      const matchEdu = eduFilter === '全部' || p.education === eduFilter;
      return matchSearch && matchEdu;
    });
  }, [allList, search, eduFilter]);

  // Pagination
  const [page, setPage] = useState(1);
  const pageSize = 15;
  const totalPages = Math.ceil(filtered.length / pageSize);
  const paginated = filtered.slice((page - 1) * pageSize, page * pageSize);

  const eduOptions = ['全部', '博士', '硕士', '本科', '大专'];

  if (!unit) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ backgroundColor: 'rgba(5,8,16,0.85)', backdropFilter: 'blur(4px)' }}
        onClick={onClose}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          className="bg-abyss border border-border rounded-xl overflow-hidden"
          style={{ maxWidth: 800, width: '90vw', maxHeight: '70vh' }}
          onClick={e => e.stopPropagation()}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-border-dim">
            <div>
              <h2 className="text-h2 text-text-primary">{unit.name} <span className="text-h4 text-text-secondary">人员明细</span></h2>
            </div>
            <button onClick={onClose} className="p-1.5 rounded-md hover:bg-surface transition-colors">
              <X className="w-5 h-5 text-text-secondary" />
            </button>
          </div>

          {/* Filters */}
          <div className="flex items-center gap-3 px-6 py-3 border-b border-border-dim">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2.5 top-1/2 -translate-y-1/2 text-text-tertiary" />
              <input
                type="text"
                placeholder="搜索姓名..."
                value={search}
                onChange={e => { setSearch(e.target.value); setPage(1); }}
                className="pl-8 pr-3 py-1.5 rounded-md bg-surface border border-border text-text-primary text-small placeholder:text-text-tertiary focus:outline-none focus:border-border-bright w-[180px]"
              />
            </div>
            <select
              value={eduFilter}
              onChange={e => { setEduFilter(e.target.value); setPage(1); }}
              className="px-3 py-1.5 rounded-md bg-surface border border-border text-text-primary text-small focus:outline-none focus:border-border-bright"
            >
              {eduOptions.map(e => <option key={e} value={e}>{e === '全部' ? '全部学历' : e}</option>)}
            </select>
            <span className="text-small text-text-tertiary ml-auto">共 {filtered.length} 人</span>
          </div>

          {/* Table */}
          <div className="overflow-auto" style={{ maxHeight: 'calc(70vh - 160px)' }}>
            <table className="w-full text-small">
              <thead className="sticky top-0">
                <tr className="bg-surface">
                  <th className="text-left px-4 py-2 text-text-secondary font-semibold">姓名</th>
                  <th className="text-left px-4 py-2 text-text-secondary font-semibold">职务/岗位</th>
                  <th className="text-center px-4 py-2 text-text-secondary font-semibold">年龄</th>
                  <th className="text-center px-4 py-2 text-text-secondary font-semibold">学历</th>
                  <th className="text-left px-4 py-2 text-text-secondary font-semibold">专业</th>
                  <th className="text-center px-4 py-2 text-text-secondary font-semibold">持证情况</th>
                  <th className="text-center px-4 py-2 text-text-secondary font-semibold">入职年限</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((p, i) => (
                  <motion.tr
                    key={`${p.name}-${i}`}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.02 }}
                    className="border-b border-border-dim hover:bg-surface transition-colors"
                    style={{ height: 40 }}
                  >
                    <td className="px-4 text-text-primary font-medium">{p.name}</td>
                    <td className="px-4 text-text-secondary">{p.position}</td>
                    <td className="px-4 text-center text-text-secondary font-mono">{p.age}</td>
                    <td className="px-4 text-center">
                      <span className="px-1.5 py-0.5 rounded-sm text-[10px] font-medium" style={{
                        backgroundColor: p.education === '博士' ? 'rgba(33,81,245,0.2)' : p.education === '硕士' ? 'rgba(0,229,255,0.15)' : p.education === '本科' ? 'rgba(0,245,160,0.15)' : 'rgba(255,209,102,0.15)',
                        color: p.education === '博士' ? '#4f8af7' : p.education === '硕士' ? '#00e5ff' : p.education === '本科' ? '#00f5a0' : '#ffd166',
                      }}>
                        {p.education}
                      </span>
                    </td>
                    <td className="px-4 text-text-secondary">{p.major}</td>
                    <td className="px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Award className="w-3 h-3" style={{ color: p.certCount >= 2 ? '#00f5a0' : p.certCount >= 1 ? '#ffd166' : '#ff4757' }} />
                        <span className="font-mono" style={{ color: p.certCount >= 2 ? '#00f5a0' : p.certCount >= 1 ? '#ffd166' : '#ff4757' }}>
                          {p.certCount}证
                        </span>
                      </div>
                    </td>
                    <td className="px-4 text-center text-text-secondary font-mono">{p.yearsOfService}年</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 px-6 py-3 border-t border-border-dim">
              <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 rounded-md bg-surface text-small text-text-secondary hover:text-text-primary disabled:opacity-30">上一页</button>
              <span className="text-small text-text-secondary">{page} / {totalPages}</span>
              <button onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="px-3 py-1 rounded-md bg-surface text-small text-text-secondary hover:text-text-primary disabled:opacity-30">下一页</button>
            </div>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
});
