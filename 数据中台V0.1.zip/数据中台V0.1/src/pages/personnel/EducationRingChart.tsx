import { memo, useCallback } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { getEducationData, getBachelorAbovePct } from './dataHelpers';

const educationColors = ['#2151f5', '#00e5ff', '#00f5a0', '#ffd166', '#3d4f70'];

export const EducationRingChart = memo(function EducationRingChart({ unitId }: { unitId?: string }) {
  const data = getEducationData(unitId);
  const bachelorAbove = getBachelorAbovePct(unitId);

  const getOption = useCallback((): EChartsOption => {
    return {
      tooltip: {
        trigger: 'item',
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: { color: '#d8dce6', fontSize: 12 },
        formatter: (params: unknown) => {
          const p = params as { name: string; value: number; percent: number };
          return `<div style="font-weight:600">${p.name}</div><div>${p.value}人 (${p.percent.toFixed(1)}%)</div>`;
        },
      },
      series: [
        {
          type: 'pie',
          radius: ['55%', '75%'],
          center: ['50%', '50%'],
          avoidLabelOverlap: false,
          itemStyle: {
            borderRadius: 4,
            borderColor: '#0a0e1a',
            borderWidth: 2,
          },
          label: { show: false },
          emphasis: {
            label: { show: true, fontSize: 14, fontWeight: 'bold', color: '#d8dce6' },
            itemStyle: { shadowBlur: 10, shadowColor: 'rgba(0,0,0,0.5)' },
          },
          labelLine: { show: false },
          data: data.map((d, i) => ({
            name: d.name,
            value: d.value,
            itemStyle: { color: educationColors[i] },
          })),
          animationType: 'expansion',
          animationDuration: 800,
        },
      ],
      graphic: {
        type: 'group',
        left: 'center',
        top: 'center',
        children: [
          {
            type: 'text',
            style: {
              text: `本科以上`,
              fill: '#6b7fa3',
              fontSize: 11,
              align: 'center',
              verticalAlign: 'top',
            },
            top: -20,
          },
          {
            type: 'text',
            style: {
              text: `${bachelorAbove}%`,
              fill: '#00f5a0',
              fontSize: 18,
              fontWeight: 'bold',
              align: 'center',
              verticalAlign: 'bottom',
            },
            top: 5,
          },
        ],
      },
    };
  }, [data, bachelorAbove]);

  return (
    <div className="bg-abyss border border-border-dim rounded-xl p-5 flex-1">
      <h3 className="text-h3 text-text-primary mb-2">学历结构</h3>
      <ReactEChartsCore
        option={getOption()}
        style={{ height: 210, width: '100%' }}
        opts={{ renderer: 'canvas' }}
      />
      {/* Legend */}
      <div className="flex flex-wrap gap-x-3 gap-y-1 justify-center mt-1">
        {data.map((d, i) => (
          <div key={d.name} className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: educationColors[i] }} />
            <span className="text-small text-text-secondary">{d.name} {d.pct}%</span>
          </div>
        ))}
      </div>
    </div>
  );
});
