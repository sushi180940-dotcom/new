import { memo, useCallback } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import type { EChartsOption } from 'echarts';
import { categoryYears, getCategoryStackedData } from './dataHelpers';

export const CategoryStackedBarChart = memo(function CategoryStackedBarChart() {
  const cats = getCategoryStackedData();

  const getOption = useCallback((): EChartsOption => {
    return {
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        textStyle: { color: '#d8dce6', fontSize: 12 },
      },
      legend: {
        data: ['行政编制', '事业编制', '工勤编制', '聘用人员'],
        bottom: 0,
        textStyle: { color: '#6b7fa3', fontSize: 11 },
        itemWidth: 10, itemHeight: 10, itemGap: 16,
      },
      grid: { left: 40, right: 10, top: 10, bottom: 30 },
      xAxis: {
        type: 'category',
        data: categoryYears,
        axisLabel: { color: '#6b7fa3', fontSize: 11 },
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisTick: { show: false },
      },
      yAxis: {
        type: 'value',
        axisLabel: { color: '#3d4f70', fontSize: 10 },
        axisLine: { show: false },
        splitLine: { lineStyle: { color: '#1e2a45', type: 'dashed' } },
        axisTick: { show: false },
      },
      series: [
        {
          name: '行政编制',
          type: 'bar',
          stack: 'total',
          data: cats.administrative,
          itemStyle: { color: '#2151f5' },
          barWidth: 32,
          animationDuration: 500,
          animationDelay: (idx: number) => idx * 100,
        },
        {
          name: '事业编制',
          type: 'bar',
          stack: 'total',
          data: cats.technical,
          itemStyle: { color: '#00e5ff' },
          animationDuration: 500,
          animationDelay: (idx: number) => idx * 100 + 50,
        },
        {
          name: '工勤编制',
          type: 'bar',
          stack: 'total',
          data: cats.auxiliary,
          itemStyle: { color: '#a855f7' },
          animationDuration: 500,
          animationDelay: (idx: number) => idx * 100 + 100,
        },
        {
          name: '聘用人员',
          type: 'bar',
          stack: 'total',
          data: cats.contract,
          itemStyle: { color: '#ffd166' },
          animationDuration: 500,
          animationDelay: (idx: number) => idx * 100 + 150,
        },
      ],
    };
  }, [cats]);

  return (
    <div className="bg-abyss border border-border-dim rounded-xl p-5 flex-1">
      <h3 className="text-h3 text-text-primary mb-4">人员分类趋势 (近5年)</h3>
      <ReactEChartsCore
        option={getOption()}
        style={{ height: 220, width: '100%' }}
        opts={{ renderer: 'canvas' }}
      />
    </div>
  );
});
