import { memo, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp, CheckCircle2, AlertTriangle, XCircle } from 'lucide-react';
import { getKeyPositionData } from './dataHelpers';
import type { KeyPositionRow } from './dataHelpers';

interface PositionMatrixProps {
  unitId: string;
}

function StatusBadge({ status }: { status: KeyPositionRow['status'] }) {
  if (status === 'normal') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-small font-medium" style={{ backgroundColor: 'rgba(0,245,160,0.15)', color: '#00f5a0' }}>
        <CheckCircle2 className="w-3 h-3" />正常
      </span>
    );
  }
  if (status === 'warning') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-small font-medium" style={{ backgroundColor: 'rgba(255,209,102,0.15)', color: '#ffd166' }}>
        <AlertTriangle className="w-3 h-3" />关注
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-sm text-small font-medium" style={{ backgroundColor: 'rgba(255,71,87,0.15)', color: '#ff4757' }}>
      <XCircle className="w-3 h-3" />缺配
    </span>
  );
}

function MiniBar({ value, threshold }: { value: number; threshold: [number, number] }) {
  const color = value >= threshold[1] ? '#00f5a0' : value >= threshold[0] ? '#ffd166' : '#ff4757';
  return (
    <div className="h-1.5 rounded-full overflow-hidden flex-1" style={{ backgroundColor: '#1e2a45', maxWidth: 50 }}>
      <div className="h-full rounded-full transition-all duration-500" style={{ width: `${Math.min(100, value)}%`, backgroundColor: color }} />
    </div>
  );
}

export const PositionMatrix = memo(function PositionMatrix({ unitId }: PositionMatrixProps) {
  const positions = getKeyPositionData(unitId);
  const [expandedRow, setExpandedRow] = useState<number | null>(null);

  return (
    <div className="space-y-2">
      <div className="overflow-auto">
        <table className="w-full text-small">
          <thead>
            <tr className="bg-surface" style={{ height: 36 }}>
              <th className="text-left px-2 text-text-secondary font-semibold">岗位名称</th>
              <th className="text-center px-2 text-text-secondary font-semibold">应配</th>
              <th className="text-center px-2 text-text-secondary font-semibold">在岗</th>
              <th className="text-center px-2 text-text-secondary font-semibold">缺配</th>
              <th className="text-left px-2 text-text-secondary font-semibold">持证率</th>
              <th className="text-left px-2 text-text-secondary font-semibold">AB角覆盖</th>
              <th className="text-center px-2 text-text-secondary font-semibold">状态</th>
              <th className="w-8" />
            </tr>
          </thead>
          <tbody>
            {positions.map((pos, i) => {
              const shortage = pos.required - pos.actual;
              const isExpanded = expandedRow === i;
              const isCritical = pos.status === 'critical';
              return (
                <motion.tr
                  key={pos.title}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.05 }}
                  className="border-b border-border-dim cursor-pointer transition-colors hover:bg-surface"
                  style={{
                    height: 44,
                    backgroundColor: isCritical ? 'rgba(255,71,87,0.05)' : undefined,
                    borderLeft: isCritical ? '2px solid #ff4757' : '2px solid transparent',
                  }}
                  onClick={() => setExpandedRow(isExpanded ? null : i)}
                >
                  <td className="px-2 text-text-primary font-medium">{pos.title}</td>
                  <td className="px-2 text-center text-text-secondary font-mono">{pos.required}</td>
                  <td className="px-2 text-center font-mono" style={{ color: pos.actual < pos.required ? '#ff4757' : '#00f5a0' }}>{pos.actual}</td>
                  <td className="px-2 text-center font-mono" style={{ color: shortage > 0 ? '#ff4757' : '#3d4f70' }}>{shortage > 0 ? shortage : '-'}</td>
                  <td className="px-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-text-primary" style={{ fontSize: 11 }}>{pos.certRate}%</span>
                      <MiniBar value={pos.certRate} threshold={[70, 90]} />
                    </div>
                  </td>
                  <td className="px-2">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-text-primary" style={{ fontSize: 11 }}>{pos.abCoverage}%</span>
                      <MiniBar value={pos.abCoverage} threshold={[50, 100]} />
                    </div>
                  </td>
                  <td className="px-2 text-center"><StatusBadge status={pos.status} /></td>
                  <td className="px-1">
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5 text-text-tertiary" /> : <ChevronDown className="w-3.5 h-3.5 text-text-tertiary" />}
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Expanded row detail */}
      <AnimatePresence>
        {expandedRow !== null && positions[expandedRow] && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="bg-surface rounded-lg p-4 overflow-hidden"
          >
            <h4 className="text-h4 text-text-primary mb-3">{positions[expandedRow].title} — 在岗人员</h4>
            {positions[expandedRow].staff.length === 0 ? (
              <p className="text-small text-accent-red">该岗位目前无在岗人员</p>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                {positions[expandedRow].staff.map((s, j) => (
                  <div key={j} className="flex items-center gap-3 bg-abyss rounded-md p-2 border border-border-dim">
                    <div className="w-8 h-8 rounded-full bg-accent-blue flex items-center justify-center text-white text-small font-bold">
                      {s.name[0]}
                    </div>
                    <div>
                      <div className="text-small text-text-primary font-medium">{s.name} · {s.age}岁</div>
                      <div className="text-small text-text-secondary">{s.abRole} · {s.certCount}证</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
});
