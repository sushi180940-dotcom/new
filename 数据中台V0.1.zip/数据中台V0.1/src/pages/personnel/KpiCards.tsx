import { memo } from 'react';
import { motion } from 'framer-motion';
import { Users, CheckCircle2, AlertTriangle } from 'lucide-react';
import CountUpNumber from '@/components/CountUpNumber';
import { getAllPersonnelSummary, getUnitMatrixData } from './dataHelpers';

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number];

export const KpiCards = memo(function KpiCards({ selectedUnitId }: { selectedUnitId?: string }) {
  const all = getAllPersonnelSummary();
  const matrixRows = getUnitMatrixData();

  const totalPersonnel = selectedUnitId
    ? (matrixRows.find(r => r.unit.id === selectedUnitId)?.totalPersonnel || 0)
    : all.totalPersonnel;
  const totalAuthorized = selectedUnitId
    ? (matrixRows.find(r => r.unit.id === selectedUnitId)?.authorizedPositions || 0)
    : all.authorizedPositions;
  const staffingRate = totalAuthorized ? (totalPersonnel / totalAuthorized * 100) : 0;
  const vacancyCount = totalAuthorized - totalPersonnel;
  const vacancyRate = totalAuthorized ? (vacancyCount / totalAuthorized * 100) : 0;

  // Top vacancy units
  const topVacancyUnits = [...matrixRows]
    .sort((a, b) => b.vacancyCount - a.vacancyCount)
    .slice(0, 3);

  return (
    <div className="grid grid-cols-3 gap-3">
      {/* Card 1: Total Personnel */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4, ease }}
        className="bg-abyss border border-border-dim rounded-xl p-4"
      >
        <div className="flex items-center gap-2 mb-2">
          <Users className="w-[18px] h-[18px] text-accent-blue" />
          <span className="text-small text-text-secondary">
            {selectedUnitId ? '单位在编人数' : '全厅在编人数'}
          </span>
        </div>
        <div className="text-data-md font-mono text-text-primary mb-1">
          <CountUpNumber end={totalPersonnel} suffix="人" className="font-mono text-data-md text-text-primary" />
        </div>
        {!selectedUnitId && (
          <div className="text-small text-text-tertiary">
            行政: {Math.round(all.totalPersonnel * 0.68)} | 事业: {Math.round(all.totalPersonnel * 0.23)} | 工勤: {Math.round(all.totalPersonnel * 0.09)}
          </div>
        )}
        <div className="flex items-center gap-1 mt-2">
          <span className="text-small text-accent-green">↑ 1.2%</span>
          <span className="text-small text-text-tertiary">同比</span>
        </div>
      </motion.div>

      {/* Card 2: Staffing Rate */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.46, ease }}
        className="bg-abyss border border-border-dim rounded-xl p-4"
      >
        <div className="flex items-center gap-2 mb-2">
          <CheckCircle2 className="w-[18px] h-[18px] text-accent-green" />
          <span className="text-small text-text-secondary">编制使用率</span>
        </div>
        <div className="text-data-md font-mono text-accent-green mb-1">
          <CountUpNumber end={staffingRate} decimals={1} suffix="%" className="font-mono text-data-md text-accent-green" />
        </div>
        <div className="text-small text-text-tertiary">
          {selectedUnitId ? '单位编制' : '全厅编制'}: {totalAuthorized}名
        </div>
        <div className="mt-2 flex items-center">
          <span className="px-2 py-0.5 rounded-sm text-small font-medium" style={{ backgroundColor: 'rgba(0,245,160,0.15)', color: '#00f5a0' }}>
            {staffingRate >= 95 ? '良好' : staffingRate >= 90 ? '正常' : '关注'}
          </span>
        </div>
      </motion.div>

      {/* Card 3: Vacancy Rate */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.52, ease }}
        className="bg-abyss border border-border-dim rounded-xl p-4"
      >
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-[18px] h-[18px] text-accent-yellow" />
          <span className="text-small text-text-secondary">空编数量/率</span>
        </div>
        <div className="text-data-md font-mono mb-1" style={{ color: vacancyRate > 5 ? '#ff4757' : vacancyRate > 2 ? '#ffd166' : '#00f5a0' }}>
          {vacancyCount}人 / <CountUpNumber end={vacancyRate} decimals={1} suffix="%" className="font-mono text-data-md" />
        </div>
        {!selectedUnitId && (
          <div className="text-small text-text-tertiary truncate">
            {topVacancyUnits.map(u => `${u.unit.name}(${u.vacancyCount})`).join(' ')}
          </div>
        )}
      </motion.div>
    </div>
  );
});
