// ============================================================
// Personnel Panorama — Data Transformation Helpers
// ============================================================

import { units, personnelData, type PersonnelData, type Unit } from '@/data/mockData';

// --- Age bracket keys ---
export const ageBrackets = ['<25', '25-29', '30-34', '35-39', '40-44', '45-49', '50-54', '55+'] as const;
export type AgeBracket = typeof ageBrackets[number];

// Map mockData ageStructure to age brackets (male/female estimate: 60/40 split)
export function getAgePyramidData(unitId?: string) {
  const data = unitId ? personnelData[unitId] : getAllPersonnelSummary();
  if (!data) return { male: [] as number[], female: [] as number[], total: 0 };

  const ages = data.ageStructure;
  // Split each bracket roughly 60% male / 40% female
  const male = [
    Math.round(ages.under25 * 0.6),
    Math.round(ages.age26to35 * 0.3),
    Math.round(ages.age26to35 * 0.3),
    Math.round(ages.age36to45 * 0.3),
    Math.round(ages.age36to45 * 0.3),
    Math.round(ages.age46to55 * 0.3),
    Math.round(ages.age46to55 * 0.3),
    Math.round(ages.over55 * 0.6),
  ];
  const female = [
    Math.round(ages.under25 * 0.4),
    Math.round(ages.age26to35 * 0.2),
    Math.round(ages.age26to35 * 0.2),
    Math.round(ages.age36to45 * 0.2),
    Math.round(ages.age36to45 * 0.2),
    Math.round(ages.age46to55 * 0.2),
    Math.round(ages.age46to55 * 0.2),
    Math.round(ages.over55 * 0.4),
  ];
  const total = male.reduce((a, b) => a + b, 0) + female.reduce((a, b) => a + b, 0);
  return { male, female, total };
}

export function getAllPersonnelSummary(): PersonnelData {
  const all = Object.values(personnelData);
  return {
    unitId: 'all',
    totalPersonnel: all.reduce((s, d) => s + d.totalPersonnel, 0),
    authorizedPositions: all.reduce((s, d) => s + d.authorizedPositions, 0),
    staffingRate: 0,
    ageStructure: {
      under25: all.reduce((s, d) => s + d.ageStructure.under25, 0),
      age26to35: all.reduce((s, d) => s + d.ageStructure.age26to35, 0),
      age36to45: all.reduce((s, d) => s + d.ageStructure.age36to45, 0),
      age46to55: all.reduce((s, d) => s + d.ageStructure.age46to55, 0),
      over55: all.reduce((s, d) => s + d.ageStructure.over55, 0),
    },
    educationStructure: {
      doctor: all.reduce((s, d) => s + d.educationStructure.doctor, 0),
      master: all.reduce((s, d) => s + d.educationStructure.master, 0),
      bachelor: all.reduce((s, d) => s + d.educationStructure.bachelor, 0),
      college: all.reduce((s, d) => s + d.educationStructure.college, 0),
      other: all.reduce((s, d) => s + d.educationStructure.other, 0),
    },
    positionTypes: [],
    keyPositions: [],
    avgYearsOfService: all.reduce((s, d) => s + d.avgYearsOfService, 0) / all.length,
    personnelChange: all.reduce((s, d) => s + d.personnelChange, 0) / all.length,
  };
}

export function getEducationData(unitId?: string) {
  const data = unitId ? personnelData[unitId] : getAllPersonnelSummary();
  if (!data) return [];
  const e = data.educationStructure;
  const eduTotal = e.doctor + e.master + e.bachelor + e.college + e.other;
  return [
    { name: '博士', value: e.doctor, pct: eduTotal ? (e.doctor / eduTotal * 100).toFixed(1) : '0' },
    { name: '硕士', value: e.master, pct: eduTotal ? (e.master / eduTotal * 100).toFixed(1) : '0' },
    { name: '本科', value: e.bachelor, pct: eduTotal ? (e.bachelor / eduTotal * 100).toFixed(1) : '0' },
    { name: '大专', value: e.college, pct: eduTotal ? (e.college / eduTotal * 100).toFixed(1) : '0' },
    { name: '其他', value: e.other, pct: eduTotal ? (e.other / eduTotal * 100).toFixed(1) : '0' },
  ];
}

export function getBachelorAbovePct(unitId?: string) {
  const data = unitId ? personnelData[unitId] : getAllPersonnelSummary();
  if (!data) return 0;
  const e = data.educationStructure;
  const total = e.doctor + e.master + e.bachelor + e.college + e.other;
  return total ? ((e.doctor + e.master + e.bachelor) / total * 100).toFixed(1) : '0';
}

// --- Rank distribution mock (since not in personnelData, generate from position types) ---
export const rankNames = ['一级警监', '二级警监', '一级警督', '二级警督', '三级警督', '一级警司', '二级警司', '三级警司', '警员'];

export function getRankDistribution(unitId?: string) {
  const data = unitId ? personnelData[unitId] : getAllPersonnelSummary();
  if (!data) return [];
  // Derive rank distribution from position types as approximation
  if (unitId) {
    // Per-unit: deterministic from unitId char code
    const seed = unitId.charCodeAt(0);
    return [
      Math.max(1, (seed * 3) % 5),
      Math.max(2, (seed * 7) % 8),
      Math.max(5, (seed * 11) % 15),
      Math.max(8, (seed * 13) % 20),
      Math.max(10, (seed * 17) % 25),
      Math.max(8, (seed * 19) % 20),
      Math.max(5, (seed * 23) % 15),
      Math.max(3, (seed * 29) % 10),
      Math.max(2, (seed * 31) % 8),
    ];
  }
  // All-hall summary
  return [4, 7, 18, 32, 58, 82, 65, 42, 28];
}

// --- Personnel category by year (mock 5-year data) ---
export const categoryYears = ['2022', '2023', '2024', '2025', '2026'];

export function getCategoryStackedData() {
  // Administrative, Technical, Auxiliary, Contract
  return {
    administrative: [2650, 2680, 2700, 2720, 2740],
    technical: [520, 540, 560, 580, 600],
    auxiliary: [300, 295, 290, 285, 280],
    contract: [180, 195, 210, 225, 240],
  };
}

// --- Unit matrix row data ---
export interface UnitMatrixRow {
  unit: Unit;
  totalPersonnel: number;
  authorizedPositions: number;
  staffingRate: number;
  vacancyCount: number;
  avgAge: number;
  bachelorAbovePct: number;
  certRate: number; // key position certification rate
  status: 'normal' | 'warning' | 'critical';
}

export function getUnitMatrixData(): UnitMatrixRow[] {
  return units.map((unit) => {
    const pd = personnelData[unit.id];
    const staffingRate = pd ? (pd.totalPersonnel / pd.authorizedPositions * 100) : 0;
    const vacancyCount = pd ? (pd.authorizedPositions - pd.totalPersonnel) : 0;
    // Deterministic avg age from unit
    const avgAge = 35 + (unit.id.charCodeAt(0) % 8);
    // Bachelor+ % from education
    const e = pd?.educationStructure;
    const eduTotal = e ? (e.doctor + e.master + e.bachelor + e.college + e.other) : 1;
    const bachelorAbovePct = e ? ((e.doctor + e.master + e.bachelor) / eduTotal * 100) : 0;
    // Certification rate: based on vacancy rate
    const vacancyRate = vacancyCount / (pd?.authorizedPositions || 1);
    const certRate = Math.max(50, Math.min(100, 100 - vacancyRate * 200));
    return {
      unit,
      totalPersonnel: pd?.totalPersonnel || 0,
      authorizedPositions: pd?.authorizedPositions || 0,
      staffingRate: Math.round(staffingRate * 10) / 10,
      vacancyCount,
      avgAge,
      bachelorAbovePct: Math.round(bachelorAbovePct * 10) / 10,
      certRate: Math.round(certRate * 10) / 10,
      status: unit.status as 'normal' | 'warning' | 'critical',
    };
  });
}

// --- Key position matrix data ---
export interface KeyPositionRow {
  title: string;
  required: number;
  actual: number;
  certRate: number;
  abCoverage: number;
  status: 'normal' | 'warning' | 'critical';
  staff: { name: string; age: number; certCount: number; abRole: string }[];
}

export function getKeyPositionData(unitId: string): KeyPositionRow[] {
  const pd = personnelData[unitId];
  if (!pd) return [];

  const titles = ['预算管理员', '核算会计', '资产管理员', '采购专管员', '基建管理员', '应急物资保管员', '信息化管理员'];
  const seed = unitId.charCodeAt(0);

  return titles.map((title, i) => {
    const required = [2, 3, 2, 2, 1, 2, 1][i];
    const actual = Math.max(0, required - (i === 1 ? (seed % 2) : i === 2 ? (seed % 3 === 0 ? 1 : 0) : 0));
    const shortage = required - actual;
    const certRate = Math.max(50, Math.min(100, 95 - (shortage * 15) - (i * 3 + seed) % 10));
    const abCoverage = actual >= required ? 100 : actual >= required * 0.5 ? 75 : 30;

    let status: 'normal' | 'warning' | 'critical' = 'normal';
    if (shortage > 0 || certRate < 70) status = 'critical';
    else if (certRate < 90 || abCoverage < 100) status = 'warning';

    const staffNames = ['张伟', '李娜', '王强', '刘芳', '陈明', '杨丽', '赵军', '黄婷'];
    const staff = Array.from({ length: actual }, (_, j) => ({
      name: staffNames[(seed + i + j) % staffNames.length],
      age: 28 + (seed + i * 3 + j * 5) % 20,
      certCount: Math.max(1, 3 - (seed + i + j) % 3),
      abRole: j === 0 ? 'A角' : 'B角',
    }));

    return { title, required, actual, certRate, abCoverage, status, staff };
  });
}

// --- Personnel detail list for popup ---
export interface PersonnelDetail {
  name: string;
  position: string;
  age: number;
  education: string;
  major: string;
  certCount: number;
  yearsOfService: number;
}

export function getPersonnelDetailList(unitId: string): PersonnelDetail[] {
  const pd = personnelData[unitId];
  if (!pd) return [];
  const names = ['张明远', '李秀华', '王建国', '陈晓红', '刘志强', '赵雪梅', '孙伟', '周丽华', '吴建东', '郑建国', '黄丽华', '李明', '徐明远', '林小红', '朱建华', '何美玲', '谢志强', '方建国', '唐丽娟', '韩志强'];
  const positions = ['财务主管', '资产管理', '预算专员', '审计主管', '出纳', '会计', '采购员', '后勤管理', '综合行政', '执法文员'];
  const educations = ['博士', '硕士', '本科', '本科', '本科', '大专'];
  const majors = ['财务管理', '会计学', '行政管理', '法律', '计算机科学', '工商管理', '经济学', '人力资源管理'];

  const seed = unitId.charCodeAt(0);
  const count = Math.min(pd.totalPersonnel, 60);
  return Array.from({ length: count }, (_, i) => ({
    name: names[(seed + i) % names.length] + (i >= names.length ? `${i - names.length + 1}` : ''),
    position: positions[(seed + i) % positions.length],
    age: 24 + (seed + i * 3) % 32,
    education: educations[(seed + i) % educations.length],
    major: majors[(seed + i) % majors.length],
    certCount: (seed + i) % 4,
    yearsOfService: 1 + (seed + i * 2) % 25,
  }));
}

// --- Radar comparison data ---
export const radarMetrics = ['编制使用率', '空编率', '平均年龄', '本科以上占比', '重点岗位持证率', '警保岗位人员占比'];

export function getRadarData(unitIds: string[]) {
  return unitIds.map((id) => {
    const pd = personnelData[id];
    const row = getUnitMatrixData().find(r => r.unit.id === id);
    if (!pd || !row) return { name: id, value: [0, 0, 0, 0, 0, 0] };
    return {
      name: units.find(u => u.id === id)?.name || id,
      value: [
        row.staffingRate,
        Math.max(0, 100 - row.staffingRate),
        row.avgAge,
        row.bachelorAbovePct,
        row.certRate,
        8 + (id.charCodeAt(0) % 8),
      ],
    };
  });
}

// --- Age bracket proportion for a unit ---
export function getAgeBracketProportion(unitId: string, bracketIndex: number): number {
  const { male, female } = getAgePyramidData(unitId);
  const bracketTotal = (male[bracketIndex] || 0) + (female[bracketIndex] || 0);
  const pd = personnelData[unitId];
  return pd ? (bracketTotal / pd.totalPersonnel) : 0;
}

// --- Status helpers ---
export function statusColor(status: string): string {
  switch (status) {
    case 'normal': return '#00f5a0';
    case 'warning': return '#ffd166';
    case 'critical': return '#ff4757';
    default: return '#6b7fa3';
  }
}
