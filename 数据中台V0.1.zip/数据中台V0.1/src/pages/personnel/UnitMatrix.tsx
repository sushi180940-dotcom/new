import { memo, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import { getUnitMatrixData, getAgeBracketProportion, ageBrackets, statusColor } from './dataHelpers';
import type { UnitMatrixRow } from './dataHelpers';

interface UnitMatrixProps {
  selectedAgeBracket: number | null;
  onSelectUnit: (unitId: string) => void;
}

const SortIcon = ({ dir }: { dir: 'asc' | 'desc' | null }) => (
  <span className="inline-block ml-1 text-text-tertiary">
    {dir === 'asc' ? '↑' : dir === 'desc' ? '↓' : '⇅'}
  </span>
);

export const UnitMatrix = memo(function UnitMatrix({ selectedAgeBracket, onSelectUnit }: UnitMatrixProps) {
  const [sortKey, setSortKey] = useState<string>('staffingRate');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const rows = getUnitMatrixData();

  const sorted = useMemo(() => {
    let sortedRows = [...rows];

    // If age bracket selected, sort by proportion of that bracket
    if (selectedAgeBracket !== null) {
      sortedRows.sort((a, b) => {
        const pa = getAgeBracketProportion(a.unit.id, selectedAgeBracket);
        const pb = getAgeBracketProportion(b.unit.id, selectedAgeBracket);
        return pb - pa; // highest first
      });
    } else {
      sortedRows.sort((a, b) => {
        const av = a[sortKey as keyof UnitMatrixRow] as number;
        const bv = b[sortKey as keyof UnitMatrixRow] as number;
        return sortDir === 'asc' ? av - bv : bv - av;
      });
    }
    return sortedRows;
  }, [rows, sortKey, sortDir, selectedAgeBracket]);

  const handleSort = (key: string) => {
    if (selectedAgeBracket !== null) return; // disabled during age filter
    if (sortKey === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir('asc');
    }
  };

  const columns: { key: string; label: string; width: string }[] = [
    { key: 'unitName', label: '单位名称', width: '140px' },
    { key: 'totalPersonnel', label: '总人数', width: '60px' },
    { key: 'authorizedPositions', label: '编制数', width: '60px' },
    { key: 'staffingRate', label: '编制使用率', width: '85px' },
    { key: 'vacancyCount', label: '空编数', width: '55px' },
    { key: 'avgAge', label: '平均年龄', width: '60px' },
    { key: 'bachelorAbovePct', label: '本科以上', width: '65px' },
    { key: 'certRate', label: '重点岗位持证率', width: '95px' },
  ];

  return (
    <div className="bg-abyss border border-border-dim rounded-xl overflow-hidden flex flex-col">
      {/* Header */}
      {selectedAgeBracket !== null && (
        <div className="px-4 py-2 bg-surface border-b border-border-dim">
          <span className="text-small text-accent-cyan">
            按 {ageBrackets[selectedAgeBracket]} 占比排序 — 点击金字塔其他年龄段切换
          </span>
        </div>
      )}

      <div className="overflow-auto flex-1">
        <table className="w-full text-small">
          <thead>
            <tr className="bg-surface" style={{ height: 40 }}>
              {columns.map(col => (
                <th
                  key={col.key}
                  className={`text-left px-3 text-text-secondary font-semibold whitespace-nowrap ${col.key !== 'unitName' ? 'cursor-pointer hover:text-text-primary' : ''}`}
                  style={{ width: col.width, minWidth: col.width }}
                  onClick={() => handleSort(col.key)}
                >
                  {col.label}
                  {col.key !== 'unitName' && col.key !== 'certRate' && <SortIcon dir={sortKey === col.key ? sortDir : null} />}
                </th>
              ))}
              <th className="text-left px-3 text-text-secondary font-semibold" style={{ width: '50px' }}>状态</th>
            </tr>
          </thead>
          <tbody>
            {sorted.map((row, i) => {
              const isTop3 = selectedAgeBracket !== null && i < 3;
              return (
                <motion.tr
                  key={row.unit.id}
                  layout
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: i * 0.03 }}
                  className="border-b border-border-dim cursor-pointer transition-colors hover:bg-surface"
                  style={{
                    height: 48,
                    backgroundColor: isTop3 ? 'rgba(0,229,255,0.04)' : i % 2 === 0 ? 'transparent' : 'rgba(16,22,40,0.3)',
                    borderLeft: isTop3 ? '2px solid #00e5ff' : '2px solid transparent',
                  }}
                  onClick={() => onSelectUnit(row.unit.id)}
                >
                  <td className="px-3 py-2">
                    <div className="flex items-center gap-2">
                      <span className="text-text-primary font-medium">{row.unit.name}</span>
                      <span className="px-1.5 py-0.5 rounded-sm text-[10px] font-medium" style={{ backgroundColor: 'rgba(33,81,245,0.15)', color: '#4f8af7' }}>
                        {row.unit.type}
                      </span>
                    </div>
                  </td>
                  <td className="px-3 text-text-primary font-mono">{row.totalPersonnel}</td>
                  <td className="px-3 text-text-secondary font-mono">{row.authorizedPositions}</td>
                  <td className="px-3">
                    <div className="flex items-center gap-2">
                      <span className="text-text-primary font-mono" style={{ color: row.staffingRate >= 95 ? '#00f5a0' : row.staffingRate >= 90 ? '#ffd166' : '#ff4757' }}>
                        {row.staffingRate.toFixed(1)}%
                      </span>
                      <div className="h-1.5 rounded-full overflow-hidden flex-1" style={{ backgroundColor: '#1e2a45', maxWidth: 60 }}>
                        <div
                          className="h-full rounded-full"
                          style={{
                            width: `${Math.min(100, row.staffingRate)}%`,
                            backgroundColor: row.staffingRate >= 95 ? '#00f5a0' : row.staffingRate >= 90 ? '#ffd166' : '#ff4757',
                          }}
                        />
                      </div>
                    </div>
                  </td>
                  <td className="px-3 font-mono" style={{ color: row.vacancyCount > 10 ? '#ff4757' : row.vacancyCount > 0 ? '#ffd166' : '#00f5a0' }}>
                    {row.vacancyCount}
                  </td>
                  <td className="px-3 text-text-secondary font-mono">{row.avgAge}岁</td>
                  <td className="px-3 text-text-primary font-mono">{row.bachelorAbovePct.toFixed(1)}%</td>
                  <td className="px-3">
                    <div className="flex items-center gap-2">
                      <span className="font-mono" style={{ color: row.certRate >= 90 ? '#00f5a0' : row.certRate >= 70 ? '#ffd166' : '#ff4757' }}>
                        {row.certRate.toFixed(0)}%
                      </span>
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: statusColor(row.certRate >= 90 ? 'normal' : row.certRate >= 70 ? 'warning' : 'critical') }} />
                    </div>
                  </td>
                  <td className="px-3">
                    <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: statusColor(row.status) }} />
                  </td>
                </motion.tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
});
