import { memo, useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import { Shield, Package, Monitor, AlertTriangle, ChevronRight, CheckCircle2 } from 'lucide-react';
import { assetData, units, type AssetData } from '@/data/mockData';
import {
  assetCategoryPieOption,
  assetTrendOption,
  COLORS,
} from './chartUtils';

interface RightPanelProps {
  onUnitClick: (unitId: string) => void;
  onPieCategoryClick?: (category: string | null) => void;
}

const springEase = [0.16, 1, 0.3, 1] as [number, number, number, number];

const cardVariants = {
  hidden: (i: number) => ({ opacity: 0, x: 15, transition: { delay: i * 0.06 } }),
  visible: (i: number) => ({
    opacity: 1,
    x: 0,
    transition: { duration: 0.4, delay: 0.5 + i * 0.06, ease: springEase },
  }),
};

function formatWan(v: number): string {
  return `${(v / 10000).toFixed(0)}万`;
}

// ── aggregate totals across all units ──
function computeAggregates(allAssetData: Record<string, AssetData>) {
  let equipment = 0;
  let emergencySupplies = 0;
  let officeDevices = 0;
  let total = 0;
  Object.values(allAssetData).forEach((d) => {
    equipment += d.assetCategories.equipment;
    emergencySupplies += d.assetCategories.emergencySupplies;
    officeDevices += d.assetCategories.officeDevices;
    total += d.totalAssetValue;
  });
  return { equipment, emergencySupplies, officeDevices, total };
}

// ── months for trend ──
const MONTHS = ['1月', '2月', '3月', '4月', '5月', '6月'];

// ── mock trend data (derived from unit totals) ──
function generateTrend(base: number) {
  const arr: number[] = [];
  let v = base;
  for (let i = 0; i < 6; i++) {
    v = v * (1 + (Math.random() * 0.04 - 0.015));
    arr.push(Math.round(v));
  }
  return arr;
}

const RightPanel = memo(function RightPanel({ onUnitClick, onPieCategoryClick }: RightPanelProps) {
  const { equipment, emergencySupplies, officeDevices, total } = useMemo(
    () => computeAggregates(assetData),
    []
  );

  // Shortage units
  const shortageUnits = useMemo(() => {
    const result: { unitId: string; unitName: string; shortages: string[]; severity: string }[] = [];
    Object.entries(assetData).forEach(([unitId, data]) => {
      const unit = units.find((u) => u.id === unitId);
      if (!unit) return;
      const sh = data.emergencySupplyTypes.filter((s) => s.status === 'critical' || s.status === 'warning');
      if (sh.length > 0) {
        const criticalCount = sh.filter((s) => s.status === 'critical').length;
        result.push({
          unitId,
          unitName: unit.name,
          shortages: sh.slice(0, 2).map((s) => s.type),
          severity: criticalCount >= 2 ? '严重' : '一般',
        });
      }
    });
    return result;
  }, []);

  // Trend data
  const eqTrend = useMemo(() => generateTrend(equipment), [equipment]);
  const emTrend = useMemo(() => generateTrend(emergencySupplies), [emergencySupplies]);
  const ofTrend = useMemo(() => generateTrend(officeDevices), [officeDevices]);
  const [activeTrendLines, setActiveTrendLines] = useState({ equipment: true, emergency: true, office: true });

  // Pie data
  const pieData = useMemo(
    () => [
      { name: '武器装备', value: Math.round(equipment * 0.35), color: COLORS.blue },
      { name: '防护装备', value: Math.round(equipment * 0.20), color: COLORS.cyan },
      { name: '安检装备', value: Math.round(equipment * 0.15), color: COLORS.purple },
      { name: '通信装备', value: Math.round(equipment * 0.12), color: COLORS.green },
      { name: '应急物资', value: emergencySupplies, color: COLORS.yellow },
      { name: '办公设备', value: officeDevices, color: COLORS.orange },
    ],
    [equipment, emergencySupplies, officeDevices]
  );

  const handlePieClick = (params: { name: string }) => {
    const catMap: Record<string, string> = {
      '武器装备': 'equipment',
      '防护装备': 'equipment',
      '安检装备': 'equipment',
      '通信装备': 'equipment',
      '应急物资': 'emergencySupplies',
      '办公设备': 'officeDevices',
    };
    onPieCategoryClick?.(catMap[params.name] || null);
    // Auto-clear after 2s
    setTimeout(() => onPieCategoryClick?.(null), 2000);
  };

  return (
    <div className="w-full h-full flex flex-col gap-3 p-4 overflow-y-auto" style={{ backgroundColor: '#02040a' }}>
      {/* ── Section A: Summary Cards ── */}
      <div className="flex gap-2.5">
        {/* Equipment Card */}
        <motion.div
          custom={0}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="flex-1 rounded-[10px] border p-3.5 flex flex-col gap-1"
          style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
        >
          <div className="flex items-center gap-1.5">
            <Shield className="w-4 h-4" style={{ color: COLORS.blue }} />
            <span className="text-small text-text-secondary">装备总值</span>
          </div>
          <span className="font-mono text-mono-md" style={{ color: COLORS.blue }}>
            {formatWan(equipment)}
          </span>
          <span className="text-small font-medium" style={{ color: COLORS.green }}>
            ↑ 2.3% 环比
          </span>
        </motion.div>

        {/* Emergency Supplies Card */}
        <motion.div
          custom={1}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="flex-1 rounded-[10px] border p-3.5 flex flex-col gap-1"
          style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
        >
          <div className="flex items-center gap-1.5">
            <Package className="w-4 h-4" style={{ color: COLORS.cyan }} />
            <span className="text-small text-text-secondary">应急物资总值</span>
          </div>
          <span className="font-mono text-mono-md" style={{ color: COLORS.cyan }}>
            {formatWan(emergencySupplies)}
          </span>
          {shortageUnits.length > 0 && (
            <span className="text-small font-medium" style={{ color: COLORS.red }}>
              缺储 {Math.min(shortageUnits.length, 9)} 类
            </span>
          )}
        </motion.div>

        {/* Office Devices Card */}
        <motion.div
          custom={2}
          initial="hidden"
          animate="visible"
          variants={cardVariants}
          className="flex-1 rounded-[10px] border p-3.5 flex flex-col gap-1"
          style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
        >
          <div className="flex items-center gap-1.5">
            <Monitor className="w-4 h-4" style={{ color: COLORS.purple }} />
            <span className="text-small text-text-secondary">办公设备库存</span>
          </div>
          <span className="font-mono text-mono-md" style={{ color: COLORS.purple }}>
            {formatWan(officeDevices)}
          </span>
          <span className="text-small font-medium" style={{ color: COLORS.red }}>
            ↓ 1.1% 环比
          </span>
        </motion.div>
      </div>

      {/* ── Section B: Asset Category Pie ── */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.7, ease: springEase }}
        className="rounded-xl border p-4"
        style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
      >
        <h3 className="text-h3 text-text-primary mb-1">资产分类占比</h3>
        <div className="h-[200px]" >
          <ReactEChartsCore
            echarts={echarts}
            option={assetCategoryPieOption(pieData, total)}
            style={{ height: '100%', width: '100%' }}
            onEvents={{
              click: (params: unknown) => handlePieClick(params as { name: string }),
            }}
          />
        </div>
        {/* Legend grid */}
        <div className="grid grid-cols-3 gap-x-3 gap-y-1.5 mt-1">
          {pieData.map((item) => (
            <div key={item.name} className="flex items-center gap-1.5">
              <span
                className="w-2 h-2 rounded-full flex-shrink-0"
                style={{ backgroundColor: item.color }}
              />
              <span className="text-small text-text-secondary">{item.name}</span>
              <span className="text-small font-mono text-text-primary ml-auto">
                {((item.value / pieData.reduce((s, d) => s + d.value, 0)) * 100).toFixed(0)}%
              </span>
            </div>
          ))}
        </div>
      </motion.div>

      {/* ── Section C: Shortage Alert List ── */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.8, ease: springEase }}
        className="rounded-xl border p-4"
        style={{
          backgroundColor: '#050810',
          borderColor: shortageUnits.length > 0 ? 'rgba(255,71,87,0.4)' : '#1e2a45',
        }}
      >
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="w-4 h-4 text-accent-red" />
          <h3 className="text-h3 text-text-primary">应急物资缺储告警</h3>
          {shortageUnits.length > 0 && (
            <span
              className="text-small font-medium px-1.5 py-0.5 rounded-sm"
              style={{ backgroundColor: 'rgba(255,71,87,0.15)', color: COLORS.red }}
            >
              {shortageUnits.length}项
            </span>
          )}
        </div>
        {shortageUnits.length === 0 ? (
          <div className="flex items-center gap-2 py-4 justify-center">
            <CheckCircle2 className="w-4 h-4 text-text-tertiary" />
            <span className="text-body text-text-tertiary">暂无缺储告警</span>
          </div>
        ) : (
          <div className="max-h-[140px] overflow-y-auto flex flex-col">
            {shortageUnits.slice(0, 4).map((item, i) => (
              <motion.div
                key={item.unitId}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 + i * 0.05, duration: 0.3 }}
                className="flex items-center justify-between py-2 border-b cursor-pointer hover:bg-surface/50 px-1 rounded transition-colors"
                style={{ borderColor: '#1e2a45' }}
                onClick={() => onUnitClick(item.unitId)}
              >
                <div>
                  <span className="text-body text-text-primary">{item.unitName}</span>
                  <div className="text-small text-accent-red mt-0.5">
                    缺储: {item.shortages.join('、')}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-small font-medium px-1.5 py-0.5 rounded-sm"
                    style={{
                      backgroundColor: item.severity === '严重' ? 'rgba(255,71,87,0.15)' : 'rgba(255,209,102,0.15)',
                      color: item.severity === '严重' ? COLORS.red : COLORS.yellow,
                    }}
                  >
                    {item.severity}
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 text-text-link" />
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </motion.div>

      {/* ── Section D: Asset Trend ── */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.9, ease: springEase }}
        className="rounded-xl border p-4 flex-1 min-h-0"
        style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
      >
        <h3 className="text-h3 text-text-primary mb-2">近6个月资产总值变动</h3>
        {/* Line toggle pills */}
        <div className="flex gap-2 mb-2">
          {[
            { key: 'equipment', label: '装备', color: COLORS.blue },
            { key: 'emergency', label: '应急物资', color: COLORS.cyan },
            { key: 'office', label: '办公设备', color: COLORS.purple },
          ].map((pill) => (
            <button
              key={pill.key}
              onClick={() =>
                setActiveTrendLines((prev) => ({
                  ...prev,
                  [pill.key]: !prev[pill.key as keyof typeof prev],
                }))
              }
              className="text-small px-2.5 py-1 rounded-md transition-all"
              style={{
                backgroundColor: activeTrendLines[pill.key as keyof typeof activeTrendLines]
                  ? `${pill.color}22`
                  : 'rgba(16,22,40,0.5)',
                color: activeTrendLines[pill.key as keyof typeof activeTrendLines]
                  ? pill.color
                  : COLORS.textTertiary,
                border: `1px solid ${activeTrendLines[pill.key as keyof typeof activeTrendLines] ? `${pill.color}44` : '#1e2a45'}`,
              }}
            >
              {pill.label}
            </button>
          ))}
        </div>
        <div className="h-[140px]">
          <ReactEChartsCore
            echarts={echarts}
            option={assetTrendOption(MONTHS, eqTrend, emTrend, ofTrend, activeTrendLines)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>
    </div>
  );
});

export default RightPanel;
