import { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import { AlertTriangle } from 'lucide-react';
import type { AssetData } from '@/data/mockData';
import {
  equipmentPieOption,
  perCapitaBarOption,
  supplyPieOption,
  supplyAgeBarOption,
  complianceGaugeOption,
  deviceAgeBarOption,
  distributionLineOption,
  COLORS,
} from './chartUtils';

const springEase = [0.16, 1, 0.3, 1] as [number, number, number, number];

// ═══════════════════════════════════════════════════════════════
// Tab 1 — 装备 (Equipment)
// ═══════════════════════════════════════════════════════════════

export function EquipmentTab({ data }: { data: AssetData; unitName: string }) {
  const totalEquipment = data.assetCategories.equipment;

  // Equipment type breakdown (map existing types to categories)
  const equipCategories = [
    { name: '武器警械', value: Math.round(totalEquipment * 0.28), color: COLORS.blue },
    { name: '防护装备', value: Math.round(totalEquipment * 0.22), color: COLORS.cyan },
    { name: '安检装备', value: Math.round(totalEquipment * 0.18), color: COLORS.purple },
    { name: '通信装备', value: Math.round(totalEquipment * 0.14), color: COLORS.green },
    { name: '交通工具', value: Math.round(totalEquipment * 0.12), color: COLORS.yellow },
    { name: '其他', value: Math.round(totalEquipment * 0.06), color: COLORS.textTertiary },
  ];

  // Per-capita data (mock based on unit)
  const categories = ['武器警械', '防护装备', '安检装备', '通信装备', '交通工具'];
  const unitPerCapita = equipCategories.slice(0, 5).map((c) => Math.round(c.value / 120));
  const avgPerCapita = [18, 14, 11, 9, 8]; // 全厅 average

  // Overstock/idle equipment list
  const overstockList = [
    { name: '对讲机', spec: 'Motorola CP200D', qty: 45, standard: 30, excess: 15, status: '超编' as const },
    { name: '执法记录仪', spec: 'DSJ-A7', qty: 320, standard: 280, excess: 40, status: '超编' as const },
    { name: '无人机', spec: 'DJI Mavic 3', qty: 3, standard: 8, excess: 0, status: '闲置' as const },
    { name: '防弹盾牌', spec: 'PE-III级', qty: 18, standard: 15, excess: 3, status: '超编' as const },
    { name: '金属探测器', spec: 'GP-3003B1', qty: 6, standard: 10, excess: 0, status: '闲置' as const },
  ];

  return (
    <div className="flex flex-col gap-5">
      {/* Sub-section A: Equipment Pie */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">装备分类价值</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={equipmentPieOption(equipCategories, equipCategories.map((c) => c.color))}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* Sub-section B: Per-Capita Bar */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">人均装备价值对比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={perCapitaBarOption(categories, unitPerCapita, avgPerCapita)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* Sub-section C: Overstock/Idle Table */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">超编/闲置装备清单</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-3 py-2">装备名称</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">在编</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">标准</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">超出</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
              </tr>
            </thead>
            <tbody>
              {overstockList.map((item, i) => (
                <motion.tr
                  key={item.name}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.25 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors"
                  style={{ borderColor: '#1e2a45' }}
                >
                  <td className="px-3 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.qty}</td>
                  <td className="px-2 py-2 text-text-secondary font-mono">{item.standard}</td>
                  <td className="px-2 py-2 font-mono" style={{ color: item.excess > 0 ? COLORS.yellow : COLORS.textSecondary }}>
                    {item.excess > 0 ? `+${item.excess}` : '-'}
                  </td>
                  <td className="px-2 py-2">
                    <span
                      className="text-small font-medium px-1.5 py-0.5 rounded-sm"
                      style={{
                        backgroundColor: item.status === '超编' ? 'rgba(255,209,102,0.15)' : 'rgba(255,71,87,0.15)',
                        color: item.status === '超编' ? COLORS.yellow : COLORS.red,
                      }}
                    >
                      {item.status}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 2 — 应急物资 (Emergency Supplies)
// ═══════════════════════════════════════════════════════════════

export function SuppliesTab({ data }: { data: AssetData; unitName: string }) {
  const totalEmergency = data.assetCategories.emergencySupplies;

  // Supply category pie data
  const supplyCategories = useMemo(() => {
    const items = [
      { name: '防护用品', value: Math.round(totalEmergency * 0.30), shortage: false },
      { name: '急救药品', value: Math.round(totalEmergency * 0.22), shortage: false },
      { name: '照明设备', value: Math.round(totalEmergency * 0.18), shortage: false },
      { name: '通信设备', value: Math.round(totalEmergency * 0.14), shortage: false },
      { name: '食品饮水', value: Math.round(totalEmergency * 0.10), shortage: false },
      { name: '其他', value: Math.round(totalEmergency * 0.06), shortage: false },
    ];
    // Mark shortage categories based on emergencySupplyTypes
    const shortageTypes = new Set(
      data.emergencySupplyTypes.filter((s) => s.status !== 'normal').map((s) => s.type)
    );
    // Map shortage types to categories
    if (shortageTypes.has('急救包')) items[1].shortage = true;
    if (shortageTypes.has('通信设备')) items[3].shortage = true;
    if (shortageTypes.has('消防器材')) items[0].shortage = true;
    if (shortageTypes.has('救生衣')) items[0].shortage = true;
    if (shortageTypes.has('防暴器材')) items[0].shortage = true;
    if (shortageTypes.has('应急照明')) items[2].shortage = true;
    return items;
  }, [totalEmergency, data.emergencySupplyTypes]);

  const supplyColors = [COLORS.blue, COLORS.cyan, COLORS.green, COLORS.yellow, COLORS.purple, COLORS.textTertiary];

  // Age distribution
  const ageGroups = ['0-6月', '6-12月', '1-2年', '2-3年', '>3年'];
  const ageValues = [
    Math.round(totalEmergency * 0.35),
    Math.round(totalEmergency * 0.28),
    Math.round(totalEmergency * 0.20),
    Math.round(totalEmergency * 0.12),
    Math.round(totalEmergency * 0.05),
  ];

  // Compliance rate
  const complianceRate = useMemo(() => {
    const totalTypes = data.emergencySupplyTypes.length;
    const normalTypes = data.emergencySupplyTypes.filter((s) => s.status === 'normal').length;
    return Math.round((normalTypes / totalTypes) * 100);
  }, [data.emergencySupplyTypes]);

  // Near-expiry items
  const [_selectedAgeGroup, setSelectedAgeGroup] = useState<number | null>(null);
  const nearExpiryItems = [
    { name: '急救包A型', date: '2023-05-12', shelf: '3年', remaining: '45天', status: '临期' as const, action: '尽快使用' },
    { name: '应急干粮', date: '2023-08-20', shelf: '2年', remaining: '已过期', status: '已过期' as const, action: '申请报废' },
    { name: '消毒液', date: '2024-01-15', shelf: '1年', remaining: '30天', status: '临期' as const, action: '尽快使用' },
    { name: '手电筒电池', date: '2022-11-03', shelf: '3年', remaining: '已过期', status: '已过期' as const, action: '申请报废' },
  ];

  const statusColors = {
    '正常': COLORS.green,
    '临期': COLORS.yellow,
    '已过期': COLORS.red,
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Sub-section A: Supply Pie */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">物资大类占比</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={supplyPieOption(supplyCategories, supplyColors)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* Sub-section B: Age Distribution */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">在库物资库龄分布</h4>
        <div
          className="h-[160px] cursor-pointer"
          onClick={() => setSelectedAgeGroup((prev) => (prev !== null ? null : 2))}
        >
          <ReactEChartsCore
            echarts={echarts}
            option={supplyAgeBarOption(ageGroups, ageValues)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
        <p className="text-small text-text-tertiary mt-1">点击柱状图查看对应库龄明细</p>
      </motion.div>

      {/* Sub-section C: Near-Expiry Items */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">临期/过期物资明细</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">物资名称</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">入库</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">剩余</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">状态</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">建议</th>
              </tr>
            </thead>
            <tbody>
              {nearExpiryItems.map((item, i) => (
                <motion.tr
                  key={item.name}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.25 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors"
                  style={{ borderColor: '#1e2a45' }}
                >
                  <td className="px-2 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 font-mono" style={{ color: statusColors[item.status] }}>
                    {item.remaining}
                  </td>
                  <td className="px-2 py-2">
                    <span
                      className="text-small font-medium px-1.5 py-0.5 rounded-sm"
                      style={{
                        backgroundColor: `${statusColors[item.status]}22`,
                        color: statusColors[item.status],
                      }}
                    >
                      {item.status}
                    </span>
                  </td>
                  <td className="px-2 py-2 text-text-secondary">{item.action}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>

      {/* Sub-section D: Compliance Gauge */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3, ease: springEase }}
        className="flex items-center gap-4"
      >
        <div className="w-[140px] h-[140px]">
          <ReactEChartsCore
            echarts={echarts}
            option={complianceGaugeOption(complianceRate)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
        <div className="flex flex-col gap-1">
          <span className="text-body text-text-secondary">应急物资储备达标率</span>
          <span
            className="text-data-md font-mono"
            style={{ color: complianceRate >= 90 ? COLORS.green : complianceRate >= 70 ? COLORS.yellow : COLORS.red }}
          >
            {complianceRate}%
          </span>
          <span className="text-small text-text-tertiary">属地标准: 90%</span>
          <span
            className="text-small font-medium"
            style={{ color: complianceRate >= 90 ? COLORS.green : complianceRate >= 70 ? COLORS.yellow : COLORS.red }}
          >
            {complianceRate >= 90 ? '已达标' : complianceRate >= 70 ? '基本达标' : '未达标'}
          </span>
        </div>
      </motion.div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════
// Tab 3 — 办公设备 (Office Equipment)
// ═══════════════════════════════════════════════════════════════

export function OfficeTab({ data }: { data: AssetData; unitName: string }) {
  const totalOffice = data.assetCategories.officeDevices;
  const totalCount = data.officeDeviceTypes.reduce((s, d) => s + d.count, 0);

  // Inventory overview cards
  const recoveryRate = 78.5; // mock
  const recoveryColor = recoveryRate >= 80 ? COLORS.green : recoveryRate >= 60 ? COLORS.yellow : COLORS.red;

  // Device age structure
  const deviceCategories = ['电脑', '打印机', '扫描仪', '投影仪', '其他'];
  const deviceAgeNew = [120, 25, 8, 12, 18];
  const deviceAgeMid = [80, 30, 5, 10, 12];
  const deviceAgeOld = [45, 15, 3, 8, 6];
  const deviceAgeStale = [15, 8, 2, 4, 3];

  // Annual distribution trend
  const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
  const issued = [12, 8, 15, 10, 18, 14, 9, 11, 16, 13, 7, 10];
  const returned = [8, 5, 10, 7, 12, 9, 6, 8, 11, 9, 5, 7];

  // Stale inventory
  const staleItems = [
    { name: '台式电脑', model: '联想M920', date: '2022-03-15', age: '2年8月', value: '0.5万', action: '报废' },
    { name: '打印机', model: 'HP LaserJet', date: '2021-11-20', age: '3年1月', value: '0.3万', action: '调拨' },
    { name: '投影仪', model: 'Epson EB-C0', date: '2022-01-08', age: '2年10月', value: '0.4万', action: '报废' },
    { name: '扫描仪', model: 'Canon DR-M160', date: '2021-08-30', age: '3年4月', value: '0.6万', action: '捐赠' },
  ];

  const actionColors: Record<string, string> = {
    '报废': COLORS.red,
    '调拨': COLORS.blue,
    '捐赠': COLORS.cyan,
  };

  return (
    <div className="flex flex-col gap-5">
      {/* Sub-section A: Inventory Overview */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: springEase }}
      >
        <div className="flex gap-3 mb-3">
          <div
            className="flex-1 rounded-lg border p-3"
            style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
          >
            <span className="text-small text-text-secondary">库存台件数</span>
            <div className="text-data-md font-mono text-text-primary">{totalCount}台</div>
          </div>
          <div
            className="flex-1 rounded-lg border p-3"
            style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}
          >
            <span className="text-small text-text-secondary">库存金额</span>
            <div className="text-data-md font-mono" style={{ color: COLORS.purple }}>
              {Math.round(totalOffice / 100)}万
            </div>
          </div>
        </div>
        <h4 className="text-h4 text-text-primary mb-2">库龄结构</h4>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={deviceAgeBarOption(deviceCategories, deviceAgeNew, deviceAgeMid, deviceAgeOld, deviceAgeStale)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* Sub-section B: Distribution Trend */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: springEase }}
      >
        <div className="flex items-center justify-between mb-2">
          <h4 className="text-h4 text-text-primary">当年发放趋势</h4>
          <span className="font-mono text-data-sm" style={{ color: recoveryColor }}>
            回收率: {recoveryRate}%
          </span>
        </div>
        <div className="h-[180px]">
          <ReactEChartsCore
            echarts={echarts}
            option={distributionLineOption(months, issued, returned)}
            style={{ height: '100%', width: '100%' }}
          />
        </div>
      </motion.div>

      {/* Sub-section C: Stale Inventory Alert */}
      {staleItems.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.2 }}
          className="rounded-md border-l-[3px] p-3 flex items-start gap-2"
          style={{
            backgroundColor: 'rgba(255,71,87,0.08)',
            borderColor: COLORS.red,
          }}
        >
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: COLORS.red }} />
          <span className="text-body" style={{ color: COLORS.red }}>
            发现 {staleItems.length * 3} 台呆滞办公设备（超2年未领用），建议尽快处置
          </span>
        </motion.div>
      )}

      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.25, ease: springEase }}
      >
        <h4 className="text-h4 text-text-primary mb-2">呆滞库存预警</h4>
        <div className="rounded-lg border overflow-hidden" style={{ backgroundColor: '#050810', borderColor: '#1e2a45' }}>
          <table className="w-full text-small">
            <thead>
              <tr style={{ backgroundColor: '#101628' }}>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">设备</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">型号</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">入库</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">时长</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">价值</th>
                <th className="text-left text-text-secondary font-semibold px-2 py-2">建议</th>
              </tr>
            </thead>
            <tbody>
              {staleItems.map((item, i) => (
                <motion.tr
                  key={item.name + i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.04 }}
                  className="border-t hover:bg-surface/40 transition-colors"
                  style={{ borderColor: '#1e2a45' }}
                >
                  <td className="px-2 py-2 text-text-primary">{item.name}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.model}</td>
                  <td className="px-2 py-2 text-text-secondary">{item.date}</td>
                  <td className="px-2 py-2 text-text-secondary font-mono">{item.age}</td>
                  <td className="px-2 py-2 text-text-primary font-mono">{item.value}</td>
                  <td className="px-2 py-2">
                    <span
                      className="text-small font-medium px-1.5 py-0.5 rounded-sm"
                      style={{
                        backgroundColor: `${actionColors[item.action]}22`,
                        color: actionColors[item.action],
                      }}
                    >
                      {item.action}
                    </span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </motion.div>
    </div>
  );
}
