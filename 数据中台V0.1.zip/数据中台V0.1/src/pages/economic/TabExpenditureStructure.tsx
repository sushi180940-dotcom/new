import { useState, useMemo, memo, useCallback } from 'react';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';
import { motion } from 'framer-motion';
import { economicData } from '@/data/mockData';
import { getUnitExpenditureBreakdown, getFiveYearTrend } from './dataGenerators';

interface TabExpenditureStructureProps {
  unitId: string;
}

type SeriesKey = 'total' | 'personnel' | 'operational' | 'project';

const seriesConfig: { key: SeriesKey; name: string; color: string; lineStyle: 'solid' | 'dashed' | 'dotted' | 'dot-dash' }[] = [
  { key: 'total', name: '总支出', color: '#2151f5', lineStyle: 'solid' },
  { key: 'personnel', name: '人员经费', color: '#00e5ff', lineStyle: 'dashed' },
  { key: 'operational', name: '公用经费', color: '#a855f7', lineStyle: 'dot-dash' },
  { key: 'project', name: '项目支出', color: '#f97316', lineStyle: 'dotted' },
];

const TabExpenditureStructure = memo(function TabExpenditureStructure({ unitId }: TabExpenditureStructureProps) {
  const [activeSeries, setActiveSeries] = useState<Record<SeriesKey, boolean>>({
    total: true,
    personnel: true,
    operational: true,
    project: true,
  });

  const ed = economicData[unitId];
  const breakdown = useMemo(() => getUnitExpenditureBreakdown(unitId), [unitId]);
  const trend = useMemo(() => getFiveYearTrend(unitId), [unitId]);

  const toggleSeries = useCallback((key: SeriesKey) => {
    setActiveSeries(prev => ({ ...prev, [key]: !prev[key] }));
  }, []);

  const pieOption: EChartsOption = useMemo(() => ({
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: '#0a0e1a',
      borderColor: '#2a3a5c',
      borderWidth: 1,
      textStyle: { color: '#d8dce6', fontSize: 12 },
      formatter: (params: any) => `${params.name}<br/><span style="font-weight:600;color:${params.color}">${params.value.toLocaleString()}万</span> (${params.percent}%)`,
    },
    series: [{
      type: 'pie',
      radius: ['50%', '75%'],
      center: ['40%', '50%'],
      avoidLabelOverlap: true,
      itemStyle: {
        borderRadius: 4,
        borderColor: '#0a0e1a',
        borderWidth: 2,
      },
      label: {
        show: false,
      },
      emphasis: {
        scaleSize: 6,
        itemStyle: { shadowBlur: 15 },
      },
      data: breakdown.map(item => ({
        value: item.value,
        name: item.name,
        itemStyle: { color: item.color },
      })),
      animationType: 'scale',
      animationEasing: 'cubicOut',
      animationDuration: 600,
    }],
  }), [breakdown]);

  const lineOption: EChartsOption = useMemo(() => {
    const years = trend.map(t => t.year);
    const series = seriesConfig
      .filter(cfg => activeSeries[cfg.key])
      .map(cfg => ({
        name: cfg.name,
        type: 'line' as const,
        data: trend.map(t => t[cfg.key]),
        smooth: true,
        symbol: 'circle',
        symbolSize: 6,
        showSymbol: false,
        lineStyle: {
          color: cfg.color,
          width: 2,
          type: cfg.lineStyle === 'solid' ? 'solid' as const : undefined,
          dashOffset: 0,
        } as any,
        itemStyle: { color: cfg.color },
        areaStyle: {
          color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
            { offset: 0, color: cfg.color.replace(')', ', 0.08)').replace('rgb', 'rgba') },
            { offset: 1, color: cfg.color.replace(')', ', 0)').replace('rgb', 'rgba') },
          ]),
        },
      }));

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        borderWidth: 1,
        textStyle: { color: '#d8dce6', fontSize: 12 },
      },
      grid: { top: 20, right: 20, bottom: 35, left: 60 },
      xAxis: {
        type: 'category',
        data: years,
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisLabel: { color: '#6b7fa3', fontSize: 11 },
        axisTick: { show: false },
      },
      yAxis: {
        type: 'value',
        name: '万元',
        nameTextStyle: { color: '#6b7fa3', fontSize: 11 },
        axisLine: { show: false },
        axisLabel: { color: '#6b7fa3', fontSize: 11 },
        splitLine: { lineStyle: { color: 'rgba(30, 42, 69, 0.5)' } },
      },
      series,
      animationEasing: 'cubicOut',
      animationDuration: 800,
    };
  }, [trend, activeSeries]);

  const totalAmount = useMemo(() =>
    breakdown.reduce((s, b) => s + b.value, 0),
    [breakdown],
  );

  if (!ed) return null;

  return (
    <div className="space-y-6">
      {/* Expenditure Pie */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
      >
        <h4 className="text-h4 text-text-primary mb-3">经费占比</h4>
        <div className="flex items-center gap-4">
          <div className="w-[160px] h-[160px] flex-shrink-0">
            <ReactEChartsCore
              echarts={echarts}
              option={pieOption}
              style={{ width: '100%', height: '100%' }}
            />
          </div>
          <div className="flex-1 space-y-2">
            {breakdown.map(item => (
              <div key={item.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className="text-small text-text-secondary">{item.name}</span>
                </div>
                <div className="text-right">
                  <span className="text-mono-sm text-text-primary">{item.value.toLocaleString()}万</span>
                  <span className="text-small text-text-tertiary ml-2">
                    {((item.value / totalAmount) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
            ))}
            <div className="pt-1 border-t border-border-dim">
              <span className="text-small text-text-tertiary">合计 </span>
              <span className="text-mono-sm text-text-primary">{totalAmount.toLocaleString()}万</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* 5-Year Trend */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
      >
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-h4 text-text-primary">近5年经费趋势</h4>
          <div className="flex gap-1.5">
            {seriesConfig.map(cfg => (
              <button
                key={cfg.key}
                onClick={() => toggleSeries(cfg.key)}
                className="px-2.5 py-1 rounded-full text-small transition-all duration-200"
                style={{
                  backgroundColor: activeSeries[cfg.key] ? `${cfg.color}25` : '#101628',
                  color: activeSeries[cfg.key] ? cfg.color : '#3d4f70',
                  border: `1px solid ${activeSeries[cfg.key] ? cfg.color : '#1e2a45'}`,
                }}
              >
                {cfg.name}
              </button>
            ))}
          </div>
        </div>
        <div className="h-[220px]">
          <ReactEChartsCore
            echarts={echarts}
            option={lineOption}
            style={{ width: '100%', height: '100%' }}
          />
        </div>
      </motion.div>
    </div>
  );
});

export default TabExpenditureStructure;
