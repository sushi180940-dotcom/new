import { useState, useMemo, memo, useCallback } from 'react';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';
import { motion } from 'framer-motion';
import { CheckCircle2, AlertTriangle, AlertCircle } from 'lucide-react';
import { allProjects, generateDepartments, getCrossUnitDeptAvg } from './dataGenerators';

interface TabProjectsDepartmentsProps {
  unitId: string;
}

type CompareMode = 'intra' | 'cross';

const statusIconMap = {
  normal: <CheckCircle2 className="w-3.5 h-3.5 text-accent-green" />,
  warning: <AlertTriangle className="w-3.5 h-3.5 text-accent-yellow" />,
  critical: <AlertCircle className="w-3.5 h-3.5 text-accent-red" />,
};

const TabProjectsDepartments = memo(function TabProjectsDepartments({ unitId }: TabProjectsDepartmentsProps) {
  const [compareMode, setCompareMode] = useState<CompareMode>('intra');

  const unitProjects = useMemo(() =>
    allProjects.filter(p => p.unitId === unitId),
    [unitId],
  );

  const allDepts = useMemo(() => generateDepartments(unitId), [unitId]);

  // Sunburst data
  const sunburstOption: EChartsOption = useMemo(() => ({
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'item',
      backgroundColor: '#0a0e1a',
      borderColor: '#2a3a5c',
      borderWidth: 1,
      textStyle: { color: '#d8dce6', fontSize: 12 },
      formatter: (params: any) => {
        return `${params.name}<br/><span style="color:#4f8af7;font-weight:600">${params.value.toLocaleString()}万</span> (${params.treePathInfo?.[params.treePathInfo.length - 1]?.data?.name !== params.name ? params.percent + '%' : ''})`;
      },
    },
    series: [{
      type: 'sunburst',
      radius: ['25%', '80%'],
      center: ['50%', '50%'],
      itemStyle: {
        borderRadius: 4,
        borderColor: '#0a0e1a',
        borderWidth: 2,
      },
      label: {
        rotate: 'tangential',
        color: '#d8dce6',
        fontSize: 10,
      },
      emphasis: {
        itemStyle: { shadowBlur: 15 },
      },
      levels: [
        {},
        {
          r0: '25%',
          r: '55%',
          itemStyle: { borderWidth: 2 },
          label: { rotate: 'tangential', fontSize: 10 },
        },
        {
          r0: '55%',
          r: '80%',
          label: { align: 'right', fontSize: 9, color: '#6b7fa3' },
        },
      ],
      data: allDepts.map((dept, i) => {
        const colors = ['#2151f5', '#00e5ff', '#a855f7', '#f97316', '#ffd166', '#00f5a0'];
        const baseColor = colors[i % colors.length];
        return {
          name: dept.name,
          value: dept.value,
          itemStyle: { color: baseColor },
          children: dept.children.map((child, j) => ({
            name: child.name,
            value: child.value,
            itemStyle: {
              color: echarts.color.modifyHSL(baseColor, undefined, undefined, 0.7 + j * 0.08),
            },
          })),
        };
      }),
      animationDuration: 800,
      animationEasing: 'cubicOut',
    }],
  }), [allDepts]);

  // Horizontal bar chart
  const barOption: EChartsOption = useMemo(() => {
    const sortedDepts = [...allDepts].sort((a, b) => b.value - a.value);
    const deptNames = sortedDepts.map(d => d.name);
    const deptValues = sortedDepts.map(d => d.value);

    const series: any[] = [{
      name: '本单位',
      type: 'bar',
      data: deptValues,
      barWidth: '50%',
      itemStyle: {
        color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
          { offset: 0, color: '#2151f5' },
          { offset: 1, color: '#00e5ff' },
        ]),
        borderRadius: [0, 3, 3, 0],
      },
      label: {
        show: true,
        position: 'right',
        color: '#d8dce6',
        fontSize: 11,
        fontFamily: 'JetBrains Mono, monospace',
        formatter: '{c}万',
      },
    }];

    if (compareMode === 'cross') {
      const avgValues = sortedDepts.map(d => getCrossUnitDeptAvg(d.name));
      series.push({
        name: '全厅平均',
        type: 'bar',
        data: avgValues,
        barWidth: '35%',
        barGap: '20%',
        itemStyle: {
          color: 'rgba(107, 127, 163, 0.3)',
          borderColor: '#6b7fa3',
          borderWidth: 1,
          borderType: 'dashed',
          borderRadius: [0, 3, 3, 0],
        },
        label: {
          show: true,
          position: 'right',
          color: '#6b7fa3',
          fontSize: 10,
          fontFamily: 'JetBrains Mono, monospace',
          formatter: '{c}万',
        },
      });
    }

    return {
      backgroundColor: 'transparent',
      tooltip: {
        trigger: 'axis',
        backgroundColor: '#0a0e1a',
        borderColor: '#2a3a5c',
        borderWidth: 1,
        textStyle: { color: '#d8dce6', fontSize: 12 },
      },
      legend: compareMode === 'cross' ? {
        data: ['本单位', '全厅平均'],
        top: 0,
        right: 0,
        textStyle: { color: '#6b7fa3', fontSize: 11 },
      } : undefined,
      grid: { top: compareMode === 'cross' ? 30 : 10, right: 80, bottom: 10, left: 90 },
      xAxis: {
        type: 'value',
        axisLine: { show: false },
        axisLabel: { color: '#6b7fa3', fontSize: 10 },
        splitLine: { lineStyle: { color: 'rgba(30, 42, 69, 0.5)' } },
      },
      yAxis: {
        type: 'category',
        data: deptNames,
        axisLine: { lineStyle: { color: '#1e2a45' } },
        axisLabel: { color: '#6b7fa3', fontSize: 11 },
        axisTick: { show: false },
        triggerEvent: true,
      },
      series,
      animationDuration: 600,
      animationEasing: 'cubicOut',
      animationDelay: (idx: number) => idx * 80,
    };
  }, [allDepts, compareMode]);

  const handleBarClick = useCallback((_params: any) => {
    // Bar click handler - can be extended for dept filtering
  }, []);

  return (
    <div className="space-y-6">
      {/* Project Cards */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
      >
        <h4 className="text-h4 text-text-primary mb-3">
          当年重点项目
          <span className="text-small text-text-tertiary ml-2">共 {unitProjects.length} 个</span>
        </h4>
        <div className="space-y-3 max-h-[280px] overflow-y-auto pr-1">
          {unitProjects.map((project, i) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.25, delay: i * 0.06 }}
              className="bg-surface border border-border-dim rounded-lg p-4 hover:border-border transition-all duration-200"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-h4 text-text-primary">{project.name}</span>
                  <span
                    className="px-1.5 py-0.5 rounded text-small"
                    style={{
                      backgroundColor: 'rgba(33,81,245,0.15)',
                      color: '#4f8af7',
                    }}
                  >
                    {project.department}
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  {statusIconMap[project.status]}
                  <span className="text-small" style={{
                    color: project.status === 'normal' ? '#00f5a0' : project.status === 'warning' ? '#ffd166' : '#ff4757',
                  }}>
                    {project.statusLabel}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-4 text-small text-text-secondary mb-2">
                <span>预算: <span className="text-text-primary">{project.budget}万</span></span>
                <span>已执行: <span className="text-text-primary">{project.executed}万</span></span>
                <span>剩余: <span className="text-accent-cyan">{project.remaining}万</span></span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2 bg-deep rounded-full overflow-hidden">
                  <motion.div
                    className="h-full rounded-full"
                    style={{
                      backgroundColor: project.status === 'normal' ? '#00f5a0' : project.status === 'warning' ? '#ffd166' : '#ff4757',
                    }}
                    initial={{ width: 0 }}
                    animate={{ width: `${project.progress}%` }}
                    transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] as [number, number, number, number] }}
                  />
                </div>
                <span className="text-mono-sm text-text-primary w-10 text-right">{project.progress}%</span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Sunburst Chart */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <h4 className="text-h4 text-text-primary mb-3">部门经费占比</h4>
        <div className="h-[260px]">
          <ReactEChartsCore
            echarts={echarts}
            option={sunburstOption}
            style={{ width: '100%', height: '100%' }}
          />
        </div>
      </motion.div>

      {/* Horizontal Bar Chart */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <div className="flex items-center justify-between mb-3">
          <h4 className="text-h4 text-text-primary">部门运行经费对比</h4>
          <div className="flex bg-surface rounded-full p-0.5">
            <button
              onClick={() => setCompareMode('intra')}
              className={`px-3 py-1 rounded-full text-small transition-all duration-200 ${
                compareMode === 'intra'
                  ? 'text-white'
                  : 'text-text-secondary hover:text-text-primary'
              }`}
              style={compareMode === 'intra' ? { backgroundColor: '#2151f5' } : {}}
            >
              本单位
            </button>
            <button
              onClick={() => setCompareMode('cross')}
              className={`px-3 py-1 rounded-full text-small transition-all duration-200 ${
                compareMode === 'cross'
                  ? 'text-white'
                  : 'text-text-secondary hover:text-text-primary'
              }`}
              style={compareMode === 'cross' ? { backgroundColor: '#2151f5' } : {}}
            >
              全厅对比
            </button>
          </div>
        </div>
        <div className="h-[240px]">
          <ReactEChartsCore
            echarts={echarts}
            option={barOption}
            style={{ width: '100%', height: '100%' }}
            onEvents={{
              click: handleBarClick,
            }}
          />
        </div>
      </motion.div>
    </div>
  );
});

export default TabProjectsDepartments;
