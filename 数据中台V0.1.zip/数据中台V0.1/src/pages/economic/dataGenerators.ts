// ============================================================
// Economic Panorama — Derived Data Generators
// Generates page-specific data for charts and tables
// ============================================================

import { units, economicData, type Unit } from '@/data/mockData';

// --- Expenditure Structure (aggregate) ---
export interface ExpenditureItem {
  name: string;
  value: number;
  color: string;
}

export const aggregateExpenditure: ExpenditureItem[] = [
  { name: '人员经费', value: 49370, color: '#2151f5' },
  { name: '公用经费', value: 27380, color: '#00e5ff' },
  { name: '项目支出', value: 24100, color: '#a855f7' },
  { name: '三公经费', color: '#ffd166', value: 9300 },
];

// Derive per-unit expenditure breakdown
export function getUnitExpenditureBreakdown(unitId: string) {
  const ed = economicData[unitId];
  if (!ed) return [];
  const personnelAmount = Math.round(ed.personnelCount * 12.8);
  const threePublicAmount = ed.threePublicFunds;
  const remaining = ed.actualExpenditure - personnelAmount - threePublicAmount;
  const projectAmount = Math.round(remaining * 0.45);
  const operationalAmount = remaining - projectAmount;
  return [
    { name: '人员经费', value: personnelAmount, color: '#2151f5' },
    { name: '公用经费', value: operationalAmount, color: '#00e5ff' },
    { name: '项目支出', value: projectAmount, color: '#a855f7' },
    { name: '三公经费', value: threePublicAmount, color: '#ffd166' },
  ];
}

// --- Aggregate monthly execution rate ---
export const months = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];

export const aggregateMonthlyExecution: number[] = Array.from({ length: 12 }, (_, i) => {
  const values = Object.values(economicData).map(d => d.monthlyBudgetExecution[i]);
  const avg = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.round(avg * 10) / 10;
});

// --- 3-Year Budget vs Actual ---
export interface YearComparison {
  year: string;
  budget: number;
  actual: number;
  diff: number;
}

export function getThreeYearComparison(unitId: string): YearComparison[] {
  const ed = economicData[unitId];
  if (!ed) return [];
  return [
    {
      year: '2024',
      budget: Math.round(ed.budgetAmount * 0.92),
      actual: Math.round(ed.budgetAmount * 0.94),
      diff: Math.round(ed.budgetAmount * 0.02),
    },
    {
      year: '2025',
      budget: ed.budgetAmount,
      actual: ed.actualExpenditure,
      diff: ed.actualExpenditure - ed.budgetAmount,
    },
    {
      year: '2026',
      budget: Math.round(ed.budgetAmount * 1.05),
      actual: Math.round(ed.budgetAmount * 1.05 * (ed.budgetExecutionRate / 100)),
      diff: Math.round(ed.budgetAmount * 1.05 * (ed.budgetExecutionRate / 100) - ed.budgetAmount * 1.05),
    },
  ];
}

// --- 5-Year Expenditure Trend ---
export interface YearTrend {
  year: string;
  total: number;
  personnel: number;
  operational: number;
  project: number;
}

export function getFiveYearTrend(unitId: string): YearTrend[] {
  const ed = economicData[unitId];
  if (!ed) return [];
  const baseExp = ed.actualExpenditure;
  const basePersonnel = Math.round(ed.personnelCount * 12.8);
  const remaining = baseExp - basePersonnel - ed.threePublicFunds;
  const baseProject = Math.round(remaining * 0.45);
  const baseOperational = remaining - baseProject;
  return [
    { year: '2022', total: Math.round(baseExp * 0.82), personnel: Math.round(basePersonnel * 0.88), operational: Math.round(baseOperational * 0.78), project: Math.round(baseProject * 0.75) },
    { year: '2023', total: Math.round(baseExp * 0.88), personnel: Math.round(basePersonnel * 0.92), operational: Math.round(baseOperational * 0.86), project: Math.round(baseProject * 0.84) },
    { year: '2024', total: Math.round(baseExp * 0.94), personnel: Math.round(basePersonnel * 0.97), operational: Math.round(baseOperational * 0.93), project: Math.round(baseProject * 0.92) },
    { year: '2025', total: baseExp, personnel: basePersonnel, operational: baseOperational, project: baseProject },
    { year: '2026', total: Math.round(baseExp * 1.06), personnel: Math.round(basePersonnel * 1.05), operational: Math.round(baseOperational * 1.08), project: Math.round(baseProject * 1.12) },
  ];
}

// --- Projects ---
export interface ProjectItem {
  id: string;
  name: string;
  unitName: string;
  unitId: string;
  budget: number;
  executed: number;
  remaining: number;
  progress: number;
  status: 'normal' | 'warning' | 'critical';
  statusLabel: string;
  department: string;
}

const projectNamePool = [
  '信息化建设升级项目', '应急指挥系统改造', '执法装备更新换代',
  '数据中心扩容工程', '智慧监控系统建设', '培训基地改造工程',
  '办公楼维修项目', '车辆更新采购计划', '网络安全加固工程',
  '移动执法平台建设', '档案数字化工程', '指挥调度系统升级',
  '视频监控全覆盖', '应急物资储备库', '办案区升级改造',
 '智能门禁系统', '通信设备更新', '警用无人机采购',
  '数据中心灾备', '综合业务平台', '办公自动化升级',
  '视频会议室建设', '停车场改造工程', '绿化环境提升',
];

const deptPool = ['指挥管理部', '财务审计部', '行政执法部', '后勤保障部', '信息技术部'];

export function generateProjects(): ProjectItem[] {
  const projects: ProjectItem[] = [];
  let idx = 0;
  for (const unit of units) {
    const ed = economicData[unit.id];
    const count = ed ? Math.min(ed.keyProjects, 5) : 2;
    for (let i = 0; i < count; i++) {
      const name = `${unit.name}·${projectNamePool[idx % projectNamePool.length]}`;
      const budget = 200 + Math.round(Math.random() * 800);
      const progress = 20 + Math.round(Math.random() * 75);
      const executed = Math.round(budget * (progress / 100));
      const status = progress >= 85 ? 'normal' as const : progress >= 60 ? 'warning' as const : 'critical' as const;
      projects.push({
        id: `${unit.id}-p${i}`,
        name,
        unitName: unit.name,
        unitId: unit.id,
        budget,
        executed,
        remaining: budget - executed,
        progress,
        status,
        statusLabel: progress >= 85 ? '正常推进' : progress >= 60 ? '进度滞后' : '严重滞后',
        department: deptPool[idx % deptPool.length],
      });
      idx++;
    }
  }
  return projects;
}

export const allProjects = generateProjects();

// --- Departments ---
export interface SubCategory {
  name: string;
  value: number;
}

export interface Department {
  name: string;
  value: number;
  children: SubCategory[];
}

const departmentTemplates = [
  { name: '指挥管理部', subs: ['行政运行', '会议培训', '差旅费', '办公费'] },
  { name: '财务审计部', subs: ['审计费', '会计服务', '财务系统维护'] },
  { name: '行政执法部', subs: ['执法装备', '办案费', '检测费', '交通费'] },
  { name: '后勤保障部', subs: ['水电物业', '维修维护', '餐饮保障', '车辆运行'] },
  { name: '信息技术部', subs: ['系统建设', '网络运维', '设备购置', '软件开发'] },
  { name: '人力资源部', subs: ['人员经费', '培训费', '招聘费', '福利费'] },
];

export function generateDepartments(unitId: string): Department[] {
  const unit = units.find(u => u.id === unitId);
  if (!unit) return [];
  const factor = unit.type === '总队' ? 1 : unit.type === '支队' ? 0.55 : 0.35;
  const ed = economicData[unitId];
  const base = ed ? ed.actualExpenditure * 0.7 : 2000;

  return departmentTemplates.map(dept => {
    const deptValue = Math.round(base * (0.08 + Math.random() * 0.12) * factor);
    const children = dept.subs.map(sub => ({
      name: sub,
      value: Math.round(deptValue / dept.subs.length * (0.7 + Math.random() * 0.6)),
    }));
    return { name: dept.name, value: children.reduce((s, c) => s + c.value, 0), children };
  });
}

// --- Cross-unit department averages (for comparison) ---
export function getCrossUnitDeptAvg(departmentName: string): number {
  let total = 0;
  let count = 0;
  for (const unit of units) {
    const depts = generateDepartments(unit.id);
    const dept = depts.find(d => d.name === departmentName);
    if (dept) {
      total += dept.value;
      count++;
    }
  }
  return count > 0 ? Math.round(total / count) : 0;
}

// --- Aggregate stats for KPI cards ---
export function getAggregateStats() {
  const allEd = Object.values(economicData);
  const totalBudget = allEd.reduce((s, d) => s + d.budgetAmount, 0);
  const totalExpenditure = allEd.reduce((s, d) => s + d.actualExpenditure, 0);
  const avgExecutionRate = allEd.reduce((s, d) => s + d.budgetExecutionRate, 0) / allEd.length;
  const totalThreePublic = allEd.reduce((s, d) => s + d.threePublicFunds, 0);
  const totalThreePublicBudget = allEd.reduce((s, d) => s + d.threePublicFundsBudget, 0);
  const threePublicRate = (totalThreePublic / totalThreePublicBudget) * 100;
  const yoyChange = allEd.reduce((s, d) => s + d.yearOverYearChange, 0) / allEd.length;

  return {
    totalBudget,
    totalExpenditure,
    avgExecutionRate: Math.round(avgExecutionRate * 10) / 10,
    totalThreePublic,
    threePublicRate: Math.round(threePublicRate * 10) / 10,
    yoyChange: Math.round(yoyChange * 10) / 10,
    totalProjects: allEd.reduce((s, d) => s + d.keyProjects, 0),
    delayedProjects: allEd.reduce((s, d) => s + d.delayedProjects, 0),
  };
}

// --- Sequential progress rate ---
export const sequentialProgressRate = 91.7;

// --- Sparkline data for KPI cards ---
export function getRevenueSparkline(): number[] {
  return [7.8, 8.0, 7.9, 8.1, 8.2, 8.4, 8.3, 8.5, 8.6, 8.8, 8.9, 9.1];
}

export function getExpenditureSparkline(): number[] {
  return [6.2, 6.4, 6.6, 6.8, 7.0, 7.2, 7.3, 7.5, 7.6, 7.8, 8.0, 8.2];
}

// --- Helper to get dot color by execution rate ---
export function getExecutionColor(rate: number): string {
  if (rate >= sequentialProgressRate) return '#00f5a0';
  if (rate >= sequentialProgressRate - 5) return '#ffd166';
  return '#ff4757';
}

// --- Unit dot size (proportional to expenditure) ---
export function getUnitDotSize(unitId: string): number {
  const ed = economicData[unitId];
  if (!ed) return 5;
  const maxExp = 28500;
  const minExp = 3800;
  const normalized = (ed.actualExpenditure - minExp) / (maxExp - minExp);
  return Math.round(6 + normalized * 18);
}

// --- Get top units by expenditure category ---
export function getTopUnitsByCategory(category: string): { unit: Unit; amount: number }[] {
  return units
    .map(unit => {
      const breakdown = getUnitExpenditureBreakdown(unit.id);
      const item = breakdown.find(b => b.name === category);
      return { unit, amount: item?.value ?? 0 };
    })
    .sort((a, b) => b.amount - a.amount);
}
