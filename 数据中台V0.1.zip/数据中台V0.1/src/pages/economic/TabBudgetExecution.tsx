import { memo, useMemo } from 'react';
import ReactEChartsCore from 'react-echarts-core';
import * as echarts from 'echarts';
import type { EChartsOption } from 'echarts';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { economicData } from '@/data/mockData';
import { getThreeYearComparison, sequentialProgressRate } from './dataGenerators';

interface TabBudgetExecutionProps {
  unitId: string;
}

const TabBudgetExecution = memo(function TabBudgetExecution({ unitId }: TabBudgetExecutionProps) {
  const ed = economicData[unitId];
  const comparison = useMemo(() => getThreeYearComparison(unitId), [unitId]);

  const ringColor = useMemo(() => {
    if (!ed) return '#00f5a0';
    if (ed.budgetExecutionRate >= sequentialProgressRate) return '#00f5a0';
    if (ed.budgetExecutionRate >= sequentialProgressRate - 5) return '#ffd166';
    return '#ff4757';
  }, [ed]);

  const deviation = useMemo(() => {
    if (!ed) return 0;
    return Math.round((ed.budgetExecutionRate - sequentialProgressRate) * 10) / 10;
  }, [ed]);

  const ringOption: EChartsOption = useMemo(() => ({
    backgroundColor: 'transparent',
    series: [{
      type: 'pie',
      radius: ['65%', '85%'],
      center: ['50%', '50%'],
      silent: false,
      label: { show: false },
      labelLine: { show: false },
      data: [
        {
          value: ed?.budgetExecutionRate ?? 0,
          itemStyle: {
            color: new echarts.graphic.LinearGradient(0, 0, 1, 1, [
              { offset: 0, color: ringColor },
              { offset: 1, color: ringColor },
            ]),
            borderRadius: 4,
          },
        },
        {
          value: 100 - (ed?.budgetExecutionRate ?? 0),
          itemStyle: { color: '#1e2a45' },
        },
      ],
      animationType: 'scale',
      animationEasing: 'cubicOut',
      animationDuration: 800,
    }],
    graphic: [
      {
        type: 'text',
        left: 'center',
        top: '38%',
        style: {
          text: `${ed?.budgetExecutionRate ?? 0}%`,
          fill: '#d8dce6',
          fontSize: 22,
          fontWeight: 600,
          fontFamily: 'JetBrains Mono, monospace',
        },
      },
      {
        type: 'text',
        left: 'center',
        top: '56%',
        style: {
          text: '预算执行率',
          fill: '#6b7fa3',
          fontSize: 12,
        },
      },
    ],
  }), [ed, ringColor]);

  const barOption: EChartsOption = useMemo(() => ({
    backgroundColor: 'transparent',
    tooltip: {
      trigger: 'axis',
      backgroundColor: '#0a0e1a',
      borderColor: '#2a3a5c',
      borderWidth: 1,
      textStyle: { color: '#d8dce6', fontSize: 12 },
    },
    grid: { top: 40, right: 20, bottom: 40, left: 60 },
    legend: {
      data: ['预算数', '决算数'],
      top: 0,
      right: 0,
      textStyle: { color: '#6b7fa3', fontSize: 12 },
      itemWidth: 12,
      itemHeight: 8,
    },
    xAxis: {
      type: 'category',
      data: comparison.map(c => c.year),
      axisLine: { lineStyle: { color: '#1e2a45' } },
      axisLabel: { color: '#6b7fa3', fontSize: 12 },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      name: '万元',
      nameTextStyle: { color: '#6b7fa3', fontSize: 11 },
      axisLine: { show: false },
      axisLabel: { color: '#6b7fa3', fontSize: 11 },
      splitLine: { lineStyle: { color: 'rgba(30, 42, 69, 0.5)' } },
    },
    series: [
      {
        name: '预算数',
        type: 'bar',
        data: comparison.map(c => c.budget),
        barWidth: '28%',
        itemStyle: { color: '#2151f5', borderRadius: [3, 3, 0, 0] },
        animationDelay: (idx: number) => idx * 200,
      },
      {
        name: '决算数',
        type: 'bar',
        data: comparison.map(c => c.actual),
        barWidth: '28%',
        itemStyle: { color: '#00e5ff', borderRadius: [3, 3, 0, 0] },
        animationDelay: (idx: number) => idx * 200 + 100,
      },
    ],
    animationEasing: 'cubicOut',
    animationDuration: 800,
  }), [comparison]);

  if (!ed) return null;

  const remainingBudget = ed.budgetAmount - ed.actualExpenditure;
  const remainingMonths = Math.max(0, 12 - new Date().getMonth() - 1);

  return (
    <div className="space-y-6">
      {/* Ring + Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
      >
        <h4 className="text-h4 text-text-primary mb-4">预算执行进度</h4>
        <div className="flex items-center gap-6">
          <div className="w-[140px] h-[140px] flex-shrink-0">
            <ReactEChartsCore
              echarts={echarts}
              option={ringOption}
              style={{ width: '100%', height: '100%' }}
            />
          </div>
          <div className="flex-1 space-y-3">
            <MetricRow
              label="序时进度"
              value={`${sequentialProgressRate}%`}
              icon={<TrendingUp className="w-3.5 h-3.5" />}
              color="#ffd166"
            />
            <MetricRow
              label="偏差值"
              value={`${deviation >= 0 ? '+' : ''}${deviation}%`}
              icon={deviation >= 0
                ? <TrendingUp className="w-3.5 h-3.5" />
                : <TrendingDown className="w-3.5 h-3.5" />}
              color={deviation >= 0 ? '#00f5a0' : '#ff4757'}
            />
            <MetricRow
              label="剩余预算"
              value={`${remainingBudget.toLocaleString()}万`}
              icon={<Minus className="w-3.5 h-3.5" />}
              color="#4f8af7"
            />
            <MetricRow
              label="剩余月份"
              value={`${remainingMonths}个月`}
              icon={<Minus className="w-3.5 h-3.5" />}
              color="#6b7fa3"
            />
          </div>
        </div>
      </motion.div>

      {/* 3-Year Comparison */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.25 }}
      >
        <h4 className="text-h4 text-text-primary mb-4">近3年收支预决算差异</h4>
        <div className="h-[220px]">
          <ReactEChartsCore
            echarts={echarts}
            option={barOption}
            style={{ width: '100%', height: '100%' }}
          />
        </div>
        <div className="flex gap-6 mt-3">
          {comparison.map(c => (
            <div key={c.year} className="text-center flex-1">
              <div className="text-small text-text-secondary">{c.year}差异</div>
              <div
                className="text-mono-sm font-medium mt-0.5"
                style={{ color: c.diff >= 0 ? '#ff4757' : '#00f5a0' }}
              >
                {c.diff >= 0 ? '+' : ''}{c.diff.toLocaleString()}万
              </div>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
});

// --- Sub-component ---
const MetricRow = memo(function MetricRow({
  label,
  value,
  icon,
  color,
}: {
  label: string;
  value: string;
  icon: React.ReactNode;
  color: string;
}) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b border-border-dim">
      <div className="flex items-center gap-2">
        <span style={{ color }}>{icon}</span>
        <span className="text-small text-text-secondary">{label}</span>
      </div>
      <span className="text-mono-sm font-medium" style={{ color }}>
        {value}
      </span>
    </div>
  );
});

export default TabBudgetExecution;
