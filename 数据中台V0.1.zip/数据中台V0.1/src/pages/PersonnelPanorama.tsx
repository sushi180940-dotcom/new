import { useState, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, Users, ChevronDown } from 'lucide-react';
import { units } from '@/data/mockData';
import { KpiCards } from './personnel/KpiCards';
import { AgePyramidChart } from './personnel/AgePyramidChart';
import { EducationRingChart } from './personnel/EducationRingChart';
import { RankDistributionChart } from './personnel/RankDistributionChart';
import { CategoryStackedBarChart } from './personnel/CategoryStackedBarChart';
import { UnitMatrix } from './personnel/UnitMatrix';
import { PositionMatrix } from './personnel/PositionMatrix';
import { CrossUnitComparison } from './personnel/CrossUnitComparison';
import { PersonnelPopup } from './personnel/PersonnelPopup';
import { getUnitMatrixData, statusColor } from './personnel/dataHelpers';
import type { Unit } from '@/data/mockData';

const ease = [0.16, 1, 0.3, 1] as [number, number, number, number];

type TabId = 'structure' | 'positions' | 'compare';

export default function PersonnelPanorama() {
  const [selectedUnitId, setSelectedUnitId] = useState<string | null>(null);
  const [selectedAgeBracket, setSelectedAgeBracket] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<TabId>('structure');
  const [showUnitDropdown, setShowUnitDropdown] = useState(false);
  const [popupUnit, setPopupUnit] = useState<Unit | null>(null);

  const selectedUnit = useMemo(() => units.find(u => u.id === selectedUnitId) || null, [selectedUnitId]);
  const matrixRow = useMemo(() => getUnitMatrixData().find(r => r.unit.id === selectedUnitId), [selectedUnitId]);

  const handleSelectUnit = useCallback((unitId: string) => {
    setSelectedUnitId(unitId);
    setActiveTab('structure');
  }, []);

  const handleBackToMatrix = useCallback(() => {
    setSelectedUnitId(null);
    setSelectedAgeBracket(null);
  }, []);

  const handleBracketClick = useCallback((index: number) => {
    setSelectedAgeBracket(prev => prev === index ? null : index);
  }, []);

  const tabs: { id: TabId; label: string }[] = [
    { id: 'structure', label: '人员结构' },
    { id: 'positions', label: '重点岗位' },
    { id: 'compare', label: '跨单位对比' },
  ];

  return (
    <div className="min-h-[100dvh] pt-[56px] pb-[64px]" style={{ backgroundColor: '#02040a' }}>
      <div className="flex h-[calc(100dvh-120px)] gap-0">
        {/* LEFT PANEL (~55%) */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="w-[55%] flex flex-col gap-4 p-5 overflow-auto"
        >
          {/* Row 1: KPI Cards */}
          <KpiCards selectedUnitId={selectedUnitId || undefined} />

          {/* Row 2: Age Pyramid + Education Ring */}
          <div className="flex gap-4">
            <AgePyramidChart unitId={selectedUnitId || undefined} onBracketClick={handleBracketClick} />
            <EducationRingChart unitId={selectedUnitId || undefined} />
          </div>

          {/* Row 3: Rank Distribution + Category Stacked Bar */}
          <div className="flex gap-4">
            <RankDistributionChart unitId={selectedUnitId || undefined} />
            <CategoryStackedBarChart />
          </div>
        </motion.div>

        {/* RIGHT PANEL (~45%) */}
        <div className="w-[45%] border-l border-border-dim flex flex-col" style={{ backgroundColor: '#0a0e1a' }}>
          <AnimatePresence mode="wait">
            {!selectedUnitId ? (
              /* Default State: Unit Matrix */
              <motion.div
                key="matrix"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease }}
                className="flex flex-col h-full p-5 gap-4"
              >
                {/* Unit Selector */}
                <div>
                  <div className="relative">
                    <button
                      onClick={() => setShowUnitDropdown(v => !v)}
                      className="flex items-center gap-2 w-[240px] px-4 py-2.5 rounded-lg bg-surface border border-border text-text-primary text-small hover:border-border-bright transition-colors"
                    >
                      <Users className="w-4 h-4 text-accent-blue" />
                      <span>选择直属单位</span>
                      <ChevronDown className="w-4 h-4 text-text-tertiary ml-auto" />
                    </button>
                    {showUnitDropdown && (
                      <div className="absolute top-full left-0 mt-1 bg-deep border border-border rounded-lg shadow-lg z-20 py-1 min-w-[240px] max-h-60 overflow-auto">
                        {units.map(u => (
                          <button
                            key={u.id}
                            className="w-full text-left px-4 py-2 text-small text-text-secondary hover:bg-surface hover:text-text-primary transition-colors flex items-center gap-2"
                            onClick={() => { handleSelectUnit(u.id); setShowUnitDropdown(false); }}
                          >
                            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: statusColor(u.status) }} />
                            {u.name}
                            <span className="ml-auto text-text-tertiary">{u.type}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <p className="text-small text-text-tertiary mt-2">或点击下方矩阵中的单位行查看详情</p>
                </div>

                {/* Unit Matrix Table */}
                <div className="flex-1 overflow-hidden">
                  <UnitMatrix
                    selectedAgeBracket={selectedAgeBracket}
                    onSelectUnit={handleSelectUnit}
                  />
                </div>

                {/* Age bracket filter label */}
                <AnimatePresence>
                  {selectedAgeBracket !== null && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -10 }}
                      className="flex items-center gap-2 px-3 py-2 rounded-lg bg-surface"
                    >
                      <span className="text-small text-accent-cyan">
                        已按年龄段筛选 — 点击左侧金字塔取消筛选
                      </span>
                      <button
                        onClick={() => setSelectedAgeBracket(null)}
                        className="text-small text-text-tertiary hover:text-text-primary ml-auto"
                      >
                        清除
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            ) : (
              /* Detail State: Unit Detail Panel */
              <motion.div
                key="detail"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3, ease }}
                className="flex flex-col h-full"
              >
                {/* Panel Header */}
                <div className="px-5 pt-5 pb-3 border-b border-border-dim">
                  <div className="flex items-center gap-3 mb-3">
                    <button
                      onClick={handleBackToMatrix}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-md text-small text-text-secondary hover:text-text-primary hover:bg-surface transition-colors"
                    >
                      <ArrowLeft className="w-4 h-4" />
                      返回矩阵
                    </button>
                    <h2
                      className="text-h2 text-text-primary cursor-pointer hover:text-accent-cyan transition-colors"
                      onClick={() => selectedUnit && setPopupUnit(selectedUnit)}
                    >
                      {selectedUnit?.name}
                    </h2>
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: statusColor(selectedUnit?.status || 'normal') }} />
                  </div>

                  {/* Quick metrics */}
                  {matrixRow && (
                    <div className="flex items-center gap-6 mb-3">
                      <div>
                        <span className="text-small text-text-secondary">总人数 </span>
                        <span className="text-data-sm font-mono text-text-primary">{matrixRow.totalPersonnel}人</span>
                      </div>
                      <div>
                        <span className="text-small text-text-secondary">编制使用率 </span>
                        <span className="text-data-sm font-mono" style={{ color: matrixRow.staffingRate >= 95 ? '#00f5a0' : '#ffd166' }}>{matrixRow.staffingRate.toFixed(0)}%</span>
                      </div>
                      <div>
                        <span className="text-small text-text-secondary">平均年龄 </span>
                        <span className="text-data-sm font-mono text-text-primary">{matrixRow.avgAge}岁</span>
                      </div>
                      <div>
                        <span className="text-small text-text-secondary">本科以上 </span>
                        <span className="text-data-sm font-mono text-text-primary">{matrixRow.bachelorAbovePct.toFixed(0)}%</span>
                      </div>
                    </div>
                  )}

                  {/* Tabs */}
                  <div className="flex gap-1">
                    {tabs.map(tab => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`relative px-4 py-2.5 text-h4 transition-colors border-b-2 ${
                          activeTab === tab.id
                            ? 'text-[#4f8af7] border-[#2151f5]'
                            : 'text-text-secondary border-transparent hover:text-text-primary'
                        }`}
                      >
                        {tab.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tab Content */}
                <div className="flex-1 overflow-auto p-5">
                  <AnimatePresence mode="wait">
                    {activeTab === 'structure' && selectedUnitId && (
                      <motion.div
                        key="structure"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                        className="space-y-4"
                      >
                        {/* Unit-specific age pyramid */}
                        <div className="flex gap-4">
                          <AgePyramidChart unitId={selectedUnitId} />
                          <EducationRingChart unitId={selectedUnitId} />
                        </div>
                        <RankDistributionChart unitId={selectedUnitId} />
                      </motion.div>
                    )}

                    {activeTab === 'positions' && selectedUnitId && (
                      <motion.div
                        key="positions"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="mb-3">
                          <h3 className="text-h3 text-text-primary">重点岗位配置矩阵</h3>
                          <p className="text-small text-text-tertiary mt-1">点击岗位行展开详细人员信息</p>
                        </div>
                        <PositionMatrix unitId={selectedUnitId} />
                      </motion.div>
                    )}

                    {activeTab === 'compare' && selectedUnitId && (
                      <motion.div
                        key="compare"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="mb-3">
                          <h3 className="text-h3 text-text-primary">跨单位对比分析</h3>
                          <p className="text-small text-text-tertiary mt-1">最多选择5个单位进行对比</p>
                        </div>
                        <CrossUnitComparison currentUnitId={selectedUnitId} />
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Personnel Detail Popup */}
      {popupUnit && (
        <PersonnelPopup unit={popupUnit} onClose={() => setPopupUnit(null)} />
      )}
    </div>
  );
}
