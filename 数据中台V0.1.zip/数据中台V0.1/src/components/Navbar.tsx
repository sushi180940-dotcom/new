import { useState, useEffect, memo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Search, Bell } from 'lucide-react';
import BreadcrumbNav from './BreadcrumbNav';
import GlobalSearch from './GlobalSearch';
import { useLocation } from 'react-router';

interface NavbarProps {
  className?: string;
}

// Simple logo SVG component
const LogoIcon = memo(function LogoIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M10 1L2 5.5V10C2 14.42 5.36 18.56 10 19.5C14.64 18.56 18 14.42 18 10V5.5L10 1Z"
        stroke="#2151f5"
        strokeWidth="1.5"
        fill="none"
      />
      <path
        d="M6 10.5L8.5 13L14 7.5"
        stroke="#00e5ff"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      <path
        d="M7 5H13"
        stroke="#2151f5"
        strokeWidth="1"
        strokeLinecap="round"
        opacity="0.6"
      />
    </svg>
  );
});

const panoramaLabels: Record<string, string> = {
  'economic': '经济运行全景',
  'financial': '财务全景',
  'asset': '资产全景',
  'personnel': '人员结构与配置全景',
};

const mockAlerts = [
  '支队C — 预算执行率低于序时进度3.2% — 10分钟前',
  '支队E — 应急物资缺储2类 — 23分钟前',
  '支队E — 资产管理员岗位缺配 — 1小时前',
];

const Navbar = memo(function Navbar({ className = '' }: NavbarProps) {
  const [showSearch, setShowSearch] = useState(false);
  const location = useLocation();

  // Keyboard shortcut for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setShowSearch(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Build breadcrumb segments
  const buildBreadcrumb = useCallback(() => {
    const segments = [{ label: '全厅', path: '/' }];

    if (location.pathname.startsWith('/panorama/')) {
      const panoramaKey = location.pathname.split('/')[2];
      const label = panoramaLabels[panoramaKey] || '全景';
      segments.push({ label, path: location.pathname });
    }

    return segments;
  }, [location.pathname]);

  const breadcrumbSegments = buildBreadcrumb();

  return (
    <>
      <motion.header
        initial={{ y: -56 }}
        animate={{ y: 0 }}
        transition={{
          duration: 0.6,
          delay: 0.2,
          ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
        }}
        className={`fixed top-0 left-0 right-0 z-50 h-[56px] flex items-center justify-between px-6 border-b border-border-dim ${className}`}
        style={{
          backgroundColor: 'rgba(5, 8, 16, 0.92)',
          backdropFilter: 'blur(12px)',
          WebkitBackdropFilter: 'blur(12px)',
        }}
      >
        {/* Left: Logo + Title + Breadcrumb */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <LogoIcon />
            <span className="text-h4 text-text-primary font-medium whitespace-nowrap">
              警保数据资源中心
            </span>
          </div>

          {breadcrumbSegments.length > 1 && (
            <div className="hidden md:block">
              <BreadcrumbNav segments={breadcrumbSegments} />
            </div>
          )}
        </div>

        {/* Center: Search Bar */}
        <div className="hidden lg:flex flex-1 items-center justify-center mx-6 max-w-[520px]">
          <button
            onClick={() => setShowSearch(true)}
            className="w-full flex items-center gap-3 px-4 py-2 rounded-lg border border-border-dim bg-void hover:border-border hover:bg-surface transition-all duration-200"
          >
            <Search className="w-4 h-4 text-text-tertiary flex-shrink-0" />
            <span className="flex-1 text-body text-text-tertiary text-left text-sm">
              搜索单位名称、指标、项目...
            </span>
            <span className="text-[11px] text-text-tertiary bg-surface px-1.5 py-0.5 rounded flex-shrink-0">
              ⌘K
            </span>
          </button>
        </div>

        {/* Right: Warning ticker + Notifications + Avatar */}
        <div className="flex items-center gap-3">
          {/* Mini warning ticker */}
          <div className="hidden xl:flex items-center overflow-hidden max-w-[240px]">
            <div className="flex items-center gap-3 animate-marquee whitespace-nowrap">
              {mockAlerts.map((alert, i) => (
                <span key={i} className="flex items-center gap-1.5 text-[11px] text-accent-yellow">
                  <span className="w-1 h-1 rounded-full bg-accent-red animate-pulse flex-shrink-0" />
                  {alert}
                </span>
              ))}
            </div>
          </div>

          <button className="relative p-2 rounded-md hover:bg-surface transition-colors text-text-secondary hover:text-text-primary">
            <Bell className="w-[18px] h-[18px]" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-accent-red" />
          </button>

          {/* User avatar */}
          <div className="w-8 h-8 rounded-full bg-accent-blue flex items-center justify-center cursor-pointer">
            <span className="text-small font-semibold text-white">管</span>
          </div>
        </div>
      </motion.header>

      {/* Global Search Modal */}
      <GlobalSearch isOpen={showSearch} onClose={() => setShowSearch(false)} />
    </>
  );
});

export default Navbar;
