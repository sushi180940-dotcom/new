import { memo } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import CountUpNumber from './CountUpNumber';

interface DataCardProps {
  title: string;
  value: number;
  suffix?: string;
  decimals?: number;
  icon?: LucideIcon;
  iconColor?: string;
  trend?: number; // positive = up, negative = down, 0 = flat
  trendLabel?: string;
  sparkline?: number[];
  sparklineColor?: string;
  delay?: number;
  className?: string;
  children?: React.ReactNode;
  onClick?: () => void;
}

const DataCard = memo(function DataCard({
  title,
  value,
  suffix = '',
  decimals = 1,
  icon: Icon,
  iconColor = '#00e5ff',
  trend,
  trendLabel,
  sparkline,
  sparklineColor = '#00e5ff',
  delay = 0,
  className = '',
  children,
  onClick,
}: DataCardProps) {
  const hasTrend = trend !== undefined;
  const trendIsUp = trend && trend > 0;
  const trendIsDown = trend && trend < 0;
  const trendColor = trendIsUp ? '#00f5a0' : trendIsDown ? '#ff4757' : '#6b7fa3';

  // Generate mini sparkline SVG path
  const sparklinePath = sparkline && sparkline.length > 1
    ? (() => {
        const min = Math.min(...sparkline);
        const max = Math.max(...sparkline);
        const range = max - min || 1;
        const w = 120;
        const h = 32;
        const points = sparkline.map((v, i) => {
          const x = (i / (sparkline.length - 1)) * w;
          const y = h - ((v - min) / range) * h;
          return `${x},${y}`;
        });
        return `M ${points.join(' L ')}`;
      })()
    : null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{
        duration: 0.4,
        delay,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      }}
      className={`bg-abyss border border-border-dim rounded-xl p-4 transition-all duration-300 hover:border-border hover:shadow-card ${onClick ? 'cursor-pointer' : ''} ${className}`}
      onClick={onClick}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {Icon && (
            <div
              className="w-5 h-5 flex items-center justify-center rounded"
              style={{ color: iconColor }}
            >
              <Icon className="w-5 h-5" />
            </div>
          )}
          <span className="text-h4 text-text-primary">{title}</span>
        </div>
      </div>

      {/* Value */}
      <div className="flex items-baseline gap-1 mb-2">
        <CountUpNumber
          end={value}
          decimals={decimals}
          suffix={suffix}
          className="font-mono text-mono-lg text-text-primary"
        />
      </div>

      {/* Trend */}
      {hasTrend && (
        <div className="flex items-center gap-1.5 mb-3">
          {trendIsUp ? (
            <ArrowUpRight className="w-3.5 h-3.5" style={{ color: trendColor }} />
          ) : trendIsDown ? (
            <ArrowDownRight className="w-3.5 h-3.5" style={{ color: trendColor }} />
          ) : (
            <Minus className="w-3.5 h-3.5" style={{ color: trendColor }} />
          )}
          <span className="text-small font-medium" style={{ color: trendColor }}>
            {Math.abs(trend).toFixed(1)}%
          </span>
          {trendLabel && (
            <span className="text-small text-text-tertiary ml-1">{trendLabel}</span>
          )}
        </div>
      )}

      {/* Sparkline */}
      {sparklinePath && (
        <svg
          viewBox="0 0 120 32"
          className="w-full h-8 mt-2"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id={`sparklineGrad-${title}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor={sparklineColor} stopOpacity="0.3" />
              <stop offset="100%" stopColor={sparklineColor} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path
            d={sparklinePath}
            fill="none"
            stroke={sparklineColor}
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {/* Fill area under the line */}
          {sparkline && (() => {
            const min = Math.min(...sparkline);
            const max = Math.max(...sparkline);
            const range = max - min || 1;
            const w = 120;
            const h = 32;
            const points = sparkline.map((v, i) => {
              const x = (i / (sparkline.length - 1)) * w;
              const y = h - ((v - min) / range) * h;
              return `${x},${y}`;
            });
            return (
              <path
                d={`M ${points.join(' L ')} L 120,32 L 0,32 Z`}
                fill={`url(#sparklineGrad-${title})`}
              />
            );
          })()}
        </svg>
      )}

      {children}
    </motion.div>
  );
});

export default DataCard;
