import { memo, useState, useEffect } from 'react';
import { RefreshCw } from 'lucide-react';

const Footer = memo(function Footer({ className = '' }: { className?: string }) {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTime = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    const h = String(date.getHours()).padStart(2, '0');
    const min = String(date.getMinutes()).padStart(2, '0');
    const s = String(date.getSeconds()).padStart(2, '0');
    const weekDays = ['日', '一', '二', '三', '四', '五', '六'];
    const w = weekDays[date.getDay()];
    return `${y}年${m}月${d}日 星期${w} ${h}:${min}:${s}`;
  };

  return (
    <footer
      className={`h-[36px] flex items-center justify-between px-6 text-small border-t border-border-dim ${className}`}
      style={{ backgroundColor: 'rgba(5,8,16,0.7)' }}
    >
      <div className="flex items-center gap-3 text-text-tertiary font-mono text-mono-sm">
        <span>省公安厅警保数据资源中心</span>
        <span className="w-1 h-1 rounded-full bg-border-dim" />
        <span className="text-text-secondary">{formatTime(currentTime)}</span>
        <span className="w-1 h-1 rounded-full bg-border-dim" />
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-accent-green" />
          <span className="text-accent-green">正常运行</span>
        </span>
      </div>

      <div className="flex items-center gap-4 text-text-tertiary">
        <div className="flex items-center gap-1.5">
          <RefreshCw className="w-3 h-3" />
          <span>数据已同步</span>
        </div>
        <span>v1.0.0</span>
      </div>
    </footer>
  );
});

export default Footer;
