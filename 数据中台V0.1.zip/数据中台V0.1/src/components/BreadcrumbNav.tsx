import { memo } from 'react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router';

interface BreadcrumbSegment {
  label: string;
  path?: string;
  isActive?: boolean;
}

interface BreadcrumbNavProps {
  segments: BreadcrumbSegment[];
  className?: string;
}

const BreadcrumbNav = memo(function BreadcrumbNav({
  segments,
  className = '',
}: BreadcrumbNavProps) {
  return (
    <nav className={`flex items-center gap-1.5 ${className}`}>
      {segments.map((segment, index) => {
        const isLast = index === segments.length - 1;

        return (
          <div key={index} className="flex items-center gap-1.5">
            {index > 0 && (
              <ChevronRight className="w-3.5 h-3.5 text-text-tertiary flex-shrink-0" />
            )}
            {segment.path && !isLast ? (
              <Link
                to={segment.path}
                className="text-h4 text-text-secondary hover:text-text-primary transition-colors relative group"
              >
                {segment.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-text-link group-hover:w-full transition-all duration-200" />
              </Link>
            ) : (
              <span
                className={`text-h4 ${
                  isLast ? 'text-text-primary' : 'text-text-secondary'
                }`}
              >
                {segment.label}
              </span>
            )}
          </div>
        );
      })}
    </nav>
  );
});

export default BreadcrumbNav;
