import { memo } from 'react';
import { Outlet, useLocation } from 'react-router';
import Navbar from './Navbar';
import PanoramaDock from './PanoramaDock';

const Layout = memo(function Layout() {
  const location = useLocation();
  const isPanoramaPage = location.pathname.startsWith('/panorama/');

  return (
    <div className="h-[100dvh] overflow-hidden" style={{ backgroundColor: '#02040a' }}>
      <Navbar />

      {/* Main content - strictly fills remaining viewport below navbar */}
      <main
        className="overflow-hidden relative"
        style={{
          height: 'calc(100dvh - 56px)',
          marginTop: 56,
        }}
      >
        <Outlet />
      </main>

      {/* Panorama Navigation Dock - only on panorama pages */}
      {isPanoramaPage && <PanoramaDock />}
    </div>
  );
});

export default Layout;
