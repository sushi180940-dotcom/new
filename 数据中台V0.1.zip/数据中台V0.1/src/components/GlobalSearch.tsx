import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, TrendingUp, BarChart3, Map, Users, Building2 } from 'lucide-react';
import { units } from '@/data/mockData';
import type { Unit } from '@/data/mockData';
import { useNavigate } from 'react-router';

interface SearchResult {
  unit: Unit;
  panorama: string;
  panoramaRoute: string;
  score: number;
}

interface GlobalSearchProps {
  isOpen: boolean;
  onClose: () => void;
}

const panoramaMap: { key: string; label: string; route: string; icon: typeof TrendingUp }[] = [
  { key: 'economic', label: '经济运行全景', route: '/panorama/economic', icon: TrendingUp },
  { key: 'financial', label: '财务全景', route: '/panorama/financial', icon: BarChart3 },
  { key: 'asset', label: '资产全景', route: '/panorama/asset', icon: Map },
  { key: 'personnel', label: '人员结构全景', route: '/panorama/personnel', icon: Users },
];

export default function GlobalSearch({ isOpen, onClose }: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const results: SearchResult[] = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();
    const matched: SearchResult[] = [];

    units.forEach((unit) => {
      const nameScore = unit.name.toLowerCase().includes(q) ? 10 : 0;
      const regionScore = unit.region.toLowerCase().includes(q) ? 5 : 0;
      const typeScore = unit.type.toLowerCase().includes(q) ? 3 : 0;
      const totalScore = nameScore + regionScore + typeScore;

      if (totalScore > 0) {
        panoramaMap.forEach((pm) => {
          matched.push({
            unit,
            panorama: pm.label,
            panoramaRoute: pm.route,
            score: totalScore,
          });
        });
      }
    });

    return matched.sort((a, b) => b.score - a.score).slice(0, 20);
  }, [query]);

  const handleSelect = useCallback((result: SearchResult) => {
    onClose();
    navigate(result.panoramaRoute);
    setQuery('');
  }, [navigate, onClose]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Cmd/Ctrl + K to open
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (!isOpen) {
          // This would need to be triggered from parent
        }
      }

      if (!isOpen) return;

      switch (e.key) {
        case 'Escape':
          e.preventDefault();
          onClose();
          break;
        case 'ArrowDown':
          e.preventDefault();
          setSelectedIndex((prev) => Math.min(prev + 1, results.length - 1));
          break;
        case 'ArrowUp':
          e.preventDefault();
          setSelectedIndex((prev) => Math.max(prev - 1, 0));
          break;
        case 'Enter':
          e.preventDefault();
          if (results[selectedIndex]) {
            handleSelect(results[selectedIndex]);
          }
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, results, selectedIndex, handleSelect]);

  // Focus input on open
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 100);
      setQuery('');
      setSelectedIndex(0);
    }
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 z-[60] flex items-start justify-center pt-[15vh]"
          onClick={onClose}
        >
          {/* Backdrop */}
          <div className="absolute inset-0" style={{ backgroundColor: 'rgba(5,8,16,0.85)' }} />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: -10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: -10 }}
            transition={{
              type: 'spring',
              stiffness: 300,
              damping: 25,
            }}
            className="relative w-full max-w-[640px] mx-4 rounded-xl overflow-hidden"
            style={{
              backgroundColor: '#050810',
              border: '1px solid #2a3a5c',
              boxShadow: '0 0 80px rgba(33,81,245,0.15)',
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Input */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-border-dim">
              <Search className="w-5 h-5 text-text-tertiary flex-shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setSelectedIndex(0);
                }}
                placeholder="搜索单位名称..."
                className="flex-1 bg-transparent text-body text-text-primary placeholder-text-tertiary outline-none border-none"
                autoComplete="off"
              />
              <button
                onClick={onClose}
                className="flex items-center gap-1 px-1.5 py-1 rounded bg-surface text-text-tertiary hover:text-text-primary transition-colors"
              >
                <span className="text-small">ESC</span>
              </button>
            </div>

            {/* Results */}
            <div className="max-h-[400px] overflow-y-auto">
              {results.length > 0 ? (
                <div className="py-2">
                  {results.map((result, index) => {
                    const PanoramaIcon = panoramaMap.find(p => p.route === result.panoramaRoute)?.icon ?? Building2;
                    const isSelected = index === selectedIndex;

                    return (
                      <button
                        key={`${result.unit.id}-${result.panorama}`}
                        onClick={() => handleSelect(result)}
                        onMouseEnter={() => setSelectedIndex(index)}
                        className={`w-full flex items-center gap-3 px-5 py-3 text-left transition-colors ${
                          isSelected ? 'bg-surface' : 'hover:bg-[rgba(16,22,40,0.5)]'
                        }`}
                      >
                        <PanoramaIcon className="w-4 h-4 text-text-tertiary flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-body text-text-primary font-medium">
                              {result.unit.name}
                            </span>
                            <span
                              className="px-1.5 py-0.5 rounded-sm text-small font-medium"
                              style={{
                                backgroundColor: 'rgba(33,81,245,0.15)',
                                color: '#4f8af7',
                              }}
                            >
                              {result.unit.type}
                            </span>
                          </div>
                          <span className="text-small text-text-secondary">
                            {result.panorama} · {result.unit.region}
                          </span>
                        </div>
                        <span className="text-small text-text-tertiary">进入</span>
                      </button>
                    );
                  })}
                </div>
              ) : query.trim() ? (
                <div className="flex flex-col items-center justify-center py-12 text-text-tertiary">
                  <Building2 className="w-10 h-10 mb-3 opacity-30" />
                  <p className="text-body">未找到匹配的单位</p>
                  <p className="text-small mt-1">尝试其他关键词</p>
                </div>
              ) : (
                <div className="py-4 px-5">
                  <p className="text-small text-text-tertiary mb-3">快捷导航</p>
                  <div className="grid grid-cols-2 gap-2">
                    {panoramaMap.map((pm) => (
                      <button
                        key={pm.key}
                        onClick={() => {
                          onClose();
                          navigate(pm.route);
                        }}
                        className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[rgba(16,22,40,0.5)] hover:bg-surface transition-colors text-left"
                      >
                        <pm.icon className="w-4 h-4 text-text-secondary" />
                        <span className="text-small text-text-primary">{pm.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
