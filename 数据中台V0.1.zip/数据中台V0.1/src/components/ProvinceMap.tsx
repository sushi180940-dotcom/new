import { memo, useState, useCallback } from 'react';
import type { Unit } from '@/data/mockData';

interface ProvinceMapProps {
  units: Unit[];
  selectedUnitId?: string | null;
  onUnitClick?: (unit: Unit) => void;
  onUnitHover?: (unit: Unit | null) => void;
  className?: string;
  heatmapMode?: 'economic' | 'financial' | 'asset' | 'personnel' | null;
}

// Color mapping for heatmap based on status
const statusColors: Record<string, string> = {
  normal: 'rgba(0, 245, 160, 0.35)',
  warning: 'rgba(255, 209, 102, 0.35)',
  critical: 'rgba(255, 71, 87, 0.35)',
};

const statusGlowColors: Record<string, string> = {
  normal: 'rgba(0, 245, 160, 0.6)',
  warning: 'rgba(255, 209, 102, 0.6)',
  critical: 'rgba(255, 71, 87, 0.6)',
};

const regionPaths: { id: string; name: string; d: string }[] = [
  { id: 'r1', name: '省会市', d: 'M 140 160 L 220 140 L 260 180 L 250 250 L 180 280 L 130 230 Z' },
  { id: 'r2', name: '东江市', d: 'M 260 180 L 380 150 L 420 200 L 400 280 L 320 300 L 250 250 Z' },
  { id: 'r3', name: '西湖市', d: 'M 60 200 L 140 160 L 130 230 L 180 280 L 140 360 L 80 340 L 40 280 Z' },
  { id: 'r4', name: '南山市', d: 'M 180 280 L 250 250 L 320 300 L 300 400 L 220 420 L 140 360 Z' },
  { id: 'r5', name: '北原市', d: 'M 100 60 L 220 40 L 300 80 L 280 140 L 220 140 L 140 160 L 60 200 L 40 140 Z' },
  { id: 'r6', name: '中卫市', d: 'M 220 140 L 280 140 L 300 80 L 400 100 L 420 160 L 380 150 L 260 180 L 250 250 Z' },
];

const ProvinceMap = memo(function ProvinceMap({
  units,
  selectedUnitId,
  onUnitClick,
  onUnitHover,
  className = '',
}: ProvinceMapProps) {
  const [hoveredUnitId, setHoveredUnitId] = useState<string | null>(null);

  const handleUnitMouseEnter = useCallback((unit: Unit) => {
    setHoveredUnitId(unit.id);
    onUnitHover?.(unit);
  }, [onUnitHover]);

  const handleUnitMouseLeave = useCallback(() => {
    setHoveredUnitId(null);
    onUnitHover?.(null);
  }, [onUnitHover]);

  const handleUnitClick = useCallback((unit: Unit) => {
    onUnitClick?.(unit);
  }, [onUnitClick]);

  const mapWidth = 480;
  const mapHeight = 460;

  return (
    <svg
      viewBox={`0 0 ${mapWidth} ${mapHeight}`}
      className={className}
      style={{ width: '100%', height: '100%' }}
    >
      <defs>
        {/* Region gradient */}
        <linearGradient id="regionGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#0a0e1a" />
          <stop offset="100%" stopColor="#101628" />
        </linearGradient>
        <linearGradient id="regionGradHover" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#101628" />
          <stop offset="100%" stopColor="#151d32" />
        </linearGradient>
        {/* Glow filters */}
        <filter id="glow-normal" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feFlood floodColor="#00f5a0" floodOpacity="0.4" />
          <feComposite in2="blur" operator="in" />
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="glow-warning" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feFlood floodColor="#ffd166" floodOpacity="0.4" />
          <feComposite in2="blur" operator="in" />
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
        <filter id="glow-critical" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" result="blur" />
          <feFlood floodColor="#ff4757" floodOpacity="0.4" />
          <feComposite in2="blur" operator="in" />
          <feMerge>
            <feMergeNode />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Background */}
      <rect width={mapWidth} height={mapHeight} fill="transparent" rx="8" />

      {/* Region boundaries */}
      {regionPaths.map((region) => (
        <path
          key={region.id}
          d={region.d}
          fill="url(#regionGrad)"
          stroke="#1e2a45"
          strokeWidth="1"
          strokeLinejoin="round"
          style={{ transition: 'all 0.3s ease' }}
          onMouseEnter={(e) => {
            (e.target as SVGPathElement).setAttribute('fill', 'url(#regionGradHover)');
            (e.target as SVGPathElement).setAttribute('stroke', '#2a3a5c');
          }}
          onMouseLeave={(e) => {
            (e.target as SVGPathElement).setAttribute('fill', 'url(#regionGrad)');
            (e.target as SVGPathElement).setAttribute('stroke', '#1e2a45');
          }}
        />
      ))}

      {/* Region labels */}
      {regionPaths.map((region) => {
        const bbox = getRegionCenter(region.d);
        return (
          <text
            key={`label-${region.id}`}
            x={bbox.x}
            y={bbox.y}
            textAnchor="middle"
            fill="#3d4f70"
            fontSize="11"
            fontFamily="Inter, sans-serif"
            fontWeight="500"
            pointerEvents="none"
          >
            {region.name}
          </text>
        );
      })}

      {/* Unit dots */}
      {units.map((unit) => {
        const isSelected = selectedUnitId === unit.id;
        const isHovered = hoveredUnitId === unit.id;
        const x = (unit.x / 100) * mapWidth;
        const y = (unit.y / 100) * mapHeight;
        const radius = unit.type === '总队' ? 8 : unit.type === '支队' ? 6 : 5;
        const glowFilter = unit.status === 'normal'
          ? 'url(#glow-normal)'
          : unit.status === 'warning'
            ? 'url(#glow-warning)'
            : 'url(#glow-critical)';

        return (
          <g
            key={unit.id}
            style={{ cursor: 'pointer' }}
            onMouseEnter={() => handleUnitMouseEnter(unit)}
            onMouseLeave={handleUnitMouseLeave}
            onClick={() => handleUnitClick(unit)}
          >
            {/* Pulse ring for selected or critical */}
            {(isSelected || unit.status === 'critical') && (
              <circle
                cx={x}
                cy={y}
                r={radius + 6}
                fill="none"
                stroke={statusGlowColors[unit.status]}
                strokeWidth="1.5"
                opacity={0.6}
              >
                <animate
                  attributeName="r"
                  from={radius + 2}
                  to={radius + 16}
                  dur="2s"
                  repeatCount="indefinite"
                />
                <animate
                  attributeName="opacity"
                  from="0.6"
                  to="0"
                  dur="2s"
                  repeatCount="indefinite"
                />
              </circle>
            )}

            {/* Outer glow */}
            {(isSelected || isHovered) && (
              <circle
                cx={x}
                cy={y}
                r={radius + 4}
                fill={statusColors[unit.status]}
                filter={glowFilter}
                style={{ transition: 'all 0.2s ease' }}
              />
            )}

            {/* Main dot */}
            <circle
              cx={x}
              cy={y}
              r={isHovered ? radius + 2 : radius}
              fill={statusGlowColors[unit.status]}
              stroke={isSelected ? '#ffffff' : 'rgba(2,4,10,0.8)'}
              strokeWidth={isSelected ? 2 : 1}
              style={{ transition: 'all 0.2s ease' }}
            />

            {/* Type badge */}
            {(isSelected || isHovered) && (
              <g>
                <rect
                  x={x - 18}
                  y={y - radius - 18}
                  width={36}
                  height={14}
                  rx={7}
                  fill="#050810"
                  stroke={statusGlowColors[unit.status]}
                  strokeWidth="0.5"
                />
                <text
                  x={x}
                  y={y - radius - 9}
                  textAnchor="middle"
                  fill={statusGlowColors[unit.status]}
                  fontSize="8"
                  fontFamily="Inter, sans-serif"
                  fontWeight="600"
                >
                  {unit.name}
                </text>
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
});

// Helper to compute region label center from SVG path
function getRegionCenter(d: string): { x: number; y: number } {
  const matches = d.match(/[-+]?[0-9]*\.?[0-9]+/g);
  if (!matches) return { x: 240, y: 230 };
  const coords = matches.map(Number);
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (let i = 0; i < coords.length; i += 2) {
    if (!isNaN(coords[i])) {
      minX = Math.min(minX, coords[i]);
      maxX = Math.max(maxX, coords[i]);
    }
    if (!isNaN(coords[i + 1])) {
      minY = Math.min(minY, coords[i + 1]);
      maxY = Math.max(maxY, coords[i + 1]);
    }
  }
  return { x: (minX + maxX) / 2, y: (minY + maxY) / 2 };
}

export default ProvinceMap;
