import { memo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, BarChart3, Map, Users } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router';
import type { LucideIcon } from 'lucide-react';

interface DockItem {
  path: string;
  label: string;
  icon: LucideIcon;
}

const dockItems: DockItem[] = [
  { path: '/panorama/economic', label: '经济运行', icon: TrendingUp },
  { path: '/panorama/financial', label: '财务全景', icon: BarChart3 },
  { path: '/panorama/asset', label: '资产全景', icon: Map },
  { path: '/panorama/personnel', label: '人员全景', icon: Users },
];

const PanoramaDock = memo(function PanoramaDock() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleNav = useCallback((path: string) => {
    navigate(path);
  }, [navigate]);

  return (
    <motion.nav
      initial={{ y: 40, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{
        duration: 0.5,
        delay: 0.8,
        ease: [0.16, 1, 0.3, 1] as [number, number, number, number],
      }}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 flex items-center gap-1 px-1.5 py-1.5 rounded-full"
      style={{
        backgroundColor: 'rgba(5, 8, 16, 0.85)',
        backdropFilter: 'blur(16px)',
        WebkitBackdropFilter: 'blur(16px)',
        border: '1px solid #2a3a5c',
      }}
    >
      {dockItems.map((item) => {
        const isActive = location.pathname === item.path;
        const Icon = item.icon;

        return (
          <button
            key={item.path}
            onClick={() => handleNav(item.path)}
            className={`relative flex items-center gap-2 px-5 py-2 rounded-full text-small transition-all duration-300 ${
              isActive
                ? 'text-white'
                : 'text-text-secondary hover:text-text-primary hover:bg-surface'
            }`}
            style={isActive ? {
              backgroundColor: '#2151f5',
              boxShadow: '0 0 20px rgba(33,81,245,0.4)',
            } : {}}
          >
            {isActive && (
              <motion.div
                layoutId="dock-active-indicator"
                className="absolute inset-0 rounded-full"
                style={{ backgroundColor: '#2151f5' }}
                transition={{
                  type: 'spring',
                  stiffness: 400,
                  damping: 30,
                }}
              />
            )}
            <Icon className="w-4 h-4 relative z-10" />
            <span className="relative z-10 font-medium whitespace-nowrap">{item.label}</span>
          </button>
        );
      })}
    </motion.nav>
  );
});

export default PanoramaDock;
