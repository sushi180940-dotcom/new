import { memo } from 'react';

interface ColorScaleCellProps {
  value: number;
  min?: number;
  max?: number;
  lowIsGood?: boolean;
  decimals?: number;
  suffix?: string;
  className?: string;
}

/**
 * Table cell with gradient background based on value.
 * By default: green for low values, red for high values.
 * Set lowIsGood=false to invert (red for low, green for high).
 */
const ColorScaleCell = memo(function ColorScaleCell({
  value,
  min = 0,
  max = 100,
  lowIsGood = true,
  decimals = 1,
  suffix = '',
  className = '',
}: ColorScaleCellProps) {
  const clampedValue = Math.max(min, Math.min(max, value));
  const ratio = (clampedValue - min) / (max - min);

  // Determine color based on ratio and lowIsGood
  let r: number, g: number, b: number;

  if (lowIsGood) {
    // 0 = green (#00f5a0), 0.5 = yellow (#ffd166), 1 = red (#ff4757)
    if (ratio <= 0.5) {
      const t = ratio * 2;
      r = Math.round(0 + (255 - 0) * t);
      g = Math.round(245 + (209 - 245) * t);
      b = Math.round(160 + (102 - 160) * t);
    } else {
      const t = (ratio - 0.5) * 2;
      r = Math.round(255 + (255 - 255) * t);
      g = Math.round(209 + (71 - 209) * t);
      b = Math.round(102 + (87 - 102) * t);
    }
  } else {
    // 0 = red (#ff4757), 0.5 = yellow (#ffd166), 1 = green (#00f5a0)
    if (ratio <= 0.5) {
      const t = ratio * 2;
      r = Math.round(255 + (255 - 255) * t);
      g = Math.round(71 + (209 - 71) * t);
      b = Math.round(87 + (102 - 87) * t);
    } else {
      const t = (ratio - 0.5) * 2;
      r = Math.round(255 + (0 - 255) * t);
      g = Math.round(209 + (245 - 209) * t);
      b = Math.round(102 + (160 - 102) * t);
    }
  }

  const bgColor = `rgba(${r}, ${g}, ${b}, 0.15)`;
  const textColor = `rgb(${r}, ${g}, ${b})`;

  return (
    <span
      className={`inline-flex items-center justify-center px-2 py-1 rounded-sm font-mono text-mono-sm ${className}`}
      style={{ backgroundColor: bgColor, color: textColor }}
    >
      {value.toFixed(decimals)}{suffix}
    </span>
  );
});

export default ColorScaleCell;
