import { memo } from 'react';
import type { UnitStatus } from '@/data/mockData';

interface StatusDotProps {
  status: UnitStatus;
  size?: 'sm' | 'md' | 'lg';
  pulse?: boolean;
  className?: string;
}

const sizeMap = {
  sm: 'w-[6px] h-[6px]',
  md: 'w-2.5 h-2.5',
  lg: 'w-3 h-3',
};

const statusColorMap: Record<UnitStatus, string> = {
  normal: 'bg-[#00f5a0]',
  warning: 'bg-[#ffd166]',
  critical: 'bg-[#ff4757]',
};

const StatusDot = memo(function StatusDot({
  status,
  size = 'sm',
  pulse = true,
  className = '',
}: StatusDotProps) {
  const baseClasses = `rounded-full inline-block ${sizeMap[size]} ${statusColorMap[status]} ${className}`;

  if (pulse && status === 'critical') {
    return (
      <span className="relative inline-flex">
        <span className={`${baseClasses}`} />
        <span
          className="absolute inset-0 rounded-full bg-[#ff4757] animate-pulse-ring"
          style={{ animation: 'pulse-ring 2s ease-out infinite' }}
        />
      </span>
    );
  }

  return <span className={baseClasses} />;
});

export default StatusDot;
