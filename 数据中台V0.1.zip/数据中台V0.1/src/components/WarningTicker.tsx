import { memo, useCallback } from 'react';
import { AlertTriangle, AlertCircle } from 'lucide-react';
import type { WarningItem } from '@/data/mockData';

interface WarningTickerProps {
  items: WarningItem[];
  speed?: number; // px per second
  className?: string;
  onItemClick?: (item: WarningItem) => void;
}

const WarningTicker = memo(function WarningTicker({
  items,
  speed = 80,
  className = '',
  onItemClick,
}: WarningTickerProps) {
  const handleItemClick = useCallback((item: WarningItem) => {
    onItemClick?.(item);
  }, [onItemClick]);

  if (items.length === 0) return null;

  // Duplicate items for seamless loop
  const allItems = [...items, ...items, ...items];

  // Calculate animation duration based on content width
  const contentWidth = items.length * 400; // rough estimate per item
  const duration = contentWidth / speed;

  return (
    <div className={`relative overflow-hidden ${className}`}>
      <div className="flex items-center h-full">
        {/* Label */}
        <div className="flex-shrink-0 flex items-center gap-2 px-8 pr-6 z-10"
          style={{ background: 'linear-gradient(90deg, #0a0e1a 0%, #0a0e1a 80%, transparent 100%)' }}>
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff4757] opacity-75" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#ff4757]" />
          </span>
          <span className="text-small font-semibold text-[#ff4757] whitespace-nowrap">实时预警</span>
        </div>

        {/* Scrolling marquee */}
        <div className="flex-1 overflow-hidden relative">
          <div
            className="flex items-center gap-0 whitespace-nowrap"
            style={{
              animation: `marquee ${duration}s linear infinite`,
            }}
          >
            {allItems.map((item, index) => (
              <button
                key={`${item.id}-${index}`}
                onClick={() => handleItemClick(item)}
                className="inline-flex items-center gap-2 px-4 py-1 hover:bg-[rgba(255,71,87,0.05)] rounded-sm transition-colors cursor-pointer border-none bg-transparent"
              >
                {item.severity === 'critical' ? (
                  <AlertCircle className="w-3.5 h-3.5 text-[#ff4757] flex-shrink-0" />
                ) : (
                  <AlertTriangle className="w-3.5 h-3.5 text-[#ffd166] flex-shrink-0" />
                )}
                <span
                  className="text-small font-medium"
                  style={{ color: item.severity === 'critical' ? '#ff4757' : '#ffd166' }}
                >
                  {item.unitName}
                </span>
                <span className="text-small text-[#6b7fa3]">— {item.message}</span>
                <span className="text-small text-[#3d4f70] ml-1">{item.timestamp}</span>
                {index < allItems.length - 1 && (
                  <span className="text-[#1e2a45] mx-2">·</span>
                )}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
});

export default WarningTicker;
