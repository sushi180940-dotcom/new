import { Routes, Route } from 'react-router';
import Layout from './components/Layout';
import Home from './pages/Home';
import EconomicPanorama from './pages/EconomicPanorama';
import FinancialPanorama from './pages/FinancialPanorama';
import AssetPanorama from './pages/AssetPanorama';
import PersonnelPanorama from './pages/PersonnelPanorama';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/panorama/economic" element={<EconomicPanorama />} />
        <Route path="/panorama/financial" element={<FinancialPanorama />} />
        <Route path="/panorama/asset" element={<AssetPanorama />} />
        <Route path="/panorama/personnel" element={<PersonnelPanorama />} />
      </Route>
    </Routes>
  );
}
