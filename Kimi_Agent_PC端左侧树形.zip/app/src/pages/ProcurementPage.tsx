import { useState, useEffect } from 'react'

interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}

const tabList = [
  { key: 'purchase', label: '装备需求申报' },
  { key: 'contract', label: '合同管理' },
  { key: 'order', label: '订单管理' },
]

type ApprovalStatus = 'draft' | 'budget_approved' | 'submitted' | 'unit_pending' | 'unit_rejected' | 'jb_pending' | 'jb_rejected' | 'approved'

interface OrgNode {
  id: string
  label: string
  expanded?: boolean
  children?: OrgNode[]
}

const orgTreeData: OrgNode[] = [
  {
    id: 'org-root',
    label: '省公安厅',
    expanded: true,
    children: [
      { id: 'org-zhzx', label: '指挥中心' },
      { id: 'org-xjzd', label: '刑警支队' },
      { id: 'org-zazd', label: '治安支队' },
      { id: 'org-jjzd', label: '交警支队' },
      { id: 'org-twjd', label: '特警支队' },
      {
        id: 'org-kffj', label: '开发区分局',
        children: [
          { id: 'org-kfpcs', label: '开发区派出所' },
          { id: 'org-kfjws', label: '开发区警务室' },
        ]
      },
      {
        id: 'org-gxfj', label: '高新分局',
        children: [
          { id: 'org-gxpcs', label: '高新派出所' },
          { id: 'org-gxjws', label: '高新警务室' },
        ]
      },
    ]
  }
]

export default function ProcurementPage({ activeSubTab, onNavigate }: Props) {
  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'purchase')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [drawerTitle, setDrawerTitle] = useState('')
  const [selectedRow, setSelectedRow] = useState<any>(null)
  const [syncLogOpen, setSyncLogOpen] = useState(false)



  // Drawer read-only mode (true when viewing, false when adding/editing)
  const isDrawerReadOnly = !!selectedRow && drawerTitle.startsWith('需求详情')



  // Line items for purchase detail
  const [lineItems, setLineItems] = useState([
    { id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' },
  ])

  // Contract form states
  const [linkedPurchase, setLinkedPurchase] = useState('')
  const [contractName, setContractName] = useState('')
  const [supplierSearch, setSupplierSearch] = useState('')
  const [contractFiles, setContractFiles] = useState<{ id: string; name: string; size: string }[]>([])
  const [orderConfirmOpen, setOrderConfirmOpen] = useState(false)
  const [completeConfirmOpen, setCompleteConfirmOpen] = useState(false)
  const [terminateReason, setTerminateReason] = useState('')
  const [terminateConfirmOpen, setTerminateConfirmOpen] = useState(false)
  const [storageConfirmOpen, setStorageConfirmOpen] = useState(false)
  const [orderModalOpen, setOrderModalOpen] = useState(false)
  const [acceptModalOpen, setAcceptModalOpen] = useState(false)
  const [acceptForm, setAcceptForm] = useState({
    itemName: '',
    result: 'pass' as 'pass' | 'fail',
    opinion: '',
    checker: '当前用户',
    checkTime: new Date().toISOString().slice(0, 16),
    handleWay: '',
  })
  const [acceptViewMode, setAcceptViewMode] = useState(false)
  const [purchaseDropdownOpen, setPurchaseDropdownOpen] = useState(false)
  const [supplierDropdownOpen, setSupplierDropdownOpen] = useState(false)
  // 订单弹窗中供应商搜索
  const [orderSupplier, setOrderSupplier] = useState('')
  const [orderSupplierOpen, setOrderSupplierOpen] = useState(false)
  // 新增企业弹窗
  const [addSupplierOpen, setAddSupplierOpen] = useState(false)
  const [newSupplierName, setNewSupplierName] = useState('')
  const [newSupplierCode, setNewSupplierCode] = useState('')
  const [newSupplierShort, setNewSupplierShort] = useState('')
  const [newSupplierTech, setNewSupplierTech] = useState('')
  const [newSupplierPhone, setNewSupplierPhone] = useState('')
  const [newSupplierPolice, setNewSupplierPolice] = useState('否')
  const [newSupplierSecret, setNewSupplierSecret] = useState('否')
  const [newSupplierStatus, setNewSupplierStatus] = useState('正常')
  const [newSupplierTypes, setNewSupplierTypes] = useState<string[]>([])
  const [newSupplierRemark, setNewSupplierRemark] = useState('')
  // 申请单位下拉树
  const [applyUnitOpen, setApplyUnitOpen] = useState(false)
  const [applyUnitVal, setApplyUnitVal] = useState('')
  const [applyUnitId, setApplyUnitId] = useState('')
  const [applyUnitSearch, setApplyUnitSearch] = useState('')
  const [orgTreeExpanded, setOrgTreeExpanded] = useState<Record<string, boolean>>({ 'org-root': true })

  const [supplierListState, setSupplierListState] = useState([
    '华为技术', '海康威视', '大疆创新', '中兴通讯', '烽火通信', '浪潮集团', '科大讯飞', '大华股份', '宇视科技', '科达股份'
  ])

  // 装备选择弹窗
  const [equipSelectOpen, setEquipSelectOpen] = useState(false)
  const [equipC1, setEquipC1] = useState('全部')
  const [equipC2, setEquipC2] = useState('全部')
  const [equipC3, setEquipC3] = useState('全部')
  const [equipNameSearch, setEquipNameSearch] = useState('')
  const [selectedEquips, setSelectedEquips] = useState<{ equip: EquipBase; qty: number }[]>([])

  // 装备基础数据
  interface EquipBase {
    id: string; name: string; code: string
    category1: string; category2: string; category3: string
    spec: string; stockQty: number; unit: string; unitPrice: number
  }
  const equipBaseData: EquipBase[] = [
    { id: 'e1', name: '手持终端 XT-2000', code: 'ZB-2023-001', category1: '通信设备', category2: '指挥调度装备', category3: '指挥决策', spec: 'XT-2000/黑色', stockQty: 50, unit: '台', unitPrice: 3200 },
    { id: 'e2', name: '对讲机 PD780G', code: 'ZB-2023-002', category1: '通信设备', category2: '通信保障装备', category3: '无线通信', spec: 'PD780G/U段', stockQty: 30, unit: '台', unitPrice: 1800 },
    { id: 'e3', name: '执法记录仪 DSJ-A7', code: 'ZB-2023-003', category1: '记录设备', category2: '现场记录装备', category3: '执法记录', spec: 'DSJ-A7/64G', stockQty: 80, unit: '台', unitPrice: 1200 },
    { id: 'e4', name: '防弹背心 FDY-3R', code: 'ZB-2023-004', category1: '防护装备', category2: '个人防护装备', category3: '防弹防护', spec: 'FDY-3R/三级', stockQty: 20, unit: '件', unitPrice: 2500 },
    { id: 'e5', name: '战术头盔 MICH-2000', code: 'ZB-2023-005', category1: '防护装备', category2: '个人防护装备', category3: '头部防护', spec: 'MICH-2000/L号', stockQty: 15, unit: '顶', unitPrice: 1500 },
    { id: 'e6', name: '警用强光手电', code: 'ZB-2023-006', category1: '应急装备', category2: '照明装备', category3: '手持照明', spec: 'CREE T6/1000流明', stockQty: 100, unit: '根', unitPrice: 280 },
    { id: 'e7', name: '急救包 JJB-A', code: 'ZB-2023-009', category1: '应急装备', category2: '医疗急救装备', category3: '急救包', spec: 'JJB-A/综合型', stockQty: 40, unit: '个', unitPrice: 220 },
    { id: 'e8', name: '防暴盾牌 FB-P', code: 'ZB-2023-007', category1: '防护装备', category2: '防暴防护装备', category3: '防暴盾牌', spec: 'FB-P/铝合金', stockQty: 25, unit: '面', unitPrice: 800 },
    { id: 'e9', name: '伸缩警棍 ZG-T', code: 'ZB-2023-008', category1: '应急装备', category2: '制服装备', category3: '警棍', spec: 'ZG-T/钛合金', stockQty: 60, unit: '根', unitPrice: 350 },
    { id: 'e10', name: '卫星便携站', code: 'ZB-2023-015', category1: '通信设备', category2: '应急通信装备', category3: '卫星通信', spec: '便携式/2.4m天线', stockQty: 5, unit: '套', unitPrice: 120000 },
    { id: 'e11', name: '调度控制台', code: 'ZB-2023-016', category1: '通信设备', category2: '指挥调度装备', category3: '指挥决策', spec: '三联屏/可升降', stockQty: 3, unit: '套', unitPrice: 45000 },
    { id: 'e12', name: '消防水带', code: 'ZB-2023-017', category1: '应急装备', category2: '消防装备', category3: '灭火器材', spec: '65mm/20m/有衬里', stockQty: 200, unit: '条', unitPrice: 180 },
  ]
  const supplierList = supplierListState

  const approvedPurchases = [
    { id: 'CG2024015', project: '[XM2024015] 2025年度应急物资储备扩充', name: '应急发电一体机', amount: 680000 },
    { id: 'CG2024011', project: '[XM2024011] 2025年度消防装备更新项目', name: '消防水带', amount: 36000 },
    { id: 'CG2024012', project: '[XM2024012] 2025年度指挥调度系统建设', name: '调度控制台', amount: 360000 },
    { id: 'CG2024013', project: '[XM2024013] 2025年度救援车辆配备项目', name: '液压破拆工具组', amount: 510000 },
    { id: 'CG2024014', project: '[XM2024014] 2025年度通信保障设备采购', name: '卫星便携站', amount: 500000 },
  ]

  const addLineItem = () => {
    setLineItems(prev => [...prev, { id: Date.now(), name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }])
  }

  const removeLineItem = (id: number) => {
    setLineItems(prev => prev.filter(item => item.id !== id))
  }

  const updateLineItem = (id: number, field: string, value: string | number) => {
    setLineItems(prev => prev.map(item => {
      if (item.id === id) {
        const updated = { ...item, [field]: value }
        if (field === 'qty' || field === 'price') {
          updated.amount = Number(updated.qty) * Number(updated.price)
        }
        return updated
      }
      return item
    }))
  }

  const totalAmount = lineItems.reduce((sum, item) => sum + item.amount, 0)

  useEffect(() => {
    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {
      setActiveTab(activeSubTab)
    }
  }, [activeSubTab])


  const purchaseData = [
    { id: 'CG2024011', projectName: '2025年度消防装备更新项目', projectType: '货物采购', budget: 360000, source: '财政', multiYear: false, applyUnit: '消防支队', operator: '王强', projectIntro: '更新消防水带等装备，提升消防救援能力。', projectJustify: '现有装备老化严重，需及时更新换代。', applyDate: '2024-03-01', status: 'draft' as ApprovalStatus },
    { id: 'CG2024012', projectName: '2025年度指挥调度系统建设', projectType: '系统集成', budget: 360000, source: '专项', multiYear: true, applyUnit: '指挥中心', operator: '李明', projectIntro: '建设新一代指挥调度系统，提升应急响应效率。', projectJustify: '现有系统已无法满足日益增长的指挥调度需求。', applyDate: '2024-03-05', status: 'submitted' as ApprovalStatus },
    { id: 'CG2024013', projectName: '2025年度救援车辆配备项目', projectType: '货物采购', budget: 510000, source: '自筹', multiYear: false, applyUnit: '救援队', operator: '陈刚', projectIntro: '配备液压破拆工具组，提升车辆救援能力。', projectJustify: '根据年度工作计划，需补充救援装备。', applyDate: '2024-03-08', status: 'unit_pending' as ApprovalStatus },
    { id: 'CG2024014', projectName: '2025年度通信保障设备采购', projectType: '货物采购', budget: 500000, source: '财政', multiYear: false, applyUnit: '通信处', operator: '刘洋', projectIntro: '采购卫星便携站等通信保障设备。', projectJustify: '保障应急通信能力，满足实战需求。', applyDate: '2024-03-10', status: 'jb_pending' as ApprovalStatus },
    { id: 'CG2024015', projectName: '2025年度应急物资储备扩充', projectType: '货物采购', budget: 680000, source: '专项', multiYear: true, applyUnit: '应急管理处', operator: '赵峰', projectIntro: '扩充应急发电一体机等储备物资。', projectJustify: '提升应急物资储备水平，保障突发事件应对能力。', applyDate: '2024-03-12', status: 'approved' as ApprovalStatus },
    { id: 'CG2024016', projectName: '2025年度防汛排涝设备采购', projectType: '货物采购', budget: 360000, source: '其他', multiYear: false, applyUnit: '防汛办', operator: '周伟', projectIntro: '采购移动排水泵车等防汛设备。', projectJustify: '汛期将至，需提前配备防汛排涝装备。', applyDate: '2024-03-15', status: 'budget_approved' as ApprovalStatus },
  ]

  const contractData = [
    { id: 'HT2024001', purchaseId: 'CG2024015', supplier: '华为技术', amount: 680000, date: '2024-03-10', status: 'draft', applicant: '王强', name: '应急物资储备扩充合同' },
    { id: 'HT2024002', purchaseId: 'CG2024012', supplier: '海康威视', amount: 360000, date: '2024-03-15', status: 'fulfilling', applicant: '李明', name: '指挥调度系统建设合同' },
    { id: 'HT2024003', purchaseId: 'CG2024014', supplier: '中兴通讯', amount: 500000, date: '2024-03-20', status: 'accepted', applicant: '赵峰', name: '通信保障设备采购合同' },
    { id: 'HT2024004', purchaseId: 'CG2024013', supplier: '大疆创新', amount: 510000, date: '2024-03-25', status: 'completed', applicant: '陈刚', name: '救援车辆配备合同' },
    { id: 'HT2024005', purchaseId: 'CG2024015', supplier: '华为技术', amount: 680000, date: '2024-03-10', status: 'terminated', applicant: '王强', name: '应急物资储备扩充合同（终止）', terminateReason: '供应商产能不足，无法按期交货，经双方协商一致终止合同。' },
  ]

  type OrderStatus = 'pending_ship' | 'partial_ship' | 'pending_storage' | 'stored'

  const orderData = [
    {
      id: 'DD2024001', contractId: 'HT2024002', contractName: '指挥调度系统建设合同', supplier: '海康威视',
      status: 'pending_ship' as OrderStatus, deliveryDate: '2024-04-15', applicant: '张三',
      items: [
        { id: 1, code: 'ZB-2025-010', name: '调度控制台', spec: '双屏/42U', brand: '海康威视', manufacturer: '海康威视数字技术股份有限公司', unit: '套', qty: 8, price: 45000, amount: 360000, location: '指挥中心', standard: 'GB/T 28181', warranty: '3年', note: '含安装调试', checkStatus: 'pending' as const },
      ],
    },
    {
      id: 'DD2024002', contractId: 'HT2024003', contractName: '通信保障设备采购合同', supplier: '中兴通讯',
      status: 'pending_ship' as OrderStatus, deliveryDate: '2024-04-20', applicant: '李四',
      items: [
        { id: 1, code: 'ZB-2025-001', name: '卫星便携站', spec: 'Ku频段/2Mbps', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '套', qty: 2, price: 125000, amount: 250000, location: '通信保障车', standard: 'GJB 5231', warranty: '5年', note: '', checkStatus: 'pending' as const },
        { id: 2, code: 'ZB-2025-011', name: '手持对讲机', spec: '数字/双模', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 5, price: 3500, amount: 17500, location: '通信保障车', standard: 'GB/T 15844', warranty: '2年', note: '', checkStatus: 'pending' as const },
        { id: 3, code: 'ZB-2025-012', name: '车载电台', spec: 'VHF/50W', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 3, price: 15000, amount: 45000, location: '通信保障车', standard: 'GJB 150', warranty: '2年', note: '', checkStatus: 'pending' as const },
        { id: 4, code: 'ZB-2025-013', name: '基站放大器', spec: '2W/双频', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 2, price: 42000, amount: 84000, location: '通信基站', standard: 'GJB 5231', warranty: '5年', note: '', checkStatus: 'pending' as const },
        { id: 5, code: 'ZB-2025-014', name: '光纤熔接机', spec: '全自动/单芯', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 1, price: 28000, amount: 28000, location: '通信机房', standard: 'YD/T 815', warranty: '3年', note: '', checkStatus: 'pending' as const },
        { id: 6, code: 'ZB-2025-015', name: '光功率计', spec: '-70~+10dBm', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 3, price: 3200, amount: 9600, location: '通信机房', standard: 'YD/T 729', warranty: '2年', note: '', checkStatus: 'pending' as const },
        { id: 7, code: 'ZB-2025-016', name: '网络分析仪', spec: '100kHz~3GHz', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 1, price: 58000, amount: 58000, location: '通信机房', standard: 'GJB 3947', warranty: '3年', note: '', checkStatus: 'pending' as const },
        { id: 8, code: 'ZB-2025-017', name: '野战光缆', spec: '单模/2芯', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '千米', qty: 5, price: 4500, amount: 22500, location: '通信保障车', standard: 'YD/T 901', warranty: '3年', note: '', checkStatus: 'pending' as const },
        { id: 9, code: 'ZB-2025-018', name: '通信电源', spec: '48V/50A', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 2, price: 18000, amount: 36000, location: '通信机房', standard: 'YD/T 731', warranty: '3年', note: '', checkStatus: 'pending' as const },
        { id: 10, code: 'ZB-2025-019', name: '便携式天线', spec: '全频段/可折叠', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '套', qty: 4, price: 6500, amount: 26000, location: '通信保障车', standard: 'GJB 150', warranty: '2年', note: '', checkStatus: 'pending' as const },
      ],
    },
    {
      id: 'DD2024003', contractId: 'HT2024004', contractName: '救援车辆配备合同', supplier: '大疆创新',
      status: 'pending_storage' as OrderStatus, deliveryDate: '2024-03-28', applicant: '王五',
      items: [
        { id: 1, code: 'ZB-2025-003', name: '液压破拆工具组', spec: '60MPa/全套', brand: '大疆', manufacturer: '大疆创新科技有限公司', unit: '套', qty: 6, price: 85000, amount: 510000, location: '救援车辆', standard: 'GB 17945', warranty: '3年', note: '', checkStatus: 'pass' as const, checkDetail: { checker: '李强', checkTime: '2025-01-10 14:00', opinion: '全部验收合格', handleWay: '' } },
      ],
    },
    {
      id: 'DD2024004', contractId: 'HT2024001', contractName: '应急物资储备扩充合同', supplier: '华为技术',
      status: 'pending_ship' as OrderStatus, deliveryDate: '2024-05-20', applicant: '赵峰',
      items: [
        { id: 1, code: 'ZB-2025-012', name: '应急发电一体机', spec: '50kW/柴油', brand: '华为', manufacturer: '华为技术有限公司', unit: '台', qty: 10, price: 68000, amount: 680000, location: '应急仓库', standard: 'GB/T 2820', warranty: '3年', note: '需现场安装调试', checkStatus: 'pending' as const },
        { id: 2, code: 'ZB-2025-013', name: 'UPS不间断电源', spec: '10kVA/在线式', brand: '华为', manufacturer: '华为技术有限公司', unit: '台', qty: 5, price: 12000, amount: 60000, location: '通信机房', standard: 'YD/T 1095', warranty: '3年', note: '', checkStatus: 'pending' as const },
      ],
    },
    {
      id: 'DD2024005', contractId: 'HT2024002', contractName: '指挥调度系统建设合同', supplier: '海康威视',
      status: 'partial_ship' as OrderStatus, deliveryDate: '2024-04-30', applicant: '孙丽',
      items: [
        { id: 1, code: 'ZB-2025-005', name: '高清监控摄像头', spec: '400万/红外夜视', brand: '海康威视', manufacturer: '海康威视数字技术股份有限公司', unit: '台', qty: 20, price: 2800, amount: 56000, location: '指挥中心', standard: 'GB/T 28181', warranty: '3年', note: '首批已到货10台', checkStatus: 'pass' as const, checkDetail: { checker: '王刚', checkTime: '2025-01-20 09:15', opinion: '到货20台全部验收合格', handleWay: '' } },
        { id: 2, code: 'ZB-2025-014', name: '高清监控摄像头', spec: '400万/红外夜视', brand: '海康威视', manufacturer: '海康威视数字技术股份有限公司', unit: '台', qty: 10, price: 2800, amount: 28000, location: '指挥中心', standard: 'GB/T 28181', warranty: '3年', note: '待发货', checkStatus: 'pending' as const },
      ],
    },
    {
      id: 'DD2024006', contractId: 'HT2024003', contractName: '通信保障设备采购合同', supplier: '中兴通讯',
      status: 'stored' as OrderStatus, deliveryDate: '2024-03-15', applicant: '周伟',
      items: [
        { id: 1, code: 'ZB-2025-006', name: '手持对讲机', spec: '数字/双模', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 30, price: 3500, amount: 105000, location: '通信保障车', standard: 'GB/T 15844', warranty: '2年', note: '已全部验收', checkStatus: 'pass' as const, checkDetail: { checker: '赵敏', checkTime: '2025-01-12 11:00', opinion: '30台全部验收合格，信号覆盖测试通过', handleWay: '' } },
        { id: 2, code: 'ZB-2025-007', name: '车载电台', spec: 'VHF/50W', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 4, price: 15000, amount: 60000, location: '通信保障车', standard: 'GJB 150', warranty: '2年', note: '已全部验收', checkStatus: 'pass' as const, checkDetail: { checker: '赵敏', checkTime: '2025-01-12 11:30', opinion: '4台全部验收合格', handleWay: '' } },
      ],
    },
    {
      id: 'DD2024007', contractId: 'HT2024001', contractName: '应急物资储备扩充合同', supplier: '华为技术',
      status: 'pending_ship' as OrderStatus, deliveryDate: '2024-06-10', applicant: '吴强',
      items: [
        { id: 1, code: 'ZB-2025-015', name: '强光手电', spec: 'LED/1000流明', brand: '华为', manufacturer: '华为技术有限公司', unit: '支', qty: 100, price: 180, amount: 18000, location: '应急仓库', standard: 'QB/T 2198', warranty: '1年', note: '集中配送', checkStatus: 'pending' as const },
      ],
    },
    {
      id: 'DD2024008', contractId: 'HT2024003', contractName: '通信保障设备采购合同', supplier: '中兴通讯',
      status: 'stored' as OrderStatus, deliveryDate: '2024-04-01', applicant: '郑华',
      items: [
        { id: 1, code: 'ZB-2025-008', name: '基站放大器', spec: '2W/双频', brand: '中兴', manufacturer: '中兴通讯股份有限公司', unit: '台', qty: 3, price: 42000, amount: 126000, location: '通信基站', standard: 'GJB 5231', warranty: '5年', note: '', checkStatus: 'pass' as const, checkDetail: { checker: '刘洋', checkTime: '2025-02-01 09:00', opinion: '全部验收合格', handleWay: '' } },
      ],
    },
  ]

  type AcceptanceStatus = 'pending_check' | 'pending_storage' | 'stored'
  type CheckResult = 'pass' | 'fail'

  const acceptanceData = [
    {
      id: 'YS2024001', orderId: 'DD2024003', contractId: 'HT2024004',
      itemName: '液压破拆工具组', itemSpec: '60MPa/全套',
      code: 'ZB-2025-003', qty: 6, unit: '套',
      result: 'pass' as CheckResult, status: 'pending_storage' as AcceptanceStatus,
      inspector: '赵伟', date: '2024-04-01 10:30',
      problemDesc: '', handleMethod: '', attachments: 3
    },
    {
      id: 'YS2024002', orderId: 'DD2024001', contractId: 'HT2024002',
      itemName: '调度控制台', itemSpec: '双屏/42U',
      code: '待编码', qty: 8, unit: '套',
      result: 'fail' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '孙丽', date: '2024-04-03 14:20',
      problemDesc: '2套控制台外观有轻微划痕，1套缺少电源适配器。', handleMethod: '换货',
      attachments: 5
    },
    {
      id: 'YS2024003', orderId: 'DD2024002', contractId: 'HT2024003',
      itemName: '卫星便携站', itemSpec: 'Ku频段/2Mbps',
      code: 'ZB-2025-001', qty: 2, unit: '套',
      result: 'fail' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '周强', date: '2024-04-05 09:15',
      problemDesc: '设备无法正常开机，经检测为主板故障。', handleMethod: '退货',
      attachments: 2
    },
    {
      id: 'YS2024004', orderId: 'DD2024001', contractId: 'HT2024002',
      itemName: '调度控制台', itemSpec: '双屏/42U',
      code: '待编码', qty: 8, unit: '套',
      result: '' as CheckResult, status: 'pending_check' as AcceptanceStatus,
      inspector: '', date: '',
      problemDesc: '', handleMethod: '',
      attachments: 0
    },
  ]

  const statusMap: Record<ApprovalStatus | string, { label: string; tag: string }> = {
    draft: { label: '草稿', tag: 'tag-gray' },
    budget_approved: { label: '预算批复', tag: 'tag-green' },
    submitted: { label: '提交申请', tag: 'tag-blue' },
    unit_pending: { label: '单位审批', tag: 'tag-yellow' },
    unit_rejected: { label: '单位驳回', tag: 'tag-red' },
    jb_pending: { label: 'JB部审批', tag: 'tag-yellow' },
    jb_rejected: { label: 'JB部驳回', tag: 'tag-red' },
    approved: { label: '审批完成', tag: 'tag-green' },
    executing: { label: '执行中', tag: 'tag-blue' },
    fulfilling: { label: '履行中', tag: 'tag-blue' },
    accepted: { label: '已验收', tag: 'tag-green' },
    pending_ship: { label: '待验收', tag: 'tag-yellow' },
    partial_ship: { label: '部分验收', tag: 'tag-blue' },
    pending_storage: { label: '待入库', tag: 'tag-orange' },
    stored: { label: '已入库', tag: 'tag-green' },
    terminated: { label: '终止/作废', tag: 'tag-red' },
    pass: { label: '合格', tag: 'tag-green' },
    fail: { label: '不合格', tag: 'tag-red' },
  }

  // Approval flow config: 5 nodes
  const flowNodes = [
    { key: 'submitted', label: '提交申请', desc: '申请人：张三', startTime: '2024-03-01 09:00', endTime: '2024-03-01 09:15' },
    { key: 'unit_pending', label: '单位审批', desc: '审批人：单位负责人', startTime: '2024-03-01 10:00', endTime: '2024-03-02 14:30' },
    { key: 'jb_pending', label: 'JB部审批', desc: '审批人：JB部负责人', startTime: '2024-03-02 16:00', endTime: '2024-03-04 11:00' },
    { key: 'budget_approved', label: '预算批复', desc: '自动同步', startTime: '2024-03-04 14:00', endTime: '2024-03-05 09:00' },
    { key: 'approved', label: '审批完成', desc: '全部审批通过', startTime: '2024-03-05 10:00', endTime: '2024-03-05 10:00' },
  ]

  // Determine each node's visual state based on current status
  function getNodeState(nodeKey: string, rowStatus: ApprovalStatus | null, isNew: boolean) {
    if (isNew) {
      // New application: only "提交申请" is done (info filled), rest are waiting
      if (nodeKey === 'submitted') return 'done'
      return 'waiting'
    }

    // Draft: same as new (not yet submitted)
    if (rowStatus === 'draft') {
      if (nodeKey === 'submitted') return 'done'
      return 'waiting'
    }

    // Detail view: determine based on row status
    if (!rowStatus) return 'waiting'

    const statusOrder = ['draft', 'submitted', 'unit_pending', 'unit_rejected', 'jb_pending', 'jb_rejected', 'budget_approved', 'approved']
    const currentIdx = statusOrder.indexOf(rowStatus)
    const nodeIdx = statusOrder.indexOf(nodeKey)

    // rejected states
    if (rowStatus === 'unit_rejected') {
      if (nodeKey === 'submitted') return 'done'
      if (nodeKey === 'unit_pending') return 'rejected'
      return 'skip'
    }
    if (rowStatus === 'jb_rejected') {
      if (nodeKey === 'submitted') return 'done'
      if (nodeKey === 'unit_pending') return 'done'
      if (nodeKey === 'jb_pending') return 'rejected'
      return 'skip'
    }

    // approved - all done
    if (rowStatus === 'approved') {
      return nodeIdx <= currentIdx ? 'done' : 'skip'
    }

    // budget_approved - all prior nodes done
    if (rowStatus === 'budget_approved') {
      if (nodeKey === 'budget_approved') return 'active'
      if (nodeIdx < currentIdx) return 'done'
      return 'skip'
    }

    // pending states (current step is the active one)
    if (nodeIdx < currentIdx) return 'done'
    if (nodeIdx === currentIdx) return 'active'
    return 'waiting'
  }

  // 工作台统计数据
  const totalProjects = purchaseData.length
  const totalBudget = purchaseData.reduce((s, r) => s + (r.budget || 0), 0)
  const totalContractCount = contractData.length
  const totalContract = contractData.reduce((s, r) => s + r.amount, 0)
  const totalPaid = purchaseData.reduce((s, r) => s + Math.floor((r.budget || 0) * 0.6), 0)
  const pendingPurchase = purchaseData.filter(r => r.status === 'submitted' || r.status === 'unit_pending' || r.status === 'jb_pending').length

  // 组织架构辅助函数
  const findOrgNode = (nodes: OrgNode[], id: string): OrgNode | null => {
    for (const n of nodes) {
      if (n.id === id) return n
      if (n.children) {
        const found = findOrgNode(n.children, id)
        if (found) return found
      }
    }
    return null
  }
  const collectOrgNodes = (nodes: OrgNode[]): OrgNode[] => {
    const res: OrgNode[] = []
    nodes.forEach(n => {
      res.push(n)
      if (n.children) res.push(...collectOrgNodes(n.children))
    })
    return res
  }
  const renderOrgTree = (nodes: OrgNode[], depth: number) => {
    return nodes.map(node => {
      const hasChildren = node.children && node.children.length > 0
      const isExpanded = orgTreeExpanded[node.id] ?? false
      const isMatch = !applyUnitSearch || node.label.toLowerCase().includes(applyUnitSearch.toLowerCase())
      if (!isMatch && hasChildren) {
        const childMatch = collectOrgNodes(node.children || []).some(c => c.label.toLowerCase().includes(applyUnitSearch.toLowerCase()))
        if (!childMatch) return null
      }
      if (!isMatch && !hasChildren) return null
      return (
        <div key={node.id}>
          <div
            className={`flex items-center gap-1 px-2 py-1.5 cursor-pointer hover:bg-blue-50 transition-colors ${applyUnitId === node.id ? 'bg-blue-50 text-blue-600 font-medium' : ''}`}
            style={{ paddingLeft: `${12 + depth * 16}px` }}
            onClick={() => {
              if (hasChildren) {
                setOrgTreeExpanded(prev => ({ ...prev, [node.id]: !isExpanded }))
              }
              setApplyUnitVal(node.label)
              setApplyUnitId(node.id)
              setApplyUnitOpen(false)
            }}
          >
            {hasChildren && (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={`transition-transform ${isExpanded ? 'rotate-90' : ''}`}><polyline points="9 18 15 12 9 6"/></svg>
            )}
            {!hasChildren && <span className="w-3" />}
            <span className="text-xs">{node.label}</span>
          </div>
          {hasChildren && isExpanded && renderOrgTree(node.children!, depth + 1)}
        </div>
      )
    }).filter(Boolean)
  }
  const fulfillingContract = contractData.filter(r => r.status === 'fulfilling').length
  const pendingOrder = orderData.filter(r => r.status === 'pending_ship').length
  const pendingAcceptance = acceptanceData.filter(r => r.status === 'pending_check').length

  return (
    <div className="p-6 space-y-4">
      {/* 统计卡片 - 所有页面共享 */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {[
          { label: '总采购项目', value: `${totalProjects} 个`, color: '#1890ff', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01' },
          { label: '总预算金额', value: `¥ ${totalBudget.toLocaleString()}`, color: '#52c41a', icon: 'M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6' },
          { label: '总合同数', value: `${totalContractCount} 个`, color: '#722ed1', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
          { label: '总合同额', value: `¥ ${totalContract.toLocaleString()}`, color: '#eb2f96', icon: 'M20 12V8H6a2 2 0 01-2-2c0-1.1.9-2 2-2h12v4M6 12h14a2 2 0 012 2c0 1.1-.9 2-2 2H6v-4' },
          { label: '已支付金额', value: `¥ ${totalPaid.toLocaleString()}`, color: '#faad14', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-xl font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* 快捷入口 - 所有页面共享 */}
      <div className="content-card p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { key: 'purchase', label: '装备需求申报', desc: '需求申报与审批', count: pendingPurchase, color: '#1890ff', icon: 'M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z' },
            { key: 'contract', label: '合同管理', desc: '合同签订与执行', count: fulfillingContract, color: '#52c41a', icon: 'M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
            { key: 'order', label: '订单管理', desc: '订单验收与管理', count: pendingOrder, color: '#faad14', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': item.color } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                  <path d={item.icon}/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium flex items-center gap-2">
                  {item.label}
                  {item.count > 0 && (
                    <span className="px-1.5 py-0.5 rounded-full text-xs text-white" style={{ background: item.color }}>{item.count}</span>
                  )}
                </div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>

      {/* Search area */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              {activeTab === 'purchase' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购单号</label>
                <input className="form-input w-40" placeholder="请输入采购单号..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属项目</label>
                <input className="form-input w-40" placeholder="请输入项目名称..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                <select className="form-input w-32">
                  <option>全部</option>
                  <option>草稿</option>
                  <option>预算批复</option>
                  <option>提交申请</option>
                  <option>单位审批</option>
                  <option>JB部审批</option>
                  <option>审批完成</option>
                  <option>单位驳回</option>
                  <option>JB部驳回</option>
                </select>
              </div>
            </>
          )}
          {activeTab === 'order' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label>
                <input className="form-input w-40" placeholder="请输入装备名称..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商</label>
                <input className="form-input w-40" placeholder="请输入供应商..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称/合同编号</label>
                <input className="form-input w-44" placeholder="请输入合同信息..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label>
                <select className="form-input w-32">
                  <option>全部</option>
                  <option>待验收</option>
                  <option>部分验收</option>
                  <option>已办结</option>
                </select>
              </div>
            </>
          )}
          {activeTab !== 'purchase' && activeTab !== 'order' && (
            <>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{activeTab === 'contract' ? '合同编号' : '验收单号'}</label>
                <input className="form-input w-40" placeholder="请输入..." />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{activeTab === 'contract' ? '供应商' : '关联订单'}</label>
                <input className="form-input w-40" placeholder="请输入..." />
              </div>
              {activeTab !== 'order' && (
                <div>
                  <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>审批状态</label>
                  <select className="form-input w-32"><option>全部</option><option>草稿</option><option>履行中</option><option>已验收</option><option>已办结</option></select>
                </div>
              )}
            </>
          )}
          <div>
            <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>时间范围</label>
            <div className="flex items-center gap-1">
              <input className="form-input w-32" type="date" />
              <span className="text-gray-400">~</span>
              <input className="form-input w-32" type="date" />
            </div>
          </div>
          <div className="flex gap-2 ml-auto">
            <button className="btn-default">重置</button>
            <button className="btn-primary">查询</button>
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            className="btn-primary flex items-center gap-1"
            onClick={() => {
              if (activeTab === 'order') {
                setSelectedRow(null)
                setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }])
                setOrderModalOpen(true)
              } else {
                setDrawerTitle(activeTab === 'purchase' ? '新增需求申请' : activeTab === 'contract' ? '新增合同' : '')
                setSelectedRow(null)
                setDrawerOpen(true)
              }
            }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            {activeTab === 'order' ? '新增采购订单' : `新增${activeTab === 'purchase' ? '申请' : activeTab === 'contract' ? '合同' : ''}`}
          </button>
          <button className="btn-default flex items-center gap-1">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            导出
          </button>
        </div>
        <div className="flex items-center gap-1 text-xs">
          <span className="px-3 py-1 rounded-full border" style={{ borderColor: 'var(--border-color)' }}>
            {activeTab === 'purchase' ? '待审批 3' : activeTab === 'contract' ? '执行中 2' : activeTab === 'order' ? '待验收 2' : ''}
          </span>
        </div>
      </div>

      {/* Tables */}
      <div className="content-card overflow-hidden">
        {activeTab === 'purchase' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" className="accent-blue-500" /></th>
                <th>采购单号</th><th>项目名称</th><th>项目类型</th><th>采购预算金额</th><th>申请单位</th><th>经办人</th><th>申请日期</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {purchaseData.map(row => (
                <tr key={row.id}>
                  <td><input type="checkbox" className="accent-blue-500" /></td>
                  <td className="font-mono text-xs">{row.id}</td>
                  <td className="text-xs font-medium">{row.projectName}</td>
                  <td><span className="tag tag-gray">{row.projectType}</span></td>
                  <td className="font-mono">¥{row.budget.toLocaleString()}</td>
                  <td>{row.applyUnit}</td>
                  <td>{row.operator}</td>
                  <td className="text-xs">{row.applyDate}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`需求详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>查看</button>
                      {(row.status === 'draft' || row.status === 'unit_rejected' || row.status === 'jb_rejected') && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`编辑需求申请 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>编辑</button>
                      )}
                      {row.status === 'budget_approved' && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`确认预算批复 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>确认批复</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {activeTab === 'contract' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" /></th>
                <th>合同编号</th><th>关联采购</th><th>供应商</th><th>金额</th><th>签订日期</th><th>状态</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {contractData.map(row => (
                <tr key={row.id}>
                  <td><input type="checkbox" /></td>
                  <td className="font-mono text-xs">{row.id}</td>
                  <td className="font-mono text-xs">{row.purchaseId}</td>
                  <td>{row.supplier}</td>
                  <td className="font-mono">¥{row.amount.toLocaleString()}</td>
                  <td>{row.date}</td>
                  <td><span className={`tag ${statusMap[row.status]?.tag}`}>{statusMap[row.status]?.label}</span></td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`合同详情 - ${row.id}`); setDrawerOpen(true) }}>查看</button>
                      {row.status === 'draft' && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`编辑合同 - ${row.id}`); setDrawerOpen(true) }}>编辑</button>
                      )}
                      {row.status === 'fulfilling' && (
                        <>
                          <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setOrderConfirmOpen(true)}>填写订单</button>
                          <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => { setSelectedRow(row); setTerminateConfirmOpen(true) }}>终止/作废</button>
                        </>
                      )}
                      {row.status === 'accepted' && (
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => setCompleteConfirmOpen(true)}>办结</button>
                      )}
                      {row.status === 'terminated' && (
                        <span className="text-xs" style={{ color: '#ff4d4f' }} title={(row as any).terminateReason}>已终止</span>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {activeTab === 'order' && (
          <table className="data-table">
            <thead>
              <tr>
                <th className="w-10"><input type="checkbox" /></th>
                <th>合同名称</th><th>合同单号</th><th>供应商</th><th>交货日期</th><th>状态</th><th>申请人</th><th>进度</th><th>操作</th>
              </tr>
            </thead>
            <tbody>
              {orderData.map(row => {
                const totalItems = row.items.length
                const checkedItems = row.items.filter((i: any) => i.checkStatus === 'pass').length
                const displayStatus = checkedItems === totalItems ? 'stored' : checkedItems > 0 ? 'partial_ship' : 'pending_ship'
                return (
                <tr key={row.id}>
                  <td><input type="checkbox" /></td>
                  <td className="text-sm font-medium">{row.contractName}</td>
                  <td className="font-mono text-xs">{row.contractId}</td>
                  <td>{row.supplier}</td>
                  <td>{row.deliveryDate}</td>
                  <td><span className={`tag ${statusMap[displayStatus]?.tag}`}>{statusMap[displayStatus]?.label}{displayStatus === 'partial_ship' && ` (${checkedItems}/${totalItems})`}</span></td>
                  <td>
                    {(() => {
                      const totalItems = row.items.length
                      const checkedItems = row.items.filter((i: any) => i.checkStatus === 'pass').length
                      const progress = totalItems > 0 ? Math.round((checkedItems / totalItems) * 100) : 0
                      return (
                        <div className="flex items-center gap-2">
                          <div className="w-20 h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                            <div className="h-full rounded-full" style={{ width: `${progress}%`, background: progress === 100 ? '#52c41a' : 'var(--primary-blue)' }} />
                          </div>
                          <span className="text-xs font-mono">{progress}%</span>
                        </div>
                      )
                    })()}
                  </td>
                  <td>
                    <div className="flex items-center gap-2 flex-wrap">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`订单详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>查看</button>
                      {(row.status === 'pending_ship' || row.status === 'partial_ship') && (
                        <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => { setDrawerTitle(`订单验收 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true) }}>验收</button>
                      )}
                      {row.status === 'pending_storage' && (
                        <button className="text-xs hover:underline" style={{ color: '#1890ff' }} onClick={() => { setDrawerTitle(`订单详情 - ${row.id}`); setSelectedRow(row); setDrawerOpen(true); alert('入库操作：将订单状态变更为已入库') }}>入库</button>
                      )}
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => { setDrawerTitle(`订单导出 - ${row.id}`); setDrawerOpen(true) }}>订单导出</button>
                    </div>
                  </td>
                </tr>
              )
            })}</tbody>
          </table>
        )}
        {/* Pagination */}
        <div className="flex items-center justify-between px-4 py-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {purchaseData.length} 条</span>
          <div className="flex items-center gap-1">
            {['<', '1', '2', '3', '...', '>'].map((p, i) => (
              <button key={i} className={`w-8 h-8 rounded text-xs flex items-center justify-center transition-all ${p === '1' ? 'text-white' : 'hover:bg-gray-100'}`} style={p === '1' ? { background: 'var(--primary-blue)' } : {}}>{p}</button>
            ))}
            <select className="form-input w-20 text-xs ml-2"><option>20条/页</option><option>50条/页</option><option>100条/页</option></select>
          </div>
        </div>
      </div>

      {/* Sync Log Drawer */}
      {syncLogOpen && (
        <>
          <div className="drawer-overlay" onClick={() => setSyncLogOpen(false)} />
          <div className="drawer-panel animate-slide-in overflow-y-auto">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">同步日志</h3>
              <button onClick={() => setSyncLogOpen(false)} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6">
              {/* Sync status cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {[
                  { name: '采购预算数据', lastSync: '2024-03-15 02:00', status: 'success', count: '156 条', icon: 'M21 4H3a2 2 0 00-2 2v12a2 2 0 002 2h18a2 2 0 002-2V6a2 2 0 00-2-2zm0 14H3V6h18v12zM7 8h10v2H7V8zm0 4h6v2H7v-2z' },
                  { name: '采购预算执行数据', lastSync: '2024-03-15 02:05', status: 'success', count: '89 条', icon: 'M12 20V10M18 20V4M6 20v-4' },
                  { name: '采购文件', lastSync: '2024-03-15 02:10', status: 'partial', count: '34 个文件', icon: 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z' },
                ].map(item => (
                  <div key={item.name} className="p-4 rounded-lg border flex items-center gap-4" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: item.status === 'success' ? '#e6f7ff' : '#fffbe6' }}>
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={item.status === 'success' ? '#1890ff' : '#faad14'} strokeWidth="2">
                        <path d={item.icon}/>
                      </svg>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{item.name}</p>
                      <p className="text-xs mt-0.5" style={{ color: 'var(--text-disabled)' }}>上次同步：{item.lastSync}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{item.count}</span>
                        <span className={`tag ${item.status === 'success' ? 'tag-green' : 'tag-yellow'} text-xs`}>{item.status === 'success' ? '同步成功' : '部分异常'}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {/* Sync Log Table */}
              <h5 className="text-sm font-medium mb-3">同步执行日志</h5>
              <div className="content-card overflow-hidden">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th className="text-xs">时间</th>
                      <th className="text-xs">模块</th>
                      <th className="text-xs">操作</th>
                      <th className="text-xs">结果</th>
                      <th className="text-xs">详情</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { time: '2024-03-15 02:10:05', module: '采购文件', action: '文件同步', result: 'warning', msg: '3个文件上传失败，已重试' },
                      { time: '2024-03-15 02:05:23', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送89条执行记录' },
                      { time: '2024-03-15 02:00:15', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取156条预算数据' },
                      { time: '2024-03-14 02:08:45', module: '采购文件', action: '文件同步', result: 'success', msg: '成功同步31个文件' },
                      { time: '2024-03-14 02:03:12', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送92条执行记录' },
                      { time: '2024-03-14 01:58:30', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取158条预算数据' },
                      { time: '2024-03-13 02:07:18', module: '采购文件', action: '文件同步', result: 'success', msg: '成功同步28个文件' },
                      { time: '2024-03-13 02:02:05', module: '预算执行', action: '数据推送', result: 'success', msg: '成功推送87条执行记录' },
                      { time: '2024-03-13 01:57:42', module: '采购预算', action: '数据拉取', result: 'success', msg: '成功拉取160条预算数据' },
                      { time: '2024-03-12 02:09:33', module: '采购文件', action: '文件同步', result: 'error', msg: '网络超时，同步失败' },
                    ].map((log, i) => (
                      <tr key={i}>
                        <td className="text-xs font-mono" style={{ color: 'var(--text-disabled)' }}>{log.time}</td>
                        <td><span className="tag tag-gray text-xs">{log.module}</span></td>
                        <td className="text-xs" style={{ color: 'var(--text-secondary)' }}>{log.action}</td>
                        <td><span className={`tag ${log.result === 'success' ? 'tag-green' : log.result === 'warning' ? 'tag-yellow' : 'tag-red'} text-xs`}>{log.result === 'success' ? '成功' : log.result === 'warning' ? '异常' : '失败'}</span></td>
                        <td className="text-xs" style={{ color: 'var(--text-primary)' }}>{log.msg}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </>
      )}

      {/* ====== Center Modal (shared) ====== */}
      {drawerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[1100px] max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b bg-white flex-shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">{drawerTitle}</h3>
              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100 transition-colors">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {activeTab === 'purchase' && (
                <>
                  {/* Section 1: 项目基本信息 */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>项目基本信息</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>项目名称 <span className="text-red-500">*</span></label>
                        <input className="form-input" placeholder="请输入项目名称" defaultValue={selectedRow?.projectName || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>项目类型 <span className="text-red-500">*</span></label>
                        {isDrawerReadOnly ? (
                          <input className="form-input" defaultValue={selectedRow?.projectType || ''} readOnly style={{ background: '#fafafa' }} />
                        ) : (
                          <select className="form-input" defaultValue={selectedRow?.projectType || ''}>
                            <option>货物采购</option>
                            <option>服务采购</option>
                            <option>系统集成</option>
                            <option>工程采购</option>
                            <option>其他</option>
                          </select>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购预算金额 <span className="text-red-500">*</span></label>
                        <input className="form-input font-mono" placeholder="¥" defaultValue={selectedRow ? `¥${selectedRow.budget.toLocaleString()}` : ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div className="relative">
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请单位 <span className="text-red-500">*</span></label>
                        {isDrawerReadOnly ? (
                          <input className="form-input" defaultValue={selectedRow?.applyUnit || ''} readOnly style={{ background: '#fafafa' }} />
                        ) : (
                          <>
                            <input
                              className="form-input w-full"
                              placeholder="请选择申请单位"
                              value={applyUnitVal}
                              onChange={e => { setApplyUnitVal(e.target.value); setApplyUnitOpen(true); setApplyUnitSearch(e.target.value) }}
                              onFocus={() => setApplyUnitOpen(true)}
                            />
                            {applyUnitOpen && (
                              <>
                                <div className="fixed inset-0 z-[55]" onClick={() => setApplyUnitOpen(false)} />
                                <div className="absolute z-[60] left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-[260px] overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
                                  {renderOrgTree(orgTreeData, 0)}
                                </div>
                              </>
                            )}
                          </>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人</label>
                        <input className="form-input" defaultValue={selectedRow?.operator || '当前用户'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请日期</label>
                        <input className="form-input" defaultValue={selectedRow?.applyDate || new Date().toISOString().slice(0, 10)} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采购单号</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.id || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: 项目介绍与论证 */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold flex items-center gap-2 mb-4"><span className="w-1 h-4 rounded-full bg-blue-500"/>项目介绍与论证</h4>
                    <div className="space-y-4">
                      {/* 项目介绍 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>项目介绍 <span className="text-red-400">*</span></label>
                        {isDrawerReadOnly ? (
                          <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>
                            {selectedRow?.projectIntro || '暂无'}
                          </div>
                        ) : (
                          <textarea className="form-input w-full text-sm" rows={3} placeholder="请简要介绍本项目背景、目标及主要内容..." defaultValue={selectedRow?.projectIntro || ''} />
                        )}
                      </div>
                      {/* 项目论证 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>项目论证</label>
                        {isDrawerReadOnly ? (
                          <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>
                            {selectedRow?.projectJustify || '暂无'}
                          </div>
                        ) : (
                          <textarea className="form-input w-full text-sm" rows={3} placeholder="请说明采购的必要性和可行性..." defaultValue={selectedRow?.projectJustify || ''} />
                        )}
                      </div>
                      {/* 附件上传 */}
                      <div>
                        <label className="block text-xs mb-1.5 font-medium" style={{ color: 'var(--text-secondary)' }}>附件上传</label>
                        {isDrawerReadOnly ? (
                          <div className="flex flex-wrap gap-2">
                            {selectedRow?.attachments && selectedRow.attachments.length > 0 ? (
                              selectedRow.attachments.map((att: any, i: number) => (
                                <span key={i} className="tag tag-blue text-xs flex items-center gap-1">
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                                  {att.name}
                                </span>
                              ))
                            ) : (
                              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>未上传附件</span>
                            )}
                          </div>
                        ) : (
                          <div className="flex items-center gap-3 flex-wrap">
                            <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: '#d9d9d9' }}>
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                              <span className="text-xs" style={{ color: '#8c8c8c' }}>上传附件</span>
                              <input type="file" multiple className="hidden" onChange={(e) => {
                                const files = e.target.files
                                if (files && files.length > 0) {
                                  const names = Array.from(files).map(f => f.name).join(', ')
                                  alert(`已选择 ${files.length} 个文件: ${names}`)
                                }
                              }} />
                            </label>
                            <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 PDF、Word、Excel 格式</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Approval Flow - always shown */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2">
                      <span className="w-1 h-4 rounded-full bg-green-500"/>
                      审批流程
                    </h4>
                    <div className="relative">
                      <div className="flex items-center justify-between">
                        {flowNodes.map((node, i) => {
                          const isNew = !selectedRow
                          const state = getNodeState(node.key, selectedRow?.status || null, isNew)
                          const circleColors: Record<string, { bg: string; border: string; text?: string }> = {
                            done: { bg: '#52c41a', border: '#52c41a' },
                            active: { bg: 'var(--primary-blue)', border: 'var(--primary-blue)' },
                            rejected: { bg: '#ff4d4f', border: '#ff4d4f' },
                            waiting: { bg: '#ffffff', border: '#d9d9d9' },
                            skip: { bg: '#f5f5f5', border: '#d9d9d9' },
                          }
                          const c = circleColors[state]
                          return (
                            <div key={i} className="flex-1 flex flex-col items-center relative">
                              {i > 0 && (
                                <div className="absolute right-1/2 top-5 -translate-y-1/2 h-0.5 w-full" style={{
                                  background: ['done', 'active'].includes(state) ? '#52c41a' : state === 'rejected' ? '#ff4d4f' : '#d9d9d9',
                                }} />
                              )}
                              <div className="relative z-10 w-10 h-10 rounded-full flex items-center justify-center border-2" style={{ background: c.bg, borderColor: c.border }}>
                                {state === 'done' && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>}
                                {state === 'active' && <span className="text-sm font-bold text-white">{i + 1}</span>}
                                {state === 'rejected' && <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>}
                                {state === 'waiting' && <span className="text-sm font-medium" style={{ color: '#8c8c8c' }}>{i + 1}</span>}
                                {state === 'skip' && <span className="text-sm" style={{ color: '#bfbfbf' }}>{i + 1}</span>}
                              </div>
                              <p className={`text-xs font-medium mt-2 ${state === 'done' ? 'text-green-600' : state === 'active' ? 'text-blue-600' : state === 'rejected' ? 'text-red-500' : state === 'skip' ? 'text-gray-400' : 'text-gray-600'}`}>{node.label}</p>
                              <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{node.desc}</p>
                              {state !== 'waiting' && state !== 'skip' && (
                                <p className="text-xs mt-0.5 font-mono" style={{ color: 'var(--text-disabled)' }}>
                                  {node.startTime}{(state === 'done' || state === 'rejected') && node.endTime ? ` ~ ${node.endTime}` : ''}
                                </p>
                              )}
                            </div>
                          )
                        })}
                      </div>
                      {selectedRow && (selectedRow.status === 'unit_rejected' || selectedRow.status === 'jb_rejected') && (
                        <div className="mt-4 p-3 rounded-lg border-l-4" style={{ borderLeftColor: '#ff4d4f', background: '#fff2f0' }}>
                          <p className="text-sm font-medium" style={{ color: '#ff4d4f' }}>驳回原因</p>
                          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{selectedRow.status === 'unit_rejected' ? '预算超支，请重新调整采购数量后再次提交。' : '不符合采购计划，请核实后重新提交。'}</p>
                          <p className="text-xs mt-1 font-mono" style={{ color: 'var(--text-disabled)' }}>驳回人：{selectedRow.status === 'unit_rejected' ? '单位负责人' : 'JB部负责人'}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Section: Budget Approval Upload - only for budget_approved */}
                  {selectedRow?.status === 'budget_approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        预算批复数据
                      </h4>
                      <div className="space-y-4">
                        {/* Status alert */}
                        <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                          <div className="flex items-center gap-2">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                            <span className="text-sm font-medium" style={{ color: '#52c41a' }}>等待预算批复</span>
                          </div>
                          <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>系统已提交至财政预算系统，请手动上传批复文件及批复金额</p>
                        </div>
                        {/* Manual input for approval amount */}
                        {!isDrawerReadOnly && (
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批复金额 <span className="text-red-400">*</span></label>
                              <input className="form-input font-mono" placeholder="¥" />
                            </div>
                            <div>
                              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批复文号 <span className="text-red-400">*</span></label>
                              <input className="form-input" placeholder="请输入批复文号" />
                            </div>
                          </div>
                        )}
                        {/* File upload */}
                        <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-2">
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              <span className="text-sm font-medium">批复文件</span>
                              <span className="text-red-400">*</span>
                            </div>
                            {!isDrawerReadOnly && (
                              <label className="btn-primary text-xs px-3 py-1.5 cursor-pointer flex items-center gap-1">
                                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                                上传文件
                                <input type="file" className="hidden" accept=".pdf,.doc,.docx" />
                              </label>
                            )}
                          </div>
                          <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                            <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{isDrawerReadOnly ? '暂无批复文件' : '请上传预算批复文件（PDF/Word）'}</p>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Section: Budget Execution Data - only for approved */}
                  {selectedRow?.status === 'approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        采购预算执行数据
                      </h4>
                      <div className="space-y-3">
                        {/* Budget summary cards */}
                        <div className="grid grid-cols-3 gap-3">
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#f6ffed' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>项目总预算</p>
                            <p className="text-sm font-mono font-medium mt-1">¥{selectedRow.totalBudget.toLocaleString()}</p>
                          </div>
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#e6f7ff' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已执行金额</p>
                            <p className="text-sm font-mono font-medium mt-1">¥{Math.round(selectedRow.totalBudget * selectedRow.executionRate / 100).toLocaleString()}</p>
                          </div>
                          <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fff7e6' }}>
                            <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已支付金额</p>
                            <p className="text-sm font-mono font-medium mt-1" style={{ color: '#fa8c16' }}>¥{selectedRow.paidAmount.toLocaleString()}</p>
                          </div>
                        </div>
                        {/* Execution rate progress */}
                        <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>预算执行率</span>
                            <span className="text-xs font-mono font-medium">{selectedRow.executionRate}%</span>
                          </div>
                          <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                            <div className="h-full rounded-full" style={{ width: `${selectedRow.executionRate}%`, background: selectedRow.executionRate > 80 ? '#ff4d4f' : 'var(--primary-blue)' }} />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Section: Purchase Files - only for approved */}
                  {selectedRow?.status === 'approved' && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2">
                        <span className="w-1 h-4 rounded-full bg-blue-500"/>
                        采购文件
                      </h4>
                      <div className="space-y-2">
                        {[
                          { name: '预算批复文件.pdf', type: '批复文件', date: '2024-03-05', size: '1.2 MB' },
                          { name: '需求申请表.docx', type: '申请文件', date: '2024-03-01', size: '856 KB' },
                          { name: '招标文件.pdf', type: '招标文件', date: '2024-03-08', size: '3.5 MB' },
                        ].map((file, i) => (
                          <div key={i} className="flex items-center justify-between p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded flex items-center justify-center flex-shrink-0" style={{ background: '#e6f7ff' }}>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              </div>
                              <div>
                                <p className="text-sm font-medium">{file.name}</p>
                                <div className="flex items-center gap-2 mt-0.5">
                                  <span className="tag tag-gray text-xs">{file.type}</span>
                                  <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{file.size}</span>
                                  <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{file.date}</span>
                                </div>
                              </div>
                            </div>
                            <button className="btn-default text-xs px-2 py-1">下载</button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </>
              )}
              {activeTab === 'contract' && (
                <div className="space-y-5">
                  {/* Section 1: Contract Basic Info */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>合同基本信息</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同单号 #</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.id || 'HT2024003'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称 <span className="text-red-400">*</span></label>
                        <input className="form-input" placeholder="请输入合同名称" defaultValue={selectedRow?.name || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同金额 <span className="text-red-400">*</span></label>
                        <input className="form-input font-mono" placeholder="¥" defaultValue={selectedRow ? `¥${selectedRow.amount.toLocaleString()}` : ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>乙方 <span className="text-red-400">*</span></label>
                        <input className="form-input" placeholder="请输入乙方名称" defaultValue={selectedRow?.supplier || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>签订日期 <span className="text-red-400">*</span></label>
                        <input className="form-input" type="date" defaultValue={selectedRow?.signDate || '2024-03-01'} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2: Order Details */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单明细</h4>
                    <div className="p-4 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                      {selectedRow?.orderDetails ? (
                        <div className="space-y-2 text-sm">
                          {selectedRow.orderDetails.map((item: any, i: number) => (
                            <div key={i} className="flex justify-between py-1 border-b" style={{ borderColor: 'var(--border-color)' }}>
                              <span>{item.name} ({item.spec}) x{item.qty}{item.unit}</span>
                              <span className="font-mono">¥{item.price.toLocaleString()}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-center" style={{ color: 'var(--text-disabled)' }}>暂无订单明细</p>
                      )}
                    </div>
                  </div>

                  {/* Section 3: Linked Purchase */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>关联采购</h4>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>关联采购项目</label>
                      <div className="relative">
                        <input
                          className="form-input w-full"
                          placeholder="搜索采购项目..."
                          value={linkedPurchase ? approvedPurchases.find(p => p.id === linkedPurchase)?.project || linkedPurchase : ''}
                          onFocus={() => setPurchaseDropdownOpen(true)}
                          onBlur={() => setTimeout(() => setPurchaseDropdownOpen(false), 150)}
                          onChange={e => { setLinkedPurchase(e.target.value); setPurchaseDropdownOpen(true) }}
                          style={{ paddingRight: 28, background: isDrawerReadOnly ? '#fafafa' : undefined }}
                          readOnly={isDrawerReadOnly}
                        />
                        {purchaseDropdownOpen && !isDrawerReadOnly && (
                          <div className="absolute left-0 right-0 top-full mt-1 rounded-lg border shadow-lg z-50 max-h-48 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                            {approvedPurchases.filter(p => p.project.toLowerCase().includes((linkedPurchase || '').toLowerCase()) || p.id.toLowerCase().includes((linkedPurchase || '').toLowerCase())).map(p => (
                              <div key={p.id} className="px-3 py-2 hover:bg-blue-50 cursor-pointer flex items-center justify-between" onClick={() => { setLinkedPurchase(p.id); setPurchaseDropdownOpen(false) }}>
                                <span className="text-sm">{p.project}</span>
                                <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>¥{p.amount.toLocaleString()}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Section 4: Remarks */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>备注</h4>
                    {isDrawerReadOnly ? (
                      <div className="p-3 rounded-lg text-sm leading-relaxed" style={{ background: '#fafafa', color: 'var(--text-primary)' }}>{selectedRow?.remarks || '暂无备注'}</div>
                    ) : (
                      <textarea className="form-input w-full text-sm" rows={3} placeholder="请输入备注信息..." defaultValue={selectedRow?.remarks || ''} />
                    )}
                  </div>

                  {/* Section 5: Attachments */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>附件</h4>
                      {!isDrawerReadOnly && (
                        <label className="btn-primary text-xs px-3 py-1.5 cursor-pointer flex items-center gap-1">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                          上传附件
                          <input type="file" className="hidden" multiple onChange={e => {
                            const files = e.target.files
                            if (files) {
                              const newFiles = Array.from(files).map(f => ({
                                id: Math.random().toString(36).substring(2, 10),
                                name: f.name,
                                size: f.size > 1024 * 1024 ? (f.size / (1024 * 1024)).toFixed(2) + ' MB' : (f.size / 1024).toFixed(1) + ' KB'
                              }))
                              setContractFiles(prev => [...prev, ...newFiles])
                            }
                          }} />
                        </label>
                      )}
                    </div>
                    {contractFiles.length === 0 ? (
                      <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                        <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>暂无附件</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {contractFiles.map(f => (
                          <div key={f.id} className="flex items-center justify-between p-2 rounded border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>
                            <div className="flex items-center gap-2">
                              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13 2 13 9 20 9"/></svg>
                              <span className="text-sm">{f.name}</span>
                              <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>({f.size})</span>
                            </div>
                            {!isDrawerReadOnly && (
                              <button className="text-red-400 hover:text-red-600 transition-colors" onClick={() => setContractFiles(prev => prev.filter(file => file.id !== f.id))}>
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
              {activeTab === 'order' && (
                <div className="space-y-5">
                  {/* Section 1: Order Basic Info */}
                  <div>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单基本信息</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称 #</label>
                        <input className="form-input" defaultValue={selectedRow?.contractName || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同单号 #</label>
                        <input className="form-input font-mono" defaultValue={selectedRow?.contractId || ''} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商 <span className="text-red-400">*</span></label>
                        {isDrawerReadOnly ? (
                          <input className="form-input" defaultValue={selectedRow?.supplier || ''} readOnly style={{ background: '#fafafa' }} />
                        ) : (
                          <div className="relative">
                            <input className="form-input w-full" placeholder="搜索供应商..." defaultValue={selectedRow?.supplier || ''} />
                          </div>
                        )}
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>交货日期 <span className="text-red-400">*</span></label>
                        <input className="form-input" type="date" defaultValue={selectedRow?.deliveryDate || ''} readOnly={isDrawerReadOnly} style={{ background: isDrawerReadOnly ? '#fafafa' : undefined }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态 #</label>
                        <input className="form-input" defaultValue={selectedRow ? statusMap[selectedRow.status]?.label : '草稿'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                      <div>
                        <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人 #</label>
                        <input className="form-input" defaultValue={selectedRow?.applicant || '当前用户'} readOnly style={{ background: '#fafafa' }} />
                      </div>
                    </div>
                  </div>

                  {/* Section 2+3: Order Detail - Wide Table Layout */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单明细</h4>
                      {!selectedRow && (
                        <button onClick={addLineItem} className="btn-primary text-xs px-2 py-1 flex items-center gap-1">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                          添加装备
                        </button>
                      )}
                    </div>
                    {/* Table Header */}
                    <div className="grid gap-1 px-2 py-1.5 text-xs font-medium rounded-t-lg" style={{ background: 'var(--card-header-bg)', gridTemplateColumns: '28px minmax(120px,1fr) minmax(100px,1fr) 48px 36px 56px 70px 70px minmax(60px,0.8fr) 80px' }}>
                      <span>#</span>
                      <span>物资名称 <span className="text-red-400">*</span></span>
                      <span>规格型号</span>
                      <span className="text-center">数量 <span className="text-red-400">*</span></span>
                      <span className="text-center">单位</span>
                      <span className="text-right">单价 <span className="text-red-400">*</span></span>
                      <span className="text-right">总价 #</span>
                      <span>装备编码 #</span>
                      <span>备注</span>
                      <span className="text-center">{selectedRow ? '验收' : '操作'}</span>
                    </div>
                    <div className="space-y-1 max-h-[480px] overflow-y-auto pr-1">
                      {(selectedRow?.items || lineItems).map((item: any, idx: number) => (
                        <div key={item.id} className="grid gap-1 px-2 py-1.5 items-center rounded text-xs" style={{ background: idx % 2 === 0 ? '#fff' : 'var(--content-bg)', gridTemplateColumns: '28px minmax(120px,1fr) minmax(100px,1fr) 48px 36px 56px 70px 70px minmax(60px,0.8fr) 80px' }}>
                          {/* # */}
                          <span className="font-medium" style={{ color: 'var(--text-disabled)' }}>{idx + 1}</span>
                          {/* 装备名称 */}
                          <input className="form-input text-xs py-1 w-full" defaultValue={item.name} placeholder="装备名称" readOnly={!!selectedRow} />
                          {/* 规格型号 */}
                          <input className="form-input text-xs py-1 w-full" defaultValue={item.spec} placeholder="规格型号" readOnly={!!selectedRow} />
                          {/* 数量 */}
                          <input className="form-input text-xs py-1 font-mono text-center w-full" type="number" min={0} defaultValue={item.qty || ''} readOnly={!!selectedRow} />
                          {/* 单位 */}
                          {selectedRow ? (
                            <input className="form-input text-xs py-1 text-center w-full" defaultValue={item.unit || '台'} readOnly />
                          ) : (
                            <select className="form-input text-xs py-1 w-full text-center" defaultValue={item.unit || '台'}>
                              <option>台</option><option>套</option><option>件</option><option>个</option>
                            </select>
                          )}
                          {/* 单价 */}
                          <input className="form-input text-xs py-1 font-mono text-right w-full" type="number" min={0} defaultValue={item.price || ''} readOnly={!!selectedRow} />
                          {/* 总价 # */}
                          <span className="font-mono font-semibold text-right" style={{ color: 'var(--primary-blue)' }}>¥{(item.amount || 0).toLocaleString()}</span>
                          {/* 装备编码 # */}
                          <div className="truncate">
                            {item.code ? (
                              <span className="font-mono px-1 py-0.5 rounded" style={{ background: '#e6f7ff', color: 'var(--primary-blue)' }}>{item.code}</span>
                            ) : (
                              <span style={{ color: 'var(--text-disabled)' }}>待申请</span>
                            )}
                          </div>
                          {/* 备注 */}
                          <input className="form-input text-xs py-1 w-full" defaultValue={item.note || ''} placeholder="备注" readOnly={!!selectedRow} />
                          {/* 操作 */}
                          {selectedRow ? (
                            item.checkStatus === 'pass' ? (
                              <div className="flex items-center justify-center">
                                <button
                                  className="px-2 py-0.5 rounded text-xs border transition-colors hover:bg-blue-50"
                                  style={{ color: '#1890ff', borderColor: '#91caff' }}
                                  onClick={() => { setAcceptForm({ itemName: item.name, result: 'pass', opinion: item.checkDetail?.opinion || '', checker: item.checkDetail?.checker || '当前用户', checkTime: item.checkDetail?.checkTime || new Date().toISOString().slice(0, 16), handleWay: item.checkDetail?.handleWay || '' }); setAcceptViewMode(true); setAcceptModalOpen(true) }}
                                >详情</button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-1 justify-center">
                                <button
                                  className="px-1.5 py-0.5 rounded text-xs border transition-colors hover:bg-green-50"
                                  style={{ color: '#52c41a', borderColor: '#b7eb8f' }}
                                  onClick={() => { setAcceptForm({ itemName: item.name, result: 'pass', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '' }); setAcceptViewMode(false); setAcceptModalOpen(true) }}
                                >合格</button>
                                <button
                                  className="px-1.5 py-0.5 rounded text-xs border transition-colors hover:bg-red-50"
                                  style={{ color: '#ff4d4f', borderColor: '#ffa39e' }}
                                  onClick={() => { setAcceptForm({ itemName: item.name, result: 'fail', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '' }); setAcceptViewMode(false); setAcceptModalOpen(true) }}
                                >不合格</button>
                              </div>
                            )
                          ) : lineItems.length > 1 && (
                            <button onClick={() => removeLineItem(item.id)} className="text-red-400 hover:text-red-600 transition-colors text-center">
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    {/* Summary */}
                    <div className="flex items-center justify-end gap-4 mt-3 pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                      <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {(selectedRow?.items || lineItems).length} 件装备</span>
                      <span className="text-sm font-semibold">合计：<span className="font-mono" style={{ color: 'var(--primary-blue)' }}>¥{(selectedRow?.items || lineItems).reduce((s: number, it: any) => s + (it.amount || 0), 0).toLocaleString()}</span></span>
                    </div>
                  </div>

                  {/* Section 4: Equipment Coding Request */}
                  <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                    <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>装备编码</h4>
                    <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                          <span className="text-sm font-medium" style={{ color: '#52c41a' }}>编码已自动生成</span>
                        </div>
                        <button className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1">
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                          导出编码
                        </button>
                      </div>
                      <p className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>订单创建时装备编码已自动生成，可直接导出使用。</p>
                      <div className="space-y-1">
                        {selectedRow?.items?.filter((i: any) => i.code).map((item: any, idx: number) => (
                          <div key={idx} className="flex items-center gap-2 text-xs py-0.5">
                            <span style={{ color: 'var(--text-secondary)' }}>{item.name}:</span>
                            <span className="font-mono font-medium">{item.code}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Section 5: Shipping Status */}
                  {selectedRow && (
                    <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                      <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>发货状态</h4>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}>
                        <div className="flex items-center gap-3 mb-2">
                          <span className={`tag ${statusMap[selectedRow.status]?.tag}`}>{statusMap[selectedRow.status]?.label}</span>
                          {(selectedRow.status as any) === 'stored' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>全部装备已入库</span>}
                          {(selectedRow.status as any) === 'pending_storage' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>全部装备已完成验收，待入库</span>}
                          {(selectedRow.status as any) === 'partial_ship' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>部分装备已验收，剩余待验收</span>}
                          {(selectedRow.status as any) === 'pending_ship' && <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>装备待验收</span>}
                        </div>
                        <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'var(--border-color)' }}>
                          <div className="h-full rounded-full" style={{
                            width: `${(selectedRow.status as any) === 'stored' || (selectedRow.status as any) === 'pending_storage' ? 100 : (selectedRow.status as any) === 'partial_ship' ? 50 : 0}%`,
                            background: (selectedRow.status as any) === 'stored' ? '#52c41a' : (selectedRow.status as any) === 'pending_storage' ? '#faad14' : 'var(--primary-blue)'
                          }} />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white flex-shrink-0" style={{ borderColor: 'var(--border-color)' }}>
              {isDrawerReadOnly ? (
                <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>关闭</button>
              ) : activeTab === 'contract' ? (
                <>
                  <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setContractName(''); setLinkedPurchase(''); setSupplierSearch(''); setContractFiles([]) }}>取消</button>
                  <button className="btn-default">保存</button>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary" onClick={() => setOrderConfirmOpen(true)}>填写订单</button>
                </>
              ) : activeTab === 'order' ? (
                <>
                  <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null) }}>取消</button>
                  <button className="btn-default">保存</button>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary">订单导出</button>
                  <label className="btn-primary flex items-center gap-1 cursor-pointer">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                    导入Excel
                    <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={() => alert('导入Excel功能开发中...')} />
                  </label>
                </>
              ) : (
                <>
                  <button className="btn-default" onClick={() => { setDrawerOpen(false); setSelectedRow(null); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]) }}>取消</button>
                  <button className="btn-default">保存草稿</button>
                  <button className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed" disabled={totalAmount <= 0}>提交</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* New Order Modal (Popup) */}
      {orderModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOrderModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[1100px] max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增采购订单</h3>
              <button onClick={() => setOrderModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Modal Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* Section 1: Basic Info */}
              <div>
                <h4 className="font-semibold mb-3 flex items-center gap-2 text-sm"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单基本信息</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同名称 <span className="text-red-400">*</span></label>
                    <select className="form-input text-xs">
                      <option value="">请选择合同</option>
                      {contractData.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>合同单号 #</label>
                    <input className="form-input font-mono text-xs" placeholder="选择合同后自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div className="relative">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商 <span className="text-red-400">*</span></label>
                    <input
                      className="form-input text-xs w-full"
                      placeholder="请输入供应商名称"
                      value={orderSupplier}
                      onChange={e => { setOrderSupplier(e.target.value); setOrderSupplierOpen(true) }}
                      onFocus={() => setOrderSupplierOpen(true)}
                    />
                    {orderSupplierOpen && (
                      <>
                        <div className="fixed inset-0 z-[55]" onClick={() => setOrderSupplierOpen(false)} />
                        <div className="absolute z-[60] left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg max-h-[200px] overflow-y-auto" style={{ borderColor: 'var(--border-color)' }}>
                          {(() => {
                            const filtered = supplierList.filter(s => s.toLowerCase().includes(orderSupplier.toLowerCase()))
                            if (filtered.length === 0) {
                              return (
                                <button
                                  className="w-full px-3 py-2 text-left text-xs flex items-center gap-2 hover:bg-blue-50 transition-colors"
                                  style={{ color: '#1890ff' }}
                                  onClick={() => { setOrderSupplierOpen(false); setAddSupplierOpen(true); setNewSupplierName(orderSupplier) }}
                                >
                                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                                  新增供应商信息
                                </button>
                              )
                            }
                            return filtered.map(s => (
                              <button
                                key={s}
                                className="w-full px-3 py-2 text-left text-xs hover:bg-blue-50 transition-colors"
                                onClick={() => { setOrderSupplier(s); setOrderSupplierOpen(false) }}
                              >
                                {s}
                              </button>
                            ))
                          })()}
                        </div>
                      </>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>交货日期 <span className="text-red-400">*</span></label>
                    <input className="form-input text-xs" type="date" />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>申请人 #</label>
                    <input className="form-input text-xs" defaultValue="当前用户" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态 #</label>
                    <input className="form-input text-xs" defaultValue="草稿" readOnly style={{ background: '#fafafa' }} />
                  </div>
                </div>
              </div>

              {/* Section 2: Order Items + Check */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold flex items-center gap-2 text-sm"><span className="w-1 h-4 rounded-full bg-blue-500"/>订单明细</h4>
                  <button onClick={() => { setEquipSelectOpen(true); setEquipC1('全部'); setEquipC2('全部'); setEquipC3('全部'); setEquipNameSearch(''); setSelectedEquips([]) }} className="btn-primary text-xs px-2 py-1 flex items-center gap-1">
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                    添加装备
                  </button>
                </div>

                {/* Table Header */}
                <div className="grid gap-1 px-2 py-1.5 text-xs font-medium rounded-t-lg" style={{ background: 'var(--card-header-bg)', gridTemplateColumns: '28px minmax(100px,1fr) minmax(80px,1fr) 48px 36px 56px 64px minmax(60px,1fr) 60px' }}>
                  <span>#</span>
                  <span>物资名称 <span className="text-red-400">*</span></span>
                  <span>规格型号</span>
                  <span className="text-center">数量 <span className="text-red-400">*</span></span>
                  <span className="text-center">单位</span>
                  <span className="text-right">单价 <span className="text-red-400">*</span></span>
                  <span className="text-right">总价 #</span>
                  <span>备注</span>
                  <span className="text-center">操作</span>
                </div>

                {/* Table Body */}
                <div className="space-y-1 max-h-[360px] overflow-y-auto pr-1">
                  {lineItems.map((item, idx) => (
                    <div key={item.id} className="grid gap-1 px-2 py-1 items-center rounded text-xs" style={{ background: idx % 2 === 0 ? '#fff' : 'var(--content-bg)', gridTemplateColumns: '28px minmax(100px,1fr) minmax(80px,1fr) 48px 36px 56px 64px minmax(60px,1fr) 60px' }}>
                      <span className="font-medium" style={{ color: 'var(--text-disabled)' }}>{idx + 1}</span>
                      <input className="form-input text-xs py-1 w-full" value={item.name} onChange={e => updateLineItem(item.id, 'name', e.target.value)} placeholder="物资名称" />
                      <input className="form-input text-xs py-1 w-full" value={item.spec} onChange={e => updateLineItem(item.id, 'spec', e.target.value)} placeholder="规格型号" />
                      <input className="form-input text-xs py-1 font-mono text-center w-full" type="number" min={0} value={item.qty || ''} onChange={e => updateLineItem(item.id, 'qty', Number(e.target.value))} />
                      <select className="form-input text-xs py-1 w-full text-center" value={item.unit} onChange={e => updateLineItem(item.id, 'unit', e.target.value)}>
                        <option>台</option><option>套</option><option>件</option><option>个</option>
                      </select>
                      <input className="form-input text-xs py-1 font-mono text-right w-full" type="number" min={0} value={item.price || ''} onChange={e => updateLineItem(item.id, 'price', Number(e.target.value))} />
                      <span className="font-mono font-semibold text-right" style={{ color: 'var(--primary-blue)' }}>¥{item.amount.toLocaleString()}</span>
                      <input className="form-input text-xs py-1 w-full" value={item.remark || ''} onChange={e => updateLineItem(item.id, 'remark', e.target.value)} placeholder="备注" />
                      <div className="text-center">
                        {lineItems.length > 1 && (
                          <button onClick={() => removeLineItem(item.id)} className="text-red-400 hover:text-red-600 transition-colors">
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Summary */}
                <div className="flex items-center justify-end gap-4 mt-3 pt-3 border-t" style={{ borderColor: 'var(--border-color)' }}>
                  <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>共 {lineItems.length} 件装备</span>
                  <span className="text-sm font-semibold">合计：<span className="font-mono" style={{ color: 'var(--primary-blue)' }}>¥{totalAmount.toLocaleString()}</span></span>
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => { setOrderModalOpen(false); setLineItems([{ id: 1, name: '', spec: '', model: '', qty: 0, unit: '台', price: 0, amount: 0, code: '', remark: '' }]); setOrderSupplier(''); setOrderSupplierOpen(false) }}>取消</button>
              <button className="btn-default text-xs">保存草稿</button>
              <button className="btn-primary text-xs disabled:opacity-50 disabled:cursor-not-allowed" disabled={totalAmount <= 0}>提交</button>
            </div>
          </div>
        </div>
      )}

      {/* Equip Select Modal */}
      {equipSelectOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEquipSelectOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[1100px] max-w-[95vw] h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">选择装备</h3>
              <button onClick={() => setEquipSelectOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>

            {/* Body - 左右分栏 */}
            <div className="flex flex-1 overflow-hidden">
              {/* 左侧：装备信息 */}
              <div className="flex-1 flex flex-col border-r" style={{ borderColor: 'var(--border-color)' }}>
                {/* 搜索区域 */}
                <div className="px-4 py-3 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <h4 className="text-sm font-semibold mb-3">装备信息</h4>
                  <div className="flex flex-wrap items-end gap-3">
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>一级分类</label>
                      <select className="form-input w-32 text-xs" value={equipC1} onChange={e => { setEquipC1(e.target.value); setEquipC2('全部'); setEquipC3('全部') }}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.map(e => e.category1))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>二级分类</label>
                      <select className="form-input w-36 text-xs" value={equipC2} onChange={e => { setEquipC2(e.target.value); setEquipC3('全部') }}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.filter(e => equipC1 === '全部' || e.category1 === equipC1).map(e => e.category2))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>三级分类</label>
                      <select className="form-input w-32 text-xs" value={equipC3} onChange={e => setEquipC3(e.target.value)}>
                        <option>全部</option>
                        {Array.from(new Set(equipBaseData.filter(e => (equipC1 === '全部' || e.category1 === equipC1) && (equipC2 === '全部' || e.category2 === equipC2)).map(e => e.category3))).map(c => <option key={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称/编码</label>
                      <input className="form-input w-40 text-xs" placeholder="装备名称/装备编码" value={equipNameSearch} onChange={e => setEquipNameSearch(e.target.value)} />
                    </div>
                  </div>
                </div>

                {/* 装备表格 */}
                <div className="flex-1 overflow-y-auto p-4">
                  {(() => {
                    const filtered = equipBaseData.filter(e => {
                      if (equipC1 !== '全部' && e.category1 !== equipC1) return false
                      if (equipC2 !== '全部' && e.category2 !== equipC2) return false
                      if (equipC3 !== '全部' && e.category3 !== equipC3) return false
                      if (equipNameSearch && !e.name.toLowerCase().includes(equipNameSearch.toLowerCase()) && !e.code.toLowerCase().includes(equipNameSearch.toLowerCase())) return false
                      if (selectedEquips.some(s => s.equip.id === e.id)) return false
                      return true
                    })
                    return (
                      <table className="w-full text-xs border" style={{ borderColor: 'var(--border-color)' }}>
                        <thead>
                          <tr style={{ background: 'var(--table-header-bg)' }}>
                            <th className="border p-2 w-10" style={{ borderColor: 'var(--border-color)' }}>
                              <input type="checkbox" disabled />
                            </th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备名称</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>一级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>二级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>三级分类</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>规格型号</th>
                            <th className="border p-2" style={{ borderColor: 'var(--border-color)' }}>装备编码</th>
                          </tr>
                        </thead>
                        <tbody>
                          {filtered.map(e => (
                            <tr key={e.id} className="cursor-pointer hover:bg-blue-50 transition-colors" onClick={() => setSelectedEquips(prev => [...prev, { equip: e, qty: 1 }])}>
                              <td className="border p-2 text-center" style={{ borderColor: 'var(--border-color)' }}><input type="checkbox" readOnly /></td>
                              <td className="border p-2 font-medium" style={{ borderColor: 'var(--border-color)' }}>{e.name}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category1}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category2}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.category3}</td>
                              <td className="border p-2" style={{ borderColor: 'var(--border-color)' }}>{e.spec}</td>
                              <td className="border p-2 font-mono text-[10px]" style={{ borderColor: 'var(--border-color)' }}>{e.code}</td>
                            </tr>
                          ))}
                          {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
                        </tbody>
                      </table>
                    )
                  })()}
                </div>
              </div>

              {/* 右侧：已选择装备 */}
              <div className="w-[280px] flex flex-col">
                <div className="p-3 border-b font-medium text-sm" style={{ borderColor: 'var(--border-color)', background: 'var(--table-header-bg)' }}>
                  已选择装备 ({selectedEquips.length})
                </div>
                <div className="flex-1 overflow-y-auto p-3 space-y-2">
                  {selectedEquips.length === 0 ? (
                    <div className="text-center py-8" style={{ color: 'var(--text-disabled)' }}>
                      <p className="text-xs">请点击左侧装备选择</p>
                    </div>
                  ) : (
                    selectedEquips.map((s, i) => (
                      <div key={s.equip.id} className="border rounded-lg p-3" style={{ borderColor: 'var(--border-color)' }}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-medium">{s.equip.name}</span>
                          <button className="text-red-400 hover:text-red-600" onClick={() => setSelectedEquips(prev => prev.filter((_, idx) => idx !== i))}>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                          </button>
                        </div>
                        <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>数量：{s.equip.stockQty}</div>
                        <div className="text-xs mb-2" style={{ color: 'var(--text-secondary)' }}>单价：¥{s.equip.unitPrice.toLocaleString()}</div>
                        <div className="flex items-center gap-2">
                          <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: Math.max(1, p.qty - 1) } : p))}>-</button>
                          <span className="text-xs font-mono w-8 text-center">{s.qty}</span>
                          <button className="w-6 h-6 rounded border flex items-center justify-center text-xs hover:bg-gray-100" onClick={() => setSelectedEquips(prev => prev.map((p, idx) => idx === i ? { ...p, qty: p.qty + 1 } : p))}>+</button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => setEquipSelectOpen(false)}>关闭</button>
              <button
                className="btn-primary text-xs"
                disabled={selectedEquips.length === 0}
                onClick={() => {
                  const newItems = selectedEquips.map((s, i) => ({
                    id: lineItems.length + i + 1,
                    name: s.equip.name,
                    spec: s.equip.spec,
                    model: s.equip.spec,
                    qty: s.qty,
                    unit: s.equip.unit,
                    price: s.equip.unitPrice,
                    amount: s.equip.unitPrice * s.qty,
                    code: s.equip.code,
                    remark: '',
                  }))
                  setLineItems(prev => [...prev, ...newItems])
                  setEquipSelectOpen(false)
                  setSelectedEquips([])
                }}
              >
                确定
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {addSupplierOpen && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAddSupplierOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[680px] max-h-[92vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">新增企业</h3>
              <button onClick={() => setAddSupplierOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-6 space-y-5">
              {/* 企业信息 */}
              <div>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>企业信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商全称 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs" placeholder="请输入供应商全称" value={newSupplierName} onChange={e => setNewSupplierName(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业信用代码 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs font-mono" placeholder="请输入企业信用代码" value={newSupplierCode} onChange={e => setNewSupplierCode(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商简称</label>
                    <input className="form-input w-full text-xs" placeholder="请输入供应商简称" value={newSupplierShort} onChange={e => setNewSupplierShort(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>技术负责人</label>
                    <input className="form-input w-full text-xs" placeholder="请输入技术负责人" value={newSupplierTech} onChange={e => setNewSupplierTech(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系电话 <span className="text-red-400">*</span></label>
                    <input className="form-input w-full text-xs" placeholder="请输入联系电话" value={newSupplierPhone} onChange={e => setNewSupplierPhone(e.target.value)} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>警用准入 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full text-xs" value={newSupplierPolice} onChange={e => setNewSupplierPolice(e.target.value)}>
                      <option>否</option>
                      <option>是</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否涉密 <span className="text-red-400">*</span></label>
                    <select className="form-input w-full text-xs" value={newSupplierSecret} onChange={e => setNewSupplierSecret(e.target.value)}>
                      <option>否</option>
                      <option>是</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>资质状态</label>
                    <select className="form-input w-full text-xs" value={newSupplierStatus} onChange={e => setNewSupplierStatus(e.target.value)}>
                      <option>正常</option>
                      <option>异常</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* 供应商类型 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#722ed1' }}/>供应商类型 <span className="text-red-400">*</span></h4>
                <div className="flex gap-6">
                  {['生产商', '协议供货商', '供应商'].map(type => (
                    <label key={type} className="flex items-center gap-2 text-sm cursor-pointer">
                      <input type="checkbox" className="rounded" checked={newSupplierTypes.includes(type)} onChange={e => {
                        if (e.target.checked) setNewSupplierTypes(prev => [...prev, type])
                        else setNewSupplierTypes(prev => prev.filter(t => t !== type))
                      }} />
                      <span className="text-xs">{type}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 备注 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                <textarea className="form-input w-full text-xs" rows={3} placeholder="请输入备注" value={newSupplierRemark} onChange={e => setNewSupplierRemark(e.target.value)} />
              </div>

              {/* 系统信息 */}
              <div className="border-t pt-4" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2"><span className="w-1 h-4 rounded-full" style={{ background: '#8c8c8c' }}/>系统信息</h4>
                <div className="grid grid-cols-3 gap-4 text-xs" style={{ color: 'var(--text-secondary)' }}>
                  <div>创建人员：<span className="font-medium">-</span></div>
                  <div>创建时间：<span className="font-medium">-</span></div>
                  <div>更新时间：<span className="font-medium">-</span></div>
                </div>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default text-xs" onClick={() => setAddSupplierOpen(false)}>取消</button>
              <button className="btn-default text-xs">保存草稿</button>
              <button
                className="btn-primary text-xs"
                onClick={() => {
                  if (!newSupplierName.trim()) { alert('请输入供应商全称'); return }
                  setSupplierListState(prev => [...prev, newSupplierName.trim()])
                  setOrderSupplier(newSupplierName.trim())
                  setNewSupplierName(''); setNewSupplierCode(''); setNewSupplierShort(''); setNewSupplierTech(''); setNewSupplierPhone('')
                  setNewSupplierPolice('否'); setNewSupplierSecret('否'); setNewSupplierStatus('正常'); setNewSupplierTypes([]); setNewSupplierRemark('')
                  setAddSupplierOpen(false)
                }}
              >
                保存
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Acceptance Check Modal */}
      {acceptModalOpen && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setAcceptModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-lg font-semibold">合格确认 — {acceptForm.itemName}</h3>
              <button onClick={() => setAcceptModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              {/* 验收结果 */}
              <div>
                <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收结果</label>
                <div className="flex items-center gap-4">
                  <span className={`px-3 py-1.5 rounded text-sm font-medium ${acceptForm.result === 'pass' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'}`}>
                    {acceptForm.result === 'pass' ? '合格' : '不合格'}
                  </span>
                </div>
              </div>

              {/* 验收人 + 验收时间 */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收人</label>
                  <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.checker} readOnly />
                </div>
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收时间</label>
                  {acceptViewMode ? (
                    <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.checkTime} readOnly />
                  ) : (
                    <input
                      className="form-input w-full text-sm"
                      type="datetime-local"
                      value={acceptForm.checkTime}
                      onChange={e => setAcceptForm({ ...acceptForm, checkTime: e.target.value })}
                    />
                  )}
                </div>
              </div>

              {/* 处理方式 - 不合格时显示 */}
              {acceptForm.result === 'fail' && (
                <div>
                  <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>处理方式</label>
                  {acceptViewMode ? (
                    <input className="form-input w-full text-sm bg-gray-50 text-gray-500" value={acceptForm.handleWay === 'return' ? '退货' : acceptForm.handleWay === 'exchange' ? '换货' : '-'} readOnly />
                  ) : (
                    <select
                      className="form-input w-full text-sm"
                      value={acceptForm.handleWay}
                      onChange={e => setAcceptForm({ ...acceptForm, handleWay: e.target.value })}
                    >
                      <option value="">请选择</option>
                      <option value="return">退货</option>
                      <option value="exchange">换货</option>
                    </select>
                  )}
                </div>
              )}

              {/* 验收意见 */}
              <div>
                <label className="block text-xs mb-1 font-medium" style={{ color: 'var(--text-secondary)' }}>验收意见</label>
                {acceptViewMode ? (
                  <div className="form-input w-full text-sm bg-gray-50 text-gray-700 min-h-[60px] py-2">
                    {acceptForm.opinion || <span style={{ color: 'var(--text-disabled)' }}>无验收意见</span>}
                  </div>
                ) : (
                  <textarea
                    className="form-input w-full text-sm"
                    rows={3}
                    value={acceptForm.opinion}
                    onChange={e => setAcceptForm({ ...acceptForm, opinion: e.target.value })}
                    placeholder={acceptForm.result === 'pass' ? '请填写合格验收意见...' : '请填写不合格原因及处理建议...'}
                  />
                )}
              </div>

              {/* 附件上传 - 查看模式下隐藏 */}
              {!acceptViewMode && (
                <div>
                  <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>附件上传</label>
                  <div className="flex items-center gap-3 flex-wrap">
                    <label className="flex items-center gap-2 px-4 py-2 rounded-lg border border-dashed cursor-pointer hover:bg-gray-50 transition-colors" style={{ borderColor: '#d9d9d9' }}>
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                      <span className="text-xs" style={{ color: '#8c8c8c' }}>上传照片</span>
                      <input type="file" accept="image/*" multiple className="hidden" onChange={(e) => {
                        const files = e.target.files
                        if (files && files.length > 0) {
                          const names = Array.from(files).map(f => f.name).join(', ')
                          alert(`已选择 ${files.length} 个文件: ${names}`)
                        }
                      }} />
                    </label>
                    <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 JPG、PNG 格式</span>
                  </div>
                </div>
              )}
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              {acceptViewMode ? (
                <button className="btn-default text-xs" onClick={() => { setAcceptModalOpen(false); setAcceptViewMode(false) }}>关闭</button>
              ) : (
                <>
                  <button className="btn-default text-xs" onClick={() => setAcceptModalOpen(false)}>取消</button>
                  <button
                    className="btn-primary text-xs"
                    style={{ background: '#52c41a' }}
                    onClick={() => {
                      if (!acceptForm.opinion) { alert('请填写验收意见'); return }
                      if (acceptForm.result === 'fail' && !acceptForm.handleWay) { alert('请选择处理方式'); return }
                      alert(`${acceptForm.itemName} 已标记为「合格」，验收意见已保存并入库。`)
                      setAcceptModalOpen(false)
                      setAcceptForm({ itemName: '', result: 'pass', opinion: '', checker: '当前用户', checkTime: new Date().toISOString().slice(0, 16), handleWay: '' })
                    }}
                  >保存并入库</button>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Order Confirmation Modal */}
      {orderConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setOrderConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认填写订单</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否保存合同信息，并填写订单信息？</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setOrderConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setOrderConfirmOpen(false)
                  setDrawerOpen(false)
                  setActiveTab('order')
                  setDrawerTitle('新增订单')
                  setDrawerOpen(true)
                }}
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Complete Confirmation Modal */}
      {completeConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setCompleteConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
              </div>
              <h3 className="text-base font-semibold">确认办结</h3>
            </div>
            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认将该合同标记为"已办结"？办结后合同将关闭，无法再进行填写订单等操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setCompleteConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setCompleteConfirmOpen(false)
                }}
              >
                确认
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Terminate Confirmation Modal */}
      {terminateConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setTerminateConfirmOpen(false); setTerminateReason('') }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
              </div>
              <h3 className="text-base font-semibold">终止/作废合同</h3>
            </div>
            <div className="mb-6 space-y-3">
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>终止/作废后，合同将关闭且无法恢复。请填写终止/作废原因以备查询。</p>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>终止/作废原因 <span className="text-red-400">*</span></label>
                <textarea
                  className="form-input w-full text-sm"
                  rows={4}
                  placeholder="请输入终止/作废原因..."
                  value={terminateReason}
                  onChange={e => setTerminateReason(e.target.value)}
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => { setTerminateConfirmOpen(false); setTerminateReason('') }}>取消</button>
              <button
                className="btn-primary"
                style={{ background: '#ff4d4f' }}
                disabled={!terminateReason.trim()}
                onClick={() => {
                  setTerminateConfirmOpen(false)
                  setTerminateReason('')
                }}
              >
                确认终止/作废
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Storage Info Confirm Modal */}
      {storageConfirmOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setStorageConfirmOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
              </div>
              <h3 className="text-base font-semibold">入库信息确认</h3>
            </div>
            <div className="grid grid-cols-2 gap-4 mb-5">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库位名称 <span className="text-red-400">*</span></label>
                <input className="form-input" placeholder="请输入库位名称" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属仓库 <span className="text-red-400">*</span></label>
                <select className="form-input">
                  <option>请选择仓库</option>
                  <option>一号应急物资仓库</option>
                  <option>二号装备储备仓库</option>
                  <option>三号通信设备仓库</option>
                  <option>南区消防装备库</option>
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属区域 <span className="text-red-400">*</span></label>
                <select className="form-input">
                  <option>请选择区域</option>
                  <option>A区-通信装备区</option>
                  <option>B区-救援装备区</option>
                  <option>C区-消防装备区</option>
                  <option>D区-通用物资区</option>
                </select>
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库位类型 <span className="text-red-400">*</span></label>
                <select className="form-input">
                  <option>请选择类型</option>
                  <option>货架</option>
                  <option>托盘</option>
                  <option>房间</option>
                  <option>库区</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>库位层级（第几层） <span className="text-red-400">*</span></label>
                <select className="form-input">
                  <option>请选择层级</option>
                  <option>第1层（地面层）</option>
                  <option>第2层</option>
                  <option>第3层</option>
                  <option>第4层</option>
                  <option>第5层</option>
                </select>
              </div>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setStorageConfirmOpen(false)}>取消</button>
              <button
                className="btn-primary"
                onClick={() => {
                  setStorageConfirmOpen(false)
                  setDrawerOpen(false)
                }}
              >
                确认入库
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}