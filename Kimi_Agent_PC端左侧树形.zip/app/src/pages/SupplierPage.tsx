import { useState, useEffect } from 'react'



interface Props {
  activeSubTab?: string
  onNavigate?: (module: string, subTab?: string) => void
}



const tabList = [
  { key: 'enterprise', label: '企业信息' },
  { key: 'product', label: '商品管理' },
  { key: 'penalty', label: '处罚管理' },
  { key: 'complaint', label: '投诉管理' },
]



type EnterpriseType = 'producer' | 'supplier'

type ProductStatus = 'review' | 'on' | 'off'

/* ─── Complaint Types ─── */

interface Complaint {
  id: string
  complainant: string
  org: string
  targetType: string
  targetName: string
  content: string
  time: string
  status: 'pending' | 'processing' | 'resolved'
  reply?: string
}

const currentUser = { name: '赵明', org: '朝阳分局' }

const complaintTargets = [
  '华为技术有限公司', '海康威视数字技术股份有限公司', '烽火通信科技股份有限公司',
  '中兴通讯股份有限公司', '大华股份有限公司', '宇视科技',
  '张伟', '李强', '王芳',
]

const complaintMock: Complaint[] = [
  { id: 'C20250501001', complainant: '郑华', org: '大兴分局', targetType: '供应商', targetName: '华为技术有限公司', content: '供货周期过长，约定30天到货，实际用了45天。', time: '2025-05-01 11:00', status: 'pending' },
  { id: 'C20250428002', complainant: '陈静', org: '房山分局', targetType: '维修人员', targetName: '某维修点', content: '维修后设备频繁死机，维修质量不达标。', time: '2025-04-28 13:40', status: 'processing' },
  { id: 'C20250420003', complainant: '黄磊', org: '顺义分局', targetType: '产品质量', targetName: '执法记录仪X5', content: '电池续航与标称不符，实际使用不到4小时。', time: '2025-04-20 10:15', status: 'resolved', reply: '已联系厂家更换电池模组，请留意后续使用。' },
]

const statusColors: Record<string, { text: string; color: string }> = {
  pending: { text: '待处理', color: '#ff4d4f' },
  processing: { text: '处理中', color: '#1890ff' },
  resolved: { text: '已解决', color: '#52c41a' },
}



interface ProductData {
  id: string
  name: string
  category: string
  model: string
  specParams: string
  price: number
  unit: string
  supplierId: string
  supplierName: string
  supplierTypes: string[]
  isShortlisted: boolean
  status: ProductStatus
  image: string
  createTime: string
}



type PenaltyType = 'warning' | 'suspend' | 'cancel'



interface PenaltyData {
  id: string
  supplierName: string
  supplierId: string
  enterpriseType: EnterpriseType
  penaltyType: PenaltyType
  reason: string
  penaltyDate: string
  duration: string
  durationStart: string
  durationEnd: string
  dept: string
  relatedOrderId: string
  relatedOrderNo: string
  source: 'internal' | 'sync'
  contentType: 'penalty' | 'review'
  remarks?: string
}





/* ─── Equipment Control Types ─── */

interface ControlRecord {
  id: string
  target: string
  reason: string
  startTime: string
  endTime: string
  owner: string
  supplier: string
  status: 'active' | 'released'
}

const systemTargets = ['华为技术有限公司', '中兴通讯股份有限公司', '海康威视数字技术', '大疆创新科技有限公司', '海能达通信股份有限公司', '紫光电子集团有限公司']

const controlOwnerTree = [
  { id: 'D001', name: '一部', members: [{ id: 'U101', name: '张三' }, { id: 'U102', name: '李四' }] },
  { id: 'D002', name: '二部', members: [{ id: 'U201', name: '王五' }, { id: 'U202', name: '赵六' }] },
  { id: 'D003', name: '三部', members: [{ id: 'U301', name: '孙七' }, { id: 'U302', name: '周八' }] },
]


const products: ProductData[] = [
  { id: 'SP001', name: '手持终端', category: '通信设备', model: 'XT-2000', specParams: '5.5寸/8核/4G+64G/IP68防护', price: 2500, unit: '台', supplierId: 'SUP001', supplierName: '华为技术有限公司', supplierTypes: ['supplier', 'producer'], isShortlisted: true, status: 'on', image: '', createTime: '2024-03-10' },
  { id: 'SP002', name: '执法记录仪', category: '监控设备', model: 'DSJ-A7', specParams: '1080P/红外夜视/32G存储/IP67防护', price: 1200, unit: '台', supplierId: 'SUP002', supplierName: '海康威视数字技术股份有限公司', supplierTypes: ['producer'], isShortlisted: true, status: 'on', image: '', createTime: '2024-03-09' },
  { id: 'SP003', name: '无人机', category: '救援装备', model: 'M300-RTK', specParams: '55min续航/15km图传/IP45防护', price: 45000, unit: '台', supplierId: 'SUP003', supplierName: '大疆创新科技有限公司', supplierTypes: ['producer', 'agreement'], isShortlisted: true, status: 'review', image: '', createTime: '2024-03-08' },
  { id: 'SP004', name: '应急照明灯', category: '照明设备', model: 'YD-100', specParams: '1000流明/8小时续航/IP65防护', price: 350, unit: '台', supplierId: 'SUP004', supplierName: '中兴通讯股份有限公司', supplierTypes: ['supplier'], isShortlisted: false, status: 'off', image: '', createTime: '2024-03-05' },
  { id: 'SP005', name: '对讲机', category: '通信设备', model: 'PD780G', specParams: '数字双模/GPS定位/2000mAh', price: 1800, unit: '台', supplierId: 'SUP005', supplierName: '烽火通信科技股份有限公司', supplierTypes: ['supplier', 'agreement'], isShortlisted: false, status: 'review', image: '', createTime: '2024-03-01' },
  { id: 'SP006', name: '防弹背心', category: '防护装备', model: 'FDY-3R', specParams: '三级防护/凯夫拉材质/5.2kg', price: 3200, unit: '台', supplierId: 'SUP001', supplierName: '华为技术有限公司', supplierTypes: ['supplier', 'producer'], isShortlisted: true, status: 'on', image: '', createTime: '2024-02-28' },
  { id: 'SP007', name: '战术头盔', category: '防护装备', model: 'MICH-2000', specParams: '三级防弹/导轨系统/1.4kg', price: 1800, unit: '台', supplierId: 'SUP002', supplierName: '海康威视数字技术股份有限公司', supplierTypes: ['producer'], isShortlisted: false, status: 'review', image: '', createTime: '2024-02-25' },
  { id: 'SP008', name: '便携式卫星通信终端', category: '通信设备', model: 'SAT-100', specParams: 'Ku波段/2Mbps/锂电池供电', price: 85000, unit: '台', supplierId: 'SUP003', supplierName: '大疆创新科技有限公司', supplierTypes: ['producer', 'agreement'], isShortlisted: true, status: 'on', image: '', createTime: '2024-02-20' },
]



const penalties: PenaltyData[] = [
  // 内部 + 处罚
  { id: 'CF2024001', supplierName: '华为技术有限公司', supplierId: 'SUP001', enterpriseType: 'producer', penaltyType: 'warning', reason: '延期交货15天，影响项目进度', penaltyDate: '2024-03-10', duration: '3个月', durationStart: '2024-03-10', durationEnd: '2024-06-10', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD001', relatedOrderNo: 'CG2024001', source: 'internal', contentType: 'penalty' },
  // 内部 + 评价
  { id: 'CF2024002', supplierName: '海康威视数字技术股份有限公司', supplierId: 'SUP002', enterpriseType: 'producer', penaltyType: 'warning', reason: '售后服务响应不及时，技术支持评分低于标准', penaltyDate: '2024-04-15', duration: '3个月', durationStart: '2024-04-15', durationEnd: '2024-07-15', dept: 'XX市局科信处', relatedOrderId: '', relatedOrderNo: '', source: 'internal', contentType: 'review' },
  // 采购平台 + 处罚
  { id: 'CF2024003', supplierName: '烽火通信科技股份有限公司', supplierId: 'SUP005', enterpriseType: 'supplier', penaltyType: 'suspend', reason: '批次产品质量不合格，抽检发现缺陷', penaltyDate: '2024-05-01', duration: '3个月', durationStart: '2024-05-01', durationEnd: '2025-05-01', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD003', relatedOrderNo: 'CG2024008', source: 'sync', contentType: 'penalty' },
  // 采购平台 + 评价
  { id: 'CF2024004', supplierName: '中兴通讯股份有限公司', supplierId: 'SUP004', enterpriseType: 'producer', penaltyType: 'warning', reason: '合同变更未按时报备，被采购平台标记', penaltyDate: '2024-05-20', duration: '3个月', durationStart: '2024-05-20', durationEnd: '2024-08-20', dept: 'XX市局科信处', relatedOrderId: '', relatedOrderNo: '', source: 'sync', contentType: 'review' },
  // 内部 + 处罚
  { id: 'CF2024005', supplierName: '浪潮集团有限公司', supplierId: 'SUP006', enterpriseType: 'supplier', penaltyType: 'cancel', reason: '交付的存储设备配置与合同不符，实际容量低于约定规格', penaltyDate: '2024-06-10', duration: '3个月', durationStart: '2024-06-10', durationEnd: '2024-09-10', dept: 'XX省厅装备财务处', relatedOrderId: 'ORD005', relatedOrderNo: 'CG2024015', source: 'internal', contentType: 'penalty' },
]



type SupplierType = 'supplier' | 'producer' | 'agreement'
type QualifyStatus = 'normal' | 'paused' | 'void'
type AuditStatus = 'pending' | 'approved' | 'rejected'

interface EnterpriseData {
  id: string
  name: string
  shortName?: string
  creditCode: string
  address: string
  legalPerson: string
  contact: string
  techContact?: string
  phone: string
  email: string
  registerTime: string
  mainProducts: string
  policeAccess: boolean
  isSecret: boolean
  supplierTypes: SupplierType[]
  qualifyStatus: QualifyStatus
  auditStatus: AuditStatus
  certNo?: string
  brandName?: string
  frameworkNo?: string
  frameworkStart?: string
  frameworkEnd?: string
  supplyArea?: string
  bankAccount?: string
  remark: string
  createTime: string
  updateTime: string
}



const enterprises: EnterpriseData[] = [
  {
    id: 'SUP001', name: '华为技术有限公司', creditCode: '914403001XXXXXXX88', address: '深圳市龙岗区坂田华为基地',
    legalPerson: '任正非', contact: '张经理', phone: '13800138001', email: 'hw@huawei.com', registerTime: '2015-03-20',
    mainProducts: '通信设备/应急通信/指挥调度/服务器', policeAccess: true, isSecret: false,
    supplierTypes: ['supplier', 'producer'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-001', brandName: '华为', frameworkNo: 'XY-2024-001', frameworkStart: '2024-01-01', frameworkEnd: '2025-12-31',
    supplyArea: '全国', bankAccount: '招商银行深圳分行 7559XXXXXXXX1234',
    remark: '一级供应商，长期合作', createTime: '2024-01-15 09:00', updateTime: '2024-03-10 15:30',
  },
  {
    id: 'SUP002', name: '海康威视数字技术股份有限公司', creditCode: '913300007XXXXXXX99', address: '杭州市滨江区阡陌路555号',
    legalPerson: '陈宗年', contact: '李经理', phone: '13900139002', email: 'hk@hikvision.com', registerTime: '2010-08-12',
    mainProducts: '视频监控/安防设备/应急照明/智能分析', policeAccess: true, isSecret: false,
    supplierTypes: ['producer'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-002', brandName: '海康威视',
    remark: '', createTime: '2024-02-01 10:00', updateTime: '2024-03-05 14:20',
  },
  {
    id: 'SUP003', name: '大疆创新科技有限公司', creditCode: '914403003XXXXXXX77', address: '深圳市南山区高新南四道18号',
    legalPerson: '汪滔', contact: '王经理', phone: '13700137003', email: 'dj@dji.com', registerTime: '2012-06-05',
    mainProducts: '无人机/航拍设备/救援装备/测绘设备', policeAccess: true, isSecret: true,
    supplierTypes: ['producer', 'agreement'], qualifyStatus: 'normal', auditStatus: 'approved',
    certNo: 'SC-2024-005', brandName: '大疆', frameworkNo: 'XY-2024-005', frameworkStart: '2024-03-01', frameworkEnd: '2024-12-31',
    supplyArea: '华南/华东', bankAccount: '工商银行深圳分行 6222XXXXXXXX8888',
    remark: '涉密生产商，需保密协议', createTime: '2024-03-01 08:00', updateTime: '2024-03-12 16:00',
  },
  {
    id: 'SUP004', name: '中兴通讯股份有限公司', creditCode: '914403002XXXXXXX66', address: '深圳市南山区高新技术产业园',
    legalPerson: '李自学', contact: '赵经理', phone: '18600186004', email: 'zhao@zte.com.cn', registerTime: '2008-01-15',
    mainProducts: '通信设备/网络设备/卫星设备/终端设备', policeAccess: true, isSecret: false,
    supplierTypes: ['supplier'], qualifyStatus: 'normal', auditStatus: 'approved',
    frameworkNo: 'XY-2024-003', frameworkStart: '2024-01-15', frameworkEnd: '2024-12-31',
    supplyArea: '华南/华东', bankAccount: '招商银行深圳分行 7559XXXXXXXX1234',
    remark: '框架协议有效期内', createTime: '2024-01-10 09:30', updateTime: '2024-03-08 11:00',
  },
  {
    id: 'SUP005', name: '烽火通信科技股份有限公司', creditCode: '914201006XXXXXXX55', address: '武汉市东湖新技术开发区高新四路6号',
    legalPerson: '曾军', contact: '钱经理', phone: '18700187005', email: 'qian@fiberhome.com', registerTime: '2011-11-20',
    mainProducts: '通信设备/光纤设备/传输设备', policeAccess: false, isSecret: false,
    supplierTypes: ['supplier', 'agreement'], qualifyStatus: 'paused', auditStatus: 'approved',
    frameworkNo: 'XY-2024-006', frameworkStart: '2024-02-01', frameworkEnd: '2024-08-31',
    supplyArea: '华中/西南', bankAccount: '中国银行武汉支行 5678XXXXXXXX9012',
    remark: '资质暂停中，暂停供货', createTime: '2024-02-05 10:00', updateTime: '2024-03-15 09:00',
  },
  {
    id: 'SUP006', name: '浪潮集团有限公司', creditCode: '913700006XXXXXXX44', address: '济南市浪潮路1036号',
    legalPerson: '孙丕恕', contact: '孙经理', phone: '18800188006', email: 'sun@inspur.com', registerTime: '2005-04-10',
    mainProducts: '服务器/存储设备/计算设备/云服务', policeAccess: true, isSecret: false,
    supplierTypes: ['agreement'], qualifyStatus: 'void', auditStatus: 'approved',
    frameworkNo: 'XY-2024-008', frameworkStart: '2024-01-01', frameworkEnd: '2024-12-31',
    supplyArea: '华北/华东', bankAccount: '建设银行济南分行 1234XXXXXXXX5678',
    remark: '框架协议已到期作废', createTime: '2024-01-20 08:30', updateTime: '2024-04-01 14:00',
  },
]



type SyncDiffLevel = 'normal' | 'warning' | 'critical'

type ExternalStatus = 'active' | 'revoked' | 'cancelled'



// Penalty sync types

type PenaltySyncStatus = 'pending' | 'adopted' | 'rejected' | 'ignored'

type SyncAction = 'reference_only' | 'sync_status'



interface PenaltySyncDiffItem {

  id: string

  externalPenaltyId: string

  supplierName: string

  externalSupplierName: string

  creditCode: string

  penaltyType: PenaltyType

  reason: string

  penaltyDate: string

  duration: string

  sourcePlatform: string

  localMatchResult: string

  localSupplierStatus: string

  syncStatus: PenaltySyncStatus

  syncTime: string

  adoptOperator?: string

  adoptTime?: string

  localPenaltyId?: string

  actionType?: SyncAction

  rejectReason?: string

  isCritical: boolean

}



interface PenaltySyncLogItem {

  id: string

  operator: string

  ip: string

  time: string

  type: '逐条' | '批量'

  externalPenaltyId: string

  supplierName: string

  result: '采纳' | '驳回'

  actionType?: string

  reason: string

}



interface SyncDiffItem {

  id: string

  enterpriseId: string

  enterpriseName: string

  creditCode: string

  enterpriseType: EnterpriseType

  fieldName: string

  localValue: string

  externalValue: string

  diffLevel: SyncDiffLevel

  externalStatus: ExternalStatus

  externalFetchTime: string

  syncReason: string

  synced: boolean

}



const syncDiffData: SyncDiffItem[] = [

  {

    id: 'SYNC001', enterpriseId: 'SUP001', enterpriseName: '华为技术有限公司',

    creditCode: '914403001XXXXXXX88', enterpriseType: 'producer',

    fieldName: '法人姓名', localValue: '任正非', externalValue: '任正非（已变更）',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC002', enterpriseId: 'SUP001', enterpriseName: '华为技术有限公司',

    creditCode: '914403001XXXXXXX88', enterpriseType: 'producer',

    fieldName: '注册地址', localValue: '深圳市龙岗区坂田华为基地', externalValue: '深圳市龙岗区坂田华为基地B区',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC003', enterpriseId: 'SUP003', enterpriseName: '大疆创新科技有限公司',

    creditCode: '914403003XXXXXXX77', enterpriseType: 'producer',

    fieldName: '联系电话', localValue: '13700137003', externalValue: '0755-26656677',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC004', enterpriseId: 'SUP005', enterpriseName: '烽火通信科技股份有限公司',

    creditCode: '914201006XXXXXXX55', enterpriseType: 'supplier',

    fieldName: '法人姓名', localValue: '曾军', externalValue: '鲁国庆',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC005', enterpriseId: 'SUP005', enterpriseName: '烽火通信科技股份有限公司',

    creditCode: '914201006XXXXXXX55', enterpriseType: 'supplier',

    fieldName: '注册地址', localValue: '武汉市东湖新技术开发区高新四路6号', externalValue: '武汉市东湖新技术开发区高新四路6号烽火科技园',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC006', enterpriseId: 'SUP006', enterpriseName: '浪潮集团有限公司',

    creditCode: '913700006XXXXXXX44', enterpriseType: 'supplier',

    fieldName: '资质状态', localValue: '正常', externalValue: '作废',

    diffLevel: 'critical', externalStatus: 'cancelled', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC007', enterpriseId: 'SUP004', enterpriseName: '中兴通讯股份有限公司',

    creditCode: '914403002XXXXXXX66', enterpriseType: 'supplier',

    fieldName: '联系电话', localValue: '18600186004', externalValue: '18600186005',

    diffLevel: 'normal', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

  {

    id: 'SYNC008', enterpriseId: 'SUP002', enterpriseName: '海康威视数字技术股份有限公司',

    creditCode: '913300007XXXXXXX99', enterpriseType: 'producer',

    fieldName: '统一社会信用代码', localValue: '913300007XXXXXXX99', externalValue: '913300007XXXXXXX00',

    diffLevel: 'warning', externalStatus: 'active', externalFetchTime: '2025-01-15 10:30',

    syncReason: '', synced: false

  },

]



const syncLogData = [

  { id: 'LOG001', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:00', type: '逐条', enterpriseId: 'SUP001', field: '法人姓名', oldValue: '任正非', newValue: '任正非（已变更）', reason: '营业执照变更' },

  { id: 'LOG002', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:05', type: '批量', enterpriseId: 'SUP001', field: '注册地址', oldValue: '深圳市龙岗区坂田华为基地', newValue: '深圳市龙岗区坂田华为基地B区', reason: '企业搬迁' },

  { id: 'LOG003', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:10', type: '逐条', enterpriseId: 'SUP003', field: '联系电话', oldValue: '13700137003', newValue: '0755-26656677', reason: '企业电话变更' },

]



const penaltySyncDiffData: PenaltySyncDiffItem[] = [

  {

    id: 'PS001', externalPenaltyId: 'JW2024015', supplierName: '华为技术有限公司',

    externalSupplierName: '华为技术有限公司', creditCode: '914403001XXXXXXX88',

    penaltyType: 'suspend', reason: '串通投标，经查实在某项目投标中存在串标行为',

    penaltyDate: '2024-03-15', duration: '12个月', sourcePlatform: '省政府采购网',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

  {

    id: 'PS002', externalPenaltyId: 'SC2024088', supplierName: '海康威视数字技术股份有限公司',

    externalSupplierName: '海康威视数字技术股份有限公司', creditCode: '913300007XXXXXXX99',

    penaltyType: 'warning', reason: '延期交货，合同约定30天内交付，实际延期45天',

    penaltyDate: '2024-06-20', duration: '6个月', sourcePlatform: '市交易中心',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: false

  },

  {

    id: 'PS003', externalPenaltyId: 'CG2024102', supplierName: '中兴通讯股份有限公司',

    externalSupplierName: '中兴通讯股份有限公司', creditCode: '914403002XXXXXXX66',

    penaltyType: 'warning', reason: '合同变更未按时报备',

    penaltyDate: '2024-08-10', duration: '永久', sourcePlatform: '公安部装财局平台',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: false

  },

  {

    id: 'PS004', externalPenaltyId: 'JW2024110', supplierName: 'XX科技有限公司',

    externalSupplierName: 'XX科技有限公司', creditCode: '914403003XXXXXXX77',

    penaltyType: 'cancel', reason: '售后服务严重不达标，多次投诉未处理，已终止合作',

    penaltyDate: '2024-09-01', duration: '永久', sourcePlatform: '省政府采购网',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

  {

    id: 'PS005', externalPenaltyId: 'SC2024125', supplierName: '烽火通信科技股份有限公司',

    externalSupplierName: '烽火通信科技股份有限公司', creditCode: '914201006XXXXXXX55',

    penaltyType: 'suspend', reason: '产品质量抽检不合格，批次产品存在严重缺陷',

    penaltyDate: '2024-10-05', duration: '6个月', sourcePlatform: '市交易中心',

    localMatchResult: '已匹配', localSupplierStatus: '正常',

    syncStatus: 'pending', syncTime: '2025-01-15 10:30',

    isCritical: true

  },

]



const penaltySyncLogData: PenaltySyncLogItem[] = [

  { id: 'PLOG001', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:00', type: '逐条', externalPenaltyId: 'JW2024015', supplierName: '华为技术有限公司', result: '采纳', actionType: '同步变更供应商状态', reason: '串通投标事实清楚，证据确凿' },

  { id: 'PLOG002', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:05', type: '逐条', externalPenaltyId: 'SC2024088', supplierName: '海康威视数字技术股份有限公司', result: '采纳', actionType: '仅记录为外部参考', reason: '延期交货属实，但已协商解决' },

  { id: 'PLOG003', operator: '管理员', ip: '10.68.12.45', time: '2025-01-15 11:10', type: '批量', externalPenaltyId: 'CG2024102,CG2024103', supplierName: '中兴通讯股份有限公司', result: '采纳', actionType: '仅记录为外部参考', reason: '批量处理合同变更类警告' },

]





export default function SupplierPage({ activeSubTab, onNavigate }: Props) {

  const [activeTab, setActiveTab] = useState(activeSubTab && tabList.some(t => t.key === activeSubTab) ? activeSubTab : 'enterprise')

  const [drawerOpen, setDrawerOpen] = useState(false)

  const [drawerTitle, setDrawerTitle] = useState('')

  const [selectedEnterprise, setSelectedEnterprise] = useState<EnterpriseData | null>(null)

  // enterprise list state (unified, no longer split by producer/supplier view)

  const [editMode, setEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false)

  const [_enterpriseList, setEnterpriseList] = useState(enterprises)



  // Sync info states

  const [syncDiffList, setSyncDiffList] = useState(syncDiffData)

  const [syncLogList] = useState(syncLogData)

  const [_syncView, setSyncView] = useState<'diff' | 'log'>('diff')

  const [syncDetailOpen, setSyncDetailOpen] = useState(false)

  const [selectedDiff, setSelectedDiff] = useState<SyncDiffItem | null>(null)

  const [syncReason, setSyncReason] = useState('')

  const [batchSyncOpen, setBatchSyncOpen] = useState(false)

  const [batchReason, setBatchReason] = useState('')

  const [syncTriggerOpen, setSyncTriggerOpen] = useState(false)

  const [logModalOpen, setLogModalOpen] = useState(false)



  // Product management states

  const [selectedProduct, setSelectedProduct] = useState<ProductData | null>(null)

  const [productEditMode, setProductEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const [productList, _setProductList] = useState(products)

  // Enterprise products modal
  const [enterpriseProductsOpen, setEnterpriseProductsOpen] = useState(false)
  const [selectedEnterpriseForProducts, setSelectedEnterpriseForProducts] = useState<EnterpriseData | null>(null)



  // Penalty management states

  const [selectedPenalty, setSelectedPenalty] = useState<PenaltyData | null>(null)

  const [penaltyEditMode, setPenaltyEditMode] = useState<'add' | 'edit' | 'view'>('view')

  const [penaltyList, _setPenaltyList] = useState(penalties)

  const [penaltyDeleteOpen, setPenaltyDeleteOpen] = useState(false)

  const [penaltyDrawerOpen, setPenaltyDrawerOpen] = useState(false)



  // Penalty sync states

  const [penaltySyncView, setPenaltySyncView] = useState<'list' | 'diff' | 'log'>('list')

  const [penaltySyncDiffList, setPenaltySyncDiffList] = useState(penaltySyncDiffData)

  const [penaltySyncLogList] = useState(penaltySyncLogData)

  const [penaltySyncDetailOpen, setPenaltySyncDetailOpen] = useState(false)

  const [selectedPenaltyDiff, setSelectedPenaltyDiff] = useState<PenaltySyncDiffItem | null>(null)

  const [penaltySyncReason, setPenaltySyncReason] = useState('')

  const [penaltyBatchSyncOpen, setPenaltyBatchSyncOpen] = useState(false)

  const [penaltyBatchReason, setPenaltyBatchReason] = useState('')

  const [penaltySyncTriggerOpen, setPenaltySyncTriggerOpen] = useState(false)

  /* ─── Complaint management states ─── */
  const [complaintList, setComplaintList] = useState<Complaint[]>(complaintMock)
  const [complaintSearch, setComplaintSearch] = useState('')
  const [complaintStatusFilter, setComplaintStatusFilter] = useState('')
  const [complaintModalOpen, setComplaintModalOpen] = useState(false)
  const [complaintForm, setComplaintForm] = useState({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
  const [replyComplaint, setReplyComplaint] = useState<Complaint | null>(null)
  const [replyContent, setReplyContent] = useState('')
  const [replyOpen, setReplyOpen] = useState(false)
  const [targetSearchText, setTargetSearchText] = useState('')
  const [targetSearchOpen, setTargetSearchOpen] = useState(false)

  /* ─── Equipment Control states ─── */
  const [controls, setControls] = useState<ControlRecord[]>([
    { id: 'GK000001', target: '华为技术', reason: '质量问题批次', startTime: '2024-01-10', endTime: '2024-07-10', owner: '张三', supplier: '华为技术有限公司', status: 'active' },
    { id: 'GK000002', target: 'ZB005批次', reason: '安全隐患', startTime: '2024-02-01', endTime: '-', owner: '李四', supplier: '烽火通信', status: 'active' },
    { id: 'GK000003', target: 'XX电子', reason: '资质过期', startTime: '2023-12-01', endTime: '2024-01-15', owner: '王五', supplier: 'XX电子科技', status: 'released' },
  ])
  const [controlModalOpen, setControlModalOpen] = useState(false)
  const [controlModalMode, setControlModalMode] = useState<'add' | 'view'>('add')
  const [selectedControl, setSelectedControl] = useState<ControlRecord | null>(null)
  const [controlForm, setControlForm] = useState({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
  const [controlTargetSearch, setControlTargetSearch] = useState('')
  const [showTargetDropdown, setShowTargetDropdown] = useState(false)
  const [showOwnerTree, setShowOwnerTree] = useState(false)
  const [releaseConfirmOpen, setReleaseConfirmOpen] = useState(false)
  const [releasingControlId, setReleasingControlId] = useState<string | null>(null)


  const [penaltyAdoptAction, setPenaltyAdoptAction] = useState<SyncAction>('reference_only')

  const [penaltyRejectReason, setPenaltyRejectReason] = useState('')

  const [penaltyLogModalOpen, setPenaltyLogModalOpen] = useState(false)



  useEffect(() => {

    if (activeSubTab && tabList.some(t => t.key === activeSubTab)) {

      setActiveTab(activeSubTab)

    }

  }, [activeSubTab])



  // filtered list is now directly filtered by enterpriseView in the render



  const openDetail = (item: EnterpriseData, mode: 'view' | 'edit') => {

    setSelectedEnterprise(item)

    setEditMode(mode)

    setDrawerTitle(mode === 'edit' ? `编辑企业 - ${item.name}` : `企业详情 - ${item.name}`)

    setDrawerOpen(true)

  }



  const openAdd = () => {
    setSelectedEnterprise(null)
    setEditMode('add')
    setDrawerTitle('新增企业')
    setDrawerOpen(true)
  }



  const openProductDetail = (item: ProductData, mode: 'view' | 'edit') => {

    setSelectedProduct(item)

    setProductEditMode(mode)

    setDrawerTitle(mode === 'edit' ? `编辑商品 - ${item.name}` : `商品详情 - ${item.name}`)

    setDrawerOpen(true)

  }



  const openAddProduct = () => {

    setSelectedProduct(null)

    setProductEditMode('add')

    setDrawerTitle('新增商品报备')

    setDrawerOpen(true)

  }



  const openEnterpriseProducts = (item: EnterpriseData) => {

    setSelectedEnterpriseForProducts(item)

    setEnterpriseProductsOpen(true)

  }



  const openPenaltyDetail = (item: PenaltyData, mode: 'view' | 'edit') => {

    setSelectedPenalty(item)

    setPenaltyEditMode(mode)

    setPenaltyDrawerOpen(true)

  }



  const openAddPenalty = () => {

    setSelectedPenalty(null)

    setPenaltyEditMode('add')

    setPenaltyDrawerOpen(true)

  }



  const handleDeletePenalty = (item: PenaltyData) => {

    setSelectedPenalty(item)

    setPenaltyDeleteOpen(true)

  }



  const confirmDeletePenalty = () => {

    if (selectedPenalty) {

      _setPenaltyList(prev => prev.filter(p => p.id !== selectedPenalty.id))

    }

    setPenaltyDeleteOpen(false)

    setSelectedPenalty(null)

  }

  /* ─── Complaint handlers ─── */

  const addComplaint = () => {
    const finalForm = { ...complaintForm, complainant: currentUser.name, org: currentUser.org }
    if (!finalForm.targetName || !finalForm.content) return
    const newItem: Complaint = {
      id: `C${new Date().toISOString().slice(0, 10).replace(/-/g, '')}${String(complaintList.length + 1).padStart(3, '0')}`,
      ...finalForm,
      time: new Date().toLocaleString('zh-CN'),
      status: 'pending',
    }
    setComplaintList(prev => [newItem, ...prev])
    setComplaintModalOpen(false)
    setComplaintForm({ complainant: '', org: '', targetType: '供应商', targetName: '', content: '' })
    setTargetSearchText('')
  }

  const submitReply = () => {
    if (!replyComplaint || !replyContent) return
    setComplaintList(prev => prev.map(c => c.id === replyComplaint.id ? { ...c, status: 'resolved', reply: replyContent } : c))
    setReplyOpen(false)
    setReplyContent('')
    setReplyComplaint(null)
  }

  const processComplaint = (id: string) => {
    setComplaintList(prev => prev.map(c => c.id === id ? { ...c, status: 'processing' } : c))
  }



  /* ─── Equipment Control handlers ─── */
  const openControlModal = (mode: 'add' | 'view', control?: ControlRecord) => {
    setControlModalMode(mode)
    if (control) {
      setSelectedControl(control)
    } else {
      setSelectedControl(null)
      setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
      setControlTargetSearch('')
      setShowTargetDropdown(false)
      setShowOwnerTree(false)
    }
    setControlModalOpen(true)
  }

  const saveControl = () => {
    if (!controlForm.target || !controlForm.reason) return
    const newControl: ControlRecord = {
      id: `GK${String(Date.now()).slice(-6)}`,
      target: controlForm.target, reason: controlForm.reason,
      startTime: controlForm.startTime || new Date().toISOString().slice(0, 10),
      endTime: controlForm.endTime || '-', owner: controlForm.owner || '当前用户',
      supplier: controlTargetSearch || '',
      status: 'active',
    }
    setControls(prev => [newControl, ...prev])
    setControlModalOpen(false)
    setControlForm({ target: '', reason: '', startTime: '', endTime: '', owner: '' })
    setControlTargetSearch('')
    setShowTargetDropdown(false)
    setShowOwnerTree(false)
  }

  const releaseControl = (id: string) => {
    setControls(prev => prev.map(c => c.id === id ? { ...c, status: 'released' as const, endTime: new Date().toISOString().slice(0, 10) } : c))
    setReleaseConfirmOpen(false)
    setReleasingControlId(null)
  }

  const filteredComplaint = complaintList.filter(c => {
    const matchSearch = !complaintSearch || c.complainant.includes(complaintSearch) || c.targetName.includes(complaintSearch)
    const matchStatus = !complaintStatusFilter || c.status === complaintStatusFilter
    return matchSearch && matchStatus
  })



  const _openPenaltySyncDetail = (item: PenaltySyncDiffItem) => {

    setSelectedPenaltyDiff(item)

    setPenaltySyncReason('')

    setPenaltyAdoptAction('reference_only')

    setPenaltyRejectReason('')

    setPenaltySyncDetailOpen(true)

  }



  const _openPenaltyBatchSync = () => {

    setPenaltyBatchReason('')

    setPenaltyBatchSyncOpen(true)

  }



  const confirmSinglePenaltySync = () => {

    if (selectedPenaltyDiff) {

      setPenaltySyncDiffList(prev => prev.map(d => d.id === selectedPenaltyDiff.id ? { ...d, syncStatus: 'adopted' as PenaltySyncStatus, adoptOperator: '管理员', adoptTime: new Date().toISOString().slice(0, 16).replace('T', ' '), localPenaltyId: 'CF' + Date.now().toString().slice(-8) } : d))

    }

    setPenaltySyncDetailOpen(false)

    setSelectedPenaltyDiff(null)

  }



  const rejectSinglePenaltySync = () => {

    if (selectedPenaltyDiff) {

      setPenaltySyncDiffList(prev => prev.map(d => d.id === selectedPenaltyDiff.id ? { ...d, syncStatus: 'rejected' as PenaltySyncStatus, rejectReason: penaltyRejectReason } : d))

    }

    setPenaltySyncDetailOpen(false)

    setPenaltyRejectReason('')

    setSelectedPenaltyDiff(null)

  }



  const confirmBatchPenaltySync = () => {

    setPenaltySyncDiffList(prev => prev.map(d => d.syncStatus === 'pending' && !d.isCritical ? { ...d, syncStatus: 'adopted' as PenaltySyncStatus, adoptOperator: '管理员', adoptTime: new Date().toISOString().slice(0, 16).replace('T', ' '), localPenaltyId: 'CF' + Date.now().toString().slice(-8) + Math.floor(Math.random() * 1000) } : d))

    setPenaltyBatchSyncOpen(false)

    setPenaltyBatchReason('')

  }



  const _openSyncDetail = (item: SyncDiffItem) => {

    setSelectedDiff(item)

    setSyncReason('')

    setSyncDetailOpen(true)

  }



  const openBatchSync = () => {

    const normalDiffs = syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced)

    if (normalDiffs.length === 0) return

    setBatchReason('')

    setBatchSyncOpen(true)

  }



  const confirmSingleSync = () => {

    if (selectedDiff && syncReason.trim()) {

      setSyncDiffList(prev => prev.map(d => d.id === selectedDiff.id ? { ...d, synced: true, syncReason } : d))

    }

    setSyncDetailOpen(false)

    setSelectedDiff(null)

    setSyncReason('')

  }



  const confirmBatchSync = () => {

    if (batchReason.trim()) {

      setSyncDiffList(prev => prev.map(d => d.diffLevel !== 'critical' && !d.synced ? { ...d, synced: true, syncReason: batchReason } : d))

    }

    setBatchSyncOpen(false)

    setBatchReason('')

  }



  const _handleDelete = (item: EnterpriseData) => {

    setSelectedEnterprise(item)

    setDeleteConfirmOpen(true)

  }



  const confirmDelete = () => {

    if (selectedEnterprise) {

      setEnterpriseList(prev => prev.filter(e => e.id !== selectedEnterprise.id))

    }

    setDeleteConfirmOpen(false)

    setSelectedEnterprise(null)

  }



  const _pendingSuppliers = [

    { name: '华为技术公司', code: '91440300XXXXXXXX', contact: '张经理', date: '2024-01-10', status: 'pending' },

    { name: '海康威视公司', code: '91330000XXXXXXXX', contact: '李经理', date: '2024-01-09', status: 'pending' },

    { name: '大华技术公司', code: '91330000XXXXXXXX', contact: '王经理', date: '2024-01-08', status: 'pending' },

  ]



  const _qualifyStatusMap: Record<string, { label: string; color: string }> = {

    normal: { label: '正常', color: '#52c41a' },

    paused: { label: '暂停', color: '#faad14' },

    void: { label: '作废', color: '#ff4d4f' },

  }



  return (
    <div className="p-6 space-y-4">
      {/* Stats cards - all pages */}
      <div className="grid grid-cols-6 gap-4">
        {[
          { label: '供应商总量', value: `${enterprises.length} 家`, color: '#1890ff', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
          { label: '装备总量', value: `${products.length} 件`, color: '#f5222d', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
          { label: '正常供应商', value: `${_enterpriseList.filter((e: any) => e.qualifyStatus === 'normal').length} 家`, color: '#52c41a', icon: 'M22 11.08V12a10 10 0 11-5.93-9.14' },
          { label: '处罚中供应商', value: `${_enterpriseList.filter((e: any) => e.qualifyStatus === 'paused').length} 家`, color: '#faad14', icon: 'M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z' },
          { label: '商品报备数', value: `${productList.length} 件`, color: '#722ed1', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
          { label: '投诉记录', value: `${complaintList.length} 条`, color: '#ff4d4f', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
        ].map(card => (
          <div key={card.label} className="content-card p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: `${card.color}15` }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d={card.icon}/>
              </svg>
            </div>
            <div>
              <div className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
              <div className="text-lg font-bold" style={{ color: card.color }}>{card.value}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick entries - all pages */}
      <div className="content-card p-4">
        <div className="grid grid-cols-5 gap-3">
          {[
            { key: 'enterprise', label: '企业信息', desc: '供应商企业档案', color: '#13c2c2', icon: 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z' },
            { key: 'product', label: '商品管理', desc: '商品报备与审核', color: '#eb2f96', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
            { key: 'penalty', label: '处罚管理', desc: '违规处罚与记录', color: '#ff4d4f', icon: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z' },
            { key: 'complaint', label: '投诉管理', desc: '供应商投诉处理', color: '#722ed1', icon: 'M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636' },
            { key: 'control', label: '装备管控', desc: '装备管控管理', color: '#faad14', icon: 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z' },
          ].map(item => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`flex items-center gap-3 p-3 rounded-lg border transition-all hover:shadow-md text-left ${activeTab === item.key ? 'ring-2' : ''}`}
              style={{ borderColor: 'var(--border-color)', background: '#fff', '--tw-ring-color': item.color } as any}
            >
              <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: `${item.color}15` }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style={{ color: item.color }}>
                  <path d={item.icon}/>
                </svg>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium">{item.label}</div>
                <div className="text-xs truncate" style={{ color: 'var(--text-secondary)' }}>{item.desc}</div>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="flex-shrink-0" style={{ color: 'var(--text-disabled)' }}>
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          ))}
        </div>
      </div>


      {activeTab === 'penalty' && (
          <>
            <button className="btn-primary text-xs ml-auto" onClick={openAddPenalty}>+ 新增处罚登记</button>

            <button className="btn-default text-xs hidden" onClick={() => setPenaltySyncTriggerOpen(true)} style={{display: 'none'}}>

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>

                同步信息

              </span>

            </button>

            <button className="btn-default text-xs" onClick={() => setPenaltyLogModalOpen(true)}>

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                操作日志

              </span>

            </button>

          </>

        )}



      {/* Search + Action - Enterprise Only */}
      {activeTab === 'enterprise' && (
        <>
          <div className="flex items-center gap-2">
            <button className="btn-primary text-xs" onClick={() => openAdd()}>
              <span className="flex items-center gap-1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增企业
              </span>
            </button>
            <div className="ml-auto flex items-center gap-2">
              <button className="btn-default text-xs" onClick={() => setSyncTriggerOpen(true)}>
                <span className="flex items-center gap-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
                  同步企业信息
                </span>
              </button>
            </div>
          </div>

          {/* Search area */}
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业名称</label><input className="form-input w-48" placeholder="请输入企业名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业类型</label><select className="form-input w-36"><option>全部</option><option>管理供应商</option><option>生产商</option><option>协议供货商</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系人</label><input className="form-input w-32" placeholder="请输入联系人" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系电话</label><input className="form-input w-36" placeholder="请输入联系电话" /></div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default">重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>
        </>
      )}



      {/* Search area - penalty only */}
      {activeTab === 'penalty' && (
        <div className="content-card p-4">
          <div className="flex flex-wrap items-end gap-3">
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商名称</label><select className="form-input w-44"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>烽火通信科技股份有限公司</option><option>中兴通讯股份有限公司</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业类型</label><select className="form-input w-32"><option>全部</option><option>生产商</option><option>供货商</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚类型</label><select className="form-input w-32"><option>全部</option><option>警告</option><option>暂停资格</option><option>取消资格</option></select></div>
            <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚期限</label><input className="form-input w-32" type="date" /></div>
            <div className="flex gap-2 ml-auto">
              <button className="btn-default">重置</button>
              <button className="btn-primary">查询</button>
            </div>
          </div>
        </div>
      )}

      {/* Search area - complaint only */}
      {activeTab === 'complaint' && (
        <div className="flex justify-between items-center">
          <div className="flex gap-3 items-center">
            <input
              placeholder="投诉人/投诉对象"
              value={complaintSearch}
              onChange={e => setComplaintSearch(e.target.value)}
              className="form-input w-56"
            />
            <select
              value={complaintStatusFilter}
              onChange={e => setComplaintStatusFilter(e.target.value)}
              className="form-input w-32"
            >
              <option value="">全部状态</option>
              <option value="pending">待处理</option>
              <option value="processing">处理中</option>
              <option value="resolved">已解决</option>
            </select>
            <button className="btn-primary text-xs">查询</button>
            {(complaintSearch || complaintStatusFilter) && (
              <button onClick={() => { setComplaintSearch(''); setComplaintStatusFilter('') }} className="text-xs" style={{ color: 'var(--text-secondary)' }}>重置</button>
            )}
          </div>
          <button
            onClick={() => setComplaintModalOpen(true)}
            className="btn-danger text-xs"
          >投诉登记</button>
        </div>
      )}

      {/* Complaint List */}
      {activeTab === 'complaint' && (
        <div className="space-y-3">
          {filteredComplaint.map(item => (
            <div key={item.id} className="rounded-lg border p-4" style={{ borderColor: 'var(--border-color)', background: '#fff' }}>
              <div className="flex justify-between items-start mb-2">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-xs" style={{ color: 'var(--text-disabled)' }}>{item.id}</span>
                  <span className="text-sm font-medium">{item.complainant}</span>
                  <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.org}</span>
                  <span className="tag tag-gray text-xs">{item.targetType}</span>
                </div>
                <span className="px-2 py-0.5 rounded text-xs" style={{ background: `${statusColors[item.status].color}15`, color: statusColors[item.status].color }}>
                  {statusColors[item.status].text}
                </span>
              </div>
              <div className="text-sm mb-2">
                <span style={{ color: 'var(--text-secondary)' }}>投诉对象：</span>{item.targetName}
              </div>
              <p className="text-sm mb-3">{item.content}</p>
              <div className="flex justify-between items-center text-xs" style={{ color: 'var(--text-disabled)' }}>
                <span>{item.time}</span>
                <div className="flex gap-2">
                  {item.status === 'pending' && (
                    <button onClick={() => processComplaint(item.id)} className="px-3 py-1 rounded border text-xs hover:bg-blue-50" style={{ borderColor: '#1890ff', color: '#1890ff' }}>受理</button>
                  )}
                  {(item.status === 'processing' || item.status === 'pending') && (
                    <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="px-3 py-1 rounded border text-xs hover:bg-green-50" style={{ borderColor: '#52c41a', color: '#52c41a' }}>回复</button>
                  )}
                  {item.reply && (
                    <button onClick={() => { setReplyComplaint(item); setReplyOpen(true) }} className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }}>查看回复</button>
                  )}
                </div>
              </div>
              {item.reply && (
                <div className="mt-3 p-3 rounded text-sm" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                  <span style={{ color: '#52c41a' }} className="font-medium">回复：</span>
                  <span>{item.reply}</span>
                </div>
              )}
            </div>
          ))}
          {filteredComplaint.length === 0 && (
            <div className="text-center py-16 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无投诉记录</div>
          )}
        </div>
      )}

      {/* ═══════════ Equipment Control ═══════════ */}
      {activeTab === 'control' && (
        <>
          <div className="flex items-center justify-between">
            <button className="btn-primary flex items-center gap-1" onClick={() => openControlModal('add')}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>新增管控</button>
            <div className="flex gap-2 text-xs">
              <span className="px-3 py-1 rounded-full border">管控中 {controls.filter(c => c.status === 'active').length}</span>
              <span className="px-3 py-1 rounded-full border">已解除 {controls.filter(c => c.status === 'released').length}</span>
            </div>
          </div>
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr><th className="w-10"><input type="checkbox"/></th><th>管控单号</th><th>被管控对象</th><th>管控原因</th><th>开始时间</th><th>结束时间</th><th>责任人</th><th>状态</th><th>操作</th></tr>
              </thead>
              <tbody>
                {controls.map(c => (
                  <tr key={c.id}>
                    <td><input type="checkbox"/></td>
                    <td className="font-mono text-xs">{c.id}</td>
                    <td>{c.target}</td>
                    <td className="text-sm">{c.reason}</td>
                    <td className="text-xs">{c.startTime}</td>
                    <td className="text-xs">{c.endTime}</td>
                    <td>{c.owner}</td>
                    <td><span className="tag text-xs px-2 py-0.5" style={{ background: c.status === 'active' ? '#fffbe6' : '#f6ffed', color: c.status === 'active' ? '#faad14' : '#52c41a', border: `1px solid ${c.status === 'active' ? '#ffe58f' : '#b7eb8f'}` }}>{c.status === 'active' ? '管控中' : '已解除'}</span></td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs" style={{ color: 'var(--primary-blue)' }} onClick={() => openControlModal('view', c)}>查看</button>
                        {c.status === 'active' && (
                          <button className="text-xs" style={{ color: '#52c41a' }} onClick={() => { setReleasingControlId(c.id); setReleaseConfirmOpen(true) }}>解除</button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Control Add / View Modal */}
          {controlModalOpen && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold">{controlModalMode === 'add' ? '新增管控' : '查看管控'}</h3>
                  <button onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                </div>
                {controlModalMode === 'view' && selectedControl ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>管控单号</span><span className="font-mono text-xs">{selectedControl.id}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>状态</span><span className="tag text-xs px-2 py-0.5" style={{ background: selectedControl.status === 'active' ? '#fffbe6' : '#f6ffed', color: selectedControl.status === 'active' ? '#faad14' : '#52c41a' }}>{selectedControl.status === 'active' ? '管控中' : '已解除'}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>被管控对象</span><span className="text-sm">{selectedControl.target}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>责任人</span><span className="text-sm">{selectedControl.owner}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>开始时间</span><span className="text-xs">{selectedControl.startTime}</span></div>
                      <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>结束时间</span><span className="text-xs">{selectedControl.endTime}</span></div>
                    </div>
                    <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: 'var(--content-bg)' }}><span className="text-xs block mb-1" style={{ color: 'var(--text-secondary)' }}>管控原因</span><p className="text-sm">{selectedControl.reason}</p></div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="relative">
                      <label className="block text-xs mb-1">被管控装备 <span className="text-red-400">*</span></label>
                      <input className="form-input w-full" value={controlTargetSearch || controlForm.target} onChange={e => { setControlTargetSearch(e.target.value); setShowTargetDropdown(true); setControlForm({ ...controlForm, target: e.target.value }) }} onFocus={() => setShowTargetDropdown(true)} placeholder="输入装备名称/编号自动匹配" />
                      {showTargetDropdown && (
                        <div className="absolute top-full left-0 right-0 mt-1 p-2 rounded-lg border z-10 max-h-48 overflow-y-auto" style={{ borderColor: 'var(--border-color)', background: 'white' }}>
                          {systemTargets.filter(t => t.toLowerCase().includes(controlTargetSearch.toLowerCase()) || !controlTargetSearch).map(t => (
                            <div key={t} className="flex items-center gap-2 px-3 py-2 rounded cursor-pointer hover:bg-blue-50 text-xs" onClick={() => { setControlForm({ ...controlForm, target: t }); setControlTargetSearch(t); setShowTargetDropdown(false) }}>
                              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                              <span>{t}</span>
                            </div>
                          ))}
                          {controlTargetSearch && !systemTargets.some(t => t.toLowerCase().includes(controlTargetSearch.toLowerCase())) && (
                            <div className="px-3 py-2 text-xs" style={{ color: 'var(--text-disabled)' }}>无匹配数据，将使用自定义值</div>
                          )}
                        </div>
                      )}
                    </div>
                    <div><label className="block text-xs mb-1">管控原因 <span className="text-red-400">*</span></label><input className="form-input w-full" value={controlForm.reason} onChange={e => setControlForm({ ...controlForm, reason: e.target.value })} placeholder="请输入管控原因" /></div>
                    <div className="grid grid-cols-2 gap-3">
                      <div><label className="block text-xs mb-1">开始时间 <span className="text-red-400">*</span></label><input className="form-input w-full" type="date" value={controlForm.startTime} onChange={e => setControlForm({ ...controlForm, startTime: e.target.value })} /></div>
                      <div><label className="block text-xs mb-1">结束时间 <span className="text-red-400">*</span></label><input className="form-input w-full" type="date" value={controlForm.endTime} onChange={e => setControlForm({ ...controlForm, endTime: e.target.value })} /></div>
                    </div>
                    <div><label className="block text-xs mb-1">所属供应商 #</label><input className="form-input w-full" defaultValue="" placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} /></div>
                    <div><label className="block text-xs mb-1">备注</label><input className="form-input w-full" defaultValue="" placeholder="请输入备注" /></div>
                  </div>
                )}
                <div className="flex items-center justify-end gap-3 mt-4">
                  <button className="btn-default" onClick={() => { setControlModalOpen(false); setShowTargetDropdown(false); setShowOwnerTree(false) }}>关闭</button>
                  {controlModalMode === 'add' && <button className="btn-primary" onClick={saveControl}>保存</button>}
                </div>
              </div>
            </div>
          )}

          {/* Release Confirm Modal */}
          {releaseConfirmOpen && releasingControlId && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center">
              <div className="absolute inset-0 bg-black/40" onClick={() => setReleaseConfirmOpen(false)} />
              <div className="relative bg-white rounded-xl shadow-2xl w-[360px] p-6 text-center">
                <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-3" style={{ background: '#f6ffed' }}>
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                </div>
                <h4 className="text-base font-semibold mb-2">确认解除管控</h4>
                <p className="text-xs mb-4" style={{ color: 'var(--text-secondary)' }}>解除后该对象将恢复正常状态，是否确认？</p>
                <div className="flex items-center justify-center gap-3">
                  <button className="btn-default" onClick={() => setReleaseConfirmOpen(false)}>取消</button>
                  <button className="btn-primary" onClick={() => releaseControl(releasingControlId)}>确认解除</button>
                </div>
              </div>
            </div>
          )}
        </>
      )}

            {/* Enterprise List Table */}
      {activeTab === 'enterprise' && (
        <div className="content-card overflow-hidden">
          <table className="data-table">
            <thead>
              <tr>
                <th>企业名称</th>
                <th>统一社会信用代码</th>
                <th>联系人</th>
                <th>联系电话</th>
                <th>供应商类型</th>
                <th>警用准入</th>
                <th>是否涉密</th>
                <th>资质状态</th>
                <th>主营产品</th>
                <th>注册时间</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {enterprises.map(e => (
                <tr key={e.id}>
                  <td className="font-medium">{e.name}</td>
                  <td className="font-mono text-xs">{e.creditCode}</td>
                  <td>{e.contact}</td>
                  <td>{e.phone}</td>
                  <td>
                    <div className="flex flex-wrap gap-1">
                      {e.supplierTypes.map(t => (
                        <span key={t} className="tag text-xs" style={{
                          background: t === 'supplier' ? '#e6f7ff' : t === 'producer' ? '#f6ffed' : '#fff7e6',
                          color: t === 'supplier' ? '#1890ff' : t === 'producer' ? '#52c41a' : '#faad14',
                          border: `1px solid ${t === 'supplier' ? '#91d5ff' : t === 'producer' ? '#b7eb8f' : '#ffd591'}`
                        }}>
                          {t === 'supplier' ? '管理供应商' : t === 'producer' ? '生产商' : '协议供货商'}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <span className={`tag text-xs ${e.policeAccess ? 'tag-green' : 'tag-gray'}`}>{e.policeAccess ? '有' : '无'}</span>
                  </td>
                  <td>
                    <span className={`tag text-xs ${e.isSecret ? 'tag-red' : 'tag-gray'}`}>{e.isSecret ? '是' : '否'}</span>
                  </td>
                  <td>
                    <span className={`tag text-xs ${e.qualifyStatus === 'normal' ? 'tag-green' : e.qualifyStatus === 'paused' ? 'tag-yellow' : 'tag-gray'}`}>
                      {e.qualifyStatus === 'normal' ? '正常' : e.qualifyStatus === 'paused' ? '暂停' : '作废'}
                    </span>
                  </td>
                  <td className="max-w-[180px] truncate" title={e.mainProducts}>{e.mainProducts}</td>
                  <td className="text-xs">{e.registerTime}</td>
                  <td>
                    <div className="flex items-center gap-2">
                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openDetail(e, 'view')}>查看</button>
                      <button className="text-xs hover:underline" style={{ color: '#52c41a' }} onClick={() => openEnterpriseProducts(e)}>商品</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Enterprise Products Modal */}
      {enterpriseProductsOpen && selectedEnterpriseForProducts && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEnterpriseProductsOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[85vh] flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <div>
                <h3 className="text-lg font-semibold">{selectedEnterpriseForProducts.name} — 关联商品</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>统一社会信用代码：{selectedEnterpriseForProducts.creditCode}</p>
              </div>
              <button onClick={() => setEnterpriseProductsOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 overflow-y-auto flex-1">
              {(() => {
                const relatedProducts = productList.filter(p => p.supplierId === selectedEnterpriseForProducts.id)
                if (relatedProducts.length === 0) {
                  return (
                    <div className="flex flex-col items-center justify-center py-12" style={{ color: 'var(--text-disabled)' }}>
                      <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mb-3"><path d="M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2z"/></svg>
                      <p className="text-sm">该企业暂无关联商品</p>
                    </div>
                  )
                }
                return (
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>商品ID</th>
                        <th>装备名称</th>
                        <th>种类</th>
                        <th>型号</th>
                        <th>规格参数</th>
                        <th>参考单价</th>
                        <th>警采入围</th>
                        <th>报备状态</th>
                        <th>报备日期</th>
                      </tr>
                    </thead>
                    <tbody>
                      {relatedProducts.map(p => (
                        <tr key={p.id}>
                          <td className="font-mono text-xs">{p.id}</td>
                          <td className="font-medium">{p.name}</td>
                          <td>{p.category}</td>
                          <td className="font-mono text-xs">{p.model}</td>
                          <td className="max-w-[200px] truncate text-xs" title={p.specParams}>{p.specParams}</td>
                          <td className="font-mono">¥{p.price.toLocaleString()}</td>
                          <td><span className={`tag text-xs ${p.isShortlisted ? 'tag-green' : 'tag-gray'}`}>{p.isShortlisted ? '已入围' : '未入围'}</span></td>
                          <td><span className={`tag text-xs ${p.status === 'on' ? 'tag-green' : p.status === 'review' ? 'tag-yellow' : 'tag-gray'}`}>{p.status === 'on' ? '已上架' : p.status === 'review' ? '待审' : '已下架'}</span></td>
                          <td className="text-xs">{p.createTime}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )
              })()}
            </div>
            <div className="sticky bottom-0 z-10 px-6 py-3 border-t bg-gray-50 flex items-center justify-between" style={{ borderColor: 'var(--border-color)' }}>
              <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                共 {productList.filter(p => p.supplierId === selectedEnterpriseForProducts.id).length} 个关联商品
              </span>
              <button className="btn-default" onClick={() => setEnterpriseProductsOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* Product Search + List */}
      {activeTab === 'product' && (
        <>

          <div className="flex items-center gap-2">
            <button className="btn-primary text-xs" onClick={openAddProduct}>
              <span className="flex items-center gap-1">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
                新增商品报备
              </span>
            </button>
          </div>
          <div className="content-card p-4">
            <div className="flex flex-wrap items-end gap-3">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业名称</label><select className="form-input w-48"><option>全部</option><option>华为技术有限公司</option><option>海康威视数字技术股份有限公司</option><option>大疆创新科技有限公司</option><option>中兴通讯股份有限公司</option><option>烽火通信科技股份有限公司</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-40" placeholder="请输入装备名称" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>警采入围</label><select className="form-input w-28"><option>全部</option><option>已入围</option><option>未入围</option></select></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报备状态</label><select className="form-input w-28"><option>全部</option><option>待审</option><option>已上架</option><option>已下架</option></select></div>
              <div className="flex gap-2 ml-auto">
                <button className="btn-default">重置</button>
                <button className="btn-primary">查询</button>
              </div>
            </div>
          </div>
          <div className="content-card overflow-hidden">
            <table className="data-table">
              <thead>
                <tr>
                  <th>商品ID</th>
                  <th>装备名称</th>
                  <th>种类</th>
                  <th>型号</th>
                  <th>参考单价</th>
                  <th>企业名称</th>
                  <th>供应商类型</th>
                  <th>警采入围</th>
                  <th>报备状态</th>
                  <th>报备日期</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {productList.map(p => (
                  <tr key={p.id}>
                    <td className="font-mono text-xs">{p.id}</td>
                    <td className="font-medium">{p.name}</td>
                    <td>{p.category}</td>
                    <td className="font-mono text-xs">{p.model}</td>
                    <td className="font-mono">¥{p.price.toLocaleString()}</td>
                    <td>{p.supplierName}</td>
                    <td>
                      <div className="flex flex-wrap gap-1">
                        {p.supplierTypes.map(t => (
                          <span key={t} className="tag text-xs" style={{
                            background: t === 'supplier' ? '#e6f7ff' : t === 'producer' ? '#f6ffed' : '#fff7e6',
                            color: t === 'supplier' ? '#1890ff' : t === 'producer' ? '#52c41a' : '#faad14',
                            border: `1px solid ${t === 'supplier' ? '#91d5ff' : t === 'producer' ? '#b7eb8f' : '#ffd591'}`
                          }}>
                            {t === 'supplier' ? '管理供应商' : t === 'producer' ? '生产商' : '协议供货商'}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td><span className={`tag text-xs ${p.isShortlisted ? 'tag-green' : 'tag-gray'}`}>{p.isShortlisted ? '已入围' : '未入围'}</span></td>
                    <td><span className={`tag text-xs ${p.status === 'on' ? 'tag-green' : p.status === 'review' ? 'tag-yellow' : 'tag-gray'}`}>{p.status === 'on' ? '已上架' : p.status === 'review' ? '待审' : '已下架'}</span></td>
                    <td className="text-xs">{p.createTime}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openProductDetail(p, 'view')}>查看</button>
                        {p.status === 'review' && <button className="text-xs hover:underline" style={{ color: '#52c41a' }}>审核</button>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      {/* Sync search area */}

      {activeTab === 'sync' && (

        <>

          <div className="flex items-center gap-2">

            <button

              className="btn-default text-xs"

              onClick={() => setActiveTab('enterprise')}

            >

              <span className="flex items-center gap-1">

                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>

                返回企业信息

              </span>

            </button>

            <button

              className={`px-4 py-1.5 rounded-lg text-xs font-medium transition-colors border`}

              style={{ borderColor: 'var(--border-color)', color: 'var(--text-secondary)' }}

              onClick={() => setSyncView('log')}

            >

              同步日志

            </button>

              <button className="btn-primary ml-3 text-xs" onClick={openBatchSync}>

                <span className="flex items-center gap-1">

                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

                  一键全部覆盖修改

                </span>

              </button>



          </div>

        </>

      )}

        {activeTab === 'penalty' && penaltySyncView === 'list' && (

          <table className="data-table">

            <thead>

              <tr><th className="w-10"><input type="checkbox"/></th><th>处罚单号</th><th>供应商名称</th><th>企业类型</th><th>处罚类型</th><th>处罚事由</th><th>处罚日期</th><th>处罚期限</th><th>发布单位</th><th>操作</th></tr>

            </thead>

            <tbody>

              {penaltyList.map(p => (

                <tr key={p.id}>

                  <td><input type="checkbox"/></td>

                  <td className="font-mono text-xs">{p.id}</td>

                  <td>{p.supplierName}</td>

                  <td><span className="tag text-xs" style={{ background: p.enterpriseType === 'producer' ? '#e6f7ff' : '#f6ffed', color: p.enterpriseType === 'producer' ? '#1890ff' : '#52c41a', border: `1px solid ${p.enterpriseType === 'producer' ? '#91d5ff' : '#b7eb8f'}` }}>{p.enterpriseType === 'producer' ? '生产商' : '协议供货商'}</span></td>

                  <td><span className={`tag text-xs ${p.penaltyType === 'warning' ? 'tag-yellow' : p.penaltyType === 'suspend' ? 'tag-red' : 'tag-gray'}`}>{p.penaltyType === 'warning' ? '⚠️ 警告' : p.penaltyType === 'suspend' ? '⏸ 暂停资格' : '🚫 取消资格'}</span></td>

                  <td>{p.reason}</td>

                  <td>{p.penaltyDate}</td>

                  <td className="text-xs">{p.durationStart} ~ {p.durationEnd}</td>

                  <td>{p.dept}</td>
                  <td>

                    <div className="flex items-center gap-2">

                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openPenaltyDetail(p, 'view')}>查看</button>

                      <button className="text-xs hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => openPenaltyDetail(p, 'edit')}>修改</button>

                      <button className="text-xs hover:underline" style={{ color: '#ff4d4f' }} onClick={() => handleDeletePenalty(p)}>删除</button>

                    </div>

                  </td>

                </tr>

              ))}

            </tbody>

          </table>

        )}





      {/* Enterprise Detail / Add / Edit Drawer */}

      {drawerOpen && activeTab === 'enterprise' && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <h3 className="text-lg font-semibold">{drawerTitle}</h3>

              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* 企业基础信息 */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>企业信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商全称 <span className="text-red-400">*</span></label><input className="form-input" defaultValue={selectedEnterprise?.name || ''} placeholder="请输入供应商全称" readOnly={editMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>企业信用代码 <span className="text-red-400">*</span></label><input className="form-input font-mono" defaultValue={selectedEnterprise?.creditCode || ''} placeholder="请输入企业信用代码" readOnly={editMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商简称</label><input className="form-input" defaultValue={selectedEnterprise?.shortName || ''} placeholder="请输入供应商简称" readOnly={editMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>技术负责人</label><input className="form-input" defaultValue={selectedEnterprise?.techContact || ''} placeholder="请输入技术负责人" readOnly={editMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>联系电话 <span className="text-red-400">*</span></label><input className="form-input" defaultValue={selectedEnterprise?.phone || ''} placeholder="请输入联系电话" readOnly={editMode === 'view'} /></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>警用准入 <span className="text-red-400">*</span></label><select className="form-input" defaultValue={selectedEnterprise?.policeAccess ? 'true' : 'false'} disabled={editMode === 'view'}><option value="true">是</option><option value="false">否</option></select></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>是否涉密 <span className="text-red-400">*</span></label><select className="form-input" defaultValue={selectedEnterprise?.isSecret ? 'true' : 'false'} disabled={editMode === 'view'}><option value="true">是</option><option value="false">否</option></select></div>
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>资质状态</label><select className="form-input" defaultValue={selectedEnterprise?.qualifyStatus || 'normal'} disabled={editMode === 'view'}><option value="normal">正常</option><option value="paused">暂停</option><option value="void">作废</option></select></div>
                </div>
              </div>

              {/* 供应商类型 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-purple-500"/>供应商类型 <span className="text-red-400">*</span></h4>
                <div className="flex gap-4">
                  {(['producer', 'agreement', 'supplier'] as SupplierType[]).map(t => (
                    <label key={t} className="flex items-center gap-2 cursor-pointer">
                      <input type="checkbox" defaultChecked={selectedEnterprise?.supplierTypes?.includes(t) || false} disabled={editMode === 'view'} />
                      <span className="text-sm">{t === 'producer' ? '生产商' : t === 'agreement' ? '协议供货商' : '供应商'}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* 备注 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <div className="grid grid-cols-1 gap-4">
                  <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label><textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedEnterprise?.remark || ''} placeholder="请输入备注" readOnly={editMode === 'view'} /></div>
                </div>
              </div>

              {/* 系统信息 */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>系统信息</h4>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div><span style={{ color: 'var(--text-secondary)' }}>创建人员：</span><span>{selectedEnterprise?.createTime ? '管理员' : '-'}</span></div>
                  <div><span style={{ color: 'var(--text-secondary)' }}>创建时间：</span><span>{selectedEnterprise?.createTime || '-'}</span></div>
                  <div><span style={{ color: 'var(--text-secondary)' }}>更新时间：</span><span>{selectedEnterprise?.updateTime || '-'}</span></div>
                </div>
              </div>

            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default" onClick={() => setDrawerOpen(false)}>{editMode === 'view' ? '关闭' : '取消'}</button>

              {editMode !== 'view' && (

                <>

                  <button className="btn-default">保存草稿</button>

                  <button className="btn-primary">保存</button>

                </>

              )}

            </div>

          </div>

        </div>

      )}



      {/* Register audit drawer */}

      



      {/* Delete Confirmation Modal */}

      {deleteConfirmOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDeleteConfirmOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-4">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>

              </div>

              <h3 className="text-base font-semibold">确认删除</h3>

            </div>

            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除企业"<span className="font-medium">{selectedEnterprise?.name}</span>"？删除后数据将无法恢复，请谨慎操作。</p>

            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => setDeleteConfirmOpen(false)}>取消</button>

              <button className="btn-danger" onClick={confirmDelete}>确认删除</button>

            </div>

          </div>

        </div>

      )}



      {/* Sync Detail Modal - Single Item */}

      {syncDetailOpen && selectedDiff && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setSyncDetailOpen(false); setSyncReason('') }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

              </div>

              <h3 className="text-base font-semibold">逐条确认修改</h3>

            </div>



            {/* Enterprise info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

              <div className="flex items-center justify-between mb-2">

                <span className="font-medium">{selectedDiff.enterpriseName}</span>

                <span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedDiff.creditCode}</span>

              </div>

              <div className="flex items-center gap-3 text-xs">

                <span style={{ color: 'var(--text-secondary)' }}>字段：<span className="font-medium" style={{ color: 'var(--text-primary)' }}>{selectedDiff.fieldName}</span></span>

                <span style={{ color: 'var(--text-secondary)' }}>类型：<span className="tag text-xs" style={{ background: selectedDiff.enterpriseType === 'producer' ? '#e6f7ff' : '#f6ffed', color: selectedDiff.enterpriseType === 'producer' ? '#1890ff' : '#52c41a', border: `1px solid ${selectedDiff.enterpriseType === 'producer' ? '#91d5ff' : '#b7eb8f'}` }}>{selectedDiff.enterpriseType === 'producer' ? '生产商' : '协议供货商'}</span></span>

              </div>

            </div>



            {/* Value comparison */}

            <div className="grid grid-cols-2 gap-4 mb-4">

              <div className="p-3 rounded-lg border" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                <p className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>系统现有值</p>

                <p className="text-sm font-medium">{selectedDiff.localValue}</p>

              </div>

              <div className="p-3 rounded-lg border" style={{ borderColor: selectedDiff.diffLevel === 'critical' ? '#ffccc7' : '#ffe58f', background: selectedDiff.diffLevel === 'critical' ? '#fff2f0' : '#fffbe6' }}>

                <p className="text-xs mb-1" style={{ color: selectedDiff.diffLevel === 'critical' ? '#ff4d4f' : '#faad14' }}>外部平台值</p>

                <p className="text-sm font-medium" style={{ color: selectedDiff.diffLevel === 'critical' ? '#ff4d4f' : 'var(--text-primary)' }}>{selectedDiff.externalValue}</p>

              </div>

            </div>



            {/* External status */}

            <div className="flex items-center gap-4 mb-4 text-xs">

              <span style={{ color: 'var(--text-secondary)' }}>外部企业状态：{selectedDiff.externalStatus === 'active' ? <span className="tag tag-green text-xs">正常</span> : selectedDiff.externalStatus === 'revoked' ? <span className="tag tag-red text-xs">吊销</span> : <span className="tag tag-red text-xs">注销</span>}</span>

              <span style={{ color: 'var(--text-secondary)' }}>抓取时间：{selectedDiff.externalFetchTime}</span>

              <span style={{ color: 'var(--text-secondary)' }}>差异级别：{selectedDiff.diffLevel === 'critical' ? <span className="tag tag-red text-xs">严重异常</span> : selectedDiff.diffLevel === 'warning' ? <span className="tag tag-orange text-xs">警告</span> : <span className="tag tag-yellow text-xs">普通不一致</span>}</span>

            </div>



            {/* Reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>修改原因 <span className="text-red-400">*</span></label>

              <textarea

                className="form-input w-full text-sm"

                rows={3}

                placeholder="请填写修改原因（如：营业执照变更、数据录入错误、系统误判）..."

                value={syncReason}

                onChange={e => setSyncReason(e.target.value)}

              />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setSyncDetailOpen(false); setSyncReason('') }}>取消</button>

              <button

                className="btn-primary"

                disabled={!syncReason.trim()}

                onClick={confirmSingleSync}

              >

                确认修改

              </button>

            </div>

          </div>

        </div>

      )}



      {/* Batch Sync Modal */}

      {batchSyncOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setBatchSyncOpen(false); setBatchReason('') }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

              </div>

              <h3 className="text-base font-semibold">一键全部覆盖修改</h3>

            </div>



            {/* Auto-filter info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>

              <div className="flex items-center gap-2 mb-2">

                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>

                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>自动过滤完成</span>

              </div>

              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统已自动剔除 <span className="font-medium" style={{ color: '#ff4d4f' }}>{syncDiffList.filter(d => d.diffLevel === 'critical' && !d.synced).length}</span> 条严重异常记录。本次将批量处理 <span className="font-medium">{syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced).length}</span> 条普通差异。</p>

            </div>



            {/* Affected items list */}

            <div className="mb-4 max-h-40 overflow-y-auto">

              <p className="text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>待处理差异列表：</p>

              {syncDiffList.filter(d => d.diffLevel !== 'critical' && !d.synced).map(d => (

                <div key={d.id} className="flex items-center justify-between p-2 rounded border mb-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <span className="text-xs">{d.enterpriseName} - {d.fieldName}</span>

                  <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{d.localValue} → <span style={{ color: 'var(--primary-blue)' }}>{d.externalValue}</span></span>

                </div>

              ))}

            </div>



            {/* Batch reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批量修改原因 <span className="text-red-400">*</span></label>

              <textarea

                className="form-input w-full text-sm"

                rows={3}

                placeholder="请填写批量修改原因（如：企业统一地址变更、批量资质更新）..."

                value={batchReason}

                onChange={e => setBatchReason(e.target.value)}

              />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setBatchSyncOpen(false); setBatchReason('') }}>取消</button>

              <button

                className="btn-primary"

                disabled={!batchReason.trim()}

                onClick={confirmBatchSync}

              >

                确认全部修改

              </button>

            </div>

          </div>

        </div>

      )}



      {/* Product Detail / Edit Drawer */}

      {drawerOpen && activeTab === 'product' && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setDrawerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <h3 className="text-lg font-semibold">{drawerTitle}</h3>

              <button onClick={() => setDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="p-6 space-y-5 overflow-y-auto flex-1">

              {/* Section 1: Basic Info */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>商品信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>物资名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" placeholder="请输入物资名称" defaultValue={selectedProduct?.name || ''} readOnly={productEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>规格型号</label>
                    <input className="form-input" placeholder="请输入规格型号" defaultValue={selectedProduct?.model || ''} readOnly={productEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>种类 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.category || ''} disabled={productEditMode === 'view'}>
                      <option>请选择</option><option>通信设备</option><option>照明设备</option><option>监控设备</option><option>救援装备</option><option>消防装备</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单位 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.unit || '台'} disabled={productEditMode === 'view'}>
                      <option>台</option><option>套</option><option>件</option><option>个</option><option>支</option><option>面</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>单价(¥) <span className="text-red-400">*</span></label>
                    <input className="form-input font-mono" type="number" placeholder="¥" defaultValue={selectedProduct?.price || ''} readOnly={productEditMode === 'view'} />
                  </div>
                </div>
              </div>

              {/* Section 2: Supplier Info */}
              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>供应商信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商名称 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedProduct?.supplierId || ''} disabled={productEditMode === 'view'}>
                      <option>请选择供应商</option>
                      <option value="SUP001">华为技术有限公司</option>
                      <option value="SUP002">海康威视数字技术股份有限公司</option>
                      <option value="SUP003">大疆创新科技有限公司</option>
                      <option value="SUP004">中兴通讯股份有限公司</option>
                      <option value="SUP005">烽火通信科技股份有限公司</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商类型 <span className="text-red-400">*</span></label>
                    <div className="flex gap-4">
                      {(['producer', 'agreement', 'supplier'] as SupplierType[]).map(t => (
                        <label key={t} className="flex items-center gap-2 cursor-pointer">
                          <input type="checkbox" defaultChecked={selectedProduct?.supplierTypes?.includes(t) || false} disabled={productEditMode === 'view'} />
                          <span className="text-sm">{t === 'producer' ? '生产商' : t === 'agreement' ? '协议供货商' : '供应商'}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </div>







              {/* Section 4: Image Upload */}

              <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-blue-500"/>商品图片</h4>

                <div className="p-4 rounded border border-dashed flex flex-col items-center justify-center gap-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#d9d9d9" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>

                  <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>{productEditMode === 'view' ? '暂无商品图片' : '请上传商品图片'}</p>

                  <p className="text-xs" style={{ color: 'var(--text-disabled)' }}>支持 JPG、PNG 格式</p>

                </div>

              </div>



              {/* Section 5: Audit Flow */}

              {selectedProduct && (

                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-green-500"/>报备流程</h4>

                  <div className="flex items-center gap-2">

                    {[

                      { label: '填写信息', active: true },

                      { label: '提交报备', active: selectedProduct.status !== 'off' },

                      { label: '审核', active: selectedProduct.status === 'on' || selectedProduct.status === 'off' },

                      { label: selectedProduct.status === 'on' ? '已上架' : selectedProduct.status === 'off' ? '已下架' : '待审核', active: selectedProduct.status === 'on' || selectedProduct.status === 'off' },

                    ].map((step, i, arr) => (

                      <div key={i} className="flex items-center gap-2 flex-1">

                        <div className="flex flex-col items-center">

                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${step.active ? 'text-white' : 'text-gray-400'}`} style={{ background: step.active ? '#52c41a' : '#f5f5f5', border: `2px solid ${step.active ? '#52c41a' : '#d9d9d9'}` }}>

                            {step.active ? i + 1 : <span style={{ color: '#bfbfbf' }}>{i + 1}</span>}

                          </div>

                          <span className={`text-xs mt-1 ${step.active ? 'text-green-600 font-medium' : 'text-gray-400'}`}>{step.label}</span>

                        </div>

                        {i < arr.length - 1 && <div className="flex-1 h-0.5 mx-1" style={{ background: step.active ? '#52c41a' : '#d9d9d9' }} />}

                      </div>

                    ))}

                  </div>

                </div>

              )}

            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default" onClick={() => setDrawerOpen(false)}>{productEditMode === 'view' ? '关闭' : '取消'}</button>

              {productEditMode !== 'view' && (

                <>

                  <button className="btn-default">保存草稿</button>

                  <button className="btn-primary">提交报备</button>

                </>

              )}

            </div>

          </div>

        </div>

      )}



      {/* Sync Trigger Modal — 自动同步确认 */}
      {syncTriggerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setSyncTriggerOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
              </div>
              <h3 className="text-base font-semibold">同步企业信息</h3>
            </div>
            <div className="mb-5 space-y-3">
              <div className="p-3 rounded-lg border" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
                <div className="flex items-center gap-2 mb-1">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                  <span className="text-sm font-medium" style={{ color: '#52c41a' }}>采购平台已接入</span>
                </div>
                <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统将自动对接采购平台获取最新企业数据</p>
              </div>
              <p className="text-sm" style={{ color: 'var(--text-secondary)' }}>点击确认后，系统将自动执行以下操作：</p>
              <ol className="text-sm space-y-1 ml-4" style={{ color: 'var(--text-secondary)' }}>
                <li>1. 从采购平台获取供应商、生产商、协议供货商最新信息</li>
                <li>2. 自动同步所有企业数据到本系统</li>
                <li>3. 更新企业档案和关联信息</li>
              </ol>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setSyncTriggerOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => { setSyncTriggerOpen(false); alert('同步成功！已同步 128 家企业信息。') }}>确认同步</button>
            </div>
          </div>
        </div>
      )}



      {/* Log Modal — 企业信息页点击"操作日志"弹出 */}

      {logModalOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setLogModalOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>

              <div className="flex items-center gap-3">

                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                </div>

                <h3 className="text-base font-semibold">同步操作日志</h3>

              </div>

              <button onClick={() => setLogModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="flex-1 overflow-auto p-6">

              <table className="w-full text-sm">

                <thead>

                  <tr style={{ background: 'var(--table-header-bg)' }}>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>类型</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>企业ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改字段</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改前</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改后</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>修改原因</th>

                  </tr>

                </thead>

                <tbody>

                  {syncLogList.map(l => (

                    <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>

                      <td className="px-3 py-2 font-mono text-xs">{l.id}</td>

                      <td className="px-3 py-2">{l.operator}</td>

                      <td className="px-3 py-2 text-xs">{l.time}</td>

                      <td className="px-3 py-2"><span className={`tag ${l.type === '逐条' ? 'tag-blue' : 'tag-green'} text-xs`}>{l.type}</span></td>

                      <td className="px-3 py-2 font-mono text-xs">{l.enterpriseId}</td>

                      <td className="px-3 py-2">{l.field}</td>

                      <td className="px-3 py-2 text-xs" style={{ color: 'var(--text-secondary)' }}>{l.oldValue}</td>

                      <td className="px-3 py-2 text-xs font-medium">{l.newValue}</td>

                      <td className="px-3 py-2 text-xs">{l.reason}</td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

            <div className="px-6 py-4 border-t flex items-center justify-end" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default text-xs" onClick={() => setLogModalOpen(false)}>关闭</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Sync Trigger Modal */}

      {penaltySyncTriggerOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltySyncTriggerOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[480px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><path d="M21.5 2v6h-6M2.5 22v-6h6M2 11.5a10 10 0 0118.8-4.3M22 12.5a10 10 0 01-18.8 4.3"/></svg>
              </div>
              <h3 className="text-base font-semibold">同步外部处罚信息</h3>
            </div>
            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>
              <div className="flex items-center gap-2 mb-2">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>采购平台已接入</span>
              </div>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统将自动对接采购平台，同步供应商处罚记录和评价信息到本系统，无需差异对比。</p>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setPenaltySyncTriggerOpen(false)}>取消</button>
              <button className="btn-primary" onClick={() => { setPenaltySyncTriggerOpen(false); alert('同步成功！已从采购平台同步 3 条处罚记录。'); }}>确认同步</button>
            </div>
          </div>

        </div>

      )}



      {/* Penalty Sync Detail Modal - Single Item */}

      {penaltySyncDetailOpen && selectedPenaltyDiff && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setPenaltySyncDetailOpen(false); setPenaltySyncReason(''); setPenaltyRejectReason(''); }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[580px] max-h-[90vh] overflow-y-auto p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#e6f7ff' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1890ff" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>

              </div>

              <h3 className="text-base font-semibold">逐条确认</h3>

              {selectedPenaltyDiff.isCritical && <span className="tag tag-red text-xs">严重-强制逐条</span>}

            </div>



            {/* External penalty info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

              <div className="flex items-center justify-between mb-2">

                <span className="font-medium">{selectedPenaltyDiff.externalSupplierName}</span>

                <span className="font-mono text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenaltyDiff.creditCode}</span>

              </div>

              <div className="flex items-center gap-3 text-xs">

                <span style={{ color: 'var(--text-secondary)' }}>外部编号：<span className="font-medium font-mono">{selectedPenaltyDiff.externalPenaltyId}</span></span>

                <span style={{ color: 'var(--text-secondary)' }}>来源：<span className="font-medium">{selectedPenaltyDiff.sourcePlatform}</span></span>

                <span className="tag text-xs" style={{ background: selectedPenaltyDiff.penaltyType === 'warning' ? '#fffbe6' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#fff2f0' : '#f5f5f5', color: selectedPenaltyDiff.penaltyType === 'warning' ? '#faad14' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#ff4d4f' : '#8c8c8c', border: `1px solid ${selectedPenaltyDiff.penaltyType === 'warning' ? '#ffe58f' : selectedPenaltyDiff.penaltyType === 'suspend' ? '#ffccc7' : '#d9d9d9'}` }}>{selectedPenaltyDiff.penaltyType === 'warning' ? '⚠️ 警告' : selectedPenaltyDiff.penaltyType === 'suspend' ? '⏸ 暂停资格' : '🚫 取消资格'}</span>

              </div>

            </div>



            {/* Detail info */}

            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">

              <div><span style={{ color: 'var(--text-secondary)' }}>处罚日期：</span><span className="font-medium">{selectedPenaltyDiff.penaltyDate}</span></div>

              <div><span style={{ color: 'var(--text-secondary)' }}>处罚期限：</span><span className="font-medium">{selectedPenaltyDiff.duration}</span></div>

              <div className="col-span-2"><span style={{ color: 'var(--text-secondary)' }}>处罚事由：</span><span>{selectedPenaltyDiff.reason}</span></div>

            </div>



            {/* Local match */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#91d5ff', background: '#e6f7ff' }}>

              <p className="text-xs font-medium mb-1" style={{ color: '#1890ff' }}>本地匹配结果</p>

              <p className="text-sm">供应商：{selectedPenaltyDiff.supplierName}（当前资质状态：<span className="tag tag-green text-xs">{selectedPenaltyDiff.localSupplierStatus}</span>）</p>

            </div>



            {/* Adopt action selection */}

            <div className="mb-4">

              <label className="block text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>采纳操作 <span className="text-red-400">*</span></label>

              <div className="space-y-2">

                <label className="flex items-center gap-2 p-3 rounded border cursor-pointer" style={{ borderColor: penaltyAdoptAction === 'reference_only' ? '#1890ff' : 'var(--border-color)', background: penaltyAdoptAction === 'reference_only' ? '#e6f7ff' : '#fafafa' }}>

                  <input type="radio" name="adoptAction" value="reference_only" checked={penaltyAdoptAction === 'reference_only'} onChange={() => setPenaltyAdoptAction('reference_only')} />

                  <div>

                    <p className="text-sm font-medium">仅记录为外部参考</p>

                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>写入本地处罚表，但不自动变更供应商状态</p>

                  </div>

                </label>

                <label className="flex items-center gap-2 p-3 rounded border cursor-pointer" style={{ borderColor: penaltyAdoptAction === 'sync_status' ? '#1890ff' : 'var(--border-color)', background: penaltyAdoptAction === 'sync_status' ? '#e6f7ff' : '#fafafa' }}>

                  <input type="radio" name="adoptAction" value="sync_status" checked={penaltyAdoptAction === 'sync_status'} onChange={() => setPenaltyAdoptAction('sync_status')} />

                  <div>

                    <p className="text-sm font-medium">同步变更供应商状态</p>

                    <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>写入本地处罚表，且根据处罚类型联动更新供应商资质状态</p>

                  </div>

                </label>

              </div>

            </div>



            {/* Sync reason */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>采纳原因 <span className="text-red-400">*</span></label>

              <textarea className="form-input w-full text-sm" rows={2} placeholder="请填写采纳原因..." value={penaltySyncReason} onChange={e => setPenaltySyncReason(e.target.value)} />

            </div>



            {/* Reject section */}

            <div className="border-t pt-4 mb-4" style={{ borderColor: 'var(--border-color)' }}>

              <label className="block text-xs mb-1 font-medium" style={{ color: '#ff4d4f' }}>驳回原因（如驳回请填写）</label>

              <textarea className="form-input w-full text-sm" rows={2} placeholder="如：信息不实、已过申诉期、与本省采购无关..." value={penaltyRejectReason} onChange={e => setPenaltyRejectReason(e.target.value)} />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setPenaltySyncDetailOpen(false); setPenaltySyncReason(''); setPenaltyRejectReason(''); }}>取消</button>

              <button className="btn-danger" disabled={!penaltyRejectReason.trim()} onClick={rejectSinglePenaltySync}>驳回</button>

              <button className="btn-primary" disabled={!penaltySyncReason.trim()} onClick={confirmSinglePenaltySync}>采纳</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Batch Sync Modal */}

      {penaltyBatchSyncOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => { setPenaltyBatchSyncOpen(false); setPenaltyBatchReason(''); }} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[520px] p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-5">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M4 14h6v2H4z"/><path d="M4 8h10v2H4z"/><path d="M20 8l-4 4 4 4"/><path d="M4 20h10v2H4z"/></svg>

              </div>

              <h3 className="text-base font-semibold">批量确认采纳</h3>

            </div>



            {/* Auto-filter info */}

            <div className="p-3 rounded-lg border mb-4" style={{ borderColor: '#b7eb8f', background: '#f6ffed' }}>

              <div className="flex items-center gap-2 mb-2">

                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M22 11.08V12a10 10 0 11-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>

                <span className="text-sm font-medium" style={{ color: '#52c41a' }}>自动过滤完成</span>

              </div>

              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>系统已自动剔除 <span className="font-medium" style={{ color: '#ff4d4f' }}>{penaltySyncDiffList.filter(d => d.isCritical && d.syncStatus === 'pending').length}</span> 条严重记录（取消资格/暂停资格）。本次将批量处理 <span className="font-medium">{penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length}</span> 条警告类记录。</p>

            </div>



            {/* Affected items list */}

            <div className="mb-4 max-h-40 overflow-y-auto">

              <p className="text-xs mb-2 font-medium" style={{ color: 'var(--text-secondary)' }}>待批量处理列表：</p>

              {penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').map(d => (

                <div key={d.id} className="flex items-center justify-between p-2 rounded border mb-1" style={{ borderColor: 'var(--border-color)', background: '#fafafa' }}>

                  <span className="text-xs">{d.externalSupplierName} - {d.externalPenaltyId}</span>

                  <span className="text-xs font-mono" style={{ color: 'var(--text-secondary)' }}>{d.sourcePlatform}</span>

                </div>

              ))}

              {penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length === 0 && (

                <p className="text-xs text-center py-2" style={{ color: 'var(--text-secondary)' }}>无符合条件的记录</p>

              )}

            </div>



            {/* Batch reason input */}

            <div className="mb-5">

              <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>批量采纳原因 <span className="text-red-400">*</span></label>

              <textarea className="form-input w-full text-sm" rows={3} placeholder="请填写批量采纳原因..." value={penaltyBatchReason} onChange={e => setPenaltyBatchReason(e.target.value)} />

            </div>



            <div className="flex items-center justify-end gap-3">

              <button className="btn-default" onClick={() => { setPenaltyBatchSyncOpen(false); setPenaltyBatchReason(''); }}>取消</button>

              <button className="btn-primary" disabled={!penaltyBatchReason.trim() || penaltySyncDiffList.filter(d => !d.isCritical && d.syncStatus === 'pending').length === 0} onClick={confirmBatchPenaltySync}>确认批量采纳</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Log Modal */}

      {penaltyLogModalOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyLogModalOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-[900px] max-h-[80vh] flex flex-col animate-in fade-in zoom-in duration-200">

            <div className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>

              <div className="flex items-center gap-3">

                <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: '#f6ffed' }}>

                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#52c41a" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>

                </div>

                <h3 className="text-base font-semibold">处罚同步操作日志</h3>

              </div>

              <button onClick={() => setPenaltyLogModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>

              </button>

            </div>

            <div className="flex-1 overflow-auto p-6">

              <table className="w-full text-sm">

                <thead>

                  <tr style={{ background: 'var(--table-header-bg)' }}>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>日志ID</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作人</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>IP地址</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作时间</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>类型</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>外部处罚编号</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>供应商名称</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>处理结果</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>操作方式</th>

                    <th className="px-3 py-2 text-left text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>处理原因</th>

                  </tr>

                </thead>

                <tbody>

                  {penaltySyncLogList.map(l => (

                    <tr key={l.id} className="border-b" style={{ borderColor: 'var(--border-color)' }}>

                      <td className="px-3 py-2 font-mono text-xs">{l.id}</td>

                      <td className="px-3 py-2">{l.operator}</td>

                      <td className="px-3 py-2 font-mono text-xs">{l.ip}</td>

                      <td className="px-3 py-2 text-xs">{l.time}</td>

                      <td className="px-3 py-2"><span className={`tag text-xs ${l.type === '逐条' ? 'tag-blue' : 'tag-green'}`}>{l.type}</span></td>

                      <td className="px-3 py-2 font-mono text-xs">{l.externalPenaltyId}</td>

                      <td className="px-3 py-2">{l.supplierName}</td>

                      <td className="px-3 py-2"><span className={`tag text-xs ${l.result === '采纳' ? 'tag-green' : 'tag-red'}`}>{l.result}</span></td>

                      <td className="px-3 py-2 text-xs">{l.actionType || '-'}</td>

                      <td className="px-3 py-2 text-xs max-w-xs truncate" title={l.reason}>{l.reason}</td>

                    </tr>

                  ))}

                </tbody>

              </table>

            </div>

            <div className="px-6 py-4 border-t flex items-center justify-end" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default text-xs" onClick={() => setPenaltyLogModalOpen(false)}>关闭</button>

            </div>

          </div>

        </div>

      )}



      {/* Penalty Detail / Edit Drawer */}

      {penaltyDrawerOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyDrawerOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[800px] max-h-[92vh] overflow-hidden flex flex-col animate-in fade-in zoom-in duration-200">
            <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">
                {penaltyEditMode === 'add' ? '新增处罚登记' : penaltyEditMode === 'edit' ? `编辑处罚 - ${selectedPenalty?.id}` : `处罚详情 - ${selectedPenalty?.id}`}
              </h3>
              <button onClick={() => setPenaltyDrawerOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="p-6 space-y-6 overflow-y-auto flex-1">
              {/* Basic Info */}
              <div>
                <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-red-500"/>处罚基本信息</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商名称 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedPenalty?.supplierName || ''} placeholder="请输入供应商名称" readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚类型 <span className="text-red-400">*</span></label>
                    <select className="form-input" defaultValue={selectedPenalty?.penaltyType || 'warning'} disabled={penaltyEditMode === 'view'}>
                      <option value="warning">警告</option>
                      <option value="suspend">暂停资格</option>
                      <option value="cancel">取消资格</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚事由 <span className="text-red-400">*</span></label>
                    <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedPenalty?.reason || ''} placeholder="请详细描述处罚事由、事实依据..." readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚日期 <span className="text-red-400">*</span></label>
                    <input className="form-input" type="date" defaultValue={selectedPenalty?.penaltyDate || ''} readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处罚期限 <span className="text-red-400">*</span></label>
                    <input className="form-input" defaultValue={selectedPenalty?.duration || ''} placeholder="请输入处罚期限" readOnly={penaltyEditMode === 'view'} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>供应商类型 #</label>
                    <input className="form-input" defaultValue={selectedPenalty?.enterpriseType || ''} placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>发布单位 #</label>
                    <input className="form-input" defaultValue={selectedPenalty?.dept || ''} placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div>
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>来源 #</label>
                    <input className="form-input" defaultValue={selectedPenalty?.source === 'sync' ? '采购平台' : '内部'} placeholder="系统自动获取" readOnly style={{ background: '#fafafa' }} />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label>
                    <textarea className="form-input w-full text-sm" rows={2} defaultValue={selectedPenalty?.remarks || ''} placeholder="请输入备注信息..." readOnly={penaltyEditMode === 'view'} />
                  </div>
                </div>
              </div>



              {/* Process Info - View Only */}

              {penaltyEditMode === 'view' && selectedPenalty && (

                <div className="border-t pt-5" style={{ borderColor: 'var(--border-color)' }}>

                  <h4 className="font-semibold mb-4 flex items-center gap-2"><span className="w-1 h-4 rounded-full bg-gray-400"/>处理流程</h4>

                  <div className="space-y-3">

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>1</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">管理员发起处罚登记</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenalty.penaltyDate} 管理员录入处罚信息</p>

                      </div>

                      <span className="tag tag-green text-xs">已完成</span>

                    </div>

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#52c41a' }}>2</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">录入事实与依据</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>{selectedPenalty.reason}</p>

                      </div>

                      <span className="tag tag-green text-xs">已完成</span>

                    </div>

                    <div className="flex items-center gap-3">

                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs text-white font-medium" style={{ background: '#1890ff' }}>3</div>

                      <div className="flex-1">

                        <p className="text-sm font-medium">内部公示</p>

                        <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>已同步更新供应商状态，对外公示中</p>

                      </div>

                      <span className="tag tag-blue text-xs">进行中</span>

                    </div>

                  </div>

                </div>

              )}

            </div>

            <div className="sticky bottom-0 flex items-center justify-end gap-3 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>

              <button className="btn-default" onClick={() => setPenaltyDrawerOpen(false)}>{penaltyEditMode === 'view' ? '关闭' : '取消'}</button>

              {penaltyEditMode !== 'view' && (

                <button className="btn-primary">保存</button>

              )}

            </div>

          </div>
        </div>
      )}

      {/* Penalty Delete Confirmation Modal */}

      {penaltyDeleteOpen && (

        <div className="fixed inset-0 z-[60] flex items-center justify-center">

          <div className="absolute inset-0 bg-black/40" onClick={() => setPenaltyDeleteOpen(false)} />

          <div className="relative bg-white rounded-xl shadow-2xl w-96 p-6 animate-in fade-in zoom-in duration-200">

            <div className="flex items-center gap-3 mb-4">

              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>

                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>

              </div>

              <h3 className="text-base font-semibold">确认删除</h3>

            </div>

            <p className="text-sm mb-6" style={{ color: 'var(--text-secondary)' }}>是否确认删除处罚记录"<span className="font-medium">{selectedPenalty?.id}</span>"？删除后数据将无法恢复，请谨慎操作。</p>
            <div className="flex items-center justify-end gap-3">
              <button className="btn-default" onClick={() => setPenaltyDeleteOpen(false)}>取消</button>
              <button className="btn-danger" onClick={confirmDeletePenalty}>确认删除</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉登记 Modal ═══════════ */}

      {complaintModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center" onClick={() => setTargetSearchOpen(false)}>
          <div className="absolute inset-0 bg-black/40" onClick={() => setComplaintModalOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">投诉登记</h3>
              <button onClick={() => setComplaintModalOpen(false)} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉人</label>
                <input value={currentUser.name} readOnly className="form-input w-full bg-gray-50 text-gray-500" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属机构</label>
                <input value={currentUser.org} readOnly className="form-input w-full bg-gray-50 text-gray-500" />
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉类型</label>
                <select value={complaintForm.targetType} onChange={e => setComplaintForm({ ...complaintForm, targetType: e.target.value })} className="form-input w-full">
                  <option>供应商</option>
                  <option>维修人员</option>
                  <option>产品质量</option>
                  <option>服务态度</option>
                </select>
              </div>
              <div className="relative">
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉对象 <span className="text-red-400">*</span></label>
                <input
                  value={targetSearchText || complaintForm.targetName}
                  onChange={e => {
                    const val = e.target.value
                    setTargetSearchText(val)
                    setComplaintForm(prev => ({ ...prev, targetName: val, complainant: currentUser.name, org: currentUser.org }))
                    setTargetSearchOpen(!!val)
                  }}
                  onFocus={() => { if ((targetSearchText || complaintForm.targetName).length >= 1) setTargetSearchOpen(true) }}
                  className="form-input w-full"
                  placeholder="输入投诉对象名称搜索..."
                />
                {targetSearchOpen && (
                  <div className="absolute top-full left-0 right-0 mt-1 rounded-lg border shadow-lg z-50 max-h-[200px] overflow-y-auto" style={{ background: '#fff', borderColor: 'var(--border-color)' }}>
                    {complaintTargets
                      .filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase()))
                      .map(t => (
                        <button
                          key={t}
                          className="w-full text-left px-3 py-2 text-sm hover:bg-blue-50 transition-colors"
                          onClick={() => {
                            setComplaintForm(prev => ({ ...prev, targetName: t, complainant: currentUser.name, org: currentUser.org }))
                            setTargetSearchText(t)
                            setTargetSearchOpen(false)
                          }}
                        >
                          {t}
                        </button>
                      ))}
                    {complaintTargets.filter(t => t.toLowerCase().includes((targetSearchText || complaintForm.targetName).toLowerCase())).length === 0 && (
                      <div className="px-3 py-2 text-sm" style={{ color: 'var(--text-disabled)' }}>无匹配数据</div>
                    )}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>投诉内容 <span className="text-red-400">*</span></label>
                <textarea value={complaintForm.content} onChange={e => setComplaintForm({ ...complaintForm, content: e.target.value })} rows={3} className="form-input w-full" placeholder="请描述投诉内容..." />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setComplaintModalOpen(false)} className="btn-default">取消</button>
              <button onClick={addComplaint} className="btn-danger">提交投诉</button>
            </div>
          </div>
        </div>
      )}

      {/* ═══════════ 投诉回复 Modal ═══════════ */}

      {replyOpen && replyComplaint && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">投诉处理 - {replyComplaint.id}</h3>
              <button onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} className="p-1 rounded-lg hover:bg-gray-100">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
              </button>
            </div>
            <div className="mb-4 p-3 rounded text-sm" style={{ background: '#f5f5f5' }}>
              <div><span style={{ color: 'var(--text-secondary)' }}>投诉人：</span>{replyComplaint.complainant} / {replyComplaint.org}</div>
              <div><span style={{ color: 'var(--text-secondary)' }}>投诉对象：</span>{replyComplaint.targetName}</div>
              <div className="mt-1"><span style={{ color: 'var(--text-secondary)' }}>内容：</span>{replyComplaint.content}</div>
            </div>
            {replyComplaint.reply ? (
              <div className="p-3 rounded" style={{ background: '#f6ffed', border: '1px solid #b7eb8f' }}>
                <span style={{ color: '#52c41a' }} className="font-medium text-sm">已回复：</span>
                <p className="text-sm mt-1">{replyComplaint.reply}</p>
              </div>
            ) : (
              <div>
                <label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>处理回复 <span className="text-red-400">*</span></label>
                <textarea value={replyContent} onChange={e => setReplyContent(e.target.value)} rows={4} className="form-input w-full" placeholder="请填写处理意见..." />
              </div>
            )}
            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => { setReplyOpen(false); setReplyContent(''); setReplyComplaint(null) }} className="btn-default">
                {replyComplaint.reply ? '关闭' : '取消'}
              </button>
              {!replyComplaint.reply && (
                <button onClick={submitReply} className="btn-primary">提交回复</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}