import { useState, useEffect } from 'react'
import ReactECharts from 'echarts-for-react'

interface DashboardProps {
  onNavigate?: (module: string, subTab?: string) => void
}

function AnimatedNumber({ value, duration = 1500 }: { value: number; duration?: number }) {
  const [display, setDisplay] = useState(0)
  useEffect(() => {
    const start = performance.now()
    const animate = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      setDisplay(Math.floor((1 - Math.pow(1 - progress, 3)) * value))
      if (progress < 1) requestAnimationFrame(animate)
    }
    requestAnimationFrame(animate)
  }, [value, duration])
  return <span>{display.toLocaleString()}</span>
}

/* ================================================================
   业务流水数据
   ================================================================ */
type BizType = '全部' | '出库' | '入库' | '领用' | '盘点' | '报修' | '报废'

const bizColors: Record<BizType, string> = {
  '全部': '#666666',
  '出库': '#1890ff', '入库': '#52c41a', '领用': '#722ed1',
  '盘点': '#13c2c2', '报修': '#faad14', '报废': '#ff4d4f',
}

interface BizRecord {
  type: BizType
  no: string
  applicant: string
  status: string
  time: string
}

const bizRecords: Record<BizType, BizRecord[]> = {
  '全部': [
    { type: '出库', no: 'LY2024001', applicant: '张建国/刑警支队', status: '已出库', time: '2024-03-15 09:30' },
    { type: '入库', no: 'RK20240301', applicant: '张建国/省厅装备处', status: '已入库', time: '2024-03-14 09:00' },
    { type: '领用', no: 'LY2024005', applicant: '王志强/特警支队', status: '已领用', time: '2024-03-15 08:30' },
    { type: '盘点', no: 'PD20240301', applicant: '马为民/资产管理组', status: '已完成', time: '2024-03-14 09:00' },
    { type: '报修', no: 'BX2024001', applicant: '郑国强/设备维护组', status: '维修中', time: '2024-03-15 08:15' },
    { type: '报废', no: 'BF2024001', applicant: '马为民/资产管理组', status: '已报废', time: '2024-03-14 10:00' },
  ],
  '出库': [
    { type: '出库', no: 'LY2024001', applicant: '张建国/刑警支队', status: '已出库', time: '2024-03-15 09:30' },
    { type: '出库', no: 'PF2024002', applicant: '陈晓东/装备调配中心', status: '已出库', time: '2024-03-15 10:15' },
    { type: '出库', no: 'DB2024001', applicant: '周文博/仓库管理组', status: '出库中', time: '2024-03-15 11:00' },
    { type: '出库', no: 'BXCK2024001', applicant: '郑国强/设备维护组', status: '待出库', time: '2024-03-15 14:20' },
    { type: '出库', no: 'JJ2024001', applicant: '黄志勇/指挥中心', status: '已出库', time: '2024-03-15 08:00' },
  ],
  '入库': [
    { type: '入库', no: 'RK20240301', applicant: '张建国/省厅装备处', status: '已入库', time: '2024-03-14 09:00' },
    { type: '入库', no: 'RK20240302', applicant: '李卫国/市局限装备仓库', status: '已入库', time: '2024-03-14 10:30' },
    { type: '入库', no: 'RK20240303', applicant: '王志强/区县装备室', status: '入库中', time: '2024-03-14 11:15' },
    { type: '入库', no: 'RK20240304', applicant: '赵明华/交警大队', status: '待验收', time: '2024-03-14 14:00' },
    { type: '入库', no: 'RK20240305', applicant: '陈晓东/网安支队', status: '已入库', time: '2024-03-14 16:45' },
  ],
  '领用': [
    { type: '领用', no: 'LY2024005', applicant: '王志强/特警支队', status: '已领用', time: '2024-03-15 08:30' },
    { type: '领用', no: 'LY2024006', applicant: '赵明华/交警大队', status: '审批中', time: '2024-03-15 09:45' },
    { type: '领用', no: 'LY2024007', applicant: '陈晓东/网安支队', status: '已领用', time: '2024-03-15 13:20' },
    { type: '领用', no: 'LY2024008', applicant: '刘建华/巡警支队', status: '待审批', time: '2024-03-15 15:00' },
    { type: '领用', no: 'LY2024009', applicant: '孙德胜/审计处', status: '已领用', time: '2024-03-15 16:30' },
  ],
  '盘点': [
    { type: '盘点', no: 'PD20240301', applicant: '马为民/资产管理组', status: '已完成', time: '2024-03-14 09:00' },
    { type: '盘点', no: 'PD20240302', applicant: '黄志勇/指挥中心', status: '盘点中', time: '2024-03-14 10:00' },
    { type: '盘点', no: 'PD20240303', applicant: '周丽华/审计处', status: '已完成', time: '2024-03-14 14:30' },
    { type: '盘点', no: 'PD20240304', applicant: '吴天明/督查室', status: '已完成', time: '2024-03-14 16:00' },
    { type: '盘点', no: 'PD20240305', applicant: '王建国/刑警支队', status: '待盘点', time: '2024-03-15 09:00' },
  ],
  '报修': [
    { type: '报修', no: 'BX2024001', applicant: '郑国强/设备维护组', status: '维修中', time: '2024-03-15 08:15' },
    { type: '报修', no: 'BX2024002', applicant: '孙德胜/技术保障组', status: '待审批', time: '2024-03-15 09:30' },
    { type: '报修', no: 'BX2024003', applicant: '马为民/资产管理组', status: '已完成', time: '2024-03-15 11:00' },
    { type: '报修', no: 'BX2024004', applicant: '黄志勇/指挥中心', status: '维修中', time: '2024-03-15 13:45' },
    { type: '报修', no: 'BX2024005', applicant: '周丽华/审计处', status: '待审批', time: '2024-03-15 15:20' },
  ],
  '报废': [
    { type: '报废', no: 'BF2024001', applicant: '马为民/资产管理组', status: '已报废', time: '2024-03-14 10:00' },
    { type: '报废', no: 'BF2024002', applicant: '黄志勇/指挥中心', status: '审批中', time: '2024-03-14 11:30' },
    { type: '报废', no: 'BF2024003', applicant: '赵明华/交警大队', status: '待出库', time: '2024-03-14 14:00' },
    { type: '报废', no: 'BF2024004', applicant: '周丽华/审计处', status: '已报废', time: '2024-03-14 16:30' },
    { type: '报废', no: 'BF2024005', applicant: '吴天明/督查室', status: '审批中', time: '2024-03-15 09:15' },
  ],
}

/* ================================================================
   预警记录数据
   ================================================================ */
const warningRecords = [
  { name: '手持终端 XT-2000', detail: '库存低于安全线（当前15件，安全库存25件）', time: '10:30', level: 'warning' },
  { name: '防弹背心 FDY-3R', detail: '库存即将耗尽（当前3件，安全库存10件）', time: '09:45', level: 'danger' },
  { name: '对讲机 PD780G', detail: '库存低于预设值（当前8件，安全库存20件）', time: '09:15', level: 'warning' },
  { name: '应急照明灯 YD-100', detail: '库存补充提醒（当前12件，安全库存15件）', time: '08:50', level: 'remind' },
  { name: '执法记录仪 DSJ-A7', detail: '即将过质保期（剩余30天）', time: '11:00', level: 'warning' },
  { name: '手持终端 XT-2000', detail: '连续超期未归还（已超期15天）', time: '10:15', level: 'danger' },
  { name: '战术头盔 MICH-2000', detail: '保养周期到期（剩余7天）', time: '08:20', level: 'remind' },
  { name: '防暴盾牌 FB-P', detail: '检测到异常出库（昨日出库10件）', time: '09:30', level: 'warning' },
]

const levelMap: Record<string, { label: string; color: string; bg: string }> = {
  warning: { label: '警告', color: '#faad14', bg: '#fffbe6' },
  danger: { label: '紧急', color: '#ff4d4f', bg: '#fff2f0' },
  remind: { label: '提醒', color: '#1890ff', bg: '#e6f7ff' },
}

/* ================================================================
   图表配置
   ================================================================ */
function getPieOption() {
  return {
    tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
    legend: { orient: 'vertical', right: 10, top: 'center', textStyle: { fontSize: 12 } },
    series: [{
      type: 'pie', radius: ['40%', '70%'], center: ['35%', '50%'],
      avoidLabelOverlap: true,
      itemStyle: { borderRadius: 6, borderColor: '#fff', borderWidth: 2 },
      label: { show: true, formatter: '{d}%', fontSize: 11 },
      emphasis: { label: { show: true, fontSize: 14, fontWeight: 'bold' } },
      data: [
        { value: 70304, name: '在用', itemStyle: { color: '#52c41a' } },
        { value: 46869, name: '库存', itemStyle: { color: '#1890ff' } },
        { value: 18748, name: '维修中', itemStyle: { color: '#faad14' } },
        { value: 12498, name: '报废', itemStyle: { color: '#ff4d4f' } },
        { value: 7811, name: '调拨中', itemStyle: { color: '#722ed1' } },
      ],
    }],
  }
}

function getBarOption() {
  return {
    tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
    grid: { left: '3%', right: '4%', bottom: '3%', top: '10%', containLabel: true },
    xAxis: { type: 'category', data: ['通信装备', '执法装备', '防护装备', '照明设备', '交通工具', '医疗装备', '警械'], axisLabel: { fontSize: 10, rotate: 20 } },
    yAxis: { type: 'value', axisLabel: { fontSize: 10 } },
    series: [{
      type: 'bar', barWidth: '50%',
      itemStyle: { color: '#1890ff', borderRadius: [4, 4, 0, 0] },
      data: [
        { value: 32500, itemStyle: { color: '#1890ff' } },
        { value: 28900, itemStyle: { color: '#52c41a' } },
        { value: 19800, itemStyle: { color: '#722ed1' } },
        { value: 15200, itemStyle: { color: '#faad14' } },
        { value: 12100, itemStyle: { color: '#13c2c2' } },
        { value: 8600, itemStyle: { color: '#eb2f96' } },
        { value: 6850, itemStyle: { color: '#ff4d4f' } },
      ],
    }],
  }
}

function getHorizontalBarOption() {
  return {
    tooltip: { trigger: 'axis', formatter: '{b}: {c}%' },
    grid: { left: '3%', right: '15%', bottom: '3%', top: '5%', containLabel: true },
    xAxis: { type: 'value', max: 100, axisLabel: { formatter: '{value}%', fontSize: 10 } },
    yAxis: { type: 'category', data: ['警械', '医疗装备', '交通工具', '照明设备', '防护装备', '执法装备', '通信装备'], axisLabel: { fontSize: 10 } },
    series: [{
      type: 'bar', barWidth: '55%',
      itemStyle: {
        borderRadius: [0, 4, 4, 0],
        color: (params: any) => {
          const colors = ['#ff4d4f', '#eb2f96', '#13c2c2', '#faad14', '#722ed1', '#52c41a', '#1890ff']
          return colors[params.dataIndex] || '#1890ff'
        },
      },
      label: { show: true, position: 'right', formatter: '{c}%', fontSize: 10 },
      data: [45, 52, 58, 65, 72, 80, 88],
    }],
  }
}

/* ================================================================
   主组件
   ================================================================ */
export default function DashboardPage({ onNavigate }: DashboardProps) {
  const commonFunctions = [
    { label: '装备采购管理', icon: 'M3 3h18v18H3V3zm16 16V5H5v14h14zM7 7h4v4H7V7zm0 6h4v4H7v-4zm6-6h4v4h-4V7zm0 6h4v4h-4v-4z', color: '#1890ff', onClick: () => onNavigate?.('procurement') },
    { label: '仓库管理', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z', color: '#52c41a', onClick: () => onNavigate?.('warehouse-mgmt') },
    { label: '装备领用', icon: 'M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z', color: '#722ed1', onClick: () => onNavigate?.('equip-borrow') },
    { label: '报修管理', icon: 'M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z', color: '#faad14', onClick: () => onNavigate?.('repair') },
    { label: '装备研判分析', icon: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 002 2h2a2 2 0 002-2v-6', color: '#13c2c2', onClick: () => onNavigate?.('analysis') },
    { label: '系统管理', icon: 'M12 2a10 10 0 100 20 10 10 0 000-20zm0 18a8 8 0 110-16 8 8 0 010 16zm0-14a4 4 0 100 8 4 4 0 000-8z', color: '#eb2f96', onClick: () => onNavigate?.('system') },
  ]

  // 实时数据
  const statCards = [
    { label: '全省装备数量', value: 156230, unit: '件', color: '#1890ff', bg: '#e6f7ff', icon: 'M20 6h-4V4c0-1.11-.89-2-2-2h-4c-1.11 0-2 .89-2 2v2H4c-1.11 0-1.99.89-1.99 2L2 19c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-6 0h-4V4h4v2z' },
    { label: '全省应急装备数量', value: 28356, unit: '件', color: '#52c41a', bg: '#f6ffed', icon: 'M12 2L2 7v10c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V7l-10-5z' },
    { label: '供应商数量', value: 156, unit: '家', color: '#722ed1', bg: '#f9f0ff', icon: 'M21 16V8a2 2 0 00-1-1.73l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.73l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z' },
    { label: '商品数量', value: 3680, unit: '种', color: '#eb2f96', bg: '#fff0f6', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
  ]

  // 调拨审批待办
  const transferApprovals = [
    { from: '省厅主仓库', to: '市局限装备仓库', equip: '手持终端 XT-2000', qty: 5, applicant: '张建国', unit: '刑警支队', module: 'emergency' },
    { from: '市局限装备仓库', to: '区县装备室', equip: '防弹背心 FDY-3R', qty: 3, applicant: '李强', unit: '治安支队', module: 'emergency' },
    { from: '省厅主仓库', to: '市局限装备仓库', equip: '执法记录仪 DSJ-A7', qty: 2, applicant: '王志强', unit: '特警支队', module: 'emergency' },
  ]

  // 业务记录
  const bizTabs: BizType[] = ['全部', '出库', '入库', '领用', '盘点', '报修', '报废']
  const [activeBizTab, setActiveBizTab] = useState<BizType>('全部')

  const statusTagMap: Record<string, string> = {
    '已出库': 'tag-green', '已入库': 'tag-green', '已领用': 'tag-green', '已完成': 'tag-green', '已报废': 'tag-green',
    '出库中': 'tag-orange', '入库中': 'tag-orange', '维修中': 'tag-orange', '审批中': 'tag-purple',
    '待出库': 'tag-yellow', '待验收': 'tag-yellow', '待审批': 'tag-yellow', '待盘点': 'tag-yellow', '待处理': 'tag-yellow',
  }

  return (
    <div className="p-4 space-y-4">
      {/* ============ 常用功能 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>常用功能</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {commonFunctions.map(item => (
            <button
              key={item.label}
              onClick={item.onClick || (() => alert('功能开发中...'))}
              className="content-card p-4 flex flex-col items-center gap-3 hover:shadow-md transition-all cursor-pointer group"
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110" style={{ background: `${item.color}15` }}>
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={item.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d={item.icon} /></svg>
              </div>
              <span className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{item.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* ============ 实时数据展示 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>实时数据展示</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {statCards.map(card => (
            <div key={card.label} className="content-card p-5 flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0" style={{ background: card.bg }}>
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke={card.color} strokeWidth="1.5"><path d={card.icon} /></svg>
              </div>
              <div>
                <div className="text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>{card.label}</div>
                <div className="text-2xl font-bold" style={{ color: card.color }}><AnimatedNumber value={card.value} /></div>
                <div className="text-xs" style={{ color: 'var(--text-disabled)' }}>{card.unit}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ============ 实时业务展示 + 待办事项 + 预警记录（同一行） ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>实时业务展示</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 业务记录 */}
          <div className="content-card p-4">
            <div className="flex gap-1 border-b mb-3" style={{ borderColor: 'var(--border-color)' }}>
              {bizTabs.map(tab => (
                <button
                  key={tab}
                  className={activeBizTab === tab
                    ? 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--primary-blue)]'
                    : 'relative px-3 py-2 text-xs font-medium transition-colors text-[var(--text-secondary)] hover:text-[var(--text-primary)]'
                  }
                  onClick={() => setActiveBizTab(tab)}
                >
                  {tab}
                  {activeBizTab === tab && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 rounded-t-full" style={{ background: 'var(--primary-blue)' }} />
                  )}
                </button>
              ))}
            </div>
            <div className="space-y-2">
              {bizRecords[activeBizTab].map((r, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-lg border" style={{ borderColor: 'var(--border-color)' }}>
                  <div className="flex items-center gap-2 min-w-0">
                    <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: bizColors[r.type] }} />
                    <div>
                      <div className="flex items-center gap-1">
                        <span className="text-xs font-mono font-medium" style={{ color: 'var(--primary-blue)' }}>{r.no}</span>
                        <span className="text-xs px-1 py-0.5 rounded" style={{ background: bizColors[r.type] + '15', color: bizColors[r.type] }}>{r.type}</span>
                      </div>
                      <div className="text-xs mt-0.5" style={{ color: 'var(--text-secondary)' }}>{r.applicant}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className={'tag text-xs ' + (statusTagMap[r.status] || 'tag-gray')}>{r.status}</span>
                    <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{r.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 调拨审批 */}
          <div className="content-card p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold">调拨审批</h3>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: '#fff2f0', color: '#ff4d4f' }}>{transferApprovals.length} 条待处理</span>
            </div>
            <div className="space-y-2">
              {transferApprovals.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => onNavigate?.(item.module, 'transfer')}
                  className="p-3 rounded-lg border cursor-pointer hover:border-blue-300 hover:shadow-sm transition-all"
                  style={{ borderColor: 'var(--border-color)' }}
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5 text-xs">
                      <span className="font-medium">{item.from}</span>
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#8c8c8c" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                      <span className="font-medium" style={{ color: '#1890ff' }}>{item.to}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: '#fffbe6', color: '#faad14' }}>待审批</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                      <span>{item.equip}</span>
                      <span className="mx-1">x</span>
                      <span className="font-mono font-medium">{item.qty}</span>
                    </div>
                    <div className="text-[10px]" style={{ color: 'var(--text-disabled)' }}>
                      {item.applicant} / {item.unit}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 预警记录 */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-3">预警记录</h3>
            <div className="space-y-2">
              {warningRecords.map((item, i) => {
                const l = levelMap[item.level]
                return (
                  <div key={i} className="flex items-center justify-between p-2 rounded-lg" style={{ background: l.bg }}>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs font-medium">{item.name}</div>
                      <div className="text-xs" style={{ color: 'var(--text-secondary)' }}>{item.detail}</div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                      <span className="text-xs" style={{ color: 'var(--text-disabled)' }}>{item.time}</span>
                      <span className="px-1.5 py-0.5 rounded text-xs" style={{ background: '#fff', color: l.color, border: `1px solid ${l.color}` }}>{l.label}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>

      {/* ============ 统计分析 ============ */}
      <div>
        <h2 className="text-base font-semibold mb-3" style={{ color: 'var(--text-primary)' }}>统计分析</h2>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* 装备状态分布（饼图） */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-2">装备状态分布</h3>
            <ReactECharts option={getPieOption()} style={{ height: 260 }} />
          </div>
          {/* 品类库存构成（柱状图） */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-2">品类库存构成</h3>
            <ReactECharts option={getBarOption()} style={{ height: 260 }} />
          </div>
          {/* 装备品类使用率（横道图） */}
          <div className="content-card p-4">
            <h3 className="text-sm font-semibold mb-2">装备品类使用率</h3>
            <ReactECharts option={getHorizontalBarOption()} style={{ height: 260 }} />
          </div>
        </div>
      </div>
    </div>
  )
}
