import { useState } from 'react'
import TagBadges, { RfidDisplay } from '../components/TagBadges'
import RfidList from '../components/RfidList'
import WarehouseTreeSelect from '../components/WarehouseTreeSelect'
import { warehouseData } from '../pages/InboundPage'

interface Props {
  onNavigate?: (module: string, subTab?: string) => void
}

type EquipStatus = 'in_stock' | 'borrowed' | 'repairing'

interface InventoryItem {
  rfidCode: string
  tags: string[]
  name: string
  category: string
  spec: string
  qty: number
  remainQty: number
  unit: string
  isBox: boolean
  boxSpec: string
  location: string
  produceDate: string
  validDate: string
  maintainPeriod: string
  price: number
  total: number
  equipCode: string
  supplier: string
  status: EquipStatus
  lastTime: string
  individualRFIDs?: string[]
}

const statusConfig: Record<EquipStatus, { label: string; color: string; bg: string; border: string }> = {
  in_stock: { label: '在库', color: '#52c41a', bg: '#f6ffed', border: '#b7eb8f' },
  borrowed: { label: '领用', color: '#1890ff', bg: '#e6f7ff', border: '#91d5ff' },
  repairing: { label: '维修', color: '#faad14', bg: '#fffbe6', border: '#ffe58f' },
}

const inventoryData: InventoryItem[] = [
  { rfidCode: '10101P0010012024031505001XXXXXX0001',
    tags: ['品类特征/贵重仪器'], name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色/128G', qty: 50, remainQty: 45, unit: '台', isBox: false, boxSpec: '', location: '省厅主仓库 A区-01-03', produceDate: '2024-01-15', validDate: '2027-01-15', maintainPeriod: '3个月', price: 3200, total: 160000, equipCode: '0101P00100', supplier: '华为技术有限公司', status: 'in_stock', lastTime: '2024-03-15 09:30:00' },
  { rfidCode: '10101P0020012024040105002XXXXXX0003',
    tags: ['状态类/临期30天'], name: '执法记录仪 DSJ-A7', category: '执法设备', spec: 'DSJ-A7/64G/防水', qty: 30, remainQty: 8, unit: '台', isBox: false, boxSpec: '', location: '省厅主仓库 A区-02-01', produceDate: '2024-02-20', validDate: '2027-02-20', maintainPeriod: '6个月', price: 1800, total: 54000, equipCode: '0101P00200', supplier: '海康威视数字技术股份有限公司', status: 'borrowed', lastTime: '2024-03-14 16:45:00' },
  { rfidCode: '10101P0050012024031505002XXXXXX0002',
    tags: ['活动类/双11备货'], name: '对讲机 PD780G', category: '通信设备', spec: 'PD780G/U段/数字', qty: 100, remainQty: 38, unit: '台', isBox: false, boxSpec: '', location: '市局限装备仓库 B区-01-05', produceDate: '2024-01-20', validDate: '2027-01-20', maintainPeriod: '3个月', price: 1200, total: 120000, equipCode: '0101P00500', supplier: '烽火通信科技股份有限公司', status: 'in_stock', lastTime: '2024-03-14 10:20:00' },
  { rfidCode: '10101P0030012024021010003XXXXXX0003',
    tags: ['品类特征/易碎品'], name: '防弹背心 FDY-3R', category: '防护装备', spec: 'FDY-3R/三级/均码', qty: 20, remainQty: 3, unit: '件', isBox: false, boxSpec: '', location: '省厅主仓库 C区-01-02', produceDate: '2023-11-10', validDate: '2028-11-10', maintainPeriod: '12个月', price: 2800, total: 56000, equipCode: '0101P00300', supplier: '华为技术有限公司', status: 'repairing', lastTime: '2024-03-13 08:00:00' },
  { rfidCode: '10101P0040012024011510004XXXXXX0004',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], name: '战术头盔 MICH-2000', category: '防护装备', spec: 'MICH-2000/L号/凯夫拉', qty: 40, remainQty: 25, unit: '顶', isBox: false, boxSpec: '', location: '区县装备室 D区-01-01', produceDate: '2023-12-05', validDate: '2028-12-05', maintainPeriod: '12个月', price: 1500, total: 60000, equipCode: '0101P00400', supplier: '中兴通讯股份有限公司', status: 'in_stock', lastTime: '2024-03-12 14:10:00' },
  { rfidCode: '10101P0060012024022010005XXXXXX0005',
    tags: ['品类特征/贵重仪器'], name: '应急照明灯 YD-100', category: '照明设备', spec: 'YD-100/LED/充电', qty: 60, remainQty: 60, unit: '台', isBox: false, boxSpec: '', location: '省厅主仓库 A区-03-04', produceDate: '2024-01-25', validDate: '2026-01-25', maintainPeriod: '6个月', price: 680, total: 40800, equipCode: '0101P00600', supplier: '海康威视数字技术股份有限公司', status: 'in_stock', lastTime: '2024-03-09 15:00:00' },
  { rfidCode: '10101P0070012024031005006XXXXXX0006',
    tags: ['状态类/临期30天'], name: '防弹盾牌 FDP-3S', category: '防护装备', spec: 'FDP-3S/三级/透明', qty: 15, remainQty: 5, unit: '面', isBox: false, boxSpec: '', location: '区县装备室 D区-02-03', produceDate: '2024-03-01', validDate: '2029-03-01', maintainPeriod: '12个月', price: 2200, total: 33000, equipCode: '0101P00700', supplier: '华为技术有限公司', status: 'borrowed', lastTime: '2024-03-08 09:45:00' },
  { rfidCode: '10101P0080012024012010007XXXXXX0007',
    tags: ['活动类/双11备货'], name: '催泪喷射器 CL-200', category: '执法设备', spec: 'CL-200/200ml/手持', qty: 100, remainQty: 100, unit: '支', isBox: false, boxSpec: '', location: '省厅主仓库 A区-04-01', produceDate: '2024-01-10', validDate: '2026-01-10', maintainPeriod: '3个月', price: 150, total: 15000, equipCode: '0101P00800', supplier: '大华技术股份有限公司', status: 'in_stock', lastTime: '2024-03-07 16:20:00' },
  { rfidCode: '10101P0010012024031505001XXXXXX0001',
    tags: ['品类特征/易碎品'], name: '手持终端 XT-2000', category: '通信设备', spec: 'XT-2000/黑色/128G', qty: 30, remainQty: 12, unit: '台', isBox: false, boxSpec: '', location: '市局限装备仓库 B区-02-04', produceDate: '2024-02-01', validDate: '2027-02-01', maintainPeriod: '3个月', price: 3200, total: 96000, equipCode: '0101P00100', supplier: '华为技术有限公司', status: 'in_stock', lastTime: '2024-03-06 11:00:00' },
  { rfidCode: '10101P0090012024021005008XXXXXX0008',
    tags: ['状态类/临期30天', '品类特征/贵重仪器'], name: '强光手电 QG-500', category: '照明设备', spec: 'QG-500/充电款', qty: 200, remainQty: 180, unit: '支', isBox: false, boxSpec: '', location: '市局限装备仓库 B区-03-01', produceDate: '2024-02-15', validDate: '2027-02-15', maintainPeriod: '3个月', price: 280, total: 56000, equipCode: '0101P00900', supplier: '烽火通信科技股份有限公司', status: 'in_stock', lastTime: '2024-03-05 14:30:00' },
]

const tabList: { key: string; label: string }[] = [
  { key: 'all', label: '全部' },
  { key: 'in_stock', label: '在库' },
  { key: 'borrowed', label: '领用' },
  { key: 'repairing', label: '维修' },
]

const warehouses = warehouseData.filter(w => !w.parent).map(w => w.name)

export default function InventoryPage({ onNavigate }: Props) {
  const [data, setData] = useState<InventoryItem[]>(inventoryData)
  const [searchName, setSearchName] = useState('')
  const [searchRfid, setSearchRfid] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [filterWarehouse, setFilterWarehouse] = useState('all')
  const [activeTab, setActiveTab] = useState('all')

  // Detail modal
  const [detailOpen, setDetailOpen] = useState(false)
  const [detailItem, setDetailItem] = useState<InventoryItem | null>(null)

  // Edit modal
  const [editOpen, setEditOpen] = useState(false)
  const [editItem, setEditItem] = useState<InventoryItem | null>(null)
  const [editLocation, setEditLocation] = useState('')
  const [editRemark, setEditRemark] = useState('')

  // Transfer modal
  const [transferOpen, setTransferOpen] = useState(false)
  const [transferItem, setTransferItem] = useState<InventoryItem | null>(null)
  const [transferTo, setTransferTo] = useState('')
  const [transferLoc, setTransferLoc] = useState('')

  // Scrap modal
  const [scrapOpen, setScrapOpen] = useState(false)
  const [scrapItem, setScrapItem] = useState<InventoryItem | null>(null)
  const [scrapReason, setScrapReason] = useState('')
  const [scrapOperator, setScrapOperator] = useState('')

  // Repair modal
  const [repairOpen, setRepairOpen] = useState(false)
  const [repairItem, setRepairItem] = useState<InventoryItem | null>(null)
  const [repairDesc, setRepairDesc] = useState('')
  const [repairOperator, setRepairOperator] = useState('')

  const filtered = data.filter(item => {
    if (searchName && !item.name.includes(searchName)) return false
    if (searchRfid && !item.rfidCode.includes(searchRfid)) return false
    if (filterStatus !== 'all' && item.status !== filterStatus) return false
    if (filterWarehouse !== 'all' && !item.location.includes(filterWarehouse)) return false
    if (activeTab !== 'all' && item.status !== activeTab) return false
    return true
  })

  const inStock = data.filter(d => d.status === 'in_stock').length
  const borrowed = data.filter(d => d.status === 'borrowed').length
  const repairing = data.filter(d => d.status === 'repairing').length
  const totalQty = data.reduce((s, d) => s + d.qty, 0)

  const getActions = (item: InventoryItem) => {
    const base = ['打印', '详情']
    switch (item.status) {
      case 'in_stock': return ['打印', '修改', '报废', '调库', '报修', '详情']
      case 'borrowed': return ['打印', '详情']
      case 'repairing': return ['打印', '详情']
      default: return base
    }
  }

  const openDetail = (item: InventoryItem) => { setDetailItem(item); setDetailOpen(true) }
  const openEdit = (item: InventoryItem) => { setEditItem(item); setEditLocation(item.location); setEditRemark(''); setEditOpen(true) }
  const openTransfer = (item: InventoryItem) => { setTransferItem(item); setTransferTo(''); setTransferLoc(''); setTransferOpen(true) }
  const openScrap = (item: InventoryItem) => { setScrapItem(item); setScrapReason(''); setScrapOperator(''); setScrapOpen(true) }
  const openRepair = (item: InventoryItem) => { setRepairItem(item); setRepairDesc(''); setRepairOperator(''); setRepairOpen(true) }

  const handleEditSave = () => {
    if (!editItem) return
    setData(prev => prev.map(d => d.rfidCode === editItem.rfidCode && d.location === editItem.location ? { ...d, location: editLocation } : d))
    setEditOpen(false)
    alert('修改已保存')
  }

  const handleTransfer = () => {
    if (!transferItem || !transferTo) { alert('请选择目标仓库'); return }
    const newLoc = transferLoc ? `${transferTo} ${transferLoc}` : transferTo
    setData(prev => prev.map(d => d.rfidCode === transferItem.rfidCode && d.location === transferItem.location ? { ...d, location: newLoc, lastTime: new Date().toLocaleString('zh-CN', { hour12: false }) } : d))
    setTransferOpen(false)
    alert(`调库完成：${transferItem.name} → ${newLoc}`)
  }

  const handleScrap = () => {
    if (!scrapItem || !scrapReason.trim()) { alert('请输入报废原因'); return }
    setData(prev => prev.filter(d => !(d.rfidCode === scrapItem.rfidCode && d.location === scrapItem.location)))
    setScrapOpen(false)
    alert(`报废申请已提交：${scrapItem.name}，原因：${scrapReason}`)
  }

  const handleRepair = () => {
    if (!repairItem || !repairDesc.trim()) { alert('请输入报修说明'); return }
    setData(prev => prev.map(d => d.rfidCode === repairItem.rfidCode && d.location === repairItem.location ? { ...d, status: 'repairing', lastTime: new Date().toLocaleString('zh-CN', { hour12: false }) } : d))
    setRepairOpen(false)
    alert(`报修申请已提交：${repairItem.name}，说明：${repairDesc}`)
  }

  const handlePrint = (item: InventoryItem) => {
    alert(`打印标签：${item.name}（${item.rfidCode}）`)
  }

  return (
    <div className="p-6 space-y-4">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm pb-1">
        <button className="flex items-center gap-1 hover:underline" style={{ color: 'var(--primary-blue)' }} onClick={() => onNavigate?.('dashboard')}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg>返回工作台
        </button>
        <span style={{ color: 'var(--text-disabled)' }}>/</span>
        <span style={{ color: 'var(--text-secondary)' }}>库存明细</span>
      </div>

      {/* Search */}
      <div className="content-card p-4">
        <div className="flex flex-wrap items-end gap-3">
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-32" placeholder="请输入..." value={searchName} onChange={e => setSearchName(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>RFID编码</label><input className="form-input w-36" placeholder="请输入RFID编码..." value={searchRfid} onChange={e => setSearchRfid(e.target.value)} /></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>状态</label><select className="form-input w-24" value={filterStatus} onChange={e => { setFilterStatus(e.target.value); setActiveTab(e.target.value) }}><option value="all">全部</option><option value="in_stock">在库</option><option value="borrowed">领用</option><option value="repairing">维修</option></select></div>
          <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>所属库室</label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={filterWarehouse} onChange={setFilterWarehouse} mode="name" showAll allValue="all" className="w-32" /></div>
          <div className="flex gap-2 ml-auto"><button className="btn-default" onClick={() => { setSearchName(''); setSearchRfid(''); setFilterStatus('all'); setFilterWarehouse('all'); setActiveTab('all') }}>重置</button><button className="btn-primary">查询</button></div>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-4 gap-4">
        {[
          { label: '在库', value: inStock, color: '#52c41a', bg: '#f6ffed' },
          { label: '领用', value: borrowed, color: '#1890ff', bg: '#e6f7ff' },
          { label: '维修', value: repairing, color: '#faad14', bg: '#fffbe6' },
          { label: '总件数', value: totalQty, color: '#722ed1', bg: '#f9f0ff' },
        ].map(s => (
          <div key={s.label} className="content-card p-4 text-center">
            <p className="text-2xl font-bold" style={{ color: s.color }}>{s.value}</p>
            <p className="text-xs mt-1" style={{ color: 'var(--text-secondary)' }}>{s.label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {tabList.map(t => (
          <button key={t.key} className={`px-4 py-2 text-sm rounded-lg border transition-all ${activeTab === t.key ? 'font-medium' : 'hover:bg-gray-50'}`}
            style={activeTab === t.key ? { borderColor: '#1890ff', background: '#e6f7ff', color: '#1890ff' } : { borderColor: 'var(--border-color)' }}
            onClick={() => setActiveTab(t.key)}>{t.label}</button>
        ))}
      </div>

      {/* Table */}
      <div className="content-card overflow-hidden">
        <table className="data-table">
          <thead>
            <tr>
              <th className="w-10"><input type="checkbox" /></th>
              <th>RFID编码</th>
              <th>物资类别</th>
              <th>装备名称</th>
              <th>规格型号</th>
              <th>标签</th>
              <th>数量</th>
              <th>单位</th>
              <th>存储位置</th>
              <th>生产日期</th>
              <th>有效期</th>
              <th>保养期</th>
              <th>单价</th>
              <th>总价</th>
              <th>供应商</th>
              <th>状态</th>
              <th>最后操作时间</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={17} className="text-center py-8 text-sm" style={{ color: 'var(--text-disabled)' }}>暂无数据</td></tr>}
            {filtered.map((item, idx) => (
              <tr key={idx}>
                <td><input type="checkbox" /></td>
                <td className="font-mono text-xs"><RfidDisplay rfid={item.rfidCode} /></td>
                <td className="text-xs">{item.category}</td>
                <td className="font-medium">{item.name}</td>
                <td className="text-xs">{item.spec}</td>
                <td className="text-xs"><TagBadges tags={item.tags || []} maxShow={2} /></td>
                <td className="text-center font-medium">{item.qty}</td>
                <td className="text-center text-xs">{item.isBox ? `箱(${item.boxSpec})` : item.unit}</td>
                <td className="text-xs">{item.location}</td>
                <td className="text-xs">{item.produceDate}</td>
                <td className="text-xs">{item.validDate}</td>
                <td className="text-xs">{item.maintainPeriod}</td>
                <td className="text-right font-mono text-xs">{item.price.toLocaleString()}</td>
                <td className="text-right font-mono text-xs font-medium" style={{ color: '#1890ff' }}>{item.total.toLocaleString()}</td>
                <td className="text-xs">{item.supplier}</td>
                <td><span className="tag text-xs" style={{ background: statusConfig[item.status].bg, color: statusConfig[item.status].color, border: `1px solid ${statusConfig[item.status].border}` }}>{statusConfig[item.status].label}</span></td>
                <td className="text-xs">{item.lastTime}</td>
                <td>
                  <div className="flex items-center gap-1 flex-wrap">
                    {getActions(item).map(a => {
                      const color = a === '报废' ? '#ff4d4f' : a === '报修' ? '#faad14' : a === '打印' ? '#52c41a' : 'var(--primary-blue)'
                      const handler = () => {
                        if (a === '打印') handlePrint(item)
                        else if (a === '修改') openEdit(item)
                        else if (a === '报废') openScrap(item)
                        else if (a === '调库') openTransfer(item)
                        else if (a === '报修') openRepair(item)
                        else if (a === '详情') openDetail(item)
                      }
                      return <button key={a} className="text-xs px-1.5 py-0.5 rounded hover:bg-gray-100 transition-colors" style={{ color }} onClick={handler}>{a}</button>
                    })}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* ===== Detail Drawer ===== */}
      {detailOpen && detailItem && (
        <div className="fixed inset-0 z-[70] flex justify-end">
          <div className="absolute inset-0 bg-black/40" onClick={() => setDetailOpen(false)} />
          <div className="relative bg-white shadow-2xl w-[600px] flex flex-col animate-in slide-in-from-right duration-200" style={{ maxWidth: '90vw' }}>
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between px-5 py-4 border-b bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <h3 className="text-lg font-semibold">装备详情</h3>
              <button onClick={() => setDetailOpen(false)} className="p-1 rounded-lg hover:bg-gray-100"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
            </div>

            {/* Content */}
            <div className="overflow-y-auto flex-1 text-sm">
              {/* ── 基本信息 ── */}
              <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                  <span className="w-1 h-4 rounded-full" style={{ background: 'var(--primary-blue)' }} />
                  基本信息
                </h4>
                <div className="grid grid-cols-3 gap-x-4 gap-y-2">
                  {[
                    { label: '装备编码', value: detailItem.equipCode },
                    { label: '装备名称', value: detailItem.name },
                    { label: '物资类别', value: detailItem.category },
                    { label: '规格型号', value: detailItem.spec },
                    { label: '数量', value: `${detailItem.qty} ${detailItem.isBox ? `箱(${detailItem.boxSpec})` : detailItem.unit}` },
                    { label: '剩余数量', value: `${detailItem.remainQty}` },
                    { label: '单位', value: detailItem.unit },
                    { label: '存储位置', value: detailItem.location },
                    { label: '生产日期', value: detailItem.produceDate },
                    { label: '有效期', value: detailItem.validDate },
                    { label: '保养期', value: detailItem.maintainPeriod },
                    { label: '单价', value: `¥${detailItem.price.toLocaleString()}` },
                    { label: '总价', value: `¥${detailItem.total.toLocaleString()}` },
                    { label: '供应商', value: detailItem.supplier },
                    { label: '状态', value: statusConfig[detailItem.status].label },
                    { label: '最后操作时间', value: detailItem.lastTime },
                  ].map(f => (
                    <div key={f.label} className="flex flex-col py-1">
                      <span className="text-xs mb-0.5" style={{ color: 'var(--text-secondary)' }}>{f.label}</span>
                      <span className={`font-medium ${f.label === '装备编码' ? 'font-mono text-[11px]' : ''}`}>{f.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* ── RFID编码列表 ── */}
              {detailItem.qty > 1 && (
                <div className="px-5 py-4 border-b" style={{ borderColor: 'var(--border-color)' }}>
                  <RfidList
                    rfids={detailItem.individualRFIDs || Array.from({ length: detailItem.qty }, (_, i) => detailItem.rfidCode.slice(0, -4) + String(i + 1).padStart(4, '0'))}
                    selectedRfid={detailItem.rfidCode}
                    onSelect={(rfid) => { }}
                  />
                </div>
              )}

              {/* ── 全生命周期记录 ── */}
              <div className="px-6 py-4">
                <h4 className="text-sm font-semibold mb-4 flex items-center gap-2">
                  <span className="w-1 h-4 rounded-full" style={{ background: 'var(--primary-blue)' }} />
                  全生命周期记录
                </h4>
                <div className="relative pl-6 space-y-4">
                  {/* 时间线竖线 */}
                  <div className="absolute left-[9px] top-2 bottom-2 w-0.5 bg-gray-200" />
                  {[
                    { type: '入库', color: '#52c41a', time: '2024-03-15 09:30:00', operator: '张建国', dept: '省厅装备处', title: '采购入库', detail: `入库数量: ${detailItem.qty} ${detailItem.unit}，存放位置: ${detailItem.location}，供应商: ${detailItem.supplier}` },
                    { type: '出库', color: '#1890ff', time: '2024-03-16 10:15:00', operator: '李卫国', dept: '市局装备科', title: '调拨出库', detail: `出库数量: 5 ${detailItem.unit}，调拨方向: 市局限装备仓库，审批单号: CK20240316001` },
                    { type: '领用', color: '#13c2c2', time: '2024-03-18 14:20:00', operator: '王志强', dept: '刑警支队', title: '任务领用', detail: `领用数量: 3 ${detailItem.unit}，领用事由: 专项行动保障，预计归还: 2024-04-18` },
                    { type: '报修', color: '#faad14', time: '2024-03-20 09:00:00', operator: '赵明华', dept: '设备维护组', title: '故障报修', detail: `故障描述: 无法正常开机，报修人: 王志强，维修方式: 返厂维修` },
                    { type: '盘点', color: '#722ed1', time: '2024-03-25 16:45:00', operator: '陈晓东', dept: '仓库管理组', title: '月度盘点', detail: `盘点结果: 账实相符，盘点方式: 人工+RFID扫描，备注: 设备状态良好` },
                    { type: '调拨', color: '#2f54eb', time: '2024-03-28 11:30:00', operator: '刘建华', dept: '装备调配中心', title: '跨区调拨', detail: `调拨数量: 2 ${detailItem.unit}，调出仓库: 省厅主仓库 A区-01-03，调入仓库: 市局限装备仓库 B区-02-04` },
                    { type: '报废', color: '#ff4d4f', time: '2025-12-01 09:00:00', operator: '陈晓东', dept: '仓库管理组', title: '到期报废', detail: `报废原因: 超过有效期，报废数量: 1 ${detailItem.unit}，处置方式: 环保回收` },
                  ].map((record, idx, arr) => (
                    <div key={idx} className="relative">
                      {/* 彩色圆点 */}
                      <div
                        className="absolute -left-6 top-1 w-5 h-5 rounded-full border-2 border-white shadow-sm flex items-center justify-center"
                        style={{ background: record.color }}
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-white" />
                      </div>
                      {/* 内容卡片 */}
                      <div className="bg-gray-50 rounded-lg p-3">
                        {/* 第一行：类型标签 + 时间 */}
                        <div className="flex items-center gap-2 mb-1.5">
                          <span
                            className="text-xs px-2 py-0.5 rounded font-medium text-white"
                            style={{ background: record.color }}
                          >
                            {record.type}
                          </span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{record.time}</span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>·</span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{record.operator}</span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>·</span>
                          <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{record.dept}</span>
                        </div>
                        {/* 标题 */}
                        <div className="font-semibold text-sm mb-1">{record.title}</div>
                        {/* 详情 */}
                        <div className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>{record.detail}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer */}
            <div className="sticky bottom-0 px-6 py-4 border-t bg-white" style={{ borderColor: 'var(--border-color)' }}>
              <button className="btn-default w-full" onClick={() => setDetailOpen(false)}>关闭</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Edit Modal ===== */}
      {editOpen && editItem && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setEditOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200">
            <h3 className="text-lg font-semibold mb-4">修改装备</h3>
            <div className="space-y-4">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>装备名称</label><input className="form-input w-full bg-gray-50" value={editItem.name} readOnly /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>存储位置 <span className="text-red-400">*</span></label><WarehouseTreeSelect warehouseData={warehouseData} value={editLocation} onChange={setEditLocation} /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>备注</label><input className="form-input w-full" placeholder="请输入备注..." value={editRemark} onChange={e => setEditRemark(e.target.value)} /></div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button className="btn-default" onClick={() => setEditOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleEditSave}>保存</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Transfer Modal ===== */}
      {transferOpen && transferItem && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setTransferOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200">
            <h3 className="text-lg font-semibold mb-4">调库 - {transferItem.name}</h3>
            <div className="space-y-4">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>当前位置</label><input className="form-input w-full bg-gray-50" value={transferItem.location} readOnly /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>目标仓库 <span className="text-red-400">*</span></label><WarehouseTreeSelect warehouseData={warehouseData.filter(w => !w.parent)} value={transferTo} onChange={setTransferTo} mode="name" placeholder="请选择目标仓库" /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>目标库位</label><input className="form-input w-full" placeholder="如 A区-01-03" value={transferLoc} onChange={e => setTransferLoc(e.target.value)} /></div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button className="btn-default" onClick={() => setTransferOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleTransfer}>确认调库</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Scrap Modal ===== */}
      {scrapOpen && scrapItem && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setScrapOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fff2f0' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ff4d4f" strokeWidth="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
              </div>
              <h3 className="text-lg font-semibold">发起报废</h3>
            </div>
            <div className="mb-4 p-3 rounded-lg bg-gray-50">
              <p className="text-sm font-medium">{scrapItem.name}</p>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>RFID：{scrapItem.rfidCode} | 数量：{scrapItem.qty} {scrapItem.unit} | 位置：{scrapItem.location}</p>
            </div>
            <div className="space-y-4">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报废原因 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入报废原因" value={scrapReason} onChange={e => setScrapReason(e.target.value)} /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人</label><input className="form-input w-full" placeholder="请输入经办人" value={scrapOperator} onChange={e => setScrapOperator(e.target.value)} /></div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button className="btn-default" onClick={() => setScrapOpen(false)}>取消</button>
              <button className="btn-danger" onClick={handleScrap}>提交报废</button>
            </div>
          </div>
        </div>
      )}

      {/* ===== Repair Modal ===== */}
      {repairOpen && repairItem && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setRepairOpen(false)} />
          <div className="relative bg-white rounded-xl shadow-2xl w-[500px] p-6 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: '#fffbe6' }}>
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#faad14" strokeWidth="2"><circle cx="12" cy="12" r="3"/><path d="M12 1v6m0 6v6m4.22-10.22l4.24-4.24M6.34 6.34L2.1 2.1m17.8 17.8l-4.24-4.24M6.34 17.66l-4.24 4.24M23 12h-6m-6 0H1m20.24 4.24l-4.24-4.24M6.34 6.34l-4.24-4.24"/></svg>
              </div>
              <h3 className="text-lg font-semibold">发起报修</h3>
            </div>
            <div className="mb-4 p-3 rounded-lg bg-gray-50">
              <p className="text-sm font-medium">{repairItem.name}</p>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>RFID：{repairItem.rfidCode} | 数量：{repairItem.qty} {repairItem.unit} | 位置：{repairItem.location}</p>
            </div>
            <div className="space-y-4">
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>报修说明 <span className="text-red-400">*</span></label><input className="form-input w-full" placeholder="请输入报修说明" value={repairDesc} onChange={e => setRepairDesc(e.target.value)} /></div>
              <div><label className="block text-xs mb-1" style={{ color: 'var(--text-secondary)' }}>经办人</label><input className="form-input w-full" placeholder="请输入经办人" value={repairOperator} onChange={e => setRepairOperator(e.target.value)} /></div>
            </div>
            <div className="flex items-center justify-end gap-3 mt-6">
              <button className="btn-default" onClick={() => setRepairOpen(false)}>取消</button>
              <button className="btn-primary" onClick={handleRepair} style={{ background: '#faad14' }}>提交报修</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
