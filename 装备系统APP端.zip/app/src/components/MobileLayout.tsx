import { useLocation, useNavigate } from 'react-router';
import { Home, ClipboardCheck, User, ChevronLeft } from 'lucide-react';
import type { ReactNode } from 'react';
import { useState, useEffect } from 'react';

interface MobileLayoutProps {
  children: ReactNode;
  title?: string;
  showNav?: boolean;
  showBack?: boolean;
  onBack?: () => void;
  rightAction?: ReactNode;
}

const navItems = [
  { key: 'home', label: '首页', icon: Home, path: '/' },
  { key: 'approval', label: '审批代办', icon: ClipboardCheck, path: '/approval' },
  { key: 'profile', label: '我的', icon: User, path: '/profile' },
];

export default function MobileLayout({ children, title, showNav = true, showBack = false, onBack, rightAction }: MobileLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [currentTime, setCurrentTime] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  const activeTab = location.pathname === '/' ? 'home' : location.pathname === '/approval' ? 'approval' : location.pathname === '/profile' ? 'profile' : '';

  const handleBack = () => {
    if (onBack) onBack();
    else navigate(-1);
  };

  const isRootPage = location.pathname === '/' || location.pathname === '/approval' || location.pathname === '/profile';
  const shouldShowNav = showNav && isRootPage;
  const shouldShowHeader = !isRootPage || title;

  return (
    <div className="h-full w-full flex flex-col overflow-hidden">
      {/* Status Bar */}
      <div className="shrink-0 h-7 flex items-center justify-between px-5 text-white text-[11px] font-medium select-none" style={{ background: 'linear-gradient(135deg, #0d2b5e 0%, #1565c0 100%)' }}>
        <span>{currentTime}</span>
        <div className="flex items-center gap-1">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M15.67 4H14V2h-4v2H8.33C7.6 4 7 4.6 7 5.33v15.33C7 21.4 7.6 22 8.33 22h7.33c.74 0 1.34-.6 1.34-1.33V5.33C17 4.6 16.4 4 15.67 4z"/></svg>
        </div>
      </div>

      {/* Header */}
      {shouldShowHeader && (
        <div className="shrink-0 h-12 flex items-center px-4 text-white" style={{ background: 'linear-gradient(135deg, #0d2b5e 0%, #1565c0 100%)' }}>
          {showBack && (
            <button onClick={handleBack} className="mr-3 p-1 -ml-1 active:opacity-60 transition-opacity">
              <ChevronLeft size={22} strokeWidth={2.5} />
            </button>
          )}
          <h1 className="text-base font-semibold flex-1 truncate">{title || '警务装备管理'}</h1>
          {rightAction && <div className="ml-2">{rightAction}</div>}
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto overflow-x-hidden no-scrollbar relative" style={{ background: '#f0f4f8' }}>
        {children}
      </div>

      {/* Bottom Navigation */}
      {shouldShowNav && (
        <div className="shrink-0 h-14 border-t border-gray-200/60 flex items-center justify-around z-50" style={{ background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)' }}>
          {navItems.map((item) => {
            const isActive = activeTab === item.key;
            const Icon = item.icon;
            return (
              <button
                key={item.key}
                onClick={() => navigate(item.path)}
                className="flex flex-col items-center justify-center gap-0.5 w-16 h-full active:scale-95 transition-transform"
              >
                <div className="relative">
                  <Icon size={22} strokeWidth={isActive ? 2.5 : 1.5} className={isActive ? 'text-[#1565c0]' : 'text-gray-400'} />
                  {item.key === 'approval' && (
                    <span className="absolute -top-1.5 -right-2 min-w-[16px] h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">3</span>
                  )}
                </div>
                <span className={`text-[10px] ${isActive ? 'text-[#1565c0] font-semibold' : 'text-gray-400'}`}>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
