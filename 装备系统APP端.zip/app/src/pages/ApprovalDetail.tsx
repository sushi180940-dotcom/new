import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { approvalMockData } from './Approval';
import {
  ClipboardCheck, CheckCircle2, XCircle, Clock,
  FileText, Package, AlertTriangle,
  Shield, StickyNote
} from 'lucide-react';

/* ─── config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending:  { label: '待审批', color: 'text-orange-600', bg: 'bg-orange-50', icon: Clock },
  approved: { label: '已通过', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  rejected: { label: '已驳回', color: 'text-red-600', bg: 'bg-red-50', icon: XCircle },
};

const typeColorMap: Record<string, string> = {
  apply: '#1565c0', transfer: '#7c4dff', handover: '#00acc1',
};

const typeLabelMap: Record<string, string> = {
  apply: '装备申领', transfer: '装备调拨', handover: '装备交接',
};

/* ─── main component ─── */
export default function ApprovalDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const item = approvalMockData[id || ''];

  const [status, setStatus] = useState<'view' | 'confirmApprove' | 'confirmReject' | 'approved' | 'rejected'>('view');
  const [rejectReason, setRejectReason] = useState('');
  const [approveOpinion, setApproveOpinion] = useState('');

  if (!item) {
    return (
      <MobileLayout title="审批详情" showBack onBack={() => navigate('/approval')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <ClipboardCheck size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到审批记录</p>
        </div>
      </MobileLayout>
    );
  }

  const sc = statusConfig[item.status];
  const StatusIcon = sc.icon;
  const totalQty = item.materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = item.materials.reduce((s, m) => s + m.total, 0);
  const isPending = item.status === 'pending';

  const handleApprove = () => {
    item.status = 'approved';
    item.approver = '张建国';
    item.approveTime = new Date().toLocaleString('zh-CN');
    item.approveOpinion = approveOpinion || '同意';
    setStatus('approved');
  };

  const handleReject = () => {
    if (!rejectReason.trim()) return;
    item.status = 'rejected';
    item.approver = '张建国';
    item.approveTime = new Date().toLocaleString('zh-CN');
    item.rejectReason = rejectReason;
    setStatus('rejected');
  };

  /* ── Approved Result ── */
  if (status === 'approved') {
    return (
      <MobileLayout title="审批完成" showBack onBack={() => navigate('/approval')}>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 size={40} className="text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">审批已通过</h3>
          <p className="text-sm text-gray-500 text-center mb-6">
            {typeLabelMap[item.typeKey]}申请已通过审批
            <br />系统将自动通知申请人
          </p>
          <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6">
            <div className="text-center mb-3 pb-3 border-b border-gray-100">
              <p className="text-xs text-gray-500 mb-1">审批单号</p>
              <p className="text-base font-semibold text-[#1565c0] font-mono">{item.id}</p>
            </div>
            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between">
                <span className="text-gray-500">申请人</span>
                <span className="font-medium">{item.applicant}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">物资数量</span>
                <span className="font-medium">{item.materials.length}种 · {totalQty}件</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">审批时间</span>
                <span className="font-medium">{item.approveTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">审批意见</span>
                <span className="font-medium text-green-600">{item.approveOpinion}</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => navigate('/approval')}
            className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors"
          >
            返回审批列表
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── Rejected Result ── */
  if (status === 'rejected') {
    return (
      <MobileLayout title="审批完成" showBack onBack={() => navigate('/approval')}>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mb-4">
            <XCircle size={40} className="text-red-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">审批已驳回</h3>
          <p className="text-sm text-gray-500 text-center mb-6">
            {typeLabelMap[item.typeKey]}申请已被驳回
            <br />系统将自动通知申请人
          </p>
          <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6">
            <div className="text-center mb-3 pb-3 border-b border-gray-100">
              <p className="text-xs text-gray-500 mb-1">审批单号</p>
              <p className="text-base font-semibold text-[#1565c0] font-mono">{item.id}</p>
            </div>
            <div className="space-y-2 text-xs text-gray-600">
              <div className="flex justify-between">
                <span className="text-gray-500">申请人</span>
                <span className="font-medium">{item.applicant}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">驳回原因</span>
                <span className="font-medium text-red-600">{item.rejectReason}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">审批时间</span>
                <span className="font-medium">{item.approveTime}</span>
              </div>
            </div>
          </div>
          <button
            onClick={() => navigate('/approval')}
            className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors"
          >
            返回审批列表
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── Confirm Approve ── */
  if (status === 'confirmApprove') {
    return (
      <MobileLayout title="确认审批" showBack onBack={() => setStatus('view')}>
        <div className="p-4">
          <div className="bg-green-50 rounded-2xl p-4 mb-4 flex items-start gap-3">
            <Shield size={20} className="text-green-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-700 mb-1">确认通过审批</p>
              <p className="text-xs text-green-600 leading-relaxed">
                审批通过后不可撤销，系统将自动通知申请人并更新业务流程状态。
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">审批意见（可选）</h3>
            <textarea
              value={approveOpinion}
              onChange={e => setApproveOpinion(e.target.value)}
              placeholder="输入审批意见..."
              rows={3}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-green-200 border border-transparent focus:border-green-300 transition-all resize-none"
            />
          </div>

          <button
            onClick={handleApprove}
            className="w-full bg-green-600 text-white py-3.5 rounded-xl font-medium mb-3 active:bg-green-700 transition-colors flex items-center justify-center gap-2 shadow-md"
          >
            <CheckCircle2 size={16} />
            确认通过
          </button>
          <button
            onClick={() => setStatus('view')}
            className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-xl font-medium active:bg-gray-200 transition-colors"
          >
            返回查看
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── Confirm Reject ── */
  if (status === 'confirmReject') {
    return (
      <MobileLayout title="确认驳回" showBack onBack={() => setStatus('view')}>
        <div className="p-4">
          <div className="bg-red-50 rounded-2xl p-4 mb-4 flex items-start gap-3">
            <AlertTriangle size={20} className="text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-700 mb-1">确认驳回申请</p>
              <p className="text-xs text-red-600 leading-relaxed">
                驳回后不可撤销，系统将自动通知申请人。请确保驳回原因准确。
              </p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <label className="text-sm font-semibold text-gray-800 mb-2 block">
              驳回原因 <span className="text-red-400">*</span>
            </label>
            <textarea
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              placeholder="请详细说明驳回原因..."
              rows={4}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-red-200 border border-transparent focus:border-red-300 transition-all resize-none"
            />
          </div>

          <button
            onClick={handleReject}
            disabled={!rejectReason.trim()}
            className={`w-full py-3.5 rounded-xl font-medium mb-3 flex items-center justify-center gap-2 transition-all ${
              rejectReason.trim()
                ? 'bg-red-500 text-white active:bg-red-600 shadow-md'
                : 'bg-gray-200 text-gray-400'
            }`}
          >
            <XCircle size={16} />
            确认驳回
          </button>
          <button
            onClick={() => setStatus('view')}
            className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-xl font-medium active:bg-gray-200 transition-colors"
          >
            返回查看
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── View (default) ── */
  return (
    <MobileLayout title="审批详情" showBack onBack={() => navigate('/approval')}>
      <div className="p-4 pb-32">
        {/* ── Status Card ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${sc.bg}`}>
              <StatusIcon size={24} className={sc.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{item.id}</span>
                <span
                  className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white"
                  style={{ backgroundColor: typeColorMap[item.typeKey] || '#1565c0' }}
                >
                  {typeLabelMap[item.typeKey] || item.type}
                </span>
              </div>
              <span className={`text-xs font-medium ${sc.color}`}>{sc.label}</span>
            </div>
          </div>

          {/* Overdue warning */}
          {item.isOverdue && isPending && (
            <div className="flex items-center gap-2 bg-red-50 rounded-xl p-3 mb-3">
              <AlertTriangle size={16} className="text-red-500 shrink-0" />
              <p className="text-xs text-red-600 font-medium">
                该工单已超过24小时未处理，请尽快审批
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请人</p>
              <p className="text-xs text-gray-800 font-medium">{item.applicant}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">所属单位</p>
              <p className="text-xs text-gray-800 font-medium">{item.applicantUnit}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请时间</p>
              <p className="text-xs text-gray-800 font-medium">{item.applyTime}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">物资合计</p>
              <p className="text-xs text-gray-800 font-medium">{item.materials.length}种 · {totalQty}件 · ¥{totalAmount.toLocaleString()}</p>
            </div>
          </div>
        </div>

        {/* ── Reason ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <FileText size={14} className="text-[#1565c0]" /> 申请事由
          </h3>
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-sm text-gray-700 leading-relaxed">{item.reason}</p>
          </div>
        </div>

        {/* ── Materials Detail ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Package size={14} className="text-[#1565c0]" /> 物资明细 ({item.materials.length})
          </h3>
          <div className="space-y-3">
            {item.materials.map((m, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-3">
                {/* Header */}
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{m.name}</span>
                    <span className="text-[10px] text-gray-500 bg-white px-1.5 py-0.5 rounded">{m.category}</span>
                    {m.isFixedAsset && (
                      <span className="text-[10px] text-purple-500 bg-purple-50 px-1.5 py-0.5 rounded">固定资产</span>
                    )}
                  </div>
                  <span className="text-sm font-bold text-[#1565c0]">¥{m.total.toLocaleString()}</span>
                </div>

                {/* Grid info */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>型号：{m.model}</span>
                  <span>单位：{m.unit}</span>
                  <span>申请数量：<span className="text-orange-600 font-medium">{m.quantity}</span></span>
                  <span>库存数量：<span className="text-green-600 font-medium">{m.stockQty}</span></span>
                  <span>单价：¥{m.price.toLocaleString()}</span>
                  <span>总价：¥{m.total.toLocaleString()}</span>
                  <span>装备编码：{m.equipmentCode}</span>
                  <span>供应商：{m.supplier}</span>
                </div>

                {/* Remark */}
                {m.remark && (
                  <div className="mt-2 pt-2 border-t border-gray-200">
                    <p className="text-[10px] text-gray-400 flex items-center gap-1">
                      <StickyNote size={9} /> 备注：{m.remark}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
          {/* Total */}
          <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
            <span className="text-sm text-gray-600">
              共 {item.materials.length} 种，{totalQty} 件
            </span>
            <span className="text-sm font-bold text-[#1565c0]">
              ¥{totalAmount.toLocaleString()}
            </span>
          </div>
        </div>

        {/* ── Approval Record (if already processed) ── */}
        {!isPending && (item.approver || item.approveTime) && (
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Shield size={14} className="text-[#1565c0]" /> 审批记录
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">审批人</span>
                <span className="text-xs text-gray-800 font-medium">{item.approver}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">审批时间</span>
                <span className="text-xs text-gray-800 font-medium">{item.approveTime}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">审批结果</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  item.status === 'approved' ? 'bg-green-50 text-green-600' : 'bg-red-50 text-red-600'
                }`}>
                  {item.status === 'approved' ? '已通过' : '已驳回'}
                </span>
              </div>
              {item.status === 'approved' && item.approveOpinion && (
                <div className="py-1.5 border-b border-gray-50">
                  <span className="text-xs text-gray-500">审批意见</span>
                  <p className="text-xs text-gray-800 font-medium mt-1">{item.approveOpinion}</p>
                </div>
              )}
              {item.status === 'rejected' && item.rejectReason && (
                <div className="py-1.5">
                  <span className="text-xs text-gray-500">驳回原因</span>
                  <p className="text-xs text-red-600 font-medium mt-1">{item.rejectReason}</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ── Irreversible notice ── */}
        {isPending && (
          <div className="bg-orange-50 rounded-xl p-3 mb-4 flex items-center gap-2">
            <AlertTriangle size={14} className="text-orange-500 shrink-0" />
            <p className="text-xs text-orange-600">
              审批操作不可逆，同意或驳回后不可二次修改
            </p>
          </div>
        )}
      </div>

      {/* ── Bottom Actions ── */}
      {isPending && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-[#f0f4f8] border-t border-gray-200/60">
          {item.isOverdue && (
            <div className="flex items-center gap-2 mb-2 bg-red-50 rounded-lg px-3 py-2">
              <AlertTriangle size={14} className="text-red-500 shrink-0" />
              <p className="text-xs text-red-600 font-medium">该工单已超时，请尽快处理</p>
            </div>
          )}
          <div className="flex gap-3">
            <button
              onClick={() => setStatus('confirmReject')}
              className="flex-1 bg-red-50 text-red-600 py-3.5 rounded-xl font-medium active:bg-red-100 transition-colors flex items-center justify-center gap-1.5 border border-red-200"
            >
              <XCircle size={16} />
              驳回
            </button>
            <button
              onClick={() => setStatus('confirmApprove')}
              className="flex-1 bg-green-600 text-white py-3.5 rounded-xl font-medium active:bg-green-700 transition-colors flex items-center justify-center gap-1.5 shadow-md"
            >
              <CheckCircle2 size={16} />
              同意
            </button>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
