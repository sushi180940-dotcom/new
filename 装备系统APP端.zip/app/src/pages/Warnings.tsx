import { useState } from 'react';
import MobileLayout from '@/components/MobileLayout';
import { warningList } from '@/data/mock';
import { Bell, AlertTriangle, User } from 'lucide-react';

const typeMap: Record<string, { label: string; color: string; bg: string }> = {
  expire: { label: '过期', color: 'text-red-600', bg: 'bg-red-50' },
  overdue: { label: '超期', color: 'text-red-600', bg: 'bg-red-50' },
  check: { label: '盘点', color: 'text-orange-600', bg: 'bg-orange-50' },
  loan: { label: '领用', color: 'text-orange-600', bg: 'bg-orange-50' },
};

const levelMap: Record<string, { label: string; color: string; border: string; bg: string }> = {
  urgent: { label: '紧急', color: 'text-red-600', border: 'border-red-300', bg: 'bg-red-50' },
  warning: { label: '重要', color: 'text-orange-600', border: 'border-orange-300', bg: 'bg-orange-50' },
  normal: { label: '一般', color: 'text-blue-600', border: 'border-blue-300', bg: 'bg-blue-50' },
};

const tabs = [
  { key: 'all', label: '全部' },
  { key: 'urgent', label: '紧急' },
  { key: 'warning', label: '重要' },
  { key: 'normal', label: '一般' },
];

export default function Warnings() {
  const [activeTab, setActiveTab] = useState('all');
  const filtered = activeTab === 'all' ? warningList : warningList.filter(w => w.level === activeTab);

  return (
    <MobileLayout title="预警信息" showBack>
      {/* Tabs */}
      <div className="sticky top-0 z-40 bg-[#f0f4f8] pt-2 pb-0 px-4">
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                activeTab === t.key
                  ? 'bg-[#1565c0] text-white shadow-md shadow-blue-900/20'
                  : 'bg-white text-gray-600'
              }`}
            >
              {t.label}
              {t.key === 'all' && <span className="ml-1 text-[10px]">({warningList.length})</span>}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pt-3 pb-4">
        {/* Stats */}
        <div className="flex gap-2 mb-3">
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center border border-red-200">
            <p className="text-lg font-bold text-red-600">{warningList.filter(w => w.level === 'urgent').length}</p>
            <p className="text-[10px] text-gray-500">紧急</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center border border-orange-200">
            <p className="text-lg font-bold text-orange-600">{warningList.filter(w => w.level === 'warning').length}</p>
            <p className="text-[10px] text-gray-500">重要</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center border border-blue-200">
            <p className="text-lg font-bold text-blue-600">{warningList.filter(w => w.level === 'normal').length}</p>
            <p className="text-[10px] text-gray-500">一般</p>
          </div>
        </div>

        {/* Warning List */}
        <div className="space-y-2">
          {filtered.map(warning => {
            const typeConfig = typeMap[warning.type];
            const levelConfig = levelMap[warning.level];
            return (
              <div
                key={warning.id}
                className={`bg-white rounded-2xl p-4 shadow-sm border-l-4 ${levelConfig.border}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className={`w-8 h-8 rounded-lg ${typeConfig.bg} flex items-center justify-center`}>
                      <AlertTriangle size={14} className={typeConfig.color} />
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-800">{warning.title}</p>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${levelConfig.bg || 'bg-gray-100'} ${levelConfig.color}`}>
                          {levelConfig.label}
                        </span>
                        <span className="text-[10px] text-gray-400">{typeConfig.label}预警</span>
                      </div>
                    </div>
                  </div>
                  <span className="text-[10px] text-gray-400">{warning.time}</span>
                </div>
                <p className="text-xs text-gray-600 mb-2 pl-10">{warning.content}</p>
                <div className="flex items-center gap-1 pl-10 text-[10px] text-gray-400">
                  <User size={10} />
                  <span>责任人：{warning.handler}</span>
                </div>
              </div>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Bell size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无预警信息</p>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
