import { useState, useCallback, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Package, ChevronRight, Plus, Trash2, CheckCircle2, Clock,
  ArrowRight, Minus, ShoppingCart, ArrowLeftRight, RotateCcw,
  Building2, QrCode, CircleDot, Search, Save
} from 'lucide-react';

/* ─── types ─── */
interface MaterialItem {
  id: string; name: string; category: string; model: string;
  quantity: number; productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
  unit: string; price: number; total: number;
  equipmentCode: string; rfidCode: string;
  storageLocation: string; supplier: string;
  isFixedAsset: boolean; remark: string;
}

interface InventoryRecord {
  id: string; type: string; status: 'pending' | 'completed' | 'draft';
  createTime: string; materials: number;
}

/* ─── static data ─── */
const inTypes = [
  { key: 'purchase', label: '采购入库', desc: '装备采购登记入库', icon: ShoppingCart, color: '#1565c0', editable: true },
  { key: 'transfer', label: '仓库调拨入库', desc: '仓库间调拨入库（系统数据）', icon: ArrowLeftRight, color: '#7c4dff', editable: false },
  { key: 'return', label: '归还入库', desc: '临时领用归还入库（系统数据）', icon: RotateCcw, color: '#00acc1', editable: false },
  { key: 'station', label: '所队装备入库', desc: '派出所装备入库', icon: Building2, color: '#43a047', editable: true },
];

const SUPPLIERS = ['红星装备厂', '国安器材有限公司', '盾甲科技', '警用装备中心', '中华安防集团', '雄鹰警械公司', '猎豹装备科技'];

const WAREHOUSES = [
  { name: '省厅主仓库', areas: ['主仓库1楼', '主仓库2楼', '主仓库3楼'] },
  { name: '01号装备室', areas: ['东侧区域', '西侧区域'] },
  { name: '02号装备室', areas: ['A区', 'B区'] },
  { name: '03号装备室', areas: ['一楼', '二楼'] },
];

const MAINTENANCE_UNITS = ['日', '月', '年'];

const mockHistory: InventoryRecord[] = [
  { id: 'RK20240520001', type: 'purchase', status: 'completed', createTime: '2024-05-20 10:30', materials: 12 },
  { id: 'RK20240520002', type: 'purchase', status: 'draft', createTime: '2024-05-20 09:00', materials: 3 },
  { id: 'RK20240519002', type: 'transfer', status: 'completed', createTime: '2024-05-19 14:20', materials: 5 },
  { id: 'RK20240518003', type: 'return', status: 'pending', createTime: '2024-05-18 09:15', materials: 3 },
  { id: 'RK20240517004', type: 'station', status: 'completed', createTime: '2024-05-17 16:00', materials: 8 },
  { id: 'RK20240516005', type: 'purchase', status: 'completed', createTime: '2024-05-16 11:30', materials: 15 },
  { id: 'RK20240515006', type: 'return', status: 'completed', createTime: '2024-05-15 08:45', materials: 2 },
];

// Auto-fetch mock data
interface AutoFetchItem {
  id: string;
  count: number;
  materials: MaterialItem[];
  [key: string]: unknown;
}

const transferList: AutoFetchItem[] = [
  { id: 'DB20240519001', fromUnit: '东坝派出所', toUnit: '省厅主仓库', count: 5, status: 'pending', createTime: '2024-05-19 10:00', materials: [{ name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 5, unit: '台', rfidCode: 'RFID202405010A~E', equipmentCode: 'EQ202405010', storageLocation: '省厅主仓库/主仓库2楼', supplier: '国安器材', price: 650, total: 3250, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
  { id: 'DB20240518002', fromUnit: '劲松派出所', toUnit: '省厅主仓库', count: 3, status: 'pending', createTime: '2024-05-18 14:30', materials: [{ name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 3, unit: '台', rfidCode: 'RFID202405011A~C', equipmentCode: 'EQ202405011', storageLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', price: 1800, total: 5400, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
];

const returnList: AutoFetchItem[] = [
  { id: 'GH20240518001', borrower: '王强', borrowUnit: '朝阳分局', borrowTime: '2024-04-15', expectedReturn: '2024-05-15', actualReturn: '2024-05-18', count: 2, materials: [{ name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', rfidCode: 'RFID202403001A', equipmentCode: 'EQ202403001', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', price: 1200, total: 1200, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }, { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', rfidCode: 'RFID202403002B', equipmentCode: 'EQ202403002', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', price: 280, total: 280, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
  { id: 'GH20240517002', borrower: '李明', borrowUnit: '东坝派出所', borrowTime: '2024-03-20', expectedReturn: '2024-05-20', actualReturn: '2024-05-17', count: 1, materials: [{ name: '警用盾牌', category: '防护装备', model: 'JYP-800-B', quantity: 1, unit: '件', rfidCode: 'RFID202403005A', equipmentCode: 'EQ202403005', storageLocation: '02号装备室/A区', supplier: '国安器材', price: 450, total: 450, id: '', productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: false, remark: '' }] },
];

const typeLabelMap: Record<string, string> = { purchase: '采购入库', transfer: '调拨入库', return: '归还入库', station: '所队入库' };
const typeColorMap: Record<string, string> = { purchase: '#1565c0', transfer: '#7c4dff', return: '#00acc1', station: '#43a047' };

function genOrderNo() {
  const d = new Date();
  return `RK${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`;
}

function emptyMaterial(storage = '', supplier = ''): MaterialItem {
  return {
    id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
    name: '', category: '', model: '', quantity: 1,
    productionDate: '', expiryDate: '', maintenanceValue: 3, maintenanceUnit: '年',
    unit: '件', price: 0, total: 0, equipmentCode: '', rfidCode: '',
    storageLocation: storage, supplier, isFixedAsset: false, remark: '',
  };
}

/* ─── component ─── */
export default function InInventory() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'type-select' | 'auto-fetch' | 'basic-info' | 'materials' | 'review' | 'success'>('list');
  const [selectedType, setSelectedType] = useState('');
  const [orderNo, setOrderNo] = useState('');
  const [basicInfo, setBasicInfo] = useState<Record<string, string>>({});
  const [materials, setMaterials] = useState<MaterialItem[]>([]);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState('全部');
  const [records, setRecords] = useState(mockHistory);
  const [savedDraft, setSavedDraft] = useState(false);

  // Supplier search
  const [supplierQuery, setSupplierQuery] = useState('');
  const [showSupplierList, setShowSupplierList] = useState(false);
  const supplierRef = useRef<HTMLDivElement>(null);
  const filteredSuppliers = SUPPLIERS.filter(s => s.toLowerCase().includes(supplierQuery.toLowerCase()));

  // Warehouse cascade
  const [selectedWarehouse, setSelectedWarehouse] = useState('');
  const [selectedArea, setSelectedArea] = useState('');

  const typeConfig = inTypes.find(t => t.key === selectedType);
  const isEditable = typeConfig?.editable ?? true;

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (supplierRef.current && !supplierRef.current.contains(e.target as Node)) {
        setShowSupplierList(false);
      }
    }
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  /* ─── actions ─── */
  const handleTypeSelect = (typeKey: string) => {
    setSelectedType(typeKey);
    const config = inTypes.find(t => t.key === typeKey);
    if (!config?.editable) {
      setStep('auto-fetch');
      return;
    }
    setOrderNo(genOrderNo());
    setStep('basic-info');
    setBasicInfo({ inTime: new Date().toLocaleString('zh-CN') });
  };

  const handleSelectAutoItem = (item: AutoFetchItem) => {
    setOrderNo(genOrderNo());
    setMaterials(item.materials.map(m => ({
      ...emptyMaterial(m.storageLocation, m.supplier),
      ...m, id: Date.now().toString() + Math.random().toString(36).slice(2, 5),
      maintenanceValue: 3, maintenanceUnit: '年',
    })));
    setBasicInfo({
      inTime: new Date().toLocaleString('zh-CN'),
      ...(selectedType === 'transfer' ? {
        transferNo: item.id, fromUnit: String(item.fromUnit || ''),
        storageLocation: item.materials[0]?.storageLocation || '',
        transferCount: String(item.count), operator: '',
      } : {
        borrower: String(item.borrower || ''), borrowTime: String(item.borrowTime || ''),
        expectedReturn: String(item.expectedReturn || ''),
        borrowCount: String(item.count), operator: '',
      }),
    });
    setStep('review');
  };

  const handleScanRFID = useCallback(() => {
    const names = ['执法记录仪', '防弹背心', '战术手电', '对讲机', '防刺手套'];
    const mockName = names[Math.floor(Math.random() * names.length)];
    const mockRFID = `RFID${Date.now().toString(36).toUpperCase()}`;

    setMaterials(prev => {
      const existing = prev.find(m => m.name === mockName);
      if (existing) {
        return prev.map(m => m.name === mockName
          ? { ...m, quantity: m.quantity + 1, rfidCode: `${m.rfidCode}, ${mockRFID}`, total: (m.quantity + 1) * m.price }
          : m
        );
      }
      const loc = selectedArea ? `${selectedWarehouse}/${selectedArea}` : basicInfo.storageLocation || '';
      return [...prev, {
        ...emptyMaterial(loc, basicInfo.supplier || ''),
        name: mockName, category: '防护装备', model: 'XZ-2024-A',
        rfidCode: mockRFID, equipmentCode: `EQ${Date.now().toString(36).toUpperCase()}`,
        storageLocation: loc, supplier: basicInfo.supplier || '',
      }];
    });
    setScanResult(`已扫描：${mockRFID} · ${mockName}`);
    setTimeout(() => setScanResult(null), 3000);
  }, [basicInfo.supplier, basicInfo.storageLocation, selectedWarehouse, selectedArea]);

  const updateMaterial = (id: string, field: keyof MaterialItem, value: unknown) => {
    setMaterials(prev => prev.map(m => {
      if (m.id !== id) return m;
      const updated = { ...m, [field]: value };
      if (field === 'quantity' || field === 'price') {
        updated.total = Number(updated.quantity) * Number(updated.price);
      }
      return updated;
    }));
  };

  const removeMaterial = (id: string) => setMaterials(prev => prev.filter(m => m.id !== id));

  const addManualMaterial = () => {
    const loc = selectedArea ? `${selectedWarehouse}/${selectedArea}` : basicInfo.storageLocation || '';
    setMaterials(prev => [...prev, emptyMaterial(loc, basicInfo.supplier || '')]);
  };

  const handleSaveDraft = () => {
    setSavedDraft(true);
    setRecords(prev => [{ id: orderNo, type: selectedType, status: 'draft', createTime: new Date().toLocaleString('zh-CN'), materials: materials.length }, ...prev]);
    setTimeout(() => {
      setStep('list');
      setMaterials([]);
      setBasicInfo({});
      setSavedDraft(false);
    }, 1500);
  };

  const totalQty = materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = materials.reduce((s, m) => s + m.total, 0);

  const filteredRecords = activeFilter === '全部' ? records : activeFilter === '草稿'
    ? records.filter(r => r.status === 'draft')
    : records.filter(r => typeLabelMap[r.type] === activeFilter || (activeFilter === '待入库' && r.status === 'pending'));

  /* ═══════════ STEP: LIST ═══════════ */
  if (step === 'list') {
    return (
      <MobileLayout title="入库管理" showBack rightAction={
        <button onClick={() => setStep('type-select')} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">
          新建入库
        </button>
      }>
        <div className="px-4 pt-3 pb-2 flex gap-2">
          {[
            { label: '入库记录', value: records.length, color: 'text-[#1565c0]' },
            { label: '已入库', value: records.filter(r => r.status === 'completed').length, color: 'text-green-600' },
            { label: '草稿', value: records.filter(r => r.status === 'draft').length, color: 'text-orange-600' },
          ].map(s => (
            <div key={s.label} className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="px-4 py-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {['全部', '采购入库', '调拨入库', '归还入库', '所队入库', '草稿'].map(t => (
              <button
                key={t}
                onClick={() => setActiveFilter(t)}
                className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${
                  activeFilter === t ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600 shadow-sm'
                }`}
              >{t}</button>
            ))}
          </div>
        </div>

        <div className="px-4 pb-4 space-y-2">
          {filteredRecords.map(r => (
            <button
              key={r.id}
              onClick={() => navigate(`/in/${r.id}`)}
              className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{r.id}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white" style={{ backgroundColor: typeColorMap[r.type] }}>
                    {typeLabelMap[r.type]}
                  </span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  r.status === 'completed' ? 'bg-green-50 text-green-600' :
                  r.status === 'draft' ? 'bg-gray-100 text-gray-600' :
                  'bg-orange-50 text-orange-600'
                }`}>
                  {r.status === 'completed' ? '已入库' : r.status === 'draft' ? '草稿' : '待入库'}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center gap-1"><Clock size={10} /> {r.createTime}</span>
                <span>共 {r.materials} 件物资</span>
              </div>
            </button>
          ))}
        </div>

        <button onClick={() => setStep('type-select')} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors">
          <Plus size={24} />
        </button>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: TYPE SELECT ═══════════ */
  if (step === 'type-select') {
    return (
      <MobileLayout title="选择入库类型" showBack onBack={() => setStep('list')}>
        <div className="p-4 space-y-3">
          {inTypes.map(t => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                onClick={() => handleTypeSelect(t.key)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all flex items-center gap-4"
              >
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${t.color}15` }}>
                  <Icon size={24} style={{ color: t.color }} />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-base font-semibold text-gray-800">{t.label}</p>
                    {!t.editable && <span className="px-1.5 py-0.5 bg-purple-50 text-purple-600 rounded text-[10px] font-medium">系统自动</span>}
                  </div>
                  <p className="text-xs text-gray-500 mt-0.5">{t.desc}</p>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            );
          })}
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: AUTO FETCH ═══════════ */
  if (step === 'auto-fetch') {
    const isTransfer = selectedType === 'transfer';
    const list = isTransfer ? transferList : returnList;
    return (
      <MobileLayout title={isTransfer ? '选择调拨单' : '选择借用记录'} showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-purple-50 border border-purple-200 rounded-xl p-3 mb-3">
            <p className="text-xs text-purple-700">
              {isTransfer
                ? '系统已自动获取待确认的调拨单，请选择要入库的调拨单'
                : '系统已自动获取待归还的借用记录，请选择要入库的记录'}
            </p>
          </div>
          <div className="space-y-2">
            {list.map(item => (
              <button
                key={item.id}
                onClick={() => handleSelectAutoItem(item)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{item.id}</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-orange-50 text-orange-600">
                    待确认
                  </span>
                </div>
                {isTransfer ? (
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>发物单位：{String(item.fromUnit || '')}</p>
                    <p>调入单位：{String(item.toUnit || '')}</p>
                    <p>调拨数量：{item.count} 件</p>
                  </div>
                ) : (
                  <div className="text-xs text-gray-500 space-y-1">
                    <p>借用人：{String(item.borrower || '')}</p>
                    <p>借用单位：{String(item.borrowUnit || '')}</p>
                    <p>借用时间：{String(item.borrowTime || '')}</p>
                    <p>归还数量：{item.count} 件</p>
                  </div>
                )}
                <div className="mt-2 pt-2 border-t border-gray-50">
                  <p className="text-[10px] text-gray-400">物资：{item.materials.map(m => `${m.name}x${m.quantity}`).join('、')}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: BASIC INFO ═══════════ */
  if (step === 'basic-info') {
    return (
      <MobileLayout title="基本信息" showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-blue-600">入库单字号</p>
              <p className="text-sm font-semibold text-blue-800 font-mono">{orderNo}</p>
            </div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          {typeConfig && (
            <div className="mb-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-white" style={{ backgroundColor: typeConfig.color }}>
                <typeConfig.icon size={14} /> {typeConfig.label}
              </span>
            </div>
          )}

          <div className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
            {/* Purchase Date — date picker */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">采购日期 <span className="text-red-500">*</span></label>
              <input
                type="date"
                value={basicInfo.purchaseDate || ''}
                onChange={e => setBasicInfo(p => ({ ...p, purchaseDate: e.target.value }))}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>

            {/* Supplier — fuzzy search */}
            <div ref={supplierRef} className="relative">
              <label className="text-xs text-gray-500 mb-1 block">供应商 <span className="text-red-500">*</span></label>
              <div className="relative">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={supplierQuery || basicInfo.supplier || ''}
                  onChange={e => { setSupplierQuery(e.target.value); setBasicInfo(p => ({ ...p, supplier: e.target.value })); setShowSupplierList(true); }}
                  onFocus={() => setShowSupplierList(true)}
                  placeholder="搜索供应商名称"
                  className="w-full bg-gray-50 rounded-xl pl-9 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                />
              </div>
              {showSupplierList && filteredSuppliers.length > 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg max-h-48 overflow-y-auto">
                  {filteredSuppliers.map(s => (
                    <button
                      key={s}
                      onClick={() => { setBasicInfo(p => ({ ...p, supplier: s })); setSupplierQuery(s); setShowSupplierList(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 first:rounded-t-xl last:rounded-b-xl transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              )}
              {showSupplierList && supplierQuery && filteredSuppliers.length === 0 && (
                <div className="absolute z-50 left-0 right-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg p-3 text-xs text-gray-400">
                  未找到匹配的供应商，可输入新供应商名称
                </div>
              )}
            </div>

            {/* Storage Location — warehouse cascade */}
            <div>
              <label className="text-xs text-gray-500 mb-1 block">存储位置 <span className="text-red-500">*</span></label>
              <select
                value={selectedWarehouse}
                onChange={e => { setSelectedWarehouse(e.target.value); setSelectedArea(''); }}
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all mb-2"
              >
                <option value="">选择仓库</option>
                {WAREHOUSES.map(w => <option key={w.name} value={w.name}>{w.name}</option>)}
              </select>
              {selectedWarehouse && (
                <select
                  value={selectedArea}
                  onChange={e => {
                    setSelectedArea(e.target.value);
                    const fullPath = `${selectedWarehouse}/${e.target.value}`;
                    setBasicInfo(p => ({ ...p, storageLocation: fullPath }));
                  }}
                  className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                >
                  <option value="">选择区域</option>
                  {WAREHOUSES.find(w => w.name === selectedWarehouse)?.areas.map(a => <option key={a} value={a}>{a}</option>)}
                </select>
              )}
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">入库时间 <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={basicInfo.inTime || ''}
                readOnly
                className="w-full bg-gray-100 rounded-xl px-4 py-3 text-sm text-gray-600 outline-none"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">经办人</label>
              <input
                type="text"
                value={basicInfo.operator || ''}
                onChange={e => setBasicInfo(p => ({ ...p, operator: e.target.value }))}
                placeholder="请输入经办人姓名"
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">采购项目名称 <span className="text-red-500">*</span></label>
              <input
                type="text"
                value={basicInfo.projectName || ''}
                onChange={e => setBasicInfo(p => ({ ...p, projectName: e.target.value }))}
                placeholder="请输入采购项目名称"
                className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>
          </div>

          <button
            onClick={() => setStep('materials')}
            className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium mt-4 active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2"
          >
            下一步：物资明细 <ArrowRight size={16} />
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: MATERIALS ═══════════ */
  if (step === 'materials') {
    return (
      <MobileLayout title="物资明细" showBack onBack={() => setStep('basic-info')}>
        <div className="p-4">
          {/* Scan */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">扫描RFID编码</p>
                <p className="text-xs text-gray-500">扫描装备RFID标签自动填充信息</p>
              </div>
              <button onClick={handleScanRFID} className="px-4 py-2 bg-[#1565c0] text-white rounded-xl text-sm font-medium active:bg-blue-700 transition-colors">
                扫描
              </button>
            </div>
            {scanResult && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-2.5 flex items-center gap-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <span className="text-xs text-green-700">{scanResult}</span>
              </div>
            )}
          </div>

          {/* Material List */}
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800">物资清单 ({materials.length})</h3>
            <button onClick={addManualMaterial} className="flex items-center gap-1 text-xs text-[#1565c0] font-medium px-3 py-1.5 bg-blue-50 rounded-lg active:bg-blue-100 transition-colors">
              <Plus size={14} /> 手动添加
            </button>
          </div>

          <div className="space-y-3 pb-4">
            {materials.length === 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm text-center text-gray-400">
                <Package size={32} className="mx-auto mb-2" />
                <p className="text-sm">请扫描RFID或手动添加物资</p>
              </div>
            )}
            {materials.map((m, idx) => (
              <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-400">物资 #{idx + 1}</span>
                  <button onClick={() => removeMaterial(m.id)} className="text-red-400 active:text-red-600 p-1">
                    <Trash2 size={14} />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500">物资名称<span className="text-red-500">*</span></label>
                    <input type="text" value={m.name} onChange={e => updateMaterial(m.id, 'name', e.target.value)} placeholder="名称" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">物资类别</label>
                    <input type="text" value={m.category} onChange={e => updateMaterial(m.id, 'category', e.target.value)} placeholder="类别" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">规格型号</label>
                    <input type="text" value={m.model} onChange={e => updateMaterial(m.id, 'model', e.target.value)} placeholder="型号" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none focus:ring-1 focus:ring-blue-200 border border-transparent" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">数量<span className="text-red-500">*</span></label>
                    <div className="flex items-center bg-gray-50 rounded-lg">
                      <button onClick={() => updateMaterial(m.id, 'quantity', Math.max(1, m.quantity - 1))} className="px-2 py-2 active:bg-gray-200 rounded-l-lg"><Minus size={12} /></button>
                      <input type="number" value={m.quantity} onChange={e => updateMaterial(m.id, 'quantity', Number(e.target.value))} className="w-full text-center text-xs bg-transparent outline-none py-2" />
                      <button onClick={() => updateMaterial(m.id, 'quantity', m.quantity + 1)} className="px-2 py-2 active:bg-gray-200 rounded-r-lg"><Plus size={12} /></button>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">单位<span className="text-red-500">*</span></label>
                    <input type="text" value={m.unit} onChange={e => updateMaterial(m.id, 'unit', e.target.value)} placeholder="件" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">单价(¥)<span className="text-red-500">*</span></label>
                    <input type="number" value={m.price || ''} onChange={e => updateMaterial(m.id, 'price', Number(e.target.value))} placeholder="0.00" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">生产日期</label>
                    <input type="date" value={m.productionDate} onChange={e => updateMaterial(m.id, 'productionDate', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">有效期</label>
                    <input type="date" value={m.expiryDate} onChange={e => updateMaterial(m.id, 'expiryDate', e.target.value)} className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>

                  {/* Maintenance Period — quantity + unit */}
                  <div>
                    <label className="text-[10px] text-gray-500">保养期</label>
                    <div className="flex gap-1.5">
                      <input
                        type="number"
                        value={m.maintenanceValue}
                        onChange={e => updateMaterial(m.id, 'maintenanceValue', Number(e.target.value))}
                        className="flex-1 bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none"
                        min={1}
                      />
                      <select
                        value={m.maintenanceUnit}
                        onChange={e => updateMaterial(m.id, 'maintenanceUnit', e.target.value)}
                        className="w-16 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-800 outline-none"
                      >
                        {MAINTENANCE_UNITS.map(u => <option key={u} value={u}>{u}</option>)}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] text-gray-500">装备编码</label>
                    <input type="text" value={m.equipmentCode} onChange={e => updateMaterial(m.id, 'equipmentCode', e.target.value)} placeholder="编码" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">RFID编码</label>
                    <input type="text" value={m.rfidCode} onChange={e => updateMaterial(m.id, 'rfidCode', e.target.value)} placeholder="RFID" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">存储位置<span className="text-red-500">*</span></label>
                    <input type="text" value={m.storageLocation} onChange={e => updateMaterial(m.id, 'storageLocation', e.target.value)} placeholder="仓库/区域" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">供应商</label>
                    <input type="text" value={m.supplier} onChange={e => updateMaterial(m.id, 'supplier', e.target.value)} placeholder="供应商" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">总价(¥)</label>
                    <input type="text" value={m.total.toFixed(2)} readOnly className="w-full bg-gray-100 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none" />
                  </div>
                  <div className="col-span-2">
                    <label className="text-[10px] text-gray-500">备注</label>
                    <input type="text" value={m.remark} onChange={e => updateMaterial(m.id, 'remark', e.target.value)} placeholder="选填" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div className="col-span-2 flex items-center gap-2">
                    <input type="checkbox" checked={m.isFixedAsset} onChange={e => updateMaterial(m.id, 'isFixedAsset', e.target.checked)} className="w-4 h-4 rounded text-[#1565c0]" />
                    <label className="text-xs text-gray-600">固定资产</label>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {materials.length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 mt-3 mb-3">
              <div className="flex items-center justify-between">
                <div><p className="text-xs text-blue-600">合计数量</p><p className="text-lg font-bold text-blue-800">{totalQty} 件</p></div>
                <div className="text-right"><p className="text-xs text-blue-600">合计金额</p><p className="text-lg font-bold text-blue-800">¥{totalAmount.toFixed(2)}</p></div>
              </div>
            </div>
          )}

          <button onClick={() => setStep('review')} disabled={materials.length === 0} className={`w-full py-3.5 rounded-xl font-medium transition-colors mb-6 ${materials.length > 0 ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}>
            提交入库申请
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: REVIEW ═══════════ */
  if (step === 'review') {
    return (
      <MobileLayout title="确认入库" showBack onBack={() => isEditable ? setStep('materials') : setStep('list')}>
        <div className="p-4">
          {savedDraft && (
            <div className="bg-green-50 border border-green-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
              <CheckCircle2 size={20} className="text-green-600" />
              <div>
                <p className="text-sm font-semibold text-green-800">草稿已保存</p>
                <p className="text-xs text-green-600">入库单已保存为草稿，可后续继续编辑</p>
              </div>
            </div>
          )}

          {/* Status */}
          {!savedDraft && (
            <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
              <Clock size={20} className="text-orange-600" />
              <div>
                <p className="text-sm font-semibold text-orange-800">待入库状态</p>
                <p className="text-xs text-orange-600">请核对信息无误后确认入库</p>
              </div>
            </div>
          )}

          {/* Order Summary */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">入库单信息</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">入库单号</span><span className="text-xs text-gray-800 font-mono">{orderNo}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gray-500">入库类型</span><span className="text-xs text-gray-800">{typeConfig?.label}</span></div>
              {Object.entries(basicInfo).filter(([, v]) => v).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-xs text-gray-500">
                    {k === 'projectName' ? '采购项目名称' : k === 'purchaseDate' ? '采购日期' : k === 'supplier' ? '供应商' : k === 'storageLocation' ? '存储位置' : k === 'inTime' ? '入库时间' : k === 'operator' ? '经办人' : k === 'transferNo' ? '调拨单号' : k === 'fromUnit' ? '发物单位' : k === 'toUnit' ? '调入单位' : k === 'transferCount' ? '调拨数量' : k === 'borrower' ? '借用人' : k === 'borrowTime' ? '借用时间' : k === 'expectedReturn' ? '预计归还' : k === 'borrowCount' ? '借用数量' : k}
                  </span>
                  <span className="text-xs text-gray-800">{v}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Materials */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">物资汇总</h3>
            <div className="space-y-2">
              {materials.map((m, i) => (
                <div key={m.id} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">#{i + 1}</span>
                    <span className="text-sm text-gray-700">{m.name}</span>
                    {m.maintenanceValue > 0 && <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">保养{m.maintenanceValue}{m.maintenanceUnit}</span>}
                  </div>
                  <div className="text-right">
                    <span className="text-sm text-gray-900">x{m.quantity}</span>
                    <span className="text-xs text-gray-500 ml-1">{m.unit}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
              <span className="text-sm text-gray-600">共 {materials.length} 种，{totalQty} 件</span>
              <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toFixed(2)}</span>
            </div>
          </div>

          {/* Rules */}
          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <h3 className="text-xs font-semibold text-gray-600 mb-2">业务规则</h3>
            <ul className="space-y-1">
              <li className="text-[10px] text-gray-500">1. 入库记录将永久留存，不可删除</li>
              <li className="text-[10px] text-gray-500">2. 确认入库后将同步更新库存数据</li>
              <li className="text-[10px] text-gray-500">3. RFID编码唯一，同种装备将合并记录</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex gap-2 mb-6">
            <button onClick={() => isEditable ? setStep('materials') : setStep('list')} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium text-sm active:bg-gray-200 transition-colors">
              返回修改
            </button>
            <button onClick={handleSaveDraft} className="flex-1 bg-orange-50 text-orange-600 py-3 rounded-xl font-medium text-sm active:bg-orange-100 transition-colors flex items-center justify-center gap-1">
              <Save size={14} /> 保存草稿
            </button>
            <button onClick={() => setStep('success')} className="flex-1 bg-[#1565c0] text-white py-3 rounded-xl font-medium text-sm active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">
              确认入库
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ STEP: SUCCESS ═══════════ */
  return (
    <MobileLayout title="入库完成" showBack onBack={() => { setStep('list'); setMaterials([]); setBasicInfo({}); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">入库成功</h3>
        <p className="text-sm text-gray-500 text-center mb-1">入库单号：{orderNo}</p>
        <p className="text-sm text-gray-500 text-center mb-6">共入库 {totalQty} 件装备，库存数据已同步更新</p>

        <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6">
          {[
            { label: '入库单号', value: orderNo },
            { label: '入库类型', value: typeConfig?.label || '' },
            { label: '物资种类', value: `${materials.length} 种` },
            { label: '入库总数', value: `${totalQty} 件` },
            { label: '入库时间', value: new Date().toLocaleString('zh-CN') },
            { label: '入库状态', value: '已入库' },
          ].map(item => (
            <div key={item.label} className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{item.label}</span>
              <span className="text-sm text-gray-800">{item.value}</span>
            </div>
          ))}
        </div>

        <button onClick={() => { setStep('list'); setMaterials([]); setBasicInfo({}); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">
          返回入库列表
        </button>
      </div>
    </MobileLayout>
  );
}
