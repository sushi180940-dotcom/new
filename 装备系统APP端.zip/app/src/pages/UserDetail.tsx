import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  User, Shield, ShieldAlert, ShieldCheck, ShieldX,
  Clock, CheckCircle2, AlertTriangle,
  RotateCcw, Building2, Phone,
  MapPin, KeyRound
} from 'lucide-react';
import { mockResetLogs } from './UserManage';

/* ─── types ─── */
interface UserRecord {
  id: string;
  account: string;
  name: string;
  unit: string;
  role: 'senior_admin' | 'admin' | 'user';
  status: 'enabled' | 'disabled' | 'abnormal';
  createTime: string;
  lastLoginTime: string;
  lastLoginIp: string;
  phone: string;
  loginCount: number;
}

interface LoginRecord {
  time: string;
  ip: string;
  device: string;
}

/* ─── mock data ─── */
const mockUsers: Record<string, UserRecord> = {
  U001: { id: 'U001', account: 'admin001', name: '张建国', unit: '省厅装备处', role: 'senior_admin', status: 'enabled', createTime: '2023-01-10 09:00', lastLoginTime: '2024-05-20 08:30', lastLoginIp: '10.168.1.23', phone: '138****0001', loginCount: 328 },
  U002: { id: 'U002', account: 'admin002', name: '李秀芬', unit: '朝阳分局', role: 'admin', status: 'enabled', createTime: '2023-03-15 14:20', lastLoginTime: '2024-05-19 17:45', lastLoginIp: '10.168.2.56', phone: '139****0002', loginCount: 186 },
  U003: { id: 'U003', account: 'u01001', name: '王强', unit: '朝阳分局刑侦大队', role: 'user', status: 'enabled', createTime: '2023-06-01 08:30', lastLoginTime: '2024-05-20 07:15', lastLoginIp: '10.168.3.12', phone: '137****0003', loginCount: 245 },
  U004: { id: 'U004', account: 'u01002', name: '李明', unit: '东城分局巡警支队', role: 'user', status: 'disabled', createTime: '2023-06-01 09:00', lastLoginTime: '2024-04-28 16:30', lastLoginIp: '10.168.4.34', phone: '136****0004', loginCount: 112 },
  U005: { id: 'U005', account: 'u01003', name: '赵刚', unit: '西城分局特警大队', role: 'user', status: 'enabled', createTime: '2023-08-12 10:15', lastLoginTime: '2024-05-18 20:00', lastLoginIp: '10.168.5.78', phone: '135****0005', loginCount: 198 },
  U006: { id: 'U006', account: 'u01004', name: '孙丽', unit: '海淀分局治安大队', role: 'user', status: 'enabled', createTime: '2023-09-05 11:30', lastLoginTime: '2024-05-20 09:00', lastLoginIp: '10.168.6.90', phone: '134****0006', loginCount: 167 },
  U007: { id: 'U007', account: 'u01005', name: '周涛', unit: '丰台分局交警大队', role: 'user', status: 'enabled', createTime: '2023-10-20 13:45', lastLoginTime: '2024-05-19 18:30', lastLoginIp: '10.168.7.45', phone: '133****0007', loginCount: 203 },
  U008: { id: 'U008', account: 'u01006', name: '张伟', unit: '昌平分局刑警大队', role: 'user', status: 'enabled', createTime: '2024-01-08 08:00', lastLoginTime: '2024-05-17 15:20', lastLoginIp: '10.168.8.67', phone: '132****0008', loginCount: 89 },
  U009: { id: 'U009', account: 'u01007', name: '刘洋', unit: '通州分局派出所', role: 'user', status: 'enabled', createTime: '2024-02-14 09:30', lastLoginTime: '2024-05-20 06:50', lastLoginIp: '10.168.9.12', phone: '131****0009', loginCount: 56 },
  U010: { id: 'U010', account: 'u01008', name: '陈静', unit: '大兴分局治安大队', role: 'user', status: 'abnormal', createTime: '2024-03-01 10:00', lastLoginTime: '2024-05-10 11:00', lastLoginIp: '10.168.10.88', phone: '130****0010', loginCount: 34 },
};

const mockLoginRecords: Record<string, LoginRecord[]> = {
  U001: [
    { time: '2024-05-20 08:30', ip: '10.168.1.23', device: 'iPhone 15 Pro' },
    { time: '2024-05-19 17:20', ip: '10.168.1.23', device: 'iPhone 15 Pro' },
    { time: '2024-05-19 08:15', ip: '10.168.1.45', device: 'PC Windows' },
    { time: '2024-05-18 16:45', ip: '10.168.1.23', device: 'iPhone 15 Pro' },
    { time: '2024-05-18 08:00', ip: '10.168.1.23', device: 'iPhone 15 Pro' },
  ],
  U003: [
    { time: '2024-05-20 07:15', ip: '10.168.3.12', device: '华为 Mate60' },
    { time: '2024-05-19 18:30', ip: '10.168.3.12', device: '华为 Mate60' },
    { time: '2024-05-19 07:00', ip: '10.168.3.45', device: 'PC Windows' },
    { time: '2024-05-17 17:00', ip: '10.168.3.12', device: '华为 Mate60' },
    { time: '2024-05-16 08:20', ip: '10.168.3.12', device: '华为 Mate60' },
  ],
  U010: [
    { time: '2024-05-10 11:00', ip: '10.168.10.88', device: 'iPhone 14' },
    { time: '2024-05-08 15:30', ip: '10.168.10.90', device: '未知设备' },
    { time: '2024-05-05 09:00', ip: '10.168.10.88', device: 'iPhone 14' },
    { time: '2024-05-01 14:20', ip: '10.168.10.88', device: 'iPhone 14' },
    { time: '2024-04-28 08:10', ip: '10.168.10.88', device: 'iPhone 14' },
  ],
};

/* ─── config ─── */
const roleConfig: Record<string, { label: string; color: string; bg: string; desc: string; permissions: string[] }> = {
  senior_admin: {
    label: '高级管理员', color: 'text-red-600', bg: 'bg-red-50',
    desc: '拥有全部管理权限，可操作所有辖区用户',
    permissions: ['用户查询', '密码重置', '权限分配', '管辖范围管理'],
  },
  admin: {
    label: '普通管理员', color: 'text-orange-600', bg: 'bg-orange-50',
    desc: '仅可查看用户信息，无操作权限',
    permissions: ['用户查询（只读）'],
  },
  user: {
    label: '普通用户', color: 'text-blue-600', bg: 'bg-blue-50',
    desc: '普通警员，无管理权限',
    permissions: ['个人信息查看'],
  },
};

const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType; desc: string }> = {
  enabled:  { label: '启用', color: 'text-green-600', bg: 'bg-green-50', icon: ShieldCheck, desc: '账号正常使用中' },
  disabled: { label: '禁用', color: 'text-gray-500', bg: 'bg-gray-100', icon: ShieldX, desc: '账号已被禁用，无法登录' },
  abnormal: { label: '异常', color: 'text-red-600', bg: 'bg-red-50', icon: AlertTriangle, desc: '账号存在异常，建议重置密码' },
};

// Current login user
const CURRENT_USER = mockUsers.U001;

/* ─── main component ─── */
export default function UserDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = mockUsers[id || ''];

  if (!user) {
    return (
      <MobileLayout title="用户详情" showBack onBack={() => navigate('/users')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <User size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到用户信息</p>
        </div>
      </MobileLayout>
    );
  }

  const rc = roleConfig[user.role];
  const sc = statusConfig[user.status];
  const StatusIcon = sc.icon;
  const loginRecords = mockLoginRecords[user.id] || [];
  const userResetLogs = mockResetLogs.filter(l => l.targetUser === user.id);
  const isSeniorAdmin = CURRENT_USER.role === 'senior_admin';
  const canReset = isSeniorAdmin && (user.status === 'abnormal' || user.status === 'disabled');
  const isSelf = user.id === CURRENT_USER.id;

  return (
    <MobileLayout title="用户详情" showBack onBack={() => navigate('/users')}>
      <div className="p-4">
        {/* ── User Info Card ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
              user.status === 'abnormal' ? 'bg-red-50' :
              user.status === 'disabled' ? 'bg-gray-100' :
              user.role === 'senior_admin' ? 'bg-red-50' :
              user.role === 'admin' ? 'bg-orange-50' : 'bg-blue-50'
            }`}>
              <span className={`text-2xl font-bold ${
                user.status === 'abnormal' ? 'text-red-600' :
                user.status === 'disabled' ? 'text-gray-500' :
                user.role === 'senior_admin' ? 'text-red-600' :
                user.role === 'admin' ? 'text-orange-600' : 'text-blue-600'
              }`}>
                {user.name[0]}
              </span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-base font-bold text-gray-900">{user.name}</h3>
                <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>
                  {sc.label}
                </span>
              </div>
              <div className="flex items-center gap-1.5 mb-1">
                <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${rc.bg} ${rc.color}`}>
                  {rc.label}
                </span>
                <span className="text-xs text-gray-500 font-mono">{user.account}</span>
              </div>
              <p className="text-xs text-gray-500 flex items-center gap-1">
                <Building2 size={10} /> {user.unit}
              </p>
            </div>
          </div>

          {/* Detail Info */}
          <div className="space-y-2">
            <div className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <Phone size={10} /> 联系电话
              </span>
              <span className="text-xs text-gray-800 font-medium">{user.phone}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <MapPin size={10} /> 所属单位
              </span>
              <span className="text-xs text-gray-800 font-medium">{user.unit}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <Clock size={10} /> 创建时间
              </span>
              <span className="text-xs text-gray-800 font-medium">{user.createTime}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-50">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <KeyRound size={10} /> 登录次数
              </span>
              <span className="text-xs text-gray-800 font-medium">{user.loginCount} 次</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <CheckCircle2 size={10} /> 最后登录
              </span>
              <span className="text-xs text-gray-800 font-medium">{user.lastLoginTime}</span>
            </div>
            <div className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                <MapPin size={10} /> 登录IP
              </span>
              <span className="text-xs text-gray-800 font-mono">{user.lastLoginIp}</span>
            </div>
          </div>
        </div>

        {/* ── Role & Permissions ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Shield size={14} className="text-[#1565c0]" /> 角色与权限
          </h3>
          <div className="bg-gray-50 rounded-xl p-3 mb-3">
            <div className="flex items-center gap-2 mb-2">
              <span className={`px-2 py-0.5 rounded text-xs font-medium ${rc.bg} ${rc.color}`}>
                {rc.label}
              </span>
            </div>
            <p className="text-xs text-gray-600 mb-2">{rc.desc}</p>
            <div className="flex flex-wrap gap-1.5">
              {rc.permissions.map(p => (
                <span key={p} className="px-2 py-0.5 rounded bg-white text-[10px] text-gray-600 border border-gray-200">
                  {p}
                </span>
              ))}
            </div>
          </div>

          {/* Status description */}
          <div className={`rounded-xl p-3 ${sc.bg}`}>
            <div className="flex items-center gap-2 mb-1">
              <StatusIcon size={14} className={sc.color} />
              <span className={`text-xs font-medium ${sc.color}`}>账号{sc.label}</span>
            </div>
            <p className="text-xs text-gray-600">{sc.desc}</p>
          </div>
        </div>

        {/* ── Login Records ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Clock size={14} className="text-[#1565c0]" /> 最近登录记录
          </h3>
          {loginRecords.length > 0 ? (
            <div className="space-y-2">
              {loginRecords.map((r, i) => (
                <div key={i} className="flex items-center gap-3 py-2 border-b border-gray-50 last:border-0">
                  <div className="w-8 h-8 rounded-lg bg-gray-50 flex items-center justify-center shrink-0">
                    <span className="text-[10px] text-gray-400 font-mono">{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-gray-800 font-medium">{r.time}</p>
                    <p className="text-[10px] text-gray-500">{r.device}</p>
                  </div>
                  <span className="text-[10px] text-gray-500 font-mono shrink-0">{r.ip}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-400">
              <Clock size={24} className="mx-auto mb-1 opacity-50" />
              <p className="text-xs">暂无登录记录</p>
            </div>
          )}
        </div>

        {/* ── Reset Logs Timeline ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <RotateCcw size={14} className="text-[#1565c0]" /> 密码重置记录
          </h3>
          {userResetLogs.length > 0 ? (
            <div className="space-y-0">
              {userResetLogs.map((log, i, arr) => (
                <div key={log.id} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-7 h-7 rounded-full bg-amber-500 flex items-center justify-center">
                      <RotateCcw size={12} className="text-white" />
                    </div>
                    {i < arr.length - 1 && <div className="w-0.5 h-10 bg-gray-200" />}
                  </div>
                  <div className="pb-4 flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-medium text-gray-800">密码重置</p>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-50 text-amber-600">
                        {log.reason}
                      </span>
                    </div>
                    <p className="text-[10px] text-gray-500 mb-1">
                      操作人：{log.operator} · {log.operateTime}
                    </p>
                    {log.remark && (
                      <p className="text-[10px] text-gray-400 bg-gray-50 rounded-lg px-2 py-1">
                        {log.remark}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-6 text-gray-400">
              <RotateCcw size={24} className="mx-auto mb-1 opacity-50" />
              <p className="text-xs">暂无重置记录</p>
            </div>
          )}
        </div>

        {/* ── Permission Warning ── */}
        {!isSeniorAdmin && (
          <div className="bg-orange-50 rounded-xl p-3 mb-4 flex items-center gap-2">
            <ShieldAlert size={14} className="text-orange-500 shrink-0" />
            <p className="text-xs text-orange-600">
              您为普通管理员身份，仅可查看信息，无操作权限
            </p>
          </div>
        )}

        {/* ── Self Warning ── */}
        {isSelf && isSeniorAdmin && (
          <div className="bg-blue-50 rounded-xl p-3 mb-4 flex items-center gap-2">
            <ShieldCheck size={14} className="text-blue-500 shrink-0" />
            <p className="text-xs text-blue-600">
              这是您自己的账号，重置密码需谨慎
            </p>
          </div>
        )}
      </div>

      {/* ── Bottom Action ── */}
      {isSeniorAdmin && !isSelf && (
        <div className="sticky bottom-0 left-0 right-0 p-4 bg-[#f0f4f8] border-t border-gray-200/60">
          <button
            onClick={() => navigate(`/users/${user.id}/reset`)}
            disabled={!canReset}
            className={`w-full py-3.5 rounded-xl font-medium text-sm flex items-center justify-center gap-2 transition-all ${
              canReset
                ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'
                : 'bg-gray-200 text-gray-400'
            }`}
          >
            <RotateCcw size={16} />
            {user.status === 'abnormal' ? '重置密码（账号异常）' :
             user.status === 'disabled' ? '重置密码（账号禁用）' :
             '账号正常，无需重置'}
          </button>
          {!canReset && (
            <p className="text-[10px] text-gray-400 text-center mt-2">
              仅账号异常或禁用状态下可发起重置
            </p>
          )}
        </div>
      )}
    </MobileLayout>
  );
}
