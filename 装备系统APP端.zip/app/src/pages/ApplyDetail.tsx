import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  CheckCircle2, X, Clock, Package, ClipboardList,
  User, Building2, CircleDot, FileText, Shield
} from 'lucide-react';

/* ─── types ─── */
interface ApplyItem {
  id: string;
  name: string;
  category: string;
  model: string;
  quantity: number;
  unit: string;
  equipmentCode: string;
  rfidCode: string;
  price: number;
  total: number;
  supplier: string;
}

interface TimelineNode {
  label: string;
  time: string;
  done: boolean;
  active?: boolean;
  type: 'submit' | 'approve' | 'issue' | 'reject';
}

interface ApplyOrderDetail {
  id: string;
  status: 'pending' | 'approved' | 'rejected' | 'issued';
  applyTime: string;
  applicant: string;
  applyUnit: string;
  applyType: 'personal' | 'unit';
  reason: string;
  approver?: string;
  approveTime?: string;
  approveOpinion?: string;
  issuer?: string;
  issueTime?: string;
  items: ApplyItem[];
  timeline: TimelineNode[];
}

/* ─── status config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending:  { label: '审批中',  color: 'text-orange-600', bg: 'bg-orange-50',  icon: Clock },
  approved: { label: '已通过',  color: 'text-blue-600',   bg: 'bg-blue-50',   icon: CheckCircle2 },
  rejected: { label: '已驳回',  color: 'text-red-600',    bg: 'bg-red-50',    icon: X },
  issued:   { label: '已发放',  color: 'text-green-600',  bg: 'bg-green-50',  icon: CheckCircle2 },
};

/* ─── mock detail data ─── */
const mockDetailData: Record<string, ApplyOrderDetail> = {
  SQ20240520001: {
    id: 'SQ20240520001',
    status: 'pending',
    applyTime: '2024-05-20 09:15',
    applicant: '王强',
    applyUnit: '朝阳分局刑侦大队',
    applyType: 'personal',
    reason: '外出执行抓捕任务，需补充防护装备',
    items: [
      { id: '1', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 2, unit: '件', equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B,RFID202301058C', price: 1200, total: 2400, supplier: '红星装备厂' },
      { id: '2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 3, unit: '个', equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C~E', price: 280, total: 840, supplier: '红星装备厂' },
    ],
    timeline: [
      { label: '提交申请', time: '2024-05-20 09:15', done: true, type: 'submit' },
      { label: '审批中', time: '', done: true, active: true, type: 'approve' },
    ],
  },
  SQ20240519002: {
    id: 'SQ20240519002',
    status: 'approved',
    applyTime: '2024-05-19 14:30',
    applicant: '李明',
    applyUnit: '东城分局巡警支队',
    applyType: 'unit',
    reason: '夏季巡逻装备更新',
    approver: '张局长',
    approveTime: '2024-05-19 16:00',
    approveOpinion: '同意，请尽快发放',
    items: [
      { id: '3', name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 10, unit: '双', equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A~J', price: 150, total: 1500, supplier: '盾甲科技' },
    ],
    timeline: [
      { label: '提交申请', time: '2024-05-19 14:30', done: true, type: 'submit' },
      { label: '审批中', time: '2024-05-19 14:35', done: true, type: 'approve' },
      { label: '审批通过', time: '2024-05-19 16:00', done: true, type: 'issue' },
    ],
  },
  SQ20240518003: {
    id: 'SQ20240518003',
    status: 'issued',
    applyTime: '2024-05-18 10:20',
    applicant: '赵刚',
    applyUnit: '西城分局特警大队',
    applyType: 'personal',
    reason: '日常执勤使用',
    approver: '李支队长',
    approveTime: '2024-05-18 11:30',
    approveOpinion: '同意发放',
    issuer: '张丽',
    issueTime: '2024-05-18 14:00',
    items: [
      { id: '4', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', price: 1800, total: 1800, supplier: '红星装备厂' },
    ],
    timeline: [
      { label: '提交申请', time: '2024-05-18 10:20', done: true, type: 'submit' },
      { label: '审批中', time: '2024-05-18 10:25', done: true, type: 'approve' },
      { label: '审批通过', time: '2024-05-18 11:30', done: true, type: 'issue' },
      { label: '物资已发放', time: '2024-05-18 14:00', done: true, type: 'issue' },
    ],
  },
  SQ20240517004: {
    id: 'SQ20240517004',
    status: 'rejected',
    applyTime: '2024-05-17 16:45',
    applicant: '孙丽',
    applyUnit: '海淀分局治安大队',
    applyType: 'personal',
    reason: '装备更换',
    approver: '王大队长',
    approveTime: '2024-05-17 17:30',
    approveOpinion: '库存不足，暂时无法发放，请等待下一批采购',
    items: [
      { id: '5', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 2, unit: '台', equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D,RFID202401089E', price: 650, total: 1300, supplier: '国安器材' },
    ],
    timeline: [
      { label: '提交申请', time: '2024-05-17 16:45', done: true, type: 'submit' },
      { label: '审批中', time: '2024-05-17 16:50', done: true, type: 'approve' },
      { label: '审批驳回', time: '2024-05-17 17:30', done: true, type: 'reject' },
    ],
  },
  SQ20240515005: {
    id: 'SQ20240515005',
    status: 'issued',
    applyTime: '2024-05-15 08:30',
    applicant: '周涛',
    applyUnit: '丰台分局交警大队',
    applyType: 'unit',
    reason: '路面执法装备补充',
    approver: '刘大队长',
    approveTime: '2024-05-15 10:00',
    approveOpinion: '同意',
    issuer: '李建国',
    issueTime: '2024-05-15 11:30',
    items: [
      { id: '6', name: '警用盾牌', category: '防护装备', model: 'JYPD-2024', quantity: 4, unit: '面', equipmentCode: 'EQ202401099', rfidCode: 'RFID202401099A~D', price: 320, total: 1280, supplier: '盾甲科技' },
    ],
    timeline: [
      { label: '提交申请', time: '2024-05-15 08:30', done: true, type: 'submit' },
      { label: '审批中', time: '2024-05-15 08:35', done: true, type: 'approve' },
      { label: '审批通过', time: '2024-05-15 10:00', done: true, type: 'issue' },
      { label: '物资已发放', time: '2024-05-15 11:30', done: true, type: 'issue' },
    ],
  },
};

/* ─── main component ─── */
export default function ApplyDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const detail = mockDetailData[id || ''];

  if (!detail) {
    return (
      <MobileLayout title="申领详情" showBack onBack={() => navigate('/apply')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <ClipboardList size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到申领记录</p>
        </div>
      </MobileLayout>
    );
  }

  const cfg = statusConfig[detail.status];
  const StatusIcon = cfg.icon;
  const totalQty = detail.items.reduce((s, i) => s + i.quantity, 0);
  const totalAmount = detail.items.reduce((s, i) => s + i.total, 0);

  return (
    <MobileLayout title="申领详情" showBack onBack={() => navigate('/apply')}>
      <div className="p-4">
        {/* ── Status Card ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${cfg.bg}`}>
              <StatusIcon size={24} className={cfg.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{detail.id}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium text-white ${
                  detail.status === 'pending' ? 'bg-orange-500' :
                  detail.status === 'approved' ? 'bg-blue-500' :
                  detail.status === 'rejected' ? 'bg-red-500' : 'bg-green-500'
                }`}>
                  {cfg.label}
                </span>
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-gray-500">{detail.applyTime} 提交</span>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请人</p>
              <p className="text-xs text-gray-800 font-medium">{detail.applicant}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请类型</p>
              <p className="text-xs text-gray-800 font-medium">{detail.applyType === 'personal' ? '个人申领' : '单位申领'}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">所属单位</p>
              <p className="text-xs text-gray-800 font-medium">{detail.applyUnit}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">物资总数</p>
              <p className="text-xs text-gray-800 font-medium">{totalQty} 件</p>
            </div>
          </div>
        </div>

        {/* ── Applicant Info ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <User size={14} className="text-[#1565c0]" /> 申请人信息
          </h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-xs text-gray-500 flex items-center gap-1">
                {detail.applyType === 'personal' ? <User size={10} /> : <Building2 size={10} />}
                {detail.applyType === 'personal' ? '申请人' : '申请单位'}
              </span>
              <span className="text-xs text-gray-800 font-medium">{detail.applicant}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-xs text-gray-500">所属单位</span>
              <span className="text-xs text-gray-800 font-medium">{detail.applyUnit}</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50">
              <span className="text-xs text-gray-500">申请类型</span>
              <span className="text-xs text-gray-800 font-medium">
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                  detail.applyType === 'personal' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
                }`}>
                  {detail.applyType === 'personal' ? '个人申领' : '单位申领'}
                </span>
              </span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">申请时间</span>
              <span className="text-xs text-gray-800 font-medium">{detail.applyTime}</span>
            </div>
          </div>
        </div>

        {/* ── Reason ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <FileText size={14} className="text-[#1565c0]" /> 申领原因
          </h3>
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-sm text-gray-700 leading-relaxed">{detail.reason}</p>
          </div>
        </div>

        {/* ── Materials ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Package size={14} className="text-[#1565c0]" /> 物资明细 ({detail.items.length})
          </h3>
          <div className="space-y-3">
            {detail.items.map((item, i) => (
              <div key={item.id} className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{item.name}</span>
                    <span className="text-[10px] text-gray-500 bg-white px-1.5 py-0.5 rounded">{item.category}</span>
                  </div>
                  <span className="text-sm font-bold text-[#1565c0]">¥{item.total.toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>型号：{item.model}</span>
                  <span>数量：{item.quantity} {item.unit}</span>
                  <span>编号：{item.equipmentCode}</span>
                  <span>RFID：{item.rfidCode}</span>
                  <span>单价：¥{item.price}</span>
                  <span>供应商：{item.supplier}</span>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
            <span className="text-sm text-gray-600">共 {detail.items.length} 种，{totalQty} 件</span>
            <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toLocaleString()}</span>
          </div>
        </div>

        {/* ── Approval Info (if approved/issued/rejected) ── */}
        {(detail.status === 'approved' || detail.status === 'issued' || detail.status === 'rejected') && (
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Shield size={14} className="text-[#1565c0]" /> 审批信息
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">审批人</span>
                <span className="text-xs text-gray-800 font-medium">{detail.approver}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">审批时间</span>
                <span className="text-xs text-gray-800 font-medium">{detail.approveTime}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">审批结果</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${
                  detail.status === 'rejected' ? 'bg-red-50 text-red-600' : 'bg-green-50 text-green-600'
                }`}>
                  {detail.status === 'rejected' ? '驳回' : '通过'}
                </span>
              </div>
              <div className="bg-gray-50 rounded-xl p-3 mt-2">
                <p className="text-[10px] text-gray-500 mb-1">审批意见</p>
                <p className="text-xs text-gray-700">{detail.approveOpinion}</p>
              </div>
            </div>
          </div>
        )}

        {/* ── Issue Info (if issued) ── */}
        {detail.status === 'issued' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Package size={14} className="text-green-600" /> 发放信息
            </h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-1.5 border-b border-gray-50">
                <span className="text-xs text-gray-500">发放人</span>
                <span className="text-xs text-gray-800 font-medium">{detail.issuer}</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">发放时间</span>
                <span className="text-xs text-gray-800 font-medium">{detail.issueTime}</span>
              </div>
            </div>
          </div>
        )}

        {/* ── Timeline ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Clock size={14} className="text-[#1565c0]" /> 状态流转
          </h3>
          <div className="space-y-0">
            {detail.timeline.map((node, i, arr) => (
              <div key={i} className="flex gap-3">
                {/* Timeline dot & line */}
                <div className="flex flex-col items-center">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    node.type === 'reject'
                      ? 'bg-red-500'
                      : node.done
                        ? 'bg-green-500'
                        : node.active
                          ? 'bg-orange-500'
                          : 'bg-gray-300'
                  }`}>
                    {node.type === 'reject' ? (
                      <X size={14} className="text-white" />
                    ) : node.done ? (
                      <CheckCircle2 size={14} className="text-white" />
                    ) : node.active ? (
                      <Clock size={14} className="text-white" />
                    ) : (
                      <CircleDot size={14} className="text-white" />
                    )}
                  </div>
                  {i < arr.length - 1 && (
                    <div className={`w-0.5 h-8 ${
                      arr[i + 1]?.done ? 'bg-green-200' : 'bg-gray-200'
                    }`} />
                  )}
                </div>
                {/* Content */}
                <div className="pb-5">
                  <div className="flex items-center gap-2">
                    <p className={`text-sm font-medium ${
                      node.done
                        ? node.type === 'reject' ? 'text-red-700' : 'text-gray-800'
                        : node.active
                          ? 'text-orange-700'
                          : 'text-gray-400'
                    }`}>
                      {node.label}
                    </p>
                    {node.active && (
                      <span className="px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-orange-100 text-orange-600 animate-pulse">
                        进行中
                      </span>
                    )}
                  </div>
                  {node.time && (
                    <p className="text-[10px] text-gray-400 mt-0.5">{node.time}</p>
                  )}
                </div>
              </div>
            ))}

            {/* Future nodes */}
            {detail.status === 'pending' && (
              <>
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
                      <CheckCircle2 size={14} className="text-white" />
                    </div>
                    <div className="w-0.5 h-8 bg-gray-200" />
                  </div>
                  <div className="pb-5">
                    <p className="text-sm text-gray-400">审批结果</p>
                    <p className="text-[10px] text-gray-400">等待审批</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
                      <Package size={14} className="text-white" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">物资发放</p>
                    <p className="text-[10px] text-gray-400">等待发放</p>
                  </div>
                </div>
              </>
            )}
            {detail.status === 'approved' && (
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
                    <Package size={14} className="text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">物资发放</p>
                  <p className="text-[10px] text-gray-400">等待发放</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
