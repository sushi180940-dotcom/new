import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { personalEquipment } from '@/data/mock';
import {
  Package, Shield, Clock, CheckCircle2, AlertTriangle, Wrench,
  ChevronRight, CalendarDays
} from 'lucide-react';

const statusMap: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  normal: { label: '正常', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  repair: { label: '维修中', color: 'text-orange-600', bg: 'bg-orange-50', icon: Wrench },
  warning: { label: '预警', color: 'text-red-600', bg: 'bg-red-50', icon: AlertTriangle },
};

/* ─── days until expiry ─── */
function getDaysUntil(dateStr: string): number {
  const target = new Date(dateStr);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

/* ─── expiry alert config ─── */
function getExpiryAlert(days: number): { label: string; color: string; bg: string } | null {
  if (days < 0) return { label: '已超期', color: 'text-red-600', bg: 'bg-red-50' };
  if (days <= 3) return { label: `${days}天后到期`, color: 'text-red-600', bg: 'bg-red-50' };
  if (days <= 7) return { label: `${days}天后到期`, color: 'text-orange-600', bg: 'bg-orange-50' };
  return null;
}

export default function PersonalEquipment() {
  const navigate = useNavigate();
  const permanentEq = personalEquipment.filter(e => e.type === 'permanent');
  const tempEq = personalEquipment.filter(e => e.type === 'temporary');

  return (
    <MobileLayout title="个人装备" showBack>
      <div className="p-4">
        {/* Summary */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center">
              <Package size={24} className="text-blue-600" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-gray-900">我的装备</h3>
              <p className="text-xs text-gray-500">共持有 {personalEquipment.length} 件装备</p>
            </div>
          </div>
          <div className="flex gap-2">
            <div className="flex-1 bg-blue-50 rounded-xl p-2.5 text-center">
              <p className="text-lg font-bold text-[#1565c0]">{permanentEq.length}</p>
              <p className="text-[10px] text-blue-600">常态配备</p>
            </div>
            <div className="flex-1 bg-orange-50 rounded-xl p-2.5 text-center">
              <p className="text-lg font-bold text-orange-600">{tempEq.length}</p>
              <p className="text-[10px] text-orange-600">临时领用</p>
            </div>
          </div>
        </div>

        {/* Permanent Equipment */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Shield size={14} className="text-blue-600" /> 常态配备
          </h3>
          <div className="space-y-2">
            {permanentEq.map(item => {
              const cfg = statusMap[item.status];
              const StatusIcon = cfg.icon;
              const daysUntilExpiry = getDaysUntil(item.expiryDate);
              const expiryAlert = getExpiryAlert(daysUntilExpiry);
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(`/profile/equipment/${item.id}`)}
                  className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl text-left active:bg-gray-100 transition-colors"
                >
                  <div className={`w-9 h-9 rounded-lg ${cfg.bg} flex items-center justify-center shrink-0`}>
                    <StatusIcon size={16} className={cfg.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-gray-800">{item.name}</p>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${cfg.bg} ${cfg.color}`}>
                        {cfg.label}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">{item.category} · {item.equipmentCode}</p>
                    <p className="text-xs text-gray-400 mt-0.5">型号：{item.model} · 数量：{item.quantity} {item.unit}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                        <CalendarDays size={9} /> 配发：{item.issueDate}
                      </span>
                    </div>
                    {/* Expiry alert for permanent */}
                    {expiryAlert && (
                      <div className={`flex items-center gap-1 mt-1.5 px-2 py-1 rounded-lg ${expiryAlert.bg}`}>
                        <AlertTriangle size={10} className={expiryAlert.color} />
                        <span className={`text-[10px] font-medium ${expiryAlert.color}`}>
                          有效期{expiryAlert.label}（{item.expiryDate}）
                        </span>
                      </div>
                    )}
                  </div>
                  <ChevronRight size={16} className="text-gray-400 shrink-0" />
                </button>
              );
            })}
          </div>
        </div>

        {/* Temporary Equipment */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Clock size={14} className="text-orange-600" /> 临时领用
          </h3>
          <div className="space-y-2">
            {tempEq.map(item => {
              const cfg = statusMap[item.status];
              const StatusIcon = cfg.icon;
              const returnDays = item.returnDate ? getDaysUntil(item.returnDate) : null;
              const returnAlert = returnDays !== null ? getExpiryAlert(returnDays) : null;
              return (
                <button
                  key={item.id}
                  onClick={() => navigate(`/profile/equipment/${item.id}`)}
                  className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl text-left active:bg-gray-100 transition-colors"
                >
                  <div className={`w-9 h-9 rounded-lg ${cfg.bg} flex items-center justify-center shrink-0`}>
                    <StatusIcon size={16} className={cfg.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-medium text-gray-800">{item.name}</p>
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${cfg.bg} ${cfg.color}`}>
                        {cfg.label}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500">{item.category} · {item.equipmentCode}</p>
                    <p className="text-xs text-gray-400 mt-0.5">型号：{item.model} · 数量：{item.quantity} {item.unit}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-[10px] text-gray-400">领用：{item.issueDate}</span>
                      <span className="text-[10px] text-orange-500">归还：{item.returnDate}</span>
                    </div>
                    {/* Return date alert */}
                    {returnAlert && (
                      <div className={`flex items-center gap-1 mt-1.5 px-2 py-1 rounded-lg ${returnAlert.bg}`}>
                        <AlertTriangle size={10} className={returnAlert.color} />
                        <span className={`text-[10px] font-medium ${returnAlert.color}`}>
                          {returnDays !== null && returnDays < 0
                            ? '已超期，请尽快归还'
                            : `临时领用${returnAlert.label}，请按时归还`}
                        </span>
                      </div>
                    )}
                    {!returnAlert && returnDays !== null && returnDays > 7 && (
                      <div className="flex items-center gap-1 mt-1.5 px-2 py-1 rounded-lg bg-green-50">
                        <CheckCircle2 size={10} className="text-green-600" />
                        <span className="text-[10px] text-green-600 font-medium">
                          {returnDays}天后归还（{item.returnDate}）
                        </span>
                      </div>
                    )}
                  </div>
                  <ChevronRight size={16} className="text-gray-400 shrink-0" />
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
