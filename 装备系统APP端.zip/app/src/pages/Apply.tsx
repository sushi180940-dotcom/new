import { useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  ClipboardList, Plus, ChevronRight, CheckCircle2, Clock,
  X, Package, Search, Minus, User, Building2
} from 'lucide-react';

/* ─── types ─── */
interface ApplyItem {
  id: string;
  name: string;
  category: string;
  model: string;
  quantity: number;
  unit: string;
  equipmentCode: string;
  rfidCode: string;
  price: number;
  total: number;
  supplier: string;
  maxQty: number;
}

interface ApplyOrder {
  id: string;
  status: 'pending' | 'approved' | 'rejected' | 'issued';
  applyTime: string;
  applicant: string;
  applyUnit: string;
  applyType: 'personal' | 'unit';
  reason: string;
  approver?: string;
  approveTime?: string;
  items: ApplyItem[];
}

/* ─── mock data ─── */
const mockOrders: ApplyOrder[] = [
  {
    id: 'SQ20240520001', status: 'pending', applyTime: '2024-05-20 09:15',
    applicant: '王强', applyUnit: '朝阳分局刑侦大队', applyType: 'personal',
    reason: '外出执行抓捕任务，需补充防护装备', items: [
      { id: '1', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 2, unit: '件', equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B,RFID202301058C', price: 1200, total: 2400, supplier: '红星装备厂', maxQty: 15 },
      { id: '2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 3, unit: '个', equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C~E', price: 280, total: 840, supplier: '红星装备厂', maxQty: 20 },
    ],
  },
  {
    id: 'SQ20240519002', status: 'approved', applyTime: '2024-05-19 14:30',
    applicant: '李明', applyUnit: '东城分局巡警支队', applyType: 'unit',
    reason: '夏季巡逻装备更新', approver: '张局长', approveTime: '2024-05-19 16:00',
    items: [
      { id: '3', name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 10, unit: '双', equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A~J', price: 150, total: 1500, supplier: '盾甲科技', maxQty: 10 },
    ],
  },
  {
    id: 'SQ20240518003', status: 'issued', applyTime: '2024-05-18 10:20',
    applicant: '赵刚', applyUnit: '西城分局特警大队', applyType: 'personal',
    reason: '日常执勤使用', approver: '李支队长', approveTime: '2024-05-18 11:30',
    items: [
      { id: '4', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', price: 1800, total: 1800, supplier: '红星装备厂', maxQty: 8 },
    ],
  },
  {
    id: 'SQ20240517004', status: 'rejected', applyTime: '2024-05-17 16:45',
    applicant: '孙丽', applyUnit: '海淀分局治安大队', applyType: 'personal',
    reason: '装备更换', approver: '王大队长', approveTime: '2024-05-17 17:30',
    items: [
      { id: '5', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 2, unit: '台', equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D,RFID202401089E', price: 650, total: 1300, supplier: '国安器材', maxQty: 6 },
    ],
  },
  {
    id: 'SQ20240515005', status: 'issued', applyTime: '2024-05-15 08:30',
    applicant: '周涛', applyUnit: '丰台分局交警大队', applyType: 'unit',
    reason: '路面执法装备补充', approver: '刘大队长', approveTime: '2024-05-15 10:00',
    items: [
      { id: '6', name: '警用盾牌', category: '防护装备', model: 'JYPD-2024', quantity: 4, unit: '面', equipmentCode: 'EQ202401099', rfidCode: 'RFID202401099A~D', price: 320, total: 1280, supplier: '盾甲科技', maxQty: 4 },
    ],
  },
];

/* ─── 物资库（三级分类） ─── */
const categoryTree = [
  {
    name: '防护装备',
    subs: ['防弹背心', '防刺手套', '警用盾牌', '防弹头盔', '防刺服']
  },
  {
    name: '通讯设备',
    subs: ['对讲机', '车载电台', '卫星电话', '耳麦']
  },
  {
    name: '记录设备',
    subs: ['执法记录仪', '相机', '录音笔', '行车记录仪']
  },
  {
    name: '照明设备',
    subs: ['战术手电', '头灯', '警示灯', '探照灯']
  },
  {
    name: '械具',
    subs: ['警棍', '手铐', '催泪喷射器', '约束带']
  },
  {
    name: '交通管理',
    subs: ['反光背心', '交通指挥棒', '测速仪', '酒精检测仪']
  },
];

const materialLibrary: ApplyItem[] = [
  { id: 'm1', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 0, unit: '件', equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B', price: 1200, total: 0, supplier: '红星装备厂', maxQty: 15 },
  { id: 'm2', name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 0, unit: '双', equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A', price: 150, total: 0, supplier: '盾甲科技', maxQty: 10 },
  { id: 'm3', name: '警用盾牌', category: '防护装备', model: 'JYPD-2024', quantity: 0, unit: '面', equipmentCode: 'EQ202401099', rfidCode: 'RFID202401099A', price: 320, total: 0, supplier: '盾甲科技', maxQty: 4 },
  { id: 'm4', name: '防弹头盔', category: '防护装备', model: 'FDTK-3A', quantity: 0, unit: '顶', equipmentCode: 'EQ202303012', rfidCode: 'RFID202303012A', price: 800, total: 0, supplier: '红星装备厂', maxQty: 8 },
  { id: 'm5', name: '防刺服', category: '防护装备', model: 'FCF-2024', quantity: 0, unit: '件', equipmentCode: 'EQ202304021', rfidCode: 'RFID202304021A', price: 950, total: 0, supplier: '盾甲科技', maxQty: 6 },
  { id: 'm6', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 0, unit: '台', equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D', price: 650, total: 0, supplier: '国安器材', maxQty: 6 },
  { id: 'm7', name: '车载电台', category: '通讯设备', model: 'CZD-HY1200', quantity: 0, unit: '台', equipmentCode: 'EQ202402056', rfidCode: 'RFID202402056A', price: 2200, total: 0, supplier: '国安器材', maxQty: 3 },
  { id: 'm8', name: '卫星电话', category: '通讯设备', model: 'WXDH-2024', quantity: 0, unit: '部', equipmentCode: 'EQ202403012', rfidCode: 'RFID202403012A', price: 4500, total: 0, supplier: '国安器材', maxQty: 2 },
  { id: 'm9', name: '耳麦', category: '通讯设备', model: 'EM-HY100', quantity: 0, unit: '个', equipmentCode: 'EQ202404067', rfidCode: 'RFID202404067A', price: 120, total: 0, supplier: '国安器材', maxQty: 12 },
  { id: 'm10', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 0, unit: '台', equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', price: 1800, total: 0, supplier: '红星装备厂', maxQty: 8 },
  { id: 'm11', name: '相机', category: '记录设备', model: 'XJ-DSLR-24', quantity: 0, unit: '台', equipmentCode: 'EQ202405033', rfidCode: 'RFID202405033A', price: 5600, total: 0, supplier: '红星装备厂', maxQty: 2 },
  { id: 'm12', name: '录音笔', category: '记录设备', model: 'LYB-16G', quantity: 0, unit: '支', equipmentCode: 'EQ202406044', rfidCode: 'RFID202406044A', price: 380, total: 0, supplier: '红星装备厂', maxQty: 5 },
  { id: 'm13', name: '行车记录仪', category: '记录设备', model: 'XCLY-4K', quantity: 0, unit: '台', equipmentCode: 'EQ202407055', rfidCode: 'RFID202407055A', price: 680, total: 0, supplier: '红星装备厂', maxQty: 4 },
  { id: 'm14', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 0, unit: '个', equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', price: 280, total: 0, supplier: '红星装备厂', maxQty: 20 },
  { id: 'm15', name: '头灯', category: '照明设备', model: 'TD-LED-50', quantity: 0, unit: '个', equipmentCode: 'EQ202408066', rfidCode: 'RFID202408066A', price: 180, total: 0, supplier: '红星装备厂', maxQty: 10 },
  { id: 'm16', name: '警示灯', category: '照明设备', model: 'JSD-LED-RB', quantity: 0, unit: '个', equipmentCode: 'EQ202409077', rfidCode: 'RFID202409077A', price: 220, total: 0, supplier: '国安器材', maxQty: 6 },
  { id: 'm17', name: '探照灯', category: '照明设备', model: 'TZD-1000W', quantity: 0, unit: '台', equipmentCode: 'EQ202410088', rfidCode: 'RFID202410088A', price: 1200, total: 0, supplier: '国安器材', maxQty: 3 },
  { id: 'm18', name: '警棍', category: '械具', model: 'JG-2019', quantity: 0, unit: '根', equipmentCode: 'EQ201908176', rfidCode: 'RFID201908176E', price: 120, total: 0, supplier: '红星装备厂', maxQty: 25 },
  { id: 'm19', name: '手铐', category: '械具', model: 'SK-2019', quantity: 0, unit: '副', equipmentCode: 'EQ201909177', rfidCode: 'RFID201909177A', price: 85, total: 0, supplier: '红星装备厂', maxQty: 30 },
  { id: 'm20', name: '催泪喷射器', category: '械具', model: 'CLPSQ-2024', quantity: 0, unit: '支', equipmentCode: 'EQ202411099', rfidCode: 'RFID202411099A', price: 160, total: 0, supplier: '盾甲科技', maxQty: 8 },
  { id: 'm21', name: '约束带', category: '械具', model: 'YSD-2024', quantity: 0, unit: '条', equipmentCode: 'EQ202412100', rfidCode: 'RFID202412100A', price: 45, total: 0, supplier: '盾甲科技', maxQty: 20 },
  { id: 'm22', name: '反光背心', category: '交通管理', model: 'FGBX-2024', quantity: 0, unit: '件', equipmentCode: 'EQ202413111', rfidCode: 'RFID202413111A', price: 65, total: 0, supplier: '盾甲科技', maxQty: 50 },
  { id: 'm23', name: '交通指挥棒', category: '交通管理', model: 'JTZHB-LED', quantity: 0, unit: '根', equipmentCode: 'EQ202414122', rfidCode: 'RFID202414122A', price: 90, total: 0, supplier: '国安器材', maxQty: 15 },
  { id: 'm24', name: '测速仪', category: '交通管理', model: 'CSY-LD-300', quantity: 0, unit: '台', equipmentCode: 'EQ202415133', rfidCode: 'RFID202415133A', price: 8500, total: 0, supplier: '国安器材', maxQty: 2 },
  { id: 'm25', name: '酒精检测仪', category: '交通管理', model: 'JJCJY-2024', quantity: 0, unit: '台', equipmentCode: 'EQ202416144', rfidCode: 'RFID202416144A', price: 3200, total: 0, supplier: '国安器材', maxQty: 3 },
];

/* ─── 申请人选项 ─── */
const applicantOptions = [
  { name: '王强', unit: '朝阳分局刑侦大队', badge: '010235' },
  { name: '李明', unit: '东城分局巡警支队', badge: '010198' },
  { name: '赵刚', unit: '西城分局特警大队', badge: '010267' },
  { name: '孙丽', unit: '海淀分局治安大队', badge: '010312' },
  { name: '周涛', unit: '丰台分局交警大队', badge: '010145' },
  { name: '张伟', unit: '昌平分局刑警大队', badge: '010389' },
];

const unitOptions = [
  '朝阳分局刑侦大队',
  '东城分局巡警支队',
  '西城分局特警大队',
  '海淀分局治安大队',
  '丰台分局交警大队',
  '昌平分局刑警大队',
  '通州分局派出所',
  '大兴分局治安大队',
];

/* ─── status config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending:  { label: '审批中',  color: 'text-orange-600', bg: 'bg-orange-50',  icon: Clock },
  approved: { label: '已通过',  color: 'text-blue-600',   bg: 'bg-blue-50',   icon: CheckCircle2 },
  rejected: { label: '已驳回',  color: 'text-red-600',    bg: 'bg-red-50',    icon: X },
  issued:   { label: '已发放',  color: 'text-green-600',  bg: 'bg-green-50',  icon: CheckCircle2 },
};

function genOrderNo() {
  const d = new Date();
  return `SQ${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}${String(Math.floor(Math.random()*900)+100)}`;
}

/* ─── main component ─── */
export default function Apply() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'form' | 'selectMaterial' | 'selectApplicant' | 'success'>('list');

  /* form state */
  const [applyType, setApplyType] = useState<'personal' | 'unit'>('personal');
  const [applicant, setApplicant] = useState('');
  const [applyUnit, setApplyUnit] = useState('');
  const [selectedItems, setSelectedItems] = useState<ApplyItem[]>([]);
  const [reason, setReason] = useState('');
  const [searchText, setSearchText] = useState('');

  /* material selection state */
  const [catLevel1, setCatLevel1] = useState('全部');
  const [catLevel2, setCatLevel2] = useState('全部');
  const [matSearch, setMatSearch] = useState('');
  const [tempSelected, setTempSelected] = useState<ApplyItem[]>([]);

  /* applicant search */
  const [applicantSearch, setApplicantSearch] = useState('');
  const [unitSearch, setUnitSearch] = useState('');
  const [applicantTab, setApplicantTab] = useState<'personal' | 'unit'>('personal');

  /* list filter */
  const [listFilter, setListFilter] = useState('all');

  const resetForm = useCallback(() => {
    setApplyType('personal');
    setApplicant('');
    setApplyUnit('');
    setSelectedItems([]);
    setReason('');
    setSearchText('');
    setCatLevel1('全部');
    setCatLevel2('全部');
    setMatSearch('');
    setTempSelected([]);
    setApplicantSearch('');
    setUnitSearch('');
    setApplicantTab('personal');
  }, []);

  const goBack = useCallback(() => {
    if (step === 'form') { resetForm(); setStep('list'); }
    else if (step === 'selectMaterial') setStep('form');
    else if (step === 'selectApplicant') setStep('form');
    else if (step === 'success') { resetForm(); setStep('list'); }
  }, [step, resetForm]);

  /* ─── filtered list ─── */
  const filteredOrders = useMemo(() => {
    let o = mockOrders;
    if (listFilter !== 'all') o = o.filter(x => x.status === listFilter);
    if (searchText.trim()) {
      const kw = searchText.toLowerCase();
      o = o.filter(x => x.id.toLowerCase().includes(kw) || x.applicant.includes(kw) || x.items.some(i => i.name.includes(kw)));
    }
    return o;
  }, [listFilter, searchText]);

  /* ─── material filters ─── */
  const subCategories = useMemo(() => {
    if (catLevel1 === '全部') return [];
    const cat = categoryTree.find(c => c.name === catLevel1);
    return cat ? cat.subs : [];
  }, [catLevel1]);

  const filteredMaterials = useMemo(() => {
    let m = [...materialLibrary];
    if (catLevel1 !== '全部') m = m.filter(x => x.category === catLevel1);
    if (catLevel2 !== '全部') m = m.filter(x => x.name === catLevel2);
    if (matSearch.trim()) {
      const kw = matSearch.toLowerCase();
      m = m.filter(x => x.name.toLowerCase().includes(kw) || x.model.toLowerCase().includes(kw) || x.equipmentCode.toLowerCase().includes(kw));
    }
    return m;
  }, [catLevel1, catLevel2, matSearch]);

  /* ─── material selection handlers ─── */
  const toggleMaterial = useCallback((item: ApplyItem) => {
    setTempSelected(prev => {
      const exists = prev.find(p => p.id === item.id);
      if (exists) return prev.filter(p => p.id !== item.id);
      return [...prev, { ...item, quantity: 1, total: item.price }];
    });
  }, []);

  const updateTempQty = useCallback((id: string, delta: number) => {
    setTempSelected(prev => prev.map(p => {
      if (p.id === id) {
        const item = materialLibrary.find(m => m.id === id);
        const max = item?.maxQty || 99;
        const newQty = Math.max(1, Math.min(max, p.quantity + delta));
        return { ...p, quantity: newQty, total: p.price * newQty };
      }
      return p;
    }));
  }, []);

  const confirmMaterials = useCallback(() => {
    setSelectedItems(tempSelected);
    setStep('form');
  }, [tempSelected]);

  /* ─── applicant selection ─── */
  const filteredApplicants = useMemo(() => {
    if (!applicantSearch.trim()) return applicantOptions;
    const kw = applicantSearch.toLowerCase();
    return applicantOptions.filter(a => a.name.includes(kw) || a.unit.includes(kw) || a.badge.includes(kw));
  }, [applicantSearch]);

  const filteredUnits = useMemo(() => {
    if (!unitSearch.trim()) return unitOptions;
    return unitOptions.filter(u => u.includes(unitSearch));
  }, [unitSearch]);

  const selectApplicant = useCallback((name: string, unit: string) => {
    setApplicant(name);
    setApplyUnit(unit);
    setStep('form');
  }, []);

  const selectUnit = useCallback((unit: string) => {
    setApplyUnit(unit);
    setApplicant('');
    setStep('form');
  }, []);

  /* ─── form qty update ─── */
  const updateFormQty = useCallback((id: string, delta: number) => {
    setSelectedItems(prev => prev.map(p => {
      if (p.id === id) {
        const newQty = Math.max(1, Math.min(p.maxQty, p.quantity + delta));
        return { ...p, quantity: newQty, total: p.price * newQty };
      }
      return p;
    }));
  }, []);

  const removeItem = useCallback((id: string) => {
    setSelectedItems(prev => prev.filter(p => p.id !== id));
  }, []);

  /* ─── submit ─── */
  const handleSubmit = useCallback(() => {
    setStep('success');
  }, []);

  const isFormValid = applicant && applyUnit && selectedItems.length > 0 && reason.trim();

  /* ═══════════════════════════════════
     RENDER: Success
     ═══════════════════════════════════ */
  if (step === 'success') {
    const orderNo = genOrderNo();
    const totalQty = selectedItems.reduce((s, i) => s + i.quantity, 0);
    const totalAmount = selectedItems.reduce((s, i) => s + i.total, 0);
    return (
      <MobileLayout title="提交成功" showBack onBack={goBack}>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 size={40} className="text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">申领申请已提交</h3>
          <p className="text-sm text-gray-500 mb-6">已推送至领导审批，审批结果将通过消息通知</p>

          <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-4">
            <div className="text-center mb-4 pb-3 border-b border-gray-100">
              <p className="text-xs text-gray-500">申请单号</p>
              <p className="text-base font-semibold text-[#1565c0] font-mono">{orderNo}</p>
            </div>
            <div className="space-y-2 text-sm mb-4">
              <div className="flex justify-between">
                <span className="text-gray-500">{applyType === 'personal' ? '申请人' : '申请单位'}</span>
                <span className="text-gray-800 font-medium">{applicant || applyUnit}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">所属单位</span>
                <span className="text-gray-800 font-medium">{applyUnit}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">申领总数</span>
                <span className="text-gray-800 font-medium">{totalQty} 件</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">合计金额</span>
                <span className="text-[#1565c0] font-bold">¥{totalAmount.toLocaleString()}</span>
              </div>
            </div>
            <p className="text-xs text-gray-500 mb-2">申请清单</p>
            {selectedItems.map(item => (
              <div key={item.id} className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-700">{item.name} <span className="text-gray-400">({item.model})</span></span>
                <span className="text-sm font-medium text-gray-900">x{item.quantity}</span>
              </div>
            ))}
          </div>

          <button
            onClick={() => { resetForm(); setStep('list'); }}
            className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors"
          >
            返回列表
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: Select Applicant
     ═══════════════════════════════════ */
  if (step === 'selectApplicant') {
    return (
      <MobileLayout title={`选择${applyType === 'personal' ? '申请人' : '申请单位'}`} showBack onBack={goBack}>
        <div className="p-4">
          {/* Tabs */}
          <div className="flex bg-gray-100 rounded-xl p-0.5 mb-4">
            <button
              onClick={() => setApplicantTab('personal')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                applicantTab === 'personal' ? 'bg-white text-[#1565c0] shadow-sm' : 'text-gray-500'
              }`}
            >
              <User size={14} /> 个人
            </button>
            <button
              onClick={() => setApplicantTab('unit')}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                applicantTab === 'unit' ? 'bg-white text-[#1565c0] shadow-sm' : 'text-gray-500'
              }`}
            >
              <Building2 size={14} /> 单位
            </button>
          </div>

          {/* Search */}
          <div className="relative mb-3">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={applicantTab === 'personal' ? applicantSearch : unitSearch}
              onChange={e => applicantTab === 'personal' ? setApplicantSearch(e.target.value) : setUnitSearch(e.target.value)}
              placeholder={applicantTab === 'personal' ? '搜索姓名或警号...' : '搜索单位名称...'}
              className="w-full bg-white rounded-xl pl-10 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-gray-200 focus:border-blue-300 transition-all"
            />
          </div>

          {/* List */}
          {applicantTab === 'personal' ? (
            <div className="space-y-2">
              {filteredApplicants.map(a => (
                <button
                  key={a.badge}
                  onClick={() => selectApplicant(a.name, a.unit)}
                  className="w-full bg-white rounded-xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center">
                      <User size={18} className="text-[#1565c0]" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-gray-800">{a.name}</span>
                        <span className="text-[10px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">{a.badge}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">{a.unit}</p>
                    </div>
                    <ChevronRight size={16} className="text-gray-400" />
                  </div>
                </button>
              ))}
              {filteredApplicants.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <User size={32} className="mx-auto mb-2 opacity-50" />
                  <p className="text-sm">未找到匹配的申请人</p>
                </div>
              )}
            </div>
          ) : (
            <div className="space-y-2">
              {filteredUnits.map(u => (
                <button
                  key={u}
                  onClick={() => selectUnit(u)}
                  className="w-full bg-white rounded-xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-purple-50 flex items-center justify-center">
                      <Building2 size={18} className="text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <span className="text-sm font-semibold text-gray-800">{u}</span>
                    </div>
                    <ChevronRight size={16} className="text-gray-400" />
                  </div>
                </button>
              ))}
              {filteredUnits.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <Building2 size={32} className="mx-auto mb-2 opacity-50" />
                  <p className="text-sm">未找到匹配的单位</p>
                </div>
              )}
            </div>
          )}
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: Select Material (三级分类)
     ═══════════════════════════════════ */
  if (step === 'selectMaterial') {
    return (
      <MobileLayout
        title="选择物资"
        showBack
        onBack={goBack}
        rightAction={
          tempSelected.length > 0 ? (
            <span className="text-xs text-white bg-white/20 px-2 py-1 rounded-full">
              已选{tempSelected.reduce((s, i) => s + i.quantity, 0)}件
            </span>
          ) : undefined
        }
      >
        <div className="flex flex-col h-full">
          {/* Search */}
          <div className="shrink-0 p-3 bg-white border-b border-gray-100">
            <div className="relative mb-2">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={matSearch}
                onChange={e => setMatSearch(e.target.value)}
                placeholder="搜索物资名称、型号、编号..."
                className="w-full bg-gray-50 rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
              />
            </div>
            {/* Level 1 Categories */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              <button
                onClick={() => { setCatLevel1('全部'); setCatLevel2('全部'); }}
                className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                  catLevel1 === '全部' ? 'bg-[#1565c0] text-white' : 'bg-gray-100 text-gray-600'
                }`}
              >
                全部
              </button>
              {categoryTree.map(cat => (
                <button
                  key={cat.name}
                  onClick={() => { setCatLevel1(cat.name); setCatLevel2('全部'); }}
                  className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    catLevel1 === cat.name ? 'bg-[#1565c0] text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
            {/* Level 2 Sub-categories */}
            {subCategories.length > 0 && (
              <div className="flex gap-1.5 overflow-x-auto no-scrollbar pt-2 border-t border-gray-50">
                <button
                  onClick={() => setCatLevel2('全部')}
                  className={`shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all ${
                    catLevel2 === '全部' ? 'bg-blue-50 text-[#1565c0] ring-1 ring-[#1565c0]/30' : 'bg-gray-50 text-gray-500'
                  }`}
                >
                  全部
                </button>
                {subCategories.map(sub => (
                  <button
                    key={sub}
                    onClick={() => setCatLevel2(sub)}
                    className={`shrink-0 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all ${
                      catLevel2 === sub ? 'bg-blue-50 text-[#1565c0] ring-1 ring-[#1565c0]/30' : 'bg-gray-50 text-gray-500'
                    }`}
                  >
                    {sub}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Material List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {filteredMaterials.map(item => {
              const selected = tempSelected.find(p => p.id === item.id);
              return (
                <div
                  key={item.id}
                  onClick={() => toggleMaterial(item)}
                  className={`bg-white rounded-xl p-3 shadow-sm border-2 transition-all cursor-pointer ${
                    selected ? 'border-[#1565c0]' : 'border-transparent'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      selected ? 'bg-blue-50' : 'bg-gray-50'
                    }`}>
                      <Package size={18} className={selected ? 'text-[#1565c0]' : 'text-gray-400'} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-gray-800">{item.name}</span>
                        <span className="text-[10px] text-gray-500 bg-gray-100 px-1.5 py-0.5 rounded">{item.category}</span>
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">型号：{item.model} | 编号：{item.equipmentCode}</p>
                      <p className="text-xs text-gray-500">库存：<span className="text-green-600 font-medium">{item.maxQty}{item.unit}</span> | 单价：¥{item.price}</p>
                    </div>
                    {selected && (
                      <div className="shrink-0 flex flex-col items-center gap-1">
                        <span className="text-[10px] text-[#1565c0] font-medium">已选</span>
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={e => { e.stopPropagation(); updateTempQty(item.id, -1); }}
                            className="w-6 h-6 rounded bg-gray-100 flex items-center justify-center"
                          >
                            <Minus size={10} />
                          </button>
                          <span className="text-xs font-semibold w-5 text-center">{selected.quantity}</span>
                          <button
                            onClick={e => { e.stopPropagation(); updateTempQty(item.id, 1); }}
                            className="w-6 h-6 rounded bg-blue-50 flex items-center justify-center"
                          >
                            <PlusIcon size={10} className="text-[#1565c0]" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
            {filteredMaterials.length === 0 && (
              <div className="text-center py-16 text-gray-400">
                <Package size={40} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">未找到匹配的物资</p>
              </div>
            )}
          </div>

          {/* Bottom Confirm Bar */}
          <div className="shrink-0 p-3 bg-white border-t border-gray-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-gray-600">已选 <span className="text-[#1565c0] font-bold">{tempSelected.length}</span> 种</span>
              <span className="text-sm text-gray-600">共 <span className="text-[#1565c0] font-bold">{tempSelected.reduce((s, i) => s + i.quantity, 0)}</span> 件</span>
            </div>
            <button
              onClick={confirmMaterials}
              disabled={tempSelected.length === 0}
              className={`w-full py-3 rounded-xl font-medium text-sm transition-all ${
                tempSelected.length > 0
                  ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'
                  : 'bg-gray-200 text-gray-400'
              }`}
            >
              确认选择
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: Form
     ═══════════════════════════════════ */
  if (step === 'form') {
    const totalQty = selectedItems.reduce((s, i) => s + i.quantity, 0);
    const totalAmount = selectedItems.reduce((s, i) => s + i.total, 0);
    return (
      <MobileLayout title="装备申领" showBack onBack={goBack}>
        <div className="p-4">
          {/* Applicant / Unit Selection */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <User size={14} className="text-[#1565c0]" /> 申请人信息
            </h3>

            {/* Type Toggle */}
            <div className="flex bg-gray-100 rounded-xl p-0.5 mb-3">
              <button
                onClick={() => {
                  setApplyType('personal');
                  setApplicant('');
                  setApplyUnit('');
                }}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  applyType === 'personal' ? 'bg-white text-[#1565c0] shadow-sm' : 'text-gray-500'
                }`}
              >
                <User size={14} /> 个人申领
              </button>
              <button
                onClick={() => {
                  setApplyType('unit');
                  setApplicant('');
                  setApplyUnit('');
                }}
                className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg text-sm font-medium transition-all ${
                  applyType === 'unit' ? 'bg-white text-[#1565c0] shadow-sm' : 'text-gray-500'
                }`}
              >
                <Building2 size={14} /> 单位申领
              </button>
            </div>

            {/* Applicant Selection Button */}
            <button
              onClick={() => setStep('selectApplicant')}
              className="w-full bg-gray-50 rounded-xl p-4 text-left border border-dashed border-gray-300 hover:border-[#1565c0] transition-colors active:bg-gray-100"
            >
              {applicant || applyUnit ? (
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    applyType === 'personal' ? 'bg-blue-50' : 'bg-purple-50'
                  }`}>
                    {applyType === 'personal' ? <User size={18} className="text-[#1565c0]" /> : <Building2 size={18} className="text-purple-600" />}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-gray-800">{applicant || applyUnit}</span>
                      {applyType === 'personal' && <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">个人</span>}
                      {applyType === 'unit' && <span className="text-[10px] text-purple-500 bg-purple-50 px-1.5 py-0.5 rounded">单位</span>}
                    </div>
                    <p className="text-xs text-gray-500 mt-0.5">{applyUnit}</p>
                  </div>
                  <ChevronRight size={16} className="text-gray-400" />
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2 text-gray-400">
                  <Plus size={16} />
                  <span className="text-sm">点击选择{applyType === 'personal' ? '申请人' : '申请单位'}</span>
                </div>
              )}
            </button>
          </div>

          {/* Material Selection */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
                <Package size={14} className="text-[#1565c0]" /> 申领物资
              </h3>
              <button
                onClick={() => {
                  setTempSelected(selectedItems);
                  setCatLevel1('全部');
                  setCatLevel2('全部');
                  setMatSearch('');
                  setStep('selectMaterial');
                }}
                className="text-xs text-[#1565c0] font-medium flex items-center gap-1 bg-blue-50 px-2.5 py-1.5 rounded-lg active:bg-blue-100 transition-colors"
              >
                <Plus size={12} /> 添加物资
              </button>
            </div>

            {selectedItems.length === 0 ? (
              <button
                onClick={() => {
                  setTempSelected([]);
                  setCatLevel1('全部');
                  setCatLevel2('全部');
                  setMatSearch('');
                  setStep('selectMaterial');
                }}
                className="w-full bg-gray-50 rounded-xl p-6 text-center border border-dashed border-gray-300 hover:border-[#1565c0] transition-colors active:bg-gray-100"
              >
                <Package size={24} className="mx-auto mb-2 text-gray-300" />
                <p className="text-sm text-gray-400">尚未选择物资，点击添加</p>
              </button>
            ) : (
              <div className="space-y-2">
                {selectedItems.map(item => (
                  <div key={item.id} className="bg-gray-50 rounded-xl p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-gray-800">{item.name}</span>
                          <span className="text-[10px] text-gray-500 bg-white px-1.5 py-0.5 rounded">{item.model}</span>
                        </div>
                        <p className="text-xs text-gray-500 mt-0.5">单价：¥{item.price} | 库存：{item.maxQty}{item.unit}</p>
                      </div>
                      <button
                        onClick={() => removeItem(item.id)}
                        className="p-1.5 rounded-lg bg-red-50 active:bg-red-100 transition-colors"
                      >
                        <TrashIcon size={12} className="text-red-500" />
                      </button>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-400">小计：<span className="text-[#1565c0] font-bold">¥{item.total}</span></span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateFormQty(item.id, -1)}
                          className="w-7 h-7 rounded-lg bg-white flex items-center justify-center shadow-sm"
                        >
                          <Minus size={12} />
                        </button>
                        <span className="text-sm font-semibold w-6 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateFormQty(item.id, 1)}
                          className="w-7 h-7 rounded-lg bg-blue-50 flex items-center justify-center shadow-sm"
                        >
                          <PlusIcon size={12} className="text-[#1565c0]" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                <div className="pt-2 border-t border-gray-100 flex justify-between">
                  <span className="text-xs text-gray-500">共 {selectedItems.length} 种，{totalQty} 件</span>
                  <span className="text-sm font-bold text-[#1565c0]">¥{totalAmount.toLocaleString()}</span>
                </div>
              </div>
            )}
          </div>

          {/* Reason */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <label className="text-xs text-gray-500 mb-2 block flex items-center gap-1.5">
              <FileTextIcon size={12} /> 申领原因 <span className="text-red-400">*</span>
            </label>
            <textarea
              value={reason}
              onChange={e => setReason(e.target.value)}
              placeholder="请详细说明申领原因及用途..."
              rows={3}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all resize-none"
            />
          </div>

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={!isFormValid}
            className={`w-full py-3.5 rounded-xl font-medium mb-6 transition-all ${
              isFormValid
                ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'
                : 'bg-gray-200 text-gray-400'
            }`}
          >
            提交申领 ({totalQty > 0 ? `${totalQty}件` : '请选择物资'})
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════════════════════════════
     RENDER: List (default)
     ═══════════════════════════════════ */
  return (
    <MobileLayout title="装备申领" showBack>
      {/* Search & Filter */}
      <div className="sticky top-0 z-10 bg-[#f0f4f8] px-4 pt-3 pb-2">
        <div className="relative mb-2">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="搜索申请单号、申请人、物资..."
            className="w-full bg-white rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-gray-200 focus:border-blue-300 transition-all shadow-sm"
          />
        </div>
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { key: 'all', label: '全部' },
            { key: 'pending', label: '审批中' },
            { key: 'approved', label: '已通过' },
            { key: 'issued', label: '已发放' },
            { key: 'rejected', label: '已驳回' },
          ].map(f => (
            <button
              key={f.key}
              onClick={() => setListFilter(f.key)}
              className={`shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                listFilter === f.key ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Order List */}
      <div className="px-4 py-3 space-y-3">
        {filteredOrders.map(order => {
          const cfg = statusConfig[order.status];
          const StatusIcon = cfg.icon;
          const totalQty = order.items.reduce((s, i) => s + i.quantity, 0);
          return (
            <button
              key={order.id}
              onClick={() => navigate(`/apply/${order.id}`)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <ClipboardList size={16} className="text-[#1565c0]" />
                  <span className="text-sm font-semibold text-gray-900 font-mono">{order.id}</span>
                </div>
                <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${cfg.bg} ${cfg.color}`}>
                  <StatusIcon size={10} /> {cfg.label}
                </span>
              </div>
              <div className="space-y-1.5 text-xs text-gray-500 mb-3">
                <div className="flex justify-between">
                  <span>申请人</span>
                  <span className="text-gray-800 font-medium">{order.applicant} <span className="text-gray-400">({order.applyUnit})</span></span>
                </div>
                <div className="flex justify-between">
                  <span>申请时间</span>
                  <span className="text-gray-800">{order.applyTime}</span>
                </div>
                <div className="flex justify-between">
                  <span>申领物资</span>
                  <span className="text-gray-800">{order.items.map(i => `${i.name}x${i.quantity}`).join('、')}</span>
                </div>
              </div>
              <div className="pt-2 border-t border-gray-50 flex items-center justify-between">
                <span className="text-xs text-gray-400">共 {order.items.length} 种 {totalQty} 件</span>
                <ChevronRight size={14} className="text-gray-400" />
              </div>
            </button>
          );
        })}

        {filteredOrders.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <ClipboardList size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无申领记录</p>
          </div>
        )}
      </div>

      {/* FAB */}
      <button
        onClick={() => { resetForm(); setStep('form'); }}
        className="fixed bottom-6 right-5 w-14 h-14 rounded-full flex items-center justify-center shadow-lg active:scale-95 transition-transform z-50"
        style={{ background: 'linear-gradient(135deg, #1565c0, #0d2b5e)' }}
      >
        <Plus size={24} className="text-white" />
      </button>
    </MobileLayout>
  );
}

/* ─── helper icons ─── */
function PlusIcon({ size, className }: { size: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>;
}
function TrashIcon({ size, className }: { size: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>;
}
function FileTextIcon({ size, className }: { size: number; className?: string }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><line x1="10" y1="9" x2="8" y2="9"/></svg>;
}
