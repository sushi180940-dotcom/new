import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  ArrowRightLeft, Package, ArrowRight, QrCode,
  CheckCircle2, XCircle, Clock, AlertTriangle,
  User, CalendarDays, StickyNote,
  CircleDot
} from 'lucide-react';

/* ─── re-export mock data and types from Transfer.tsx ─── */
import { mockRecords } from './Transfer';

/* ─── config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType; desc: string }> = {
  pending:   { label: '待确认',  color: 'text-orange-600',  bg: 'bg-orange-50',  icon: Clock,         desc: '等待接收人扫码确认' },
  completed: { label: '已完成',  color: 'text-green-600',   bg: 'bg-green-50',   icon: CheckCircle2,  desc: '交接已成功完成，装备归属已变更' },
  expired:   { label: '已失效',  color: 'text-gray-500',    bg: 'bg-gray-100',   icon: XCircle,       desc: '二维码已过期，交接自动失效' },
};

/* ─── main component ─── */
export default function TransferDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const record = mockRecords.find(r => r.id === id);

  if (!record) {
    return (
      <MobileLayout title="交接详情" showBack onBack={() => navigate('/transfer')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <ArrowRightLeft size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到交接记录</p>
        </div>
      </MobileLayout>
    );
  }

  const sc = statusConfig[record.status];
  const StatusIcon = sc.icon;
  const totalQty = record.materials.reduce((s, m) => s + m.quantity, 0);
  const totalAmount = record.materials.reduce((s, m) => s + m.total, 0);
  const isExpired = record.status === 'expired';
  const isCompleted = record.status === 'completed';

  return (
    <MobileLayout title="交接详情" showBack onBack={() => navigate('/transfer')}>
      <div className="p-4">
        {/* ── Status Card ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-3">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${sc.bg}`}>
              <StatusIcon size={24} className={sc.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{record.id}</span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${sc.bg} ${sc.color}`}>
                  {sc.label}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{sc.desc}</p>
            </div>
          </div>

          {/* Overdue warning for expired */}
          {isExpired && (
            <div className="flex items-center gap-2 bg-red-50 rounded-xl p-3 mb-2">
              <AlertTriangle size={16} className="text-red-500 shrink-0" />
              <p className="text-xs text-red-600 font-medium">
                二维码已超过有效期（{record.qrExpireTime}），交接自动失效
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">交接时间</p>
              <p className="text-xs text-gray-800 font-medium">{record.createTime}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">装备数量</p>
              <p className="text-xs text-gray-800 font-medium">{record.materials.length}种 · {totalQty}件</p>
            </div>
            {record.completeTime && (
              <div className="bg-gray-50 rounded-xl p-2.5">
                <p className="text-[10px] text-gray-500">完成时间</p>
                <p className="text-xs text-gray-800 font-medium">{record.completeTime}</p>
              </div>
            )}
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">二维码有效期</p>
              <p className={`text-xs font-medium ${isExpired ? 'text-red-600' : 'text-gray-800'}`}>
                {isExpired ? '已失效' : `至 ${record.qrExpireTime}`}
              </p>
            </div>
          </div>
        </div>

        {/* ── Both Parties ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <User size={14} className="text-[#1565c0]" /> 交接双方
          </h3>
          <div className="flex items-center justify-center gap-4 py-2">
            {/* From User */}
            <div className="text-center flex-1">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-2 ${
                isCompleted ? 'bg-blue-50' : 'bg-blue-50'
              }`}>
                <span className="text-xl font-bold text-blue-600">{record.fromUser[0]}</span>
              </div>
              <p className="text-sm font-semibold text-gray-800">{record.fromUser}</p>
              <p className="text-[10px] text-gray-500">{record.fromBadge}</p>
              <p className="text-[10px] text-gray-400">{record.fromUnit}</p>
              {isCompleted && (
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-gray-100 text-gray-500">
                  已移交
                </span>
              )}
            </div>

            {/* Arrow */}
            <div className="flex flex-col items-center shrink-0">
              <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                isCompleted ? 'bg-green-100' : isExpired ? 'bg-red-100' : 'bg-orange-100'
              }`}>
                {isCompleted ? (
                  <CheckCircle2 size={20} className="text-green-600" />
                ) : isExpired ? (
                  <XCircle size={20} className="text-red-500" />
                ) : (
                  <Clock size={20} className="text-orange-500" />
                )}
              </div>
              <ArrowRight size={16} className={`mt-1 ${
                isCompleted ? 'text-green-400' : isExpired ? 'text-red-300' : 'text-orange-300'
              }`} />
            </div>

            {/* To User */}
            <div className="text-center flex-1">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-2 ${
                isCompleted ? 'bg-green-50' : 'bg-green-50'
              }`}>
                <span className="text-xl font-bold text-green-600">{record.toUser[0]}</span>
              </div>
              <p className="text-sm font-semibold text-gray-800">{record.toUser}</p>
              <p className="text-[10px] text-gray-500">{record.toBadge}</p>
              <p className="text-[10px] text-gray-400">{record.toUnit}</p>
              {isCompleted && (
                <span className="inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-medium bg-green-50 text-green-600">
                  已接收
                </span>
              )}
            </div>
          </div>
        </div>

        {/* ── QR Code Info ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <QrCode size={14} className="text-[#1565c0]" /> 交接二维码
          </h3>
          <div className="flex items-center gap-3">
            <div className={`w-20 h-20 rounded-xl flex items-center justify-center shrink-0 ${
              isExpired ? 'bg-gray-100' : isCompleted ? 'bg-gray-100' : 'bg-blue-50'
            }`}>
              {isExpired ? (
                <XCircle size={36} className="text-gray-400" />
              ) : isCompleted ? (
                <CheckCircle2 size={36} className="text-gray-400" />
              ) : (
                <QrCode size={36} className="text-[#1565c0]" />
              )}
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-xs font-medium text-gray-800 font-mono">
                  {record.id}QR
                </span>
                {isCompleted && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-gray-100 text-gray-500">
                    已使用
                  </span>
                )}
                {isExpired && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-red-50 text-red-500">
                    已失效
                  </span>
                )}
              </div>
              <p className="text-xs text-gray-500">生成时间：{record.createTime}</p>
              <p className={`text-xs font-medium ${isExpired ? 'text-red-600' : 'text-gray-500'}`}>
                {isExpired
                  ? '二维码已过期，不可再次使用'
                  : isCompleted
                    ? '二维码已使用，单次有效'
                    : `有效期至：${record.qrExpireTime}`
                }
              </p>
            </div>
          </div>
        </div>

        {/* ── Materials ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Package size={14} className="text-[#1565c0]" /> 物资明细 ({record.materials.length})
          </h3>
          <div className="space-y-3">
            {record.materials.map((m, i) => (
              <div key={i} className="bg-gray-50 rounded-xl p-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400">#{i + 1}</span>
                    <span className="text-sm font-medium text-gray-800">{m.name}</span>
                    <span className="text-[10px] text-gray-500 bg-white px-1.5 py-0.5 rounded">{m.category}</span>
                    {m.isFixedAsset && (
                      <span className="text-[10px] text-purple-500 bg-purple-50 px-1.5 py-0.5 rounded">固定资产</span>
                    )}
                  </div>
                  <span className="text-sm font-bold text-[#1565c0]">¥{m.total.toLocaleString()}</span>
                </div>
                <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>型号：{m.model}</span>
                  <span>数量：{m.quantity} {m.unit}</span>
                  <span>生产日期：{m.productionDate}</span>
                  <span>有效期：{m.expiryDate}</span>
                  <span>保养期：{m.maintenanceValue}{m.maintenanceUnit}</span>
                  <span>单价：¥{m.price}</span>
                  <span>装备编码：{m.equipmentCode}</span>
                  <span>RFID：{m.rfidCode}</span>
                  <span>存储位置：{m.storageLocation}</span>
                  <span>供应商：{m.supplier}</span>
                </div>
                {m.remark && (
                  <div className="mt-2 pt-2 border-t border-gray-200">
                    <p className="text-[10px] text-gray-400 flex items-center gap-1">
                      <StickyNote size={9} /> 备注：{m.remark}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
            <span className="text-sm text-gray-600">
              共 {record.materials.length} 种，{totalQty} 件
            </span>
            <span className="text-sm font-bold text-[#1565c0]">
              ¥{totalAmount.toLocaleString()}
            </span>
          </div>
        </div>

        {/* ── Timeline ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <h3 className="text-sm font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <CalendarDays size={14} className="text-[#1565c0]" /> 交接流程
          </h3>
          <div className="space-y-0">
            {/* Step 1: Create */}
            <div className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className="w-7 h-7 rounded-full bg-green-500 flex items-center justify-center">
                  <CheckCircle2 size={14} className="text-white" />
                </div>
                {(!isExpired || true) && <div className="w-0.5 h-8 bg-gray-200" />}
              </div>
              <div className="pb-4">
                <p className="text-sm font-medium text-gray-800">发起交接</p>
                <p className="text-[10px] text-gray-400">{record.createTime}</p>
                <p className="text-[10px] text-gray-500">{record.fromUser} 发起交接申请</p>
              </div>
            </div>

            {/* Step 2: QR Generated */}
            <div className="flex gap-3">
              <div className="flex flex-col items-center">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                  isExpired ? 'bg-red-500' : 'bg-green-500'
                }`}>
                  {isExpired ? (
                    <XCircle size={14} className="text-white" />
                  ) : (
                    <CheckCircle2 size={14} className="text-white" />
                  )}
                </div>
                {(!isExpired || true) && <div className="w-0.5 h-8 bg-gray-200" />}
              </div>
              <div className="pb-4">
                <p className={`text-sm font-medium ${isExpired ? 'text-red-700' : 'text-gray-800'}`}>
                  生成二维码
                </p>
                <p className="text-[10px] text-gray-400">{record.createTime}</p>
                <p className={`text-[10px] ${isExpired ? 'text-red-500' : 'text-gray-500'}`}>
                  {isExpired ? '二维码已过期失效' : '二维码生成成功'}
                </p>
              </div>
            </div>

            {/* Step 3: Scan QR */}
            {!isExpired && (
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    isCompleted ? 'bg-green-500' : 'bg-orange-500'
                  }`}>
                    {isCompleted ? (
                      <CheckCircle2 size={14} className="text-white" />
                    ) : (
                      <CircleDot size={14} className="text-white" />
                    )}
                  </div>
                  {isCompleted && <div className="w-0.5 h-8 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm font-medium ${isCompleted ? 'text-gray-800' : 'text-orange-700'}`}>
                    扫码确认
                  </p>
                  {isCompleted ? (
                    <>
                      <p className="text-[10px] text-gray-400">{record.completeTime}</p>
                      <p className="text-[10px] text-gray-500">{record.toUser} 扫码确认</p>
                    </>
                  ) : (
                    <p className="text-[10px] text-orange-500">等待接收人扫码</p>
                  )}
                </div>
              </div>
            )}

            {/* Step 4: Complete */}
            {isCompleted && (
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 rounded-full bg-green-500 flex items-center justify-center">
                    <CheckCircle2 size={14} className="text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-800">交接完成</p>
                  <p className="text-[10px] text-gray-400">{record.completeTime}</p>
                  <p className="text-[10px] text-green-600">装备归属已变更</p>
                </div>
              </div>
            )}

            {/* Expired end */}
            {isExpired && (
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 rounded-full bg-red-500 flex items-center justify-center">
                    <XCircle size={14} className="text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-red-700">交接失效</p>
                  <p className="text-[10px] text-gray-400">{record.qrExpireTime}</p>
                  <p className="text-[10px] text-red-500">二维码过期，交接自动关闭</p>
                </div>
              </div>
            )}

            {/* Pending final step */}
            {!isCompleted && !isExpired && (
              <div className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center">
                    <CheckCircle2 size={14} className="text-white" />
                  </div>
                </div>
                <div>
                  <p className="text-sm text-gray-400">交接完成</p>
                  <p className="text-[10px] text-gray-400">等待双方确认</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
