import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import MobileLayout from '@/components/MobileLayout';
import {
  ScanLine, Search, Package, Tag, MapPin, Calendar,
  CheckCircle2, XCircle, QrCode, RefreshCw, AlertTriangle,
  Database, ChevronDown, ChevronUp, Eye
} from 'lucide-react';

/* ─── types ─── */
interface EquipmentRecord {
  rfid: string; equipmentCode: string; name: string;
  category: string; model: string;
  status: 'in_stock' | 'out' | 'repairing' | 'scrapped';
  stockQty: number; totalQty: number;
  warehouse: string; inDate: string; inOrderNo: string;
  inType: string; supplier: string; price: number; unit: string;
  productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
  isFixedAsset: boolean; remark: string; lastCheck: string;
  holder?: string; outDate?: string; outType?: string;
  repairNo?: string; scrapNo?: string;
}

/* ─── mock data (same equipment, multiple RFID) ─── */
const EQUIPMENT_DB: EquipmentRecord[] = [
  { rfid: 'RFID202301058B', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 3, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058C', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 5, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-01-15', expiryDate: '2028-01-15', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058D', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'out', stockQty: 0, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-02-01', expiryDate: '2028-02-01', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15', holder: '王强', outDate: '2024-05-18', outType: '领用出库' },
  { rfid: 'RFID202301058E', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 4, totalQty: 15, warehouse: '省厅主仓库/主仓库2楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-02-20', expiryDate: '2028-02-20', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058F', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'repairing', stockQty: 0, totalQty: 15, warehouse: '01号装备室/东侧区域', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-03-01', expiryDate: '2028-03-01', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15', repairNo: 'WX20240518001' },
  { rfid: 'RFID202301058G', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 3, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-03-15', expiryDate: '2028-03-15', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202401001A', equipmentCode: 'EQ202401001', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', status: 'out', stockQty: 0, totalQty: 12, warehouse: '省厅主仓库/主仓库2楼', inDate: '2024-01-15', inOrderNo: 'RK20240115002', inType: '采购入库', supplier: '红星装备厂', price: 1800, unit: '台', productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '4K高清', lastCheck: '2024-05-01', holder: '李明', outDate: '2024-05-19', outType: '领用出库' },
  { rfid: 'RFID202401001B', equipmentCode: 'EQ202401001', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', status: 'in_stock', stockQty: 8, totalQty: 12, warehouse: '省厅主仓库/主仓库2楼', inDate: '2024-01-15', inOrderNo: 'RK20240115002', inType: '采购入库', supplier: '红星装备厂', price: 1800, unit: '台', productionDate: '2024-01-20', expiryDate: '2027-01-20', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '4K高清', lastCheck: '2024-05-01' },
  { rfid: 'RFID202202112C', equipmentCode: 'EQ202202112', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', status: 'in_stock', stockQty: 18, totalQty: 20, warehouse: '01号装备室/东侧区域', inDate: '2022-06-10', inOrderNo: 'RK20220610003', inType: '采购入库', supplier: '红星装备厂', price: 280, unit: '个', productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年', isFixedAsset: false, remark: 'LED强光', lastCheck: '2024-05-10' },
  { rfid: 'RFID202401089D', equipmentCode: 'EQ202401089', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', status: 'in_stock', stockQty: 8, totalQty: 8, warehouse: '03号装备室/一楼', inDate: '2024-02-01', inOrderNo: 'RK20240201004', inType: '采购入库', supplier: '国安器材', price: 650, unit: '台', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '800MHz频段', lastCheck: '2024-05-05' },
];

const statusMap: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  in_stock: { label: '在库', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  out: { label: '已出库', color: 'text-blue-600', bg: 'bg-blue-50', icon: Package },
  repairing: { label: '维修中', color: 'text-orange-600', bg: 'bg-orange-50', icon: AlertTriangle },
  scrapped: { label: '已报废', color: 'text-red-600', bg: 'bg-red-50', icon: XCircle },
};

/* merge same equipment by name + model */
function mergeEquipment(items: EquipmentRecord[]) {
  const map = new Map<string, EquipmentRecord[]>();
  items.forEach(item => {
    const key = `${item.name}|${item.model}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(item);
  });
  return Array.from(map.entries()).map(([, group]) => ({
    key: `${group[0].name}|${group[0].model}`,
    name: group[0].name,
    model: group[0].model,
    category: group[0].category,
    equipmentCode: group[0].equipmentCode,
    supplier: group[0].supplier,
    unit: group[0].unit,
    price: group[0].price,
    isFixedAsset: group[0].isFixedAsset,
    items: group,
    totalStock: group.filter(g => g.status === 'in_stock').reduce((s, g) => s + g.stockQty, 0),
    totalCount: group.length,
    rfidList: group.map(g => g.rfid),
  }));
}

type MergeResult = ReturnType<typeof mergeEquipment>[0];

/* highlight all matched keywords */
function HighlightText({ text, query }: { text: string; query: string }) {
  const keywords = query.toLowerCase().trim().split(/\s+/).filter(k => k.length > 0);
  if (keywords.length === 0) return <>{text}</>;

  // Find all match positions
  type MatchPos = { start: number; end: number };
  const matches: MatchPos[] = [];
  const lowerText = text.toLowerCase();

  keywords.forEach(kw => {
    let idx = lowerText.indexOf(kw, 0);
    while (idx !== -1) {
      matches.push({ start: idx, end: idx + kw.length });
      idx = lowerText.indexOf(kw, idx + 1);
    }
  });

  if (matches.length === 0) return <>{text}</>;

  // Sort and merge overlapping ranges
  matches.sort((a, b) => a.start - b.start);
  const merged: MatchPos[] = [];
  for (const m of matches) {
    if (merged.length === 0 || m.start > merged[merged.length - 1].end) {
      merged.push(m);
    } else {
      merged[merged.length - 1].end = Math.max(merged[merged.length - 1].end, m.end);
    }
  }

  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  merged.forEach((m, i) => {
    if (m.start > lastIndex) {
      parts.push(<span key={`n${i}`}>{text.slice(lastIndex, m.start)}</span>);
    }
    parts.push(<span key={`h${i}`} className="text-[#1565c0] font-bold">{text.slice(m.start, m.end)}</span>);
    lastIndex = m.end;
  });
  if (lastIndex < text.length) parts.push(<span key="tail">{text.slice(lastIndex)}</span>);

  return <>{parts}</>;
}

/* find which field matched for display label - uses last keyword */
function getMatchLabel(group: MergeResult, query: string): { code: string; name: string } {
  const keywords = query.toLowerCase().trim().split(/\s+/).filter(k => k.length > 0);
  const q = keywords.length > 0 ? keywords[keywords.length - 1] : '';
  if (!q) return { code: group.equipmentCode, name: group.name };
  // Check equipment code match
  if (group.equipmentCode.toLowerCase().includes(q)) {
    return { code: group.equipmentCode, name: group.name };
  }
  // Check RFID match
  const matchedRfid = group.items.find(i => i.rfid.toLowerCase().includes(q));
  if (matchedRfid) {
    return { code: matchedRfid.rfid, name: group.name };
  }
  // Default
  return { code: group.equipmentCode, name: group.name };
}

export default function ScanQuery() {
  const [mode, setMode] = useState<'scan' | 'result' | 'empty'>('scan');
  const [searchText, setSearchText] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<MergeResult | null>(null);
  const [scanAnim, setScanAnim] = useState(false);
  const [showAllRfid, setShowAllRfid] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  /* real-time fuzzy search - multi-keyword AND match */
  const dropdownResults = useMemo(() => {
    const query = searchText.trim();
    if (!query) return [];
    const keywords = query.toLowerCase().split(/\s+/).filter(k => k.length > 0);
    if (keywords.length === 0) return [];
    const matched = EQUIPMENT_DB.filter(e => {
      const fields = [e.rfid, e.equipmentCode, e.name, e.category, e.model, e.supplier].map(f => f.toLowerCase());
      return keywords.every(kw => fields.some(f => f.includes(kw)));
    });
    return mergeEquipment(matched).slice(0, 8);
  }, [searchText]);

  /* click outside to close dropdown */
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelectGroup = useCallback((group: MergeResult) => {
    setSelectedGroup(group);
    setMode('result');
    setDropdownOpen(false);
    setShowAllRfid(false);
  }, []);

  const handleScan = () => {
    setScanAnim(true);
    setTimeout(() => {
      setScanAnim(false);
      const randomItem = EQUIPMENT_DB[Math.floor(Math.random() * EQUIPMENT_DB.length)];
      const matched = mergeEquipment(EQUIPMENT_DB.filter(e =>
        e.name === randomItem.name && e.model === randomItem.model
      ));
      if (matched.length > 0) handleSelectGroup(matched[0]);
    }, 1500);
  };

  /* ═══════════ SCAN MODE ═══════════ */
  if (mode === 'scan') {
    return (
      <MobileLayout title="装备查询" showBack>
        <div className="p-5">
          {/* Search with dropdown */}
          <div ref={searchRef} className="relative mb-4">
            <div className="bg-white rounded-2xl shadow-sm p-3">
              <p className="text-sm text-gray-500 mb-2">输入关键词查询装备（名称/编号/RFID/型号/类别/供应商）</p>
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  ref={inputRef}
                  type="text"
                  value={searchText}
                  onChange={e => {
                    setSearchText(e.target.value);
                    setDropdownOpen(e.target.value.trim().length > 0);
                  }}
                  onFocus={() => {
                    if (searchText.trim().length > 0) setDropdownOpen(true);
                  }}
                  placeholder="输入关键词，空格分隔，如：防弹 红星"
                  className="w-full bg-gray-50 rounded-xl pl-9 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                />
              </div>
            </div>

            {/* Dropdown results */}
            {dropdownOpen && (
              <div className="absolute z-50 left-0 right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden">
                {dropdownResults.length > 0 ? (
                  <div className="max-h-80 overflow-y-auto no-scrollbar">
                    <div className="px-3 py-2 bg-gray-50 text-[10px] text-gray-500">
                      共找到 {dropdownResults.length} 种装备（同种已合并）
                    </div>
                    {dropdownResults.map(group => {
                      const label = getMatchLabel(group, searchText);
                      return (
                        <button
                          key={group.key}
                          onClick={() => handleSelectGroup(group)}
                          className="w-full text-left px-4 py-3 hover:bg-blue-50 active:bg-blue-100 transition-colors border-b border-gray-50 last:border-0"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-gray-800 font-mono">
                              <HighlightText text={label.code} query={searchText} />
                            </span>
                            <span className="text-gray-300">·</span>
                            <span className="text-sm text-gray-700">
                              <HighlightText text={label.name} query={searchText} />
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] text-gray-400">
                              <HighlightText text={group.model} query={searchText} />
                            </span>
                            <span className="text-[10px] text-gray-300">|</span>
                            <span className="text-[10px] text-gray-400">
                              <HighlightText text={group.category} query={searchText} />
                            </span>
                            <span className="text-[10px] text-gray-300">|</span>
                            <span className="text-[10px] text-gray-400">
                              <HighlightText text={group.supplier} query={searchText} />
                            </span>
                            <span className="ml-auto text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded font-medium">
                              库存<HighlightText text={`${group.totalStock}${group.unit}`} query={searchText} />
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-400">
                    <Database size={24} className="mx-auto mb-2" />
                    <p className="text-sm">无对应装备信息</p>
                    <p className="text-xs mt-1">请尝试其他关键词</p>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Scan Button */}
          <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
            <div className={`w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-4 transition-all ${scanAnim ? 'bg-blue-100 scale-95' : 'bg-blue-50'}`}>
              {scanAnim ? <RefreshCw size={40} className="text-blue-600 animate-spin" /> : <QrCode size={40} className="text-blue-600" />}
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{scanAnim ? '正在扫描...' : '扫描RFID编码'}</h3>
            <p className="text-xs text-gray-500 mb-6">{scanAnim ? '请对准装备RFID标签' : '点击按钮模拟扫描装备RFID标签'}</p>
            <button onClick={handleScan} disabled={scanAnim} className={`w-full py-3.5 rounded-xl font-medium transition-all ${scanAnim ? 'bg-gray-200 text-gray-400' : 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'}`}>
              {scanAnim ? '扫描中...' : '开始扫描'}
            </button>
          </div>

          {/* Quick Tips */}
          <div className="mt-4 bg-blue-50 border border-blue-100 rounded-xl p-3">
            <p className="text-xs text-blue-600 font-medium mb-1">查询提示</p>
            <p className="text-[11px] text-blue-500">RFID编码为装备唯一识别凭证，一物一码，无重复、无失效</p>
            <p className="text-[11px] text-blue-500 mt-0.5">可尝试搜索：防弹、30032、FDY、058B、防护</p>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ EMPTY ═══════════ */
  if (mode === 'empty') {
    return (
      <MobileLayout title="查询结果" showBack>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
            <Database size={36} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">无对应装备信息</h3>
          <p className="text-xs text-gray-400 text-center mb-6">请检查关键词是否正确，或重新扫描</p>
          <div className="w-full space-y-3">
            <button onClick={() => { setMode('scan'); setSearchText(''); setDropdownOpen(false); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors flex items-center justify-center gap-2">
              <RefreshCw size={16} /> 重新查询
            </button>
            <button onClick={handleScan} className="w-full bg-blue-50 text-[#1565c0] py-3 rounded-xl font-medium active:bg-blue-100 transition-colors flex items-center justify-center gap-2">
              <ScanLine size={16} /> 重新扫描
            </button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ RESULT ═══════════ */
  if (!selectedGroup) return null;

  const g = selectedGroup;
  const first = g.items[0];
  const sm = statusMap[first.status];
  const StatusIcon = sm.icon;

  const statusCount = { in_stock: 0, out: 0, repairing: 0, scrapped: 0 };
  g.items.forEach(i => { statusCount[i.status] += i.stockQty; });

  return (
    <MobileLayout title="装备详情" showBack onBack={() => { setMode('scan'); setShowAllRfid(false); setSearchText(''); setDropdownOpen(false); }}>
      <div className="p-4">
        {/* Header */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-4">
            <div className={`w-14 h-14 rounded-2xl ${sm.bg} flex items-center justify-center`}>
              <StatusIcon size={28} className={sm.color} />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900">{g.name}</h3>
              <p className="text-xs text-gray-500">{g.equipmentCode} · {g.model}</p>
            </div>
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${sm.bg} ${sm.color}`}>{sm.label}</span>
          </div>
          <div className="grid grid-cols-4 gap-2 mt-3">
            <div className="bg-green-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-green-600">{g.totalStock}</p>
              <p className="text-[9px] text-green-600">在库</p>
            </div>
            <div className="bg-blue-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-blue-600">{statusCount.out}</p>
              <p className="text-[9px] text-blue-600">已出库</p>
            </div>
            <div className="bg-orange-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-orange-600">{g.items.filter(i => i.status === 'repairing').length}</p>
              <p className="text-[9px] text-orange-600">维修中</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-gray-600">{g.totalCount}</p>
              <p className="text-[9px] text-gray-600">总件数</p>
            </div>
          </div>
        </div>

        {/* RFID Section */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
              <Tag size={14} className="text-blue-600" /> RFID编码
            </h3>
            <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full font-medium">共{g.rfidList.length}个</span>
          </div>
          <p className="text-[10px] text-gray-400 mb-2">RFID为装备唯一识别凭证，一物一码，无重复</p>
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-2">
            <p className="text-xs text-blue-600 font-medium mb-0.5">主RFID</p>
            <p className="text-sm font-bold text-blue-800 font-mono">{g.rfidList[0]}</p>
          </div>
          {g.rfidList.length > 1 && (
            <>
              <button onClick={() => setShowAllRfid(!showAllRfid)} className="w-full flex items-center justify-center gap-1 text-xs text-blue-600 py-2 active:bg-blue-50 rounded-lg transition-colors">
                {showAllRfid ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                {showAllRfid ? '收起' : `查看全部${g.rfidList.length}个RFID编码`}
              </button>
              {showAllRfid && (
                <div className="mt-2 space-y-2">
                  {g.items.map((item, i) => {
                    const s = statusMap[item.status];
                    return (
                      <div key={i} className="bg-gray-50 rounded-xl p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-mono text-gray-800">{item.rfid}</span>
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${s.bg} ${s.color}`}>{s.label}</span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-gray-500">
                          <span>库存：{item.stockQty}{item.unit}</span>
                          <span>存放：{item.warehouse}</span>
                          {item.holder && <span>持有人：{item.holder}</span>}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>

        {/* Complete Material Detail */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Database size={14} className="text-blue-600" /> 物资明细
          </h3>
          <div className="space-y-2">
            {[
              { label: '物资名称', value: g.name, req: true },
              { label: '物资类别', value: first.category },
              { label: '规格型号', value: g.model },
              { label: '剩余数量', value: `${g.totalStock} ${first.unit}`, hl: true },
              { label: '生产日期', value: first.productionDate },
              { label: '有效期', value: first.expiryDate },
              { label: '保养期', value: `${first.maintenanceValue}${first.maintenanceUnit}` },
              { label: '单位', value: first.unit, req: true },
              { label: '单价(¥)', value: `¥${first.price.toLocaleString()}`, req: true },
              { label: '总价(¥)', value: `¥${(first.price * g.totalStock).toLocaleString()}` },
              { label: '装备编码', value: g.equipmentCode },
              { label: 'RFID编码', value: `${g.rfidList[0]}${g.rfidList.length > 1 ? ` 等${g.rfidList.length}个` : ''}` },
              { label: '存储位置', value: first.warehouse, req: true },
              { label: '供应商', value: first.supplier, req: true },
              { label: '固定资产', value: first.isFixedAsset ? '是' : '否' },
              { label: '备注', value: first.remark || '—' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-1 text-gray-500">
                  <span className="text-xs">{item.label}</span>
                  {item.req && <span className="text-red-500 text-[10px]">*</span>}
                </div>
                <span className={`text-sm font-medium ${item.hl ? 'text-[#1565c0]' : 'text-gray-800'}`}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Warehouse Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <MapPin size={14} className="text-blue-600" /> 仓储信息
          </h3>
          <div className="space-y-2">
            {[
              { icon: MapPin, label: '存储位置', value: first.warehouse },
              { icon: Calendar, label: '入库时间', value: first.inDate },
              { icon: Tag, label: '入库单号', value: first.inOrderNo },
              { icon: Tag, label: '入库类型', value: first.inType },
              { icon: Calendar, label: '最近盘点', value: first.lastCheck },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-1.5 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-2 text-gray-500">
                  <item.icon size={12} />
                  <span className="text-xs">{item.label}</span>
                </div>
                <span className="text-sm text-gray-800 font-medium">{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stock Distribution */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Eye size={14} className="text-blue-600" /> 库存分布
          </h3>
          <div className="space-y-2">
            {g.items.map((item, i) => {
              const s = statusMap[item.status];
              return (
                <div key={i} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-gray-400 font-mono">{item.rfid.slice(-6)}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${s.bg} ${s.color}`}>{s.label}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-sm text-gray-800">{item.stockQty}{item.unit}</span>
                    <span className="text-[10px] text-gray-400 ml-2">{item.warehouse}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-3 mb-6">
          <button onClick={() => { setMode('scan'); setShowAllRfid(false); setSearchText(''); }} className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-xl font-medium active:bg-gray-200 transition-colors">返回查询</button>
          {g.totalStock > 0 && <button className="flex-1 bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">发起出库</button>}
        </div>
      </div>
    </MobileLayout>
  );
}


