import { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import MobileLayout from '@/components/MobileLayout';
import {
  Search, Package, Tag, Calendar, ClipboardList,
  QrCode, RefreshCw, AlertTriangle,
  Database, Eye, Archive, UserCheck,
  Wrench, ArrowLeftRight, PackageOpen
} from 'lucide-react';

/* ─── types ─── */
interface EquipmentRecord {
  rfid: string; equipmentCode: string; name: string;
  category: string; model: string;
  status: 'in_stock' | 'out' | 'repairing' | 'scrapped';
  stockQty: number; totalQty: number;
  warehouse: string; inDate: string; inOrderNo: string;
  inType: string; supplier: string; price: number; unit: string;
  productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
  isFixedAsset: boolean; remark: string; lastCheck: string;
}

interface LifeCycleNode {
  id: string;
  type: 'in' | 'out' | 'receive' | 'repair' | 'check' | 'transfer' | 'scrap';
  subType: string;
  time: string;
  operator: string;
  department: string;
  description: string;
  rfid: string;
}

/* ─── mock equipment db (multiple RFID per equipment) ─── */
const EQUIPMENT_DB: EquipmentRecord[] = [
  { rfid: 'RFID202301058B', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 3, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058C', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 5, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-01-15', expiryDate: '2028-01-15', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058D', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'out', stockQty: 0, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-02-01', expiryDate: '2028-02-01', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058E', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 4, totalQty: 15, warehouse: '省厅主仓库/主仓库2楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-02-20', expiryDate: '2028-02-20', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058F', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'repairing', stockQty: 0, totalQty: 15, warehouse: '01号装备室/东侧区域', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-03-01', expiryDate: '2028-03-01', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202301058G', equipmentCode: 'EQ202301058', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', status: 'in_stock', stockQty: 3, totalQty: 15, warehouse: '省厅主仓库/主仓库1楼', inDate: '2023-03-20', inOrderNo: 'RK20230320001', inType: '采购入库', supplier: '红星装备厂', price: 1200, unit: '件', productionDate: '2023-03-15', expiryDate: '2028-03-15', maintenanceValue: 3, maintenanceUnit: '年', isFixedAsset: true, remark: 'III级防弹标准', lastCheck: '2024-04-15' },
  { rfid: 'RFID202401001A', equipmentCode: 'EQ202401001', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', status: 'out', stockQty: 0, totalQty: 12, warehouse: '省厅主仓库/主仓库2楼', inDate: '2024-01-15', inOrderNo: 'RK20240115002', inType: '采购入库', supplier: '红星装备厂', price: 1800, unit: '台', productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '4K高清', lastCheck: '2024-05-01' },
  { rfid: 'RFID202401001B', equipmentCode: 'EQ202401001', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', status: 'in_stock', stockQty: 8, totalQty: 12, warehouse: '省厅主仓库/主仓库2楼', inDate: '2024-01-15', inOrderNo: 'RK20240115002', inType: '采购入库', supplier: '红星装备厂', price: 1800, unit: '台', productionDate: '2024-01-20', expiryDate: '2027-01-20', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '4K高清', lastCheck: '2024-05-01' },
  { rfid: 'RFID202202112C', equipmentCode: 'EQ202202112', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', status: 'in_stock', stockQty: 18, totalQty: 20, warehouse: '01号装备室/东侧区域', inDate: '2022-06-10', inOrderNo: 'RK20220610003', inType: '采购入库', supplier: '红星装备厂', price: 280, unit: '个', productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年', isFixedAsset: false, remark: 'LED强光', lastCheck: '2024-05-10' },
  { rfid: 'RFID202401089D', equipmentCode: 'EQ202401089', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', status: 'in_stock', stockQty: 8, totalQty: 8, warehouse: '03号装备室/一楼', inDate: '2024-02-01', inOrderNo: 'RK20240201004', inType: '采购入库', supplier: '国安器材', price: 650, unit: '台', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年', isFixedAsset: true, remark: '800MHz频段', lastCheck: '2024-05-05' },
];

/* ─── mock lifecycle data ─── */
const LIFE_CYCLE_DATA: LifeCycleNode[] = [
  { id: '1', type: 'in', subType: '采购入库', time: '2023-03-20 09:30', operator: '张建国', department: '省厅装备处', description: '入库数量: 50台，存放位置: 省厅主仓库A区-01-03，供应商: 红星装备厂', rfid: 'RFID202301058B' },
  { id: '2', type: 'in', subType: '采购入库', time: '2023-03-20 09:30', operator: '张建国', department: '省厅装备处', description: '入库数量: 50台，存放位置: 省厅主仓库A区-01-04，供应商: 红星装备厂', rfid: 'RFID202301058C' },
  { id: '3', type: 'check', subType: '月度盘点', time: '2023-04-15 16:45', operator: '陈晓东', department: '仓库管理组', description: '盘点结果: 账实相符，盘点方式: 人工+RFID扫描，备注: 设备状态良好', rfid: 'RFID202301058B' },
  { id: '4', type: 'check', subType: '月度盘点', time: '2023-04-15 16:45', operator: '陈晓东', department: '仓库管理组', description: '盘点结果: 账实相符，盘点方式: 人工+RFID扫描，备注: 设备状态良好', rfid: 'RFID202301058C' },
  { id: '5', type: 'receive', subType: '任务领用', time: '2023-06-10 14:20', operator: '王志强', department: '刑警支队', description: '领用数量: 1台，领用事由: 专项行动保障，预计归还: 2023-07-10', rfid: 'RFID202301058B' },
  { id: '6', type: 'out', subType: '归还入库', time: '2023-07-08 09:15', operator: '王志强', department: '刑警支队', description: '归还数量: 1台，归还状态: 完好，存放位置: 省厅主仓库A区-01-03', rfid: 'RFID202301058B' },
  { id: '7', type: 'check', subType: '季度盘点', time: '2023-07-20 10:00', operator: '陈晓东', department: '仓库管理组', description: '盘点结果: 账实相符，备注: 无异常', rfid: 'RFID202301058C' },
  { id: '8', type: 'transfer', subType: '辖区调拨', time: '2023-08-15 11:30', operator: '刘建华', department: '装备调配中心', description: '调拨数量: 1台，调出仓库: 省厅主仓库A区-01-04，调入仓库: 市局限装备仓库B区-02-04', rfid: 'RFID202301058C' },
  { id: '9', type: 'check', subType: '月度盘点', time: '2023-09-15 14:30', operator: '陈晓东', department: '仓库管理组', description: '盘点结果: 账实相符，备注: 无异常', rfid: 'RFID202301058B' },
  { id: '10', type: 'repair', subType: '故障报修', time: '2024-01-20 09:00', operator: '赵明华', department: '设备维护组', description: '故障描述: 防弹层出现裂纹，报修人: 王强，维修方式: 返厂维修', rfid: 'RFID202301058B' },
  { id: '11', type: 'repair', subType: '维修完成', time: '2024-02-05 16:30', operator: '赵明华', department: '设备维护组', description: '维修结果: 更换防弹层，维修费用: 350元，维修后状态: 正常', rfid: 'RFID202301058B' },
  { id: '12', type: 'check', subType: '季度盘点', time: '2024-04-15 09:00', operator: '陈晓东', department: '仓库管理组', description: '盘点结果: 账实相符，备注: 设备状态良好', rfid: 'RFID202301058B' },
  { id: '13', type: 'receive', subType: '日常领用', time: '2024-05-10 10:30', operator: '李军', department: '交警支队', description: '领用数量: 1台，领用事由: 路面执勤，预计归还: 2024-06-10', rfid: 'RFID202301058B' },
];

/* ─── node type config ─── */
const nodeTypeConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  in:       { label: '入库',   color: 'text-blue-700',     bg: 'bg-blue-50',     icon: Archive },
  out:      { label: '出库',   color: 'text-sky-600',      bg: 'bg-sky-50',      icon: PackageOpen },
  receive:  { label: '领用',   color: 'text-green-700',    bg: 'bg-green-50',    icon: UserCheck },
  repair:   { label: '报修',   color: 'text-red-700',      bg: 'bg-red-50',      icon: Wrench },
  check:    { label: '盘点',   color: 'text-orange-700',   bg: 'bg-orange-50',   icon: ClipboardList },
  transfer: { label: '调拨',   color: 'text-indigo-700',   bg: 'bg-indigo-50',   icon: ArrowLeftRight },
  scrap:    { label: '报废',   color: 'text-gray-700',     bg: 'bg-gray-100',    icon: AlertTriangle },
};

/* merge same equipment */
function mergeEquipment(items: EquipmentRecord[]) {
  const map = new Map<string, EquipmentRecord[]>();
  items.forEach(item => {
    const key = `${item.name}|${item.model}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(item);
  });
  return Array.from(map.entries()).map(([, group]) => ({
    key: `${group[0].name}|${group[0].model}`,
    name: group[0].name,
    model: group[0].model,
    category: group[0].category,
    equipmentCode: group[0].equipmentCode,
    supplier: group[0].supplier,
    unit: group[0].unit,
    price: group[0].price,
    isFixedAsset: group[0].isFixedAsset,
    items: group,
    totalStock: group.filter(g => g.status === 'in_stock').reduce((s, g) => s + g.stockQty, 0),
    totalCount: group.length,
    rfidList: group.map(g => g.rfid),
  }));
}

type MergeResult = ReturnType<typeof mergeEquipment>[0];

/* highlight text */
function HighlightText({ text, query }: { text: string; query: string }) {
  if (!query.trim()) return <>{text}</>;
  const lowerText = text.toLowerCase();
  const lowerQuery = query.toLowerCase();
  if (!lowerText.includes(lowerQuery)) return <>{text}</>;
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let idx = lowerText.indexOf(lowerQuery, lastIndex);
  while (idx !== -1) {
    if (idx > lastIndex) parts.push(<span key={lastIndex}>{text.slice(lastIndex, idx)}</span>);
    parts.push(<span key={idx} className="text-[#1565c0] font-bold">{text.slice(idx, idx + query.length)}</span>);
    lastIndex = idx + query.length;
    idx = lowerText.indexOf(lowerQuery, lastIndex);
  }
  if (lastIndex < text.length) parts.push(<span key={lastIndex}>{text.slice(lastIndex)}</span>);
  return <>{parts}</>;
}

export default function Trace() {
  const [mode, setMode] = useState<'scan' | 'list' | 'detail' | 'empty'>('scan');
  const [searchText, setSearchText] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<MergeResult | null>(null);
  const [selectedRfid, setSelectedRfid] = useState('全部');
  const [scanAnim, setScanAnim] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  /* fuzzy search */
  const dropdownResults = useMemo(() => {
    const query = searchText.trim();
    if (!query) return [];
    const matched = EQUIPMENT_DB.filter(e =>
      e.rfid.toLowerCase().includes(query.toLowerCase()) ||
      e.equipmentCode.toLowerCase().includes(query.toLowerCase()) ||
      e.name.toLowerCase().includes(query.toLowerCase()) ||
      e.category.toLowerCase().includes(query.toLowerCase()) ||
      e.model.toLowerCase().includes(query.toLowerCase())
    );
    return mergeEquipment(matched).slice(0, 8);
  }, [searchText]);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setDropdownOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleSelectGroup = useCallback((group: MergeResult) => {
    setSelectedGroup(group);
    setSelectedRfid('全部');
    setMode('detail');
    setDropdownOpen(false);
  }, []);

  const handleScan = () => {
    setScanAnim(true);
    setTimeout(() => {
      setScanAnim(false);
      const randomItem = EQUIPMENT_DB[Math.floor(Math.random() * EQUIPMENT_DB.length)];
      const matched = mergeEquipment(EQUIPMENT_DB.filter(e => e.name === randomItem.name && e.model === randomItem.model));
      if (matched.length > 0) handleSelectGroup(matched[0]);
    }, 1500);
  };

  /* filtered lifecycle by RFID */
  const filteredLifecycle = useMemo(() => {
    if (!selectedGroup) return [];
    if (selectedRfid === '全部') return LIFE_CYCLE_DATA;
    return LIFE_CYCLE_DATA.filter(n => n.rfid === selectedRfid);
  }, [selectedRfid, selectedGroup]);

  /* get match label */
  function getMatchLabel(group: MergeResult, query: string): { code: string; name: string } {
    const q = query.toLowerCase().trim();
    if (group.equipmentCode.toLowerCase().includes(q)) return { code: group.equipmentCode, name: group.name };
    const matchedRfid = group.items.find(i => i.rfid.toLowerCase().includes(q));
    if (matchedRfid) return { code: matchedRfid.rfid, name: group.name };
    return { code: group.equipmentCode, name: group.name };
  }

  /* ═══════════ SCAN MODE ═══════════ */
  if (mode === 'scan') {
    return (
      <MobileLayout title="装备溯源" showBack>
        <div className="p-5">
          <div ref={searchRef} className="relative mb-4">
            <div className="bg-white rounded-2xl shadow-sm p-3">
              <p className="text-sm text-gray-500 mb-2">输入装备编码、RFID编码或名称查询溯源</p>
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={searchText}
                  onChange={e => { setSearchText(e.target.value); setDropdownOpen(e.target.value.trim().length > 0); }}
                  onFocus={() => { if (searchText.trim().length > 0) setDropdownOpen(true); }}
                  placeholder="输入关键词，如：防弹、30032、FDY"
                  className="w-full bg-gray-50 rounded-xl pl-9 pr-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
                />
              </div>
            </div>

            {dropdownOpen && (
              <div className="absolute z-50 left-0 right-0 mt-2 bg-white border border-gray-200 rounded-2xl shadow-xl overflow-hidden">
                {dropdownResults.length > 0 ? (
                  <div className="max-h-80 overflow-y-auto no-scrollbar">
                    <div className="px-3 py-2 bg-gray-50 text-[10px] text-gray-500">
                      共找到 {dropdownResults.length} 种装备（同种已合并）
                    </div>
                    {dropdownResults.map(group => {
                      const label = getMatchLabel(group, searchText);
                      return (
                        <button
                          key={group.key}
                          onClick={() => handleSelectGroup(group)}
                          className="w-full text-left px-4 py-3 hover:bg-blue-50 active:bg-blue-100 transition-colors border-b border-gray-50 last:border-0"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-gray-800 font-mono">
                              <HighlightText text={label.code} query={searchText} />
                            </span>
                            <span className="text-gray-300">·</span>
                            <span className="text-sm text-gray-700">
                              <HighlightText text={label.name} query={searchText} />
                            </span>
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[10px] text-gray-400">{group.model} | {group.category}</span>
                            <span className="ml-auto text-[10px] text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded font-medium">
                              库存{group.totalStock}{group.unit}
                            </span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-400">
                    <Database size={24} className="mx-auto mb-2" />
                    <p className="text-sm">无对应装备信息</p>
                    <p className="text-xs mt-1">请尝试其他关键词</p>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-sm text-center">
            <div className={`w-24 h-24 rounded-3xl flex items-center justify-center mx-auto mb-4 transition-all ${scanAnim ? 'bg-blue-100 scale-95' : 'bg-blue-50'}`}>
              {scanAnim ? <RefreshCw size={40} className="text-blue-600 animate-spin" /> : <QrCode size={40} className="text-blue-600" />}
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{scanAnim ? '正在扫描...' : '扫描RFID编码'}</h3>
            <p className="text-xs text-gray-500 mb-6">{scanAnim ? '请对准装备RFID标签' : '点击按钮模拟扫描装备RFID标签'}</p>
            <button onClick={handleScan} disabled={scanAnim} className={`w-full py-3.5 rounded-xl font-medium ${scanAnim ? 'bg-gray-200 text-gray-400' : 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'}`}>
              {scanAnim ? '扫描中...' : '开始扫描'}
            </button>
          </div>

          <div className="mt-4 bg-blue-50 border border-blue-100 rounded-xl p-3">
            <p className="text-xs text-blue-600 font-medium mb-1">溯源提示</p>
            <p className="text-[11px] text-blue-500">可查看见装备从入库到报废的全生命周期流转记录</p>
            <p className="text-[11px] text-blue-500 mt-0.5">可尝试搜索：防弹、30032、FDY、058B</p>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ LIST MODE ═══════════ */
  if (mode === 'list') {
    return (
      <MobileLayout title="搜索结果" showBack onBack={() => setMode('scan')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3">
            <p className="text-xs text-blue-700">关键词 "{searchText}" 的搜索结果</p>
          </div>
          <div className="space-y-2">
            {dropdownResults.map(group => (
              <button key={group.key} onClick={() => handleSelectGroup(group)} className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all">
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-gray-800">{group.name}</span>
                    <span className="text-xs text-gray-400">{group.model}</span>
                  </div>
                  <span className="text-xs text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full font-medium">库存{group.totalStock}{group.unit}</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Tag size={10} className="text-gray-400" />
                  <span className="text-[10px] text-gray-500 font-mono">{group.rfidList[0]}</span>
                  {group.rfidList.length > 1 && <span className="text-[10px] text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded">等{group.rfidList.length}个RFID</span>}
                </div>
              </button>
            ))}
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ DETAIL MODE ═══════════ */
  if (!selectedGroup) return null;

  const g = selectedGroup;
  const first = g.items[0];
  const rfidShortList = g.rfidList.map(r => ({ full: r, short: r.slice(-4) }));

  return (
    <MobileLayout title="装备溯源" showBack onBack={() => { setMode('scan'); setSearchText(''); }}>
      <div className="p-4">
        {/* Header */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center">
              <Eye size={28} className="text-blue-600" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900">{g.name}</h3>
              <p className="text-xs text-gray-500">{g.equipmentCode} · {g.model}</p>
            </div>
          </div>
          <div className="grid grid-cols-4 gap-2 mt-3">
            <div className="bg-blue-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-blue-600">{g.totalStock}</p>
              <p className="text-[9px] text-blue-600">在库</p>
            </div>
            <div className="bg-green-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-green-600">{g.items.filter(i => i.status === 'out').length}</p>
              <p className="text-[9px] text-green-600">已出库</p>
            </div>
            <div className="bg-orange-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-orange-600">{g.items.filter(i => i.status === 'repairing').length}</p>
              <p className="text-[9px] text-orange-600">维修中</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2 text-center">
              <p className="text-lg font-bold text-gray-600">{g.totalCount}</p>
              <p className="text-[9px] text-gray-600">RFID数</p>
            </div>
          </div>
        </div>

        {/* Material Detail - 16 fields */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Package size={14} className="text-blue-600" /> 物资明细
          </h3>
          <div className="space-y-2">
            {[
              { label: '物资名称', value: g.name, req: true },
              { label: '物资类别', value: first.category },
              { label: '规格型号', value: g.model },
              { label: '数量', value: `${g.totalStock} ${first.unit}`, req: true, hl: true },
              { label: '生产日期', value: first.productionDate },
              { label: '有效期', value: first.expiryDate },
              { label: '保养期', value: `${first.maintenanceValue}${first.maintenanceUnit}` },
              { label: '单位', value: first.unit, req: true },
              { label: '单价(¥)', value: `¥${first.price.toLocaleString()}`, req: true },
              { label: '总价(¥)', value: `¥${(first.price * g.totalStock).toLocaleString()}` },
              { label: '装备编码', value: g.equipmentCode },
              { label: 'RFID编码', value: `${g.rfidList[0]}${g.rfidList.length > 1 ? ` 等${g.rfidList.length}个` : ''}` },
              { label: '存储位置', value: first.warehouse, req: true },
              { label: '供应商', value: first.supplier, req: true },
              { label: '固定资产', value: first.isFixedAsset ? '是' : '否' },
              { label: '备注', value: first.remark || '—' },
            ].map((item, i) => (
              <div key={i} className="flex items-center justify-between py-1 border-b border-gray-50 last:border-0">
                <div className="flex items-center gap-1 text-gray-500">
                  <span className="text-xs">{item.label}</span>
                  {item.req && <span className="text-red-500 text-[10px]">*</span>}
                </div>
                <span className={`text-sm font-medium ${item.hl ? 'text-[#1565c0]' : 'text-gray-800'}`}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* RFID Filter Tabs */}
        {g.rfidList.length > 1 && (
          <div className="bg-white rounded-2xl p-3 shadow-sm mb-3">
            <div className="flex items-center gap-2 mb-2">
              <Tag size={12} className="text-gray-500" />
              <span className="text-xs text-gray-500">RFID筛选</span>
              <span className="text-[10px] text-gray-400 ml-auto">
                {selectedRfid === '全部' ? `共${filteredLifecycle.length}条记录` : `${filteredLifecycle.length}条记录`}
              </span>
            </div>
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar pb-1">
              <button
                onClick={() => setSelectedRfid('全部')}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  selectedRfid === '全部' ? 'bg-[#1565c0] text-white' : 'bg-gray-100 text-gray-600'
                }`}
              >
                全部
              </button>
              {rfidShortList.map(r => (
                <button
                  key={r.full}
                  onClick={() => setSelectedRfid(r.full)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all font-mono ${
                    selectedRfid === r.full ? 'bg-[#1565c0] text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  {r.short}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Life Cycle Timeline */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <Calendar size={14} className="text-blue-600" /> 全生命周期记录
          </h3>

          {filteredLifecycle.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <Database size={32} className="mx-auto mb-2" />
              <p className="text-sm">该RFID暂无生命周期记录</p>
            </div>
          ) : (
            <div className="relative">
              {/* vertical line */}
              <div className="absolute left-[17px] top-2 bottom-2 w-0.5 bg-gray-200" />

              <div className="space-y-0">
                {filteredLifecycle.map((node) => {
                  const cfg = nodeTypeConfig[node.type];
                  const NodeIcon = cfg.icon;

                  return (
                    <div key={node.id} className="relative flex gap-3 pb-5 last:pb-0">
                      {/* Dot */}
                      <div className={`w-9 h-9 rounded-full ${cfg.bg} flex items-center justify-center shrink-0 z-10 border-2 border-white shadow-sm`}>
                        <NodeIcon size={16} style={{ color: cfg.color.replace('text-', '').replace('-700', '').replace('-600', '') }} className={cfg.color} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0 -mt-0.5">
                        {/* Top row: type · time · operator · department */}
                        <div className="flex items-center flex-wrap gap-x-2 gap-y-0.5 mb-1">
                          <span className={`text-xs font-bold ${cfg.color}`}>{cfg.label}</span>
                          <span className="text-[10px] text-gray-400">{node.time}</span>
                          <span className="text-[10px] text-gray-500">{node.operator}</span>
                          <span className="text-[10px] text-gray-400">{node.department}</span>
                        </div>

                        {/* Sub type */}
                        <p className="text-sm font-semibold text-gray-800 mb-1">{node.subType}</p>

                        {/* Description */}
                        <p className="text-xs text-gray-500 leading-relaxed">{node.description}</p>

                        {/* RFID tag (only in "all" mode) */}
                        {selectedRfid === '全部' && g.rfidList.length > 1 && (
                          <span className="inline-block mt-1 text-[10px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded font-mono">
                            {node.rfid.slice(-6)}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="bg-gray-50 rounded-2xl p-3 mb-6">
          <p className="text-[10px] text-gray-500 mb-2 font-medium">节点图例</p>
          <div className="flex flex-wrap gap-2">
            {Object.entries(nodeTypeConfig).map(([key, cfg]) => {
              const Icon = cfg.icon;
              return (
                <div key={key} className="flex items-center gap-1">
                  <div className={`w-5 h-5 rounded-full ${cfg.bg} flex items-center justify-center`}>
                    <Icon size={10} className={cfg.color} />
                  </div>
                  <span className="text-[10px] text-gray-600">{cfg.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
