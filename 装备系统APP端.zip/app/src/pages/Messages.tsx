import { useState } from 'react';
import MobileLayout from '@/components/MobileLayout';
import { messageList } from '@/data/mock';
import { ClipboardCheck, Wrench, Bell, GitCommit, Check } from 'lucide-react';

const tabs = [
  { key: 'all', label: '全部' },
  { key: 'approval', label: '审批' },
  { key: 'repair', label: '报修' },
  { key: 'warning', label: '预警' },
  { key: 'business', label: '业务' },
];

const typeConfig: Record<string, { icon: React.ElementType; bg: string; color: string; label: string }> = {
  approval: { icon: ClipboardCheck, bg: 'bg-blue-50', color: 'text-blue-600', label: '审批' },
  repair: { icon: Wrench, bg: 'bg-green-50', color: 'text-green-600', label: '报修' },
  warning: { icon: Bell, bg: 'bg-orange-50', color: 'text-orange-600', label: '预警' },
  business: { icon: GitCommit, bg: 'bg-purple-50', color: 'text-purple-600', label: '业务' },
};

export default function Messages() {
  const [activeTab, setActiveTab] = useState('all');
  const filtered = activeTab === 'all' ? messageList : messageList.filter(m => m.type === activeTab);
  const [readIds, setReadIds] = useState<Set<number>>(new Set());

  const markRead = (id: number) => {
    setReadIds(prev => new Set(prev).add(id));
  };

  return (
    <MobileLayout title="消息通知" showBack>
      {/* Tabs */}
      <div className="sticky top-0 z-40 bg-[#f0f4f8] pt-2 pb-0">
        <div className="flex px-4 gap-2 overflow-x-auto no-scrollbar">
          {tabs.map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                activeTab === t.key
                  ? 'bg-[#1565c0] text-white shadow-md shadow-blue-900/20'
                  : 'bg-white text-gray-600'
              }`}
            >
              {t.label}
              {t.key === 'all' && <span className="ml-1 text-[10px]">({messageList.length})</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Message List */}
      <div className="px-4 pt-3 pb-4">
        <div className="space-y-2">
          {filtered.map(msg => {
            const config = typeConfig[msg.type];
            const Icon = config.icon;
            const isRead = readIds.has(msg.id);
            return (
              <button
                key={msg.id}
                onClick={() => markRead(msg.id)}
                className={`w-full bg-white rounded-2xl p-4 text-left active:scale-[0.98] transition-all shadow-sm ${!isRead ? 'border-l-4 border-[#1565c0]' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-xl ${config.bg} flex items-center justify-center shrink-0`}>
                    <Icon size={16} className={config.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-1">
                      <p className={`text-sm ${!isRead ? 'font-semibold text-gray-900' : 'font-medium text-gray-700'}`}>{msg.title}</p>
                      {!msg.read && !isRead && <span className="w-2 h-2 bg-red-500 rounded-full shrink-0" />}
                    </div>
                    <p className="text-xs text-gray-500 leading-relaxed">{msg.content}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-[10px] text-gray-400">{msg.time}</span>
                      {(isRead || msg.read) && (
                        <span className="text-[10px] text-gray-400 flex items-center gap-0.5">
                          <Check size={10} /> 已读
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <Bell size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无通知</p>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
