import { useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Search, Shield, ShieldAlert, UserCog,
  ChevronRight, Building2, Clock, CheckCircle2,
  Filter
} from 'lucide-react';

/* ─── types ─── */
interface UserRecord {
  id: string;
  account: string;
  name: string;
  unit: string;
  role: 'senior_admin' | 'admin' | 'user';
  status: 'enabled' | 'disabled' | 'abnormal';
  createTime: string;
  lastLoginTime: string;
  lastLoginIp: string;
  phone: string;
  loginCount: number;
}

interface ResetLog {
  id: string;
  targetUser: string;
  operator: string;
  operateTime: string;
  reason: string;
  remark: string;
}

/* ─── mock data ─── */
const mockUsers: UserRecord[] = [
  { id: 'U001', account: 'admin001', name: '张建国', unit: '省厅装备处', role: 'senior_admin', status: 'enabled', createTime: '2023-01-10 09:00', lastLoginTime: '2024-05-20 08:30', lastLoginIp: '10.168.1.23', phone: '138****0001', loginCount: 328 },
  { id: 'U002', account: 'admin002', name: '李秀芬', unit: '朝阳分局', role: 'admin', status: 'enabled', createTime: '2023-03-15 14:20', lastLoginTime: '2024-05-19 17:45', lastLoginIp: '10.168.2.56', phone: '139****0002', loginCount: 186 },
  { id: 'U003', account: 'u01001', name: '王强', unit: '朝阳分局刑侦大队', role: 'user', status: 'enabled', createTime: '2023-06-01 08:30', lastLoginTime: '2024-05-20 07:15', lastLoginIp: '10.168.3.12', phone: '137****0003', loginCount: 245 },
  { id: 'U004', account: 'u01002', name: '李明', unit: '东城分局巡警支队', role: 'user', status: 'disabled', createTime: '2023-06-01 09:00', lastLoginTime: '2024-04-28 16:30', lastLoginIp: '10.168.4.34', phone: '136****0004', loginCount: 112 },
  { id: 'U005', account: 'u01003', name: '赵刚', unit: '西城分局特警大队', role: 'user', status: 'enabled', createTime: '2023-08-12 10:15', lastLoginTime: '2024-05-18 20:00', lastLoginIp: '10.168.5.78', phone: '135****0005', loginCount: 198 },
  { id: 'U006', account: 'u01004', name: '孙丽', unit: '海淀分局治安大队', role: 'user', status: 'enabled', createTime: '2023-09-05 11:30', lastLoginTime: '2024-05-20 09:00', lastLoginIp: '10.168.6.90', phone: '134****0006', loginCount: 167 },
  { id: 'U007', account: 'u01005', name: '周涛', unit: '丰台分局交警大队', role: 'user', status: 'enabled', createTime: '2023-10-20 13:45', lastLoginTime: '2024-05-19 18:30', lastLoginIp: '10.168.7.45', phone: '133****0007', loginCount: 203 },
  { id: 'U008', account: 'u01006', name: '张伟', unit: '昌平分局刑警大队', role: 'user', status: 'enabled', createTime: '2024-01-08 08:00', lastLoginTime: '2024-05-17 15:20', lastLoginIp: '10.168.8.67', phone: '132****0008', loginCount: 89 },
  { id: 'U009', account: 'u01007', name: '刘洋', unit: '通州分局派出所', role: 'user', status: 'enabled', createTime: '2024-02-14 09:30', lastLoginTime: '2024-05-20 06:50', lastLoginIp: '10.168.9.12', phone: '131****0009', loginCount: 56 },
  { id: 'U010', account: 'u01008', name: '陈静', unit: '大兴分局治安大队', role: 'user', status: 'abnormal', createTime: '2024-03-01 10:00', lastLoginTime: '2024-05-10 11:00', lastLoginIp: '10.168.10.88', phone: '130****0010', loginCount: 34 },
];

// Current login user (senior admin)
const CURRENT_USER: UserRecord = mockUsers[0];

/* ─── reset logs ─── */
export const mockResetLogs: ResetLog[] = [
  { id: 'RS001', targetUser: 'U004', operator: '张建国', operateTime: '2024-04-15 10:30', reason: '遗忘密码', remark: '用户多次输错密码导致锁定' },
  { id: 'RS002', targetUser: 'U010', operator: '张建国', operateTime: '2024-05-08 14:20', reason: '账号异常', remark: '发现异常登录行为，先禁用再重置' },
  { id: 'RS003', targetUser: 'U006', operator: '张建国', operateTime: '2024-03-22 09:15', reason: '其他', remark: '用户手机丢失，担心密码泄露' },
];

/* ─── unit options ─── */
const unitOptions = ['全部', '省厅装备处', '朝阳分局', '朝阳分局刑侦大队', '东城分局巡警支队', '西城分局特警大队', '海淀分局治安大队', '丰台分局交警大队', '昌平分局刑警大队', '通州分局派出所', '大兴分局治安大队'];

/* ─── role config ─── */
const roleConfig: Record<string, { label: string; color: string; bg: string }> = {
  senior_admin: { label: '高级管理员', color: 'text-red-600', bg: 'bg-red-50' },
  admin: { label: '普通管理员', color: 'text-orange-600', bg: 'bg-orange-50' },
  user: { label: '普通用户', color: 'text-blue-600', bg: 'bg-blue-50' },
};

const statusConfig: Record<string, { label: string; color: string; bg: string; dot: string }> = {
  enabled:  { label: '启用', color: 'text-green-600', bg: 'bg-green-50', dot: 'bg-green-500' },
  disabled: { label: '禁用', color: 'text-gray-500', bg: 'bg-gray-100', dot: 'bg-gray-400' },
  abnormal: { label: '异常', color: 'text-red-600', bg: 'bg-red-50', dot: 'bg-red-500' },
};

/* ─── main component ─── */
export default function UserManage() {
  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');
  const [unitFilter, setUnitFilter] = useState('全部');
  const [roleFilter, setRoleFilter] = useState('全部');
  const [statusFilter, setStatusFilter] = useState('全部');
  const [showFilter, setShowFilter] = useState(false);

  const isSeniorAdmin = CURRENT_USER.role === 'senior_admin';

  /* filtered users */
  const filteredUsers = useMemo(() => {
    let list = [...mockUsers];

    // Search
    if (searchText.trim()) {
      const kw = searchText.toLowerCase();
      list = list.filter(u =>
        u.name.toLowerCase().includes(kw) ||
        u.account.toLowerCase().includes(kw) ||
        u.unit.includes(kw)
      );
    }

    // Unit filter
    if (unitFilter !== '全部') {
      list = list.filter(u => u.unit === unitFilter);
    }

    // Role filter
    if (roleFilter !== '全部') {
      list = list.filter(u => u.role === roleFilter);
    }

    // Status filter
    if (statusFilter !== '全部') {
      list = list.filter(u => u.status === statusFilter);
    }

    return list;
  }, [searchText, unitFilter, roleFilter, statusFilter]);

  /* stats */
  const stats = useMemo(() => ({
    total: mockUsers.length,
    enabled: mockUsers.filter(u => u.status === 'enabled').length,
    disabled: mockUsers.filter(u => u.status === 'disabled').length,
    abnormal: mockUsers.filter(u => u.status === 'abnormal').length,
  }), []);

  /* active filter count */
  const activeFilterCount = [unitFilter !== '全部', roleFilter !== '全部', statusFilter !== '全部'].filter(Boolean).length;

  const clearFilters = useCallback(() => {
    setUnitFilter('全部');
    setRoleFilter('全部');
    setStatusFilter('全部');
  }, []);

  return (
    <MobileLayout title="用户管理" showBack>
      {/* ── Permission Banner ── */}
      <div className="mx-4 mt-3 mb-2">
        <div className={`rounded-xl px-3 py-2.5 flex items-center gap-2 ${
          isSeniorAdmin ? 'bg-blue-50' : 'bg-orange-50'
        }`}>
          {isSeniorAdmin ? (
            <Shield size={16} className="text-blue-600 shrink-0" />
          ) : (
            <ShieldAlert size={16} className="text-orange-600 shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-gray-700">
              当前身份：
              <span className={isSeniorAdmin ? 'text-blue-600' : 'text-orange-600'}>
                {roleConfig[CURRENT_USER.role].label}
              </span>
            </p>
            <p className="text-[10px] text-gray-500">
              {isSeniorAdmin
                ? '拥有用户查询、密码重置等全部权限'
                : '仅可查看本辖区用户信息，无操作权限'}
            </p>
          </div>
        </div>
      </div>

      {/* ── Search Bar ── */}
      <div className="px-4 mb-2">
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              value={searchText}
              onChange={e => setSearchText(e.target.value)}
              placeholder="搜索姓名、账号..."
              className="w-full bg-white rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-gray-200 focus:border-blue-300 transition-all shadow-sm"
            />
          </div>
          <button
            onClick={() => setShowFilter(!showFilter)}
            className={`shrink-0 px-3 py-2.5 rounded-xl text-sm font-medium flex items-center gap-1.5 transition-all border shadow-sm ${
              showFilter || activeFilterCount > 0
                ? 'bg-[#1565c0] text-white border-[#1565c0]'
                : 'bg-white text-gray-600 border-gray-200'
            }`}
          >
            <Filter size={14} />
            筛选
            {activeFilterCount > 0 && (
              <span className="w-5 h-5 rounded-full bg-white/20 text-white text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* ── Filter Panel ── */}
      {showFilter && (
        <div className="px-4 mb-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            {/* Unit */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                <Building2 size={10} /> 所属单位
              </p>
              <div className="flex flex-wrap gap-1.5">
                {unitOptions.map(u => (
                  <button
                    key={u}
                    onClick={() => setUnitFilter(u)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all ${
                      unitFilter === u
                        ? 'bg-[#1565c0] text-white'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {u}
                  </button>
                ))}
              </div>
            </div>

            {/* Role */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                <UserCog size={10} /> 用户角色
              </p>
              <div className="flex gap-1.5">
                {[
                  { key: '全部', label: '全部' },
                  { key: 'senior_admin', label: '高级管理员' },
                  { key: 'admin', label: '普通管理员' },
                  { key: 'user', label: '普通用户' },
                ].map(r => (
                  <button
                    key={r.key}
                    onClick={() => setRoleFilter(r.key)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all ${
                      roleFilter === r.key
                        ? 'bg-[#1565c0] text-white'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Status */}
            <div className="mb-3">
              <p className="text-xs text-gray-500 mb-2 flex items-center gap-1">
                <CheckCircle2 size={10} /> 账号状态
              </p>
              <div className="flex gap-1.5">
                {[
                  { key: '全部', label: '全部' },
                  { key: 'enabled', label: '启用' },
                  { key: 'disabled', label: '禁用' },
                  { key: 'abnormal', label: '异常' },
                ].map(s => (
                  <button
                    key={s.key}
                    onClick={() => setStatusFilter(s.key)}
                    className={`px-2.5 py-1 rounded-lg text-[10px] font-medium transition-all ${
                      statusFilter === s.key
                        ? 'bg-[#1565c0] text-white'
                        : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Clear */}
            {activeFilterCount > 0 && (
              <button
                onClick={clearFilters}
                className="w-full py-2 text-xs text-gray-500 bg-gray-50 rounded-lg active:bg-gray-100 transition-colors"
              >
                清除全部筛选
              </button>
            )}
          </div>
        </div>
      )}

      {/* ── Stats ── */}
      <div className="px-4 mb-3">
        <div className="flex gap-2">
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-[#1565c0]">{stats.total}</p>
            <p className="text-[10px] text-gray-500">总用户</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-green-600">{stats.enabled}</p>
            <p className="text-[10px] text-gray-500">启用</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-gray-500">{stats.disabled}</p>
            <p className="text-[10px] text-gray-500">禁用</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-red-500">{stats.abnormal}</p>
            <p className="text-[10px] text-gray-500">异常</p>
          </div>
        </div>
      </div>

      {/* ── User List ── */}
      <div className="px-4 pb-4 space-y-2">
        {filteredUsers.map(user => {
          const rc = roleConfig[user.role];
          const sc = statusConfig[user.status];
          return (
            <button
              key={user.id}
              onClick={() => navigate(`/users/${user.id}`)}
              className="w-full bg-white rounded-2xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                {/* Avatar */}
                <div className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${
                  user.status === 'abnormal' ? 'bg-red-50' :
                  user.status === 'disabled' ? 'bg-gray-100' :
                  user.role === 'senior_admin' ? 'bg-red-50' :
                  user.role === 'admin' ? 'bg-orange-50' : 'bg-blue-50'
                }`}>
                  <span className={`text-sm font-bold ${
                    user.status === 'abnormal' ? 'text-red-600' :
                    user.status === 'disabled' ? 'text-gray-500' :
                    user.role === 'senior_admin' ? 'text-red-600' :
                    user.role === 'admin' ? 'text-orange-600' : 'text-blue-600'
                  }`}>
                    {user.name[0]}
                  </span>
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="text-sm font-semibold text-gray-800">{user.name}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>
                      <span className={`inline-block w-1.5 h-1.5 rounded-full ${sc.dot} mr-1`} />
                      {sc.label}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${rc.bg} ${rc.color}`}>
                      {rc.label}
                    </span>
                  </div>
                  <p className="text-xs text-gray-500">
                    {user.account} · {user.unit}
                  </p>
                  <p className="text-[10px] text-gray-400 mt-0.5 flex items-center gap-1">
                    <Clock size={9} /> 最后登录：{user.lastLoginTime}
                  </p>
                </div>

                <ChevronRight size={16} className="text-gray-400 shrink-0" />
              </div>
            </button>
          );
        })}

        {filteredUsers.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <UserCog size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">未找到匹配用户</p>
            <button
              onClick={clearFilters}
              className="mt-2 text-xs text-[#1565c0] font-medium"
            >
              清除筛选条件
            </button>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
