import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Wrench, Plus, QrCode, CheckCircle2, Clock,
  RotateCcw, Package, ChevronRight, RefreshCw, Shield,
  CalendarDays, FileText, CircleDot
} from 'lucide-react';

/* ─── types ─── */
interface RepairItem {
  id: string; name: string; category: string; model: string;
  quantity: number; unit: string; price: number; total: number;
  equipmentCode: string; rfidCode: string;
  storageLocation: string; supplier: string;
  isFixedAsset: boolean; remark: string;
  productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
}

interface RepairOrder {
  id: string; status: 'pending' | 'repairing' | 'completed' | 'withdrawn';
  applyTime: string; completeTime?: string;
  reporter: string; description: string; deadline: string;
  items: RepairItem[];
}

/* ─── mock data ─── */
const mockOrders: RepairOrder[] = [
  {
    id: 'WX20240520001', status: 'pending', applyTime: '2024-05-20 09:30',
    reporter: '张伟', description: '执法记录仪无法开机，疑似电池故障', deadline: '2024-05-25 18:00',
    items: [{ id: '1', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', price: 1800, total: 1800, equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', storageLocation: '省厅主仓库/主仓库2楼', supplier: '红星装备厂', isFixedAsset: true, remark: '4K高清', productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  {
    id: 'WX20240519002', status: 'repairing', applyTime: '2024-05-19 14:00',
    reporter: '王强', description: '战术手电开关接触不良，时亮时灭', deadline: '2024-05-24 18:00',
    completeTime: '', items: [{ id: '2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', price: 280, total: 280, equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', isFixedAsset: false, remark: 'LED强光', productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年' }],
  },
  {
    id: 'WX20240518003', status: 'completed', applyTime: '2024-05-18 10:20',
    reporter: '李明', description: '防刺手套掌心部位磨损严重', deadline: '2024-05-23 18:00',
    completeTime: '2024-05-22 16:30',
    items: [{ id: '3', name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 1, unit: '双', price: 150, total: 150, equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A', storageLocation: '02号装备室/A区', supplier: '盾甲科技', isFixedAsset: false, remark: '', productionDate: '2023-05-10', expiryDate: '2026-05-10', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  {
    id: 'WX20240517004', status: 'pending', applyTime: '2024-05-17 16:45',
    reporter: '赵刚', description: '防弹背心魔术贴脱落，影响穿戴', deadline: '2024-05-27 18:00',
    items: [{ id: '4', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058F', storageLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', isFixedAsset: true, remark: 'III级防弹标准', productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年' }],
  },
  {
    id: 'WX20240516005', status: 'withdrawn', applyTime: '2024-05-16 11:00',
    reporter: '孙丽', description: '对讲机信号不稳定', deadline: '2024-05-21 18:00',
    items: [{ id: '5', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 1, unit: '台', price: 650, total: 650, equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D', storageLocation: '03号装备室/一楼', supplier: '国安器材', isFixedAsset: true, remark: '800MHz频段', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  {
    id: 'WX20240515006', status: 'completed', applyTime: '2024-05-15 08:30',
    reporter: '周涛', description: '警棍表面氧化生锈', deadline: '2024-05-20 18:00',
    completeTime: '2024-05-19 14:00',
    items: [{ id: '6', name: '警棍', category: '械具', model: 'JG-2019', quantity: 2, unit: '根', price: 120, total: 240, equipmentCode: 'EQ201908176', rfidCode: 'RFID201908176E,RFID201908177E', storageLocation: '02号装备室/B区', supplier: '红星装备厂', isFixedAsset: false, remark: '', productionDate: '2019-08-15', expiryDate: '2022-08-15', maintenanceValue: 3, maintenanceUnit: '年' }],
  },
];

// Personal equipment (in-use status only)
const personalEquipList: RepairItem[] = [
  { id: 'pe1', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058B', storageLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', isFixedAsset: true, remark: 'III级防弹标准', productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年' },
  { id: 'pe2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', price: 280, total: 280, equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', isFixedAsset: false, remark: 'LED强光', productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年' },
  { id: 'pe3', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 1, unit: '台', price: 650, total: 650, equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D', storageLocation: '03号装备室/一楼', supplier: '国安器材', isFixedAsset: true, remark: '800MHz频段', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年' },
  { id: 'pe4', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', price: 1800, total: 1800, equipmentCode: 'EQ202401001', rfidCode: 'RFID202401001A', storageLocation: '省厅主仓库/主仓库2楼', supplier: '红星装备厂', isFixedAsset: true, remark: '4K高清', productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年' },
];

const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending: { label: '待审批', color: 'text-orange-600', bg: 'bg-orange-50', icon: Clock },
  repairing: { label: '维修中', color: 'text-purple-600', bg: 'bg-purple-50', icon: Wrench },
  completed: { label: '已办结', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  withdrawn: { label: '已撤回', color: 'text-gray-500', bg: 'bg-gray-100', icon: RotateCcw },
};

function genOrderNo() {
  const d = new Date();
  return `WX${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}${String(Math.floor(Math.random() * 900) + 100).padStart(3, '0')}`;
}

export default function Repair() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'select' | 'form' | 'success'>('list');
  const [orders, setOrders] = useState(mockOrders);
  const [activeFilter, setActiveFilter] = useState('全部');
  const [selectedItem, setSelectedItem] = useState<RepairItem | null>(null);
  const [description, setDescription] = useState('');
  const [deadline, setDeadline] = useState('');
  const [scanResult, setScanResult] = useState<{ msg: string; ok: boolean } | null>(null);
  const [scanAnim, setScanAnim] = useState(false);

  const filtered = activeFilter === '全部' ? orders
    : activeFilter === '已撤回' ? orders.filter(o => o.status === 'withdrawn')
    : orders.filter(o => statusConfig[o.status].label === activeFilter);

  const isOverdue = (order: RepairOrder) => {
    if (order.status === 'completed' || order.status === 'withdrawn') return false;
    return new Date(order.deadline) < new Date();
  };

  /* ─── SCAN ─── */
  const handleScan = useCallback(() => {
    setScanAnim(true);
    setTimeout(() => {
      setScanAnim(false);
      const names = ['执法记录仪', '战术手电', '对讲机'];
      const mockName = names[Math.floor(Math.random() * names.length)];
      const found = personalEquipList.find(e => e.name === mockName);
      if (found) {
        setSelectedItem(found);
        setScanResult({ msg: `已识别：${found.rfidCode} · ${found.name}`, ok: true });
        setTimeout(() => setStep('form'), 800);
      } else {
        setScanResult({ msg: '该装备非领用状态，禁止报修', ok: false });
      }
      setTimeout(() => setScanResult(null), 3000);
    }, 1500);
  }, []);

  const handleSelectEquip = (item: RepairItem) => {
    setSelectedItem(item);
    // Set default deadline to 5 days later
    const d = new Date();
    d.setDate(d.getDate() + 5);
    setDeadline(d.toISOString().slice(0, 16));
    setStep('form');
  };

  const handleSubmit = () => {
    if (!selectedItem || !description.trim()) return;
    const newOrder: RepairOrder = {
      id: genOrderNo(), status: 'pending', applyTime: new Date().toLocaleString('zh-CN'),
      reporter: '张伟', description: description.trim(), deadline,
      items: [{ ...selectedItem }],
    };
    setOrders(prev => [newOrder, ...prev]);
    setStep('success');
  };

  const resetForm = () => {
    setSelectedItem(null);
    setDescription('');
    setDeadline('');
  };

  /* ═══════════ LIST ═══════════ */
  if (step === 'list') {
    return (
      <MobileLayout title="快速报修" showBack rightAction={
        <button onClick={() => { setStep('select'); resetForm(); }} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">新建报修</button>
      }>
        {/* Stats */}
        <div className="px-4 pt-3 pb-2 flex gap-2">
          {[
            { label: '待审批', value: orders.filter(o => o.status === 'pending').length, color: 'text-orange-600' },
            { label: '维修中', value: orders.filter(o => o.status === 'repairing').length, color: 'text-purple-600' },
            { label: '已办结', value: orders.filter(o => o.status === 'completed').length, color: 'text-green-600' },
            { label: '已撤回', value: orders.filter(o => o.status === 'withdrawn').length, color: 'text-gray-500' },
          ].map(s => (
            <div key={s.label} className="flex-1 bg-white rounded-2xl p-2.5 shadow-sm text-center">
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[9px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Filter */}
        <div className="px-4 py-2">
          <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
            {['全部', '待审批', '维修中', '已办结', '已撤回'].map(t => (
              <button key={t} onClick={() => setActiveFilter(t)} className={`px-3 py-1.5 rounded-full text-xs whitespace-nowrap transition-all ${activeFilter === t ? 'bg-[#1565c0] text-white' : 'bg-white text-gray-600 shadow-sm'}`}>{t}</button>
            ))}
          </div>
        </div>

        {/* List */}
        <div className="px-4 pb-4 space-y-2">
          {filtered.map(order => {
            const sc = statusConfig[order.status];
            const overdue = isOverdue(order);
            return (
              <button
                key={order.id}
                onClick={() => navigate(`/repair/${order.id}`)}
                className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-gray-800 font-mono">{order.id}</span>
                    <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>{sc.label}</span>
                    {overdue && <span className="px-1.5 py-0.5 bg-red-50 text-red-600 rounded text-[10px] font-medium">超期</span>}
                  </div>
                </div>
                <p className="text-sm text-gray-700 mb-1 line-clamp-1">{order.items[0]?.name} · {order.description}</p>
                <div className="flex items-center justify-between text-xs text-gray-500">
                  <span className="flex items-center gap-1"><Clock size={10} /> {order.applyTime}</span>
                  <span>要求完成：{order.deadline.split(' ')[0]}</span>
                </div>
              </button>
            );
          })}
        </div>

        <button onClick={() => { setStep('select'); resetForm(); }} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors">
          <Plus size={24} />
        </button>
      </MobileLayout>
    );
  }

  /* ═══════════ SELECT EQUIPMENT ═══════════ */
  if (step === 'select') {
    return (
      <MobileLayout title="选择报修装备" showBack onBack={() => setStep('list')}>
        <div className="p-4">
          {/* Scan */}
          <div className="bg-white rounded-2xl p-5 shadow-sm mb-4 text-center">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-3 transition-all ${scanAnim ? 'bg-blue-100' : 'bg-blue-50'}`}>
              {scanAnim ? <RefreshCw size={36} className="text-blue-600 animate-spin" /> : <QrCode size={36} className="text-blue-600" />}
            </div>
            <h3 className="text-base font-semibold text-gray-800 mb-1">{scanAnim ? '正在扫描...' : '扫码报修'}</h3>
            <p className="text-xs text-gray-500 mb-4">扫描故障装备的RFID编码</p>
            <button onClick={handleScan} disabled={scanAnim} className={`w-full py-3 rounded-xl font-medium ${scanAnim ? 'bg-gray-200 text-gray-400' : 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'}`}>
              {scanAnim ? '扫描中...' : '开始扫描'}
            </button>
            {scanResult && (
              <div className={`mt-3 border rounded-xl p-2.5 flex items-center gap-2 ${scanResult.ok ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                <CheckCircle2 size={14} className={scanResult.ok ? 'text-green-600' : 'text-red-600'} />
                <span className={`text-xs ${scanResult.ok ? 'text-green-700' : 'text-red-700'}`}>{scanResult.msg}</span>
              </div>
            )}
          </div>

          {/* Personal Equipment */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Shield size={14} className="text-blue-600" /> 我的装备（在使用）
            </h3>
            <p className="text-xs text-gray-400 mb-3">仅可选择已领用且在使用状态的装备</p>
            <div className="space-y-2">
              {personalEquipList.map(item => (
                <button
                  key={item.id}
                  onClick={() => handleSelectEquip(item)}
                  className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-xl text-left active:bg-blue-50 transition-colors"
                >
                  <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center">
                    <Wrench size={18} className="text-blue-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.equipmentCode} · {item.model}</p>
                    <p className="text-[10px] text-gray-400">{item.storageLocation}</p>
                  </div>
                  <ChevronRight size={18} className="text-gray-400" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ FORM ═══════════ */
  if (step === 'form') {
    const item = selectedItem;
    if (!item) return null;

    return (
      <MobileLayout title="填写报修信息" showBack onBack={() => setStep('select')}>
        <div className="p-4">
          {/* Order Info */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div><p className="text-[10px] text-blue-600">报修单号</p><p className="text-sm font-semibold text-blue-800 font-mono">{genOrderNo()}</p></div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          {/* Auto info */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">申请时间</span><span className="text-xs text-gray-800">{new Date().toLocaleString('zh-CN')}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gray-500">报修人</span><span className="text-xs text-gray-800">张伟</span></div>
            </div>
          </div>

          {/* Material Detail (auto) */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <Package size={14} className="text-blue-600" /> 物资明细（自动带出）
            </h3>
            <div className="space-y-2">
              {[
                { label: '物资名称', value: item.name },
                { label: '物资类别', value: item.category },
                { label: '规格型号', value: item.model },
                { label: '数量', value: `${item.quantity} ${item.unit}` },
                { label: '生产日期', value: item.productionDate },
                { label: '有效期', value: item.expiryDate },
                { label: '保养期', value: `${item.maintenanceValue}${item.maintenanceUnit}` },
                { label: '装备编码', value: item.equipmentCode },
                { label: 'RFID编码', value: item.rfidCode },
                { label: '存储位置', value: item.storageLocation },
                { label: '供应商', value: item.supplier },
                { label: '单价(¥)', value: `¥${item.price}` },
                { label: '固定资产', value: item.isFixedAsset ? '是' : '否' },
                { label: '备注', value: item.remark || '—' },
              ].map((f, i) => (
                <div key={i} className="flex justify-between py-1 border-b border-gray-50 last:border-0">
                  <span className="text-xs text-gray-500">{f.label}</span>
                  <span className="text-xs text-gray-800 font-medium">{f.value}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <label className="text-sm font-semibold text-gray-800 mb-2 block flex items-center gap-2">
              <FileText size={14} className="text-orange-600" /> 报修说明 <span className="text-red-500">*</span>
            </label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="请详细描述故障现象..."
              rows={3}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all resize-none"
            />
          </div>

          {/* Deadline */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <label className="text-sm font-semibold text-gray-800 mb-2 block flex items-center gap-2">
              <CalendarDays size={14} className="text-blue-600" /> 要求完成时间
            </label>
            <input
              type="datetime-local"
              value={deadline}
              onChange={e => setDeadline(e.target.value)}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all"
            />
          </div>

          {/* Rules */}
          <div className="bg-gray-50 rounded-2xl p-3 mb-4">
            <p className="text-[10px] text-gray-500 leading-relaxed">1. 仅已领用、在使用状态的装备可发起报修</p>
            <p className="text-[10px] text-gray-500 leading-relaxed">2. 报修工单提交后在未审批状态下可撤回</p>
            <p className="text-[10px] text-gray-500 leading-relaxed">3. 所有报修节点状态实时更新，全程可溯源</p>
          </div>

          <button
            onClick={handleSubmit}
            disabled={!description.trim()}
            className={`w-full py-3.5 rounded-xl font-medium transition-colors mb-6 ${description.trim() ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}
          >
            提交报修申请
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ═══════════ SUCCESS ═══════════ */
  return (
    <MobileLayout title="报修成功" showBack onBack={() => { setStep('list'); resetForm(); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">报修工单已提交</h3>
        <p className="text-sm text-gray-500 text-center mb-6">系统将自动推送至警保部门，审批通过后将对接维修</p>
        <div className="w-full bg-white rounded-2xl p-4 shadow-sm mb-6 space-y-2">
          <div className="flex justify-between"><span className="text-xs text-gray-500">报修装备</span><span className="text-sm text-gray-800">{selectedItem?.name}</span></div>
          <div className="flex justify-between"><span className="text-xs text-gray-500">当前状态</span><span className="text-sm text-orange-600 font-medium">待审批</span></div>
        </div>
        <button onClick={() => { setStep('list'); resetForm(); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">返回报修列表</button>
      </div>
    </MobileLayout>
  );
}
