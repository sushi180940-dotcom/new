import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  Wrench, CheckCircle2, Clock, RotateCcw, Package,
  FileText, CircleDot
} from 'lucide-react';

interface RepairItem {
  id: string; name: string; category: string; model: string;
  quantity: number; unit: string; price: number; total: number;
  equipmentCode: string; rfidCode: string;
  storageLocation: string; supplier: string;
  isFixedAsset: boolean; remark: string;
  productionDate: string; expiryDate: string;
  maintenanceValue: number; maintenanceUnit: string;
}

interface RepairOrder {
  id: string; status: 'pending' | 'repairing' | 'completed' | 'withdrawn';
  applyTime: string; approveTime?: string; completeTime?: string; withdrawTime?: string;
  reporter: string; description: string; deadline: string;
  items: RepairItem[];
}

const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending: { label: '待审批', color: 'text-orange-600', bg: 'bg-orange-50', icon: Clock },
  repairing: { label: '维修中', color: 'text-purple-600', bg: 'bg-purple-50', icon: Wrench },
  completed: { label: '已办结', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  withdrawn: { label: '已撤回', color: 'text-gray-500', bg: 'bg-gray-100', icon: RotateCcw },
};

const mockOrders: Record<string, RepairOrder> = {
  WX20240520001: {
    id: 'WX20240520001', status: 'pending', applyTime: '2024-05-20 09:30',
    reporter: '张伟', description: '执法记录仪无法开机，疑似电池故障', deadline: '2024-05-25 18:00',
    items: [{ id: '1', name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, unit: '台', price: 1800, total: 1800, equipmentCode: 'EQ202401002', rfidCode: 'RFID202401002B', storageLocation: '省厅主仓库/主仓库2楼', supplier: '红星装备厂', isFixedAsset: true, remark: '4K高清', productionDate: '2024-01-10', expiryDate: '2027-01-10', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  WX20240519002: {
    id: 'WX20240519002', status: 'repairing', applyTime: '2024-05-19 14:00',
    approveTime: '2024-05-19 16:30',
    reporter: '王强', description: '战术手电开关接触不良，时亮时灭', deadline: '2024-05-24 18:00',
    items: [{ id: '2', name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 1, unit: '个', price: 280, total: 280, equipmentCode: 'EQ202202112', rfidCode: 'RFID202202112C', storageLocation: '01号装备室/东侧区域', supplier: '红星装备厂', isFixedAsset: false, remark: 'LED强光', productionDate: '2022-05-20', expiryDate: '2025-05-20', maintenanceValue: 1, maintenanceUnit: '年' }],
  },
  WX20240518003: {
    id: 'WX20240518003', status: 'completed', applyTime: '2024-05-18 10:20',
    approveTime: '2024-05-18 14:00', completeTime: '2024-05-22 16:30',
    reporter: '李明', description: '防刺手套掌心部位磨损严重', deadline: '2024-05-23 18:00',
    items: [{ id: '3', name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 1, unit: '双', price: 150, total: 150, equipmentCode: 'EQ202302145', rfidCode: 'RFID202302145A', storageLocation: '02号装备室/A区', supplier: '盾甲科技', isFixedAsset: false, remark: '', productionDate: '2023-05-10', expiryDate: '2026-05-10', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  WX20240517004: {
    id: 'WX20240517004', status: 'pending', applyTime: '2024-05-17 16:45',
    reporter: '赵刚', description: '防弹背心魔术贴脱落，影响穿戴', deadline: '2024-05-15 18:00',
    items: [{ id: '4', name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', rfidCode: 'RFID202301058F', storageLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', isFixedAsset: true, remark: 'III级防弹标准', productionDate: '2023-01-10', expiryDate: '2028-01-10', maintenanceValue: 3, maintenanceUnit: '年' }],
  },
  WX20240516005: {
    id: 'WX20240516005', status: 'withdrawn', applyTime: '2024-05-16 11:00',
    withdrawTime: '2024-05-16 13:30',
    reporter: '孙丽', description: '对讲机信号不稳定', deadline: '2024-05-21 18:00',
    items: [{ id: '5', name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 1, unit: '台', price: 650, total: 650, equipmentCode: 'EQ202401089', rfidCode: 'RFID202401089D', storageLocation: '03号装备室/一楼', supplier: '国安器材', isFixedAsset: true, remark: '800MHz频段', productionDate: '2024-01-25', expiryDate: '2026-01-25', maintenanceValue: 2, maintenanceUnit: '年' }],
  },
  WX20240515006: {
    id: 'WX20240515006', status: 'completed', applyTime: '2024-05-15 08:30',
    approveTime: '2024-05-15 10:00', completeTime: '2024-05-19 14:00',
    reporter: '周涛', description: '警棍表面氧化生锈', deadline: '2024-05-20 18:00',
    items: [{ id: '6', name: '警棍', category: '械具', model: 'JG-2019', quantity: 2, unit: '根', price: 120, total: 240, equipmentCode: 'EQ201908176', rfidCode: 'RFID201908176E', storageLocation: '02号装备室/B区', supplier: '红星装备厂', isFixedAsset: false, remark: '', productionDate: '2019-08-15', expiryDate: '2022-08-15', maintenanceValue: 3, maintenanceUnit: '年' }],
  },
};

export default function RepairDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<RepairOrder | null>(mockOrders[id || ''] || null);
  const [showWithdrawConfirm, setShowWithdrawConfirm] = useState(false);

  if (!order) {
    return (
      <MobileLayout title="报修详情" showBack onBack={() => navigate('/repair')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Wrench size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到报修工单</p>
        </div>
      </MobileLayout>
    );
  }

  const sc = statusConfig[order.status];
  const StatusIcon = sc.icon;
  const overdue = order.status !== 'completed' && order.status !== 'withdrawn' && new Date(order.deadline) < new Date();
  const item = order.items[0];

  const handleWithdraw = () => {
    setOrder({ ...order, status: 'withdrawn', withdrawTime: new Date().toLocaleString('zh-CN') });
    setShowWithdrawConfirm(false);
  };

  // Timeline nodes
  const timeline = [
    { label: '提交报修', time: order.applyTime, done: true },
    ...(order.status === 'withdrawn' ? [{ label: '已撤回', time: order.withdrawTime || '', done: true, isWithdraw: true as const }] : [
      { label: '待审批', time: order.applyTime, done: true },
      { label: '维修中', time: order.approveTime || '', done: !!order.approveTime },
      { label: '已办结', time: order.completeTime || '', done: !!order.completeTime },
    ]),
  ];

  return (
    <MobileLayout title="报修详情" showBack onBack={() => navigate('/repair')}>
      <div className="p-4">
        {/* Header */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-xl ${sc.bg} flex items-center justify-center`}>
              <StatusIcon size={24} className={sc.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900 font-mono">{order.id}</span>
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${sc.bg} ${sc.color}`}>{sc.label}</span>
                {overdue && <span className="px-1.5 py-0.5 bg-red-50 text-red-600 rounded text-[10px] font-medium">超期</span>}
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{item.name} · {item.model}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">申请时间</p>
              <p className="text-xs text-gray-800 font-medium">{order.applyTime}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">报修人</p>
              <p className="text-xs text-gray-800 font-medium">{order.reporter}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">要求完成</p>
              <p className={`text-xs font-medium ${overdue ? 'text-red-600' : 'text-gray-800'}`}>{order.deadline}</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-2.5">
              <p className="text-[10px] text-gray-500">装备编码</p>
              <p className="text-xs text-gray-800 font-medium font-mono">{item.equipmentCode}</p>
            </div>
          </div>

          {/* Withdraw button */}
          {order.status === 'pending' && (
            <button
              onClick={() => setShowWithdrawConfirm(true)}
              className="w-full mt-3 py-2.5 bg-gray-100 text-gray-600 rounded-xl text-sm font-medium active:bg-gray-200 transition-colors"
            >
              撤回工单
            </button>
          )}
        </div>

        {/* Description */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <FileText size={14} className="text-orange-600" /> 报修说明
          </h3>
          <div className="bg-orange-50 rounded-xl p-3">
            <p className="text-sm text-gray-800">{order.description}</p>
          </div>
        </div>

        {/* Material Detail */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Package size={14} className="text-blue-600" /> 物资明细
          </h3>
          <div className="space-y-2">
            {[
              { label: '物资名称', value: item.name },
              { label: '物资类别', value: item.category },
              { label: '规格型号', value: item.model },
              { label: '数量', value: `${item.quantity} ${item.unit}` },
              { label: '生产日期', value: item.productionDate },
              { label: '有效期', value: item.expiryDate },
              { label: '保养期', value: `${item.maintenanceValue}${item.maintenanceUnit}` },
              { label: '装备编码', value: item.equipmentCode },
              { label: 'RFID编码', value: item.rfidCode },
              { label: '存储位置', value: item.storageLocation },
              { label: '供应商', value: item.supplier },
              { label: '单价(¥)', value: `¥${item.price}` },
              { label: '总价(¥)', value: `¥${item.total}` },
              { label: '固定资产', value: item.isFixedAsset ? '是' : '否' },
              { label: '备注', value: item.remark || '—' },
            ].map((f, i) => (
              <div key={i} className="flex justify-between py-1 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{f.label}</span>
                <span className="text-xs text-gray-800 font-medium">{f.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Timeline */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Clock size={14} className="text-blue-600" /> 状态流转
          </h3>
          <div className="space-y-0">
            {timeline.map((node, i, arr) => (
              <div key={i} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                    node.done ? (node.isWithdraw ? 'bg-gray-400' : 'bg-green-500') : 'bg-gray-300'
                  }`}>
                    {node.done ? <CheckCircle2 size={14} className="text-white" /> : <CircleDot size={14} className="text-white" />}
                  </div>
                  {i < arr.length - 1 && <div className="w-0.5 h-6 bg-gray-200" />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm ${node.done ? 'text-gray-800 font-medium' : 'text-gray-400'}`}>{node.label}</p>
                  {node.time && <p className="text-[10px] text-gray-400">{node.time}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Withdraw Confirm Modal */}
      {showWithdrawConfirm && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowWithdrawConfirm(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative bg-white rounded-t-3xl w-full p-6" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
            <div className="flex items-center gap-2 mb-3">
              <RotateCcw size={20} className="text-gray-600" />
              <h3 className="text-lg font-semibold text-gray-900">撤回工单</h3>
            </div>
            <p className="text-sm text-gray-500 mb-6">
              确认撤回报修工单「{order.id}」？<br />
              撤回后该工单将变为「已撤回」状态，不可恢复。
            </p>
            <button onClick={handleWithdraw} className="w-full bg-gray-800 text-white py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-gray-900 transition-colors">
              确认撤回
            </button>
            <button onClick={() => setShowWithdrawConfirm(false)} className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-2xl font-medium text-base active:bg-gray-200">
              取消
            </button>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
