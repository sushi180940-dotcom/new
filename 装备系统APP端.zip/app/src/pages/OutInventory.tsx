import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  PackageOpen, ChevronRight, Plus, Trash2, CheckCircle2, Clock,
  ArrowRight, Minus, UserCheck, ArrowLeftRight, AlertTriangle,
  MoreHorizontal, QrCode, CircleDot, Wrench
} from 'lucide-react';

interface OutMaterialItem {
  id: string;
  name: string;
  category: string;
  model: string;
  quantity: number;
  stockQty: number;
  remainQty: number;
  unit: string;
  price: number;
  total: number;
  equipmentCode: string;
  rfidCode: string;
  fromLocation: string;
  supplier: string;
  isFixedAsset: boolean;
  remark: string;
  productionDate: string;
  expiryDate: string;
  maintenanceValue: number;
  maintenanceUnit: string;
}

interface OutRecord {
  id: string;
  type: string;
  status: 'pending' | 'completed' | 'draft';
  createTime: string;
  materials: number;
}

const outTypes = [
  {
    key: 'receive',
    label: '领用出库',
    desc: '民警领用装备出库',
    icon: UserCheck,
    color: '#1565c0',
    fields: [
      { key: 'receiver', label: '领用人', required: true },
      { key: 'receiverUnit', label: '领用单位', required: true },
      { key: 'receiveReason', label: '领用事由', required: true },
      { key: 'fromLocation', label: '出库仓库', required: true },
      { key: 'outTime', label: '出库时间', required: true },
      { key: 'expectedReturn', label: '预计归还', required: false },
    ]
  },
  {
    key: 'transfer',
    label: '调拨出库',
    desc: '仓库间调拨出库',
    icon: ArrowLeftRight,
    color: '#7c4dff',
    fields: [
      { key: 'transferNo', label: '调拨单号', required: true },
      { key: 'toUnit', label: '接收单位', required: true },
      { key: 'toLocation', label: '接收仓库', required: true },
      { key: 'fromLocation', label: '出库仓库', required: true },
      { key: 'outTime', label: '出库时间', required: true },
    ]
  },
  {
    key: 'scrap',
    label: '报废出库',
    desc: '超期报废出库',
    icon: AlertTriangle,
    color: '#e53935',
    fields: [
      { key: 'scrapReason', label: '报废原因', required: true },
      { key: 'scrapType', label: '报废类型', required: true },
      { key: 'approvalNo', label: '审批单号', required: true },
      { key: 'fromLocation', label: '出库仓库', required: true },
      { key: 'outTime', label: '出库时间', required: true },
    ]
  },
  {
    key: 'repair',
    label: '报修出库',
    desc: '装备维修送检出库',
    icon: Wrench,
    color: '#00acc1',
    fields: [
      { key: 'repairNo', label: '报修单号', required: true },
      { key: 'applicant', label: '申请人', required: true },
      { key: 'fromLocation', label: '出库仓库', required: true },
      { key: 'outTime', label: '出库时间', required: true },
    ]
  },
  {
    key: 'other',
    label: '其他出库',
    desc: '其他原因出库',
    icon: MoreHorizontal,
    color: '#43a047',
    fields: [
      { key: 'outReason', label: '出库原因', required: true },
      { key: 'fromLocation', label: '出库仓库', required: true },
      { key: 'outTime', label: '出库时间', required: true },
      { key: 'remark', label: '备注', required: false },
    ]
  },
];

const mockHistory: OutRecord[] = [
  { id: 'CK20240520001', type: 'receive', status: 'completed', createTime: '2024-05-20 09:15', materials: 3 },
  { id: 'CK20240520002', type: 'other', status: 'draft', createTime: '2024-05-20 08:00', materials: 1 },
  { id: 'CK20240519003', type: 'transfer', status: 'completed', createTime: '2024-05-19 14:30', materials: 5 },
  { id: 'CK20240518004', type: 'repair', status: 'pending', createTime: '2024-05-18 10:00', materials: 1 },
  { id: 'CK20240517005', type: 'scrap', status: 'completed', createTime: '2024-05-17 16:20', materials: 1 },
  { id: 'CK20240516006', type: 'receive', status: 'completed', createTime: '2024-05-16 11:45', materials: 4 },
  { id: 'CK20240515007', type: 'transfer', status: 'pending', createTime: '2024-05-15 08:30', materials: 6 },
];

const typeLabelMap: Record<string, string> = {
  receive: '领用出库', transfer: '调拨出库', scrap: '报废出库', repair: '报修出库', other: '其他出库',
};
const typeColorMap: Record<string, string> = {
  receive: '#1565c0', transfer: '#7c4dff', scrap: '#e53935', repair: '#00acc1', other: '#43a047',
};

function generateOrderNo(): string {
  const d = new Date();
  const prefix = 'CK';
  const dateStr = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`;
  const random = String(Math.floor(Math.random() * 900) + 100).padStart(3, '0');
  return `${prefix}${dateStr}${random}`;
}

export default function OutInventory() {
  const navigate = useNavigate();
  const [step, setStep] = useState<'list' | 'type-select' | 'basic-info' | 'materials' | 'review' | 'success'>('list');
  const [selectedType, setSelectedType] = useState('');
  const [orderNo, setOrderNo] = useState('');
  const [basicInfo, setBasicInfo] = useState<Record<string, string>>({});
  const [materials, setMaterials] = useState<OutMaterialItem[]>([]);
  const [scanResult, setScanResult] = useState<string | null>(null);

  const selectedTypeConfig = outTypes.find(t => t.key === selectedType);

  const handleTypeSelect = (typeKey: string) => {
    setSelectedType(typeKey);
    setOrderNo(generateOrderNo());
    setStep('basic-info');
    setBasicInfo({ outTime: new Date().toLocaleString('zh-CN') });
  };

  const handleScanRFID = useCallback(() => {
    const mockStockDB: Record<string, { name: string; category: string; model: string; stockQty: number; unit: string; price: number; equipmentCode: string; fromLocation: string; supplier: string; productionDate: string; expiryDate: string }> = {
      'RFID202301058B': { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', stockQty: 15, unit: '件', price: 1200, equipmentCode: 'EQ202301058', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', productionDate: '2023-01-15', expiryDate: '2028-01-15' },
      'RFID202401001A': { name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', stockQty: 12, unit: '台', price: 1800, equipmentCode: 'EQ202401001', fromLocation: '省厅主仓库/主仓库2楼', supplier: '红星装备厂', productionDate: '2024-01-15', expiryDate: '2027-01-15' },
      'RFID202202112C': { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', stockQty: 20, unit: '个', price: 280, equipmentCode: 'EQ202202112', fromLocation: '省厅主仓库/主仓库1楼', supplier: '红星装备厂', productionDate: '2022-06-10', expiryDate: '2025-06-10' },
    };
    const keys = Object.keys(mockStockDB);
    const randomKey = keys[Math.floor(Math.random() * keys.length)];
    const info = mockStockDB[randomKey];

    setMaterials(prev => {
      const existing = prev.find(m => m.name === info.name);
      if (existing) {
        return prev.map(m => m.name === info.name
          ? { ...m, quantity: m.quantity + 1, remainQty: info.stockQty - (m.quantity + 1), rfidCode: `${m.rfidCode}, ${randomKey}`, total: (m.quantity + 1) * m.price }
          : m
        );
      }
      return [...prev, {
        id: Date.now().toString(), name: info.name, category: info.category, model: info.model,
        quantity: 1, stockQty: info.stockQty, remainQty: info.stockQty - 1,
        unit: info.unit, price: info.price, total: info.price,
        equipmentCode: info.equipmentCode, rfidCode: randomKey,
        fromLocation: info.fromLocation, supplier: info.supplier,
        isFixedAsset: false, remark: '',
        productionDate: info.productionDate, expiryDate: info.expiryDate,
        maintenanceValue: 3, maintenanceUnit: '年',
      }];
    });
    setScanResult(`已扫描：${randomKey} · ${info.name} · 库存${info.stockQty}件`);
    setTimeout(() => setScanResult(null), 3000);
  }, []);

  const updateMaterial = (id: string, field: keyof OutMaterialItem, value: unknown) => {
    setMaterials(prev => prev.map(m => {
      if (m.id !== id) return m;
      const updated = { ...m, [field]: value };
      if (field === 'quantity') {
        updated.remainQty = updated.stockQty - Number(value);
        updated.total = Number(value) * updated.price;
      }
      return updated;
    }));
  };

  const removeMaterial = (id: string) => setMaterials(prev => prev.filter(m => m.id !== id));

  const totalQty = materials.reduce((s, m) => s + m.quantity, 0);

  // ─── LIST ───
  if (step === 'list') {
    return (
      <MobileLayout title="出库管理" showBack rightAction={
        <button onClick={() => setStep('type-select')} className="text-white text-sm font-medium px-3 py-1.5 bg-white/20 rounded-lg active:bg-white/30 transition-colors">
          新建出库
        </button>
      }>
        <div className="px-4 pt-3 pb-2 flex gap-2">
          {[
            { label: '出库记录', value: mockHistory.length, color: 'text-[#1565c0]' },
            { label: '已出库', value: mockHistory.filter(r => r.status === 'completed').length, color: 'text-green-600' },
            { label: '草稿', value: mockHistory.filter(r => r.status === 'draft').length, color: 'text-orange-600' },
          ].map(s => (
            <div key={s.label} className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>

        <div className="px-4 pb-4 space-y-2 mt-2">
          {mockHistory.map(record => (
            <button key={record.id} onClick={() => navigate(`/out/${record.id}`)} className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-800 font-mono">{record.id}</span>
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white" style={{ backgroundColor: typeColorMap[record.type] }}>{typeLabelMap[record.type]}</span>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${record.status === 'completed' ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-600'}`}>{record.status === 'completed' ? '已出库' : '待出库'}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-gray-500">
                <span className="flex items-center gap-1"><Clock size={10} /> {record.createTime}</span>
                <span>共 {record.materials} 件物资</span>
              </div>
            </button>
          ))}
        </div>

        <button onClick={() => setStep('type-select')} className="fixed right-4 bottom-20 w-12 h-12 bg-[#1565c0] text-white rounded-full shadow-lg flex items-center justify-center z-50 active:bg-blue-700 transition-colors"><Plus size={24} /></button>
      </MobileLayout>
    );
  }

  // ─── TYPE SELECT ───
  if (step === 'type-select') {
    return (
      <MobileLayout title="选择出库类型" showBack onBack={() => setStep('list')}>
        <div className="p-4 space-y-3">
          {outTypes.map(t => {
            const Icon = t.icon;
            return (
              <button key={t.key} onClick={() => handleTypeSelect(t.key)} className="w-full bg-white rounded-2xl p-4 shadow-sm text-left active:scale-[0.99] transition-all flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${t.color}15` }}>
                  <Icon size={24} style={{ color: t.color }} />
                </div>
                <div className="flex-1">
                  <p className="text-base font-semibold text-gray-800">{t.label}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{t.desc}</p>
                </div>
                <ChevronRight size={20} className="text-gray-400" />
              </button>
            );
          })}
        </div>
      </MobileLayout>
    );
  }

  // ─── BASIC INFO ───
  if (step === 'basic-info') {
    return (
      <MobileLayout title="基本信息" showBack onBack={() => setStep('type-select')}>
        <div className="p-4">
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-3 mb-3 flex items-center justify-between">
            <div>
              <p className="text-[10px] text-blue-600">出库单号</p>
              <p className="text-sm font-semibold text-blue-800 font-mono">{orderNo}</p>
            </div>
            <CircleDot size={18} className="text-blue-500" />
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm space-y-3">
            {selectedTypeConfig?.fields.map(field => (
              <div key={field.key}>
                <label className="text-xs text-gray-500 mb-1 block">{field.label}{field.required && <span className="text-red-500 ml-0.5">*</span>}</label>
                {field.key === 'scrapType' ? (
                  <div className="flex flex-wrap gap-2">
                    {['超期报废', '损坏报废', '技术淘汰', '其他'].map(opt => (
                      <button key={opt} onClick={() => setBasicInfo(p => ({ ...p, [field.key]: opt }))} className={`px-3 py-2 rounded-xl text-xs transition-all ${basicInfo[field.key] === opt ? 'bg-red-50 text-red-600 border border-red-200' : 'bg-gray-50 text-gray-600 border border-transparent'}`}>{opt}</button>
                    ))}
                  </div>
                ) : (
                  <input type={field.key.includes('Time') || field.key.includes('Date') ? 'datetime-local' : 'text'} value={basicInfo[field.key] || ''} onChange={e => setBasicInfo(p => ({ ...p, [field.key]: e.target.value }))} placeholder={`请输入${field.label}`} className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all" />
                )}
              </div>
            ))}
          </div>

          <button onClick={() => setStep('materials')} className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium mt-4 active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20 flex items-center justify-center gap-2">
            下一步：物资明细 <ArrowRight size={16} />
          </button>
        </div>
      </MobileLayout>
    );
  }

  // ─── MATERIALS ───
  if (step === 'materials') {
    const hasOverStock = materials.some(m => m.quantity > m.stockQty);
    return (
      <MobileLayout title="物资明细" showBack onBack={() => setStep('basic-info')}>
        <div className="p-4">
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center">
                <QrCode size={20} className="text-blue-600" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-800">扫描RFID编码</p>
                <p className="text-xs text-gray-500">扫描装备RFID标签，自动显示库存数量</p>
              </div>
              <button onClick={handleScanRFID} className="px-4 py-2 bg-[#1565c0] text-white rounded-xl text-sm font-medium active:bg-blue-700 transition-colors">扫描</button>
            </div>
            {scanResult && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-2.5 flex items-center gap-2">
                <CheckCircle2 size={14} className="text-green-600" />
                <span className="text-xs text-green-700">{scanResult}</span>
              </div>
            )}
          </div>

          {hasOverStock && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-3 mb-3 flex items-center gap-2">
              <AlertTriangle size={16} className="text-red-600 shrink-0" />
              <span className="text-xs text-red-700">出库数量超过库存，请减少数量</span>
            </div>
          )}

          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-semibold text-gray-800">物资清单 ({materials.length})</h3>
          </div>

          <div className="space-y-3 pb-4">
            {materials.length === 0 && (
              <div className="bg-white rounded-2xl p-8 shadow-sm text-center text-gray-400">
                <PackageOpen size={32} className="mx-auto mb-2" />
                <p className="text-sm">请扫描RFID添加物资</p>
              </div>
            )}
            {materials.map((m, idx) => (
              <div key={m.id} className="bg-white rounded-2xl p-4 shadow-sm">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs text-gray-400">物资 #{idx + 1}</span>
                  <button onClick={() => removeMaterial(m.id)} className="text-red-400 active:text-red-600 p-1"><Trash2 size={14} /></button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] text-gray-500">物资名称<span className="text-red-500">*</span></label>
                    <input type="text" value={m.name} onChange={e => updateMaterial(m.id, 'name', e.target.value)} placeholder="名称" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">在库数量</label>
                    <input type="number" value={m.stockQty} readOnly className="w-full bg-gray-100 rounded-lg px-3 py-2 text-xs text-gray-600 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">出库数量<span className="text-red-500">*</span></label>
                    <div className="flex items-center bg-gray-50 rounded-lg">
                      <button onClick={() => updateMaterial(m.id, 'quantity', Math.max(1, m.quantity - 1))} className="px-2 py-2 active:bg-gray-200 rounded-l-lg"><Minus size={12} /></button>
                      <input type="number" value={m.quantity} onChange={e => updateMaterial(m.id, 'quantity', Number(e.target.value))} className={`w-full text-center text-xs bg-transparent outline-none py-2 ${m.quantity > m.stockQty ? 'text-red-600 font-bold' : ''}`} />
                      <button onClick={() => updateMaterial(m.id, 'quantity', m.quantity + 1)} className="px-2 py-2 active:bg-gray-200 rounded-r-lg"><Plus size={12} /></button>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">剩余数量</label>
                    <input type="number" value={m.remainQty} readOnly className={`w-full rounded-lg px-3 py-2 text-xs outline-none ${m.remainQty < 0 ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-600'}`} />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">装备编码</label>
                    <input type="text" value={m.equipmentCode} onChange={e => updateMaterial(m.id, 'equipmentCode', e.target.value)} placeholder="编码" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">RFID编码</label>
                    <input type="text" value={m.rfidCode} onChange={e => updateMaterial(m.id, 'rfidCode', e.target.value)} placeholder="RFID" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">存储位置</label>
                    <input type="text" value={m.fromLocation} onChange={e => updateMaterial(m.id, 'fromLocation', e.target.value)} placeholder="仓库" className="w-full bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-500">保养期</label>
                    <div className="flex gap-1.5">
                      <input type="number" value={m.maintenanceValue} onChange={e => updateMaterial(m.id, 'maintenanceValue', Number(e.target.value))} className="flex-1 bg-gray-50 rounded-lg px-3 py-2 text-xs text-gray-800 outline-none" min={1} />
                      <select value={m.maintenanceUnit} onChange={e => updateMaterial(m.id, 'maintenanceUnit', e.target.value)} className="w-16 bg-gray-50 rounded-lg px-2 py-2 text-xs text-gray-800 outline-none">
                        <option value="日">日</option>
                        <option value="月">月</option>
                        <option value="年">年</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <button onClick={() => setStep('review')} disabled={!materials.length || hasOverStock} className={`w-full py-3.5 rounded-xl font-medium transition-colors mb-6 ${materials.length && !hasOverStock ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20' : 'bg-gray-200 text-gray-400'}`}>
            {hasOverStock ? '数量超过库存，请修改' : '提交出库申请'}
          </button>
        </div>
      </MobileLayout>
    );
  }

  // ─── REVIEW ───
  if (step === 'review') {
    return (
      <MobileLayout title="确认出库" showBack onBack={() => setStep('materials')}>
        <div className="p-4">
          <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-3 flex items-center gap-3">
            <Clock size={20} className="text-orange-600" />
            <div>
              <p className="text-sm font-semibold text-orange-800">待出库状态</p>
              <p className="text-xs text-orange-600">请核对信息无误后确认出库</p>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">出库单信息</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-xs text-gray-500">出库单号</span><span className="text-xs text-gray-800 font-mono">{orderNo}</span></div>
              <div className="flex justify-between"><span className="text-xs text-gray-500">出库类型</span><span className="text-xs text-gray-800">{selectedTypeConfig?.label}</span></div>
              {Object.entries(basicInfo).filter(([, v]) => v).map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-xs text-gray-500">{selectedTypeConfig?.fields.find(f => f.key === k)?.label || k}</span>
                  <span className="text-xs text-gray-800">{v}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">物资汇总</h3>
            {materials.map((m) => (
              <div key={m.id} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-700">{m.name} <span className="text-xs text-gray-400">(库存{m.stockQty})</span></span>
                <span className="text-sm text-gray-900">x{m.quantity} {m.unit}</span>
              </div>
            ))}
            <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between">
              <span className="text-sm text-gray-600">共 {materials.length} 种，{totalQty} 件</span>
            </div>
          </div>

          <div className="bg-gray-50 rounded-2xl p-4 mb-4">
            <h3 className="text-xs font-semibold text-gray-600 mb-2">业务规则</h3>
            <ul className="space-y-1">
              <li className="text-[10px] text-gray-500">1. 出库记录将永久留存，不可删除</li>
              <li className="text-[10px] text-gray-500">2. 确认出库后将同步扣减库存数据</li>
              <li className="text-[10px] text-gray-500">3. 仅在库状态装备可执行出库操作</li>
            </ul>
          </div>

          <div className="flex gap-3 mb-6">
            <button onClick={() => setStep('materials')} className="flex-1 bg-gray-100 text-gray-700 py-3.5 rounded-xl font-medium active:bg-gray-200 transition-colors">返回修改</button>
            <button onClick={() => setStep('success')} className="flex-1 bg-[#1565c0] text-white py-3.5 rounded-xl font-medium active:bg-blue-700 transition-colors shadow-md shadow-blue-900/20">确认出库</button>
          </div>
        </div>
      </MobileLayout>
    );
  }

  // ─── SUCCESS ───
  return (
    <MobileLayout title="出库完成" showBack onBack={() => { setStep('list'); setMaterials([]); setBasicInfo({}); }}>
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
        <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
          <CheckCircle2 size={40} className="text-green-600" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">出库成功</h3>
        <p className="text-sm text-gray-500 text-center mb-6">共出库 {totalQty} 件装备，库存已扣减</p>
        <button onClick={() => { setStep('list'); setMaterials([]); setBasicInfo({}); }} className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors">返回出库列表</button>
      </div>
    </MobileLayout>
  );
}
