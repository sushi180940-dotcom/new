import { useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  RotateCcw, User, AlertTriangle,
  CheckCircle2, Copy, Shield, FileText, KeyRound
} from 'lucide-react';

/* ─── types ─── */
interface UserRecord {
  id: string;
  account: string;
  name: string;
  unit: string;
  role: string;
  status: string;
}

/* ─── mock data ─── */
const mockUsers: Record<string, UserRecord> = {
  U001: { id: 'U001', account: 'admin001', name: '张建国', unit: '省厅装备处', role: 'senior_admin', status: 'enabled' },
  U002: { id: 'U002', account: 'admin002', name: '李秀芬', unit: '朝阳分局', role: 'admin', status: 'enabled' },
  U003: { id: 'U003', account: 'u01001', name: '王强', unit: '朝阳分局刑侦大队', role: 'user', status: 'enabled' },
  U004: { id: 'U004', account: 'u01002', name: '李明', unit: '东城分局巡警支队', role: 'user', status: 'disabled' },
  U005: { id: 'U005', account: 'u01003', name: '赵刚', unit: '西城分局特警大队', role: 'user', status: 'enabled' },
  U006: { id: 'U006', account: 'u01004', name: '孙丽', unit: '海淀分局治安大队', role: 'user', status: 'enabled' },
  U007: { id: 'U007', account: 'u01005', name: '周涛', unit: '丰台分局交警大队', role: 'user', status: 'enabled' },
  U008: { id: 'U008', account: 'u01006', name: '张伟', unit: '昌平分局刑警大队', role: 'user', status: 'enabled' },
  U009: { id: 'U009', account: 'u01007', name: '刘洋', unit: '通州分局派出所', role: 'user', status: 'enabled' },
  U010: { id: 'U010', account: 'u01008', name: '陈静', unit: '大兴分局治安大队', role: 'user', status: 'abnormal' },
};

/* ─── reset reasons ─── */
const resetReasons = [
  {
    key: 'forgot',
    label: '遗忘密码',
    desc: '用户忘记登录密码，无法正常登录系统',
    icon: KeyRound,
    color: '#1565c0',
  },
  {
    key: 'abnormal',
    label: '账号异常',
    desc: '发现异常登录行为或账号存在安全风险',
    icon: AlertTriangle,
    color: '#e53935',
  },
  {
    key: 'other',
    label: '其他原因',
    desc: '其他特殊场景需要重置密码',
    icon: FileText,
    color: '#7c4dff',
  },
];

/* ─── password generator ─── */
function generatePassword(): string {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let pwd = '';
  for (let i = 0; i < 8; i++) {
    pwd += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return pwd;
}

/* ─── main component ─── */
export default function UserReset() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = mockUsers[id || ''];

  const [selectedReason, setSelectedReason] = useState('');
  const [remark, setRemark] = useState('');
  const [step, setStep] = useState<'form' | 'confirm' | 'result'>('form');
  const [newPassword, setNewPassword] = useState('');
  const [copied, setCopied] = useState(false);

  const selectedReasonData = resetReasons.find(r => r.key === selectedReason);

  const handleSubmit = useCallback(() => {
    if (!selectedReason) return;
    setStep('confirm');
  }, [selectedReason]);

  const handleConfirm = useCallback(() => {
    const pwd = generatePassword();
    setNewPassword(pwd);
    setStep('result');
  }, []);

  const handleCopy = useCallback(() => {
    navigator.clipboard?.writeText(newPassword).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [newPassword]);

  /* ── Not Found ── */
  if (!user) {
    return (
      <MobileLayout title="密码重置" showBack onBack={() => navigate('/users')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <User size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到用户信息</p>
        </div>
      </MobileLayout>
    );
  }

  /* ── Result Step ── */
  if (step === 'result') {
    return (
      <MobileLayout title="重置成功" showBack onBack={() => navigate(`/users/${user.id}`)}>
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-5">
          <div className="w-20 h-20 bg-green-50 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 size={40} className="text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-1">密码重置成功</h3>
          <p className="text-sm text-gray-500 mb-6">新初始密码已生成，请妥善告知用户</p>

          {/* New Password Card */}
          <div className="w-full bg-white rounded-2xl p-5 shadow-sm mb-4">
            <div className="text-center mb-4">
              <p className="text-xs text-gray-500 mb-1">新初始密码</p>
              <div className="flex items-center justify-center gap-3">
                <span className="text-2xl font-bold text-[#1565c0] font-mono tracking-wider">{newPassword}</span>
                <button
                  onClick={handleCopy}
                  className="p-2 rounded-lg bg-blue-50 active:bg-blue-100 transition-colors"
                >
                  {copied ? (
                    <CheckCircle2 size={16} className="text-green-600" />
                  ) : (
                    <Copy size={16} className="text-[#1565c0]" />
                  )}
                </button>
              </div>
              {copied && <p className="text-[10px] text-green-600 mt-1">已复制到剪贴板</p>}
            </div>

            <div className="bg-gray-50 rounded-xl p-3 text-xs text-gray-600 space-y-1.5">
              <div className="flex justify-between">
                <span className="text-gray-500">重置对象</span>
                <span className="font-medium">{user.name}（{user.account}）</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">重置原因</span>
                <span className="font-medium">{selectedReasonData?.label}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">操作人</span>
                <span className="font-medium">张建国（高级管理员）</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">操作时间</span>
                <span className="font-medium">{new Date().toLocaleString('zh-CN')}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">重置记录</span>
                <span className="font-medium text-green-600">已留痕</span>
              </div>
            </div>
          </div>

          <p className="text-xs text-gray-400 text-center mb-4">
            提示：请尽快将新密码告知用户，用户首次登录后需自行修改密码
          </p>

          <button
            onClick={() => navigate(`/users/${user.id}`)}
            className="w-full bg-[#1565c0] text-white py-3 rounded-xl font-medium active:bg-blue-700 transition-colors flex items-center justify-center gap-2"
          >
            <CheckCircle2 size={16} />
            完成
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── Confirm Step ── */
  if (step === 'confirm') {
    return (
      <MobileLayout title="确认重置" showBack onBack={() => setStep('form')}>
        <div className="p-4">
          {/* Warning */}
          <div className="bg-red-50 rounded-2xl p-4 mb-4 flex items-start gap-3">
            <AlertTriangle size={20} className="text-red-600 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-700 mb-1">请确认重置操作</p>
              <p className="text-xs text-red-600 leading-relaxed">
                密码重置将生成新的初始密码，原密码将失效。此操作不可逆，请确认确实需要重置。
              </p>
            </div>
          </div>

          {/* User Info */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">重置对象</h3>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center">
                <span className="text-lg font-bold text-blue-600">{user.name[0]}</span>
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-gray-800">{user.name}</p>
                <p className="text-xs text-gray-500">{user.account} · {user.unit}</p>
              </div>
            </div>
          </div>

          {/* Reason Confirm */}
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">重置原因</h3>
            <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl">
              {selectedReasonData && (
                <>
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${selectedReasonData.color}15` }}>
                    <selectedReasonData.icon size={18} style={{ color: selectedReasonData.color }} />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-800">{selectedReasonData.label}</p>
                    <p className="text-xs text-gray-500">{selectedReasonData.desc}</p>
                  </div>
                </>
              )}
            </div>
            {remark.trim() && (
              <div className="mt-2 p-3 bg-gray-50 rounded-xl">
                <p className="text-[10px] text-gray-500 mb-1">补充说明</p>
                <p className="text-xs text-gray-700">{remark}</p>
              </div>
            )}
          </div>

          {/* Log Notice */}
          <div className="bg-blue-50 rounded-xl p-3 mb-4 flex items-center gap-2">
            <Shield size={14} className="text-blue-600 shrink-0" />
            <p className="text-xs text-blue-700">
              重置操作将自动留痕，记录操作人、时间、原因等信息
            </p>
          </div>

          {/* Actions */}
          <button
            onClick={handleConfirm}
            className="w-full bg-[#1565c0] text-white py-3.5 rounded-xl font-medium mb-3 active:bg-blue-700 transition-colors flex items-center justify-center gap-2 shadow-md shadow-blue-900/20"
          >
            <RotateCcw size={16} />
            确认重置
          </button>
          <button
            onClick={() => setStep('form')}
            className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-xl font-medium active:bg-gray-200 transition-colors"
          >
            返回修改
          </button>
        </div>
      </MobileLayout>
    );
  }

  /* ── Form Step (default) ── */
  return (
    <MobileLayout title="密码重置" showBack onBack={() => navigate(`/users/${user.id}`)}>
      <div className="p-4">
        {/* User Info */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">重置对象</h3>
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${
              user.status === 'abnormal' ? 'bg-red-50' : 'bg-blue-50'
            }`}>
              <span className={`text-lg font-bold ${
                user.status === 'abnormal' ? 'text-red-600' : 'text-blue-600'
              }`}>
                {user.name[0]}
              </span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-gray-800">{user.name}</p>
              <p className="text-xs text-gray-500">{user.account} · {user.unit}</p>
            </div>
          </div>
        </div>

        {/* Reason Selection */}
        <div className="mb-4">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <AlertTriangle size={14} className="text-[#1565c0]" /> 选择重置原因 <span className="text-red-400">*</span>
          </h3>
          <div className="space-y-2">
            {resetReasons.map(reason => {
              const ReasonIcon = reason.icon;
              const isSelected = selectedReason === reason.key;
              return (
                <button
                  key={reason.key}
                  onClick={() => setSelectedReason(reason.key)}
                  className={`w-full rounded-2xl p-4 text-left border-2 transition-all ${
                    isSelected
                      ? 'border-[#1565c0] bg-blue-50'
                      : 'border-transparent bg-white shadow-sm'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${reason.color}${isSelected ? '20' : '10'}` }}>
                      <ReasonIcon size={18} style={{ color: reason.color }} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className={`text-sm font-medium ${isSelected ? 'text-[#1565c0]' : 'text-gray-800'}`}>
                          {reason.label}
                        </span>
                        {isSelected && (
                          <CheckCircle2 size={14} className="text-[#1565c0]" />
                        )}
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">{reason.desc}</p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Remark (show when "other" selected) */}
        {selectedReason === 'other' && (
          <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
            <label className="text-xs text-gray-500 mb-2 block">
              补充说明 <span className="text-red-400">*</span>
            </label>
            <textarea
              value={remark}
              onChange={e => setRemark(e.target.value)}
              placeholder="请详细说明重置原因..."
              rows={3}
              className="w-full bg-gray-50 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-transparent focus:border-blue-300 transition-all resize-none"
            />
          </div>
        )}

        {/* Rules */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-4">
          <h3 className="text-sm font-semibold text-gray-800 mb-3">操作规范</h3>
          <div className="space-y-2">
            {[
              '仅高级管理员可执行密码重置操作',
              '仅可操作本管辖范围内的用户',
              '重置操作全程留痕，记录操作人、时间、原因',
              '禁止随意重置正常账号，仅限遗忘密码、账号异常场景',
              '重置后需告知用户新密码，用户登录后需自行修改',
            ].map((rule, i) => (
              <div key={i} className="flex items-start gap-2">
                <span className="text-[10px] text-gray-400 font-mono shrink-0 mt-0.5">{String(i + 1).padStart(2, '0')}</span>
                <p className="text-xs text-gray-600 leading-relaxed">{rule}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Submit */}
        <button
          onClick={handleSubmit}
          disabled={!selectedReason || (selectedReason === 'other' && !remark.trim())}
          className={`w-full py-3.5 rounded-xl font-medium mb-6 transition-all flex items-center justify-center gap-2 ${
            selectedReason && (selectedReason !== 'other' || remark.trim())
              ? 'bg-[#1565c0] text-white active:bg-blue-700 shadow-md shadow-blue-900/20'
              : 'bg-gray-200 text-gray-400'
          }`}
        >
          <RotateCcw size={16} />
          下一步：确认重置
        </button>
      </div>
    </MobileLayout>
  );
}
