import { useState } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { currentUser, personalEquipment } from '@/data/mock';
import { Shield, ChevronRight, Settings, Lock, Package, HelpCircle } from 'lucide-react';

export default function Profile() {
  const navigate = useNavigate();
  const [showLogout, setShowLogout] = useState(false);
  const permanentEq = personalEquipment.filter(e => e.type === 'permanent');
  const tempEq = personalEquipment.filter(e => e.type === 'temporary');

  return (
    <MobileLayout showNav={true}>
      {/* Header Gradient */}
      <div className="relative" style={{ background: 'linear-gradient(180deg, #0d2b5e 0%, #1565c0 100%)' }}>
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-b from-transparent to-[#f0f4f8]" />
        <div className="pt-6 pb-12 px-5 text-center">
          <div className="w-18 h-18 rounded-full bg-white/20 flex items-center justify-center mx-auto border-3 border-white/40 mb-3">
            <Shield size={32} className="text-white" />
          </div>
          <h2 className="text-lg font-semibold text-white">{currentUser.name}</h2>
          <p className="text-white/70 text-xs mt-1">{currentUser.badge} · {currentUser.unit}</p>
          <div className="flex justify-center gap-6 mt-4">
            <div className="text-center">
              <p className="text-white text-lg font-bold">{personalEquipment.length}</p>
              <p className="text-white/60 text-xs">持有装备</p>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div className="text-center">
              <p className="text-white text-lg font-bold">{permanentEq.length}</p>
              <p className="text-white/60 text-xs">常态配备</p>
            </div>
            <div className="h-8 w-px bg-white/20" />
            <div className="text-center">
              <p className="text-white text-lg font-bold">{tempEq.length}</p>
              <p className="text-white/60 text-xs">临时领用</p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-4 -mt-4 relative z-10 pb-6">
        {/* Personal Equipment */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-3">
          <button
            onClick={() => navigate('/profile/equipment')}
            className="w-full flex items-center justify-between p-4 text-left active:bg-gray-50"
          >
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center">
                <Package size={18} className="text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-800">个人装备</p>
                <p className="text-xs text-gray-500">常态配备{permanentEq.length}件 · 临时领用{tempEq.length}件</p>
              </div>
            </div>
            <ChevronRight size={18} className="text-gray-400" />
          </button>
        </div>

        {/* Account Settings */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-3">
          <div className="p-4 pb-2">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wide">基础信息</h3>
          </div>
          {[
            { icon: Settings, label: '账号信息', desc: currentUser.phone },
            { icon: Lock, label: '修改密码', desc: '' },
          ].map((item, i, arr) => (
            <button
              key={item.label}
              className={`w-full flex items-center justify-between p-4 text-left active:bg-gray-50 ${i < arr.length - 1 ? 'border-b border-gray-50' : ''}`}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-gray-50 flex items-center justify-center">
                  <item.icon size={18} className="text-gray-600" />
                </div>
                <span className="text-sm text-gray-800">{item.label}</span>
              </div>
              <div className="flex items-center gap-1">
                {item.desc && <span className="text-xs text-gray-400">{item.desc}</span>}
                <ChevronRight size={18} className="text-gray-400" />
              </div>
            </button>
          ))}
        </div>

        {/* Help & Support */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden mb-3">
          <button className="w-full flex items-center justify-between p-4 text-left active:bg-gray-50">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gray-50 flex items-center justify-center">
                <HelpCircle size={18} className="text-gray-600" />
              </div>
              <span className="text-sm text-gray-800">帮助与反馈</span>
            </div>
            <ChevronRight size={18} className="text-gray-400" />
          </button>
        </div>

        {/* Logout */}
        <button
          onClick={() => setShowLogout(true)}
          className="w-full mt-3 bg-white rounded-2xl shadow-sm py-3.5 text-sm text-red-500 font-medium active:bg-red-50 transition-colors"
        >
          安全退出
        </button>
      </div>

      {/* Logout Confirm Modal */}
      {showLogout && (
        <div className="fixed inset-0 z-[60] flex items-end justify-center" onClick={() => setShowLogout(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="relative bg-white rounded-t-3xl w-full p-6 animate-in slide-in-from-bottom" onClick={e => e.stopPropagation()}>
            <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4" />
            <p className="text-lg font-semibold text-gray-900 text-center mb-2">确认退出登录？</p>
            <p className="text-sm text-gray-500 text-center mb-6">退出后将无法接收审批通知和预警信息</p>
            <button className="w-full bg-red-500 text-white py-3.5 rounded-2xl font-medium text-base mb-3 active:bg-red-600">确认退出</button>
            <button onClick={() => setShowLogout(false)} className="w-full bg-gray-100 text-gray-700 py-3.5 rounded-2xl font-medium text-base active:bg-gray-200">取消</button>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
