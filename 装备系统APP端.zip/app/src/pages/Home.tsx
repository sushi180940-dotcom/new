import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { currentUser, homeFeatures, messageList, warningList } from '@/data/mock';
import {
  Archive, PackageOpen, Search, Wrench, ClipboardCheck, GitBranch,
  FilePlus, Users, BarChart3, UserCog, Bell, Shield, CalendarDays, MessageSquare
} from 'lucide-react';

const iconMap: Record<string, React.ElementType> = {
  Archive, PackageOpen, Search, Wrench, ClipboardCheck, GitBranch,
  FilePlus, Users, BarChart3, UserCog, Bell, MessageSquare
};

export default function Home() {
  const navigate = useNavigate();
  const today = new Date();
  const dateStr = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;
  const weekStr = ['日', '一', '二', '三', '四', '五', '六'][today.getDay()];
  const unreadMessages = messageList.filter(m => !m.read).length;
  const warningCount = warningList.length;

  return (
    <MobileLayout showNav={true}>
      {/* Header Gradient Area */}
      <div className="relative" style={{ background: 'linear-gradient(180deg, #0d2b5e 0%, #1565c0 60%, #1976d2 100%)' }}>
        {/* Top gradient overlay for transition */}
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-gradient-to-b from-transparent to-[#f0f4f8]" />

        <div className="pt-4 pb-10 px-5">
          {/* User Info Row */}
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-full bg-white/20 flex items-center justify-center border-2 border-white/40">
                <Shield size={20} className="text-white" />
              </div>
              <div>
                <p className="text-white text-base font-semibold">{currentUser.name}</p>
                <p className="text-white/70 text-xs">{currentUser.unit}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-white/60 text-xs flex items-center gap-1">
                <CalendarDays size={12} />
                {dateStr} 星期{weekStr}
              </p>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="flex gap-3 mb-2">
            <div className="flex-1 bg-white/15 backdrop-blur-sm rounded-2xl px-3 py-2.5 border border-white/20">
              <p className="text-white/60 text-xs">待审批</p>
              <p className="text-white text-xl font-bold">5</p>
            </div>
            <div className="flex-1 bg-white/15 backdrop-blur-sm rounded-2xl px-3 py-2.5 border border-white/20">
              <p className="text-white/60 text-xs">待维修</p>
              <p className="text-white text-xl font-bold">3</p>
            </div>
            <div className="flex-1 bg-white/15 backdrop-blur-sm rounded-2xl px-3 py-2.5 border border-white/20">
              <p className="text-white/60 text-xs">预警</p>
              <p className="text-white text-xl font-bold">6</p>
            </div>
          </div>
        </div>
      </div>

      {/* Feature Grid */}
      <div className="px-4 -mt-2 relative z-10 pb-4">
        <div className="bg-white rounded-2xl shadow-sm p-4">
          <h2 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-1.5">
            <span className="w-1 h-4 bg-[#1565c0] rounded-full" />
            核心业务
          </h2>
          <div className="grid grid-cols-4 gap-y-4 gap-x-2">
            {homeFeatures.slice(0, 8).map((f) => {
              const Icon = iconMap[f.icon] || Archive;
              const badge = f.id === 'messages' && unreadMessages > 0 ? unreadMessages : null;
              return (
                <button
                  key={f.id}
                  onClick={() => navigate(`/${f.id}`)}
                  className="flex flex-col items-center gap-1.5 active:scale-95 active:opacity-70 transition-all"
                >
                  <div className="relative w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${f.color}12` }}>
                    <Icon size={20} strokeWidth={1.5} style={{ color: f.color }} />
                    {badge && (
                      <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 flex items-center justify-center bg-red-500 text-white text-[10px] font-bold rounded-full">
                        {badge}
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-gray-700 font-medium">{f.title}</span>
                </button>
              );
            })}
          </div>

          <div className="h-px bg-gray-100 my-3" />

          <h2 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-1.5">
            <span className="w-1 h-4 bg-[#ed6c02] rounded-full" />
            管理支持
          </h2>
          <div className="grid grid-cols-4 gap-y-4 gap-x-2">
            {homeFeatures.slice(8).map((f) => {
              const Icon = iconMap[f.icon] || Archive;
              const badge = f.id === 'warnings' && warningCount > 0 ? warningCount : null;
              return (
                <button
                  key={f.id}
                  onClick={() => navigate(`/${f.id}`)}
                  className="flex flex-col items-center gap-1.5 active:scale-95 active:opacity-70 transition-all"
                >
                  <div className="relative w-11 h-11 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${f.color}12` }}>
                    <Icon size={20} strokeWidth={1.5} style={{ color: f.color }} />
                    {badge && (
                      <span className="absolute -top-1.5 -right-1.5 min-w-[16px] h-4 px-1 flex items-center justify-center bg-red-500 text-white text-[10px] font-bold rounded-full">
                        {badge}
                      </span>
                    )}
                  </div>
                  <span className="text-xs text-gray-700 font-medium">{f.title}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Recent Notifications */}
        <div className="bg-white rounded-2xl shadow-sm p-4 mt-3">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-semibold text-gray-800 flex items-center gap-1.5">
              <span className="w-1 h-4 bg-[#d32f2f] rounded-full" />
              最近通知
            </h2>
            <button onClick={() => navigate('/messages')} className="text-xs text-[#1565c0] font-medium">查看更多</button>
          </div>
          <div className="space-y-3">
            {[
              { title: '装备申领审批通知', desc: '王强申请的防弹背心已审批通过', time: '10分钟前', type: 'approval' },
              { title: '报修进度更新', desc: '执法记录仪#2024038已维修完成', time: '30分钟前', type: 'repair' },
              { title: '装备过期预警', desc: '编号EQ20210123防弹背心15天后过期', time: '1小时前', type: 'warning' },
            ].map((n, i) => (
              <button
                key={i}
                onClick={() => navigate('/messages')}
                className="w-full flex items-start gap-3 text-left active:bg-gray-50 p-2 -mx-2 rounded-xl transition-colors"
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  n.type === 'approval' ? 'bg-blue-50' : n.type === 'repair' ? 'bg-green-50' : 'bg-orange-50'
                }`}>
                  <Bell size={14} className={n.type === 'approval' ? 'text-blue-600' : n.type === 'repair' ? 'text-green-600' : 'text-orange-600'} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-800 truncate">{n.title}</p>
                  <p className="text-xs text-gray-500 truncate">{n.desc}</p>
                </div>
                <span className="text-[10px] text-gray-400 shrink-0">{n.time}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
