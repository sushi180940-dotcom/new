import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import {
  ClipboardCheck, Search, Shield, ShieldAlert, Clock,
  CheckCircle2, XCircle, AlertTriangle, ChevronRight,
  Package, User, Building2, CalendarDays
} from 'lucide-react';

/* ─── types ─── */
export interface ApprovalMaterial {
  name: string; category: string; model: string;
  quantity: number; stockQty: number; unit: string;
  price: number; total: number; equipmentCode: string;
  supplier: string; isFixedAsset: boolean; remark: string;
}

export interface ApprovalItem {
  id: string; type: string; typeKey: string;
  applicant: string; applicantUnit: string;
  applyTime: string; reason: string;
  materials: ApprovalMaterial[];
  status: 'pending' | 'approved' | 'rejected';
  isOverdue: boolean;
  approver?: string; approveTime?: string;
  approveOpinion?: string; rejectReason?: string;
}

/* ─── mock data (exported for ApprovalDetail) ─── */
export const approvalMockData: Record<string, ApprovalItem> = {
  SP20240520001: {
    id: 'SP20240520001', type: '装备申领', typeKey: 'apply',
    applicant: '王强', applicantUnit: '朝阳分局刑侦大队',
    applyTime: '2024-05-20 08:30', reason: '外出执行抓捕任务，需补充防护装备和照明设备',
    isOverdue: true, status: 'pending',
    materials: [
      { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 2, stockQty: 15, unit: '件', price: 1200, total: 2400, equipmentCode: 'EQ202301058', supplier: '红星装备厂', isFixedAsset: true, remark: 'III级防弹标准' },
      { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 3, stockQty: 20, unit: '个', price: 280, total: 840, equipmentCode: 'EQ202202112', supplier: '红星装备厂', isFixedAsset: false, remark: 'LED强光' },
    ],
  },
  SP20240520002: {
    id: 'SP20240520002', type: '装备调拨', typeKey: 'transfer',
    applicant: '李明', applicantUnit: '东城分局巡警支队',
    applyTime: '2024-05-20 14:15', reason: '夏季巡逻装备更新，从主仓库调拨至支队仓库',
    isOverdue: false, status: 'pending',
    materials: [
      { name: '防刺手套', category: '防护装备', model: 'FCST-100', quantity: 10, stockQty: 10, unit: '双', price: 150, total: 1500, equipmentCode: 'EQ202302145', supplier: '盾甲科技', isFixedAsset: false, remark: '' },
      { name: '反光背心', category: '交通管理', model: 'FGBX-2024', quantity: 15, stockQty: 50, unit: '件', price: 65, total: 975, equipmentCode: 'EQ202413111', supplier: '盾甲科技', isFixedAsset: false, remark: '' },
    ],
  },
  SP20240519001: {
    id: 'SP20240519001', type: '装备申领', typeKey: 'apply',
    applicant: '赵刚', applicantUnit: '西城分局特警大队',
    applyTime: '2024-05-19 16:45', reason: '日常执勤使用，需补充记录设备',
    isOverdue: false, status: 'pending',
    materials: [
      { name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 2, stockQty: 8, unit: '台', price: 1800, total: 3600, equipmentCode: 'EQ202401002', supplier: '红星装备厂', isFixedAsset: true, remark: '4K高清，128G存储' },
    ],
  },
  SP20240518001: {
    id: 'SP20240518001', type: '装备交接', typeKey: 'handover',
    applicant: '孙丽', applicantUnit: '海淀分局治安大队',
    applyTime: '2024-05-18 10:20', reason: '装备交接，从治安大队移交至派出所',
    isOverdue: false, status: 'approved',
    approver: '张建国', approveTime: '2024-05-18 11:30',
    approveOpinion: '手续齐全，同意交接',
    materials: [
      { name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 3, stockQty: 6, unit: '台', price: 650, total: 1950, equipmentCode: 'EQ202401089', supplier: '国安器材', isFixedAsset: true, remark: '800MHz频段' },
    ],
  },
  SP20240517001: {
    id: 'SP20240517001', type: '装备申领', typeKey: 'apply',
    applicant: '周涛', applicantUnit: '丰台分局交警大队',
    applyTime: '2024-05-17 09:00', reason: '路面执法装备补充',
    isOverdue: false, status: 'rejected',
    approver: '张建国', approveTime: '2024-05-17 10:15',
    rejectReason: '该装备季度配额已用完，请等待下季度申请',
    materials: [
      { name: '警用盾牌', category: '防护装备', model: 'JYPD-2024', quantity: 5, stockQty: 4, unit: '面', price: 320, total: 1600, equipmentCode: 'EQ202401099', supplier: '盾甲科技', isFixedAsset: true, remark: '' },
    ],
  },
  SP20240515001: {
    id: 'SP20240515001', type: '装备调拨', typeKey: 'transfer',
    applicant: '张伟', applicantUnit: '昌平分局刑警大队',
    applyTime: '2024-05-15 11:00', reason: '跨区协作装备支援调拨',
    isOverdue: false, status: 'approved',
    approver: '张建国', approveTime: '2024-05-15 14:20',
    approveOpinion: '同意调拨，请按流程办理交接手续',
    materials: [
      { name: '战术手电', category: '照明设备', model: 'ZSD-200-X', quantity: 5, stockQty: 20, unit: '个', price: 280, total: 1400, equipmentCode: 'EQ202202112', supplier: '红星装备厂', isFixedAsset: false, remark: 'LED强光' },
      { name: '防弹背心', category: '防护装备', model: 'FDY-2024-A', quantity: 1, stockQty: 15, unit: '件', price: 1200, total: 1200, equipmentCode: 'EQ202301058', supplier: '红星装备厂', isFixedAsset: true, remark: 'III级防弹标准' },
    ],
  },
  SP20240510001: {
    id: 'SP20240510001', type: '装备申领', typeKey: 'apply',
    applicant: '刘洋', applicantUnit: '通州分局派出所',
    applyTime: '2024-05-10 08:30', reason: '新入职警员装备配发',
    isOverdue: false, status: 'rejected',
    approver: '张建国', approveTime: '2024-05-10 09:45',
    rejectReason: '新入职装备配发需通过人事部门统一申报，请补充相关手续',
    materials: [
      { name: '执法记录仪', category: '记录设备', model: 'ZFY-4K-01', quantity: 1, stockQty: 8, unit: '台', price: 1800, total: 1800, equipmentCode: 'EQ202401002', supplier: '红星装备厂', isFixedAsset: true, remark: '' },
      { name: '对讲机', category: '通讯设备', model: 'DJ-HY-800', quantity: 1, stockQty: 6, unit: '台', price: 650, total: 650, equipmentCode: 'EQ202401089', supplier: '国安器材', isFixedAsset: true, remark: '' },
    ],
  },
};

/* ─── current user ─── */
const CURRENT_USER = { name: '张建国', unit: '省厅装备处', role: 'senior_admin', isLeader: true };

/* ─── config ─── */
const statusConfig: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  pending:  { label: '待审批', color: 'text-orange-600', bg: 'bg-orange-50', icon: Clock },
  approved: { label: '已通过', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  rejected: { label: '已驳回', color: 'text-red-600', bg: 'bg-red-50', icon: XCircle },
};

const typeColorMap: Record<string, string> = {
  apply: '#1565c0', transfer: '#7c4dff', handover: '#00acc1',
};

/* ─── main component ─── */
export default function Approval() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('pending');
  const [searchText, setSearchText] = useState('');
  const [orders] = useState(approvalMockData);

  const ordersList = useMemo(() => Object.values(orders), [orders]);

  /* filtered */
  const filtered = useMemo(() => {
    let list = [...ordersList];

    // Tab filter
    if (activeTab === 'pending') list = list.filter(o => o.status === 'pending');
    else if (activeTab === 'approved') list = list.filter(o => o.status === 'approved');
    else if (activeTab === 'rejected') list = list.filter(o => o.status === 'rejected');

    // Search
    if (searchText.trim()) {
      const kw = searchText.toLowerCase();
      list = list.filter(o =>
        o.id.toLowerCase().includes(kw) ||
        o.applicant.includes(kw) ||
        o.type.includes(kw)
      );
    }

    // Sort: overdue first for pending
    if (activeTab === 'pending') {
      list.sort((a, b) => (b.isOverdue ? 1 : 0) - (a.isOverdue ? 1 : 0));
    } else {
      list.sort((a, b) => new Date(b.applyTime).getTime() - new Date(a.applyTime).getTime());
    }

    return list;
  }, [ordersList, activeTab, searchText]);

  /* stats */
  const stats = useMemo(() => ({
    pending: ordersList.filter(o => o.status === 'pending').length,
    overdue: ordersList.filter(o => o.status === 'pending' && o.isOverdue).length,
    approved: ordersList.filter(o => o.status === 'approved').length,
    rejected: ordersList.filter(o => o.status === 'rejected').length,
  }), [ordersList]);

  return (
    <MobileLayout title="审批代办">
      {/* ── Permission Banner ── */}
      <div className="mx-4 mt-3 mb-2">
        <div className={`rounded-xl px-3 py-2.5 flex items-center gap-2 ${
          CURRENT_USER.isLeader ? 'bg-blue-50' : 'bg-orange-50'
        }`}>
          {CURRENT_USER.isLeader ? (
            <Shield size={16} className="text-blue-600 shrink-0" />
          ) : (
            <ShieldAlert size={16} className="text-orange-600 shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium text-gray-700">
              当前身份：<span className={CURRENT_USER.isLeader ? 'text-blue-600' : 'text-orange-600'}>
                {CURRENT_USER.isLeader ? '审批领导' : '普通用户'}
              </span>
            </p>
            <p className="text-[10px] text-gray-500">
              {CURRENT_USER.isLeader
                ? '具备审批权限，可处理待审批工单'
                : '无审批权限，仅可查看已归档记录'}
            </p>
          </div>
        </div>
      </div>

      {/* ── Stats ── */}
      <div className="px-4 mb-3">
        <div className="flex gap-2">
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center relative overflow-hidden">
            {stats.overdue > 0 && (
              <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
            )}
            <p className="text-lg font-bold text-orange-600">{stats.pending}</p>
            <p className="text-[10px] text-gray-500">待审批</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-red-500">{stats.overdue}</p>
            <p className="text-[10px] text-gray-500">已超时</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-green-600">{stats.approved}</p>
            <p className="text-[10px] text-gray-500">已通过</p>
          </div>
          <div className="flex-1 bg-white rounded-2xl p-3 shadow-sm text-center">
            <p className="text-lg font-bold text-gray-500">{stats.rejected}</p>
            <p className="text-[10px] text-gray-500">已驳回</p>
          </div>
        </div>
      </div>

      {/* ── Search ── */}
      <div className="px-4 mb-3">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            value={searchText}
            onChange={e => setSearchText(e.target.value)}
            placeholder="搜索审批单号、申请人..."
            className="w-full bg-white rounded-xl pl-10 pr-4 py-2.5 text-sm text-gray-800 placeholder:text-gray-400 outline-none focus:ring-2 focus:ring-blue-200 border border-gray-200 focus:border-blue-300 transition-all shadow-sm"
          />
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="px-4 mb-3">
        <div className="flex bg-white rounded-xl p-0.5">
          {[
            { key: 'pending', label: '待审批', count: stats.pending },
            { key: 'approved', label: '已通过', count: stats.approved },
            { key: 'rejected', label: '已驳回', count: stats.rejected },
            { key: 'all', label: '全部', count: ordersList.length },
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setActiveTab(t.key)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1 ${
                activeTab === t.key
                  ? t.key === 'pending' ? 'bg-orange-500 text-white' :
                    t.key === 'approved' ? 'bg-green-500 text-white' :
                    t.key === 'rejected' ? 'bg-red-500 text-white' :
                    'bg-[#1565c0] text-white'
                  : 'text-gray-500'
              }`}
            >
              {t.label}
              <span className={`text-[10px] ${activeTab === t.key ? 'text-white/80' : 'text-gray-400'}`}>
                ({t.count})
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* ── List ── */}
      <div className="px-4 pb-4 space-y-2">
        {filtered.map(item => {
          const sc = statusConfig[item.status];
          const StatusIcon = sc.icon;
          const totalQty = item.materials.reduce((s, m) => s + m.quantity, 0);
          const totalAmount = item.materials.reduce((s, m) => s + m.total, 0);
          return (
            <button
              key={item.id}
              onClick={() => navigate(`/approval/${item.id}`)}
              className={`w-full bg-white rounded-2xl p-4 text-left shadow-sm active:bg-gray-50 transition-colors ${
                item.isOverdue && item.status === 'pending' ? 'ring-1 ring-red-200' : ''
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-900 font-mono">{item.id}</span>
                  <span
                    className="px-1.5 py-0.5 rounded text-[10px] font-medium text-white"
                    style={{ backgroundColor: typeColorMap[item.typeKey] || '#1565c0' }}
                  >
                    {item.type}
                  </span>
                </div>
                <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${sc.bg} ${sc.color}`}>
                  <StatusIcon size={10} /> {sc.label}
                </span>
              </div>

              {/* Overdue Warning */}
              {item.isOverdue && item.status === 'pending' && (
                <div className="flex items-center gap-1.5 bg-red-50 rounded-lg px-2.5 py-1.5 mb-2.5">
                  <AlertTriangle size={12} className="text-red-500" />
                  <span className="text-xs text-red-600 font-medium">审批已超时，请尽快处理</span>
                </div>
              )}

              {/* Info */}
              <div className="space-y-1.5 mb-2.5">
                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                  <User size={10} className="shrink-0" />
                  <span>{item.applicant}</span>
                  <span className="text-gray-300">|</span>
                  <Building2 size={10} className="shrink-0" />
                  <span className="truncate">{item.applicantUnit}</span>
                </div>
                <div className="flex items-center gap-1.5 text-xs text-gray-500">
                  <CalendarDays size={10} className="shrink-0" />
                  <span>{item.applyTime}</span>
                </div>
                <p className="text-xs text-gray-600 line-clamp-1">{item.reason}</p>
              </div>

              {/* Materials Summary */}
              <div className="pt-2 border-t border-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-1">
                  <Package size={10} className="text-gray-400" />
                  <span className="text-xs text-gray-500">
                    {item.materials.length}种 · {totalQty}件 · ¥{totalAmount.toLocaleString()}
                  </span>
                </div>
                <ChevronRight size={14} className="text-gray-400" />
              </div>
            </button>
          );
        })}

        {filtered.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-gray-400">
            <ClipboardCheck size={40} strokeWidth={1} />
            <p className="mt-3 text-sm">暂无审批事项</p>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}
