import { useState } from 'react';
import { statisticsData } from '@/data/mock';
import MobileLayout from '@/components/MobileLayout';
import {
  BarChart3, Shield, ShieldCheck, ArrowUpRight,
  ArrowDownRight, TrendingUp, Package,
  Warehouse, Wrench, AlertTriangle,
  XCircle, Clock
} from 'lucide-react';

/* ─── types ─── */
interface Period {
  key: string;
  label: string;
  inDate: string;
  outDate: string;
}

const periods: Period[] = [
  { key: 'day', label: '日', inDate: '2024-05-20', outDate: '2024-05-19' },
  { key: 'week', label: '周', inDate: '2024-05-18~20', outDate: '2024-05-11~17' },
  { key: 'month', label: '月', inDate: '2024-05', outDate: '2024-04' },
  { key: 'custom', label: '自定义', inDate: '', outDate: '' },
];

const colors = ['#1565c0', '#43a047', '#7c4dff', '#ff9800', '#ef5350', '#26a69a'];

/* ─── bar chart helper ─── */
function MiniBarChart({ data, max }: { data: number[]; max?: number }) {
  const maxVal = max || Math.max(...data);
  return (
    <div className="flex items-end gap-1 h-16">
      {data.map((v, i) => (
        <div key={i} className="flex-1 flex flex-col items-center justify-end gap-1">
          <div className="w-full bg-blue-200 rounded-sm relative" style={{ height: `${Math.max(4, (v / maxVal) * 40)}px` }}>
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 text-[9px] text-gray-500">{v}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ─── pie chart helper ─── */
function MiniPieChart({ data, total }: { data: { name: string; value: number }[]; total: number }) {
  let cumulative = 0;
  const slices = data.map((d, i) => {
    const start = cumulative;
    cumulative += (d.value / total) * 360;
    return { ...d, start, end: cumulative, color: colors[i % colors.length] };
  });

  return (
    <div className="flex items-center gap-4">
      <svg viewBox="0 0 100 100" className="w-24 h-24 shrink-0">
        {slices.map((s, i) => {
          const startAngle = (s.start - 90) * (Math.PI / 180);
          const endAngle = (s.end - 90) * (Math.PI / 180);
          const x1 = 50 + 40 * Math.cos(startAngle);
          const y1 = 50 + 40 * Math.sin(startAngle);
          const x2 = 50 + 40 * Math.cos(endAngle);
          const y2 = 50 + 40 * Math.sin(endAngle);
          const largeArc = s.end - s.start > 180 ? 1 : 0;
          return (
            <path
              key={i}
              d={`M 50 50 L ${x1} ${y1} A 40 40 0 ${largeArc} 1 ${x2} ${y2} Z`}
              fill={s.color}
            />
          );
        })}
        <circle cx="50" cy="50" r="20" fill="white" />
        <text x="50" y="48" textAnchor="middle" className="text-[10px] font-bold" fill="#374151">{total}</text>
        <text x="50" y="56" textAnchor="middle" className="text-[6px]" fill="#9ca3af">总计</text>
      </svg>
      <div className="flex-1 space-y-1.5">
        {slices.map((s, i) => (
          <div key={i} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: s.color }} />
              <span className="text-gray-600">{s.name}</span>
            </div>
            <span className="text-gray-800 font-medium">{s.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Statistics() {
  const [activePeriod, setActivePeriod] = useState('month');
  const [activeTab, setActiveTab] = useState('overview');

  const isAdmin = true;
  const d = statisticsData;
  const totalEquip = d.equipment.total;

  /* tabs */
  const tabs = [
    { key: 'overview', label: '总览', icon: BarChart3 },
    { key: 'inventory', label: '出入库', icon: Package },
    { key: 'status', label: '存放状态', icon: Warehouse },
    { key: 'efficiency', label: '使用效能', icon: TrendingUp },
    { key: 'check', label: '盘点统计', icon: ShieldCheck },
  ];

  return (
    <MobileLayout title="统计分析" showBack>
      {/* ── Permission Banner ── */}
      <div className="mx-4 mt-3 mb-2">
        <div className={`rounded-xl px-3 py-2.5 flex items-center gap-2 ${isAdmin ? 'bg-blue-50' : 'bg-orange-50'}`}>
          {isAdmin ? <Shield size={16} className="text-blue-600 shrink-0" /> : <ShieldCheck size={16} className="text-orange-600 shrink-0" />}
          <div>
            <p className="text-xs font-medium text-gray-700">
              当前身份：<span className={isAdmin ? 'text-blue-600' : 'text-orange-600'}>{isAdmin ? '高级管理员' : '普通用户'}</span>
            </p>
            <p className="text-[10px] text-gray-500">{isAdmin ? '可查看完整统计数据' : '仅可查看基础公开数据'}</p>
          </div>
        </div>
      </div>

      {/* ── Period Selector ── */}
      <div className="px-4 mb-3">
        <div className="flex bg-white rounded-xl p-0.5">
          {periods.map(p => (
            <button
              key={p.key}
              onClick={() => setActivePeriod(p.key)}
              className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                activePeriod === p.key ? 'bg-[#1565c0] text-white' : 'text-gray-500'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="px-4 mb-3">
        <div className="flex bg-white rounded-xl p-0.5 overflow-x-auto no-scrollbar">
          {tabs.map(t => {
            const TabIcon = t.icon;
            return (
              <button
                key={t.key}
                onClick={() => setActiveTab(t.key)}
                className={`shrink-0 px-3 py-2 rounded-lg text-xs font-medium transition-all flex items-center gap-1 ${
                  activeTab === t.key ? 'bg-[#1565c0] text-white' : 'text-gray-500'
                }`}
              >
                <TabIcon size={12} /> {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Overview Tab ── */}
      {activeTab === 'overview' && (
        <div className="px-4 pb-4 space-y-3">
          {/* Summary Cards */}
          <div className="grid grid-cols-2 gap-2">
            {[
              { label: '在库总数', value: d.equipment.inStock, icon: Warehouse, color: 'text-blue-600', bg: 'bg-blue-50' },
              { label: '闲置装备', value: d.equipment.idle, icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
              { label: '在用装备', value: d.equipment.inUse, icon: Package, color: 'text-green-600', bg: 'bg-green-50' },
              { label: '超期装备', value: d.equipment.overdue, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
              { label: '报废装备', value: d.equipment.scrapped, icon: XCircle, color: 'text-gray-500', bg: 'bg-gray-100' },
              { label: '维修中', value: d.equipment.repairing, icon: Wrench, color: 'text-purple-600', bg: 'bg-purple-50' },
            ].map(card => {
              const CardIcon = card.icon;
              return (
                <div key={card.label} className="bg-white rounded-2xl p-3 shadow-sm">
                  <div className="flex items-center gap-1.5 mb-1">
                    <CardIcon size={12} className={card.color} />
                    <span className="text-[10px] text-gray-500">{card.label}</span>
                  </div>
                  <p className={`text-lg font-bold ${card.color}`}>{card.value.toLocaleString()}</p>
                </div>
              );
            })}
          </div>

          {/* In/Out Summary */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">出入库概况</h3>
            <div className="flex gap-3">
              <div className="flex-1 bg-green-50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">本期入库</p>
                <p className="text-xl font-bold text-green-600">{d.inventory.inMonth}</p>
                <div className="flex items-center justify-center gap-1 mt-1">
                  <ArrowUpRight size={10} className="text-green-500" />
                  <span className="text-[10px] text-green-500">同比 {d.inventory.inYoY}%</span>
                </div>
              </div>
              <div className="flex-1 bg-red-50 rounded-xl p-3 text-center">
                <p className="text-xs text-gray-500">本期出库</p>
                <p className="text-xl font-bold text-red-500">{d.inventory.outMonth}</p>
                <div className="flex items-center justify-center gap-1 mt-1">
                  {d.inventory.outMoM >= 0 ? (
                    <ArrowUpRight size={10} className="text-red-500" />
                  ) : (
                    <ArrowDownRight size={10} className="text-green-500" />
                  )}
                  <span className={`text-[10px] ${d.inventory.outMoM >= 0 ? 'text-red-500' : 'text-green-500'}`}>
                    环比 {d.inventory.outMoM}%
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Inventory Tab ── */}
      {activeTab === 'inventory' && (
        <div className="px-4 pb-4 space-y-3">
          {/* Trend Chart */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">每日入库/出库趋势</h3>
            <div className="mb-4">
              <MiniBarChart data={d.inventory.inTrend} />
              <div className="flex justify-between mt-1">
                {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map(d => (
                  <span key={d} className="text-[9px] text-gray-400">{d}</span>
                ))}
              </div>
              <p className="text-[10px] text-gray-500 mt-1 flex items-center gap-1">
                <span className="w-3 h-1.5 bg-blue-200 rounded-sm inline-block" /> 入库
              </p>
            </div>
            <div>
              <MiniBarChart data={d.inventory.outTrend} />
              <div className="flex justify-between mt-1">
                {['周一', '周二', '周三', '周四', '周五', '周六', '周日'].map(d => (
                  <span key={d} className="text-[9px] text-gray-400">{d}</span>
                ))}
              </div>
              <p className="text-[10px] text-gray-500 mt-1 flex items-center gap-1">
                <span className="w-3 h-1.5 bg-blue-200 rounded-sm inline-block" /> 出库
              </p>
            </div>
          </div>

          {/* YoY MoM */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">同比/环比数据</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between py-2 border-b border-gray-50">
                <span className="text-xs text-gray-500">入库同比</span>
                <span className="text-xs font-medium text-green-600">+{d.inventory.inYoY}%</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-50">
                <span className="text-xs text-gray-500">入库环比</span>
                <span className="text-xs font-medium text-green-600">+{d.inventory.inMoM}%</span>
              </div>
              <div className="flex justify-between py-2 border-b border-gray-50">
                <span className="text-xs text-gray-500">出库同比</span>
                <span className="text-xs font-medium text-green-600">+{d.inventory.outYoY}%</span>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-xs text-gray-500">出库环比</span>
                <span className="text-xs font-medium text-red-500">{d.inventory.outMoM}%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Status Tab ── */}
      {activeTab === 'status' && (
        <div className="px-4 pb-4 space-y-3">
          {/* Pie Chart */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">装备存放状态分布</h3>
            <MiniPieChart data={d.equipment.statusPie} total={totalEquip} />
          </div>

          {/* Category Stats */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">各仓库存放情况</h3>
            {d.warehouse.warehouseStats.map((w, i) => {
              const pct = Math.round((w.used / w.capacity) * 100);
              return (
                <div key={i} className="mb-3 last:mb-0">
                  <div className="flex justify-between mb-1">
                    <span className="text-xs text-gray-700">{w.name}</span>
                    <span className="text-xs text-gray-500">{w.used}/{w.capacity}</span>
                  </div>
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-[#1565c0] rounded-full" style={{ width: `${pct}%` }} />
                  </div>
                  <p className="text-[10px] text-gray-400 mt-0.5">利用率 {pct}%</p>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Efficiency Tab ── */}
      {activeTab === 'efficiency' && (
        <div className="px-4 pb-4 space-y-3">
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">装备类别利用率</h3>
            <div className="space-y-3">
              {d.equipment.categoryStats.map((c, i) => (
                <div key={i}>
                  <div className="flex justify-between mb-1">
                    <span className="text-xs text-gray-700">{c.name}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-400">{c.inUse}/{c.count}件</span>
                      <span className="text-xs font-medium text-[#1565c0]">{c.utilization}%</span>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${c.utilization}%`, backgroundColor: colors[i % colors.length] }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Summary */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className="text-lg font-bold text-[#1565c0]">{d.equipment.total.toLocaleString()}</p>
              <p className="text-[10px] text-gray-500">装备总量</p>
            </div>
            <div className="bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className="text-lg font-bold text-green-600">{((d.equipment.inUse / d.equipment.total) * 100).toFixed(1)}%</p>
              <p className="text-[10px] text-gray-500">整体利用率</p>
            </div>
          </div>
        </div>
      )}

      {/* ── Check Tab ── */}
      {activeTab === 'check' && (
        <div className="px-4 pb-4 space-y-3">
          {/* Check Summary */}
          <div className="grid grid-cols-3 gap-2">
            <div className="bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className="text-lg font-bold text-[#1565c0]">{d.check.totalCheck}</p>
              <p className="text-[10px] text-gray-500">盘点总数</p>
            </div>
            <div className="bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className="text-lg font-bold text-green-600">{d.check.passed}</p>
              <p className="text-[10px] text-gray-500">正常</p>
            </div>
            <div className="bg-white rounded-2xl p-3 shadow-sm text-center">
              <p className="text-lg font-bold text-red-500">{d.check.abnormal}</p>
              <p className="text-[10px] text-gray-500">异常</p>
            </div>
          </div>

          {/* Monthly Check Trend */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3">盘点趋势</h3>
            <div className="space-y-2">
              {d.check.monthlyCheck.map((m, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs text-gray-500 w-8 shrink-0">{m.month}</span>
                  <div className="flex-1 flex items-center gap-1">
                    <div className="flex-1 h-4 bg-green-100 rounded-sm relative overflow-hidden">
                      <div className="h-full bg-green-400 rounded-sm" style={{ width: `${(m.passed / m.total) * 100}%` }} />
                    </div>
                    {m.abnormal > 0 && (
                      <div className="h-4 bg-red-100 rounded-sm relative overflow-hidden" style={{ width: `${(m.abnormal / m.total) * 60}px` }}>
                        <div className="h-full bg-red-400 rounded-sm w-full" />
                      </div>
                    )}
                  </div>
                  <span className="text-[10px] text-gray-500 shrink-0">{m.total}件</span>
                </div>
              ))}
            </div>
            <div className="flex items-center gap-4 mt-2">
              <span className="text-[10px] text-gray-400 flex items-center gap-1"><span className="w-2 h-2 bg-green-400 rounded-sm" /> 正常</span>
              <span className="text-[10px] text-gray-400 flex items-center gap-1"><span className="w-2 h-2 bg-red-400 rounded-sm" /> 异常</span>
            </div>
          </div>

          {/* Abnormal List */}
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
              <AlertTriangle size={14} className="text-red-500" /> 盘点异常清单
            </h3>
            <div className="space-y-2">
              {d.check.abnormalList.map((a, i) => (
                <div key={i} className="flex items-start gap-3 bg-red-50 rounded-xl p-3">
                  <span className="text-[10px] text-red-400 font-mono shrink-0">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-800">{a.name}</p>
                    <p className="text-[10px] text-gray-500 font-mono">{a.code}</p>
                    <p className="text-xs text-red-600 mt-0.5">{a.reason}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </MobileLayout>
  );
}
