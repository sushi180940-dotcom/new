import { useParams, useNavigate } from 'react-router';
import MobileLayout from '@/components/MobileLayout';
import { personalEquipment } from '@/data/mock';
import { useState, useCallback } from 'react';
import {
  Package, CheckCircle2, Wrench, AlertTriangle,
  Clock, Tag, StickyNote,
  CircleDot, FileText, CheckCircle, Copy
} from 'lucide-react';

const statusMap: Record<string, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  normal: { label: '正常', color: 'text-green-600', bg: 'bg-green-50', icon: CheckCircle2 },
  repair: { label: '维修中', color: 'text-orange-600', bg: 'bg-orange-50', icon: Wrench },
  warning: { label: '预警', color: 'text-red-600', bg: 'bg-red-50', icon: AlertTriangle },
};

function getDaysUntil(dateStr: string): number {
  const target = new Date(dateStr);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export default function PersonalEquipmentDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const item = personalEquipment.find(e => e.id === id);

  if (!item) {
    return (
      <MobileLayout title="装备详情" showBack onBack={() => navigate('/profile/equipment')}>
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <Package size={40} strokeWidth={1} />
          <p className="mt-3 text-sm">未找到装备信息</p>
        </div>
      </MobileLayout>
    );
  }

  const cfg = statusMap[item.status];
  const StatusIcon = cfg.icon;
  const daysUntilExpiry = getDaysUntil(item.expiryDate);
  const isExpired = daysUntilExpiry < 0;
  const isNearExpiry = daysUntilExpiry >= 0 && daysUntilExpiry <= 30;
  const isTemp = item.type === 'temporary';
  const returnDays = isTemp && item.returnDate ? getDaysUntil(item.returnDate) : null;

  return (
    <MobileLayout title="装备详情" showBack onBack={() => navigate('/profile/equipment')}>
      <div className="p-4">
        {/* ── Header Card ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <div className="flex items-center gap-4 mb-4">
            <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${cfg.bg}`}>
              <StatusIcon size={28} className={cfg.color} />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="text-base font-bold text-gray-900">{item.name}</h3>
                <span className={`px-2 py-0.5 rounded text-[10px] font-medium ${cfg.bg} ${cfg.color}`}>
                  {cfg.label}
                </span>
              </div>
              <p className="text-xs text-gray-500">{item.category} · {item.equipmentCode}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${
                  item.type === 'permanent' ? 'bg-blue-50 text-blue-600' : 'bg-orange-50 text-orange-600'
                }`}>
                  {item.type === 'permanent' ? '常态配备' : '临时领用'}
                </span>
                {item.isFixedAsset && (
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-medium bg-purple-50 text-purple-600">
                    固定资产
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Expiry alert */}
          {(isExpired || isNearExpiry) && (
            <div className={`rounded-xl p-3 mb-2 flex items-center gap-2 ${
              isExpired ? 'bg-red-50' : 'bg-orange-50'
            }`}>
              <AlertTriangle size={16} className={isExpired ? 'text-red-600' : 'text-orange-600'} />
              <p className={`text-xs font-medium ${isExpired ? 'text-red-700' : 'text-orange-700'}`}>
                {isExpired
                  ? `该装备已于 ${item.expiryDate} 过期，请尽快处理`
                  : `该装备有效期仅剩 ${daysUntilExpiry} 天（${item.expiryDate} 到期）`}
              </p>
            </div>
          )}

          {/* Return alert for temp */}
          {isTemp && returnDays !== null && (
            <div className={`rounded-xl p-3 mb-2 flex items-center gap-2 ${
              returnDays < 0 ? 'bg-red-50' : returnDays <= 3 ? 'bg-red-50' : returnDays <= 7 ? 'bg-orange-50' : 'bg-green-50'
            }`}>
              <Clock size={16} className={returnDays <= 7 ? 'text-red-600' : 'text-green-600'} />
              <p className={`text-xs font-medium ${
                returnDays < 0 ? 'text-red-700' : returnDays <= 7 ? 'text-red-700' : 'text-green-700'
              }`}>
                {returnDays < 0
                  ? `临时领用已超期 ${Math.abs(returnDays)} 天，请尽快归还（应还日期：${item.returnDate}）`
                  : returnDays <= 7
                    ? `临时领用即将到期，还剩 ${returnDays} 天（应还日期：${item.returnDate}）`
                    : `临时领用剩余 ${returnDays} 天（应还日期：${item.returnDate}）`}
              </p>
            </div>
          )}
        </div>

        {/* ── Equipment Info ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <Tag size={14} className="text-[#1565c0]" /> 装备信息
          </h3>
          <div className="space-y-2 text-sm">
            <InfoRow label="物资名称" value={item.name} />
            <InfoRow label="物资类别" value={item.category} />
            <InfoRow label="规格型号" value={item.model} />
            <InfoRow label="数量" value={`${item.quantity} ${item.unit}`} />
            <InfoRow label="单价" value={`¥${item.price.toLocaleString()}`} />
            <InfoRow label="总价" value={`¥${item.total.toLocaleString()}`} bold />
            <InfoRow label="装备编码" value={item.equipmentCode} mono />
            <InfoRow label="RFID编码" value={item.rfidCode} mono />
            <InfoRow label="供应商" value={item.supplier} />
            <InfoRow label="生产日期" value={item.productionDate} />
            <InfoRow label="有效期至" value={item.expiryDate} highlight={isExpired || isNearExpiry} />
            <InfoRow label="保养期" value={`${item.maintenanceValue}${item.maintenanceUnit}`} />
            <InfoRow label="配发日期" value={item.issueDate} />
            {item.remark && (
              <div className="pt-2 border-t border-gray-100">
                <p className="text-xs text-gray-500 flex items-center gap-1">
                  <StickyNote size={10} /> 备注
                </p>
                <p className="text-xs text-gray-700 mt-1">{item.remark}</p>
              </div>
            )}
          </div>
        </div>

        {/* ── User Manual ── */}
        <div className="bg-white rounded-2xl p-4 shadow-sm mb-3">
          <h3 className="text-sm font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <FileText size={14} className="text-[#1565c0]" /> 使用说明
          </h3>
          <UserManualLink equipmentCode={item.equipmentCode} equipmentName={item.name} />
        </div>

        {/* ── Issue Records Timeline ── */}
        {'issueRecords' in item && Array.isArray(item.issueRecords) && item.issueRecords.length > 0 && (
          <div className="bg-white rounded-2xl p-4 shadow-sm">
            <h3 className="text-sm font-semibold text-gray-800 mb-4 flex items-center gap-2">
              <Clock size={14} className="text-[#1565c0]" /> 领用记录
            </h3>
            <div className="space-y-0">
              {(item.issueRecords as Array<{event: string; operator: string; time: string; detail: string}>).map((rec, i, arr) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-7 h-7 rounded-full flex items-center justify-center ${
                      i === 0 ? 'bg-green-500' : 'bg-blue-500'
                    }`}>
                      <CircleDot size={12} className="text-white" />
                    </div>
                    {i < arr.length - 1 && <div className="w-0.5 h-10 bg-gray-200" />}
                  </div>
                  <div className="pb-4">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-medium text-gray-800">{rec.event}</p>
                      <span className="text-[10px] text-gray-400">{rec.operator}</span>
                    </div>
                    <p className="text-[10px] text-gray-400">{rec.time}</p>
                    <p className="text-xs text-gray-600 mt-0.5">{rec.detail}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </MobileLayout>
  );
}

/* ─── User Manual Link Component ─── */
function UserManualLink({ equipmentCode, equipmentName }: { equipmentCode: string; equipmentName: string }) {
  const [copied, setCopied] = useState(false);
  const manualUrl = `https://manual.police.gov.cn/equipment/${equipmentCode}`;

  const handleCopy = useCallback(() => {
    navigator.clipboard?.writeText(manualUrl).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [manualUrl]);

  return (
    <div>
      <p className="text-xs text-gray-500 mb-2">{equipmentName} 使用说明文档</p>
      <div className="flex items-center gap-2 bg-gray-50 rounded-xl p-3">
        <div className="flex-1 min-w-0">
          <p className="text-xs text-[#1565c0] font-mono truncate">{manualUrl}</p>
        </div>
        <button
          onClick={handleCopy}
          className="shrink-0 flex items-center gap-1 px-3 py-1.5 rounded-lg bg-blue-50 text-[#1565c0] text-xs font-medium active:bg-blue-100 transition-colors"
        >
          {copied ? (
            <><CheckCircle size={12} /> 已复制</>
          ) : (
            <><Copy size={12} /> 复制链接</>
          )}
        </button>
      </div>
    </div>
  );
}

/* ─── helper ─── */
function InfoRow({ label, value, bold, mono, highlight }: {
  label: string; value: string; bold?: boolean; mono?: boolean; highlight?: boolean;
}) {
  return (
    <div className="flex justify-between py-1.5 border-b border-gray-50 last:border-0">
      <span className="text-xs text-gray-500">{label}</span>
      <span className={`text-xs ${bold ? 'font-bold text-[#1565c0]' : mono ? 'font-mono text-gray-800' : highlight ? 'font-medium text-red-600' : 'text-gray-800 font-medium'}`}>
        {value}
      </span>
    </div>
  );
}
