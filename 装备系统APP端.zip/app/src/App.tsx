import { Routes, Route } from 'react-router';
import Home from './pages/Home';
import Messages from './pages/Messages';
import Profile from './pages/Profile';
import InInventory from './pages/InInventory';
import InInventoryDetail from './pages/InInventoryDetail';
import OutInventory from './pages/OutInventory';
import OutInventoryDetail from './pages/OutInventoryDetail';
import ScanQuery from './pages/ScanQuery';
import Repair from './pages/Repair';
import RepairDetail from './pages/RepairDetail';
import Approval from './pages/Approval';
import ApprovalDetail from './pages/ApprovalDetail';
import Trace from './pages/Trace';
import Apply from './pages/Apply';
import ApplyDetail from './pages/ApplyDetail';
import Transfer from './pages/Transfer';
import TransferDetail from './pages/TransferDetail';
import Statistics from './pages/Statistics';
import UserManage from './pages/UserManage';
import UserDetail from './pages/UserDetail';
import UserReset from './pages/UserReset';
import Warnings from './pages/Warnings';
import PersonalEquipment from './pages/PersonalEquipment';
import PersonalEquipmentDetail from './pages/PersonalEquipmentDetail';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/messages" element={<Messages />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/in" element={<InInventory />} />
      <Route path="/in/:id" element={<InInventoryDetail />} />
      <Route path="/out" element={<OutInventory />} />
      <Route path="/out/:id" element={<OutInventoryDetail />} />
      <Route path="/scan" element={<ScanQuery />} />
      <Route path="/repair" element={<Repair />} />
      <Route path="/repair/:id" element={<RepairDetail />} />
      <Route path="/approval" element={<Approval />} />
      <Route path="/approval/:id" element={<ApprovalDetail />} />
      <Route path="/trace" element={<Trace />} />
      <Route path="/apply" element={<Apply />} />
      <Route path="/apply/:id" element={<ApplyDetail />} />
      <Route path="/transfer" element={<Transfer />} />
      <Route path="/transfer/:id" element={<TransferDetail />} />
      <Route path="/statistics" element={<Statistics />} />
      <Route path="/users" element={<UserManage />} />
      <Route path="/users/:id" element={<UserDetail />} />
      <Route path="/users/:id/reset" element={<UserReset />} />
      <Route path="/warnings" element={<Warnings />} />
      <Route path="/profile/equipment" element={<PersonalEquipment />} />
      <Route path="/profile/equipment/:id" element={<PersonalEquipmentDetail />} />
    </Routes>
  );
}
