import { useState } from 'react'
import {
  ChevronRight, ChevronDown, Search, Plus, X, Eye,
  Image, Video, FileText, Battery, BatteryMedium,
  Pencil, Trash2, Upload, XCircle
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'

// ─── Types ───
interface CategoryNode {
  id: string
  name: string
  level: number
  children?: CategoryNode[]
}

type DetailTab = 'basic' | 'images' | 'videos' | 'docs'

type PageTab = 'equipment' | 'pending'
type PendingStatus = '待审核' | '已通过' | '已驳回' | '转审中'

interface PendingEquipment {
  id: string
  code: string
  name: string
  categoryL1: string
  categoryL2: string
  categoryL3: string
  model: string
  modelCode: string
  unit: string
  brand: string
  manufacturer: string
  spec: string
  submitCompany: string
  submitter: string
  submitTime: string
  status: PendingStatus
  auditUnit?: string
  remark: string
  rejectReason?: string
  transferTo?: string
}

interface EditingForm {
  code: string
  name: string
  categoryL3: string
  model: string
  modelCode: string
  unit: string
  brand: string
  manufacturer: string
  spec: string
  auditRemark: string
}


interface Equipment {
  id: string
  code: string
  name: string
  category: string
  variety: string
  model: string
  modelCode: string
  unit: string
  brand: string
  manufacturer: string
  spec: string
  material: string
  weight: string
  warranty: number
  hasBattery: '是' | '否'
  maintenanceMonths: number
  description: string
  images: string[]
  videos: string[]
  docs: string[]
  status: '启用' | '停用'
}

// ─── Pending Equipment Mock Data ───
let pendingEquipmentList: PendingEquipment[] = [
  { id: 'pe1', code: '2101001-A', name: '现场测记录综合系统V2', categoryL1: '刑事技术装备', categoryL2: '现场勘查装备', categoryL3: '现场检测', model: 'SJ-V2', modelCode: 'MOD-SJV2-2025', unit: '套', brand: 'AA科技', manufacturer: 'AA信息技术有限公司', spec: '增强版/AI辅助', submitCompany: 'AA信息技术有限公司', submitter: '王经理', submitTime: '2025-12-28 10:30', status: '已通过', auditUnit: '省公安厅警保部', remark: 'AI辅助功能增强' },
  { id: 'pe2', code: '2103010-A', name: '生物物证勘查提取箱升级版', categoryL1: '刑事技术装备', categoryL2: '现场勘查装备', categoryL3: '发现提取', model: 'SW-V2', modelCode: 'MOD-SWV2-2025', unit: '个', brand: 'BB生物', manufacturer: 'BB生物科技有限公司', spec: '升级版/快速检测', submitCompany: 'BB生物科技有限公司', submitter: '李经理', submitTime: '2025-12-27 14:20', status: '已通过', auditUnit: '装备标准化委员会', remark: '新增快速检测模块' },
  { id: 'pe3', code: '2201001-A', name: '气味鉴别犬', categoryL1: '刑事技术装备', categoryL2: '警犬装备', categoryL3: '警犬', model: 'QW-001', modelCode: 'MOD-QW001-2025', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '气味鉴别型', submitCompany: 'CC警犬繁育基地', submitter: '张主任', submitTime: '2025-12-26 09:15', status: '已驳回', auditUnit: '省公安厅警保部', remark: '专项气味鉴别训练', rejectReason: '训练周期不足，未达到上岗标准' },
  { id: 'pe4', code: '2102006-A', name: '多波段光源PRO版', categoryL1: '刑事技术装备', categoryL2: '现场勘查装备', categoryL3: '辅助观测', model: 'DB-PRO', modelCode: 'MOD-DBPRO-2025', unit: '台', brand: 'DD光学', manufacturer: 'DD光学仪器有限公司', spec: 'PRO版/16波段', submitCompany: 'DD光学仪器有限公司', submitter: '赵经理', submitTime: '2025-12-25 16:45', status: '待审核', remark: '16波段可调，覆盖200-1000nm' },
  { id: 'pe5', code: '2301001-A', name: '智能物证保全管理系统', categoryL1: '刑事技术装备', categoryL2: '物证保全装备', categoryL3: '管理系统', model: 'ZN-001', modelCode: 'MOD-ZN001-2025', unit: '套', brand: 'EE软件', manufacturer: 'EE软件科技有限公司', spec: '智能版/RFID追踪', submitCompany: 'EE软件科技有限公司', submitter: '刘经理', submitTime: '2025-12-24 11:00', status: '转审中', auditUnit: '省公安厅警保部', remark: 'RFID全程追踪', transferTo: '采购管理中心' },
]

// ─── Category Tree (刑事技术装备) ───
const categoryTree: CategoryNode[] = [
  { id: 'all', name: '全部装备', level: 0 },
  {
    id: 'c1', name: '刑事技术装备', level: 0,
    children: [
      {
        id: 'v1', name: '现场勘查装备', level: 1,
        children: [
          { id: 'm1', name: '现场检测', level: 2 },
          { id: 'm2', name: '辅助观测', level: 2 },
          { id: 'm3', name: '发现提取', level: 2 },
        ],
      },
      {
        id: 'v2', name: '警犬装备', level: 1,
        children: [
          { id: 'm4', name: '警犬', level: 2 },
          { id: 'm5', name: '配套保障', level: 2 },
        ],
      },
      {
        id: 'v3', name: '物证保全装备', level: 1,
        children: [
          { id: 'm6', name: '管理系统', level: 2 },
          { id: 'm7', name: '存放容器', level: 2 },
        ],
      },
    ],
  },
]

// ─── 47 Equipment Records ───
const equipmentList: Equipment[] = [
  { id: 'e2101001', code: '2101001', name: '现场测记录、信息录入及三维重建综合系统', category: '现场检测', variety: '现场检测', model: 'SJ-001', modelCode: '001', unit: '套', brand: 'XX科技', manufacturer: 'XX信息技术有限公司', spec: '记录/录入/三维重建', material: '电子设备', weight: '5kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '集现场测记录、信息录入及三维重建功能于一体的综合系统。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101002', code: '2101002', name: '现场制卷软件及输出设备', category: '现场检测', variety: '现场检测', model: 'ZJ-002', modelCode: '002', unit: '套', brand: 'XX软件', manufacturer: 'XX软件开发有限公司', spec: '制卷/输出', material: '软件+硬件', weight: '3kg', warranty: 2, hasBattery: '否', maintenanceMonths: 12, description: '用于现场制卷及输出的软件和设备。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101003', code: '2101003', name: '案件现场计算机绘图系统', category: '现场检测', variety: '现场检测', model: 'HT-003', modelCode: '003', unit: '套', brand: 'XX数码', manufacturer: 'XX数码科技有限公司', spec: '计算机绘图', material: '电子设备', weight: '4kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '案件现场计算机绘图系统。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101004', code: '2101004', name: '现场甚测多功能计算尺', category: '现场检测', variety: '现场检测', model: 'JC-004', modelCode: '004', unit: '把', brand: 'XX工具', manufacturer: 'XX工具制造有限公司', spec: '多功能测量', material: '合金', weight: '0.2kg', warranty: 2, hasBattery: '否', maintenanceMonths: 12, description: '现场甚测多功能计算尺。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101005', code: '2101005', name: 'LSD激光照相测量器', category: '现场检测', variety: '现场检测', model: 'JG-005', modelCode: '005', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '激光照相测量', material: '精密光学', weight: '1.5kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: 'LSD激光照相测量器。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101006', code: '2101006', name: '激光观察仪', category: '现场检测', variety: '现场检测', model: 'JG-006', modelCode: '006', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '激光观察', material: '精密光学', weight: '1.2kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '激光观察仪。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101007', code: '2101007', name: '定向反射镜', category: '现场检测', variety: '现场检测', model: 'FS-007', modelCode: '007', unit: '面', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '定向反射', material: '镀银玻璃', weight: '0.5kg', warranty: 2, hasBattery: '否', maintenanceMonths: 12, description: '定向反射镜。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101008', code: '2101008', name: '现场勘查化验箱', category: '现场检测', variety: '现场检测', model: 'HY-008', modelCode: '008', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '勘查化验', material: '复合材料', weight: '8kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '现场勘查化验箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101009', code: '2101009', name: '道路与机动车性能测试设备', category: '现场检测', variety: '现场检测', model: 'CS-009', modelCode: '009', unit: '套', brand: 'XX交通', manufacturer: 'XX交通设备有限公司', spec: '性能测试', material: '电子设备', weight: '15kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '道路与机动车性能测试设备。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2101010', code: '2101010', name: '交通事故现场勘验箱', category: '现场检测', variety: '现场检测', model: 'KY-010', modelCode: '010', unit: '个', brand: 'XX交通', manufacturer: 'XX交通设备有限公司', spec: '勘验', material: '复合材料', weight: '10kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '交通事故现场勘验箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102001', code: '2102001', name: '紫外现场勘查观察系统', category: '辅助观测', variety: '辅助观测', model: 'ZW-001', modelCode: '011', unit: '套', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '紫外观察', material: '精密光学', weight: '3kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '紫外现场勘查观察系统。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102002', code: '2102002', name: '现场勘验灯', category: '辅助观测', variety: '辅助观测', model: 'KY-002', modelCode: '012', unit: '盏', brand: 'XX照明', manufacturer: 'XX照明科技有限公司', spec: '勘验照明', material: 'LED', weight: '1kg', warranty: 2, hasBattery: '是', maintenanceMonths: 12, description: '现场勘验灯。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102003', code: '2102003', name: '扁平光查灯', category: '辅助观测', variety: '辅助观测', model: 'PC-003', modelCode: '013', unit: '盏', brand: 'XX照明', manufacturer: 'XX照明科技有限公司', spec: '扁平光', material: 'LED', weight: '0.8kg', warranty: 2, hasBattery: '是', maintenanceMonths: 12, description: '扁平光查灯。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102004', code: '2102004', name: '碘钨灯', category: '辅助观测', variety: '辅助观测', model: 'DW-004', modelCode: '014', unit: '盏', brand: 'XX照明', manufacturer: 'XX照明科技有限公司', spec: '强光照明', material: '钨丝', weight: '2kg', warranty: 1, hasBattery: '否', maintenanceMonths: 6, description: '碘钨灯。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102005', code: '2102005', name: '足迹搜索专用灯', category: '辅助观测', variety: '辅助观测', model: 'ZJ-005', modelCode: '015', unit: '盏', brand: 'XX照明', manufacturer: 'XX照明科技有限公司', spec: '足迹搜索', material: 'LED', weight: '1.5kg', warranty: 2, hasBattery: '是', maintenanceMonths: 6, description: '足迹搜索专用灯。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102006', code: '2102006', name: '多波段光源', category: '辅助观测', variety: '辅助观测', model: 'DB-006', modelCode: '016', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '多波段', material: '精密光学', weight: '4kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '多波段光源。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102007', code: '2102007', name: '大功率宽幅测光源', category: '辅助观测', variety: '辅助观测', model: 'DG-007', modelCode: '017', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '大功率宽幅', material: '精密光学', weight: '6kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '大功率宽幅测光源。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102008', code: '2102008', name: '偏振光源', category: '辅助观测', variety: '辅助观测', model: 'PZ-008', modelCode: '018', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '偏振光', material: '精密光学', weight: '2kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '偏振光源。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2102009', code: '2102009', name: '红外线光源', category: '辅助观测', variety: '辅助观测', model: 'HW-009', modelCode: '019', unit: '台', brand: 'XX光学', manufacturer: 'XX光学仪器有限公司', spec: '红外线', material: '精密光学', weight: '2.5kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '红外线光源。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103001', code: '2103001', name: '血痕发现仪', category: '发现提取', variety: '发现提取', model: 'XF-001', modelCode: '020', unit: '台', brand: 'XX生物', manufacturer: 'XX生物科技有限公司', spec: '血痕发现', material: '精密光学', weight: '1.5kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '血痕发现仪。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103002', code: '2103002', name: '生物物证发现仪', category: '发现提取', variety: '发现提取', model: 'SW-002', modelCode: '021', unit: '台', brand: 'XX生物', manufacturer: 'XX生物科技有限公司', spec: '生物物证发现', material: '精密光学', weight: '2kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '生物物证发现仪。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103003', code: '2103003', name: '气味提取仪', category: '发现提取', variety: '发现提取', model: 'QT-003', modelCode: '022', unit: '台', brand: 'XX生物', manufacturer: 'XX生物科技有限公司', spec: '气味提取', material: '精密仪器', weight: '1kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '气味提取仪。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103004', code: '2103004', name: '语音信号采集仪', category: '发现提取', variety: '发现提取', model: 'YY-004', modelCode: '023', unit: '台', brand: 'XX电子', manufacturer: 'XX电子科技有限公司', spec: '语音采集', material: '电子设备', weight: '0.5kg', warranty: 2, hasBattery: '是', maintenanceMonths: 12, description: '语音信号采集仪。', images: [], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103005', code: '2103005', name: '立体足迹提取箱', category: '发现提取', variety: '发现提取', model: 'LT-005', modelCode: '024', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '立体足迹提取', material: '复合材料', weight: '5kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '立体足迹提取箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103006', code: '2103006', name: '立体痕迹提取箱', category: '发现提取', variety: '发现提取', model: 'LH-006', modelCode: '025', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '立体痕迹提取', material: '复合材料', weight: '5kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '立体痕迹提取箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103007', code: '2103007', name: '轮胎痕迹提取箱', category: '发现提取', variety: '发现提取', model: 'LT-007', modelCode: '026', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '轮胎痕迹提取', material: '复合材料', weight: '6kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '轮胎痕迹提取箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103008', code: '2103008', name: '现场痕迹勘查箱', category: '发现提取', variety: '发现提取', model: 'XC-008', modelCode: '027', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '痕迹勘查', material: '复合材料', weight: '8kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '现场痕迹勘查箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103009', code: '2103009', name: '现场勘查附件箱', category: '发现提取', variety: '发现提取', model: 'FJ-009', modelCode: '028', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '勘查附件', material: '复合材料', weight: '4kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '现场勘查附件箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103010', code: '2103010', name: '现场生物物证勘查提取箱', category: '发现提取', variety: '发现提取', model: 'SW-010', modelCode: '029', unit: '个', brand: 'XX生物', manufacturer: 'XX生物科技有限公司', spec: '生物物证勘查提取', material: '复合材料', weight: '7kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '现场生物物证勘查提取箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103011', code: '2103011', name: '微量物证提取箱', category: '发现提取', variety: '发现提取', model: 'WL-011', modelCode: '030', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '微量物证提取', material: '复合材料', weight: '5kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '微量物证提取箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103012', code: '2103012', name: '标准化物证包装器具箱', category: '发现提取', variety: '发现提取', model: 'BZ-012', modelCode: '031', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '标准化包装', material: '复合材料', weight: '4kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '标准化物证包装器具箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103013', code: '2103013', name: '文检查箱', category: '发现提取', variety: '发现提取', model: 'WJ-013', modelCode: '032', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '文检', material: '复合材料', weight: '6kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '文检查箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103014', code: '2103014', name: '爆炸纵火现场查箱', category: '发现提取', variety: '发现提取', model: 'BZ-014', modelCode: '033', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '爆炸纵火勘查', material: '防爆材料', weight: '10kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '爆炸纵火现场查箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103015', code: '2103015', name: '毒品勘查箱', category: '发现提取', variety: '发现提取', model: 'DP-015', modelCode: '034', unit: '个', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '毒品勘查', material: '复合材料', weight: '5kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '毒品勘查箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103016', code: '2103016', name: '电子物证现场取证勘查箱', category: '发现提取', variety: '发现提取', model: 'DZ-016', modelCode: '035', unit: '个', brand: 'XX电子', manufacturer: 'XX电子科技有限公司', spec: '电子物证取证', material: '电子设备', weight: '8kg', warranty: 3, hasBattery: '是', maintenanceMonths: 6, description: '电子物证现场取证勘查箱。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2103017', code: '2103017', name: '射击残留物提取工具包', category: '发现提取', variety: '发现提取', model: 'SJ-017', modelCode: '036', unit: '套', brand: 'XX科技', manufacturer: 'XX科技有限公司', spec: '射击残留物提取', material: '复合材料', weight: '2kg', warranty: 3, hasBattery: '否', maintenanceMonths: 6, description: '射击残留物提取工具包。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2201001', code: '2201001', name: '搜索犬', category: '警犬', variety: '警犬', model: 'SS-001', modelCode: '037', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '搜索型', material: '活体', weight: '30kg', warranty: 5, hasBattery: '否', maintenanceMonths: 3, description: '经过专业训练的搜索犬。', images: ['照片'], videos: [], docs: ['训练档案.pdf'], status: '启用' },
  { id: 'e2201002', code: '2201002', name: '防暴犬', category: '警犬', variety: '警犬', model: 'FB-002', modelCode: '038', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '防暴型', material: '活体', weight: '35kg', warranty: 5, hasBattery: '否', maintenanceMonths: 3, description: '经过专业训练的防暴犬。', images: ['照片'], videos: [], docs: ['训练档案.pdf'], status: '启用' },
  { id: 'e2201003', code: '2201003', name: '追踪犬', category: '警犬', variety: '警犬', model: 'ZZ-003', modelCode: '039', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '追踪型', material: '活体', weight: '30kg', warranty: 5, hasBattery: '否', maintenanceMonths: 3, description: '经过专业训练的追踪犬。', images: ['照片'], videos: [], docs: ['训练档案.pdf'], status: '启用' },
  { id: 'e2201004', code: '2201004', name: '鉴别犬', category: '警犬', variety: '警犬', model: 'JB-004', modelCode: '040', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '鉴别型', material: '活体', weight: '25kg', warranty: 5, hasBattery: '否', maintenanceMonths: 3, description: '经过专业训练的鉴别犬。', images: ['照片'], videos: [], docs: ['训练档案.pdf'], status: '启用' },
  { id: 'e2201005', code: '2201005', name: '治安巡逻犬', category: '警犬', variety: '警犬', model: 'XL-005', modelCode: '041', unit: '头', brand: '繁育基地', manufacturer: '公安部警犬繁育基地', spec: '巡逻型', material: '活体', weight: '30kg', warranty: 5, hasBattery: '否', maintenanceMonths: 3, description: '经过专业训练的治安巡逻犬。', images: ['照片'], videos: [], docs: ['训练档案.pdf'], status: '启用' },
  { id: 'e2202001', code: '2202001', name: '带犬民警装备', category: '配套保障', variety: '配套保障', model: 'DK-001', modelCode: '042', unit: '套', brand: 'XX装备', manufacturer: 'XX装备有限公司', spec: '带犬民警专用', material: '复合材料', weight: '5kg', warranty: 2, hasBattery: '否', maintenanceMonths: 12, description: '带犬民警装备。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2202002', code: '2202002', name: '警犬训练装备', category: '配套保障', variety: '配套保障', model: 'XL-002', modelCode: '043', unit: '套', brand: 'XX装备', manufacturer: 'XX装备有限公司', spec: '警犬训练', material: '复合材料', weight: '10kg', warranty: 2, hasBattery: '否', maintenanceMonths: 12, description: '警犬训练装备。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2301001', code: '2301001', name: '物证保全管理系统', category: '管理系统', variety: '管理系统', model: 'WZ-001', modelCode: '044', unit: '套', brand: 'XX软件', manufacturer: 'XX软件开发有限公司', spec: '物证保全管理', material: '软件', weight: '0kg', warranty: 3, hasBattery: '否', maintenanceMonths: 3, description: '物证保全管理系统软件。', images: ['界面图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2302001', code: '2302001', name: '物证存放架', category: '存放容器', variety: '存放容器', model: 'CF-001', modelCode: '045', unit: '组', brand: 'XX设备', manufacturer: 'XX设备有限公司', spec: '物证存放', material: '钢材', weight: '50kg', warranty: 5, hasBattery: '否', maintenanceMonths: 12, description: '物证存放架。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
  { id: 'e2302002', code: '2302002', name: '密集柜', category: '存放容器', variety: '存放容器', model: 'MJ-002', modelCode: '046', unit: '组', brand: 'XX设备', manufacturer: 'XX设备有限公司', spec: '密集存储', material: '钢材', weight: '80kg', warranty: 5, hasBattery: '否', maintenanceMonths: 12, description: '密集柜。', images: ['外观图'], videos: [], docs: ['说明书.pdf'], status: '启用' },
]

// Recursively find a node by id in the nested category tree
function findNodeInTree(nodes: CategoryNode[], id: string): CategoryNode | null {
  for (const n of nodes) {
    if (n.id === id) return n
    if (n.children) {
      const found = findNodeInTree(n.children, id)
      if (found) return found
    }
  }
  return null
}

function getCategoryFilterIds(catId: string): string[] {
  if (catId === 'all') return equipmentList.map(e => e.id)
  const node = findNodeInTree(categoryTree, catId)
  if (!node) return []
  // Collect all leaf node names under the selected node
  const collect = (n: CategoryNode): string[] => {
    const names: string[] = []
    if (!n.children || n.children.length === 0) {
      names.push(n.name)
    } else {
      n.children.forEach(c => names.push(...collect(c)))
    }
    return names
  }
  const allNames = collect(node)
  // Filter equipment: match if equipment.category equals any collected leaf name
  // or equipment.variety equals any collected leaf name (for backward compatibility)
  return equipmentList.filter(e => allNames.some(name => e.category === name || e.variety === name)).map(e => e.id)
}

// ─── Tree Node ───
function TreeNode({
  node, selectedId, onSelect, expandedIds, onToggleExpand,
}: {
  node: CategoryNode
  selectedId: string | null
  onSelect: (id: string) => void
  expandedIds: Set<string>
  onToggleExpand: (id: string) => void
}) {
  const isExpanded = expandedIds.has(node.id)
  const hasChildren = node.children && node.children.length > 0
  const levelLabels = ['一级', '二级', '三级']
  return (
    <div>
      <div
        className={cn(
          'flex cursor-pointer items-center gap-1 rounded-md px-2 py-1.5 text-sm transition',
          selectedId === node.id ? 'bg-[#E8F0FE] text-[#1A56DB]' : 'text-[#374151] hover:bg-[#F3F4F6]'
        )}
        style={{ paddingLeft: `${8 + node.level * 16}px` }}
        onClick={() => {
          onSelect(node.id)
          if (hasChildren) onToggleExpand(node.id)
        }}
      >
        {hasChildren
          ? (isExpanded ? <ChevronDown size={14} className="text-[#6B7280]" /> : <ChevronRight size={14} className="text-[#6B7280]" />)
          : <span className="w-3.5" />
        }
        <span className="mr-1 rounded bg-[#F3F4F6] px-1 text-[10px] text-[#6B7280]">{levelLabels[node.level] || ''}</span>
        <span className="truncate">{node.name}</span>
      </div>
      {hasChildren && isExpanded && (
        <div>
          {node.children!.map((child) => (
            <TreeNode key={child.id} node={child} selectedId={selectedId} onSelect={onSelect} expandedIds={expandedIds} onToggleExpand={onToggleExpand} />
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Image Tab with Upload ───
function EquipmentImageTab({ equipment }: { equipment: Equipment }) {
  const [images, setImages] = useState<{ name: string; url: string }[]>(
    equipment.images.map((name) => ({ name, url: '' }))
  )

  const handleUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        setImages((prev) => [...prev, { name: file.name, url: ev.target?.result as string }])
      }
      reader.readAsDataURL(file)
    })
    e.target.value = ''
  }

  const handleRemove = (idx: number) => {
    setImages((prev) => prev.filter((_, i) => i !== idx))
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-base font-semibold text-[#1F2937]">
          <Image size={18} className="text-[#1A56DB]" />图片附件 ({images.length})
        </h3>
        <label className="inline-flex h-8 cursor-pointer items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white transition hover:bg-[#153E7E]">
          <Upload size={13} /> 上传图片
          <input type="file" accept="image/*" multiple className="hidden" onChange={handleUpload} />
        </label>
      </div>
      {images.length > 0 ? (
        <div className="grid grid-cols-3 gap-4">
          {images.map((img, idx) => (
            <div key={idx} className="group relative aspect-square overflow-hidden rounded-lg border border-[#E5E7EB] bg-[#F3F4F6]">
              {img.url ? (
                <img src={img.url} alt={img.name} className="h-full w-full object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center text-[#9CA3AF]"><Image size={32} /></div>
              )}
              <div className="absolute inset-x-0 bottom-0 bg-black/50 p-2">
                <p className="truncate text-xs text-white">{img.name}</p>
              </div>
              <button
                onClick={() => handleRemove(idx)}
                className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition hover:bg-[#DC2626] group-hover:opacity-100"
                title="删除"
              >
                <X size={14} />
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无图片附件</div>
      )}
    </div>
  )
}

// ─── Pending Equipment Panel ───
function PendingEquipmentPanel() {
  const [items, setItems] = useState<PendingEquipment[]>(pendingEquipmentList)
  const [filterStatus, setFilterStatus] = useState<string>('')
  const [searchText, setSearchText] = useState('')
  const [showApproveModal, setShowApproveModal] = useState(false)
  const [showRejectModal, setShowRejectModal] = useState(false)
  const [showTransferModal, setShowTransferModal] = useState(false)
  const [showDetailModal, setShowDetailModal] = useState(false)
  const [selectedItem, setSelectedItem] = useState<PendingEquipment | null>(null)
  const [editForm, setEditForm] = useState<EditingForm>({
    code: '', name: '', categoryL3: '', model: '', modelCode: '',
    unit: '', brand: '', manufacturer: '', spec: '', auditRemark: ''
  })
  const [rejectReason, setRejectReason] = useState('')
  const [transferTarget, setTransferTarget] = useState('')
  const [currentPage, setCurrentPage] = useState(1)

  const statusOptions = ['待审核', '已通过', '已驳回', '转审中']

  let filtered = items
  if (filterStatus) filtered = filtered.filter((p) => p.status === filterStatus)
  if (searchText.trim()) {
    const s = searchText.toLowerCase()
    filtered = filtered.filter((p) => p.code.toLowerCase().includes(s) || p.name.toLowerCase().includes(s) || p.submitCompany.toLowerCase().includes(s))
  }

  const pageSize = 10
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safePage = Math.min(currentPage, totalPages)
  const paginated = filtered.slice((safePage - 1) * pageSize, safePage * pageSize)

  const openApprove = (item: PendingEquipment) => {
    setSelectedItem(item)
    setEditForm({ code: item.code, name: item.name, categoryL3: item.categoryL3, model: item.model, modelCode: item.modelCode, unit: item.unit, brand: item.brand, manufacturer: item.manufacturer, spec: item.spec, auditRemark: '' })
    setShowApproveModal(true)
  }
  const handleApprove = () => {
    if (!selectedItem) return
    setItems((prev) => prev.map((p) => (p.id === selectedItem.id ? { ...p, status: '已通过' as PendingStatus, auditUnit: '省公安厅警保部', code: editForm.code, name: editForm.name, categoryL3: editForm.categoryL3, model: editForm.model, modelCode: editForm.modelCode, unit: editForm.unit, brand: editForm.brand, manufacturer: editForm.manufacturer, spec: editForm.spec } : p)))
    setShowApproveModal(false); setSelectedItem(null)
  }

  const openReject = (item: PendingEquipment) => {
    setSelectedItem(item)
    setEditForm({ code: item.code, name: item.name, categoryL3: item.categoryL3, model: item.model, modelCode: item.modelCode, unit: item.unit, brand: item.brand, manufacturer: item.manufacturer, spec: item.spec, auditRemark: '' })
    setRejectReason('')
    setShowRejectModal(true)
  }
  const handleReject = () => {
    if (!rejectReason.trim()) { alert('请输入驳回原因'); return }
    if (!selectedItem) return
    setItems((prev) => prev.map((p) => (p.id === selectedItem.id ? { ...p, status: '已驳回' as PendingStatus, rejectReason: rejectReason, auditUnit: '省公安厅警保部', code: editForm.code, name: editForm.name, categoryL3: editForm.categoryL3, model: editForm.model, modelCode: editForm.modelCode, unit: editForm.unit, brand: editForm.brand, manufacturer: editForm.manufacturer, spec: editForm.spec } : p)))
    setShowRejectModal(false); setSelectedItem(null)
  }

  const openTransfer = (item: PendingEquipment) => { setSelectedItem(item); setTransferTarget(''); setShowTransferModal(true) }
  const handleTransfer = () => {
    if (!transferTarget.trim()) { alert('请选择转审目标单位'); return }
    if (!selectedItem) return
    setItems((prev) => prev.map((p) => (p.id === selectedItem.id ? { ...p, status: '转审中' as PendingStatus, transferTo: transferTarget, auditUnit: '省公安厅警保部' } : p)))
    setShowTransferModal(false); setSelectedItem(null)
  }

  const openDetail = (item: PendingEquipment) => { setSelectedItem(item); setShowDetailModal(true) }

  const statusBadge = (s: PendingStatus, unit?: string) => {
    const map: Record<string, { bg: string; text: string }> = {
      '待审核': { bg: 'bg-[#FEF3C7]', text: 'text-[#D97706]' },
      '已通过': { bg: 'bg-[#D1FAE5]', text: 'text-[#10B981]' },
      '已驳回': { bg: 'bg-[#FEE2E2]', text: 'text-[#EF4444]' },
      '转审中': { bg: 'bg-[#E0E7FF]', text: 'text-[#8B5CF6]' },
    }
    const st = map[s] || map['待审核']
    return (
      <div className="flex flex-col">
        <span className={cn('inline-flex w-fit rounded px-2 py-0.5 text-[11px] font-medium', st.bg, st.text)}>{s}</span>
        {unit && <span className="mt-0.5 text-[10px] text-[#6B7280]">{unit}</span>}
      </div>
    )
  }

  // 三级联动分类数据
  const catTree = [
    { name: '刑事技术装备', children: [
      { name: '现场勘查装备', children: [
        { name: '现场检测' }, { name: '辅助观测' }, { name: '发现提取' }
      ]},
      { name: '警犬装备', children: [
        { name: '警犬' }, { name: '配套保障' }
      ]},
      { name: '物证保全装备', children: [
        { name: '管理系统' }, { name: '存放容器' }
      ]},
    ]},
  ]
  const [selL1, setSelL1] = useState(selectedItem?.categoryL1 || '刑事技术装备')
  const [selL2, setSelL2] = useState(selectedItem?.categoryL2 || '')
  const l2Options = catTree.find(c => c.name === selL1)?.children || []
  const l3Options = l2Options.find(c => c.name === selL2)?.children || []

  const renderEditForm = () => (
    <div className="mb-4 grid grid-cols-2 gap-3">
      <div><label className="mb-1 block text-xs text-[#374151]">装备编码</label><input type="text" value={editForm.code} onChange={(e) => setEditForm({...editForm, code: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">装备名称</label><input type="text" value={editForm.name} onChange={(e) => setEditForm({...editForm, name: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div className="col-span-2">
        <label className="mb-1 block text-xs text-[#374151]">装备分类（三级联动）</label>
        <div className="grid grid-cols-3 gap-2">
          <select value={selL1} onChange={(e) => { setSelL1(e.target.value); setSelL2('') }} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]">
            {catTree.map(c => (<option key={c.name} value={c.name}>{c.name}</option>))}
          </select>
          <select value={selL2} onChange={(e) => setSelL2(e.target.value)} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]">
            <option value="">请选择二级分类</option>
            {l2Options.map(c => (<option key={c.name} value={c.name}>{c.name}</option>))}
          </select>
          <select value={editForm.categoryL3} onChange={(e) => setEditForm({...editForm, categoryL3: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]">
            <option value="">请选择三级分类</option>
            {l3Options.map(c => (<option key={c.name} value={c.name}>{c.name}</option>))}
          </select>
        </div>
      </div>
      <div><label className="mb-1 block text-xs text-[#374151]">型号</label><input type="text" value={editForm.model} onChange={(e) => setEditForm({...editForm, model: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">型号编码</label><input type="text" value={editForm.modelCode} onChange={(e) => setEditForm({...editForm, modelCode: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">计量单位</label><input type="text" value={editForm.unit} onChange={(e) => setEditForm({...editForm, unit: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">品牌</label><input type="text" value={editForm.brand} onChange={(e) => setEditForm({...editForm, brand: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">制造商</label><input type="text" value={editForm.manufacturer} onChange={(e) => setEditForm({...editForm, manufacturer: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
      <div><label className="mb-1 block text-xs text-[#374151]">规格</label><input type="text" value={editForm.spec} onChange={(e) => setEditForm({...editForm, spec: e.target.value})} className="h-8 w-full rounded-md border border-[#D1D5DB] px-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
    </div>
  )

  return (
    <div className="p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <select value={filterStatus} onChange={(e) => { setFilterStatus(e.target.value); setCurrentPage(1) }} className="h-8 rounded-md border border-[#D1D5DB] px-2 text-xs text-[#374151] outline-none">
            <option value="">全部状态</option>
            {statusOptions.map((s) => (<option key={s} value={s}>{s}</option>))}
          </select>
          <div className="flex items-center gap-1 rounded-md border border-[#D1D5DB] px-2 py-1">
            <Search size={12} className="text-[#9CA3AF]" />
            <input type="text" placeholder="搜索编码/名称/提交公司..." value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }} className="w-40 bg-transparent text-xs outline-none" />
          </div>
        </div>
        <span className="text-xs text-[#6B7280]">共 {filtered.length} 条</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">序号</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">装备编码</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">装备名称</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">装备分类</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">型号</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">提交公司</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">提交时间</th>
              <th className="px-3 py-2.5 text-left text-xs font-semibold text-[#6B7280]">状态</th>
              <th className="px-3 py-2.5 text-center text-xs font-semibold text-[#6B7280]">操作</th>
            </tr>
          </thead>
          <tbody>
            {paginated.map((p, idx) => (
              <tr key={p.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                <td className="px-3 py-2.5 text-[#6B7280]">{(safePage - 1) * pageSize + idx + 1}</td>
                <td className="px-3 py-2.5 font-mono text-xs text-[#1A56DB]">{p.code}</td>
                <td className="px-3 py-2.5 font-medium text-[#374151]">{p.name}</td>
                <td className="px-3 py-2.5">
                  <span className="rounded bg-[#FEF3C7] px-2 py-0.5 text-[11px] font-medium text-[#D97706]">{p.categoryL3}</span>
                </td>
                <td className="px-3 py-2.5 text-[#374151]">{p.model}</td>
                <td className="px-3 py-2.5 text-[#1A56DB]">{p.submitCompany}</td>
                <td className="px-3 py-2.5 text-xs text-[#6B7280]">{p.submitTime}</td>
                <td className="px-3 py-2.5">{statusBadge(p.status, p.auditUnit)}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center justify-center gap-1">
                    <button onClick={() => openDetail(p)} className="rounded p-1 text-[#3B82F6] transition hover:bg-[#DBEAFE]" title="查看"><Eye size={14} /></button>
                    {p.status === '待审核' && (
                      <>
                        <button onClick={() => openApprove(p)} className="rounded bg-[#10B981] px-2 py-1 text-[11px] text-white transition hover:bg-[#059669]">通过</button>
                        <button onClick={() => openReject(p)} className="rounded bg-[#EF4444] px-2 py-1 text-[11px] text-white transition hover:bg-[#DC2626]">驳回</button>
                        <button onClick={() => openTransfer(p)} className="rounded bg-[#8B5CF6] px-2 py-1 text-[11px] text-white transition hover:bg-[#7C3AED]">转审</button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {paginated.length === 0 && <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无待审核商品</div>}
      </div>

      {filtered.length > 0 && (
        <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-2.5">
          <span className="text-xs text-[#6B7280]">显示 {(safePage - 1) * pageSize + 1}-{Math.min(safePage * pageSize, filtered.length)} / 共 {filtered.length} 条</span>
          <div className="flex items-center gap-1">
            <button onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={safePage <= 1} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">上一页</button>
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
              <button key={p} onClick={() => setCurrentPage(p)} className={cn('h-7 w-7 rounded-md text-xs font-medium transition', safePage === p ? 'bg-[#1A56DB] text-white' : 'text-[#6B7280] hover:bg-[#F3F4F6]')}>{p}</button>
            ))}
            <button onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))} disabled={safePage >= totalPages} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">下一页</button>
          </div>
        </div>
      )}

      {showApproveModal && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowApproveModal(false)} />
          <div className="relative z-10 w-[600px] max-h-[90vh] overflow-auto rounded-xl bg-white p-6 shadow-2xl">
            <h3 className="mb-4 text-base font-semibold text-[#1F2937]">审核通过确认</h3>
            <div className="mb-4 rounded-lg bg-[#F0FDF4] p-3"><p className="text-sm text-[#166534]">确认通过该装备审核？审核通过后装备将纳入装备分类管理库。</p></div>
            <h4 className="mb-2 text-sm font-medium text-[#374151]">装备信息（可编辑）：</h4>
            {renderEditForm()}
            <div><label className="mb-1 block text-xs text-[#374151]">审核意见</label><textarea rows={2} value={editForm.auditRemark} onChange={(e) => setEditForm({...editForm, auditRemark: e.target.value})} placeholder="请输入审核意见..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" /></div>
            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setShowApproveModal(false)} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6]">取消</button>
              <button onClick={handleApprove} className="h-8 rounded-md bg-[#10B981] px-4 text-sm text-white transition hover:bg-[#059669]">确认通过</button>
            </div>
          </div>
        </div>
      )}

      {showRejectModal && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowRejectModal(false)} />
          <div className="relative z-10 w-[600px] max-h-[90vh] overflow-auto rounded-xl bg-white p-6 shadow-2xl">
            <h3 className="mb-4 text-base font-semibold text-[#1F2937]">驳回审核</h3>
            <h4 className="mb-2 text-sm font-medium text-[#374151]">装备信息（可编辑）：</h4>
            {renderEditForm()}
            <div className="mb-4">
              <label className="mb-1.5 block text-sm text-[#374151]">驳回原因 <span className="text-[#EF4444]">*</span></label>
              <textarea rows={3} value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="请输入驳回原因..." className="w-full rounded-md border border-[#D1D5DB] px-3 py-2 text-sm outline-none focus:border-[#1A56DB]" />
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowRejectModal(false)} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6]">取消</button>
              <button onClick={handleReject} className="h-8 rounded-md bg-[#EF4444] px-4 text-sm text-white transition hover:bg-[#DC2626]">确认驳回</button>
            </div>
          </div>
        </div>
      )}

      {showTransferModal && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowTransferModal(false)} />
          <div className="relative z-10 w-[480px] rounded-xl bg-white p-6 shadow-2xl">
            <h3 className="mb-4 text-base font-semibold text-[#1F2937]">转审给其他单位</h3>
            <div className="mb-4 rounded-lg bg-[#E0E7FF] p-3">
              <p className="text-sm text-[#4338CA]">装备：<span className="font-medium">{selectedItem.name}</span></p>
              <p className="text-xs text-[#6B7280]">编码：{selectedItem.code}</p>
            </div>
            <div className="mb-4">
              <label className="mb-1.5 block text-sm text-[#374151]">选择目标单位 <span className="text-[#EF4444]">*</span></label>
              <select value={transferTarget} onChange={(e) => setTransferTarget(e.target.value)} className="h-9 w-full rounded-md border border-[#D1D5DB] px-3 text-sm outline-none focus:border-[#1A56DB]">
                <option value="">请选择目标单位</option>
                <option value="省公安厅警保部">省公安厅警保部</option>
                <option value="市公安局装备处">市公安局装备处</option>
                <option value="装备标准化委员会">装备标准化委员会</option>
                <option value="采购管理中心">采购管理中心</option>
              </select>
            </div>
            <div className="flex justify-end gap-2">
              <button onClick={() => setShowTransferModal(false)} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6]">取消</button>
              <button onClick={handleTransfer} className="h-8 rounded-md bg-[#8B5CF6] px-4 text-sm text-white transition hover:bg-[#7C3AED]">确认转审</button>
            </div>
          </div>
        </div>
      )}

      {showDetailModal && selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowDetailModal(false)} />
          <div className="relative z-10 w-[600px] max-h-[90vh] overflow-auto rounded-xl bg-white p-6 shadow-2xl">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="text-base font-semibold text-[#1F2937]">待审核商品详情</h3>
              <button onClick={() => setShowDetailModal(false)} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6]"><X size={18} /></button>
            </div>
            <div className="mb-4">{statusBadge(selectedItem.status, selectedItem.auditUnit)}</div>
            <div className="mb-4 grid grid-cols-2 gap-3 rounded-lg bg-[#F9FAFB] p-4">
              <div><label className="text-xs text-[#6B7280]">装备编码</label><p className="text-sm font-medium text-[#1F2937]">{selectedItem.code}</p></div>
              <div><label className="text-xs text-[#6B7280]">装备名称</label><p className="text-sm font-medium text-[#1F2937]">{selectedItem.name}</p></div>
              <div><label className="text-xs text-[#6B7280]">一级分类</label><p className="text-sm text-[#374151]">{selectedItem.categoryL1}</p></div>
              <div><label className="text-xs text-[#6B7280]">二级分类</label><p className="text-sm text-[#374151]">{selectedItem.categoryL2}</p></div>
              <div><label className="text-xs text-[#6B7280]">三级分类</label><p className="text-sm text-[#374151]">{selectedItem.categoryL3}</p></div>
              <div><label className="text-xs text-[#6B7280]">型号</label><p className="text-sm text-[#374151]">{selectedItem.model}</p></div>
              <div><label className="text-xs text-[#6B7280]">型号编码</label><p className="text-sm font-mono text-[#6B7280]">{selectedItem.modelCode}</p></div>
              <div><label className="text-xs text-[#6B7280]">计量单位</label><p className="text-sm text-[#374151]">{selectedItem.unit}</p></div>
              <div><label className="text-xs text-[#6B7280]">品牌</label><p className="text-sm text-[#374151]">{selectedItem.brand}</p></div>
              <div><label className="text-xs text-[#6B7280]">制造商</label><p className="text-sm text-[#374151]">{selectedItem.manufacturer}</p></div>
              <div><label className="text-xs text-[#6B7280]">规格</label><p className="text-sm text-[#374151]">{selectedItem.spec}</p></div>
              <div><label className="text-xs text-[#6B7280]">提交公司</label><p className="text-sm text-[#1A56DB]">{selectedItem.submitCompany}</p></div>
              <div><label className="text-xs text-[#6B7280]">提交人</label><p className="text-sm text-[#374151]">{selectedItem.submitter}</p></div>
              <div><label className="text-xs text-[#6B7280]">提交时间</label><p className="text-sm text-[#6B7280]">{selectedItem.submitTime}</p></div>
            </div>
            <div className="mb-4">
              <label className="text-xs text-[#6B7280]">备注</label>
              <p className="mt-1 rounded-md border border-[#E5E7EB] bg-[#F9FAFB] p-3 text-sm text-[#374151]">{selectedItem.remark}</p>
            </div>
            {selectedItem.rejectReason && (
              <div className="mb-4">
                <label className="text-xs text-[#EF4444]">驳回原因</label>
                <p className="mt-1 rounded-md border border-[#FECACA] bg-[#FEF2F2] p-3 text-sm text-[#EF4444]">{selectedItem.rejectReason}</p>
              </div>
            )}
            {selectedItem.transferTo && (
              <div className="mb-4">
                <label className="text-xs text-[#8B5CF6]">转审目标</label>
                <p className="mt-1 rounded-md border border-[#C7D2FE] bg-[#E0E7FF] p-3 text-sm text-[#8B5CF6]">{selectedItem.transferTo}</p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Detail Drawer ───
function EquipmentDetailDrawer({ equipment, onClose }: { equipment: Equipment | null; onClose: () => void }) {
  const [activeTab, setActiveTab] = useState<DetailTab>('basic')
  if (!equipment) return null
  const tabs: { key: DetailTab; label: string }[] = [
    { key: 'basic', label: '基础信息' },
    { key: 'images', label: '图片附件' },
    { key: 'videos', label: '视频资料' },
    { key: 'docs', label: '文档资料' },
  ]
  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="absolute inset-0 bg-black/40" onClick={onClose} />
      <div className="relative z-10 flex h-full w-[720px] max-w-[95vw] flex-col bg-white shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-6 py-4">
          <div>
            <h2 className="text-lg font-semibold text-[#1F2937]">{equipment.name}</h2>
            <p className="text-xs text-[#6B7280]">{equipment.code} · {equipment.modelCode}</p>
          </div>
          <button onClick={onClose} className="flex h-8 w-8 items-center justify-center rounded-md text-[#6B7280] hover:bg-[#F3F4F6] hover:text-[#EF4444]"><X size={18} /></button>
        </div>
        {/* Stats */}
        <div className="grid grid-cols-4 gap-3 border-b border-[#E5E7EB] bg-[#F9FAFB] px-6 py-3">
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">装备编码</div>
            <div className="mt-1 text-sm font-semibold text-[#1A56DB] truncate">{equipment.code}</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">是否电池</div>
            <div className="mt-1 text-sm font-semibold text-[#374151]">{equipment.hasBattery === '是'
              ? <span className="flex items-center gap-1 text-[#D97706]"><BatteryMedium size={14} />是</span>
              : <span className="flex items-center gap-1 text-[#6B7280]"><Battery size={14} />否</span>
            }</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">保养周期</div>
            <div className="mt-1 text-sm font-semibold text-[#374151]">{equipment.maintenanceMonths} 个月</div>
          </div>
          <div className="rounded-lg bg-white p-3 shadow-sm">
            <div className="text-xs text-[#6B7280]">状态</div>
            <div className="mt-1"><Badge variant={equipment.status === '启用' ? 'success' : 'default'}>{equipment.status}</Badge></div>
          </div>
        </div>
        {/* Tabs */}
        <div className="flex shrink-0 gap-0 border-b border-[#E5E7EB] bg-white px-6">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={cn(
                'px-4 py-3 text-sm font-medium transition border-b-2',
                activeTab === tab.key ? 'border-[#1A56DB] text-[#1A56DB]' : 'border-transparent text-[#6B7280] hover:text-[#374151]'
              )}
            >
              {tab.label}
            </button>
          ))}
        </div>
        {/* Tab Content */}
        <div className="flex-1 overflow-auto p-6">
          {activeTab === 'basic' && (
            <div className="space-y-6">
              {/* 15 fields in 3-col grid */}
              <div className="grid grid-cols-3 gap-4">
                <div><label className="mb-1 block text-xs text-[#6B7280]">装备编码</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.code}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">装备名称</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm font-medium text-[#1F2937]">{equipment.name}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">所属分类</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.category}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">品种</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.variety}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">型号</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.model}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">型号编码</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.modelCode}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">计量单位</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.unit}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">品牌</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.brand}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">原厂商</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.manufacturer}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">规格</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.spec}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">材质</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.material}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">重量</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.weight}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">质保期</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.warranty} 年</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">是否电池</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.hasBattery}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">保养周期(月)</label><div className="flex h-9 items-center rounded-md border border-[#E5E7EB] bg-[#F9FAFB] px-3 text-sm text-[#374151]">{equipment.maintenanceMonths}</div></div>
                <div><label className="mb-1 block text-xs text-[#6B7280]">状态</label><div className="flex h-9 items-center"><Badge variant={equipment.status === '启用' ? 'success' : 'default'}>{equipment.status}</Badge></div></div>
              </div>
              <div>
                <label className="mb-1 block text-xs text-[#6B7280]">产品描述</label>
                <div className="rounded-md border border-[#E5E7EB] bg-[#F9FAFB] p-3 text-sm leading-relaxed text-[#374151]">{equipment.description}</div>
              </div>
            </div>
          )}
          {activeTab === 'images' && (
            <EquipmentImageTab equipment={equipment} />
          )}
          {activeTab === 'videos' && (
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-base font-semibold text-[#1F2937]"><Video size={18} className="text-[#EF4444]" />视频资料 ({equipment.videos.length})</h3>
              <div className="grid grid-cols-3 gap-4">
                {equipment.videos.map((vid, idx) => (
                  <div key={idx} className="flex flex-col items-center rounded-lg border border-[#E5E7EB] bg-[#F3F4F6] p-6">
                    <Video size={36} className="mb-3 text-[#EF4444]" />
                    <p className="text-center text-xs text-[#374151]">{vid}</p>
                  </div>
                ))}
              </div>
              {equipment.videos.length === 0 && <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无视频资料</div>}
            </div>
          )}
          {activeTab === 'docs' && (
            <div>
              <h3 className="mb-4 flex items-center gap-2 text-base font-semibold text-[#1F2937]"><FileText size={18} className="text-[#10B981]" />文档资料 ({equipment.docs.length})</h3>
              <div className="space-y-2">
                {equipment.docs.map((doc, idx) => (
                  <div key={idx} className="flex items-center justify-between rounded-md border border-[#E5E7EB] px-4 py-3 text-sm text-[#374151] hover:bg-[#F9FAFB]">
                    <div className="flex items-center gap-2"><FileText size={16} className="text-[#10B981]" />{doc}</div>
                    <button className="text-xs text-[#1A56DB] hover:underline">预览</button>
                  </div>
                ))}
              </div>
              {equipment.docs.length === 0 && <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无文档资料</div>}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Add Equipment Modal ───
function AddEquipmentModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [form, setForm] = useState({
    code: '', name: '', category: '防护装备', variety: '', model: '', modelCode: '', manufacturer: '',
    unit: '', brand: '', spec: '', material: '', weight: '', warranty: '',
    hasBattery: '否' as '是' | '否', maintenanceMonths: '', description: '',
  })
  const [uploadedImages, setUploadedImages] = useState<{ name: string; preview: string }[]>([])
  const [errors, setErrors] = useState<Record<string, boolean>>({})
  const fieldMeta: { key: string; label: string; type?: string; placeholder?: string }[] = [
    { key: 'code', label: '装备编码', placeholder: '如：EQ-2024-XXX' },
    { key: 'name', label: '装备名称' },
    { key: 'category', label: '所属分类' },
    { key: 'variety', label: '品种' },
    { key: 'model', label: '型号' },
    { key: 'modelCode', label: '型号编码', placeholder: '如：MOD-XXX-2024' },
    { key: 'unit', label: '计量单位', placeholder: '如：件/台/副' },
    { key: 'brand', label: '品牌' },
    { key: 'manufacturer', label: '原厂商' },
    { key: 'spec', label: '规格' },
    { key: 'material', label: '材质' },
    { key: 'weight', label: '重量', placeholder: '如：4.2kg' },
    { key: 'warranty', label: '质保期(年)', type: 'number' },
    { key: 'maintenanceMonths', label: '保养周期(月)', type: 'number' },
  ]
  const validate = () => {
    const required = ['code', 'name', 'category', 'variety', 'model', 'modelCode', 'unit']
    const errs: Record<string, boolean> = {}
    let ok = true
    required.forEach((k) => {
      if (!form[k as keyof typeof form]?.toString().trim()) {
        errs[k] = true; ok = false
      }
    })
    setErrors(errs)
    return ok
  }
  const handleSubmit = () => {
    if (!validate()) return
    onClose()
  }
  const handleChange = (key: string, val: string) => {
    setForm((prev) => ({ ...prev, [key]: val }))
    if (errors[key]) setErrors((prev) => { const n = { ...prev }; delete n[key]; return n })
  }
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (!files) return
    Array.from(files).forEach((file) => {
      const reader = new FileReader()
      reader.onload = (ev) => {
        setUploadedImages((prev) => [...prev, { name: file.name, preview: ev.target?.result as string }])
      }
      reader.readAsDataURL(file)
    })
    e.target.value = ''
  }
  const handleRemoveImage = (idx: number) => {
    setUploadedImages((prev) => prev.filter((_, i) => i !== idx))
  }
  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) onClose() }}>
      <DialogContent className="max-h-[90vh] overflow-auto sm:max-w-[700px]">
        <DialogHeader>
          <DialogTitle className="text-base font-semibold text-[#1F2937]">新增装备分类管理</DialogTitle>
        </DialogHeader>
        <div className="mt-2 space-y-4">
          <div className="grid grid-cols-3 gap-4">
            {fieldMeta.map((f) => (
              <div key={f.key}>
                <label className="mb-1 block text-xs text-[#374151]">{f.label}{['code','name','category','variety','model','modelCode','unit'].includes(f.key) && <span className="text-[#EF4444]">*</span>}</label>
                <input
                  type={f.type || 'text'}
                  placeholder={f.placeholder || ''}
                  value={form[f.key as keyof typeof form] as string}
                  onChange={(e) => handleChange(f.key, e.target.value)}
                  className={cn(
                    'h-8 w-full rounded-md border px-2.5 text-sm outline-none transition',
                    errors[f.key] ? 'border-[#EF4444] bg-[#FEF2F2]' : 'border-[#D1D5DB] bg-white focus:border-[#1A56DB] focus:ring-1 focus:ring-[#1A56DB]'
                  )}
                />
                {errors[f.key] && <p className="mt-0.5 text-[11px] text-[#EF4444]">必填</p>}
              </div>
            ))}
            <div>
              <label className="mb-1 block text-xs text-[#374151]">是否电池</label>
              <div className="flex h-8 gap-2">
                {(['否', '是'] as const).map((v) => (
                  <button key={v} onClick={() => handleChange('hasBattery', v)} className={cn(
                    'flex-1 rounded-md border text-xs font-medium transition',
                    form.hasBattery === v ? 'border-[#1A56DB] bg-[#E8F0FE] text-[#1A56DB]' : 'border-[#D1D5DB] text-[#6B7280] hover:border-[#9CA3AF]'
                  )}>{v}</button>
                ))}
              </div>
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-[#374151]">产品描述</label>
            <textarea
              rows={3}
              placeholder="请输入装备的功能描述、技术特点等信息..."
              value={form.description}
              onChange={(e) => handleChange('description', e.target.value)}
              className="w-full rounded-md border border-[#D1D5DB] bg-white px-3 py-2 text-sm outline-none transition focus:border-[#1A56DB] focus:ring-1 focus:ring-[#1A56DB]"
            />
          </div>
          {/* 图片上传 */}
          <div>
            <label className="mb-2 block text-xs text-[#374151]">装备图片</label>
            <div className="rounded-lg border border-dashed border-[#D1D5DB] bg-[#F9FAFB] p-4">
              <label className="flex cursor-pointer flex-col items-center justify-center gap-1 rounded-md py-4 transition hover:bg-[#F3F4F6]">
                <Upload size={20} className="text-[#6B7280]" />
                <span className="text-xs text-[#6B7280]">点击上传装备图片</span>
                <span className="text-[10px] text-[#9CA3AF]">支持 JPG、PNG 格式</span>
                <input type="file" accept="image/*" multiple className="hidden" onChange={handleImageUpload} />
              </label>
              {uploadedImages.length > 0 && (
                <div className="mt-3 grid grid-cols-4 gap-2">
                  {uploadedImages.map((img, idx) => (
                    <div key={idx} className="group relative aspect-square overflow-hidden rounded-md border border-[#E5E7EB] bg-white">
                      <img src={img.preview} alt={img.name} className="h-full w-full object-cover" />
                      <button
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute right-0.5 top-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-black/60 text-white opacity-0 transition hover:bg-black/80 group-hover:opacity-100"
                      >
                        <XCircle size={12} />
                      </button>
                      <p className="absolute inset-x-0 bottom-0 truncate bg-black/50 px-1 py-0.5 text-[10px] text-white">{img.name}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button onClick={onClose} className="h-8 rounded-md border border-[#D1D5DB] px-4 text-sm text-[#6B7280] transition hover:bg-[#F3F4F6]">取消</button>
            <button onClick={handleSubmit} className="h-8 rounded-md bg-[#1A56DB] px-4 text-sm text-white transition hover:bg-[#153E7E]">保存</button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

// ─── Main Page ───
export default function EquipmentLibPage() {
  const [selectedCatId, setSelectedCatId] = useState<string>('all')
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set(['c1', 'c2', 'c3', 'c4', 'c5', 'c6']))
  const [searchText, setSearchText] = useState('')
  const [detailEq, setDetailEq] = useState<Equipment | null>(null)
  const [showAdd, setShowAdd] = useState(false)
  const [pageTab, setPageTab] = useState<PageTab>('equipment')

  const toggleExpand = (id: string) => {
    setExpandedIds((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })
  }

  // Filter equipment
  const filtered = equipmentList.filter((eq) => {
    // Category filter
    if (selectedCatId !== 'all') {
      const ids = getCategoryFilterIds(selectedCatId)
      if (!ids.includes(eq.id)) return false
    }
    // Search filter
    if (searchText.trim()) {
      const s = searchText.toLowerCase()
      return eq.code.toLowerCase().includes(s) || eq.name.toLowerCase().includes(s) || eq.model.toLowerCase().includes(s) || eq.brand.toLowerCase().includes(s) || eq.category.toLowerCase().includes(s)
    }
    return true
  })

  // Pagination (simple)
  const pageSize = 10
  const [currentPage, setCurrentPage] = useState(1)
  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize))
  const safePage = Math.min(currentPage, totalPages)
  const paginated = filtered.slice((safePage - 1) * pageSize, safePage * pageSize)

  const sV = (s: string) => s === '启用' ? 'success' : 'default'

  return (
    <div className="flex gap-4" style={{ minHeight: 'calc(100dvh - 200px)' }}>
      {/* Left: Category Tree */}
      <div className="w-56 flex-shrink-0 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        <div className="border-b border-[#E5E7EB] px-3 py-3">
          <h3 className="text-sm font-semibold text-[#1F2937]">装备分类树</h3>
        </div>
        <div className="p-2">
          {categoryTree.map((node) => (
            <TreeNode key={node.id} node={node} selectedId={selectedCatId} onSelect={setSelectedCatId} expandedIds={expandedIds} onToggleExpand={toggleExpand} />
          ))}
        </div>
      </div>

      {/* Right: Equipment List */}
      <div className="min-w-0 flex-1 rounded-lg border border-[#E5E7EB] bg-white shadow-sm">
        {/* Tab Header */}
        <div className="flex items-center justify-between border-b border-[#E5E7EB] px-4 py-3">
          <div className="flex items-center gap-1 rounded-lg bg-[#F3F4F6] p-1">
            <button onClick={() => setPageTab('equipment')} className={cn('rounded-md px-4 py-1.5 text-sm font-medium transition', pageTab === 'equipment' ? 'bg-[#1A56DB] text-white shadow-sm' : 'text-[#6B7280] hover:text-[#374151]')}>装备分类管理</button>
            <button onClick={() => setPageTab('pending')} className={cn('relative rounded-md px-4 py-1.5 text-sm font-medium transition', pageTab === 'pending' ? 'bg-[#1A56DB] text-white shadow-sm' : 'text-[#6B7280] hover:text-[#374151]')}>
              待审核商品
              {pendingEquipmentList.filter(p => p.status === '待审核').length > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#EF4444] px-1 text-[10px] font-bold text-white">{pendingEquipmentList.filter(p => p.status === '待审核').length}</span>
              )}
            </button>
          </div>
          {pageTab === 'equipment' && (
            <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 rounded-md border border-[#D1D5DB] px-2 py-1">
              <Search size={12} className="text-[#9CA3AF]" />
              <input
                type="text" placeholder="搜索编码/名称/型号/品牌..."
                value={searchText} onChange={(e) => { setSearchText(e.target.value); setCurrentPage(1) }}
                className="w-48 bg-transparent text-xs outline-none"
              />
            </div>
            <button onClick={() => setShowAdd(true)} className="inline-flex h-7 items-center gap-1 rounded-md bg-[#1A56DB] px-3 text-xs text-white transition hover:bg-[#153E7E]">
              <Plus size={13} /> 新增装备
            </button>
            <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> 导入
            </button>
            <button className="inline-flex h-7 items-center gap-1 rounded-md border border-[#E5E7EB] bg-white px-3 text-xs text-[#374151] transition hover:bg-[#F3F4F6]">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> 导出
            </button>
            </div>
          )}
        </div>

        {pageTab === 'equipment' && (
        <div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F9FAFB]">
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">序号</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备编码</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">装备名称</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">所属分类</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">型号</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">型号编码</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">计量单位</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">是否电池</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">保养周期(月)</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">原厂商</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">状态</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold uppercase tracking-wider text-[#6B7280]">操作</th>
              </tr>
            </thead>
            <tbody>
              {paginated.map((eq, idx) => (
                <tr key={eq.id} className="border-b border-[#F3F4F6] transition hover:bg-[#F9FAFB]">
                  <td className="px-3 py-2.5 text-[#6B7280]">{(safePage - 1) * pageSize + idx + 1}</td>
                  <td className="px-3 py-2.5 font-mono text-xs text-[#1A56DB]">{eq.code}</td>
                  <td className="px-3 py-2.5 font-medium text-[#374151]">{eq.name}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.category}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.model}</td>
                  <td className="px-3 py-2.5 font-mono text-xs text-[#6B7280]">{eq.modelCode}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.unit}</td>
                  <td className="px-3 py-2.5">
                    {eq.hasBattery === '是'
                      ? <span className="flex items-center gap-1 text-xs text-[#D97706]"><BatteryMedium size={12} />是</span>
                      : <span className="flex items-center gap-1 text-xs text-[#6B7280]"><Battery size={12} />否</span>
                    }
                  </td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.maintenanceMonths}</td>
                  <td className="px-3 py-2.5 text-[#374151]">{eq.manufacturer}</td>
                  <td className="px-3 py-2.5"><Badge variant={sV(eq.status)}>{eq.status}</Badge></td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setDetailEq(eq)} className="rounded p-1 text-[#1A56DB] transition hover:bg-[#E8F0FE]" title="查看"><Eye size={14} /></button>
                      <button className="rounded p-1 text-[#F59E0B] transition hover:bg-[#FEF3C7]" title="编辑"><Pencil size={14} /></button>
                      <button className="rounded p-1 text-[#EF4444] transition hover:bg-[#FEF2F2]" title="删除"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {paginated.length === 0 && (
            <div className="py-12 text-center text-sm text-[#9CA3AF]">暂无装备数据</div>
          )}
        </div>

        {/* Pagination */}
        {filtered.length > 0 && (
          <div className="flex items-center justify-between border-t border-[#E5E7EB] px-4 py-2.5">
            <span className="text-xs text-[#6B7280]">显示 {(safePage - 1) * pageSize + 1}-{Math.min(safePage * pageSize, filtered.length)} / 共 {filtered.length} 条</span>
            <div className="flex items-center gap-1">
              <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={safePage <= 1} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">上一页</button>
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                <button key={p} onClick={() => setCurrentPage(p)} className={cn(
                  'h-7 w-7 rounded-md text-xs font-medium transition',
                  safePage === p ? 'bg-[#1A56DB] text-white' : 'text-[#6B7280] hover:bg-[#F3F4F6]'
                )}>{p}</button>
              ))}
              <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={safePage >= totalPages} className="rounded-md border border-[#D1D5DB] px-2.5 py-1 text-xs text-[#6B7280] transition hover:bg-[#F3F4F6] disabled:opacity-40">下一页</button>
            </div>
          </div>
        )}
        </div>
        )}
        {pageTab === 'pending' && (
          <PendingEquipmentPanel />
        )}
      </div>

      {/* Detail Drawer */}
      {detailEq && <EquipmentDetailDrawer equipment={detailEq} onClose={() => setDetailEq(null)} />}

      {/* Add Modal */}
      <AddEquipmentModal open={showAdd} onClose={() => setShowAdd(false)} />
    </div>
  )
}
