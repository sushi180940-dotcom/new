import { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  Database,
  ShieldCheck,
  Warehouse,
  AlertTriangle,
  UserCircle,
  BarChart3,
  GraduationCap,
  MessageSquare,
  GitBranch,
  ChevronDown,
  ChevronRight,
  Shield,
} from 'lucide-react'
import { cn } from '@/lib/utils'

interface SidebarProps {
  collapsed: boolean
}

interface MenuItem {
  key: string
  icon: React.ReactNode
  label: string
  path?: string
  children?: MenuItem[]
}

const menuData: MenuItem[] = [
  {
    key: 'dashboard',
    icon: <LayoutDashboard size={20} />,
    label: '首页工作台',
    path: '/dashboard',
  },
  {
    key: 'warehouse',
    icon: <Warehouse size={20} />,
    label: '日常装备管理',
    children: [
      { key: 'ledger', icon: <ChevronRight size={14} />, label: '仓库台账', path: '/warehouse/ledger' },
      { key: 'inbound', icon: <ChevronRight size={14} />, label: '入库管理', path: '/warehouse/inbound' },
      { key: 'outbound', icon: <ChevronRight size={14} />, label: '出库管理', path: '/warehouse/outbound',
        children: [
          { key: 'pickup', icon: <ChevronRight size={14} />, label: '装备领用', path: '/warehouse/pickup' },
          { key: 'allocation', icon: <ChevronRight size={14} />, label: '配发管理', path: '/warehouse/allocation' },
          { key: 'transfer', icon: <ChevronRight size={14} />, label: '调拨管理', path: '/warehouse/transfer' },
          { key: 'repair', icon: <ChevronRight size={14} />, label: '报修管理', path: '/warehouse/repair' },
          { key: 'scrap', icon: <ChevronRight size={14} />, label: '报废管理', path: '/warehouse/scrap' },
        ],
      },
      { key: 'inventory', icon: <ChevronRight size={14} />, label: '盘点管理', path: '/warehouse/inventory' },
      { key: 'maintenance', icon: <ChevronRight size={14} />, label: '保养登记', path: '/warehouse/maintenance' },
      { key: 'channel', icon: <ChevronRight size={14} />, label: '通道记录', path: '/warehouse/channel' },
    ],
  },
  {
    key: 'emergency',
    icon: <AlertTriangle size={20} />,
    label: '应急装备管理',
    children: [
      { key: 'inbound', icon: <ChevronRight size={14} />, label: '入库管理', path: '/warehouse/inbound' },
      { key: 'pickup', icon: <ChevronRight size={14} />, label: '装备领用', path: '/warehouse/pickup' },
      { key: 'ledger', icon: <ChevronRight size={14} />, label: '仓库台账', path: '/warehouse/ledger' },
      { key: 'outbound', icon: <ChevronRight size={14} />, label: '出库管理', path: '/warehouse/outbound' },
      { key: 'maintenance', icon: <ChevronRight size={14} />, label: '保养登记', path: '/warehouse/maintenance' },
      { key: 'repair', icon: <ChevronRight size={14} />, label: '报修管理', path: '/warehouse/repair' },
      { key: 'scrap', icon: <ChevronRight size={14} />, label: '报废管理', path: '/warehouse/scrap' },
      { key: 'transfer', icon: <ChevronRight size={14} />, label: '调拨管理', path: '/warehouse/transfer' },
      { key: 'allocation', icon: <ChevronRight size={14} />, label: '配发管理', path: '/warehouse/allocation' },
      { key: 'inventory', icon: <ChevronRight size={14} />, label: '盘点管理', path: '/warehouse/inventory' },
      { key: 'channel', icon: <ChevronRight size={14} />, label: '通道记录', path: '/warehouse/channel' },
    ],
  },
  {
    key: 'supervision',
    icon: <ShieldCheck size={20} />,
    label: '装备监督管理',
    children: [
      { key: 'warning-rules', icon: <ChevronRight size={14} />, label: '预警规则', path: '/supervision/warning-rules' },
      { key: 'warning-records', icon: <ChevronRight size={14} />, label: '预警记录', path: '/supervision/warning-records' },
      { key: 'equipment-control', icon: <ChevronRight size={14} />, label: '异常装备监管', path: '/supervision/equipment-control' },
    ],
  },
  {
    key: 'analysis',
    icon: <BarChart3 size={20} />,
    label: '装备研判分析',
    children: [
      { key: 'procurement', icon: <ChevronRight size={14} />, label: '采购分析', path: '/analysis/procurement' },
      { key: 'allocation', icon: <ChevronRight size={14} />, label: '配备分析', path: '/analysis/allocation' },
      { key: 'aftersales', icon: <ChevronRight size={14} />, label: '售后分析', path: '/analysis/aftersales' },
      { key: 'supplier-analysis', icon: <ChevronRight size={14} />, label: '供应商分析', path: '/analysis/supplier' },
      { key: 'quality', icon: <ChevronRight size={14} />, label: '质量分析', path: '/analysis/quality' },
      { key: 'distribution', icon: <ChevronRight size={14} />, label: '分布分析', path: '/analysis/distribution' },
    ],
  },
  {
    key: 'training',
    icon: <GraduationCap size={20} />,
    label: '应用技能培训',
    children: [
      { key: 'materials', icon: <ChevronRight size={14} />, label: '培训资料', path: '/training/materials' },
      { key: 'process', icon: <ChevronRight size={14} />, label: '培训过程', path: '/training/process' },
    ],
  },
  {
    key: 'forum',
    icon: <MessageSquare size={20} />,
    label: '交流论坛',
    path: '/forum',
  },
  {
    key: 'personal',
    icon: <UserCircle size={20} />,
    label: '个人中心',
    children: [
      { key: 'my-equipment', icon: <ChevronRight size={14} />, label: '我的装备', path: '/personal/my-equipment' },
      { key: 'borrow', icon: <ChevronRight size={14} />, label: '领用管理', path: '/personal/borrow' },
      { key: 'personal-repair', icon: <ChevronRight size={14} />, label: '报修申请', path: '/personal/repair' },
      { key: 'handover', icon: <ChevronRight size={14} />, label: '交接记录', path: '/personal/handover' },
      { key: 'complaint', icon: <ChevronRight size={14} />, label: '我的投诉', path: '/personal/complaint' },
    ],
  },
  {
    key: 'workflow',
    icon: <GitBranch size={20} />,
    label: '流程管理',
    children: [
      { key: 'design', icon: <ChevronRight size={14} />, label: '流程设计', path: '/workflow/design' },
      { key: 'templates', icon: <ChevronRight size={14} />, label: '流程模板', path: '/workflow/templates' },
      { key: 'monitor', icon: <ChevronRight size={14} />, label: '流程监控', path: '/workflow/monitor' },
    ],
  },
  {
    key: 'basic-info',
    icon: <Database size={20} />,
    label: '基础信息管理',
    children: [
      { key: 'supplier', icon: <ChevronRight size={14} />, label: '供应商管理', path: '/basic-info/supplier', children: [
        { key: 'supplier-evaluation', icon: <ChevronRight size={14} />, label: '供应商评价', path: '/basic-info/supplier-evaluation' },
      ]},
      { key: 'warehouse', icon: <ChevronRight size={14} />, label: '仓库信息', path: '/basic-info/warehouse' },
      { key: 'equipment-lib', icon: <ChevronRight size={14} />, label: '装备分类管理', path: '/basic-info/equipment-lib' },
      { key: 'standard', icon: <ChevronRight size={14} />, label: '配备标准', path: '/basic-info/standard' },
      { key: 'rfid', icon: <ChevronRight size={14} />, label: 'RFID管理', path: '/basic-info/rfid' },
    ],
  },
]

export default function Sidebar({ collapsed }: SidebarProps) {
  const location = useLocation()
  const navigate = useNavigate()
  const [expandedKeys, setExpandedKeys] = useState<string[]>(['basic-info', 'warehouse', 'supervision'])

  const toggleExpand = (key: string) => {
    setExpandedKeys((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    )
  }

  const isActive = (path?: string) => {
    if (!path) return false
    return location.pathname === path
  }

  const isParentActive = (item: MenuItem) => {
    if (!item.children) return false
    return item.children.some((child) => location.pathname === child.path)
  }

  const handleNavigate = (path?: string) => {
    if (path) navigate(path)
  }

  /* ── Recursive SubMenuItem ── */
  function SubMenuItem({
    item,
    depth,
    expandedKeys,
    toggleExpand,
    isActive,
    handleNavigate,
  }: {
    item: MenuItem
    depth: number
    expandedKeys: string[]
    toggleExpand: (key: string) => void
    isActive: (path?: string) => boolean
    handleNavigate: (path?: string) => void
  }) {
    const hasChildren = !!item.children
    const isExpanded = expandedKeys.includes(item.key)
    const activeSelf = isActive(item.path)
    const childActive = hasChildren
      ? item.children!.some((c) => isActive(c.path) || c.children?.some((gc) => isActive(gc.path)))
      : false

    if (!hasChildren) {
      return (
        <button
          onClick={() => handleNavigate(item.path)}
          className={cn(
            'flex h-10 w-full items-center gap-2 pr-4 text-left text-[13px] text-[#374151] transition hover:bg-[#F3F4F6]',
            activeSelf && 'border-l-4 border-[#1A56DB] bg-[#E8F0FE] font-medium text-[#1A56DB]'
          )}
          style={{ paddingLeft: `${depth * 20 + 12}px` }}
        >
          {item.label}
        </button>
      )
    }

    return (
      <div>
        <button
          onClick={() => {
            toggleExpand(item.key)
            if (item.path) handleNavigate(item.path)
          }}
          className={cn(
            'flex h-10 w-full items-center gap-2 pr-4 text-left text-[13px] transition hover:bg-[#F3F4F6]',
            (activeSelf || childActive || isExpanded) ? 'text-[#1A56DB]' : 'text-[#374151]',
            (activeSelf || childActive) && 'border-l-4 border-[#1A56DB] bg-[#E8F0FE] font-medium'
          )}
          style={{ paddingLeft: `${depth * 20 + 8}px` }}
        >
          <ChevronDown
            size={12}
            className={cn('transition-transform', !isExpanded && 'rotate-[-90deg]')}
          />
          <span className="flex-1">{item.label}</span>
        </button>
        {isExpanded && (
          <div>
            {item.children!.map((child) => (
              <SubMenuItem
                key={child.key}
                item={child}
                depth={depth + 1}
                expandedKeys={expandedKeys}
                toggleExpand={toggleExpand}
                isActive={isActive}
                handleNavigate={handleNavigate}
              />
            ))}
          </div>
        )}
      </div>
    )
  }

  return (
    <aside
      className={cn(
        'fixed left-0 top-14 z-40 h-[calc(100vh-3.5rem)] overflow-y-auto overflow-x-hidden border-r border-[#E5E7EB] bg-white transition-all duration-200',
        collapsed ? 'w-16' : 'w-[220px]'
      )}
    >
      {/* Collapsed logo area */}
      {collapsed && (
        <div className="flex h-12 items-center justify-center border-b border-[#E5E7EB]">
          <Shield size={20} className="text-[#1A56DB]" />
        </div>
      )}

      <nav className="py-2">
        {menuData.map((item) => {
          const hasChildren = !!item.children
          const isExpanded = expandedKeys.includes(item.key)
          const activeParent = isParentActive(item)
          const activeSelf = isActive(item.path)

          if (collapsed) {
            return (
              <div key={item.key} className="relative">
                {hasChildren ? (
                  <>
                    <button
                      onClick={() => toggleExpand(item.key)}
                      className={cn(
                        'flex h-12 w-full items-center justify-center transition hover:bg-[#F3F4F6]',
                        (activeParent || isExpanded) && 'text-[#1A56DB]'
                      )}
                      title={item.label}
                    >
                      {item.icon}
                    </button>
                    {isExpanded && (
                      <div className="absolute left-full top-0 z-50 ml-0 min-w-[160px] rounded-r-lg border border-[#E5E7EB] bg-white py-1 shadow-lg">
                        <div className="px-3 py-2 text-xs font-semibold text-[#9CA3AF]">{item.label}</div>
                        {item.children?.map((child) => (
                          <button
                            key={child.key}
                            onClick={() => handleNavigate(child.path)}
                            className={cn(
                              'flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition hover:bg-[#F3F4F6]',
                              isActive(child.path) && 'bg-[#E8F0FE] text-[#1A56DB]'
                            )}
                          >
                            {child.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </>
                ) : (
                  <button
                    onClick={() => handleNavigate(item.path)}
                    className={cn(
                      'flex h-12 w-full items-center justify-center transition hover:bg-[#F3F4F6]',
                      activeSelf && 'text-[#1A56DB]'
                    )}
                    title={item.label}
                  >
                    {item.icon}
                  </button>
                )}
              </div>
            )
          }

          // Expanded sidebar
          return (
            <div key={item.key}>
              {hasChildren ? (
                <>
                  <button
                    onClick={() => toggleExpand(item.key)}
                    className={cn(
                      'flex h-12 w-full items-center gap-3 px-4 text-sm transition hover:bg-[#F3F4F6]',
                      (activeParent || isExpanded) && 'text-[#1A56DB]',
                      activeParent && 'border-l-4 border-[#1A56DB] bg-[#E8F0FE]'
                    )}
                  >
                    {item.icon}
                    <span className="flex-1 text-left text-[14px]">{item.label}</span>
                    <ChevronDown
                      size={14}
                      className={cn('transition-transform', !isExpanded && 'rotate-[-90deg]')}
                    />
                  </button>
                  {isExpanded && (
                    <div className="bg-white">
                      {item.children?.map((child) => (
                        <SubMenuItem
                          key={child.key}
                          item={child}
                          depth={1}
                          expandedKeys={expandedKeys}
                          toggleExpand={toggleExpand}
                          isActive={isActive}
                          handleNavigate={handleNavigate}
                        />
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <button
                  onClick={() => handleNavigate(item.path)}
                  className={cn(
                    'flex h-12 w-full items-center gap-3 px-4 text-sm transition hover:bg-[#F3F4F6]',
                    activeSelf
                      ? 'border-l-4 border-[#1A56DB] bg-[#E8F0FE] font-medium text-[#1A56DB]'
                      : 'text-[#374151]'
                  )}
                  style={!activeSelf ? { paddingLeft: '20px' } : undefined}
                >
                  {item.icon}
                  <span className="text-[14px]">{item.label}</span>
                </button>
              )}
            </div>
          )
        })}
      </nav>
    </aside>
  )
}
